create package body PKG_CREDIT_ACCOUNT_CONTROL is

  /*----------------------------------------------------------------
  *         包：PKG_CREDIT_ACCOUNT_CONTROL
  *   创建日期：2014-06-28
  *     创建者：苏冬渊
  *   功能说明：处理信用控制中的资金校验、账户款项变更、重新款项明细、重新账户款项、账户款项日冻结
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  */ ----------------------------------------------------------------

  V_NL             CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
  V_SEC_RESULT         CONSTANT NUMBER := 0; --成功返回
  V_SUCCESS        CONSTANT VARCHAR2(10) := 'SUCCESS';
  V_BASE_EXCEPTION EXCEPTION; --自定义异常
  
  LG_LINE_STATE_NORMAL CONSTANT VARCHAR2(10) := 'NORMAL';
  LG_LINE_STATE_CLOSED CONSTANT VARCHAR2(10) := 'CLOSED';
  
  PROCEDURE 获取营销明细临时ID is begin null ; end ;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-01
  *     创建者：苏冬渊
  *   功能说明：在调用资金校验之前，由于一个单据可能会多个品类，所以调用校验之前，先将
  *             营销大类及其额度等存放在临时表中
  *             T_CREDIT_CONTROL_TEMP 单据营销大类临时存放表（销售单、订单、收款单）
  *   此函数用以获取该临时表的ID
  *
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_CONTROL_TEMP_ID RETURN NUMBER IS
    V_CONTROL_TEMP_ID NUMBER ;
  BEGIN
    SELECT S_CREDIT_CONTROL_TEMP.NEXTVAL INTO V_CONTROL_TEMP_ID FROM DUAL ;
    RETURN V_CONTROL_TEMP_ID ;
  EXCEPTION WHEN OTHERS THEN
    RETURN NULL;
  END ;

  PROCEDURE 以下为调用入口 is begin null ; end ;
  /*
   1：订单评审
      2：订单取消
      3：开单（销售单）
      4：开单（销售红冲单）
      5：开单（退货单）
      6：开单（退货红冲单）
      7：开单（折让证明单）
      8：开单（折让证明红冲单）
      9：开单（销售折让单）
      10：开单（销售折让红冲单）
      11：开单（扣率折让单）
      12：开单（扣率折让红冲单）
      13：结算（退货单）
      14：结算（销售单）
      15：收款确认（不包括三方承兑）
      16：收款冲销
      17：三方承兑到款
      18：三方承兑冲销
      19：三方承兑解付
      20：三方承兑解付冲销
      21：退款
      22：铺底审批（铺底）
      23：铺底审批（临时铺底）
      24：铺底审批（冻结折让）
      25：铺底到期（铺底）
      26：铺底到期（临时铺底）
      27：铺底到期（冻结折让）
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-08
  *     创建者：苏冬渊
  *   功能说明：订单调用接口:订单评审，取消订单
  *             该过程只有订单调用
  */
  -------------------------------------------------------------------------------
  /*PROCEDURE PRC_CREDIT_ORDER_BILL(P_ENTITY_ID               IN NUMBER, --主体ID
                                  P_ACTION_TYPE          IN NUMBER, --动作标示
                                  P_CONTROL_TEMP_ID       IN NUMBER, --单据临时ID
                                  P_ACCOUNT_ID           IN NUMBER, --账户ID
                                  P_CUSTOMER_ID          IN NUMBER, --客户ID
                                  P_PROJ_NUMBER          IN VARCHAR2, --项目号
                                  P_ORDER_ID             IN NUMBER,   --单据ID
                                  P_ORDER_TYPE           IN VARCHAR2, --单据类型
                                  P_USERNAME            IN VARCHAR2 ,
                                  P_RESULT            IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG           IN OUT VARCHAR2 --返回错误信息
                            ) IS
    CURSOR CUR_CREDIT_CONTROL_TEMP IS
    SELECT * FROM T_CREDIT_CONTROL_TEMP T WHERE T.CONTROL_TEMP_ID = P_CONTROL_TEMP_ID ;
    --V_CREDIT_GROUP_ID NUMBER ;
  BEGIN
    IF P_ACTION_TYPE <> 1 AND P_ACTION_TYPE <> 2 THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '传入动作标识有问题，P_ACTION_TYPE IN (1，2)表示订单！';
      RETURN ;
    END IF;

    FOR I IN CUR_CREDIT_CONTROL_TEMP LOOP
    BEGIN
      PRC_CREDIT_VERIFICATION(P_ENTITY_ID          => P_ENTITY_ID, --主体ID
                              P_ACTION_TYPE        => P_ACTION_TYPE, --动作标示
                              P_Settlement_SUM     => I.SETTLEMENT_SUM, --结算金额
                              P_Discount_SUM       => I.DISCOUNT_SUM, --折扣金额
                              P_THREE_NO_PAY_SUM   => NULL , --三方承兑锁定金额
                              P_SALES_MAIN_TYPE => I.SALES_MAIN_TYPE , --营销大类
                              P_ACCOUNT_ID  => P_ACCOUNT_ID, --账户ID
                              P_CUSTOMER_ID => P_CUSTOMER_ID, --客户ID
                              P_PROJ_NUMBER => P_PROJ_NUMBER , --项目号
                              P_CREATED_MODE =>  NULL ,
                              P_RESULT      =>  P_RESULT, --返回错误ID
                              P_ERR_MSG     =>  P_ERR_MSG --返回错误信息
                      ) ;
        IF P_RESULT <> V_SEC_RESULT THEN
           GOTO HERE ;
        END IF ;
     EXCEPTION WHEN OTHERS THEN
        P_RESULT  := -20000;
        P_ERR_MSG := '调用资金校验模块出现异常，请了解！'|| V_NL || SQLERRM ;
        RETURN ;
     END ;
     END LOOP ;
     --如果检验通过，则调用款项变更
     IF P_RESULT = V_SEC_RESULT THEN
       FOR I IN CUR_CREDIT_CONTROL_TEMP LOOP
       BEGIN
          PRC_CREDIT_FUND_UPDATE(P_ENTITY_ID       => P_ENTITY_ID, --主体ID
                                 P_ACTION_TYPE     => P_ACTION_TYPE, --动作标示
                                 P_Settlement_SUM  => I.SETTLEMENT_SUM, --结算金额
                                 P_Discount_SUM    => I.DISCOUNT_SUM, --折扣金额
                                 P_THREE_NOT_PAY   => NULL, --三方承兑锁定金额
                                 P_SALES_MAIN_TYPE => I.SALES_MAIN_TYPE, --营销大类
                                 P_ACCOUNT_ID         => P_ACCOUNT_ID, --账户ID
                                 P_CUSTOMER_ID        => P_CUSTOMER_ID, --客户ID
                                 P_PROJ_NUMBER        => P_PROJ_NUMBER, --项目号
                                 P_ORDER_ID           => P_ORDER_ID, --单据ID
                                 P_ORDER_TYPE         => P_ORDER_TYPE, --单据类型
                                 P_USERNAME            => P_USERNAME ,
                                 P_RESULT             => P_RESULT, --返回错误ID
                                 P_ERR_MSG            => P_ERR_MSG --返回错误信息
                                 );
          IF P_RESULT <> V_SEC_RESULT THEN
           GOTO HERE ;
          END IF ;
       EXCEPTION WHEN OTHERS THEN
          P_RESULT  := -20000;
          P_ERR_MSG := '调用款项变更模块出现异常，请了解！'|| V_NL || SQLERRM ;
          RETURN ;
       END ;
       END LOOP ;
     END IF ;
     <<HERE>>
     NULL ;
  END ; */--PRC_CREDIT_ORDER_BILL

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-01
  *     创建者：苏冬渊
  *   功能说明：销售单调用接口,比订单入口多了开单方式P_CREATED_MODE
  */
  -------------------------------------------------------------------------------
  /*PROCEDURE PRC_CREDIT_SALES_BILL(P_ENTITY_ID               IN NUMBER, --主体ID
                                  P_ACTION_TYPE          IN NUMBER, --动作标示
                                  P_CONTROL_TEMP_ID       IN NUMBER, --单据临时ID
                                  P_ACCOUNT_ID           IN NUMBER, --账户ID
                                  P_CUSTOMER_ID          IN NUMBER, --客户ID
                                  P_PROJ_NUMBER          IN VARCHAR2, --项目号
                                  P_CREATED_MODE         IN NUMBER,   --开单方式
                                  P_ORDER_ID             IN NUMBER,   --单据ID
                                  P_ORDER_TYPE           IN VARCHAR2, --单据类型
                                  P_USERNAME            IN VARCHAR2 ,
                                  P_RESULT            IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG           IN OUT VARCHAR2 --返回错误信息
                            ) IS
    CURSOR CUR_CREDIT_CONTROL_TEMP IS
    SELECT * FROM T_CREDIT_CONTROL_TEMP T WHERE T.CONTROL_TEMP_ID = P_CONTROL_TEMP_ID ;

  BEGIN

    IF P_ACTION_TYPE < 3 OR P_ACTION_TYPE > 10 THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '传入动作标识有问题，3=<P_ACTION_TYPE<=10表示销售单！';
      RETURN ;
    END IF;

    FOR I IN CUR_CREDIT_CONTROL_TEMP LOOP
    BEGIN
      PRC_CREDIT_VERIFICATION(P_ENTITY_ID          => P_ENTITY_ID, --主体ID
                              P_ACTION_TYPE        => P_ACTION_TYPE, --动作标示
                              P_Settlement_SUM     => I.SETTLEMENT_SUM, --结算金额
                              P_Discount_SUM       => I.DISCOUNT_SUM, --折扣金额
                              P_THREE_NO_PAY_SUM   => NULL , --三方承兑锁定金额
                              P_SALES_MAIN_TYPE => I.SALES_MAIN_TYPE , --营销大类
                              P_ACCOUNT_ID  => P_ACCOUNT_ID, --账户ID
                              P_CUSTOMER_ID => P_CUSTOMER_ID, --客户ID
                              P_PROJ_NUMBER => P_PROJ_NUMBER , --项目号
                              P_CREATED_MODE    =>  P_CREATED_MODE ,  --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                              P_RESULT      =>  P_RESULT, --返回错误ID
                              P_ERR_MSG     =>  P_ERR_MSG --返回错误信息
                      ) ;
       IF P_RESULT <> V_SEC_RESULT THEN
           GOTO HERE ;
       END IF ;
     EXCEPTION WHEN OTHERS THEN
        P_RESULT  := -20000;
        P_ERR_MSG := '调用资金校验模块出现异常，请了解！'|| V_NL || SQLERRM ;
        RETURN ;
     END ;
     END LOOP ;
     --如果检验通过，则调用款项变更
     IF P_RESULT = V_SEC_RESULT THEN
       FOR I IN CUR_CREDIT_CONTROL_TEMP LOOP
       BEGIN
          PRC_CREDIT_FUND_UPDATE(P_ENTITY_ID       => P_ENTITY_ID, --主体ID
                                 P_ACTION_TYPE     => P_ACTION_TYPE, --动作标示
                                 P_Settlement_SUM  => I.SETTLEMENT_SUM, --结算金额
                                 P_Discount_SUM    => I.DISCOUNT_SUM, --折扣金额
                                 P_THREE_NOT_PAY   => NULL, --三方承兑锁定金额
                                 P_SALES_MAIN_TYPE => I.SALES_MAIN_TYPE, --营销大类
                                 P_ACCOUNT_ID         => P_ACCOUNT_ID, --账户ID
                                 P_CUSTOMER_ID        => P_CUSTOMER_ID, --客户ID
                                 P_PROJ_NUMBER        => P_PROJ_NUMBER, --项目号
                                 P_ORDER_ID           => P_ORDER_ID, --单据ID
                                 P_ORDER_TYPE         => P_ORDER_TYPE, --单据类型
                                 P_USERNAME            => P_USERNAME ,
                                 P_RESULT             => P_RESULT, --返回错误ID
                                 P_ERR_MSG            => P_ERR_MSG --返回错误信息
                                 );
          IF P_RESULT <> V_SEC_RESULT THEN
             GOTO HERE ;
          END IF ;
       EXCEPTION WHEN OTHERS THEN
          P_RESULT  := -20000;
          P_ERR_MSG := '调用款项变更模块出现异常，请了解！'|| V_NL || SQLERRM ;
          RETURN ;
       END ;
       END LOOP ;
     END IF ;
     <<HERE>>
     NULL ;
  END ; --PRC_CREDIT_SALES_BILL
  */
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-08
  *     创建者：苏冬渊
  *   功能说明：收款单调用该接口(不包括三方承兑)
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_RECEIVE_BILL(P_ENTITY_ID               IN NUMBER, --主体ID
                                  P_ACTION_TYPE          IN NUMBER, --动作标示
                                  P_CONTROL_TEMP_ID       IN NUMBER, --单据临时ID
                                  P_ACCOUNT_ID           IN NUMBER, --账户ID
                                  P_CUSTOMER_ID          IN NUMBER, --客户ID
                                  P_PROJ_NUMBER          IN VARCHAR2, --项目号
                                  P_ORDER_ID             IN NUMBER,   --单据ID
                                  P_ORDER_TYPE           IN VARCHAR2, --单据类型
                                  P_USERNAME            IN VARCHAR2 , --用户名称
                                  P_RESULT            IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG           IN OUT VARCHAR2 --返回错误信息
                            ) IS
   CURSOR CUR_CREDIT_CONTROL_TEMP IS
    SELECT * FROM T_CREDIT_CONTROL_TEMP T WHERE T.CONTROL_TEMP_ID = P_CONTROL_TEMP_ID ;
   V_COUNT NUMBER ;
   VS_OS   VARCHAR2(300);
  BEGIN
    IF P_ACTION_TYPE < 15 OR P_ACTION_TYPE > 27 OR P_ACTION_TYPE IN (17,18,19,20)THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '传入动作标识有问题，15=<P_ACTION_TYPE<=27和P_ACTION_TYPE NOT IN (17,18,19,20)表示收款、三方承兑的处理！';
      RETURN ;
    END IF;

    SELECT COUNT(1) INTO V_COUNT
      FROM T_CREDIT_CONTROL_TEMP T
     WHERE T.CONTROL_TEMP_ID = P_CONTROL_TEMP_ID;

    IF V_COUNT = 0 THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '临时表中没有查到营销大类的款项金额信息，请先保存该款项信息！';
      RETURN ;
    END IF ;
    --增加信用控制的总保存点2014-10-29. 苏冬渊
    SAVEPOINT SAVEPOINT_CREDIT ;

    FOR I IN CUR_CREDIT_CONTROL_TEMP LOOP
    BEGIN
      PRC_CREDIT_VERIFICATION(P_ENTITY_ID          => P_ENTITY_ID, --主体ID
                              P_ACTION_TYPE        => P_ACTION_TYPE, --动作标示
                              P_Settlement_SUM     => I.SETTLEMENT_SUM, --结算金额
                              P_Discount_SUM       => I.DISCOUNT_SUM, --折扣金额
                              P_ORDER_ID           => P_ORDER_ID , --单据ID
                              P_SALES_MAIN_TYPE => I.SALES_MAIN_TYPE , --营销大类
                              P_ACCOUNT_ID  => P_ACCOUNT_ID, --账户ID
                              P_CUSTOMER_ID => P_CUSTOMER_ID, --客户ID
                              P_PROJ_NUMBER => P_PROJ_NUMBER , --项目号
                              P_CREATED_MODE    =>  NULL ,  --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                              P_RESULT      =>  P_RESULT, --返回错误ID
                              P_ERR_MSG     =>  P_ERR_MSG, --返回错误信息
                              P_ORDER_TYPE  => P_ORDER_TYPE,--订单类型
                              IS_DISCOUNT_TYPE => I.DISCOUNT_TYPE,--折让方式
                              IS_PLN_SRC_ORDER_TYPE => NULL--订单源类型
                      ) ;
        IF P_RESULT <> V_SEC_RESULT THEN
           ROLLBACK TO SAVEPOINT_CREDIT ;
           GOTO HERE ;
        END IF ;
     EXCEPTION WHEN OTHERS THEN
        P_RESULT  := -20000;
        P_ERR_MSG := '调用资金校验模块出现异常，请了解！'|| V_NL ||P_ERR_MSG ;
        ROLLBACK TO SAVEPOINT_CREDIT ;
        RETURN ;
     END ;
     END LOOP ;
     --如果检验通过，则调用款项变更
     IF P_RESULT = V_SEC_RESULT THEN
       FOR I IN CUR_CREDIT_CONTROL_TEMP LOOP
       BEGIN
          PRC_CREDIT_FUND_UPDATE(P_ENTITY_ID       => P_ENTITY_ID, --主体ID
                                 P_ACTION_TYPE     => P_ACTION_TYPE, --动作标示
                                 P_Settlement_SUM  => I.SETTLEMENT_SUM, --结算金额
                                 P_Discount_SUM    => I.DISCOUNT_SUM, --折扣金额
                                 P_SALES_MAIN_TYPE => I.SALES_MAIN_TYPE, --营销大类
                                 P_ACCOUNT_ID         => P_ACCOUNT_ID, --账户ID
                                 P_CUSTOMER_ID        => P_CUSTOMER_ID, --客户ID
                                 P_PROJ_NUMBER        => P_PROJ_NUMBER, --项目号
                                 P_CREATED_MODE    =>  null ,
                                 P_ORDER_ID           => P_ORDER_ID, --单据ID
                                 P_ORDER_TYPE         => P_ORDER_TYPE, --单据类型
                                 P_USERNAME           => P_USERNAME ,
                                 P_RESULT             => P_RESULT, --返回错误ID
                                 P_ERR_MSG            => P_ERR_MSG --返回错误信息
                                 );
          IF P_RESULT <> V_SEC_RESULT THEN
             ROLLBACK TO SAVEPOINT_CREDIT ;
             GOTO HERE ;
          END IF ;
       EXCEPTION WHEN OTHERS THEN
          --P_RESULT  := -20000;
          P_ERR_MSG := '调用款项变更模块出现异常，请了解！'|| V_NL || P_ERR_MSG ;
          ROLLBACK TO SAVEPOINT_CREDIT ;
          RETURN ;
       END ;
       BEGIN
          PKG_CREDIT_DIS.P_CHECK_DIS_AMOUNT(IN_ACTION_TYPE     => P_ACTION_TYPE, --动作标示
                                 IN_ENTITY_ID       => P_ENTITY_ID, --主体ID
                                 IN_ACCOUNT_ID         => P_ACCOUNT_ID, --账户ID
                                 IS_SOURCE_TYPE        => '12',--来源类型 取码表 SO_SRC_TYPE P_ORDER_TYPE 取销售单一样
                                 IN_SOURCE_BILL_ID           => P_ORDER_ID, --单据ID
                                 IS_SALES_MAIN_TYPE => I.SALES_MAIN_TYPE, --营销大类
                                 IS_DISCOUNT_TYPE => I.DISCOUNT_TYPE,--折让方式
                                 IN_AMOUNT  => I.SETTLEMENT_SUM, --金额
                                 IS_USER_NAME           => P_USERNAME ,
                                 IS_ATTRIB01            => NULL,--
                                 IS_ATTRIB02            => NULL,--
                                 ON_RESULT             => P_RESULT, --返回错误ID 
                                 --V_SEC_RESULT         CONSTANT NUMBER := 0; --成功返回
                                 OS_MESSAGE            => P_ERR_MSG, --返回错误信息
                                 OS_ATTRIB01           => VS_OS,
                                 OS_ATTRIB02           => VS_OS
                                 );
          IF P_RESULT <> V_SEC_RESULT THEN
             ROLLBACK TO SAVEPOINT_CREDIT ;
             GOTO HERE ;
          END IF ;
       EXCEPTION WHEN OTHERS THEN
          --P_RESULT  := -20000;
          P_ERR_MSG := '调用折让到款更新出现异常，请了解！'|| V_NL || P_ERR_MSG ;
          ROLLBACK TO SAVEPOINT_CREDIT ;
          RETURN ;
       END ;
       END LOOP ;
     END IF ;
     <<HERE>>
     NULL ;
  END ; --PRC_CREDIT_RECEIVE_BILL

   -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-08
  *     创建者：苏冬渊
  *   功能说明：三方承兑单调用接口
  *             该过程只有三方承兑单据调用
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_THREE_PAY(P_ENTITY_ID               IN NUMBER, --主体ID
                                  P_ACTION_TYPE          IN NUMBER, --动作标示
                                  P_CONTROL_TEMP_ID       IN NUMBER, --单据临时ID
                                  P_ACCOUNT_ID           IN NUMBER, --账户ID
                                  P_CUSTOMER_ID          IN NUMBER, --客户ID
                                  P_PROJ_NUMBER          IN VARCHAR2, --项目号
                                  P_ORDER_ID             IN NUMBER,   --单据ID
                                  P_ORDER_TYPE           IN VARCHAR2, --单据类型
                                  P_USERNAME            IN VARCHAR2 ,
                                  P_RESULT            IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG           IN OUT VARCHAR2 --返回错误信息
                            ) IS
   CURSOR CUR_CREDIT_CONTROL_TEMP IS
    SELECT * FROM T_CREDIT_CONTROL_TEMP T WHERE T.CONTROL_TEMP_ID = P_CONTROL_TEMP_ID ;

   V_COUNT NUMBER ;
   VS_OS   VARCHAR2(300);
  BEGIN
    IF P_ACTION_TYPE NOT IN (17,18,19,20) THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '传入动作标识有问题，P_ACTION_TYPE IN (17,18,19,20)表示三方承兑单据！';
      RETURN ;
    END IF;

    SELECT COUNT(1) INTO V_COUNT
      FROM T_CREDIT_CONTROL_TEMP T
     WHERE T.CONTROL_TEMP_ID = P_CONTROL_TEMP_ID;

    IF V_COUNT = 0 THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '临时表中没有查到营销大类的款项金额信息，请先保存该款项信息！';
      RETURN ;
    END IF ;

    --增加信用控制的总保存点2014-10-29. 苏冬渊
    SAVEPOINT SAVEPOINT_CREDIT ;

    FOR I IN CUR_CREDIT_CONTROL_TEMP LOOP
        BEGIN
          PRC_CREDIT_VERIFICATION(P_ENTITY_ID          => P_ENTITY_ID, --主体ID
                                  P_ACTION_TYPE        => P_ACTION_TYPE, --动作标示
                                  P_Settlement_SUM     => I.SETTLEMENT_SUM, --结算金额
                                  P_Discount_SUM       => NULL , --折扣金额
                                  P_ORDER_ID        => P_ORDER_ID, --单据ID
                                  P_SALES_MAIN_TYPE => I.SALES_MAIN_TYPE , --营销大类
                                  P_ACCOUNT_ID  => P_ACCOUNT_ID, --账户ID
                                  P_CUSTOMER_ID => P_CUSTOMER_ID, --客户ID
                                  P_PROJ_NUMBER => P_PROJ_NUMBER , --项目号
                                  P_CREATED_MODE    =>  NULL , --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                                  P_RESULT      =>  P_RESULT, --返回错误ID
                                  P_ERR_MSG     =>  P_ERR_MSG, --返回错误信息
                                  P_ORDER_TYPE  => P_ORDER_TYPE,--订单类型
                                  IS_DISCOUNT_TYPE => I.DISCOUNT_TYPE,--折让方式
                                  IS_PLN_SRC_ORDER_TYPE => NULL--订单源类型
                          ) ;
            IF P_RESULT <> V_SEC_RESULT THEN
               ROLLBACK TO SAVEPOINT_CREDIT ;
               GOTO HERE ;
            END IF ;
         EXCEPTION WHEN OTHERS THEN
            --P_RESULT  := -20000;
            P_ERR_MSG := '调用资金校验模块出现异常，请了解！'|| V_NL || P_ERR_MSG ;
            ROLLBACK TO SAVEPOINT_CREDIT ;
            RETURN ;
         END ;
     END LOOP ;
     --如果检验通过，则调用款项变更
     IF P_RESULT = V_SEC_RESULT THEN
       FOR I IN CUR_CREDIT_CONTROL_TEMP LOOP
         BEGIN
            PRC_CREDIT_FUND_UPDATE(P_ENTITY_ID       => P_ENTITY_ID, --主体ID
                                   P_ACTION_TYPE     => P_ACTION_TYPE, --动作标示
                                   P_Settlement_SUM  => I.SETTLEMENT_SUM, --结算金额
                                   P_Discount_SUM    => NULL, --折扣金额
                                   P_SALES_MAIN_TYPE => I.Sales_Main_Type, --营销大类
                                   P_ACCOUNT_ID         => P_ACCOUNT_ID, --账户ID
                                   P_CUSTOMER_ID        => P_CUSTOMER_ID, --客户ID
                                   P_PROJ_NUMBER        => P_PROJ_NUMBER, --项目号
                                   P_CREATED_MODE    =>  null ,
                                   P_ORDER_ID           => P_ORDER_ID, --单据ID
                                   P_ORDER_TYPE         => P_ORDER_TYPE, --单据类型
                                   P_USERNAME            => P_USERNAME ,
                                   P_RESULT             => P_RESULT, --返回错误ID
                                   P_ERR_MSG            => P_ERR_MSG --返回错误信息
                                   );
            IF P_RESULT <> V_SEC_RESULT THEN
               ROLLBACK TO SAVEPOINT_CREDIT ;
               GOTO HERE ;
            END IF ;
            
       BEGIN
          PKG_CREDIT_DIS.P_CHECK_DIS_AMOUNT(IN_ACTION_TYPE     => P_ACTION_TYPE, --动作标示
                                 IN_ENTITY_ID       => P_ENTITY_ID, --主体ID
                                 IN_ACCOUNT_ID         => P_ACCOUNT_ID, --账户ID
                                 IS_SOURCE_TYPE        => '12',--来源类型 取码表 SO_SRC_TYPE P_ORDER_TYPE 取销售单一样
                                 IN_SOURCE_BILL_ID           => P_ORDER_ID, --单据ID
                                 IS_SALES_MAIN_TYPE => I.SALES_MAIN_TYPE, --营销大类
                                 IS_DISCOUNT_TYPE => I.DISCOUNT_TYPE,--折让方式
                                 IN_AMOUNT  => I.SETTLEMENT_SUM, --金额
                                 IS_USER_NAME           => P_USERNAME ,
                                 IS_ATTRIB01            => NULL,--
                                 IS_ATTRIB02            => NULL,--
                                 ON_RESULT             => P_RESULT, --返回错误ID 
                                 --V_SEC_RESULT         CONSTANT NUMBER := 0; --成功返回
                                 OS_MESSAGE            => P_ERR_MSG, --返回错误信息
                                 OS_ATTRIB01           => VS_OS,
                                 OS_ATTRIB02           => VS_OS
                                 );
          IF P_RESULT <> V_SEC_RESULT THEN
             ROLLBACK TO SAVEPOINT_CREDIT ;
             GOTO HERE ;
          END IF ;
       EXCEPTION WHEN OTHERS THEN
          --P_RESULT  := -20000;
          P_ERR_MSG := '调用折让到款更新出现异常，请了解！'|| V_NL || P_ERR_MSG ;
          ROLLBACK TO SAVEPOINT_CREDIT ;
          RETURN ;
       END ;
       
            --如果调用款项变更操作成功，并且是三方承兑解付，三方承兑解付冲销
            --则调用铺底核销
            If P_ACTION_TYPE IN (19,20) THEN
               PKG_CREDIT_THREE_PAY.PRC_CREDIT_TREEDELAYPAY_UPDATE(P_ENTITY_ID => P_ENTITY_ID,
                                                            P_ACTION_TYPE => P_ACTION_TYPE,
                                                            P_SALES_MAIN_TYPE => I.Sales_Main_Type,
                                                            P_ACCOUNT_ID => P_ACCOUNT_ID,
                                                            P_CUSTOMER_ID => P_CUSTOMER_ID,
                                                            P_ORDER_ID => P_ORDER_ID,
                                                            P_USERNAME => P_USERNAME,
                                                            P_RESULT => P_RESULT,
                                                            P_ERR_MSG => P_ERR_MSG) ;
               IF P_RESULT <> V_SEC_RESULT THEN
                  ROLLBACK TO SAVEPOINT_CREDIT ;
                  GOTO HERE ;
               END IF ;

            END IF ;

         EXCEPTION WHEN OTHERS THEN
            --P_RESULT  := -20000;
            P_ERR_MSG := '调用款项变更模块出现异常，请了解！'|| V_NL || P_ERR_MSG ;
            ROLLBACK TO SAVEPOINT_CREDIT ;
            RETURN ;
         END ;
       END LOOP ;
     END IF ;

     --如果调用款项变更操作成功，并且是三方承兑解付，三方承兑解付冲销
     --则调用铺底核销
     /*IF P_RESULT = V_SEC_RESULT AND P_ACTION_TYPE IN (19,20) THEN
        PRC_CREDIT_DELAYPAY_APPLIED_AT(P_ACTION_TYPE => P_ACTION_TYPE, --动作标识
                                       P_SETTLE_AMOUNT => P_SETTLE_AMOUNT, --结算金额
                                       P_ENTITY_ID => P_ENTITY_ID, --主体ID
                                       P_CUSTOMER_ID => P_CUSTOMER_ID, --客户ID
                                       P_ACCOUNT_ID => P_ACCOUNT_ID , --账户ID
                                       P_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE, --营销大类
                                       P_CASH_RECEIPT_ID NUMBER , --收款单据ID
                                       P_THREE_PAY_ID NUMBER, --三方承兑ID
                                       P_USERNAME VARCHAR2,
                                       P_RESULT   IN OUT NUMBER, --返回错误ID
                                       P_ERR_MSG  IN OUT VARCHAR2 --返回错误信息
                                       )
     END IF ;*/


     <<HERE>>
     NULL ;
  END ; --PRC_CREDIT_THREE_PAY

  PROCEDURE PRC_CREDIT_ORDER_BILL(P_ENTITY_ID               IN NUMBER, --主体ID
                                    P_ACTION_TYPE          IN NUMBER, --动作标示
                                    P_Settlement_SUM       IN NUMBER, --结算金额
                                    P_Discount_SUM         IN NUMBER, --折让金额
                                    P_SALES_MAIN_TYPE   IN VARCHAR2, --营销大类
                                    P_ACCOUNT_ID           IN NUMBER, --账户ID
                                    P_CUSTOMER_ID          IN NUMBER, --客户ID
                                    P_PROJ_NUMBER          IN VARCHAR2, --项目号
                                    P_ORDER_ID             IN NUMBER,   --单据ID
                                    P_ORDER_TYPE           IN VARCHAR2, --单据类型
                                    P_USERNAME            IN VARCHAR2 ,
                                    P_RESULT            IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG           IN OUT VARCHAR2, --返回错误信息
                                    IS_DISCOUNT_TYPE    IN VARCHAR2 DEFAULT NULL--
                            ) IS
    --V_CREDIT_GROUP_ID NUMBER ;
     V_PLN_SRC_ORDER_TYPE	 T_PLN_ORDER_TYPE.SOURCE_ORDER_TYPE_ID%TYPE;--订单类型：1提货订单，0计划订单
     V_PLN_LG_ORDER_HEAD   T_PLN_LG_ORDER_HEAD%ROWTYPE;
     V_PLN_ORDER_HEAD T_PLN_ORDER_HEAD%ROWTYPE; --计划订单头数据
     V_DOWN_PAY_SCALE NUMBER;
     V_LOCK_AMOUNT_FLAG T_PLN_ORDER_TYPE.CHK_CUSG_AMOUNT_FLAG%TYPE;
  BEGIN
    IF P_ACTION_TYPE NOT IN (1,2,28,29) THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '传入动作标识有问题，P_ACTION_TYPE IN (1,2,28,29)表示订单！';
      RETURN ;
    END IF;

    IF P_SALES_MAIN_TYPE IS NULL AND P_PROJ_NUMBER IS NULL THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '传入营销大类和项目号有误，必须有一个不为空！';
       RETURN ;
    END IF ;

    --增加信用控制的总保存点2014-10-29. 苏冬渊
    SAVEPOINT SAVEPOINT_CREDIT ;

    BEGIN
       --20160909 梁颜明 订金金额校验
       --V_PLN_SRC_ORDER_TYPE获取订单类型 1提货订单
       IF P_ACTION_TYPE IN (1,2,28,29) THEN
         SELECT MAX(SOURCE_ORDER_TYPE_ID) INTO V_PLN_SRC_ORDER_TYPE FROM T_PLN_ORDER_TYPE
         WHERE ENTITY_ID = P_ENTITY_ID AND ORDER_TYPE_CODE = P_ORDER_TYPE;
       END IF;
       --判断是提货订单，根据订单ID获取提货订单头表的订金比例、订金、锁款类型
       IF V_PLN_SRC_ORDER_TYPE IN (1,10,0) THEN
       IF V_PLN_SRC_ORDER_TYPE IN (1,10) THEN
         SELECT * INTO V_PLN_LG_ORDER_HEAD FROM T_PLN_LG_ORDER_HEAD
         WHERE ORDER_HEAD_ID = P_ORDER_ID;
         IF V_PLN_LG_ORDER_HEAD.ORDER_TYPE_CODE <> P_ORDER_TYPE THEN
           P_RESULT  := -20000 ;
           P_ERR_MSG := '订单传入参数检查不通过：传入的订单类型编码：'
             || P_ORDER_TYPE || '与提货订单 ' || V_PLN_LG_ORDER_HEAD.ORDER_NUMBER || ' 对应的订单类型编码：'
           || V_PLN_LG_ORDER_HEAD.ORDER_TYPE_CODE || '不一致';
           RETURN;
           END IF;
           V_DOWN_PAY_SCALE := V_PLN_LG_ORDER_HEAD.DOWN_PAY_SCALE;
           V_LOCK_AMOUNT_FLAG := V_PLN_LG_ORDER_HEAD.LOCK_AMOUNT_FLAG;
         ELSIF V_PLN_SRC_ORDER_TYPE IN (0) THEN --计划订单
           SELECT * INTO V_PLN_ORDER_HEAD FROM T_PLN_ORDER_HEAD
           WHERE ORDER_HEAD_ID = P_ORDER_ID;
           IF V_PLN_ORDER_HEAD.ORDER_TYPE_CODE <> P_ORDER_TYPE THEN
             P_RESULT  := -20000 ;
             P_ERR_MSG := '订单传入参数检查不通过：传入的订单类型编码：'
             || P_ORDER_TYPE || '与计划订单 ' || V_PLN_ORDER_HEAD.ORDER_NUMBER || ' 对应的订单类型编码：'
             || V_PLN_LG_ORDER_HEAD.ORDER_TYPE_CODE || '不一致';
             RETURN;
           END IF;
           V_DOWN_PAY_SCALE := V_PLN_ORDER_HEAD.DOWN_PAY_SCALE;
           V_LOCK_AMOUNT_FLAG := V_PLN_ORDER_HEAD.LOCK_AMOUNT_FLAG;
         END IF;
       END IF;
      --如果动作标识是28，送审锁款，并且订金比例为空或小于0，不做任何处理，直接返回成功
      IF P_ACTION_TYPE IN (28,29) AND (V_LOCK_AMOUNT_FLAG IN ('S','RS','HQ')
        AND 0 > NVL(V_DOWN_PAY_SCALE,-1)) THEN
        P_RESULT  := V_SEC_RESULT ;
        P_ERR_MSG := V_SUCCESS;
        RETURN;
      END IF;
      PRC_CREDIT_VERIFICATION(P_ENTITY_ID          => P_ENTITY_ID, --主体ID
                              P_ACTION_TYPE        => P_ACTION_TYPE, --动作标示
                              P_Settlement_SUM     => P_Settlement_SUM, --结算金额
                              P_Discount_SUM       => P_Discount_SUM, --折扣金额
                              P_ORDER_ID        => P_ORDER_ID, --单据ID
                              P_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE , --营销大类
                              P_ACCOUNT_ID  => P_ACCOUNT_ID, --账户ID
                              P_CUSTOMER_ID => P_CUSTOMER_ID, --客户ID
                              P_PROJ_NUMBER => P_PROJ_NUMBER , --项目号
                              P_CREATED_MODE =>  NULL ,
                              P_RESULT      =>  P_RESULT, --返回错误ID
                              P_ERR_MSG     =>  P_ERR_MSG, --返回错误信息
                              P_ORDER_TYPE  =>  P_ORDER_TYPE,--单据类型编码
                              IS_DISCOUNT_TYPE => IS_DISCOUNT_TYPE,
                              IS_PLN_SRC_ORDER_TYPE => V_PLN_SRC_ORDER_TYPE
                      ) ;
        IF P_RESULT <> V_SEC_RESULT THEN
           ROLLBACK TO SAVEPOINT_CREDIT ;
           GOTO HERE ;
        END IF ;
     EXCEPTION WHEN OTHERS THEN
        P_RESULT  := -20000;
        P_ERR_MSG := '调用资金校验模块出现异常，请了解！'|| V_NL || SQLERRM ;
        ROLLBACK TO SAVEPOINT_CREDIT ;
        RETURN ;
     END ;
     --如果检验通过，则调用款项变更
     IF P_RESULT = V_SEC_RESULT THEN
       IF V_DOWN_PAY_SCALE >= 0 AND V_LOCK_AMOUNT_FLAG IN ('S','HQ') THEN
         IF 1 = P_ACTION_TYPE OR 29 = P_ACTION_TYPE THEN
           BEGIN
             PKG_CREDIT_DOWN_PAY.P_LOCK_DOWN_PAY_AMOUNT(IN_ORDER_ID => P_ORDER_ID, --单据ID
             IS_ORDER_TYPE => P_ORDER_TYPE, --单据类型
             IS_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE, --营销大类
             IN_LOCK_AMOUNT => P_Settlement_SUM,--结算金额
             IN_ENTITY_ID => P_ENTITY_ID,--主体ID
             IN_CUSTOMER_ID => P_CUSTOMER_ID,--客户ID
             IN_ACCOUNT_ID => P_ACCOUNT_ID,--账户ID
             IN_DOWN_PAY_RATE => V_DOWN_PAY_SCALE,--V_PLN_LG_ORDER_HEAD.DOWN_PAY_SCALE,--订金比例
             IS_ACTION_TYPE => P_ACTION_TYPE,--动作标示
             IS_USER_ACCOUNT => P_USERNAME,--
             OS_MESSAGE => P_ERR_MSG,
             IS_DISCOUNT_TYPE => IS_DISCOUNT_TYPE
             );--返回错误信息
           EXCEPTION WHEN OTHERS THEN
              IF SQLCODE = -30006 OR SQLCODE = -54 THEN
               P_RESULT  := -20000;
               P_ERR_MSG := '调用订金锁定出现异常，原因：订单存在并发的多次操作，处理超过3秒或者3秒内存在大批量操作，请稍等再重试！';
              ELSE
               P_RESULT  := -20000;
               P_ERR_MSG := '调用订金锁定出现异常，请了解！'|| V_NL || SQLERRM ;
              END IF;
             ROLLBACK TO SAVEPOINT_CREDIT ;
             RETURN;
           END;
           BEGIN
             PKG_CREDIT_DOWN_PAY.P_LOCK_DP_DIS_AMOUNT(IN_ORDER_ID => P_ORDER_ID, --单据ID
             IS_ORDER_TYPE => P_ORDER_TYPE, --单据类型
             IS_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE, --营销大类
             IN_LOCK_AMOUNT => P_Discount_SUM,--结算金额
             IN_ENTITY_ID => P_ENTITY_ID,--主体ID
             IN_CUSTOMER_ID => P_CUSTOMER_ID,--客户ID
             IN_ACCOUNT_ID => P_ACCOUNT_ID,--账户ID
             IN_DOWN_PAY_RATE => V_DOWN_PAY_SCALE,--V_PLN_LG_ORDER_HEAD.DOWN_PAY_SCALE,--订金比例
             IS_ACTION_TYPE => P_ACTION_TYPE,--动作标示
             IS_USER_ACCOUNT => P_USERNAME,--
             OS_MESSAGE => P_ERR_MSG,
             IS_DISCOUNT_TYPE => IS_DISCOUNT_TYPE
             );--返回错误信息
           EXCEPTION WHEN OTHERS THEN
              IF SQLCODE = -30006 OR SQLCODE = -54 THEN
               P_RESULT  := -20000;
               P_ERR_MSG := '调用折扣订金锁定出现异常，原因：订单存在并发的多次操作，处理超过3秒或者3秒内存在大批量操作，请稍等再重试！';
              ELSE
               P_RESULT  := -20000;
               P_ERR_MSG := '调用折扣订金锁定出现异常，请了解'|| V_NL || SQLERRM ;
              END IF;
             ROLLBACK TO SAVEPOINT_CREDIT ;
             RETURN;
           END;
         ELSIF 2 = P_ACTION_TYPE OR 28 = P_ACTION_TYPE THEN
           BEGIN
             PKG_CREDIT_DOWN_PAY.P_UNLOCK_DOWN_PAY_AMOUNT(IN_ORDER_ID => P_ORDER_ID, --单据ID
             IS_ORDER_TYPE => P_ORDER_TYPE, --单据类型
             IS_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE, --营销大类
             IN_UNLOCK_AMOUNT => P_Settlement_SUM,--结算金额
             IN_ENTITY_ID => P_ENTITY_ID,--主体ID
             IN_CUSTOMER_ID => P_CUSTOMER_ID,--客户ID
             IN_ACCOUNT_ID => P_ACCOUNT_ID,--账户ID
             IN_DOWN_PAY_RATE => V_DOWN_PAY_SCALE,--V_PLN_LG_ORDER_HEAD.DOWN_PAY_SCALE,--订金比例
             IS_ACTION_TYPE => P_ACTION_TYPE,--动作标示
             IS_USER_ACCOUNT => P_USERNAME,
             OS_MESSAGE => P_ERR_MSG,
             IS_DISCOUNT_TYPE => IS_DISCOUNT_TYPE
             );--返回错误信息
           EXCEPTION WHEN OTHERS THEN
              IF SQLCODE = -30006 OR SQLCODE = -54 THEN
               P_RESULT  := -20000;
               P_ERR_MSG := '调用订金释放出现异常，原因：订单存在并发的多次操作，处理超过3秒或者3秒内存在大批量操作，请稍等再重试！';
              ELSE
               P_RESULT  := -20000;
               P_ERR_MSG := '调用订金释放出现异常，请了解！'|| V_NL || SQLERRM ;
              END IF;
             ROLLBACK TO SAVEPOINT_CREDIT ;
             RETURN;
           END;
           BEGIN
             PKG_CREDIT_DOWN_PAY.P_UNLOCK_DP_DIS_AMOUNT(IN_ORDER_ID => P_ORDER_ID, --单据ID
             IS_ORDER_TYPE => P_ORDER_TYPE, --单据类型
             IS_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE, --营销大类
             IN_UNLOCK_AMOUNT => P_Discount_SUM,--结算金额
             IN_ENTITY_ID => P_ENTITY_ID,--主体ID
             IN_CUSTOMER_ID => P_CUSTOMER_ID,--客户ID
             IN_ACCOUNT_ID => P_ACCOUNT_ID,--账户ID
             IN_DOWN_PAY_RATE => V_DOWN_PAY_SCALE,--V_PLN_LG_ORDER_HEAD.DOWN_PAY_SCALE,--订金比例
             IS_ACTION_TYPE => P_ACTION_TYPE,--动作标示
             IS_USER_ACCOUNT => P_USERNAME,
             OS_MESSAGE => P_ERR_MSG,
             IS_DISCOUNT_TYPE => IS_DISCOUNT_TYPE
             );--返回错误信息
           EXCEPTION WHEN OTHERS THEN
              IF SQLCODE = -30006 OR SQLCODE = -54 THEN
               P_RESULT  := -20000;
               P_ERR_MSG := '调用折扣订金释放出现异常，原因：订单存在并发的多次操作，处理超过3秒或者3秒内存在大批量操作，请稍等再重试！';
              ELSE
               P_RESULT  := -20000;
               P_ERR_MSG := '调用折扣订金释放出现异常，请了解！'|| V_NL || SQLERRM ;
              END IF;
             ROLLBACK TO SAVEPOINT_CREDIT ;
             RETURN;
           END;
         END IF;
       END IF;
       
       IF P_ERR_MSG IS NOT NULL AND 'SUCCESS' <> P_ERR_MSG THEN
         IF 1 = P_ACTION_TYPE OR 29 = P_ACTION_TYPE THEN
           P_ERR_MSG := '订金锁定不成功：'|| V_NL || P_ERR_MSG ;
           --P_RESULT  := -20000;
           --RETURN ;
         ELSIF 2 = P_ACTION_TYPE OR 28 = P_ACTION_TYPE THEN
           P_ERR_MSG := '订金释放不成功：'|| V_NL || P_ERR_MSG ;
           --P_RESULT  := -20000;
           --RETURN ;
         END IF;
         P_RESULT  := -20000;
         RETURN ;
       END IF;
       
       /*IF 1 = P_ACTION_TYPE AND 1 = PKG_CREDIT_DOWN_PAY.
         FUN_JUDGE_OCCUPY_ORDER_AMOUNT(NULL,V_PLN_LG_ORDER_HEAD) THEN
         BEGIN
           PKG_CREDIT_DOWN_PAY.P_LOCK_ORDER_AMOUNT(IN_ORDER_ID => P_ORDER_ID, --单据ID
           IS_ORDER_TYPE => P_ORDER_TYPE, --单据类型
           IN_LOCK_AMOUNT => P_Settlement_SUM,--结算金额
           IN_ENTITY_ID => P_ENTITY_ID,--主体ID
           IN_CUSTOMER_ID => P_CUSTOMER_ID,--客户ID
           IN_ACCOUNT_ID => P_ACCOUNT_ID,--账户ID
           IS_USER_ACCOUNT => P_USERNAME,
           OS_MESSAGE => P_ERR_MSG);--返回错误信息
         EXCEPTION WHEN OTHERS THEN
           P_RESULT  := -20000;
           P_ERR_MSG := '调用订单提货额度锁定出现异常，请了解！'|| V_NL || SQLERRM ;
           ROLLBACK TO SAVEPOINT_CREDIT ;
           RETURN;
         END;
       
         IF P_ERR_MSG IS NOT NULL AND 'SUCCESS' <> P_ERR_MSG THEN
           P_ERR_MSG := '订单提货额度锁定不成功：'|| V_NL || P_ERR_MSG ;
           P_RESULT  := -20000;
           RETURN ;
         END IF;
       END IF;*/
       
       IF P_ACTION_TYPE IN (28,29) OR NOT (P_ACTION_TYPE IN (1,2)
         AND NVL(V_DOWN_PAY_SCALE,-1) >= 0
         AND NVL(V_LOCK_AMOUNT_FLAG,'N') IN ('S','HQ')) THEN
         BEGIN
            PRC_CREDIT_FUND_UPDATE(P_ENTITY_ID       => P_ENTITY_ID, --主体ID
                                   P_ACTION_TYPE     => P_ACTION_TYPE, --动作标示
                                   P_Settlement_SUM  => P_Settlement_SUM, --结算金额
                                   P_Discount_SUM    => P_Discount_SUM, --折扣金额
                                   P_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE, --营销大类
                                   P_ACCOUNT_ID         => P_ACCOUNT_ID, --账户ID
                                   P_CUSTOMER_ID        => P_CUSTOMER_ID, --客户ID
                                   P_PROJ_NUMBER        => P_PROJ_NUMBER, --项目号
                                   P_CREATED_MODE    =>  null ,  --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                                   P_ORDER_ID           => P_ORDER_ID, --单据ID
                                   P_ORDER_TYPE         => P_ORDER_TYPE, --单据类型
                                   P_USERNAME            => P_USERNAME ,
                                   P_RESULT             => P_RESULT, --返回错误ID
                                   P_ERR_MSG            => P_ERR_MSG --返回错误信息
                                   );
            IF P_RESULT <> V_SEC_RESULT THEN
             ROLLBACK TO SAVEPOINT_CREDIT ;
             GOTO HERE ;
            END IF ;
         EXCEPTION WHEN OTHERS THEN
            P_RESULT  := -20000;
            P_ERR_MSG := '调用款项变更模块出现异常，请了解！'|| V_NL || SQLERRM ;
            ROLLBACK TO SAVEPOINT_CREDIT ;
            RETURN ;
         END ;
       END IF;
     END IF ;
     <<HERE>>
     NULL ;
  END ; --PRC_CREDIT_订单入口

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-07
  *     创建者：苏冬渊
  *   功能说明：销售单调用接口,比订单入口多了开单方式P_CREATED_MODE
                扣率折让单、结算单调用接口，铺底单据也调用该接口，但是开单方式应传null
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_SALES_BILL(P_ENTITY_ID               IN NUMBER, --主体ID
                                  P_ACTION_TYPE          IN NUMBER, --动作标示
                                  P_Settlement_SUM       IN NUMBER, --结算金额
                                  P_Discount_SUM         IN NUMBER, --折让金额
                                  P_SALES_MAIN_TYPE   IN VARCHAR2, --营销大类
                                  P_ACCOUNT_ID           IN NUMBER, --账户ID
                                  P_CUSTOMER_ID          IN NUMBER, --客户ID
                                  P_PROJ_NUMBER          IN VARCHAR2, --项目号
                                  P_CREATED_MODE         IN NUMBER,   --开单方式
                                  P_ORDER_ID             IN NUMBER,   --单据ID
                                  P_ORDER_TYPE           IN VARCHAR2, --单据类型
                                  P_USERNAME             IN VARCHAR2 ,
                                  P_RESULT            IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG           IN OUT VARCHAR2 --返回错误信息
                            ) IS
    --V_CREDIT_GROUP_ID NUMBER ;
    VS_DISCOUNT_TYPE    T_SO_HEADER.DISCOUNT_TYPE%TYPE;
    R_SO_HEADER T_SO_HEADER%ROWTYPE;
  BEGIN

    IF P_ACTION_TYPE < 3 OR (P_ACTION_TYPE > 14 AND P_ACTION_TYPE NOT IN (22,23,24,25,26,27)) THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '传入动作标识有问题，3=<P_ACTION_TYPE<=14表示销售单及其结算过程,P_ACTION_TYPE NOT IN (22,23,24,25,26,27)表示铺底！';
      RETURN ;
    END IF;

    --增加信用控制的总保存点2014-10-29. 苏冬渊
    SAVEPOINT SAVEPOINT_CREDIT ;

    BEGIN
      IF P_ACTION_TYPE BETWEEN 3 AND 14 THEN
        BEGIN
          
          SELECT T.* INTO R_SO_HEADER FROM T_SO_HEADER T WHERE T.SO_HEADER_ID = P_ORDER_ID;
          
        EXCEPTION WHEN OTHERS THEN
          NULL;
        END;
      END IF;
      PRC_CREDIT_VERIFICATION(P_ENTITY_ID          => P_ENTITY_ID, --主体ID
                              P_ACTION_TYPE        => P_ACTION_TYPE, --动作标示
                              P_Settlement_SUM     => P_Settlement_SUM, --结算金额
                              P_Discount_SUM       => P_Discount_SUM, --折扣金额
                              P_ORDER_ID        => P_ORDER_ID, --单据ID
                              P_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE , --营销大类
                              P_ACCOUNT_ID  => P_ACCOUNT_ID, --账户ID
                              P_CUSTOMER_ID => P_CUSTOMER_ID, --客户ID
                              P_PROJ_NUMBER => P_PROJ_NUMBER , --项目号
                              P_CREATED_MODE    =>  P_CREATED_MODE ,  --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                              P_RESULT      =>  P_RESULT, --返回错误ID
                              P_ERR_MSG     =>  P_ERR_MSG --返回错误信息
                              ,P_ORDER_TYPE =>  P_ORDER_TYPE
                              ,IS_DISCOUNT_TYPE => R_SO_HEADER.DISCOUNT_TYPE
                      ) ;
        IF P_RESULT <> V_SEC_RESULT THEN
           ROLLBACK TO SAVEPOINT_CREDIT ;
           GOTO HERE ;
        END IF ;
     EXCEPTION WHEN OTHERS THEN
        P_RESULT  := -20000;
        P_ERR_MSG := '调用资金校验模块出现异常，请了解！'|| V_NL || SQLERRM ;
        ROLLBACK TO SAVEPOINT_CREDIT ;
        RETURN ;
     END ;
     --如果检验通过，则调用款项变更
     IF P_RESULT = V_SEC_RESULT THEN
       BEGIN
          PRC_CREDIT_FUND_UPDATE(P_ENTITY_ID       => P_ENTITY_ID, --主体ID
                                 P_ACTION_TYPE     => P_ACTION_TYPE, --动作标示
                                 P_Settlement_SUM  => P_Settlement_SUM, --结算金额
                                 P_Discount_SUM    => P_Discount_SUM, --折扣金额
                                 P_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE, --营销大类
                                 P_ACCOUNT_ID         => P_ACCOUNT_ID, --账户ID
                                 P_CUSTOMER_ID        => P_CUSTOMER_ID, --客户ID
                                 P_PROJ_NUMBER        => P_PROJ_NUMBER, --项目号
                                 P_ORDER_ID           => P_ORDER_ID, --单据ID
                                 P_ORDER_TYPE         => P_ORDER_TYPE, --单据类型
                                 P_CREATED_MODE    =>  P_CREATED_MODE ,  --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                                 P_USERNAME            => P_USERNAME ,
                                 P_RESULT             => P_RESULT, --返回错误ID
                                 P_ERR_MSG            => P_ERR_MSG --返回错误信息
                                 );
         IF P_RESULT <> V_SEC_RESULT THEN
           ROLLBACK TO SAVEPOINT_CREDIT ;
           GOTO HERE ;
          END IF ;
       EXCEPTION WHEN OTHERS THEN
          P_RESULT  := -20000;
          P_ERR_MSG := '调用款项变更模块出现异常，请了解！'|| V_NL || SQLERRM ;
          ROLLBACK TO SAVEPOINT_CREDIT ;
          RETURN ;
       END ;
     END IF ;
     <<HERE>>
     NULL ;
  END ; --PRC_CREDIT_SALES_BILL
  
  
 PROCEDURE PRC_CREDIT_BATCH_SALES_BILL(P_ENTITY_ID   IN NUMBER, --主体ID
                                       P_RESULT      OUT NUMBER, --返回错误ID
                                       P_ERR_MSG     OUT VARCHAR2 --返回错误信息
                                  )IS                     
     V_CREDIT_GROUP_ID T_CREDIT_GROUP_CUST.Credit_Group_Id%TYPE; 
     V_ERROE_MSG VARCHAR(10000);  
     V_AMOUNT_ID NUMBER;     
     V_ORDER_TYPE VARCHAR2(400) ;
     
     V_UPDATE_TABLE VARCHAR2(4000);
     V_UPDATE_COLS   VARCHAR2(4000);
     V_UPDATE_WHERE VARCHAR2(4000);
     V_UPDATE_TABLE_MX VARCHAR2(4000);
     V_UPDATE_WHERE_MX VARCHAR2(4000);
     
     V_SQL     VARCHAR2(4000) ;
     V_SQL_MX  VARCHAR2(4000) ; 
     
     V_AMOUNT_MX_COUNT NUMBER;   
     V_ACTION_TYPE NUMBER;     
  BEGIN 
       
    UPDATE 
      T_SO_HEADER 
    SET 
     CREDIT_CONTROL_FLAG='P'
    WHERE 
      ENTITY_ID = P_ENTITY_ID
    AND  CREDIT_CONTROL_FLAG='N'
    AND  ROWNUM<=1000;
                               
    FOR 
      SO_HEADER_ROW 
       IN(SELECT
                ENTITY_ID
               ,CUSTOMER_ID
               ,ACCOUNT_ID 
               ,SALES_MAIN_TYPE
               ,CREATED_MODE
               ,BILL_TYPE_ID
               ,CREATED_BY
               ,BIZ_SRC_BILL_TYPE_CODE
               ,SUM(NVL(SETTLE_AMOUNT,0)) SETTLE_AMOUNT
               ,SUM(NVL(DISCOUNT_AMOUNT,0)) DISCOUNT_AMOUNT
            FROM 
              T_SO_HEADER 
            WHERE 
                CREDIT_CONTROL_FLAG='P' 
            AND ENTITY_ID = P_ENTITY_ID
            AND CREATED_MODE = 20
            GROUP BY 
                ENTITY_ID
               ,CUSTOMER_ID
               ,ACCOUNT_ID 
               ,SALES_MAIN_TYPE
               ,CREATED_MODE
               ,BILL_TYPE_ID
               ,CREATED_BY
               ,BIZ_SRC_BILL_TYPE_CODE
      )LOOP
          BEGIN 
              SAVEPOINT SP;
              --3、根据营销大类ID，客户ID，获取额度组
              V_CREDIT_GROUP_ID := pkg_credit_tools.FUN_GET_CREDITGROUPID(SO_HEADER_ROW.ENTITY_ID, SO_HEADER_ROW.CUSTOMER_ID,SO_HEADER_ROW.SALES_MAIN_TYPE
              --2017-4-22 获取额度组增加账户ID liangym2
              , SO_HEADER_ROW.ACCOUNT_ID);
             
              IF V_CREDIT_GROUP_ID = -2 THEN
                V_ERROE_MSG := '该客户已经存在特殊额度组，请到额度组维护模块维护特殊额度组与'|| SO_HEADER_ROW.SALES_MAIN_TYPE ||'的关系！'|| SQLERRM;
                RAISE_APPLICATION_ERROR(-20001,V_ERROE_MSG);   
              ELSIF V_CREDIT_GROUP_ID = -1 THEN
                V_ERROE_MSG := '根据营销大类查询额度组出错，请到额度组管理模块维护！' || SQLERRM;
                RAISE_APPLICATION_ERROR(-20001,V_ERROE_MSG); 
              END IF ;
              
              V_UPDATE_TABLE := 'UPDATE T_SALES_ACCOUNT_AMOUNT T SET ' ;
              V_UPDATE_COLS  := '' ;
              V_UPDATE_WHERE := ' WHERE T.ENTITY_ID = ' || SO_HEADER_ROW.ENTITY_ID
                                    ||' AND T.CUSTOMER_ID = '|| SO_HEADER_ROW.CUSTOMER_ID
                                    ||' AND T.ACCOUNT_ID = '|| SO_HEADER_ROW.ACCOUNT_ID
                                    ||' AND nvl(T.CREDIT_GROUP_ID,-1) = '|| nvl(V_CREDIT_GROUP_ID,-1)
                                    ||' AND nvl(T.PROJ_NUMBER,-1) = '||'-1' ;

              V_UPDATE_TABLE_MX := 'UPDATE T_SALES_ACCOUNT_MX_AMOUNT T SET ' ;
              
              V_UPDATE_WHERE_MX := ' WHERE T.ENTITY_ID = '||SO_HEADER_ROW.ENTITY_ID
                                       ||' AND T.CUSTOMER_ID = '|| SO_HEADER_ROW.CUSTOMER_ID
                                       ||' AND T.ACCOUNT_ID = '||SO_HEADER_ROW.ACCOUNT_ID
                                       ||' AND T.SALES_MAIN_TYPE = '''||SO_HEADER_ROW.SALES_MAIN_TYPE
                                       ||''' AND nvl(T.PROJ_NUMBER,-1) = '||'-1' ;   

               IF   SO_HEADER_ROW.BIZ_SRC_BILL_TYPE_CODE = '1001' THEN
                 
                  SELECT T.BILL_TYPE_NAME
                  INTO V_ORDER_TYPE
                  FROM V_SO_BILL_TYPE_EXTEND T
                  WHERE T.BILL_TYPE_ID = SO_HEADER_ROW.BILL_TYPE_ID
                  And t.ENTITY_ID = SO_HEADER_ROW.ENTITY_ID;  
               
                    IF SO_HEADER_ROW.CREATED_MODE <> 20 AND SO_HEADER_ROW.CREATED_MODE <> 30 THEN
                        V_UPDATE_COLS := ' T.SALES_AMOUNT = T.SALES_AMOUNT + ' || SO_HEADER_ROW.SETTLE_AMOUNT ||
                                         ',T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT - ' || SO_HEADER_ROW.SETTLE_AMOUNT ||
                                         ',T.APPLIED_DISCOUNT_AMOUNT = T.APPLIED_DISCOUNT_AMOUNT + ' || SO_HEADER_ROW.DISCOUNT_AMOUNT ||
                                         ',T.LOCK_DISCOUNT_AMOUNT = T.LOCK_DISCOUNT_AMOUNT - ' || SO_HEADER_ROW.DISCOUNT_AMOUNT ||
                                         ',T.LAST_UPDATED_BY = ''' || SO_HEADER_ROW.CREATED_BY ||
                                         ''',T.LAST_UPDATE_DATE = SYSDATE ';
                      
                    ELSIF SO_HEADER_ROW.CREATED_MODE = 20 THEN
                        V_UPDATE_COLS := ' T.SALES_AMOUNT = T.SALES_AMOUNT + ' || SO_HEADER_ROW.SETTLE_AMOUNT ||
                                         ',T.APPLIED_DISCOUNT_AMOUNT = T.APPLIED_DISCOUNT_AMOUNT + ' || SO_HEADER_ROW.DISCOUNT_AMOUNT ||
                                         ',T.LAST_UPDATED_BY = ''' || SO_HEADER_ROW.CREATED_BY ||
                                         ''',T.LAST_UPDATE_DATE = SYSDATE ';

                    ELSIF SO_HEADER_ROW.CREATED_MODE = 30 THEN
                        V_UPDATE_COLS := ' T.SALES_AMOUNT = T.SALES_AMOUNT + ' || SO_HEADER_ROW.SETTLE_AMOUNT ||
                                         ',T.APPLIED_DISCOUNT_AMOUNT = T.APPLIED_DISCOUNT_AMOUNT + ' || SO_HEADER_ROW.DISCOUNT_AMOUNT ||
                                         ',T.LAST_UPDATED_BY = ''' || SO_HEADER_ROW.CREATED_BY ||
                                         ''',T.LAST_UPDATE_DATE = SYSDATE ';
                    END IF ;
                    
               ELSIF SO_HEADER_ROW.BIZ_SRC_BILL_TYPE_CODE = '1003' THEN
                         V_UPDATE_COLS := ' T.SALES_AMOUNT = T.SALES_AMOUNT - ' || SO_HEADER_ROW.SETTLE_AMOUNT ||
                                          ',T.APPLIED_DISCOUNT_AMOUNT = T.APPLIED_DISCOUNT_AMOUNT - ' || SO_HEADER_ROW.DISCOUNT_AMOUNT ||
                                          ',T.LAST_UPDATED_BY = ''' || SO_HEADER_ROW.CREATED_BY ||
                                          ''',T.LAST_UPDATE_DATE = SYSDATE ';
               ELSE          
                    V_ERROE_MSG := '其他单据类型不支持批量更新款项';
                    RAISE_APPLICATION_ERROR(-20001,V_ERROE_MSG); 
               END IF;

              V_SQL := V_UPDATE_TABLE || V_UPDATE_COLS || V_UPDATE_WHERE ;
              V_SQL_MX := V_UPDATE_TABLE_MX || V_UPDATE_COLS || V_UPDATE_WHERE_MX ;
              
              SELECT
                  COUNT(*)
               INTO 
                  V_AMOUNT_MX_COUNT 
               FROM T_SALES_ACCOUNT_MX_AMOUNT T
              WHERE T.ENTITY_ID = SO_HEADER_ROW.ENTITY_ID
               AND T.CUSTOMER_ID = SO_HEADER_ROW.CUSTOMER_ID
               AND T.ACCOUNT_ID = SO_HEADER_ROW.ACCOUNT_ID
               AND nvl(T.PROJ_NUMBER,-1) = -1
               AND T.SALES_MAIN_TYPE = SO_HEADER_ROW.SALES_MAIN_TYPE ;  
      
              IF V_AMOUNT_MX_COUNT < 1 THEN
                 prc_credit_amount_contorl_init(p_entity_id => SO_HEADER_ROW.ENTITY_ID,
                                                p_customer_id => SO_HEADER_ROW.CUSTOMER_ID,
                                                p_account_id => SO_HEADER_ROW.ACCOUNT_ID,
                                                p_proj_number => null,
                                                p_sales_main_type => SO_HEADER_ROW.SALES_MAIN_TYPE ,
                                                p_username => '初始化',
                                                p_result => p_result,
                                                p_err_msg => p_err_msg);
                 IF P_RESULT <> V_SEC_RESULT THEN
                      V_ERROE_MSG := p_err_msg;
                      RAISE_APPLICATION_ERROR(-20001,V_ERROE_MSG); 
                 END IF ;
              END IF ; 
                   
               SELECT
                  ACCOUNT_AMOUNT_ID
               INTO 
                  V_AMOUNT_ID
               FROM T_SALES_ACCOUNT_AMOUNT T
              WHERE T.ENTITY_ID = SO_HEADER_ROW.ENTITY_ID
               AND T.CUSTOMER_ID = SO_HEADER_ROW.CUSTOMER_ID
               AND T.ACCOUNT_ID = SO_HEADER_ROW.ACCOUNT_ID
               AND NVL(T.PROJ_NUMBER,-1) = -1
               AND NVL(T.CREDIT_GROUP_ID,-1) =  NVL(V_CREDIT_GROUP_ID,-1)
               FOR UPDATE NOWAIT;
              
              EXECUTE IMMEDIATE V_SQL ;
              
              UPDATE 
                 T_SO_HEADER 
              SET 
                CREDIT_CONTROL_FLAG='Y'
              WHERE 
                ENTITY_ID = SO_HEADER_ROW.ENTITY_ID
              AND  CREDIT_CONTROL_FLAG='P'
              AND  CUSTOMER_ID = SO_HEADER_ROW.CUSTOMER_ID
              AND  ACCOUNT_ID = SO_HEADER_ROW.ACCOUNT_ID
              AND  SALES_MAIN_TYPE = SO_HEADER_ROW.SALES_MAIN_TYPE
              AND  CREATED_MODE = SO_HEADER_ROW.CREATED_MODE
              AND  BILL_TYPE_ID = SO_HEADER_ROW.BILL_TYPE_ID
              AND  BIZ_SRC_BILL_TYPE_CODE = SO_HEADER_ROW.BIZ_SRC_BILL_TYPE_CODE;

              EXECUTE IMMEDIATE V_SQL_MX ;
            
              commit;
          EXCEPTION
                WHEN OTHERS THEN
                     ROLLBACK TO SAVEPOINT SP;
                     --记录日志
                     V_ERROE_MSG := substr(sqlerrm,1,200);
                     
                      UPDATE 
                         T_SO_HEADER 
                      SET 
                        CREDIT_CONTROL_FLAG='E'
                       ,CREDIT_CONTROL_MSG =  V_ERROE_MSG
                      WHERE 
                        ENTITY_ID = SO_HEADER_ROW.ENTITY_ID
                      AND  CREDIT_CONTROL_FLAG='P'
                      AND  CUSTOMER_ID = SO_HEADER_ROW.CUSTOMER_ID
                      AND  ACCOUNT_ID = SO_HEADER_ROW.ACCOUNT_ID
                      AND  SALES_MAIN_TYPE = SO_HEADER_ROW.SALES_MAIN_TYPE
                      AND  CREATED_MODE = SO_HEADER_ROW.CREATED_MODE
                      AND  BILL_TYPE_ID = SO_HEADER_ROW.BILL_TYPE_ID
                      AND  BIZ_SRC_BILL_TYPE_CODE = SO_HEADER_ROW.BIZ_SRC_BILL_TYPE_CODE;
           END;
        END LOOP;  
  END PRC_CREDIT_BATCH_SALES_BILL;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-08
  *     创建者：苏冬渊
  *   功能说明：收款单、扣率折让单、结算单调用接口，铺底单据也调用该接口，
  *
  */
  -------------------------------------------------------------------------------
  /*PROCEDURE PRC_CREDIT_RECEIVE_BILL(P_ENTITY_ID               IN NUMBER, --主体ID
                                  P_ACTION_TYPE          IN NUMBER, --动作标示
                                  P_Settlement_SUM       IN NUMBER, --结算金额
                                  --P_Discount_SUM         IN NUMBER, --折让金额
                                  --P_THREE_NO_PAY_SUM       IN NUMBER, --三方承兑锁定金额
                                  P_SALES_MAIN_TYPE   IN VARCHAR2, --营销大类
                                  P_ACCOUNT_ID           IN NUMBER, --账户ID
                                  P_CUSTOMER_ID          IN NUMBER, --客户ID
                                  P_PROJ_NUMBER          IN VARCHAR2, --项目号
                                  --P_CREATED_MODE             IN NUMBER,  --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                                  --P_CREDIT_GROUP_ID           OUT NUMBER,  --额度组ID(传出给款项变更用，不用重复查询)
                                  P_ORDER_ID             IN NUMBER,   --单据ID
                                  P_ORDER_TYPE           IN VARCHAR2, --单据类型
                                  P_USERNAME            IN VARCHAR2 ,
                                  P_RESULT            IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG           IN OUT VARCHAR2 --返回错误信息
                            ) IS
    V_CREDIT_GROUP_ID NUMBER ;
  BEGIN
    IF P_ACTION_TYPE < 11 OR P_ACTION_TYPE > 27 OR P_ACTION_TYPE IN (17,18,19,20)THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '传入动作标识有问题，11=<P_ACTION_TYPE<=27和P_ACTION_TYPE NOT IN (17,18,19,20)表示收款、扣率折让、结算和铺底的处理！';
      RETURN ;
    END IF;

    BEGIN
      PRC_CREDIT_VERIFICATION(P_ENTITY_ID          => P_ENTITY_ID, --主体ID
                              P_ACTION_TYPE        => P_ACTION_TYPE, --动作标示
                              P_Settlement_SUM     => P_Settlement_SUM, --结算金额
                              P_Discount_SUM       => NULL, --折扣金额
                              P_THREE_NO_PAY_SUM   => NULL , --三方承兑锁定金额
                              P_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE , --营销大类
                              P_ACCOUNT_ID  => P_ACCOUNT_ID, --账户ID
                              P_CUSTOMER_ID => P_CUSTOMER_ID, --客户ID
                              P_PROJ_NUMBER => P_PROJ_NUMBER , --项目号
                              P_CREATED_MODE    =>  NULL ,  --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                              P_CREDIT_GROUP_ID   =>  V_CREDIT_GROUP_ID , --额度组ID(传出给款项变更用，不用重复查询)
                              P_RESULT      =>  P_RESULT, --返回错误ID
                              P_ERR_MSG     =>  P_ERR_MSG --返回错误信息
                      ) ;
     EXCEPTION WHEN OTHERS THEN
        -- P_RESULT  := -20000;
        P_ERR_MSG := '调用资金校验模块出现异常，请了解！'|| V_NL ||P_ERR_MSG ;
        RETURN ;
     END ;
     --如果检验通过，则调用款项变更
     IF P_RESULT = V_SEC_RESULT THEN
       BEGIN
          PRC_CREDIT_FUND_UPDATE(P_ENTITY_ID       => P_ENTITY_ID, --主体ID
                                 P_ACTION_TYPE     => P_ACTION_TYPE, --动作标示
                                 P_Settlement_SUM  => P_Settlement_SUM, --结算金额
                                 P_Discount_SUM    => NULL, --折扣金额
                                 P_THREE_NOT_PAY   => NULL, --三方承兑锁定金额
                                 P_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE, --营销大类
                                 P_ACCOUNT_ID         => P_ACCOUNT_ID, --账户ID
                                 P_CUSTOMER_ID        => P_CUSTOMER_ID, --客户ID
                                 P_PROJ_NUMBER        => P_PROJ_NUMBER, --项目号
                                 P_CREDIT_GROUP_ID    => V_CREDIT_GROUP_ID ,--(直接根据资金校验结果传入，不用重复查询)
                                 P_ORDER_ID           => P_ORDER_ID, --单据ID
                                 P_ORDER_TYPE         => P_ORDER_TYPE, --单据类型
                                 P_USERNAME           => P_USERNAME ,
                                 P_RESULT             => P_RESULT, --返回错误ID
                                 P_ERR_MSG            => P_ERR_MSG --返回错误信息
                                 );
       EXCEPTION WHEN OTHERS THEN
          --P_RESULT  := -20000;
          P_ERR_MSG := '调用款项变更模块出现异常，请了解！'|| V_NL || P_ERR_MSG ;
          RETURN ;
       END ;
     END IF ;
  END ; --PRC_CREDIT_RECEIVE_BILL

   -------------------------------------------------------------------------------
  \*
  *   创建日期：2014-07-08
  *     创建者：苏冬渊
  *   功能说明：三方承兑单调用接口
  *             该过程只有三方承兑单据调用
  *\
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_THREE_PAY(P_ENTITY_ID               IN NUMBER, --主体ID
                                  P_ACTION_TYPE          IN NUMBER, --动作标示
                                  P_Settlement_SUM       IN NUMBER, --结算金额
                                  --P_Discount_SUM         IN NUMBER, --折让金额
                                  P_THREE_NO_PAY_SUM     IN NUMBER, --三方承兑锁定金额
                                  P_SALES_MAIN_TYPE   IN VARCHAR2, --营销大类
                                  P_ACCOUNT_ID           IN NUMBER, --账户ID
                                  P_CUSTOMER_ID          IN NUMBER, --客户ID
                                  P_PROJ_NUMBER          IN VARCHAR2, --项目号
                                  --P_CREATED_MODE           IN NUMBER,  --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                                  --P_CREDIT_GROUP_ID          OUT NUMBER,  --额度组ID(传出给款项变更用，不用重复查询)
                                  P_ORDER_ID             IN NUMBER,   --单据ID
                                  P_ORDER_TYPE           IN VARCHAR2, --单据类型
                                  P_USERNAME            IN VARCHAR2 ,
                                  P_RESULT            IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG           IN OUT VARCHAR2 --返回错误信息
                            ) IS
    V_CREDIT_GROUP_ID NUMBER ;
  BEGIN
    IF P_ACTION_TYPE NOT IN (17,18,19,20) THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '传入动作标识有问题，P_ACTION_TYPE IN (17,18,19,20)表示三方承兑单据！';
      RETURN ;
    END IF;

    BEGIN
      PRC_CREDIT_VERIFICATION(P_ENTITY_ID          => P_ENTITY_ID, --主体ID
                              P_ACTION_TYPE        => P_ACTION_TYPE, --动作标示
                              P_Settlement_SUM     => P_Settlement_SUM, --结算金额
                              P_Discount_SUM       => NULL , --折扣金额
                              P_THREE_NO_PAY_SUM   => P_THREE_NO_PAY_SUM , --三方承兑锁定金额
                              P_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE , --营销大类
                              P_ACCOUNT_ID  => P_ACCOUNT_ID, --账户ID
                              P_CUSTOMER_ID => P_CUSTOMER_ID, --客户ID
                              P_PROJ_NUMBER => P_PROJ_NUMBER , --项目号
                              P_CREATED_MODE    =>  NULL , --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                              P_CREDIT_GROUP_ID   =>  V_CREDIT_GROUP_ID , --额度组ID(传出给款项变更用，不用重复查询)
                              P_RESULT      =>  P_RESULT, --返回错误ID
                              P_ERR_MSG     =>  P_ERR_MSG --返回错误信息
                      ) ;
     EXCEPTION WHEN OTHERS THEN
        --P_RESULT  := -20000;
        P_ERR_MSG := '调用资金校验模块出现异常，请了解！'|| V_NL || P_ERR_MSG ;
        RETURN ;
     END ;
     --如果检验通过，则调用款项变更
     IF P_RESULT = V_SEC_RESULT THEN
       BEGIN
          PRC_CREDIT_FUND_UPDATE(P_ENTITY_ID       => P_ENTITY_ID, --主体ID
                                 P_ACTION_TYPE     => P_ACTION_TYPE, --动作标示
                                 P_Settlement_SUM  => P_Settlement_SUM, --结算金额
                                 P_Discount_SUM    => NULL, --折扣金额
                                 P_THREE_NOT_PAY   => P_THREE_NO_PAY_SUM, --三方承兑锁定金额
                                 P_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE, --营销大类
                                 P_ACCOUNT_ID         => P_ACCOUNT_ID, --账户ID
                                 P_CUSTOMER_ID        => P_CUSTOMER_ID, --客户ID
                                 P_PROJ_NUMBER        => P_PROJ_NUMBER, --项目号
                                 P_CREDIT_GROUP_ID          => V_CREDIT_GROUP_ID ,--(直接根据资金校验结果传入，不用重复查询)
                                 P_ORDER_ID           => P_ORDER_ID, --单据ID
                                 P_ORDER_TYPE         => P_ORDER_TYPE, --单据类型
                                 P_USERNAME            => P_USERNAME ,
                                 P_RESULT             => P_RESULT, --返回错误ID
                                 P_ERR_MSG            => P_ERR_MSG --返回错误信息
                                 );
       EXCEPTION WHEN OTHERS THEN
          --P_RESULT  := -20000;
          P_ERR_MSG := '调用款项变更模块出现异常，请了解！'|| V_NL || P_ERR_MSG ;
          RETURN ;
       END ;
     END IF ;
  END ; --PRC_CREDIT_THREE_PAY */

  PROCEDURE 以下为资金校验的过程 is begin null ; end ;
  

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2017-3-23
  *     创建者：梁颜明
  *   功能说明：当客户款项明细或者客户款项信息不存在时，
                根据客户的营销大类关系初始化客户款项.
  *
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_ACC_AMOUNT_INIT(P_ENTITY_ID IN NUMBER,
                                          P_CUSTOMER_ID IN NUMBER,
                                          P_ACCOUNT_ID IN NUMBER,--可以为空，当传入不为空时，遍历
                                          P_PROJ_NUMBER IN VARCHAR2,
                                          P_SALES_MAIN_TYPE IN VARCHAR2,--可以为空，当传入不为空时，如果客户营销大类有效，就初始化
                                          P_USERNAME IN VARCHAR2,
                                          P_RESULT IN OUT NUMBER,
                                          P_ERR_MSG IN OUT VARCHAR2,
                                          P_ATT_IN  IN VARCHAR2 DEFAULT NULL) Is
                                          vn_count      number;
                                          VV_INIT       VARCHAR2(100);
  BEGIN
    VV_INIT := 'Y';
    IF P_ATT_IN IS NOT NULL THEN
      BEGIN
        PKG_BD.P_GET_PARAMETER_VALUE('CUST_ACCOUNT_CREDIT_AMOUNT_INIT',
                                     P_ENTITY_ID,
                                     NULL,
                                     NULL,
                                     VV_INIT);
      EXCEPTION
        WHEN OTHERS THEN
          VV_INIT := 'Y'; --默认值
      END;
    END IF;
    
    IF 'Y' = VV_INIT THEN
      FOR LI IN (
        SELECT A.ACCOUNT_ID,B.SALES_MAIN_TYPE_CODE
        --2017-4-22 获取额度组增加账户ID liangym2
        ,pkg_credit_tools.FUN_GET_CREDITGROUPID(A.ENTITY_ID,A.CUSTOMER_ID,B.SALES_MAIN_TYPE_CODE,A.ACCOUNT_ID) AS CREDIT_GROUP_ID
            FROM T_CUSTOMER_ACCOUNT A, T_CUSTOMER_SALES_MAIN_TYPE B,T_CUSTOMER_HEADER C,t_bd_item_class ic
           WHERE A.ENTITY_ID = B.ENTITY_ID
             AND A.CUSTOMER_ID = B.CUSTOM_ID
             AND A.CUSTOMER_ID = C.CUSTOMER_ID
             AND A.ENTITY_ID = P_ENTITY_ID
             AND A.CUSTOMER_ID = P_CUSTOMER_ID
             AND (P_ACCOUNT_ID IS NULL OR A.ACCOUNT_ID = P_ACCOUNT_ID)
             AND (P_SALES_MAIN_TYPE IS NULL OR B.SALES_MAIN_TYPE_CODE = P_SALES_MAIN_TYPE)
             AND DECODE(NVL(UPPER(A.ACTIVE_FLAG), 'Y'),'ACTIVE','Y',A.ACTIVE_FLAG) = 'Y'
             AND DECODE(NVL(UPPER(B.ACTIVE_FLAG), 'ACTIVE'),'ACTIVE','Y',B.ACTIVE_FLAG) = 'Y'
             AND DECODE(NVL(UPPER(C.CUSTOMER_STATUS),'ACTIVE')
             ,'FREEZING','Y','ACTIVE','Y',C.CUSTOMER_STATUS) = 'Y'
             --推广物料的不允许初始化客户款项
      and (ic.entity_id = a.entity_id and b.sales_main_type_code = ic.class_code and
         'Y' = ic.active_flag and 'M' = ic.class_type and
         (ic.promotion_flag is null or ic.promotion_flag <> 'Y'))
         
         and (P_ATT_IN is null
         or exists (select 1 from T_CUSTOMER_ACCOUNT A1 WHERE A1.ENTITY_ID = A.ENTITY_ID
         AND A1.CUSTOMER_ID = A.CUSTOMER_ID AND A1.ACCOUNT_ID <> A.ACCOUNT_ID
         )
         )
         
        ) LOOP
        IF LI.CREDIT_GROUP_ID NOT IN (0,-1,-2) THEN
          SELECT COUNT(0) INTO VN_COUNT FROM t_sales_account_amount M
             WHERE M.ENTITY_ID = P_ENTITY_ID AND M.CUSTOMER_ID = P_CUSTOMER_ID
             --2017 05 26
             AND M.ACCOUNT_ID = LI.ACCOUNT_ID AND M.CREDIT_GROUP_ID = LI.CREDIT_GROUP_ID;
          IF 0 = VN_COUNT THEN 
            PRC_CREDIT_AMOUNT_CONTORL_INIT(P_ENTITY_ID,P_CUSTOMER_ID,LI.ACCOUNT_ID,P_PROJ_NUMBER
            ,LI.SALES_MAIN_TYPE_CODE,P_USERNAME,P_RESULT,P_ERR_MSG, '0');
          END IF;
        END IF;
      END LOOP;
    END IF;
  END PRC_CREDIT_ACC_AMOUNT_INIT;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-10-29
  *     创建者：苏冬渊
  *   功能说明：当客户款项明细或者客户款项信息不存在时，
                根据客户营销大类关系初始化客户款项.
  *
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_AMOUNT_CONTORL_INIT(P_ENTITY_ID IN NUMBER,
                                          P_CUSTOMER_ID IN NUMBER,
                                          P_ACCOUNT_ID IN NUMBER,
                                          P_PROJ_NUMBER IN VARCHAR2,
                                          P_SALES_MAIN_TYPE IN VARCHAR2,
                                          P_USERNAME IN VARCHAR2,
                                          P_RESULT IN OUT NUMBER,
                                          P_ERR_MSG IN OUT VARCHAR2,
                                          P_ATT_IN  IN VARCHAR2 DEFAULT NULL) Is
    Pragma Autonomous_Transaction;--定义自治事务
    V_CUSTOMER_CODE T_SALES_ACCOUNT_MX_AMOUNT.CUSTOMER_CODE%TYPE ;
    V_CUSTOMER_NAME T_SALES_ACCOUNT_MX_AMOUNT.CUSTOMER_NAME%TYPE ;
    V_ACCOUNT_CODE  T_SALES_ACCOUNT_MX_AMOUNT.ACCOUNT_CODE%TYPE ;
    V_ACCOUNT_NAME  T_SALES_ACCOUNT_MX_AMOUNT.ACCOUNT_NAME%TYPE ;

    V_CREDIT_GROUP_ID T_SALES_ACCOUNT_AMOUNT.CREDIT_GROUP_ID%TYPE ;
    V_COUNT NUMBER ;
    VS_SALES_MAIN_TYPE_NAME T_BD_ITEM_CLASS.CLASS_NAME%TYPE;

  BEGIN
    --检查是否存在客户账户，客户营销大类关系
    BEGIN
      
        SELECT A.CUSTOMER_CODE,
               C.CUSTOMER_NAME,
               A.ACCOUNT_CODE,
               A.ACCOUNT_NAME
          INTO V_CUSTOMER_CODE,
               V_CUSTOMER_NAME,
               V_ACCOUNT_CODE,
               V_ACCOUNT_NAME
          FROM T_CUSTOMER_ACCOUNT A, T_CUSTOMER_SALES_MAIN_TYPE B,T_CUSTOMER_HEADER C
         WHERE A.ENTITY_ID = B.ENTITY_ID
           AND A.CUSTOMER_ID = B.CUSTOM_ID
           AND A.CUSTOMER_ID = C.CUSTOMER_ID
           AND A.ENTITY_ID = P_ENTITY_ID
           AND A.CUSTOMER_ID = P_CUSTOMER_ID
           AND A.ACCOUNT_ID = P_ACCOUNT_ID
           AND B.SALES_MAIN_TYPE_CODE = P_SALES_MAIN_TYPE
           AND DECODE(NVL(UPPER(A.ACTIVE_FLAG), 'Y'),'ACTIVE','Y',A.ACTIVE_FLAG) = 'Y'
           AND DECODE(NVL(UPPER(B.ACTIVE_FLAG), 'ACTIVE'),'ACTIVE','Y',B.ACTIVE_FLAG) = 'Y'
           --AND DECODE(NVL(UPPER(C.CUSTOMER_STATUS),'ACTIVE'),'ACTIVE','Y',C.CUSTOMER_STATUS) = 'Y';
           --liangym2 2017-3-23 客户头冻结允许初始化
           AND DECODE(NVL(UPPER(C.CUSTOMER_STATUS),'ACTIVE')
           ,'FREEZING','Y','ACTIVE','Y',C.CUSTOMER_STATUS) = 'Y';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
         P_RESULT  := -20000;
         SELECT (SELECT C.CLASS_NAME FROM T_BD_ITEM_CLASS C
         WHERE C.ENTITY_ID = P_ENTITY_ID AND C.CLASS_TYPE = 'M'
         AND C.CLASS_CODE = P_SALES_MAIN_TYPE
         AND 'Y' = C.ACTIVE_FLAG) INTO VS_SALES_MAIN_TYPE_NAME FROM DUAL;
         IF 0 < P_ACCOUNT_ID THEN
           P_ERR_MSG := '系统中不存在该客户与营销大类的关系（客户管理-客户资料-客户信息，点击客户名称的链接，查看经营产品信息，如果不存在该客户与该大类“' || VS_SALES_MAIN_TYPE_NAME || '”的有效关系，请在CRM进行维护）！账户ID：' || P_ACCOUNT_ID;
         ELSE
           P_ERR_MSG := '系统中不存在该客户的客户账户、客户以及营销大类关系，请了解！';
         END IF;
         RETURN;
      WHEN TOO_MANY_ROWS THEN
         P_RESULT  := -20000;
         SELECT (SELECT C.CLASS_NAME FROM T_BD_ITEM_CLASS C
         WHERE C.ENTITY_ID = P_ENTITY_ID AND C.CLASS_TYPE = 'M'
         AND C.CLASS_CODE = P_SALES_MAIN_TYPE
         AND 'Y' = C.ACTIVE_FLAG) INTO VS_SALES_MAIN_TYPE_NAME FROM DUAL;
         IF 0 < P_ACCOUNT_ID THEN
           P_ERR_MSG := '系统中存在多条该客户与营销大类的关系（客户管理-客户资料-客户等级维护，在查询条件输入客户编码，点击查询，如果存在多条该客户与该大类“' || VS_SALES_MAIN_TYPE_NAME || '”的有效关系，请尝试在CRM将某条重复的关系失效）！账户ID：' || P_ACCOUNT_ID;
         ELSE
           P_ERR_MSG := '系统中存在多条该客户的客户、账户以及营销大类关系，请了解！';
         END IF;
         RETURN;
      WHEN OTHERS THEN
         P_RESULT  := -20000;
         P_ERR_MSG := '根据客户ID，账户ID，营销大类等获取客户信息出错，请了解！' || V_NL || SQLERRM;
         RETURN;
    END ;

    --客户款项明细信息缺失，根据客户、账户以及营销大类关系初始化客户款项明细信息
    BEGIN
      INSERT INTO t_sales_account_mx_amount   --账户款项明细信息表
          ( account_amount_mx_id,   --账户款项明细ID
            entity_id,   --经营主体ID
            proj_number,   --项目号
            customer_id,   --客户ID
            customer_code,   --客户编码
            customer_name,   --客户名称
            account_id,   --账户ID
            account_code,   --账户编码
            account_name,   --账户名称
            sales_main_type,   --营销大类
            sales_year_id,   --销售年度ID
            received_amount,   --到款金额
            sales_amount,   --销售金额
            lock_received_amount,   --锁定到款金额
            delaypay_amount,   --铺底额度
            temp_delaypay_amount,   --临时额度
            discount_amount,   --折让金额
            applied_discount_amount,   --核销折让金额
            freeze_discount_amount,   --冻结折让金额
            lock_discount_amount,   --锁定折让金额
            dispay_amount,   --未解付金额
            creation_date,   --创建日期
            created_by,   --创建人
            last_update_date,   --修改日期
            last_updated_by,   --修改人
            three_not_pay, pre_field_01)  --三方承兑未解付金额
     VALUES
          ( S_sales_account_mx_amount.Nextval,   --账户款项明细ID
            P_ENTITY_ID,   --经营主体ID
            P_PROJ_NUMBER,   --项目号
            P_CUSTOMER_ID,   --客户ID
            V_CUSTOMER_CODE,   --客户编码
            V_CUSTOMER_NAME,   --客户名称
            P_ACCOUNT_ID,   --账户ID
            V_ACCOUNT_CODE,   --账户编码
            V_ACCOUNT_NAME,   --账户名称
            P_SALES_MAIN_TYPE,   --营销大类
            NULL,   --销售年度ID
            0,   --到款金额
            0,   --销售金额
            0,   --锁定到款金额
            0,   --铺底额度
            0,   --临时额度
            0,   --折让金额
            0,   --核销折让金额
            0,   --冻结折让金额
            0,   --锁定折让金额
            0,   --未解付金额
            SYSDATE,   --创建日期
            P_USERNAME,   --创建人
            SYSDATE,   --修改日期
            P_USERNAME,  --修改人
            0
            ,DECODE(P_ATT_IN,NULL,1,'Active',1,0)); --三方承兑未解付金额 ;
       EXCEPTION WHEN OTHERS THEN
         P_RESULT  := -20000;
         P_ERR_MSG := '插入客户款项明细信息出错！请了解！' || V_NL || SQLERRM;
         RETURN;
       END ;
       --获取额度组ID --2017-4-22 获取额度组增加账户ID liangym2
       V_CREDIT_GROUP_ID := pkg_credit_tools.FUN_GET_CREDITGROUPID(P_ENTITY_ID,P_CUSTOMER_ID,P_SALES_MAIN_TYPE,P_ACCOUNT_ID);
       IF V_CREDIT_GROUP_ID = -2 THEN
         P_RESULT := -20002;
         P_ERR_MSG := '该客户已经存在特殊额度组，请到额度组维护模块维护特殊额度组与'|| P_SALES_MAIN_TYPE ||'的关系！' || V_NL || SQLERRM;
         RETURN ;
       ELSIF V_CREDIT_GROUP_ID = -1 THEN
         P_RESULT := -20002;
         P_ERR_MSG := '根据营销大类查询额度组出错，请到额度组管理模块维护！' || V_NL || SQLERRM;
         RETURN ;
       END IF ;
       --检查是否存在客户款项信息
       BEGIN
         SELECT COUNT(1)
           INTO V_COUNT
           FROM T_SALES_ACCOUNT_AMOUNT T
          WHERE T.ENTITY_ID = P_ENTITY_ID
            AND T.CUSTOMER_ID = P_CUSTOMER_ID
            AND T.ACCOUNT_ID = P_ACCOUNT_ID
            AND T.CREDIT_GROUP_ID = V_CREDIT_GROUP_ID
            AND T.ACTIVE_FLAG = '1';
        EXCEPTION WHEN OTHERS THEN
           P_RESULT := -20000;
           P_ERR_MSG := '查询是否存在相应的客户款项信息出错，请了解！' || V_NL || SQLERRM;
           RETURN ;
        END ;
        --如果V_COUNT <= 0 ,新增客户款项信息
        IF V_COUNT <= 0 THEN
           BEGIN
             INSERT INTO T_SALES_ACCOUNT_AMOUNT
               (account_amount_id,
                entity_id,
                credit_group_id,
                proj_number,
                customer_id,
                customer_code,
                customer_name,
                account_id,
                account_code,
                account_name,
                sales_year_id,
                received_amount,
                sales_amount,
                lock_received_amount,
                delaypay_amount,
                temp_delaypay_amount,
                discount_amount,
                applied_discount_amount,
                freeze_discount_amount,
                lock_discount_amount,
                dispay_amount,
                amount_crtl_flag,
                discont_crtl_flag,
                creation_date,
                created_by,
                last_update_date,
                last_updated_by,
                pre_field_01,
                pre_field_02,
                pre_field_03,
                pre_field_04,
                pre_field_05,
                pre_field_06,
                three_not_pay,
                active_flag
                ,MPAY_STREAM_AMOUNT
                ,MPAY_CASH_AMOUNT
                )
               SELECT S_SALES_ACCOUNT_AMOUNT.NEXTVAL account_amount_id, B.*
                 FROM (SELECT P_ENTITY_ID entity_id,
                              V_CREDIT_GROUP_ID credit_group_id,
                              NULL proj_number,
                              T.customer_id customer_id,
                              T.customer_code customer_code,
                              T.CUSTOMER_NAME customer_name,
                              T.account_id account_id,
                              T.account_code account_code,
                              T.account_name account_name,
                              NULL sales_year_id,
                              SUM(received_amount) received_amount,
                              SUM(sales_amount) sales_amount,
                              SUM(lock_received_amount) lock_received_amount,
                              SUM(delaypay_amount) delaypay_amount,
                              SUM(temp_delaypay_amount) temp_delaypay_amount,
                              SUM(discount_amount) discount_amount,
                              SUM(applied_discount_amount) applied_discount_amount,
                              SUM(freeze_discount_amount) freeze_discount_amount,
                              SUM(lock_discount_amount) lock_discount_amount,
                              SUM(dispay_amount) dispay_amount,
                              '0' amount_crtl_flag,
                              '0' discont_crtl_flag,
                              SYSDATE creation_date,
                              P_USERNAME created_by,
                              SYSDATE last_update_date,
                              P_USERNAME last_updated_by,
                              DECODE(P_ATT_IN,NULL,1,'Active',1,0) pre_field_01,
                              NULL pre_field_02,
                              NULL pre_field_03,
                              NULL pre_field_04,
                              NULL pre_field_05,
                              NULL pre_field_06,
                              SUM(three_not_pay) three_not_pay,
                              '1' active_flag
                              ,SUM(MPAY_STREAM_AMOUNT) AS MPAY_STREAM_AMOUNT
                              ,SUM(MPAY_CASH_AMOUNT) AS MPAY_CASH_AMOUNT
                         FROM T_SALES_ACCOUNT_MX_AMOUNT T
                        WHERE T.ENTITY_ID = P_ENTITY_ID
                          AND T.CUSTOMER_ID = P_CUSTOMER_ID
                          AND T.ACCOUNT_ID = P_ACCOUNT_ID
                          --2017-4-22 获取额度组增加账户ID liangym2
                          AND V_CREDIT_GROUP_ID =
                              PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(T.ENTITY_ID,T.CUSTOMER_ID,
                                                                     T.SALES_MAIN_TYPE, T.ACCOUNT_ID)
                             GROUP BY T.customer_id,
                                      T.customer_code,
                                      T.CUSTOMER_NAME,
                                      T.account_id,
                                      T.account_code,
                                      T.account_name) B;

          EXCEPTION WHEN OTHERS THEN
             P_RESULT := -20000;
             P_ERR_MSG := '根据客户款项明细信息执行客户款项信息生成操作出错，请了解！' || V_NL || SQLERRM;
             RETURN ;
          END ;
        END IF ;
    --由于定义了自治事务，款项初始化
    Commit ;
  END ;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-28
  *     创建者：苏冬渊
  *   功能说明：处理信用控制中的资金校验
  *             该过程只有计划订单、销售单 1~12
  *
      1：订单评审
      2：订单取消
      3：开单（销售单）
      4：开单（销售红冲单）
      5：开单（退货单）
      6：开单（退货红冲单）
      7：开单（折让证明单）
      8：开单（折让证明红冲单）
      9：开单（销售折让单）
      10：开单（销售折让红冲单）
      11：开单（扣率折让单）
      12：开单（扣率折让红冲单）
      13：结算（退货单）
      14：结算（销售单）
      15：收款确认（不包括三方承兑）
      16：收款冲销
      17：三方承兑到款
      18：三方承兑冲销
      19：三方承兑解付
      20：三方承兑解付冲销
      21：退款
      22：铺底审批（铺底）
      23：铺底审批（临时铺底）
      24：铺底审批（冻结折让）
      25：铺底到期（铺底）
      26：铺底到期（临时铺底）
      27：铺底到期（冻结折让）
      28:解锁订金锁款
      29:解锁款项锁订金
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_VERIFICATION(P_ENTITY_ID               IN NUMBER, --主体ID
                                    P_ACTION_TYPE          IN NUMBER, --动作标示
                                    P_Settlement_SUM       IN NUMBER, --结算金额
                                    P_Discount_SUM         IN NUMBER, --折扣金额
                                    P_ORDER_ID             IN NUMBER, --单据ID
                                    P_SALES_MAIN_TYPE   IN VARCHAR2, --营销大类
                                    P_ACCOUNT_ID           IN NUMBER, --账户ID
                                    P_CUSTOMER_ID          IN NUMBER, --客户ID
                                    P_PROJ_NUMBER          IN VARCHAR2, --项目号
                                    P_CREATED_MODE         IN NUMBER,  --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                                    P_RESULT            IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG           IN OUT VARCHAR2, --返回错误信息
                                    P_ORDER_TYPE        IN VARCHAR2 DEFAULT NULL, --订单类型
                                    IS_DISCOUNT_TYPE    IN VARCHAR2 DEFAULT NULL,--折让方式
                                    IS_PLN_SRC_ORDER_TYPE IN VARCHAR2 DEFAULT NULL--订单源类型 1提货订单
                            ) IS

   V_CREDIT_GROUP_ID T_SALES_ACCOUNT_AMOUNT.Credit_Group_Id%TYPE ; --额度组
   V_ENTITY_ID T_SALES_ACCOUNT_AMOUNT.Entity_Id%TYPE ;
   V_CONTROL_GRADE VARCHAR2(2) ; --控制级别
   V_AMOUNT_CRTL_FLAG T_SALES_ACCOUNT_AMOUNT.AMOUNT_CRTL_FLAG%TYPE ; --金额控制
   V_DISCONT_CRTL_FLAG T_SALES_ACCOUNT_AMOUNT.DISCONT_CRTL_FLAG%TYPE ; --折扣控制
   V_RECEIVABLE_CRTL_FLAG T_SALES_ACCOUNT_AMOUNT.RECEIVABLE_CRTL_FLAG%TYPE ; --应收控制

   C_SALES_ACCOUNT_AMOUNT CUR_SALES_ACCOUNT_AMOUNT ;
   C_SALES_ACCOUNT_MX_AMOUNT CUR_SALES_ACCOUNT_MX_AMOUNT ;
   C_CREDIT_DISCOUNT_AMOUNT CUR_CREDIT_DISCOUNT_AMOUNT ;--add by liangym2 2017-8-5 折让款项：上账、销售金额、上账锁款
   --V_SALES_MAIN_TYPE VARCHAR2(32) ;
   V_CUSTOMER_INFO VARCHAR2(1000) ;

   V_CUSTOMER_CODE T_CUSTOMER_ACCOUNT.CUSTOMER_CODE%Type ;
   V_ACCOUNT_CODE  T_CUSTOMER_ACCOUNT.ACCOUNT_CODE%Type ;
   --VN_CNT                NUMBER;--用于判断记录条数
   V_VERIFIED_CREDIT  VARCHAR2(32);
   V_TURNFEE_VERIFIED_CREDIT VARCHAR2(32);
  BEGIN

    --初始值
    P_RESULT  := V_SEC_RESULT;
    P_ERR_MSG := V_SUCCESS ;

  --根据客户ID，账户ID获取客户编码，账户编码。add by sudy 2015-07-06
  Begin
    Select Customer_Code, Account_Code,IS_REFUND_VERIFIED_CREDIT,IS_TURNFEE_VERIFIED_CREDIT
      Into V_Customer_Code, V_Account_Code,V_VERIFIED_CREDIT,V_TURNFEE_VERIFIED_CREDIT
      From T_Customer_Account t
     Where T.Entity_Id = P_Entity_Id
       And T.Customer_Id = P_Customer_Id
       And T.Account_Id = P_Account_Id
       And Nvl(T.Active_Flag, 'Y') = 'Y'
       And Rownum = 1;
  Exception When Others Then
    V_CUSTOMER_CODE := '从T_CUSTOMER_ACCOUNT表中无法查询到' ;
    V_ACCOUNT_CODE := '从T_CUSTOMER_ACCOUNT表中无法查询到' ;
  End ;

    --V_CUSTOMER_INFO := '||客户ID = ' || P_CUSTOMER_ID || ',账户ID = ' || P_ACCOUNT_ID || ',营销大类编码 = ' || P_SALES_MAIN_TYPE || '】' ;
    V_CUSTOMER_INFO := '||客户编码 = ' || V_CUSTOMER_CODE || ',账户编码 = ' || V_ACCOUNT_CODE || ',营销大类编码 = ' || P_SALES_MAIN_TYPE || '】' ;

  --校验传入参数是否正确
  IF P_CUSTOMER_ID IS NULL OR P_ACCOUNT_ID IS NULL THEN
     P_RESULT  := -20000;
     P_ERR_MSG := '传入客户ID或者账户ID有误，不能为空！';
     RETURN ;
  END IF ;
  IF P_SALES_MAIN_TYPE IS NULL AND P_PROJ_NUMBER IS NULL THEN
     P_RESULT  := -20000;
     P_ERR_MSG := '传入营销大类和项目号有误，必须有一个不为空！';
     RETURN ;
  END IF ;
    ----0、判断是否存在此种单据类型，目前单据类型的动作标识只有27种
  IF P_ACTION_TYPE < 1 OR P_ACTION_TYPE > 29 OR MOD(P_ACTION_TYPE,1) <> 0 THEN
     P_RESULT  := -20005;
     P_ERR_MSG := '传入动作标识有问题，请确认是否有此种单据类型！';
     --RAISE V_BASE_EXCEPTION ;
     RETURN ;
  END IF ;
    --1、获取主体ID(基础数据接口)
      --根据与熊培良确认，主体ID还是通过参数传2014-07-07
    V_ENTITY_ID := P_ENTITY_ID ;
    --2、根据系统参数获取款项控制级别（基础数据提供接口）
    V_CONTROL_GRADE := '2' ;

    --3、根据营销大类ID，客户ID，获取额度组 --2017-4-22 获取额度组增加账户ID liangym2
    V_CREDIT_GROUP_ID := pkg_credit_tools.FUN_GET_CREDITGROUPID(P_ENTITY_ID,P_CUSTOMER_ID,P_SALES_MAIN_TYPE,P_ACCOUNT_ID);
    IF V_CREDIT_GROUP_ID = -2 THEN
      P_RESULT := -20002;
      P_ERR_MSG := '该客户已经存在特殊额度组，请到额度组维护模块维护特殊额度组与'|| P_SALES_MAIN_TYPE ||'的关系！' || V_NL || SQLERRM;
      RETURN ;
    ELSIF V_CREDIT_GROUP_ID = -1 THEN
      P_RESULT := -20002;
      P_ERR_MSG := '根据营销大类查询额度组出错，请到额度组管理模块维护！' || V_NL || SQLERRM;
      RETURN ;
    END IF ;

    --4、对款项信息表的相关款项信息加锁,同时锁住款项信息和款项明细信息
      --控制级别为客户级别时，在客户一级上锁定款项；控制级别为账户级别时，在账户一级上锁定款项
    IF V_CONTROL_GRADE = '1' THEN --客户级别
      BEGIN
          --锁定款项明细信息
          SELECT * BULK COLLECT INTO C_SALES_ACCOUNT_MX_AMOUNT
            FROM T_SALES_ACCOUNT_MX_AMOUNT T
           WHERE T.ENTITY_ID = V_ENTITY_ID
             AND T.CUSTOMER_ID = P_CUSTOMER_ID
             AND nvl(T.PROJ_NUMBER,-1) = nvl(P_PROJ_NUMBER,-1)
             AND T.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
             FOR UPDATE NOWAIT;

          IF C_SALES_ACCOUNT_MX_AMOUNT.COUNT < 1 THEN
             prc_credit_amount_contorl_init(p_entity_id => p_entity_id,
                                            p_customer_id => p_customer_id,
                                            p_account_id => p_account_id,
                                            p_proj_number => p_proj_number,
                                            p_sales_main_type => p_sales_main_type,
                                            p_username => '初始化',
                                            p_result => p_result,
                                            p_err_msg => p_err_msg);
             IF P_RESULT <> V_SEC_RESULT THEN
                Return ;
             END IF ;
          END IF ;

          --锁定款项信息
          SELECT * BULK COLLECT INTO C_SALES_ACCOUNT_AMOUNT
            FROM T_SALES_ACCOUNT_AMOUNT T
           WHERE T.ENTITY_ID = V_ENTITY_ID
             AND nvl(T.CREDIT_GROUP_ID,-1) = V_CREDIT_GROUP_ID
             AND nvl(T.PROJ_NUMBER,-1) = nvl(P_PROJ_NUMBER,-1)
             AND T.CUSTOMER_ID = P_CUSTOMER_ID
             FOR UPDATE NOWAIT;

          IF C_SALES_ACCOUNT_AMOUNT.COUNT < 1 THEN
             P_RESULT  := -20004;
             P_ERR_MSG := '系统中不存在该客户在该账户下，营销大类为'|| P_SALES_MAIN_TYPE ||'的客户款项信息！' || V_NL || SQLERRM;
             --ROLLBACK ;
             --RAISE V_BASE_EXCEPTION ;
             RETURN ;
          END IF ;

          BEGIN
            
          SELECT * BULK COLLECT INTO C_CREDIT_DISCOUNT_AMOUNT
          FROM T_CREDIT_DISCOUNT_AMOUNT T
           WHERE T.ENTITY_ID = V_ENTITY_ID
             AND T.CUSTOMER_ID = P_CUSTOMER_ID
             --AND T.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
             AND V_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(T.ENTITY_ID
             ,T.CUSTOMER_ID,T.SALES_MAIN_TYPE,T.ACCOUNT_ID)
             AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON' OR IS_DISCOUNT_TYPE = T.DISCOUNT_TYPE)
             --梁颜明 2017-8-7 修改 由按大类汇总
             --“AND T.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE” 改为按额度组汇总
             -- “AND V_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS****”
             FOR UPDATE NOWAIT;
             
          EXCEPTION WHEN NO_DATA_FOUND THEN
            NULL;
          END;
          
          --获取控制方式（客户级别的控制方式配置在基础数据，从基础数据接口来）
          V_AMOUNT_CRTL_FLAG := '0' ;
          V_DISCONT_CRTL_FLAG := '0' ;
      EXCEPTION WHEN OTHERS THEN
          P_RESULT  := -20003;
          P_ERR_MSG := '锁定款项信息出错，可能该款项信息被其他用户操作，请稍后再试！' || V_NL || SQLERRM;
          --ROLLBACK ;
          --RAISE V_BASE_EXCEPTION ;
          RETURN ;
      END ;
    ELSIF V_CONTROL_GRADE = '2' THEN --账户级别
        BEGIN

          --锁定款项明细信息
          SELECT * BULK COLLECT INTO C_SALES_ACCOUNT_MX_AMOUNT
            FROM T_SALES_ACCOUNT_MX_AMOUNT T
           WHERE T.ENTITY_ID = V_ENTITY_ID
             AND T.CUSTOMER_ID = P_CUSTOMER_ID
             AND T.ACCOUNT_ID = P_ACCOUNT_ID
             AND nvl(T.PROJ_NUMBER,-1) = nvl(P_PROJ_NUMBER,-1)
             AND T.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
             --FOR UPDATE NOWAIT;
             FOR UPDATE WAIT 3;
          --缺少客户款项明细信息，初始化该客户该账户下的营销大类款项明细信息
          IF C_SALES_ACCOUNT_MX_AMOUNT.COUNT < 1 THEN
             prc_credit_amount_contorl_init(p_entity_id => p_entity_id,
                                            p_customer_id => p_customer_id,
                                            p_account_id => p_account_id,
                                            p_proj_number => p_proj_number,
                                            p_sales_main_type => p_sales_main_type,
                                            p_username => '初始化',
                                            p_result => p_result,
                                            p_err_msg => p_err_msg);
             IF P_RESULT <> V_SEC_RESULT THEN
                Return ;
             END IF ;
          END IF ;

         --锁定款项信息
         SELECT * BULK COLLECT INTO C_SALES_ACCOUNT_AMOUNT
            FROM T_SALES_ACCOUNT_AMOUNT T
           WHERE T.ENTITY_ID = V_ENTITY_ID
             AND nvl(T.CREDIT_GROUP_ID,-1) = V_CREDIT_GROUP_ID
             AND nvl(T.PROJ_NUMBER,-1) = nvl(P_PROJ_NUMBER,-1)
             AND T.CUSTOMER_ID = P_CUSTOMER_ID
             AND T.ACCOUNT_ID = P_ACCOUNT_ID
             --FOR UPDATE NOWAIT;
             FOR UPDATE WAIT 3;

          IF C_SALES_ACCOUNT_AMOUNT.COUNT < 1 THEN
             P_RESULT  := -20004;
             P_ERR_MSG := '系统中不存在该客户在该账户下，营销大类为'|| P_SALES_MAIN_TYPE ||'的客户款项信息！' || V_NL || SQLERRM;
             RETURN ;
          END IF ;

          BEGIN
            
          SELECT * BULK COLLECT INTO C_CREDIT_DISCOUNT_AMOUNT
          FROM T_CREDIT_DISCOUNT_AMOUNT T
           WHERE T.ENTITY_ID = V_ENTITY_ID
             AND T.CUSTOMER_ID = P_CUSTOMER_ID
             AND T.ACCOUNT_ID = P_ACCOUNT_ID
             --AND T.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
             AND V_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(T.ENTITY_ID
             ,T.CUSTOMER_ID,T.SALES_MAIN_TYPE,T.ACCOUNT_ID)
             AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON' OR IS_DISCOUNT_TYPE = T.DISCOUNT_TYPE)
             --梁颜明 2017-8-7 修改 由按大类汇总
             --“AND T.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE” 改为按额度组汇总
             -- “AND V_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS****”
             --FOR UPDATE NOWAIT;
             FOR UPDATE WAIT 3;
             
          EXCEPTION WHEN NO_DATA_FOUND THEN
            NULL;
          END;
          
          --获取控制方式
          V_AMOUNT_CRTL_FLAG :=  NVL(C_SALES_ACCOUNT_AMOUNT(1).AMOUNT_CRTL_FLAG,'-1') ;
          V_DISCONT_CRTL_FLAG := NVL(C_SALES_ACCOUNT_AMOUNT(1).DISCONT_CRTL_FLAG,'-1') ;
          V_RECEIVABLE_CRTL_FLAG := NVL(C_SALES_ACCOUNT_AMOUNT(1).RECEIVABLE_CRTL_FLAG,'-1') ;
        EXCEPTION WHEN OTHERS THEN
          P_RESULT  := -20003;
          P_ERR_MSG := '锁定款项信息出错，可能该款项信息被其他用户操作，请稍后再试！' || V_NL || SQLERRM;
          --ROLLBACK ;
          RETURN ;
        END ;
     ELSE
          P_RESULT  := -20006;
          P_ERR_MSG := '获取到的控制级别不对，必须为1：客户级别或者2：账户级别，请检查！' || V_NL || SQLERRM;
          --RAISE V_BASE_EXCEPTION ;
          RETURN ;
     END IF ; --3：

    --add by sudy 2015-01-31 如果折扣金额为0，则折扣不校验
  If nvl(P_Discount_SUM,0) = 0 Then
     V_DISCONT_CRTL_FLAG := '-1' ;
  End If  ;

  --4、判断控制方式，若是两种控制方式都为-1，则不需要进行校验
  IF V_AMOUNT_CRTL_FLAG = '-1' AND V_DISCONT_CRTL_FLAG = '-1' THEN
     P_RESULT  := V_SEC_RESULT ;
     P_ERR_MSG := V_SUCCESS ;
     --RAISE V_BASE_EXCEPTION ;
     RETURN ;
  Elsif V_AMOUNT_CRTL_FLAG Not In ('0','-1') Then
     P_RESULT  := -20006;
     P_ERR_MSG := '该客户款项上金额控制方式上的值不对，只能为[0]或者[-1]' || V_NL || SQLERRM;
     --RAISE V_BASE_EXCEPTION ;
     RETURN ;
  Elsif V_DISCONT_CRTL_FLAG Not In ('0','-1') Then
     P_RESULT  := -20006;
     P_ERR_MSG := '该客户款项上折扣控制方式上的值不对，只能为[0]或者[-1]' || V_NL || SQLERRM;
     --RAISE V_BASE_EXCEPTION ;
     RETURN ;
  Elsif V_RECEIVABLE_CRTL_FLAG Not In ('0','-1') Then
     P_RESULT  := -20006;
     P_ERR_MSG := '该客户款项上应收控制方式上的值不对，只能为[0]或者[-1]' || V_NL || SQLERRM;
     --RAISE V_BASE_EXCEPTION ;
     RETURN ;
  END IF ;--4:

  --5、6,8,10,11,15,17,20,22,23,27的单据不用校验，直接返回校验通过.因为这几类金额是加法
  --13-结算（退货单）
  --13要校验的是退货单执行之后
  IF P_ACTION_TYPE IN (6,8,10,11,15,17,20,22,27) THEN--,23
     P_RESULT  := V_SEC_RESULT ;
     P_ERR_MSG := V_SUCCESS ;
     --RAISE V_BASE_EXCEPTION ;
     RETURN ;
  ELSE
     PRC_CREDIT_VERIFICATION_IMPL(P_ENTITY_ID,    --主体ID
                                  P_ACTION_TYPE , --动作标示
                                  NVL(P_Settlement_SUM,0) , --结算金额
                                  NVL(P_Discount_SUM,0) , --折扣金额
                                  P_ORDER_ID,      --单据ID
                                  P_SALES_MAIN_TYPE , --营销大类
                                  C_SALES_ACCOUNT_AMOUNT ,
                                  C_CREDIT_DISCOUNT_AMOUNT,--折让款项明细 add by liangym2 2017-8-5
                                  V_AMOUNT_CRTL_FLAG, --金额控制方式
                                  V_DISCONT_CRTL_FLAG , --折扣控制方式
                                  P_CREATED_MODE  ,  --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                                  P_RESULT , --返回错误ID
                                  P_ERR_MSG, --返回错误信息
                                  V_RECEIVABLE_CRTL_FLAG,
                                  P_ORDER_TYPE--单据类型编码
                                  ,IS_DISCOUNT_TYPE
                                  ,IS_PLN_SRC_ORDER_TYPE
                                  ,V_VERIFIED_CREDIT
                                  ,V_TURNFEE_VERIFIED_CREDIT
                            )  ;
     --校验不通过，则通过回滚释放锁定款项
     IF P_RESULT <> V_SEC_RESULT THEN
        --ROLLBACK ;
        --RAISE V_BASE_EXCEPTION ;
        P_ERR_MSG := P_ERR_MSG || V_CUSTOMER_INFO ;
        RETURN ;
     END IF ;
  END IF ; --5:

  END ; --PRC_CREDIT_VERIFICATION

   --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-28
  *     创建者：苏冬渊
  *   功能说明：处理信用控制中的资金校验，具体金额校验的过程
  *             该过程只有计划订单、销售单
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_VERIFICATION_IMPL( P_ENTITY_ID            IN NUMBER, --主体ID
                                          P_ACTION_TYPE          IN NUMBER, --动作标示
                                          P_Settlement_SUM       IN NUMBER, --结算金额
                                          P_Discount_SUM         IN NUMBER, --折扣金额
                                          P_ORDER_ID             IN NUMBER, --单据ID
                                          P_SALES_MAIN_TYPE      IN VARCHAR2, --营销大类
                                          P_SALES_ACCOUNT_AMOUNT IN CUR_SALES_ACCOUNT_AMOUNT,
                                          IC_CREDIT_DISCOUNT_AMOUNT IN CUR_CREDIT_DISCOUNT_AMOUNT,--add by liangym2 2017-8-5
                                          P_AMOUNT_CRTL_FLAG     IN VARCHAR2, --金额控制方式
                                          P_DISCONT_CRTL_FLAG    IN VARCHAR2, --折扣控制方式
                                          P_CREATED_MODE         IN NUMBER,  --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                                          P_RESULT            IN OUT NUMBER, --返回错误ID
                                          P_ERR_MSG           IN OUT VARCHAR2, --返回错误信息
                                          IS_RECEIVABLE_CRTL_FLAG    IN VARCHAR2, --应收控制标识
                                          P_ORDER_TYPE        IN VARCHAR2 DEFAULT NULL, --订单类型
                                          IS_DISCOUNT_TYPE    IN VARCHAR2 DEFAULT NULL,--折让方式
                                          IS_PLN_SRC_ORDER_TYPE IN VARCHAR2 DEFAULT NULL,--订单源类型 1提货订单
                                          IS_RE_VERIFIED_CREDIT IN VARCHAR2 DEFAULT NULL,--退款是否检查信用
                                          IS_TU_VERIFIED_CREDIT IN VARCHAR2 DEFAULT NULL--转款是否检查信用
                            ) IS
     V_AMOUNT_SUM NUMBER := 0 ;   --金额控制金额
     V_DISCONT_SUM NUMBER := 0;  --折扣控制金额
     V_AMOUNT_FLAG        VARCHAR2(2) ; --金额校验通过标识（0：通过，-1：不通过）
     V_DISCONT_FLAG       VARCHAR2(2) ; --折扣校验通过标识（0：通过，-1：不通过）
     V_AMOUNT_CHK_DIS_FLAG  VARCHAR2(2); --到款余额使用负折让余额
     V_RECEIVED_AMOUNT      T_SALES_ACCOUNT_AMOUNT.RECEIVED_AMOUNT%TYPE := 0 ; --到款金额
     V_SALES_AMOUNT         T_SALES_ACCOUNT_AMOUNT.SALES_AMOUNT%TYPE := 0 ;    --销售金额
     V_LOCK_RECEIVED_AMOUNT T_SALES_ACCOUNT_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0 ; --锁定到款金额
     V_THREE_NOT_PAY        T_SALES_ACCOUNT_AMOUNT.THREE_NOT_PAY%TYPE := 0 ; --三方承兑未解付金额
     V_DELAYPAY_AMOUNT      T_SALES_ACCOUNT_AMOUNT.Delaypay_Amount%TYPE := 0 ; --铺底额度
     V_TEMP_DELAYPAY_AMOUNT T_SALES_ACCOUNT_AMOUNT.TEMP_DELAYPAY_AMOUNT%TYPE := 0 ; --临时铺底额度
     V_DISCOUNT_AMOUNT      T_SALES_ACCOUNT_AMOUNT.DISCOUNT_AMOUNT%TYPE := 0 ;  --折让金额
     V_LOCK_DISCOUNT_AMOUNT T_SALES_ACCOUNT_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ; --锁定折让金额
     V_FREEZE_DISCOUNT_AMOUNT  T_SALES_ACCOUNT_AMOUNT.FREEZE_DISCOUNT_AMOUNT%TYPE := 0 ; --冻结折让金额
     V_APPLIED_DISCOUNT_AMOUNT T_SALES_ACCOUNT_AMOUNT.APPLIED_DISCOUNT_AMOUNT%TYPE := 0 ; --核销折让金额
     V_MPAY_STREAM_AMOUNT      T_SALES_ACCOUNT_AMOUNT.MPAY_STREAM_AMOUNT%TYPE      := 0;--流水金额
     V_MPAY_CASH_AMOUNT        T_SALES_ACCOUNT_AMOUNT.MPAY_CASH_AMOUNT%TYPE        := 0;--提现金额

     V_AR_THREE_SUM T_SALES_ACCOUNT_AMOUNT.THREE_NOT_PAY%TYPE ;
     --V_AR_PAYED     T_SALES_ACCOUNT_AMOUNT.THREE_NOT_PAY%TYPE ;
     V_AR_NOT_PAY   T_SALES_ACCOUNT_AMOUNT.THREE_NOT_PAY%TYPE ;

     V_CREDIT_METHOD t_Ar_Receipt_Methods.Attribute1%Type ; --收款方法校验方式
     V_CREDIT_AMOUNT Number ;
     v_credit_msg Varchar2(1000) ;
     V_CHK_DIS_AMOUNT NUMBER;
   
     V_PLN_SRC_ORDER_TYPE	 T_PLN_ORDER_TYPE.SOURCE_ORDER_TYPE_ID%TYPE;--订单类型：1提货订单
     V_PLN_LG_ORDER_HEAD   T_PLN_LG_ORDER_HEAD%ROWTYPE;
     V_PLN_ORDER_HEAD T_PLN_ORDER_HEAD%ROWTYPE; --计划订单
     V_SO_HEADER           T_SO_HEADER%ROWTYPE;
     V_ORDER_DOWN_PAY_SCALE NUMBER;
     V_ORDER_DOWN_PAY_AMOUNT NUMBER;
     V_ORDER_DOWN_PAY_DISAMOUNT NUMBER;
     V_ORDER_LOCK_AMOUNT_FLAG T_PLN_ORDER_TYPE.CHK_CUSG_AMOUNT_FLAG%TYPE;
     V_ORDER_CUSTOMER_ID NUMBER;
     V_ORDER_ACCOUNT_ID NUMBER;
     V_ORDER_HEAD_ID NUMBER;
     V_ORDER_NUMBER T_PLN_LG_ORDER_HEAD.ORDER_NUMBER%TYPE;
     V_ORDER_TYPE_CODE T_PLN_ORDER_TYPE.ORDER_TYPE_CODE%TYPE;
     V_ACTION_TYPE         NUMBER;--对于动作标识1/28，转换为1
     
     VN_DIS_RECEIPT_AMOUNT T_CREDIT_DISCOUNT_AMOUNT.RECEIPT_AMOUNT%TYPE := 0; --折让款项 上账金额 销售折让部分
     VN_DIS_SALES_AMOUNT   T_CREDIT_DISCOUNT_AMOUNT.SALES_AMOUNT%TYPE := 0; --折让款项 销售金额 常规销售部分
     VN_DIS_LOCK_AMOUNT    T_CREDIT_DISCOUNT_AMOUNT.LOCK_AMOUNT%TYPE := 0; --折让款项 锁定到款金额
      --铺底类型
      V_DELAY_TYPE   T_CREDIT_DELAYPAY.DELAYPAY_TYPE%TYPE;
     V_FREEZE_DELAYPAY_AMOUNT  T_SALES_ACCOUNT_AMOUNT.FREEZE_DELAY_AMOUNT%TYPE := 0 ; --冻结保证金
     VN_DIS_RECEIVED_AMOUNT T_CREDIT_DISCOUNT_AMOUNT.RECEIVED_AMOUNT%TYPE := 0; --折让款项 到款金额 收款部分
     --已结算销售金额 add by liangym2 退款校验公式增加未结算金额（销售金额-已结算销售金额）
     V_SALES_AMOUNT_SETTLE         T_SALES_ACCOUNT_AMOUNT.SALES_AMOUNT%TYPE := 0 ;    --已结算销售金额
     V_CREDIT_GROUP_ID T_SALES_ACCOUNT_AMOUNT.Credit_Group_Id%TYPE ; --额度组
     V_ACCOUNT_ID      NUMBER;--账户ID
     V_CUSTOMER_ID     NUMBER;--客户ID
     
     V_REFU_TYPE VARCHAR2(32); --是否转款对应收款方法
     
     V_CUSTOMER_IS_LOCKED T_CUSTOMER_HEADER.IS_LOCKED%TYPE := 'N';  --客户是否逾期锁定  N-未锁定 Y-标识锁定
     v_OVERDUE_CONTROL Varchar2(2);   --20191106 huanghb12  客户逾期锁定是否启用标志
     
  BEGIN

    --获取参数值
    V_AMOUNT_CHK_DIS_FLAG := PKG_BD.F_GET_PARAMETER_VALUE('PLCY_AMOUNT_CHECK_DIS',P_ENTITY_ID);
    
    IF P_ACTION_TYPE BETWEEN 22 AND 27 AND '3' = P_ORDER_TYPE THEN
      BEGIN
        SELECT D.DELAYPAY_TYPE INTO V_DELAY_TYPE FROM T_CREDIT_DELAYPAY D WHERE D.BILL_ID = P_ORDER_ID AND D.BILL_TYPE_ID = TO_NUMBER(P_ORDER_TYPE);
      EXCEPTION WHEN OTHERS THEN
        NULL;
      END;
    END IF;
    
    BEGIN
        SELECT T.* INTO V_SO_HEADER
          FROM CIMS.T_SO_HEADER T 
         WHERE T.SO_HEADER_ID = P_ORDER_ID;
      EXCEPTION WHEN OTHERS THEN
        NULL;
    END;

    FOR I IN 1.. P_SALES_ACCOUNT_AMOUNT.COUNT LOOP
      V_CREDIT_GROUP_ID := P_SALES_ACCOUNT_AMOUNT(I).CREDIT_GROUP_ID;
      V_ACCOUNT_ID := P_SALES_ACCOUNT_AMOUNT(I).ACCOUNT_ID;
       --到款金额
       V_RECEIVED_AMOUNT := V_RECEIVED_AMOUNT + P_SALES_ACCOUNT_AMOUNT(I).RECEIVED_AMOUNT ;
       --销售金额
       V_SALES_AMOUNT    := V_SALES_AMOUNT + P_SALES_ACCOUNT_AMOUNT(I).SALES_AMOUNT ;
       --锁定到款金额
       V_LOCK_RECEIVED_AMOUNT := V_LOCK_RECEIVED_AMOUNT + P_SALES_ACCOUNT_AMOUNT(I).LOCK_RECEIVED_AMOUNT ;
       --三方承兑未解付金额
       V_THREE_NOT_PAY := V_THREE_NOT_PAY + P_SALES_ACCOUNT_AMOUNT(I).THREE_NOT_PAY ;
       --铺底额度
       V_DELAYPAY_AMOUNT := V_DELAYPAY_AMOUNT + P_SALES_ACCOUNT_AMOUNT(I).DELAYPAY_AMOUNT ;
       --临时铺底额度
       V_TEMP_DELAYPAY_AMOUNT := V_TEMP_DELAYPAY_AMOUNT + P_SALES_ACCOUNT_AMOUNT(I).TEMP_DELAYPAY_AMOUNT ;
       --折让金额
       V_DISCOUNT_AMOUNT := V_DISCOUNT_AMOUNT + P_SALES_ACCOUNT_AMOUNT(I).DISCOUNT_AMOUNT ;
       --锁定折让金额
       V_LOCK_DISCOUNT_AMOUNT := V_LOCK_DISCOUNT_AMOUNT + P_SALES_ACCOUNT_AMOUNT(I).LOCK_DISCOUNT_AMOUNT ;
       --冻结折让金额
       V_FREEZE_DISCOUNT_AMOUNT := V_FREEZE_DISCOUNT_AMOUNT + P_SALES_ACCOUNT_AMOUNT(I).FREEZE_DISCOUNT_AMOUNT ;
       --核销折让金额
       V_APPLIED_DISCOUNT_AMOUNT := V_APPLIED_DISCOUNT_AMOUNT + P_SALES_ACCOUNT_AMOUNT(I).APPLIED_DISCOUNT_AMOUNT ;
       --流水金额
       V_MPAY_STREAM_AMOUNT        := V_MPAY_STREAM_AMOUNT + P_SALES_ACCOUNT_AMOUNT(I).MPAY_STREAM_AMOUNT ;
       --提现金额
       V_MPAY_CASH_AMOUNT        := V_MPAY_CASH_AMOUNT + P_SALES_ACCOUNT_AMOUNT(I).MPAY_CASH_AMOUNT ;
       --
       V_FREEZE_DELAYPAY_AMOUNT  := V_FREEZE_DELAYPAY_AMOUNT + P_SALES_ACCOUNT_AMOUNT(I).FREEZE_DELAY_AMOUNT;

    END LOOP ;
    
    FOR I IN 1.. IC_CREDIT_DISCOUNT_AMOUNT.COUNT LOOP
      --折让款项上账金额
      VN_DIS_RECEIPT_AMOUNT := VN_DIS_RECEIPT_AMOUNT + IC_CREDIT_DISCOUNT_AMOUNT(I).RECEIPT_AMOUNT;
      --折让款项销售金额
      VN_DIS_SALES_AMOUNT := VN_DIS_SALES_AMOUNT + IC_CREDIT_DISCOUNT_AMOUNT(I).SALES_AMOUNT;
      --折让款项锁款金额
      VN_DIS_LOCK_AMOUNT := VN_DIS_LOCK_AMOUNT + IC_CREDIT_DISCOUNT_AMOUNT(I).LOCK_AMOUNT;
      --折让到款到款金额
      VN_DIS_RECEIVED_AMOUNT := VN_DIS_RECEIVED_AMOUNT + IC_CREDIT_DISCOUNT_AMOUNT(I).RECEIVED_AMOUNT;
    END LOOP;

    --提货订单 送审锁款 关闭、驳回解锁、销售单开单（3）、退款（21）、销售单结算（14）
    IF ( (1 = IS_PLN_SRC_ORDER_TYPE AND P_ACTION_TYPE IN (1,2,28,29))
      OR P_ACTION_TYPE IN (3,14) )
      AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON') THEN
      V_SALES_AMOUNT := (V_SALES_AMOUNT + VN_DIS_RECEIPT_AMOUNT - VN_DIS_SALES_AMOUNT);
      V_LOCK_RECEIVED_AMOUNT := (V_LOCK_RECEIVED_AMOUNT - VN_DIS_LOCK_AMOUNT);
      V_RECEIVED_AMOUNT := (V_RECEIVED_AMOUNT - VN_DIS_RECEIVED_AMOUNT);
    ELSIF P_ACTION_TYPE BETWEEN 15 AND 21 THEN
      IF (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON') THEN
        V_SALES_AMOUNT := (V_SALES_AMOUNT + VN_DIS_RECEIPT_AMOUNT - VN_DIS_SALES_AMOUNT);
        V_LOCK_RECEIVED_AMOUNT := (V_LOCK_RECEIVED_AMOUNT - VN_DIS_LOCK_AMOUNT);
        V_RECEIVED_AMOUNT := (V_RECEIVED_AMOUNT - VN_DIS_RECEIVED_AMOUNT);
      ELSE
        V_SALES_AMOUNT := VN_DIS_SALES_AMOUNT;
        V_LOCK_RECEIVED_AMOUNT := VN_DIS_LOCK_AMOUNT;
        V_RECEIVED_AMOUNT := (VN_DIS_RECEIVED_AMOUNT + VN_DIS_RECEIPT_AMOUNT);
        V_DELAYPAY_AMOUNT := 0;
        V_TEMP_DELAYPAY_AMOUNT := 0;
        V_DISCOUNT_AMOUNT := 0;
        V_APPLIED_DISCOUNT_AMOUNT := 0;
        V_LOCK_DISCOUNT_AMOUNT := 0;
        V_FREEZE_DISCOUNT_AMOUNT := 0;
        V_MPAY_STREAM_AMOUNT := 0;
        V_MPAY_CASH_AMOUNT := 0;
        --V_THREE_NOT_PAY
      END IF;
    END IF;

    --到款余额-锁定到款金额+铺底额度+临时额度
    --到款余额=到款金额 - 销售金额
    V_AMOUNT_SUM := V_RECEIVED_AMOUNT - V_SALES_AMOUNT - V_LOCK_RECEIVED_AMOUNT
                  + V_DELAYPAY_AMOUNT + V_TEMP_DELAYPAY_AMOUNT ;   --结算控制金额

    --折让余额-锁定折让金额+冻结折让金额
    --扣率折让余额 = 扣率折让金额 - 核销扣率折让金额
    V_DISCONT_SUM := V_DISCOUNT_AMOUNT - V_APPLIED_DISCOUNT_AMOUNT
                   - V_LOCK_DISCOUNT_AMOUNT + V_FREEZE_DISCOUNT_AMOUNT ;  --折扣控制金额
       
    /*=====================================
    --add by sudy 2016-01-06
      由于上游从订单、物流、财务、销售过来的金额，四舍五入造成金额不对等。出现由于几分钱而发
      不出货，开不了单。所以应老马的要求，在相关资金校验项上加5分钱
      造成的结果是：差5分钱内的单，直接让单据过去。
    */
     V_AMOUNT_SUM  := V_AMOUNT_SUM + 0.05 ;
     V_DISCONT_SUM := V_DISCONT_SUM + 0.05 ;
     V_LOCK_RECEIVED_AMOUNT := V_LOCK_RECEIVED_AMOUNT + 0.05 ;
     V_LOCK_DISCOUNT_AMOUNT := V_LOCK_DISCOUNT_AMOUNT + 0.05 ;
     --add by liangym2 2017-6-16 加上美的付平台金额
     V_AMOUNT_SUM  := V_AMOUNT_SUM + (V_MPAY_STREAM_AMOUNT - V_MPAY_CASH_AMOUNT) ;

     IF NVL(V_AMOUNT_CHK_DIS_FLAG,'Y') = 'Y' THEN
       V_CHK_DIS_AMOUNT := LEAST(0,V_DISCONT_SUM);
     ELSE
       V_CHK_DIS_AMOUNT := 0;
     END IF;
     
     --20160909 梁颜明 订金金额校验
     --V_PLN_SRC_ORDER_TYPE获取订单类型 1提货订单
     IF P_ACTION_TYPE IN (1,2,28) THEN
       V_ACTION_TYPE := (CASE WHEN P_ACTION_TYPE = 2 THEN NULL ELSE 1 END);--P_ACTION_TYPE
       SELECT MAX(SOURCE_ORDER_TYPE_ID) INTO V_PLN_SRC_ORDER_TYPE FROM T_PLN_ORDER_TYPE
       WHERE ENTITY_ID = P_ENTITY_ID AND ORDER_TYPE_CODE = P_ORDER_TYPE;
     END IF;
     --判断是提货订单，根据订单ID获取提货订单头表的订金比例、订金、锁款类型
     IF V_PLN_SRC_ORDER_TYPE IN (1,10, 0) THEN
     IF V_PLN_SRC_ORDER_TYPE IN (1,10) THEN
       SELECT * INTO V_PLN_LG_ORDER_HEAD FROM T_PLN_LG_ORDER_HEAD
       WHERE ORDER_HEAD_ID = P_ORDER_ID;
       IF V_PLN_LG_ORDER_HEAD.ORDER_TYPE_CODE <> P_ORDER_TYPE THEN
         P_RESULT  := -20000 ;
         P_ERR_MSG := '订单校验不通过：传入的订单类型编码：'
           || P_ORDER_TYPE || '与提货订单 ' || V_PLN_LG_ORDER_HEAD.ORDER_NUMBER || ' 对应的订单类型编码：'
         || V_PLN_LG_ORDER_HEAD.ORDER_TYPE_CODE || '不一致';
         RETURN;
         END IF;
         V_ORDER_DOWN_PAY_SCALE := V_PLN_LG_ORDER_HEAD.DOWN_PAY_SCALE;
         V_ORDER_DOWN_PAY_AMOUNT := V_PLN_LG_ORDER_HEAD.DOWN_PAY_AMOUNT;
         V_ORDER_DOWN_PAY_DISAMOUNT := V_PLN_LG_ORDER_HEAD.DOWN_PAY_DIS_AMOUNT;
         V_ORDER_LOCK_AMOUNT_FLAG := V_PLN_LG_ORDER_HEAD.LOCK_AMOUNT_FLAG;
         V_ORDER_CUSTOMER_ID := V_PLN_LG_ORDER_HEAD.CUSTOMER_ID;
         V_ORDER_ACCOUNT_ID := V_PLN_LG_ORDER_HEAD.ACCOUNT_ID;
         V_ORDER_HEAD_ID := V_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID;
         V_ORDER_NUMBER := V_PLN_LG_ORDER_HEAD.ORDER_NUMBER;
         V_ORDER_TYPE_CODE := V_PLN_LG_ORDER_HEAD.ORDER_TYPE_CODE;
       ELSIF V_PLN_SRC_ORDER_TYPE IN (0) THEN
         SELECT * INTO V_PLN_ORDER_HEAD FROM T_PLN_ORDER_HEAD
         WHERE ORDER_HEAD_ID = P_ORDER_ID;
         IF V_PLN_ORDER_HEAD.ORDER_TYPE_CODE <> P_ORDER_TYPE THEN
           P_RESULT  := -20000 ;
           P_ERR_MSG := '订单校验不通过：传入的订单类型编码：'
           || P_ORDER_TYPE || '与计划订单 ' || V_PLN_ORDER_HEAD.ORDER_NUMBER || ' 对应的订单类型编码：'
           || V_PLN_ORDER_HEAD.ORDER_TYPE_CODE || '不一致';
           RETURN;
         END IF;
         V_ORDER_DOWN_PAY_SCALE := V_PLN_ORDER_HEAD.DOWN_PAY_SCALE;
         V_ORDER_DOWN_PAY_AMOUNT := V_PLN_ORDER_HEAD.DOWN_PAY_AMOUNT;
         V_ORDER_DOWN_PAY_DISAMOUNT := V_PLN_ORDER_HEAD.DOWN_PAY_DIS_AMOUNT;
         V_ORDER_LOCK_AMOUNT_FLAG := V_PLN_ORDER_HEAD.LOCK_AMOUNT_FLAG;
         V_ORDER_CUSTOMER_ID := V_PLN_ORDER_HEAD.CUSTOMER_ID;
         V_ORDER_ACCOUNT_ID := V_PLN_ORDER_HEAD.ACCOUNT_ID;
         V_ORDER_HEAD_ID := V_PLN_ORDER_HEAD.ORDER_HEAD_ID;
         V_ORDER_NUMBER := V_PLN_ORDER_HEAD.ORDER_NUMBER;
         V_ORDER_TYPE_CODE := V_PLN_ORDER_HEAD.ORDER_TYPE_CODE;
       END IF;
     END IF;
     --LOCK_AMOUNT_FLAG 到款锁定标志：S:送审锁款 Y:发货锁定到款 N:不锁定到款 
     --RS:资源送审锁定到款  RT:资源提货锁定到款（标志来源单据类型）

   --P_ACTION_TYPE = 1 订单评审
      --P_ACTION_TYPE = 28实际上是原来P_ACTION_TYPE = 1的逻辑
    IF V_ACTION_TYPE = 1 THEN    
      --不校验客户款项（update by zhoujg3 2019-02-16） T_PLN_LG_ORDER_HEAD.fund_check_mode = 'ORDER' 款项校验模式：ORDER 订单，CREDIT (校验)余额
      IF (NVL(V_PLN_LG_ORDER_HEAD.FUND_CHECK_MODE,'-') = 'ORDER') THEN
          P_RESULT  := V_SEC_RESULT;
          P_ERR_MSG := V_SUCCESS;
          RETURN;
      END IF;
      
      IF V_ORDER_DOWN_PAY_SCALE >= 0 AND V_ORDER_LOCK_AMOUNT_FLAG IN ('S', 'HQ') THEN
        --如果是送审锁款并且订金比例大于0，进行订金的资金校验
        --对于动作标识1/28都要进入此资金校验，1/28的校验公式是不一样的
        PKG_CREDIT_DOWN_PAY.PRC_DOWN_PAY_VERIFICATION(P_ENTITY_ID,
        P_ACTION_TYPE,V_ORDER_CUSTOMER_ID,V_ORDER_ACCOUNT_ID,P_SETTLEMENT_SUM
        ,P_DISCOUNT_SUM,V_AMOUNT_SUM,V_DISCONT_SUM,P_DISCONT_CRTL_FLAG
        ,V_CHK_DIS_AMOUNT,V_ORDER_DOWN_PAY_SCALE
        ,V_ORDER_HEAD_ID,V_ORDER_NUMBER,V_ORDER_TYPE_CODE
        ,V_ORDER_DOWN_PAY_AMOUNT,V_ORDER_DOWN_PAY_DISAMOUNT
        ,V_LOCK_RECEIVED_AMOUNT,V_LOCK_DISCOUNT_AMOUNT
        ,(CASE WHEN 1 = P_ACTION_TYPE THEN 1 ELSE 3 END)--DECODE(P_ACTION_TYPE,28,NULL,1)
        --解锁订金锁款，不校验提货额度，因为在送审时已经校验且锁订金
        ,P_RESULT,P_ERR_MSG);
      ELSE
        --对于动作标识1，判断是否需要占用订单提货额度
        IF 1 = P_ACTION_TYPE AND V_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID IS NOT NULL
          AND 1 = PKG_CREDIT_DOWN_PAY.FUN_JUDGE_OCCUPY_ORDER_AMOUNT(NULL,V_PLN_LG_ORDER_HEAD) THEN
          PKG_CREDIT_DOWN_PAY.PRC_ORDER_AMOUNT_VERIFICATION(P_ENTITY_ID, P_ACTION_TYPE
          ,V_PLN_LG_ORDER_HEAD.CUSTOMER_ID,V_PLN_LG_ORDER_HEAD.ACCOUNT_ID,P_SETTLEMENT_SUM,P_RESULT,P_ERR_MSG);
          --校验提货额度有错误，直接返回提示
          IF P_RESULT <> V_SEC_RESULT THEN
            RETURN;
          END IF;
        END IF;
      
       IF P_AMOUNT_CRTL_FLAG = '0' THEN --金额控制
         --若结算金额小于（到款余额-锁定到款金额+铺底额度+临时额度），校验结果为是
         IF P_Settlement_SUM <= V_AMOUNT_SUM + V_CHK_DIS_AMOUNT THEN  --对于折让余额小于0，则合并到到款余额中检查
            V_AMOUNT_FLAG := '0' ;
         ELSE
            V_AMOUNT_FLAG := '-1' ;
         END IF ;
       ELSIF P_AMOUNT_CRTL_FLAG = '-1' THEN --金额控制标识为-1，不用校验直接通过
            V_AMOUNT_FLAG := '0' ;
       END IF ;

       IF P_DISCONT_CRTL_FLAG = '0' THEN --折扣控制
         --若折扣金额小于（折让余额-锁定折让金额+冻结折让金额）
         IF P_Discount_SUM <= V_DISCONT_SUM THEN
            V_DISCONT_FLAG := '0' ;
         ELSE
            V_DISCONT_FLAG := '-1' ;
         END IF ;
       ELSIF P_DISCONT_CRTL_FLAG = '-1' THEN  ----折扣控制标识为-1，不用校验直接通过
            V_DISCONT_FLAG := '0' ;
       END IF ;

       --判断最终的校验结果：金额控制=0 折扣控制=0 通过，其他都不通过
       IF V_AMOUNT_FLAG = '0' AND V_DISCONT_FLAG = '0' THEN
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           --RAISE V_BASE_EXCEPTION ;
          RETURN ;
       ELSE
           P_RESULT  := -20000 ;
           P_ERR_MSG := '订单评审校验不通过!';
           IF V_AMOUNT_FLAG <> '0' THEN
             IF V_DISCONT_SUM >= 0 THEN
               P_ERR_MSG := P_ERR_MSG ||V_NL|| '【原因：客户可用到款余额('|| V_AMOUNT_SUM ||')小于订单金额('|| P_Settlement_SUM ||')！';
             ELSE
               P_ERR_MSG := P_ERR_MSG ||V_NL|| '【原因：客户可用到款余额('|| V_AMOUNT_SUM ||')+折让余额('|| (V_DISCONT_SUM-0.05) ||')小于订单金额('|| P_Settlement_SUM ||')！';
             END IF;
           END IF;
           IF V_DISCONT_FLAG <> '0' THEN
             P_ERR_MSG := P_ERR_MSG ||V_NL|| '【原因：客户可用折让余额('|| V_DISCONT_SUM ||')小于订单折让金额('|| P_Discount_SUM ||')！';
           END IF;
           --原有报错信息
           --P_ERR_MSG := '订单评审校验不通过!' ||V_NL|| (CASE WHEN V_AMOUNT_FLAG <> '0' THEN '【原因：客户可用到款余额('|| V_AMOUNT_SUM ||')小于订单金额('|| P_Settlement_SUM ||')！' END)
           --                                   ||V_NL|| (CASE WHEN V_DISCONT_FLAG <> '0' THEN '【原因：客户可用折让余额('|| V_DISCONT_SUM ||')小于订单折让金额('|| P_Discount_SUM ||')！' END) ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
       END IF ;
      END IF;

    --P_ACTION_TYPE = 2 取消订单
     /*校验规则：1、结算金额 <= 锁定到款金额
                 2、折让金额 <= 锁定折让金额*/
    ELSIF P_ACTION_TYPE = 2 THEN
       
      --网批不校验客户款项（update by zhoujg3 2019-02-16）
      IF (NVL(V_PLN_LG_ORDER_HEAD.FUND_CHECK_MODE,'-') = 'ORDER') THEN
          P_RESULT  := V_SEC_RESULT;
          P_ERR_MSG := V_SUCCESS;
          RETURN;
      END IF;
       
      IF V_ORDER_DOWN_PAY_SCALE >= 0 AND V_ORDER_LOCK_AMOUNT_FLAG IN ('S', 'HQ') THEN
        PKG_CREDIT_DOWN_PAY.PRC_DOWN_PAY_VERIFICATION(P_ENTITY_ID,
        P_ACTION_TYPE,V_ORDER_CUSTOMER_ID,V_ORDER_ACCOUNT_ID,P_SETTLEMENT_SUM
        ,P_DISCOUNT_SUM,V_AMOUNT_SUM,V_DISCONT_SUM,P_DISCONT_CRTL_FLAG
        ,V_CHK_DIS_AMOUNT,V_ORDER_DOWN_PAY_SCALE
        ,V_ORDER_HEAD_ID,V_ORDER_NUMBER,V_ORDER_TYPE_CODE
        ,V_ORDER_DOWN_PAY_AMOUNT,V_ORDER_DOWN_PAY_DISAMOUNT
        ,V_LOCK_RECEIVED_AMOUNT,V_LOCK_DISCOUNT_AMOUNT
        ,1,P_RESULT,P_ERR_MSG);
      ELSE
        --判断是否需要占用订单提货额度
       IF V_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID IS NOT NULL
         AND 1 = PKG_CREDIT_DOWN_PAY.FUN_JUDGE_OCCUPY_ORDER_AMOUNT(NULL,V_PLN_LG_ORDER_HEAD) THEN
         PKG_CREDIT_DOWN_PAY.PRC_ORDER_AMOUNT_VERIFICATION(P_ENTITY_ID, P_ACTION_TYPE
         ,V_PLN_LG_ORDER_HEAD.CUSTOMER_ID,V_PLN_LG_ORDER_HEAD.ACCOUNT_ID,P_SETTLEMENT_SUM,P_RESULT,P_ERR_MSG);
         --校验提货额度有错误，直接返回提示
         IF P_RESULT <> V_SEC_RESULT THEN
           RETURN;
         END IF;
       END IF;
       IF P_AMOUNT_CRTL_FLAG = '0' THEN --金额控制
          IF P_Settlement_SUM <= V_LOCK_RECEIVED_AMOUNT Then
            V_AMOUNT_FLAG := '0' ;
          ELSE
            V_AMOUNT_FLAG := '-1' ;
          End If ;
       Elsif P_AMOUNT_CRTL_FLAG = '-1' Then
           V_AMOUNT_FLAG := '0' ;
       End If ;

       IF P_DISCONT_CRTL_FLAG = '0' THEN --折扣控制
          If P_Discount_SUM <= V_LOCK_DISCOUNT_AMOUNT THEN
            V_DISCONT_FLAG := '0' ;
          ELSE
            V_DISCONT_FLAG := '-1' ;
          End If ;
       Elsif P_DISCONT_CRTL_FLAG = '-1' Then
           V_DISCONT_FLAG := '0' ;
       End If ;

       --判断最终的校验结果：金额控制=0 折扣控制=0 通过，其他都不通过
       IF V_AMOUNT_FLAG = '0' AND V_DISCONT_FLAG = '0' THEN
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
       ELSE
           P_RESULT  := -20000 ;
           P_ERR_MSG := '取消订单校验不通过!'||V_NL|| (CASE WHEN V_AMOUNT_FLAG <> '0' THEN '【原因：客户订单锁款金额('|| V_LOCK_RECEIVED_AMOUNT ||')小于需要取消订单的金额('|| P_Settlement_SUM ||')！' END)
                                             ||V_NL|| (CASE WHEN V_DISCONT_FLAG <> '0' THEN '【原因：客户订单锁定折让金额('|| V_LOCK_DISCOUNT_AMOUNT ||')小于需要取消订单的折让金额('|| P_Discount_SUM ||')！' END) ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
       END IF ;
      END IF;

    -- P_ACTION_TYPE = 3 开单（销售单）
    /*校验规则：1、解锁锁定到款金额和锁定折让金额，
                2、若是锁定的金额不够，再看一下可提货金额是否够开销售单*/
    ELSIF P_ACTION_TYPE = 3 THEN
       --销售开单，手工开单时候，如果发货方式为调账，则不需要进行锁定金额的解锁,
         --则可提货余额必须加上锁定金额，可用折让余额也是
       /*IF P_CREATED_MODE = 2 THEN  --跟廖丽章已确认，2为人工开单
          V_AMOUNT_SUM := V_AMOUNT_SUM + V_LOCK_RECEIVED_AMOUNT ; --可提货金额加上锁定部分
          V_DISCONT_SUM := V_DISCONT_SUM + V_LOCK_DISCOUNT_AMOUNT ;
       END IF ;

       IF P_AMOUNT_CRTL_FLAG = '0' THEN --金额控制
         --若结算金额 小于等于 锁定到款金额
         IF P_Settlement_SUM <= V_LOCK_RECEIVED_AMOUNT THEN
            V_AMOUNT_FLAG := '0' ;
         --若结算金额小于可提货余额，校验结果为是
         ELSIF P_Settlement_SUM <= V_AMOUNT_SUM THEN
            V_AMOUNT_FLAG := '0' ;
         ELSE
            V_AMOUNT_FLAG := '-1' ;
         END IF ;
       ELSIF P_AMOUNT_CRTL_FLAG = '-1' THEN --金额控制标识为-1，不用校验直接通过
            V_AMOUNT_FLAG := '0' ;
       END IF ;

       IF P_DISCONT_CRTL_FLAG = '0' THEN --折扣控制
         --若是折扣金额小于等于锁定折让金额，校验结果为是
         IF P_Discount_SUM <= V_LOCK_DISCOUNT_AMOUNT THEN
            V_DISCONT_FLAG := '0' ;
         --若折扣金额小于等于可用折让余额，校验结果为是
         ELSIF P_Discount_SUM <= V_DISCONT_SUM THEN
            V_DISCONT_FLAG := '0' ;
         ELSE
            V_DISCONT_FLAG := '-1' ;
         END IF ;
       ELSIF P_DISCONT_CRTL_FLAG = '-1' THEN  ----折扣控制标识为-1，不用校验直接通过
            V_DISCONT_FLAG := '0' ;
       END IF ;*/
       --20191106 huanghb12 获取参数是否将客户逾期控制作用到提货订单上
        Begin
          v_OVERDUE_CONTROL := Pkg_Bd.f_Get_Parameter_Value('CREDIT_CUSTOMER_OVERDUE_CONTROL',
                                                              V_SO_HEADER.Entity_Id);
        Exception
          When Others Then
            v_OVERDUE_CONTROL := 'N';
        End;
       
       --add by huanghb12 20-手工销售开单的时候，增加客户逾期校验，
       IF (v_OVERDUE_CONTROL = 'Y')and (P_CREATED_MODE = 20) THEN
         select H.IS_LOCKED INTO V_CUSTOMER_IS_LOCKED
          from cims.t_Customer_Header H
          WHERE H.CUSTOMER_CODE = V_SO_HEADER.Customer_Code;
        IF V_CUSTOMER_IS_LOCKED = 'Y' THEN
          P_RESULT  := -20000 ;
          P_ERR_MSG := '开单(销售单)校验不通过！';
          P_ERR_MSG := P_ERR_MSG ||V_NL|| '【原因：该客户('|| V_SO_HEADER.Customer_Code ||')逾期3次及以上！】';
          RETURN;
        END IF;
       END IF;
      --end by huanghb12
      
       --网批不校验客户款项（update by zhoujg3 2019-02-16）
       IF (NVL(V_SO_HEADER.CUSTOMER_CHANNEL_TYPE,'-1') = PKG_CUSTOMER_PUB.V_CUSTOMER_CHANNEL_TYPE_15
             AND NVL(V_SO_HEADER.FUND_CHECK_MODE,'-') = 'ORDER') THEN
           P_RESULT  := V_SEC_RESULT;
           P_ERR_MSG := V_SUCCESS;
           RETURN;
       END IF;

       --以上的校验规则有问题，重新梳理
       IF P_CREATED_MODE = 20 OR P_CREATED_MODE = 30 THEN
         IF P_AMOUNT_CRTL_FLAG = '0' THEN --金额控制
           --若结算金额 小于等于 可提货金额
           IF P_Settlement_SUM <= V_AMOUNT_SUM + V_CHK_DIS_AMOUNT THEN
              V_AMOUNT_FLAG := '0' ;
           ELSE
              V_AMOUNT_FLAG := '-1' ;
           END IF ;
         ELSIF P_AMOUNT_CRTL_FLAG = '-1' THEN --金额控制标识为-1，不用校验直接通过
              V_AMOUNT_FLAG := '0' ;
         END IF ;

         IF P_DISCONT_CRTL_FLAG = '0' THEN --折扣控制
           --若是折扣金额小于等于锁定折让金额，校验结果为是
           IF P_Discount_SUM <= V_DISCONT_SUM THEN
              V_DISCONT_FLAG := '0' ;
           ELSE
              V_DISCONT_FLAG := '-1' ;
           END IF ;
         ELSIF P_DISCONT_CRTL_FLAG = '-1' THEN  ----折扣控制标识为-1，不用校验直接通过
           V_DISCONT_FLAG := '0' ;
         END IF ;

         --记录校验不通过原因
         IF V_AMOUNT_FLAG <> '0' THEN
           IF V_DISCONT_SUM >= 0 THEN
             P_ERR_MSG := V_NL|| '【原因：客户可用到款余额('|| V_AMOUNT_SUM ||')小于订单金额('|| P_Settlement_SUM ||')！';
           ELSE
             P_ERR_MSG := V_NL|| '【原因：客户可用到款余额('|| V_AMOUNT_SUM ||')+折让余额('|| (V_DISCONT_SUM-0.05) ||')小于销售开单金额('|| P_Settlement_SUM ||')！';
           END IF;
         END IF;
         IF V_DISCONT_FLAG <> '0' THEN
           P_ERR_MSG := P_ERR_MSG ||V_NL|| '【原因：客户可用折让余额('|| V_DISCONT_SUM ||')小于销售开单折让金额('|| P_Discount_SUM ||')！';
         END IF;
         --原报错信息
         --P_ERR_MSG := V_NL || (CASE WHEN V_AMOUNT_FLAG <> '0' THEN '【原因：客户可用到款余额('|| V_AMOUNT_SUM ||')小于销售开单金额('|| P_Settlement_SUM ||')！' END)
         --            || V_NL || (CASE WHEN V_DISCONT_FLAG <> '0' THEN '【原因：客户可用折让余额('|| V_DISCONT_SUM ||')小于销售开单折让金额('|| P_Discount_SUM ||')！' END) ;

       ELSIF P_CREATED_MODE NOT IN (20,30) THEN  --跟廖丽章已确认，20为人工开单,30为中转全赔开单
         
         IF P_AMOUNT_CRTL_FLAG = '0' THEN --金额控制
           --若结算金额 小于等于 锁定到款金额
           IF P_Settlement_SUM <= V_LOCK_RECEIVED_AMOUNT THEN
              V_AMOUNT_FLAG := '0' ;
           ELSE
              V_AMOUNT_FLAG := '-1' ;
           END IF ;
         ELSIF P_AMOUNT_CRTL_FLAG = '-1' THEN --金额控制标识为-1，不用校验直接通过
              V_AMOUNT_FLAG := '0' ;
         END IF ;

         IF P_DISCONT_CRTL_FLAG = '0' THEN --折扣控制
           --若是折扣金额小于等于锁定折让金额，校验结果为是
           IF P_Discount_SUM <= V_LOCK_DISCOUNT_AMOUNT THEN
              V_DISCONT_FLAG := '0' ;
           ELSE
              V_DISCONT_FLAG := '-1' ;
           END IF ;
         ELSIF P_DISCONT_CRTL_FLAG = '-1' THEN  ----折扣控制标识为-1，不用校验直接通过
           V_DISCONT_FLAG := '0' ;
         END IF ;

         --记录校验不通过原因
         P_ERR_MSG := V_NL || (CASE WHEN V_AMOUNT_FLAG <> '0' THEN '【原因：客户锁款金额('|| V_LOCK_RECEIVED_AMOUNT ||')小于销售开单金额('|| P_Settlement_SUM ||')！' END)
                   || V_NL || (CASE WHEN V_DISCONT_FLAG <> '0' THEN '【原因：客户锁定折让金额('|| V_LOCK_DISCOUNT_AMOUNT ||')小于销售开单折让金额('|| P_Discount_SUM ||')！' END) ;

       END IF ;

       --判断最终的校验结果：金额控制=0 折扣控制=0 通过，其他都不通过
       IF V_AMOUNT_FLAG = '0' AND V_DISCONT_FLAG = '0' THEN
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           RETURN ;
       ELSE
           P_RESULT  := -20000 ;
           P_ERR_MSG := '开单(销售单)校验不通过！' || P_ERR_MSG ;
           RETURN ;
       END IF ;
    -- P_ACTION_TYPE = 4 开单（销售红冲单） P_ACTION_TYPE = 5 开单（退货单） P_ACTION_TYPE = 13 结算（退货单）
    /*校验规则：1、销售金额>=结算金额
                2、扣率折让金额>=核销扣率折让金额
                3、两种款项必须都校验，不管控制方式情况如何*/
    ELSIF P_ACTION_TYPE = 4 OR P_ACTION_TYPE = 5 OR P_ACTION_TYPE = 13 THEN
       --经过跟欧阳、马晓武确认，退货，红冲不校验 2014-11-05 11:22
      /*IF P_Settlement_SUM <= V_SALES_AMOUNT
         AND P_Discount_SUM <= V_APPLIED_DISCOUNT_AMOUNT THEN
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           RETURN ;
      ELSE
           P_RESULT  := -20000 ;
           P_ERR_MSG := (CASE P_ACTION_TYPE WHEN 4 THEN '开单(销售红冲单)' ELSE '开单（退货单）' END) ||'校验不通过!'
              || V_NL ||(CASE WHEN P_Settlement_SUM > V_SALES_AMOUNT THEN '【原因：客户销售金额小于销售' || (CASE P_ACTION_TYPE WHEN 4 THEN '红冲金额】!' ELSE '退货金额】!' END) END )
              || V_NL ||(CASE WHEN P_Discount_SUM > V_APPLIED_DISCOUNT_AMOUNT THEN '【原因：客户核销折让金额小于销售' || (CASE P_ACTION_TYPE WHEN 4 THEN '红冲折让金额】!' ELSE '退货折让金额】!' END) END) ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
       END IF ;*/

       P_RESULT  := V_SEC_RESULT ;
       P_ERR_MSG := V_SUCCESS ;
       RETURN ;

    --P_ACTION_TYPE = 7 开单（折让证明单） P_ACTION_TYPE = 9 开单（销售折让单）
    /*校验规则：1、销售金额>=结算金额
                2、两种款项必须都校验，不管控制方式情况如何*/
     ELSIF P_ACTION_TYPE = 7 OR P_ACTION_TYPE = 9 THEN
       --经过跟欧阳、马晓武确认，退货，红冲不校验 2014-11-05 11:22
       /*IF P_Settlement_SUM <= V_SALES_AMOUNT THEN
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
       ELSE
           P_RESULT  := -20000 ;
           P_ERR_MSG := (CASE P_ACTION_TYPE WHEN 7 THEN '开单（折让证明单）校验不通过！【原因：开单金额大于客户总销售金额】'
                                                ELSE '开单（销售折让单）校验不通过！【原因：开单金额大于客户总销售金额】' END) ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
       END IF ; */

       P_RESULT  := V_SEC_RESULT ;
       P_ERR_MSG := V_SUCCESS ;
       RETURN ;

    --P_ACTION_TYPE = 10,销售折让红冲单
    /*校验规则：到款余额 - 结算金额 >= 0 */
    /*ELSIF P_ACTION_TYPE = 10 THEN
       --梁学荣要求添加校验，结算金额不能大于到款余额 2015-07-08
       IF P_Settlement_SUM <= (V_RECEIVED_AMOUNT - V_SALES_AMOUNT) THEN
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
       ELSE
           P_RESULT  := -20000 ;
           P_ERR_MSG := (CASE P_ACTION_TYPE WHEN 10 THEN '开单（销售折让红冲单）校验不通过！【原因：开单金额（'||P_Settlement_SUM||'）大于客户到款余额（'||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'）】' END) ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
       END IF ;*/

      --P_ACTION_TYPE = 12 开单（扣率折让红冲单）
    /*校验规则：1、扣率折让金额>=折让金额 */
     ELSIF P_ACTION_TYPE = 12 THEN
       IF P_DISCONT_CRTL_FLAG = '0' THEN --折扣控制
           --IF P_Discount_SUM <= V_DISCOUNT_AMOUNT THEN
           --IF P_Settlement_SUM <= V_DISCONT_SUM THEN
               P_RESULT  := V_SEC_RESULT ;
               P_ERR_MSG := V_SUCCESS ;
               --RAISE V_BASE_EXCEPTION ;
               RETURN ;
           /*ELSE
               P_RESULT  := -20000 ;
               P_ERR_MSG := '开单（扣率折让红冲单）校验不通过!【原因：开单金额('|| P_Settlement_SUM ||')大于客户折让金额('|| V_DISCOUNT_AMOUNT ||')' ;
               --RAISE V_BASE_EXCEPTION ;
               RETURN ;
           END IF ; */
       Elsif P_DISCONT_CRTL_FLAG = '-1' Then
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
       End If ;
     --P_ACTION_TYPE = 14 结算（销售单）
    /*校验规则：1、结算（销售单），参数传的是差额，有可能是负数
                2、销售金额+P_Settlement_SUM >= 0
                3、核销扣率折让金额 + P_Discount_SUM >= 0*/

     /* 2016-01-18 - 龙鸿文
     校验规则重置：
                1、单据结算金额（差额） <= 到款余额 （差额>0时校验）
                2、单据结算折让金额（差额） <= 折让余额 （差额>0时校验）
               到款余额 = 到款金额 - 销售金额
               折让余额 = 折让金额 - 核销折让金额*/
     ELSIF P_ACTION_TYPE = 14 THEN
       
       --网批不校验客户款项（update by zhoujg3 2019-02-16）
       IF (NVL(V_SO_HEADER.CUSTOMER_CHANNEL_TYPE,'-1') = PKG_CUSTOMER_PUB.V_CUSTOMER_CHANNEL_TYPE_15
             AND NVL(V_SO_HEADER.FUND_CHECK_MODE,'-') = 'ORDER') THEN
           P_RESULT  := V_SEC_RESULT;
           P_ERR_MSG := V_SUCCESS;
           RETURN;
       END IF;

       IF P_AMOUNT_CRTL_FLAG = '0' THEN --金额控制
           IF P_Settlement_SUM > 0 THEN
             IF '0' = IS_RECEIVABLE_CRTL_FLAG THEN
              IF P_Settlement_SUM <= V_RECEIVED_AMOUNT - V_SALES_AMOUNT THEN
                 V_AMOUNT_FLAG := '0' ;
              ELSE
                 V_AMOUNT_FLAG := '-1' ;
              END IF;
             ELSIF '-1' = IS_RECEIVABLE_CRTL_FLAG THEN
              IF P_Settlement_SUM <= V_AMOUNT_SUM THEN
                 V_AMOUNT_FLAG := '0' ;
              ELSE
                 V_AMOUNT_FLAG := '-1' ;
              END IF;
             END IF;
           ELSE
              V_AMOUNT_FLAG := '0' ;
           END IF;
       Elsif P_AMOUNT_CRTL_FLAG = '-1' Then
              V_AMOUNT_FLAG := '0' ;
       Else
              V_AMOUNT_FLAG := '-1' ;
       End If ;

       IF P_DISCONT_CRTL_FLAG = '0' THEN --折扣控制
          IF P_Discount_SUM > 0 THEN
            IF '0' = IS_RECEIVABLE_CRTL_FLAG THEN
             IF P_Discount_SUM <= V_DISCOUNT_AMOUNT - V_APPLIED_DISCOUNT_AMOUNT THEN
                V_DISCONT_FLAG := '0' ;
             ELSE
                V_DISCONT_FLAG := '-1' ;
             END IF;
            ELSIF '-1' = IS_RECEIVABLE_CRTL_FLAG THEN
             IF P_Discount_SUM <= V_DISCONT_SUM THEN
                V_DISCONT_FLAG := '0' ;
             ELSE
                V_DISCONT_FLAG := '-1' ;
             END IF;
            END IF;
          ELSE
             V_DISCONT_FLAG := '0' ;
          END IF;
       Elsif P_DISCONT_CRTL_FLAG = '-1' Then
              V_DISCONT_FLAG := '0' ;
       Else
              V_DISCONT_FLAG := '-1' ;
       End If ;

        --判断最终的校验结果：金额控制=0 折扣控制=0 通过，其他都不通过
       IF V_AMOUNT_FLAG = '0' AND V_DISCONT_FLAG = '0' THEN

          P_RESULT  := V_SEC_RESULT ;
          P_ERR_MSG := V_SUCCESS ;
          --RAISE V_BASE_EXCEPTION ;
          RETURN ;
       ELSE
           P_RESULT  := -20000 ;
           P_ERR_MSG := '结算（销售单）校验不通过！';
           IF '0' = IS_RECEIVABLE_CRTL_FLAG THEN
             IF V_RECEIVED_AMOUNT - V_SALES_AMOUNT < P_Settlement_SUM THEN
               P_ERR_MSG := P_ERR_MSG || V_NL || '【原因：调整部分结算金额('|| P_Settlement_SUM ||')大于客户到款余额：   客户到款金额('|| V_RECEIVED_AMOUNT ||')-客户销售额('|| V_SALES_AMOUNT
               ||')=   ' || (V_RECEIVED_AMOUNT - V_SALES_AMOUNT);
             END IF;
             IF V_DISCOUNT_AMOUNT - V_APPLIED_DISCOUNT_AMOUNT < P_Discount_SUM THEN
               P_ERR_MSG := P_ERR_MSG || V_NL || '【原因：调整部分结算折让金额('|| P_Discount_SUM ||')大于客户折扣余额：   客户折让金额('|| V_DISCOUNT_AMOUNT ||')-客户核销折让金额('|| V_APPLIED_DISCOUNT_AMOUNT
                ||')=   ' || (V_DISCOUNT_AMOUNT - V_APPLIED_DISCOUNT_AMOUNT);
             END IF;
           ELSIF '-1' = IS_RECEIVABLE_CRTL_FLAG THEN
             IF V_AMOUNT_SUM < P_Settlement_SUM THEN
               P_ERR_MSG := P_ERR_MSG || V_NL || '【原因：调整部分结算金额('|| P_Settlement_SUM ||')大于客户可用到款金额：   客户到款金额('|| V_RECEIVED_AMOUNT ||')-客户销售额('|| V_SALES_AMOUNT
                ||')-锁定到款金额('|| V_LOCK_RECEIVED_AMOUNT ||')+铺底金额('|| V_DELAYPAY_AMOUNT
                 ||')+临时铺底金额('|| V_TEMP_DELAYPAY_AMOUNT ||')+流水金额('|| V_MPAY_STREAM_AMOUNT ||')-提现金额('|| V_MPAY_CASH_AMOUNT ||')=   ' || V_AMOUNT_SUM;
             END IF;
             IF V_DISCONT_SUM < P_Discount_SUM THEN
               P_ERR_MSG := P_ERR_MSG || V_NL || '【原因：调整部分结算折让金额('|| P_Discount_SUM ||')大于客户可用折扣金额：   客户折让金额('|| V_DISCOUNT_AMOUNT ||')-客户核销折让金额('|| V_APPLIED_DISCOUNT_AMOUNT
                ||')-锁定扣率折让金额('|| V_LOCK_DISCOUNT_AMOUNT ||')+冻结扣率折让金额('|| V_FREEZE_DISCOUNT_AMOUNT ||')=   ' || V_DISCONT_SUM;
             END IF;
           END IF;
           /*P_ERR_MSG := '结算（销售单）校验不通过！'
                  || V_NL || (CASE WHEN P_Settlement_SUM + V_SALES_AMOUNT < 0 THEN '【原因：结算金额('|| P_Settlement_SUM ||')+客户销售额('|| V_SALES_AMOUNT ||')小于0' END)
                  || V_NL || (CASE WHEN P_Discount_SUM + V_DISCOUNT_AMOUNT < 0 THEN '【原因：结算折让金额('|| P_Discount_SUM ||')+客户可用折让余额('|| V_DISCOUNT_AMOUNT ||')小于0' END);*/
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
       END IF ;
     --P_ACTION_TYPE = 16 收款冲销
     /*校验规则：1、到款金额 >= P_Settlement_SUM
      *    规则改动：跟刘会玲确认，收款红冲应该是不校验的
      */
     ELSIF P_ACTION_TYPE = 16 THEN

       --根据单据ID获取收款方法信用校验方式
       Begin
         Select B.ATTRIBUTE1,A.CUSTOMER_ID,A.ACCOUNT_ID,B.TYPE
           Into V_CREDIT_METHOD,V_CUSTOMER_ID,V_ACCOUNT_ID,V_REFU_TYPE
          From T_Ar_Cash_Receipt_Headers a, T_Ar_Receipt_Methods b
         Where A.Receipt_Method_Id = B.Receipt_Method_Id
           And A.CASH_RECEIPT_ID = P_ORDER_ID ;
       Exception When Others Then
         P_RESULT  := -20000 ;
         P_ERR_MSG :=  '收款冲销校验不通过！【原因：根据收款单ID获取收款方法信用校验方式出错'|| V_NL ||Sqlcode ||sqlerrm ;
         --RAISE V_BASE_EXCEPTION ;
         RETURN ;
       End ;
       --根据信用校验方式获取校验金额以及出错信息结果
       If nvl(V_CREDIT_METHOD,'-1') Not In ('0','1','2','3','4','5','6') Then
          P_RESULT  := -20000 ;
          P_ERR_MSG :=  '收款冲销校验不通过！【原因：根据收款单ID获取收款方法信用校验方式不对，信用校验方式只能为(0,1,2)'  ;
          --RAISE V_BASE_EXCEPTION ;
          RETURN ;
       End If ;
       
       IF IS_RE_VERIFIED_CREDIT = 'N' AND V_REFU_TYPE='N' THEN
           V_CREDIT_METHOD := '0';  --退款不检查 且 不是转款转出的收款方法
       END IF;
       
       IF IS_TU_VERIFIED_CREDIT = 'N' AND V_REFU_TYPE='Y' THEN
           V_CREDIT_METHOD := '0';  --转款不检查 且是  转款转出的收款方法
       END IF;
       

       --V_SALES_AMOUNT := (V_SALES_AMOUNT + VN_DIS_RECEIPT_AMOUNT - VN_DIS_SALES_AMOUNT);
       --V_LOCK_RECEIVED_AMOUNT := (V_LOCK_RECEIVED_AMOUNT - VN_DIS_LOCK_AMOUNT);
       IF IS_DISCOUNT_TYPE = 'COMMON' THEN
         V_CREDIT_MSG := '【折让方式=“常规到款”】';
       ELSIF IS_DISCOUNT_TYPE <> 'COMMON' THEN
         V_CREDIT_MSG := '【折让方式=“折让到款”】';
       ELSE
         V_CREDIT_MSG := '';
       END IF;
       IF V_CREDIT_METHOD IN ('4','5','6') THEN
        IF IS_DISCOUNT_TYPE = 'COMMON' THEN
           SELECT SUM(NVL(T.SETTLE_AMOUNT,0)) INTO V_SALES_AMOUNT_SETTLE FROM V_CREDIT_CONTACT_AMOUNT_FREEZE T
           WHERE T.ENTITY_ID = P_ENTITY_ID
           AND T.ACCOUNT_ID = V_ACCOUNT_ID
           AND T.SRC_TYPE_CODE NOT IN ('1009', '1010')
           AND T.BUSINESS_ID = 'so'
           AND T.SO_STATUS = '12'--已结算
           AND T.SO_SETTLE_DATE IS NOT NULL--结算日期不为空
           AND (T.DISCOUNT_TYPE IS NULL OR T.DISCOUNT_TYPE='COMMON' )
           AND V_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(P_ENTITY_ID,V_CUSTOMER_ID,T.SALES_MAIN_TYPE,V_ACCOUNT_ID)
           ;
        ELSIF IS_DISCOUNT_TYPE <> 'COMMON' THEN
          SELECT SUM(NVL(T.SETTLE_AMOUNT,0)) INTO V_SALES_AMOUNT_SETTLE FROM V_CREDIT_CONTACT_AMOUNT_FREEZE T
           WHERE T.ENTITY_ID = P_ENTITY_ID
           AND T.ACCOUNT_ID = V_ACCOUNT_ID
           AND T.SRC_TYPE_CODE NOT IN ('1009', '1010')
           AND T.BUSINESS_ID = 'so'
           AND T.SO_STATUS = '12'--已结算
           AND T.SO_SETTLE_DATE IS NOT NULL--结算日期不为空
           AND T.DISCOUNT_TYPE='DISCOUNT'
           AND V_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(P_ENTITY_ID,V_CUSTOMER_ID,T.SALES_MAIN_TYPE,V_ACCOUNT_ID)
           ;
        ELSE
          SELECT SUM(NVL(T.SETTLE_AMOUNT,0)) INTO V_SALES_AMOUNT_SETTLE FROM V_CREDIT_CONTACT_AMOUNT_FREEZE T
           WHERE T.ENTITY_ID = P_ENTITY_ID
           AND T.ACCOUNT_ID = V_ACCOUNT_ID
           AND T.SRC_TYPE_CODE NOT IN ('1009', '1010')
           AND T.BUSINESS_ID = 'so'
           AND T.SO_STATUS = '12'--已结算
           AND T.SO_SETTLE_DATE IS NOT NULL--结算日期不为空
           AND V_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(P_ENTITY_ID,V_CUSTOMER_ID,T.SALES_MAIN_TYPE,V_ACCOUNT_ID)
           ;
        END IF;   
           
         V_SALES_AMOUNT_SETTLE := NVL(V_SALES_AMOUNT_SETTLE,0);
       END IF;
       If V_CREDIT_METHOD = '1' OR ('4' = V_CREDIT_METHOD AND V_SALES_AMOUNT < V_SALES_AMOUNT_SETTLE) Then --到款余额-锁定到款金额
          V_CREDIT_AMOUNT := V_RECEIVED_AMOUNT - V_SALES_AMOUNT - (V_LOCK_RECEIVED_AMOUNT - 0.05) + V_CHK_DIS_AMOUNT;
          IF V_CHK_DIS_AMOUNT >= 0 THEN
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG;
          ELSE
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG || '+负折让余额('||(V_DISCONT_SUM-0.05)||')';
          END IF;
       Elsif V_CREDIT_METHOD = '2' OR ('5' = V_CREDIT_METHOD AND V_SALES_AMOUNT < V_SALES_AMOUNT_SETTLE) Then --到款余额 - 锁定到款金额 + 临时铺底金额
          V_CREDIT_AMOUNT := V_RECEIVED_AMOUNT - V_SALES_AMOUNT - (V_LOCK_RECEIVED_AMOUNT - 0.05) + V_TEMP_DELAYPAY_AMOUNT + V_CHK_DIS_AMOUNT;
          IF V_CHK_DIS_AMOUNT >= 0 THEN
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG || '+临时铺底金额('||V_TEMP_DELAYPAY_AMOUNT||')' ;
          ELSE
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG || '+临时铺底金额('||V_TEMP_DELAYPAY_AMOUNT||')' || '+负折让余额('||(V_DISCONT_SUM-0.05)||')' ;
          END IF;
       Elsif V_CREDIT_METHOD = '3' OR ('6' = V_CREDIT_METHOD AND V_SALES_AMOUNT < V_SALES_AMOUNT_SETTLE) Then --到款余额-锁定到款金额+铺底额度金额+临时额度金额
          V_CREDIT_AMOUNT := V_AMOUNT_SUM + V_CHK_DIS_AMOUNT;
          IF V_CHK_DIS_AMOUNT >= 0 THEN
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG ||'+铺底额度金额(' || V_DELAYPAY_AMOUNT || ')' || '+临时铺底金额('||V_TEMP_DELAYPAY_AMOUNT||')' ;
          ELSE
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG ||'+铺底额度金额(' || V_DELAYPAY_AMOUNT || ')' || '+临时铺底金额('||V_TEMP_DELAYPAY_AMOUNT||')' || '+负折让余额('||(V_DISCONT_SUM-0.05)||')';
          END IF;
       ELSIF V_CREDIT_METHOD = '4' Then --到款余额-未结算金额-锁定到款金额
          V_CREDIT_AMOUNT := V_RECEIVED_AMOUNT - V_SALES_AMOUNT - (V_LOCK_RECEIVED_AMOUNT - 0.05) + V_CHK_DIS_AMOUNT;
          IF V_SALES_AMOUNT > V_SALES_AMOUNT_SETTLE THEN
            V_CREDIT_AMOUNT := V_CREDIT_AMOUNT - (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE);
          END IF;
          IF V_CHK_DIS_AMOUNT >= 0 THEN
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-未结算金额(' || (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE) || ')'
            ||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG;
          ELSE
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-未结算金额(' || (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE) || ')'
            ||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG || '+负折让余额('||(V_DISCONT_SUM-0.05)||')';
          END IF;
       Elsif V_CREDIT_METHOD = '5' Then --到款余额-未结算金额 - 锁定到款金额 + 临时铺底金额
          V_CREDIT_AMOUNT := V_RECEIVED_AMOUNT - V_SALES_AMOUNT - (V_LOCK_RECEIVED_AMOUNT - 0.05) + V_TEMP_DELAYPAY_AMOUNT + V_CHK_DIS_AMOUNT;
          IF V_SALES_AMOUNT > V_SALES_AMOUNT_SETTLE THEN
            V_CREDIT_AMOUNT := V_CREDIT_AMOUNT - (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE);
          END IF;
          IF V_CHK_DIS_AMOUNT >= 0 THEN
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-未结算金额(' || (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE) || ')'
            ||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG || '+临时铺底金额('||V_TEMP_DELAYPAY_AMOUNT||')' ;
          ELSE
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-未结算金额(' || (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE) || ')'
            ||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG || '+临时铺底金额('||V_TEMP_DELAYPAY_AMOUNT||')' || '+负折让余额('||(V_DISCONT_SUM-0.05)||')' ;
          END IF;
       Elsif V_CREDIT_METHOD = '6' Then --到款余额-未结算金额-锁定到款金额+铺底额度金额+临时额度金额
          V_CREDIT_AMOUNT := V_AMOUNT_SUM + V_CHK_DIS_AMOUNT;
          IF V_SALES_AMOUNT > V_SALES_AMOUNT_SETTLE THEN
            V_CREDIT_AMOUNT := V_CREDIT_AMOUNT - (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE);
          END IF;
          
          IF V_CHK_DIS_AMOUNT >= 0 THEN
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-未结算金额(' || (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE) || ')'
            ||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG ||'+铺底额度金额(' || V_DELAYPAY_AMOUNT || ')' || '+临时铺底金额('||V_TEMP_DELAYPAY_AMOUNT||')' ;
          ELSE
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-未结算金额(' || (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE) || ')'
            ||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG ||'+铺底额度金额(' || V_DELAYPAY_AMOUNT || ')' || '+临时铺底金额('||V_TEMP_DELAYPAY_AMOUNT||')' || '+负折让余额('||(V_DISCONT_SUM-0.05)||')';
          END IF;
       End If ;

       If P_AMOUNT_CRTL_FLAG = '-1'  --金额控制标识为-1，不用校验直接通过
          Or V_CREDIT_METHOD = '0' Then --信用校验方式为'0',不校验
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
       Elsif P_AMOUNT_CRTL_FLAG = '0' THEN --金额控制
         --IF P_Settlement_SUM <= V_RECEIVED_AMOUNT THEN
         IF P_Settlement_SUM <= V_CREDIT_AMOUNT THEN
             P_RESULT  := V_SEC_RESULT ;
             P_ERR_MSG := V_SUCCESS ;
             --RAISE V_BASE_EXCEPTION ;
             RETURN ;
         ELSE
             P_RESULT  := -20000 ;
             P_ERR_MSG :=  '收款冲销校验不通过！【原因：冲销金额('|| P_Settlement_SUM ||')大于（' || V_CREDIT_MSG || '）'  ;
             --RAISE V_BASE_EXCEPTION ;
             RETURN ;
         END IF ;
       END IF ;
       /*IF P_Settlement_SUM <= (V_RECEIVED_AMOUNT - V_SALES_AMOUNT - V_LOCK_RECEIVED_AMOUNT) THEN
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
       ELSE
           P_RESULT  := -20000 ;
           P_ERR_MSG := (CASE P_ACTION_TYPE WHEN 16 THEN '收款冲销' ELSE '退款单' END) ||
                     '校验不通过，可能是由于收款金额比冲销或者退款金额小，请了解！' ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
       END IF ; */
      --P_ACTION_TYPE = 18 三方承兑冲销
    /*校验规则：1、到款余额 >= P_Settlement_SUM
                2、锁定到款金额 >= P_THREE_NO_PAY_SUM
                3、三方承兑未解付金额 >= P_THREE_NO_PAY_SUM */
     ELSIF P_ACTION_TYPE = 18 THEN

       IF P_AMOUNT_CRTL_FLAG = '0' THEN --金额控制
           --三方承兑单据对应营销大类下的总额
           V_AR_THREE_SUM := PKG_CREDIT_TOOLS.FUN_GET_THREE_AMOUNT(P_ORDER_ID,P_SALES_MAIN_TYPE,1,IS_DISCOUNT_TYPE) ;
           --三方承兑未解付金额（大类下）
           V_AR_NOT_PAY := PKG_CREDIT_TOOLS.FUN_GET_THREE_AMOUNT(P_ORDER_ID,P_SALES_MAIN_TYPE,3,IS_DISCOUNT_TYPE) ;

           IF V_AR_THREE_SUM <> P_Settlement_SUM THEN
              P_RESULT  := -20000 ;
              P_ERR_MSG := '三方承兑冲销校验不通过！'
                    || V_NL || '【原因：三方承兑只能整单冲销，三方承兑大类下总金额(' || V_AR_THREE_SUM || ')不等于冲销金额(' || P_Settlement_SUM || ')！' ;

              RETURN ;
           END IF ;
           IF   P_Settlement_SUM <= (V_RECEIVED_AMOUNT - V_SALES_AMOUNT)
               AND V_AR_NOT_PAY <= V_LOCK_RECEIVED_AMOUNT
               AND V_AR_NOT_PAY <= V_THREE_NOT_PAY THEN
               P_RESULT  := V_SEC_RESULT ;
               P_ERR_MSG := V_SUCCESS ;
               --RAISE V_BASE_EXCEPTION ;
               RETURN ;
           ELSE
               P_RESULT  := -20000 ;
               P_ERR_MSG := '三方承兑冲销校验不通过！'
                    || V_NL || (CASE WHEN P_Settlement_SUM > (V_RECEIVED_AMOUNT - V_SALES_AMOUNT) THEN '【原因：客户到款余额('|| (V_RECEIVED_AMOUNT - V_SALES_AMOUNT) ||')小于三方承兑冲销金额('|| P_Settlement_SUM ||')' END)
                    || V_NL || (CASE WHEN V_AR_NOT_PAY > V_LOCK_RECEIVED_AMOUNT THEN '【原因：客户锁定到款金额('|| V_LOCK_RECEIVED_AMOUNT ||')小于三方承兑冲销金额('|| V_AR_NOT_PAY ||')' END)
                    || V_NL || (CASE WHEN V_AR_NOT_PAY > V_THREE_NOT_PAY THEN '【原因：客户三方承兑未解付金额('|| V_THREE_NOT_PAY ||')小于三方承兑冲销金额('|| V_AR_NOT_PAY ||')' END);
               IF IS_DISCOUNT_TYPE = 'COMMON' THEN
                 P_ERR_MSG := P_ERR_MSG || V_NL || '（当前折让方式：常规到款）';
               ELSIF IS_DISCOUNT_TYPE <> 'COMMON' THEN
                 P_ERR_MSG := P_ERR_MSG || V_NL || '（当前折让方式：折让到款）';
               END IF;
               --RAISE V_BASE_EXCEPTION ;
              RETURN ;
           END IF ;
      Elsif P_AMOUNT_CRTL_FLAG = '-1' THEN --金额控制
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
      Else
          P_RESULT  := -20000 ;
          P_ERR_MSG := '三方承兑冲销校验不通过！该客户款项的金额控制方式异常！'  ;
          Return ;
      End If ;
     --P_ACTION_TYPE = 19 三方承兑解付
    /*校验规则：1、锁定到款金额 >= P_Settlement_SUM
                2、三方承兑未解付金额 >= P_Settlement_SUM
                3、解付单传入的结算金额就是未解付金额，需要解付的金额，
                   所以只需要用锁定金额和三方承兑未解付金额跟结算金额做对比*/
     ELSIF P_ACTION_TYPE = 19 THEN
       IF P_AMOUNT_CRTL_FLAG = '0' THEN --金额控制
         IF P_Settlement_SUM <= V_LOCK_RECEIVED_AMOUNT
             AND P_Settlement_SUM <= V_THREE_NOT_PAY THEN
             P_RESULT  := V_SEC_RESULT ;
             P_ERR_MSG := V_SUCCESS ;
             --RAISE V_BASE_EXCEPTION ;
            RETURN ;
         ELSE
             P_RESULT  := -20000 ;
             P_ERR_MSG := '三方承兑解付校验不通过！'
                   || V_NL || (CASE WHEN P_Settlement_SUM > V_LOCK_RECEIVED_AMOUNT THEN '【原因：客户锁定到款金额('|| V_LOCK_RECEIVED_AMOUNT ||')小于三方承兑解付金额('|| P_Settlement_SUM ||')' END)
                   || V_NL || (CASE WHEN P_Settlement_SUM > V_THREE_NOT_PAY THEN '【原因：客户三方承兑未解付金额('|| V_THREE_NOT_PAY ||')小于三方承兑解付金额('|| P_Settlement_SUM ||')' END);
             IF IS_DISCOUNT_TYPE = 'COMMON' THEN
                 P_ERR_MSG := P_ERR_MSG || V_NL || '（当前折让方式：常规到款）';
               ELSIF IS_DISCOUNT_TYPE <> 'COMMON' THEN
                 P_ERR_MSG := P_ERR_MSG || V_NL || '（当前折让方式：折让到款）';
               END IF;
             --RAISE V_BASE_EXCEPTION ;
            RETURN ;
         END IF ;
      Elsif P_AMOUNT_CRTL_FLAG = '-1' THEN --金额控制
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
      Else
          P_RESULT  := -20000 ;
          P_ERR_MSG := '三方承兑解付校验不通过！该客户款项的金额控制方式异常！'  ;
          Return ;
      End If ;
     --P_ACTION_TYPE = 21 退款单
     /*校验规则：1、到款金额 >= P_Settlement_SUM */
     /*ELSIF P_ACTION_TYPE = 21 THEN
       IF P_AMOUNT_CRTL_FLAG = '0' THEN --金额控制
         --IF P_Settlement_SUM <= V_RECEIVED_AMOUNT THEN
         IF P_Settlement_SUM <= (V_RECEIVED_AMOUNT - V_SALES_AMOUNT - V_LOCK_RECEIVED_AMOUNT) THEN
             P_RESULT  := V_SEC_RESULT ;
             P_ERR_MSG := V_SUCCESS ;
             --RAISE V_BASE_EXCEPTION ;
             RETURN ;
         ELSE
             P_RESULT  := -20000 ;
             P_ERR_MSG :=  '退款单校验不通过！【原因：退款金额('|| P_Settlement_SUM ||')大于（到款余额('|| (V_RECEIVED_AMOUNT - V_SALES_AMOUNT) ||')-客户锁定到款金额('|| V_LOCK_RECEIVED_AMOUNT ||')）' ;
             --RAISE V_BASE_EXCEPTION ;
             RETURN ;
         END IF ;
       ELSIF P_AMOUNT_CRTL_FLAG = '-1' THEN  ----金额控制标识为-1，不用校验直接通过
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
       END IF ;*/


    --P_ACTION_TYPE = 21 退款单
     /* 需求变更：
             1、普通退款业务，例如：退款-现汇、退款-承兑 退款金额 必须小于或等于【到款余款-锁定到款金额】；
             2、以票换票的退款业务：退款-承兑HP 退款金额 必须小于或等于【到款余款-锁定到款+临时铺底额度】
             3、以票换现即贴现的退款业务：退款-现汇TX  必须小于或等于【到款余款-锁定到款+临时铺底额度】；
             4、对于直营电商发生的退款业务：退款-现汇（电商零售）退款金额 必须小于或等于【到款余款-锁定到款+临时铺底额度】；
             5、转款业务：转出金额必须小于或等于【到款余款-锁定到款金额】；
             6、扣销售公司罚款业务：退款-扣货款 不必校验信用。
      *校验规则：根据收款方法配置的信用校验方式字段
        ATTRIBUTE1 = 0 ： 不校验
        ATTRIBUTE1 = 1 ： 到款余款-锁定到款金额
        ATTRIBUTE1 = 2 ： 到款余款-锁定到款+临时铺底额度
        ATTRIBUTE1 = 3 ： 到款余额-锁定到款金额+铺底额度+临时额度
      */
     ELSIF P_ACTION_TYPE = 21 THEN
       --根据单据ID获取收款方法信用校验方式
       Begin
         Select B.ATTRIBUTE1,A.CUSTOMER_ID,A.ACCOUNT_ID,B.TYPE
           Into V_CREDIT_METHOD,V_CUSTOMER_ID,V_ACCOUNT_ID,V_REFU_TYPE
          From T_Ar_Cash_Receipt_Headers a, T_Ar_Receipt_Methods b
         Where A.Receipt_Method_Id = B.Receipt_Method_Id
           And A.CASH_RECEIPT_ID = P_ORDER_ID ;
       Exception When Others Then
         P_RESULT  := -20000 ;
         P_ERR_MSG :=  '退款单校验不通过！【原因：根据收款单ID获取收款方法信用校验方式出错'|| V_NL ||Sqlcode ||sqlerrm ;
         --RAISE V_BASE_EXCEPTION ;
         RETURN ;
       End ;
       --根据信用校验方式获取校验金额以及出错信息结果
       If nvl(V_CREDIT_METHOD,'-1') Not In ('0','1','2','3','4','5','6') Then
          P_RESULT  := -20000 ;
          P_ERR_MSG :=  '退款单校验不通过！【原因：根据收款单ID获取收款方法信用校验方式不对，信用校验方式只能为(0,1,2)'  ;
          --RAISE V_BASE_EXCEPTION ;
          RETURN ;
       End If ;
       
       IF IS_RE_VERIFIED_CREDIT = 'N' AND V_REFU_TYPE='N' THEN
           V_CREDIT_METHOD := '0';  --退款不检查 且 不是转款转出的收款方法
       END IF;
       
       IF IS_TU_VERIFIED_CREDIT = 'N' AND V_REFU_TYPE='Y' THEN
           V_CREDIT_METHOD := '0';  --转款不检查 且是  转款转出的收款方法
       END IF;
       

       --V_SALES_AMOUNT := (V_SALES_AMOUNT + VN_DIS_RECEIPT_AMOUNT - VN_DIS_SALES_AMOUNT);
       --V_LOCK_RECEIVED_AMOUNT := (V_LOCK_RECEIVED_AMOUNT - VN_DIS_LOCK_AMOUNT);
       IF IS_DISCOUNT_TYPE = 'COMMON' THEN
         V_CREDIT_MSG := '【折让方式=“常规到款”】';
       ELSIF IS_DISCOUNT_TYPE <> 'COMMON' THEN
         V_CREDIT_MSG := '【折让方式=“折让到款”】';
       ELSE
         V_CREDIT_MSG := '';
       END IF;
       IF V_CREDIT_METHOD IN ('4','5','6') THEN
        IF IS_DISCOUNT_TYPE = 'COMMON' THEN
           SELECT SUM(NVL(T.SETTLE_AMOUNT,0)) INTO V_SALES_AMOUNT_SETTLE FROM V_CREDIT_CONTACT_AMOUNT_FREEZE T
           WHERE T.ENTITY_ID = P_ENTITY_ID
           AND T.ACCOUNT_ID = V_ACCOUNT_ID
           AND T.SRC_TYPE_CODE NOT IN ('1009', '1010')
           AND T.BUSINESS_ID = 'so'
           AND T.SO_STATUS = '12'--已结算
           AND T.SO_SETTLE_DATE IS NOT NULL--结算日期不为空
           AND (T.DISCOUNT_TYPE IS NULL OR T.DISCOUNT_TYPE='COMMON' )
           AND V_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(P_ENTITY_ID,V_CUSTOMER_ID,T.SALES_MAIN_TYPE,V_ACCOUNT_ID)
           ;
        ELSIF IS_DISCOUNT_TYPE <> 'COMMON' THEN
          SELECT SUM(NVL(T.SETTLE_AMOUNT,0)) INTO V_SALES_AMOUNT_SETTLE FROM V_CREDIT_CONTACT_AMOUNT_FREEZE T
           WHERE T.ENTITY_ID = P_ENTITY_ID
           AND T.ACCOUNT_ID = V_ACCOUNT_ID
           AND T.SRC_TYPE_CODE NOT IN ('1009', '1010')
           AND T.BUSINESS_ID = 'so'
           AND T.SO_STATUS = '12'--已结算
           AND T.SO_SETTLE_DATE IS NOT NULL--结算日期不为空
           AND T.DISCOUNT_TYPE='DISCOUNT'
           AND V_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(P_ENTITY_ID,V_CUSTOMER_ID,T.SALES_MAIN_TYPE,V_ACCOUNT_ID)
           ;
        ELSE
          SELECT SUM(NVL(T.SETTLE_AMOUNT,0)) INTO V_SALES_AMOUNT_SETTLE FROM V_CREDIT_CONTACT_AMOUNT_FREEZE T
           WHERE T.ENTITY_ID = P_ENTITY_ID
           AND T.ACCOUNT_ID = V_ACCOUNT_ID
           AND T.SRC_TYPE_CODE NOT IN ('1009', '1010')
           AND T.BUSINESS_ID = 'so'
           AND T.SO_STATUS = '12'--已结算
           AND T.SO_SETTLE_DATE IS NOT NULL--结算日期不为空
           AND V_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(P_ENTITY_ID,V_CUSTOMER_ID,T.SALES_MAIN_TYPE,V_ACCOUNT_ID)
           ;
        END IF;   
           
         V_SALES_AMOUNT_SETTLE := NVL(V_SALES_AMOUNT_SETTLE,0);
       END IF;
       If V_CREDIT_METHOD = '1' OR ('4' = V_CREDIT_METHOD AND V_SALES_AMOUNT < V_SALES_AMOUNT_SETTLE) Then --到款余额-锁定到款金额
          V_CREDIT_AMOUNT := V_RECEIVED_AMOUNT - V_SALES_AMOUNT - (V_LOCK_RECEIVED_AMOUNT - 0.05) + V_CHK_DIS_AMOUNT;
          IF V_CHK_DIS_AMOUNT >= 0 THEN
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG;
          ELSE
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG || '+负折让余额('||(V_DISCONT_SUM-0.05)||')';
          END IF;
       Elsif V_CREDIT_METHOD = '2' OR ('5' = V_CREDIT_METHOD AND V_SALES_AMOUNT < V_SALES_AMOUNT_SETTLE) Then --到款余额 - 锁定到款金额 + 临时铺底金额
          V_CREDIT_AMOUNT := V_RECEIVED_AMOUNT - V_SALES_AMOUNT - (V_LOCK_RECEIVED_AMOUNT - 0.05) + V_TEMP_DELAYPAY_AMOUNT + V_CHK_DIS_AMOUNT;
          IF V_CHK_DIS_AMOUNT >= 0 THEN
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG || '+临时铺底金额('||V_TEMP_DELAYPAY_AMOUNT||')' ;
          ELSE
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG || '+临时铺底金额('||V_TEMP_DELAYPAY_AMOUNT||')' || '+负折让余额('||(V_DISCONT_SUM-0.05)||')' ;
          END IF;
       Elsif V_CREDIT_METHOD = '3' OR ('6' = V_CREDIT_METHOD AND V_SALES_AMOUNT < V_SALES_AMOUNT_SETTLE) Then --到款余额-锁定到款金额+铺底额度金额+临时额度金额
          V_CREDIT_AMOUNT := V_AMOUNT_SUM + V_CHK_DIS_AMOUNT;
          IF V_CHK_DIS_AMOUNT >= 0 THEN
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG ||'+铺底额度金额(' || V_DELAYPAY_AMOUNT || ')' || '+临时铺底金额('||V_TEMP_DELAYPAY_AMOUNT||')' ;
          ELSE
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG ||'+铺底额度金额(' || V_DELAYPAY_AMOUNT || ')' || '+临时铺底金额('||V_TEMP_DELAYPAY_AMOUNT||')' || '+负折让余额('||(V_DISCONT_SUM-0.05)||')';
          END IF;
       ELSIF V_CREDIT_METHOD = '4' Then --到款余额-未结算金额-锁定到款金额
          V_CREDIT_AMOUNT := V_RECEIVED_AMOUNT - V_SALES_AMOUNT - (V_LOCK_RECEIVED_AMOUNT - 0.05) + V_CHK_DIS_AMOUNT;
          IF V_SALES_AMOUNT > V_SALES_AMOUNT_SETTLE THEN
            V_CREDIT_AMOUNT := V_CREDIT_AMOUNT - (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE);
          END IF;
          IF V_CHK_DIS_AMOUNT >= 0 THEN
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-未结算金额(' || (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE) || ')'
            ||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG;
          ELSE
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-未结算金额(' || (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE) || ')'
            ||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG || '+负折让余额('||(V_DISCONT_SUM-0.05)||')';
          END IF;
       Elsif V_CREDIT_METHOD = '5' Then --到款余额-未结算金额 - 锁定到款金额 + 临时铺底金额
          V_CREDIT_AMOUNT := V_RECEIVED_AMOUNT - V_SALES_AMOUNT - (V_LOCK_RECEIVED_AMOUNT - 0.05) + V_TEMP_DELAYPAY_AMOUNT + V_CHK_DIS_AMOUNT;
          IF V_SALES_AMOUNT > V_SALES_AMOUNT_SETTLE THEN
            V_CREDIT_AMOUNT := V_CREDIT_AMOUNT - (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE);
          END IF;
          IF V_CHK_DIS_AMOUNT >= 0 THEN
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-未结算金额(' || (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE) || ')'
            ||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG || '+临时铺底金额('||V_TEMP_DELAYPAY_AMOUNT||')' ;
          ELSE
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-未结算金额(' || (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE) || ')'
            ||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG || '+临时铺底金额('||V_TEMP_DELAYPAY_AMOUNT||')' || '+负折让余额('||(V_DISCONT_SUM-0.05)||')' ;
          END IF;
       Elsif V_CREDIT_METHOD = '6' Then --到款余额-未结算金额-锁定到款金额+铺底额度金额+临时额度金额
          V_CREDIT_AMOUNT := V_AMOUNT_SUM + V_CHK_DIS_AMOUNT;
          IF V_SALES_AMOUNT > V_SALES_AMOUNT_SETTLE THEN
            V_CREDIT_AMOUNT := V_CREDIT_AMOUNT - (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE);
          END IF;
          
          IF V_CHK_DIS_AMOUNT >= 0 THEN
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-未结算金额(' || (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE) || ')'
            ||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG ||'+铺底额度金额(' || V_DELAYPAY_AMOUNT || ')' || '+临时铺底金额('||V_TEMP_DELAYPAY_AMOUNT||')' ;
          ELSE
            V_CREDIT_MSG := '到款余款('||(V_RECEIVED_AMOUNT - V_SALES_AMOUNT)||'-未结算金额(' || (V_SALES_AMOUNT - V_SALES_AMOUNT_SETTLE) || ')'
            ||'-锁定到款金额(' || (V_LOCK_RECEIVED_AMOUNT - 0.05) || ')'  || V_CREDIT_MSG ||'+铺底额度金额(' || V_DELAYPAY_AMOUNT || ')' || '+临时铺底金额('||V_TEMP_DELAYPAY_AMOUNT||')' || '+负折让余额('||(V_DISCONT_SUM-0.05)||')';
          END IF;
       End If ;

       If P_AMOUNT_CRTL_FLAG = '-1'  --金额控制标识为-1，不用校验直接通过
          Or V_CREDIT_METHOD = '0' Then --信用校验方式为'0',不校验
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
       Elsif P_AMOUNT_CRTL_FLAG = '0' THEN --金额控制
         --IF P_Settlement_SUM <= V_RECEIVED_AMOUNT THEN
         IF P_Settlement_SUM <= V_CREDIT_AMOUNT THEN
             P_RESULT  := V_SEC_RESULT ;
             P_ERR_MSG := V_SUCCESS ;
             --RAISE V_BASE_EXCEPTION ;
             RETURN ;
         ELSE
             P_RESULT  := -20000 ;
             P_ERR_MSG :=  '退款单校验不通过！【原因：退款金额('|| P_Settlement_SUM ||')大于（' || V_CREDIT_MSG || '）'  ;
             --RAISE V_BASE_EXCEPTION ;
             RETURN ;
         END IF ;
       END IF ;
    --P_ACTION_TYPE = 24 铺底审批（冻结折让）
    /*校验规则：1、冻结折让金额 + P_Settlement_SUM >= 0
                2、冻结折让铺底是反方向，申请冻结折让铺底，应该是冻结折让金额会减少，所以结算金额应该是负数*/
     ELSIF P_ACTION_TYPE = 24 THEN
       --
       P_RESULT  := V_SEC_RESULT ;
       P_ERR_MSG := V_SUCCESS ;
       --RAISE V_BASE_EXCEPTION ;
       RETURN ;
       /*IF P_Settlement_SUM + V_FREEZE_DISCOUNT_AMOUNT >= 0  THEN
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           --RAISE V_BASE_EXCEPTION ;
          RETURN ;
       ELSE
           P_RESULT  := -20000 ;
           P_ERR_MSG := '铺底审批（冻结折让）校验不通过！【原因：铺底金额('|| P_Settlement_SUM ||') + 冻结折让金额('|| V_FREEZE_DISCOUNT_AMOUNT ||') < 0' ;
           --RAISE V_BASE_EXCEPTION ;
          RETURN ;
       END IF ; */

    --P_ACTION_TYPE = 25 铺底到期（铺底）
    /*校验规则：1、铺底额度 >= P_Settlement_SUM */
     ELSIF P_ACTION_TYPE = 25 THEN
       IF P_AMOUNT_CRTL_FLAG = '0' THEN --金额控制
           IF P_Settlement_SUM <= V_DELAYPAY_AMOUNT  THEN
               P_RESULT  := V_SEC_RESULT ;
               P_ERR_MSG := V_SUCCESS ;
               --RAISE V_BASE_EXCEPTION ;
              RETURN ;
           ELSE
               P_RESULT  := -20000 ;
               P_ERR_MSG := '铺底到期（铺底）校验不通过！【原因：需要到期的铺底金额('|| P_Settlement_SUM ||')大于客户已经生效的铺底金额('|| V_DELAYPAY_AMOUNT ||')' ;
               --RAISE V_BASE_EXCEPTION ;
              RETURN ;
           END IF ;
       ELSIF P_AMOUNT_CRTL_FLAG = '-1' THEN  ----金额控制标识为-1，不用校验直接通过
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
       End If ;
    --23：铺底审批（临时铺底）
    ELSIF P_ACTION_TYPE = 23 THEN
       
       IF '10' = V_DELAY_TYPE THEN
         --2017-11-10 梁颜明 临时铺底增加冻结保证金
         IF 0 > (V_FREEZE_DELAYPAY_AMOUNT - P_Settlement_SUM) THEN
           P_RESULT  := -20000 ;
           P_ERR_MSG := '铺底审批（临时铺底）校验不通过！【原因：需要审批通过的保证金金额('|| P_Settlement_SUM ||')大于客户已经生效的保证金金额('|| V_FREEZE_DELAYPAY_AMOUNT ||')' ;
         ELSE
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
         END IF;
       ELSE
       P_RESULT  := V_SEC_RESULT ;
       P_ERR_MSG := V_SUCCESS ;
       END IF;
       RETURN ;
     --P_ACTION_TYPE = 26 铺底到期（临时铺底）
    /*校验规则：1、临时铺底额度 >= P_Settlement_SUM */
     ELSIF P_ACTION_TYPE = 26 THEN
       --
       IF '10' = V_DELAY_TYPE THEN
         --2017-11-10 梁颜明 临时铺底增加冻结保证金
         IF 0 > (V_FREEZE_DELAYPAY_AMOUNT + P_Settlement_SUM) THEN
           P_RESULT  := -20000 ;
           P_ERR_MSG := '铺底到期（临时铺底）校验不通过！【原因：需要到期的保证金金额('|| P_Settlement_SUM ||')的绝对值大于客户已经生效的保证金金额('|| V_FREEZE_DELAYPAY_AMOUNT ||')' ;
         ELSE
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
         END IF;
       ELSE
       P_RESULT  := V_SEC_RESULT ;
       P_ERR_MSG := V_SUCCESS ;
       END IF;
       --RAISE V_BASE_EXCEPTION ;
       RETURN ;
       /*IF P_Settlement_SUM <= V_TEMP_DELAYPAY_AMOUNT  THEN
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           --RAISE V_BASE_EXCEPTION ;
          RETURN ;
       ELSE
           P_RESULT  := -20000 ;
           P_ERR_MSG := '铺底到期（临时铺底）校验不通过！【需要到期的铺底金额('|| P_Settlement_SUM ||')大于客户已经生效的铺底金额('|| V_TEMP_DELAYPAY_AMOUNT ||')' ;
           --RAISE V_BASE_EXCEPTION ;
           RETURN ;
       END IF ; */
    END IF ;

  END ; --PRC_CREDIT_VERIFICATION_IMPL

  PROCEDURE 以下为款项变更的过程 is begin null ; end ;

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-28
  *     创建者：苏冬渊
  *   功能说明：处理信用控制中的款项变更,更新客户账户款项
  *
  *   1：订单评审
      2：订单取消
      3：开单（销售单）
      4：开单（销售红冲单）
      5：开单（退货单）
      6：开单（退货红冲单）
      7：开单（折让证明单）
      8：开单（折让证明红冲单）
      9：开单（销售折让单）
      10：开单（销售折让红冲单）
      11：开单（扣率折让单）
      12：开单（扣率折让红冲单）
      13：结算（退货单）
      14：结算（销售单）
      15：收款确认（不包括三方承兑）
      16：收款冲销
      17：三方承兑到款
      18：三方承兑冲销
      19：三方承兑解付
      20：三方承兑解付冲销
      21：退款
      22：铺底审批（铺底）
      23：铺底审批（临时铺底）
      24：铺底审批（冻结折让）
      25：铺底到期（铺底）
      26：铺底到期（临时铺底）
      27：铺底到期（冻结折让）
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_FUND_UPDATE(P_ENTITY_ID          IN NUMBER, --主体ID
                                   P_ACTION_TYPE        IN NUMBER, --动作标示
                                   P_Settlement_SUM     IN NUMBER, --结算金额
                                   P_Discount_SUM       IN NUMBER, --折扣金额
                                   P_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                   P_ACCOUNT_ID         IN NUMBER, --账户ID
                                   P_CUSTOMER_ID        IN NUMBER, --客户ID
                                   P_PROJ_NUMBER        IN VARCHAR2, --项目号
                                   P_CREATED_MODE       IN NUMBER,  --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                                   --P_CREDIT_GROUP_ID    IN NUMBER ,--(直接根据资金校验结果传入，不用重复查询)
                                   P_ORDER_ID           IN NUMBER, --单据ID
                                   P_ORDER_TYPE         IN VARCHAR2, --单据类型
                                   P_USERNAME            IN VARCHAR2 ,
                                   P_RESULT             IN OUT NUMBER, --返回错误ID
                                   P_ERR_MSG            IN OUT VARCHAR2 --返回错误信息
                                   ) IS
      V_UPDATE_TABLE VARCHAR2(4000) ;
      V_UPDATE_COLS   VARCHAR2(4000) ;
      V_UPDATE_WHERE VARCHAR2(4000) ;
      V_UPDATE_TABLE_MX VARCHAR2(4000) ;
      --V_UPDATE_COLS_MX  VARCHAR2(100) ;
      V_UPDATE_WHERE_MX VARCHAR2(4000) ;
      V_SQL     VARCHAR2(4000) ;
      V_SQL_MX  VARCHAR2(4000) ;
      V_CREDIT_GROUP_ID T_CREDIT_GROUP_CUST.Credit_Group_Id%TYPE ;

      TYPE TRANS_TYPE IS RECORD(R_TRANS_ACTION t_sales_amount_trans.Trans_Action%TYPE,
                                R_AMOUNT_NAME  t_sales_amount_trans.Amount_Name%TYPE,
                                R_AMOUNT       t_sales_amount_trans.Amount%TYPE) ;
      TYPE CUR_TRANS_TYPE IS TABLE OF TRANS_TYPE INDEX BY BINARY_INTEGER;
      TRANS_TABLE CUR_TRANS_TYPE ;

      V_ORDER_TYPE VARCHAR2(400) ;
      V_AR_NOT_PAY   T_SALES_ACCOUNT_AMOUNT.THREE_NOT_PAY%TYPE ;
      --铺底类型
      V_DELAY_TYPE   T_CREDIT_DELAYPAY.DELAYPAY_TYPE%TYPE;
  BEGIN
    P_RESULT  := V_SEC_RESULT;
    P_ERR_MSG := V_SUCCESS;

    V_ORDER_TYPE := P_ORDER_TYPE ;
    
    IF P_ACTION_TYPE BETWEEN 22 AND 27 AND '3' = V_ORDER_TYPE THEN
      BEGIN
        SELECT D.DELAYPAY_TYPE INTO V_DELAY_TYPE FROM T_CREDIT_DELAYPAY D WHERE D.BILL_ID = P_ORDER_ID AND D.BILL_TYPE_ID = TO_NUMBER(V_ORDER_TYPE);
      EXCEPTION WHEN OTHERS THEN
        NULL;
      END;
    END IF;

    --3、根据营销大类ID，客户ID，获取额度组 --2017-4-22 获取额度组增加账户ID liangym2
    V_CREDIT_GROUP_ID := pkg_credit_tools.FUN_GET_CREDITGROUPID(P_ENTITY_ID,P_CUSTOMER_ID,P_SALES_MAIN_TYPE, P_ACCOUNT_ID);
    IF V_CREDIT_GROUP_ID = -2 THEN
      P_RESULT := -20002;
      P_ERR_MSG := '该客户已经存在特殊额度组，请到额度组维护模块维护特殊额度组与'|| P_SALES_MAIN_TYPE ||'的关系！' || V_NL || SQLERRM;
      RETURN ;
    ELSIF V_CREDIT_GROUP_ID = -1 THEN
      P_RESULT := -20002;
      P_ERR_MSG := '根据营销大类查询额度组出错，请到额度组管理模块维护！' || V_NL || SQLERRM;
      RETURN ;
    END IF ;

    V_UPDATE_TABLE := 'UPDATE T_SALES_ACCOUNT_AMOUNT T SET ' ;
    V_UPDATE_COLS  := '' ;
    V_UPDATE_WHERE := ' WHERE T.ENTITY_ID = ' || P_ENTITY_ID
                          ||' AND T.CUSTOMER_ID = '|| P_CUSTOMER_ID
                          ||' AND T.ACCOUNT_ID = '|| P_ACCOUNT_ID
                          ||' AND nvl(T.CREDIT_GROUP_ID,-1) = '|| nvl(V_CREDIT_GROUP_ID,-1)
                          ||' AND nvl(T.PROJ_NUMBER,-1) = '||nvl(P_PROJ_NUMBER,-1) ;

    V_UPDATE_TABLE_MX := 'UPDATE T_SALES_ACCOUNT_MX_AMOUNT T SET ' ;
    --V_UPDATE_COLS_MX  := '' ;
    V_UPDATE_WHERE_MX := ' WHERE T.ENTITY_ID = '||P_ENTITY_ID
                             ||' AND T.CUSTOMER_ID = '||P_CUSTOMER_ID
                             ||' AND T.ACCOUNT_ID = '||P_ACCOUNT_ID
                             ||' AND T.SALES_MAIN_TYPE = '''||P_SALES_MAIN_TYPE
                             ||''' AND nvl(T.PROJ_NUMBER,-1) = '||nvl(P_PROJ_NUMBER,-1) ;
    --1、订单评审
    IF P_ACTION_TYPE = 1 OR 28 = P_ACTION_TYPE THEN
       V_UPDATE_COLS := 'T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT + ' || P_Settlement_SUM ||
                       ',T.LOCK_DISCOUNT_AMOUNT = T.LOCK_DISCOUNT_AMOUNT + ' || P_Discount_SUM ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';

       TRANS_TABLE(1).R_TRANS_ACTION := '1' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '锁定到款金额' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;
       TRANS_TABLE(2).R_TRANS_ACTION := '1' ;
       TRANS_TABLE(2).R_AMOUNT_NAME  := '锁定折让金额' ;
       TRANS_TABLE(2).R_AMOUNT       := P_Discount_SUM ;

    --2、订单取消
    ELSIF P_ACTION_TYPE = 2 OR 29 = P_ACTION_TYPE THEN
       V_UPDATE_COLS := 'T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT - ' || P_Settlement_SUM ||
                       ',T.LOCK_DISCOUNT_AMOUNT = T.LOCK_DISCOUNT_AMOUNT - ' || P_Discount_SUM ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';
       TRANS_TABLE(1).R_TRANS_ACTION := '2' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '锁定到款金额' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;
       TRANS_TABLE(2).R_TRANS_ACTION := '2' ;
       TRANS_TABLE(2).R_AMOUNT_NAME  := '锁定折让金额' ;
       TRANS_TABLE(2).R_AMOUNT       := P_Discount_SUM ;
    --3、开单（销售单）
    ELSIF P_ACTION_TYPE = 3 THEN
      BEGIN
        SELECT T.BILL_TYPE_NAME
          INTO V_ORDER_TYPE
          FROM V_SO_BILL_TYPE_EXTEND T
         WHERE T.BILL_TYPE_ID = P_ORDER_TYPE
           And t.ENTITY_ID = P_ENTITY_ID ;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT  := -20002;
          P_ERR_MSG := '根据销售开单单据类型ID获取单据类型名称出错，可能是V_SO_BILL_TYPE_EXTEND视图中没有维护对应的单据类型！' || V_NL ||
                       SQLERRM;
          RETURN;
      END;

      IF P_CREATED_MODE <> 20 AND P_CREATED_MODE <> 30 THEN
         V_UPDATE_COLS := ' T.SALES_AMOUNT = T.SALES_AMOUNT + ' || P_Settlement_SUM ||
                          ',T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT - ' || P_Settlement_SUM ||
                          ',T.APPLIED_DISCOUNT_AMOUNT = T.APPLIED_DISCOUNT_AMOUNT + ' || P_Discount_SUM ||
                          ',T.LOCK_DISCOUNT_AMOUNT = T.LOCK_DISCOUNT_AMOUNT - ' || P_Discount_SUM ||
                         ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                         ''',T.LAST_UPDATE_DATE = SYSDATE ';
         TRANS_TABLE(1).R_TRANS_ACTION := '1' ;
         TRANS_TABLE(1).R_AMOUNT_NAME  := '销售金额' ;
         TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;
         TRANS_TABLE(2).R_TRANS_ACTION := '2' ;
         TRANS_TABLE(2).R_AMOUNT_NAME  := '锁定到款金额' ;
         TRANS_TABLE(2).R_AMOUNT       := P_Settlement_SUM ;
         TRANS_TABLE(3).R_TRANS_ACTION := '1' ;
         TRANS_TABLE(3).R_AMOUNT_NAME  := '核销折让金额' ;
         TRANS_TABLE(3).R_AMOUNT       := P_Discount_SUM ;
         TRANS_TABLE(4).R_TRANS_ACTION := '2' ;
         TRANS_TABLE(4).R_AMOUNT_NAME  := '锁定折让金额' ;
         TRANS_TABLE(4).R_AMOUNT       := P_Discount_SUM ;

         V_ORDER_TYPE := V_ORDER_TYPE || '(销售自动开单)' ;

      ELSIF P_CREATED_MODE = 20 THEN
         V_UPDATE_COLS := ' T.SALES_AMOUNT = T.SALES_AMOUNT + ' || P_Settlement_SUM ||
                          --',T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT - ' || P_Settlement_SUM ||
                          ',T.APPLIED_DISCOUNT_AMOUNT = T.APPLIED_DISCOUNT_AMOUNT + ' || P_Discount_SUM ||
                          --',T.LOCK_DISCOUNT_AMOUNT = T.LOCK_DISCOUNT_AMOUNT - ' || P_Discount_SUM ||
                         ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                         ''',T.LAST_UPDATE_DATE = SYSDATE ';
         TRANS_TABLE(1).R_TRANS_ACTION := '1' ;
         TRANS_TABLE(1).R_AMOUNT_NAME  := '销售金额' ;
         TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;
         TRANS_TABLE(2).R_TRANS_ACTION := '1' ;
         TRANS_TABLE(2).R_AMOUNT_NAME  := '核销折让金额' ;
         TRANS_TABLE(2).R_AMOUNT       := P_Discount_SUM ;

         V_ORDER_TYPE := V_ORDER_TYPE || '(销售手工开单)' ;
      ELSIF P_CREATED_MODE = 30 THEN
         V_UPDATE_COLS := ' T.SALES_AMOUNT = T.SALES_AMOUNT + ' || P_Settlement_SUM ||
                          --',T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT - ' || P_Settlement_SUM ||
                          ',T.APPLIED_DISCOUNT_AMOUNT = T.APPLIED_DISCOUNT_AMOUNT + ' || P_Discount_SUM ||
                          --',T.LOCK_DISCOUNT_AMOUNT = T.LOCK_DISCOUNT_AMOUNT - ' || P_Discount_SUM ||
                         ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                         ''',T.LAST_UPDATE_DATE = SYSDATE ';
         TRANS_TABLE(1).R_TRANS_ACTION := '1' ;
         TRANS_TABLE(1).R_AMOUNT_NAME  := '销售金额' ;
         TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;
         TRANS_TABLE(2).R_TRANS_ACTION := '1' ;
         TRANS_TABLE(2).R_AMOUNT_NAME  := '核销折让金额' ;
         TRANS_TABLE(2).R_AMOUNT       := P_Discount_SUM ;

         V_ORDER_TYPE := V_ORDER_TYPE || '(中转全赔开销售单)' ;
      END IF ;
    --4、开单（销售红冲单）
    --5、开单（退货单）
    --13、结算（退货单）
    ELSIF P_ACTION_TYPE = 4 OR P_ACTION_TYPE = 5 OR P_ACTION_TYPE = 13 THEN
       V_UPDATE_COLS := ' T.SALES_AMOUNT = T.SALES_AMOUNT - ' || P_Settlement_SUM ||
                        ',T.APPLIED_DISCOUNT_AMOUNT = T.APPLIED_DISCOUNT_AMOUNT - ' || P_Discount_SUM ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';

       TRANS_TABLE(1).R_TRANS_ACTION := '2' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '销售金额' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;
       TRANS_TABLE(2).R_TRANS_ACTION := '2' ;
       TRANS_TABLE(2).R_AMOUNT_NAME  := '核销折让金额' ;
       TRANS_TABLE(2).R_AMOUNT       := P_Discount_SUM ;
    --6、开单（退货红冲单）
    --14、结算（销售单）
    ELSIF P_ACTION_TYPE = 6  OR P_ACTION_TYPE = 14 THEN
       V_UPDATE_COLS := ' T.SALES_AMOUNT = T.SALES_AMOUNT + ' || P_Settlement_SUM ||
                        ',T.APPLIED_DISCOUNT_AMOUNT = T.APPLIED_DISCOUNT_AMOUNT + ' || P_Discount_SUM ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';
       TRANS_TABLE(1).R_TRANS_ACTION := '1' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '销售金额' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;
       TRANS_TABLE(2).R_TRANS_ACTION := '1' ;
       TRANS_TABLE(2).R_AMOUNT_NAME  := '核销折让金额' ;
       TRANS_TABLE(2).R_AMOUNT       := P_Discount_SUM ;
    --7、开单（折让证明单）
    --9、开单（销售折让单）
    ELSIF P_ACTION_TYPE = 7 OR P_ACTION_TYPE = 9 THEN
       V_UPDATE_COLS := ' T.SALES_AMOUNT = T.SALES_AMOUNT - ' || P_Settlement_SUM  ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';

       TRANS_TABLE(1).R_TRANS_ACTION := '2' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '销售金额' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;
    --8、开单（折让证明红冲单）
    --10、开单（销售折让红冲单）
    ELSIF P_ACTION_TYPE = 8 OR P_ACTION_TYPE = 10 THEN
       V_UPDATE_COLS := ' T.SALES_AMOUNT = T.SALES_AMOUNT + ' || P_Settlement_SUM  ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';

       TRANS_TABLE(1).R_TRANS_ACTION := '1' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '销售金额' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;

    --11、开单（扣率折让单）：扣率折让单，发生的金额记在结算金额
    ELSIF P_ACTION_TYPE = 11 THEN
       V_UPDATE_COLS := ' T.DISCOUNT_AMOUNT = T.DISCOUNT_AMOUNT + ' || P_Settlement_SUM  ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';

       TRANS_TABLE(1).R_TRANS_ACTION := '1' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '折让金额' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;

    --12、开单（扣率折让红冲单）：扣率折让红冲单，发生的金额记在结算金额
    ELSIF P_ACTION_TYPE = 12 THEN
       V_UPDATE_COLS := ' T.DISCOUNT_AMOUNT = T.DISCOUNT_AMOUNT - ' || P_Settlement_SUM ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';

       TRANS_TABLE(1).R_TRANS_ACTION := '2' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '折让金额' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;

    --15、收款确认（不包括三方承兑）
    ELSIF P_ACTION_TYPE = 15 THEN
       V_UPDATE_COLS := ' T.RECEIVED_AMOUNT = T.RECEIVED_AMOUNT + ' || P_Settlement_SUM ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';

       TRANS_TABLE(1).R_TRANS_ACTION := '1' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '到款金额' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;

    --16、收款冲销
    --21、退款
    ELSIF P_ACTION_TYPE = 16 OR P_ACTION_TYPE = 21 THEN
       V_UPDATE_COLS := ' T.RECEIVED_AMOUNT = T.RECEIVED_AMOUNT - ' || P_Settlement_SUM ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';

       TRANS_TABLE(1).R_TRANS_ACTION := '2' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '到款金额' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;

    --17、三方承兑到款
    ELSIF P_ACTION_TYPE = 17 THEN
       V_UPDATE_COLS := ' T.RECEIVED_AMOUNT = T.RECEIVED_AMOUNT + ' || P_Settlement_SUM ||
                        ',T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT + ' || P_Settlement_SUM ||
                        ',T.THREE_NOT_PAY = T.THREE_NOT_PAY + ' || P_Settlement_SUM ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';

       TRANS_TABLE(1).R_TRANS_ACTION := '1' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '到款金额' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;

       TRANS_TABLE(2).R_TRANS_ACTION := '1' ;
       TRANS_TABLE(2).R_AMOUNT_NAME  := '锁定到款金额' ;
       TRANS_TABLE(2).R_AMOUNT       := P_Settlement_SUM ;

       TRANS_TABLE(3).R_TRANS_ACTION := '1' ;
       TRANS_TABLE(3).R_AMOUNT_NAME  := '三方承兑未解付金额' ;
       TRANS_TABLE(3).R_AMOUNT       := P_Settlement_SUM ;

    --18、三方承兑冲销
    ELSIF P_ACTION_TYPE = 18 THEN

       --三方承兑未解付金额（大类下）
       V_AR_NOT_PAY := PKG_CREDIT_TOOLS.FUN_GET_THREE_AMOUNT(P_ORDER_ID,P_SALES_MAIN_TYPE,3) ;

       V_UPDATE_COLS := ' T.RECEIVED_AMOUNT = T.RECEIVED_AMOUNT - ' || P_Settlement_SUM ||
                        ',T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT - ' || V_AR_NOT_PAY ||
                        ',T.THREE_NOT_PAY = T.THREE_NOT_PAY - ' || V_AR_NOT_PAY ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';
       TRANS_TABLE(1).R_TRANS_ACTION := '2' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '到款金额' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;

       TRANS_TABLE(2).R_TRANS_ACTION := '2' ;
       TRANS_TABLE(2).R_AMOUNT_NAME  := '锁定到款金额' ;
       TRANS_TABLE(2).R_AMOUNT       := V_AR_NOT_PAY ;

       TRANS_TABLE(3).R_TRANS_ACTION := '2' ;
       TRANS_TABLE(3).R_AMOUNT_NAME  := '三方承兑未解付金额' ;
       TRANS_TABLE(3).R_AMOUNT       := V_AR_NOT_PAY ;

    --19、三方承兑解付
    ELSIF P_ACTION_TYPE = 19 THEN
       V_UPDATE_COLS := ' T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT - ' || P_Settlement_SUM ||
                        ',T.THREE_NOT_PAY = T.THREE_NOT_PAY - ' || P_Settlement_SUM ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';
       TRANS_TABLE(1).R_TRANS_ACTION := '2' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '锁定到款金额' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;

       TRANS_TABLE(2).R_TRANS_ACTION := '2' ;
       TRANS_TABLE(2).R_AMOUNT_NAME  := '三方承兑未解付金额' ;
       TRANS_TABLE(2).R_AMOUNT       := P_Settlement_SUM ;
    --20、三方承兑解付冲销
    ELSIF P_ACTION_TYPE = 20 THEN
       V_UPDATE_COLS := ' T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT + ' || P_Settlement_SUM ||
                        ',T.THREE_NOT_PAY = T.THREE_NOT_PAY + ' || P_Settlement_SUM ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';
       TRANS_TABLE(1).R_TRANS_ACTION := '1' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '锁定到款金额' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;

       TRANS_TABLE(2).R_TRANS_ACTION := '1' ;
       TRANS_TABLE(2).R_AMOUNT_NAME  := '三方承兑未解付金额' ;
       TRANS_TABLE(2).R_AMOUNT       := P_Settlement_SUM ;
    --22：铺底审批（铺底）
    ELSIF P_ACTION_TYPE = 22 THEN
       V_UPDATE_COLS := ' T.DELAYPAY_AMOUNT = T.DELAYPAY_AMOUNT + ' || P_Settlement_SUM ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';

       TRANS_TABLE(1).R_TRANS_ACTION := '1' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '铺底额度' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;
    --23：铺底审批（临时铺底）
    ELSIF P_ACTION_TYPE = 23 THEN
       TRANS_TABLE(1).R_TRANS_ACTION := '1' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '临时额度' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;
       
       IF '10' = V_DELAY_TYPE THEN
         --2017-10-11 梁颜明 临时铺底增加冻结保证金
         V_UPDATE_COLS := ' T.TEMP_DELAYPAY_AMOUNT = T.TEMP_DELAYPAY_AMOUNT + ' || P_Settlement_SUM ||
                         ',T.FREEZE_DELAY_AMOUNT = T.FREEZE_DELAY_AMOUNT - ' || P_Settlement_SUM ||
                         ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                         ''',T.LAST_UPDATE_DATE = SYSDATE ';
                         
       TRANS_TABLE(2).R_TRANS_ACTION := '2' ;
       TRANS_TABLE(2).R_AMOUNT_NAME  := '冻结保证金' ;
       TRANS_TABLE(2).R_AMOUNT       := P_Settlement_SUM ;
       
       ELSE
         V_UPDATE_COLS := ' T.TEMP_DELAYPAY_AMOUNT = T.TEMP_DELAYPAY_AMOUNT + ' || P_Settlement_SUM ||
                         ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                         ''',T.LAST_UPDATE_DATE = SYSDATE ';
       END IF;

    --24：铺底审批（冻结折让）：P_Settlement_SUM > 0
    ELSIF P_ACTION_TYPE = 24 THEN
       V_UPDATE_COLS := ' T.FREEZE_DISCOUNT_AMOUNT = T.FREEZE_DISCOUNT_AMOUNT - ' || P_Settlement_SUM ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';

       TRANS_TABLE(1).R_TRANS_ACTION := '1' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '冻结折让金额' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;

    --25：铺底到期（铺底）
    ELSIF P_ACTION_TYPE = 25 THEN
       V_UPDATE_COLS := ' T.DELAYPAY_AMOUNT = T.DELAYPAY_AMOUNT - ' || P_Settlement_SUM ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';

       TRANS_TABLE(1).R_TRANS_ACTION := '2' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '铺底额度' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;

    --26：铺底到期（临时铺底）
    ELSIF P_ACTION_TYPE = 26 THEN

       TRANS_TABLE(1).R_TRANS_ACTION := '2' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '临时额度' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;
       
       IF '10' = V_DELAY_TYPE THEN
         --2017-10-11 梁颜明 临时铺底增加冻结保证金
         V_UPDATE_COLS := ' T.TEMP_DELAYPAY_AMOUNT = T.TEMP_DELAYPAY_AMOUNT - ' || P_Settlement_SUM ||
                         ',T.FREEZE_DELAY_AMOUNT = T.FREEZE_DELAY_AMOUNT + ' || P_Settlement_SUM ||
                         ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                         ''',T.LAST_UPDATE_DATE = SYSDATE ';

       TRANS_TABLE(2).R_TRANS_ACTION := '1' ;
       TRANS_TABLE(2).R_AMOUNT_NAME  := '冻结保证金' ;
       TRANS_TABLE(2).R_AMOUNT       := P_Settlement_SUM ;
       
       ELSE
         V_UPDATE_COLS := ' T.TEMP_DELAYPAY_AMOUNT = T.TEMP_DELAYPAY_AMOUNT - ' || P_Settlement_SUM ||
                         ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                         ''',T.LAST_UPDATE_DATE = SYSDATE ';
       END IF;

    --27：铺底到期（冻结折让）：P_Settlement_SUM > 0
    ELSIF P_ACTION_TYPE = 27 THEN
       V_UPDATE_COLS := ' T.FREEZE_DISCOUNT_AMOUNT = T.FREEZE_DISCOUNT_AMOUNT + ' || P_Settlement_SUM ||
                       ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                       ''',T.LAST_UPDATE_DATE = SYSDATE ';

       TRANS_TABLE(1).R_TRANS_ACTION := '2' ;
       TRANS_TABLE(1).R_AMOUNT_NAME  := '冻结折让金额' ;
       TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;

    END IF ;

       V_UPDATE_COLS := V_UPDATE_COLS || ',T.PRE_FIELD_01 = ''1''';
       V_SQL := V_UPDATE_TABLE || V_UPDATE_COLS || V_UPDATE_WHERE ;
    V_SQL_MX := V_UPDATE_TABLE_MX || V_UPDATE_COLS || V_UPDATE_WHERE_MX ;

    --执行款项更新操作
    BEGIN
      EXECUTE IMMEDIATE V_SQL ;
      EXECUTE IMMEDIATE V_SQL_MX ;
      --记录款项变更历史
      FOR I IN 1 .. TRANS_TABLE.COUNT LOOP
        INSERT INTO t_sales_amount_trans
            ( trans_id,   --事务ID
              entity_id,   --主体ID
              sales_year_id,   --销售年度ID
              customer_id,   --客户ID
              account_id,   --账户ID
              credit_group_id, --额度组ID
              proj_number,   --项目号
              sales_main_type,   --营销大类ID
              order_id,   --单据ID
              order_type,   --单据类型
              action_flag,   --动作标识
              trans_action,   --事务动作（1：增加；2：减少；3：变更）
              amount_name,   --款项名称
              amount,   --金额
              due_flag,   --处理标识（1：成功；2：失败）
              created_by,   --创建人
              creation_date,   --创建日期
              last_updated_by,   --最后修改人
              last_update_date,   --最后修改日期
              pre_field_01,
              pre_field_02,
              pre_field_03,
              pre_field_04,
              pre_field_05,
              pre_field_06 )
       VALUES
            ( S_sales_amount_trans.Nextval ,   --事务ID
              P_ENTITY_ID,   --主体ID
              NULL ,   --销售年度ID
              P_CUSTOMER_ID,   --客户ID
              P_ACCOUNT_ID,   --账户ID
              V_CREDIT_GROUP_ID,   --额度组ID
              P_PROJ_NUMBER,   --项目号
              P_SALES_MAIN_TYPE,   --营销大类
              P_ORDER_ID,   --单据ID
              V_ORDER_TYPE,   --单据类型
              P_ACTION_TYPE,  --动作标识
              TRANS_TABLE(I).R_TRANS_ACTION,   --事务动作（1：增加；2：减少；3：变更）
              TRANS_TABLE(I).R_AMOUNT_NAME,   --款项名称
              TRANS_TABLE(I).R_AMOUNT,   --金额
              '1' ,   --处理标识（1：成功；2：失败）
              P_USERNAME,   --创建人
              SYSDATE ,   --创建日期
              P_USERNAME,   --最后修改人
              SYSDATE,   --最后修改日期
              NULL ,
              NULL,
              NULL,
              NULL,
              NULL,
              NULL
               );
      END LOOP ;
    EXCEPTION WHEN OTHERS THEN
      P_RESULT  := -20000 ;
      P_ERR_MSG := '执行更新款项信息操作失败，请了解！'|| V_NL || SQLERRM;
      --ROLLBACK ;
      --RAISE V_BASE_EXCEPTION ;
      RETURN ;
    END ;
  END; --PRC_CREDIT_FUND_UPDATE

  PROCEDURE 以下为款项重算的过程 is begin null ; end ;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-13
  *     创建者：苏冬渊
  *   功能说明：客户锁款金额重算，根据发货通知单行ID，获取已经生成销售单的数量
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_ITEM_QTY(P_Ship_Doc_Line_Id Number) RETURN NUMBER IS
    V_COUNT NUMBER ;
  BEGIN
    Select Sum(T.Item_Qty)
      Into V_Count
      From V_So_Lg_Shipdoc t
     Where T.Ship_Doc_Line_Id = P_Ship_Doc_Line_Id;
    RETURN V_Count ;
  EXCEPTION WHEN OTHERS THEN
    RETURN 0 ;
  END ;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-10-12
  *     创建者：苏冬渊
  *   功能说明：客户锁款金额重算，凌晨时点跑，冻结的是前一天的客户款项
                冻结时点不一定是0点，可能是2点，那么0点到2点之间是会有业务进行的。
                这时候使用客户账户的金额来进行冻结的话，那么冻结金额就有偏差。跟ERP等的金额就会有误差
            本函数是用来计算这部分金额的
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_THIS_AMOUNT(P_ENTITY_ID       T_SALES_ACCOUNT_MX_AMOUNT.Entity_Id%Type,
                               P_CUSTOMER_ID     T_SALES_ACCOUNT_MX_AMOUNT.CUSTOMER_ID%Type,
                               P_ACCOUNT_ID      T_SALES_ACCOUNT_MX_AMOUNT.ACCOUNT_ID%Type,
                               P_SALES_MAIN_TYPE T_SALES_ACCOUNT_MX_AMOUNT.SALES_MAIN_TYPE%Type,
                               P_AMOUNT          T_SALES_ACCOUNT_MX_AMOUNT.RECEIVED_AMOUNT%Type,
                               P_FLAG Varchar2) RETURN NUMBER IS
    V_SUM NUMBER ;
  Begin
    --到款金额
    If P_FLAG = 'RECEIVED_AMOUNT' Then

      Begin
       Select nvl(Sum(decode(t.trans_action,'1',1,'2',-1,0) * t.amount),0)
         Into V_SUM
         From cims.t_sales_amount_trans t
        Where t.entity_id = P_ENTITY_ID
          And t.customer_id = P_CUSTOMER_ID
          And t.account_id = P_ACCOUNT_ID
          And t.sales_main_type = P_SALES_MAIN_TYPE
          And t.amount_name = '到款金额'
          And Trunc(t.creation_date) = Trunc(Sysdate) ;
      Exception When Others Then
        V_SUM := 0 ;
      End ;

    --销售金额
    Elsif P_FLAG = 'SALES_AMOUNT' Then

      Begin
       Select nvl(Sum(decode(t.trans_action,'1',1,'2',-1,0) * t.amount),0)
         Into V_SUM
         From cims.t_sales_amount_trans t
        Where t.entity_id = P_ENTITY_ID
          And t.customer_id = P_CUSTOMER_ID
          And t.account_id = P_ACCOUNT_ID
          And t.sales_main_type = P_SALES_MAIN_TYPE
          And t.amount_name = '销售金额'
          And Trunc(t.creation_date) = Trunc(Sysdate) ;
      Exception When Others Then
        V_SUM := 0 ;
      End ;
    --锁定到款金额
    Elsif P_FLAG = 'LOCK_RECEIVED_AMOUNT' Then

      Begin
       Select nvl(Sum(decode(t.trans_action,'1',1,'2',-1,0) * t.amount),0)
         Into V_SUM
         From cims.t_sales_amount_trans t
        Where t.entity_id = P_ENTITY_ID
          And t.customer_id = P_CUSTOMER_ID
          And t.account_id = P_ACCOUNT_ID
          And t.sales_main_type = P_SALES_MAIN_TYPE
          And t.amount_name in ('锁定到款金额','锁定到款金额(订金)')
          And Trunc(t.creation_date) = Trunc(Sysdate) ;
      Exception When Others Then
        V_SUM := 0 ;
      End ;
    --锁定折让金额
    Elsif P_FLAG = 'LOCK_DISCOUNT_AMOUNT' Then

      Begin
       Select nvl(Sum(decode(t.trans_action,'1',1,'2',-1,0) * t.amount),0)
         Into V_SUM
         From cims.t_sales_amount_trans t
        Where t.entity_id = P_ENTITY_ID
          And t.customer_id = P_CUSTOMER_ID
          And t.account_id = P_ACCOUNT_ID
          And t.sales_main_type = P_SALES_MAIN_TYPE
          And t.amount_name = '锁定折让金额'
          And Trunc(t.creation_date) = Trunc(Sysdate) ;
      Exception When Others Then
        V_SUM := 0 ;
      End ;
    --折让金额
    Elsif P_FLAG = 'DISCOUNT_AMOUNT' Then

      Begin
       Select nvl(Sum(decode(t.trans_action,'1',1,'2',-1,0) * t.amount),0)
         Into V_SUM
         From cims.t_sales_amount_trans t
        Where t.entity_id = P_ENTITY_ID
          And t.customer_id = P_CUSTOMER_ID
          And t.account_id = P_ACCOUNT_ID
          And t.sales_main_type = P_SALES_MAIN_TYPE
          And t.amount_name = '折让金额'
          And Trunc(t.creation_date) = Trunc(Sysdate) ;
      Exception When Others Then
        V_SUM := 0 ;
      End ;
    --核销折让金额
    Elsif P_FLAG = 'APPLIED_DISCOUNT_AMOUNT' Then

      Begin
       Select nvl(Sum(decode(t.trans_action,'1',1,'2',-1,0) * t.amount),0)
         Into V_SUM
         From cims.t_sales_amount_trans t
        Where t.entity_id = P_ENTITY_ID
          And t.customer_id = P_CUSTOMER_ID
          And t.account_id = P_ACCOUNT_ID
          And t.sales_main_type = P_SALES_MAIN_TYPE
          And t.amount_name = '核销折让金额'
          And Trunc(t.creation_date) = Trunc(Sysdate) ;
      Exception When Others Then
        V_SUM := 0 ;
      End ;
    End If ;

    --用当前账户中的金额，减去冻结日期之后产生的金额，就是正确的冻结金额
    V_SUM := P_AMOUNT - V_SUM ;
    RETURN V_SUM ;
  END ;
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-29
  *     创建者：苏冬渊
  *   功能说明：处理信用模块中的款项重算，重算的来源包括销售单、订单、铺底、收款
  *   v_credit_contact_amount 客户往来视图
      v_credit_contact_amount_ar 客户往来视图之收款视图
      v_credit_contact_amount_delay 客户往来视图之铺底视图
  *   v_credit_contact_amount_order 客户往来视图之订单视图
  *   v_credit_contact_amount_so 客户往来视图之销售视图
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_FUND_RERUN
  (
    IN_ENTITY_ID   IN  NUMBER,    --主体ID
    IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
    IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
    IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
    IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
    IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
    IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
   -- P_ERR_MSG OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  )
  IS
    P_RESULT  NUMBER ;
    P_ERR_MSG VARCHAR2(4000);
  BEGIN
    P_RESULT  := V_SEC_RESULT;
    P_ERR_MSG := V_SUCCESS;  
  
    IF 1 = INSTR(IS_PRE_ARG,'PRC_LG_SHIP_DOCL_RERUN,') AND LENGTH(IS_PRE_ARG) > LENGTH('PRC_LG_SHIP_DOCL_RERUN,') THEN
      PRC_LG_SHIP_DOCL_RERUN(IN_ENTITY_ID,IN_CUSTOMER_ID,IN_ACCOUNT_ID
      ,SUBSTR(IS_PRE_ARG,1 + LENGTH('PRC_LG_SHIP_DOCL_RERUN,')),IS_USER_CODE,IS_REASON,IS_PRE_ARG,IS_FREEZE_DATE);-- ADD BY LIANGYM2 2017-8-25
    END IF;
    
    IF 10 = IN_ENTITY_ID AND IS_PRE_ARG = 'JYRERUN'-- AND 0 = INSTR(IS_PRE_ARG,'PRC_LG_SHIP_DOCL_RERUN') AND 'NO' <> IS_PRE_ARG
       AND SYSDATE < TO_DATE('20170903','YYYYMMDD') THEN
      PRC_LG_SHIP_DOCL_RERUN(IN_ENTITY_ID,IN_CUSTOMER_ID,IN_ACCOUNT_ID
      ,'010000015',IS_USER_CODE,IS_REASON,IS_PRE_ARG,IS_FREEZE_DATE);-- ADD BY LIANGYM2 2017-8-25
    END IF;
      
    P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PRC_CREDIT_FUND_RERUN'
    ,'SUCCESS',SUBSTR('款项明细重新开始，主体ID=' ||IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
     || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE,1,240));
    -- 对客户账户额度的订金配置、订单已使用提货金额进行重算
    BEGIN
       PKG_CREDIT_DOWN_PAY.PRC_CREDIT_ACC_LIMIT_RERUN(IN_ENTITY_ID,SYSDATE,'PRC_CREDIT_FUND_RERUN',P_ERR_MSG,IN_CUSTOMER_ID,IN_ACCOUNT_ID);
       IF P_ERR_MSG <> 'SUCCESS' THEN
        P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_DOWN_PAY.PRC_CREDIT_ACC_LIMIT_RERUN','RETURN_FAIL'
        ,SUBSTR('根据主体ID=' ||IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
     || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE || '，对客户账户额度重算不成功：' || P_ERR_MSG,1,240));
       END IF;
    EXCEPTION WHEN OTHERS THEN
      P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_DOWN_PAY.PRC_CREDIT_ACC_LIMIT_RERUN',SQLCODE
      ,SUBSTR('根据主体ID=' ||IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
     || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE || '，对客户账户额度重算异常：' || SQLERRM,1,240) || SQLERRM);
    END;
    
     --款项初始化
    PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_FUND_INIT(IN_ENTITY_ID,IN_CUSTOMER_ID,IN_ACCOUNT_ID,IS_USER_CODE,IS_REASON,IS_PRE_ARG,IS_FREEZE_DATE);
    
    --往来冻结
    PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_FUND_CONTACT(IN_ENTITY_ID,IN_CUSTOMER_ID,IN_ACCOUNT_ID,IS_USER_CODE,IS_REASON,IS_PRE_ARG,IS_FREEZE_DATE);
 
    --明细重算
    PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_FUND_MX_RETURN(IN_ENTITY_ID,1,0,IN_CUSTOMER_ID,IN_ACCOUNT_ID,IS_USER_CODE,IS_REASON,IS_PRE_ARG,IS_FREEZE_DATE);
     
     --款项冻结
     PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_FUND_FREEZE(IN_ENTITY_ID,IN_CUSTOMER_ID,IN_ACCOUNT_ID,IS_USER_CODE,IS_REASON,IS_PRE_ARG,IS_FREEZE_DATE);

        --折让重算
     PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_FUND_DIS_RETURN(IN_ENTITY_ID,IN_CUSTOMER_ID,IN_ACCOUNT_ID,IS_USER_CODE,IS_REASON,IS_PRE_ARG,IS_FREEZE_DATE); 

  EXCEPTION WHEN OTHERS THEN
      P_ERR_MSG := '方法执行体异常！'|| SQLERRM;
      P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PRC_CREDIT_FUND_RERUN'
      ,'款项明细重算异常',SUBSTR(P_ERR_MSG || ',主体ID=' ||IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
     || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE,1,240));
  END; --PRC_CREDIT_FUND_RERUN
  
                               
  --款项初始化
  PROCEDURE PRC_CREDIT_FUND_INIT(
      IN_ENTITY_ID   IN  NUMBER,    --主体ID
      IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
      IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
      IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
      IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
      IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
      IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
   -- P_ERR_MSG OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  ) IS
    P_RESULT  NUMBER ;
    P_ERR_MSG VARCHAR2(4000);
    V_CNT    NUMBER;
  BEGIN
      P_RESULT  := V_SEC_RESULT;
      P_ERR_MSG := V_SUCCESS;
      
      SELECT COUNT(0) INTO V_CNT
      FROM UP_CODELIST C,UP_CODELIST_ENTITY CE
      WHERE CE.CODELIST_ID = C.ID
      AND CE.ENTITY_ID = IN_ENTITY_ID
      AND NVL(CE.ENABLED,'0')='0'
      AND C.CODETYPE = 'temp_all_free'--临时自由码表
      AND C.CODE_VALUE = '信用重算改动风险开关'
      AND C.CODE_NAME = '信用重算改动风险开关'
      AND C.ENTITY_FLAG = 'Y'
      AND C.ENABLED = '0';
      
      FOR LI IN (SELECT AA.*,CS.SALES_MAIN_TYPE_CODE 
          FROM T_SALES_ACCOUNT_AMOUNT AA
          INNER JOIN T_CREDIT_CUSTOMER CS ON (AA.ENTITY_ID = CS.ENTITY_ID
          AND AA.CUSTOMER_ID = CS.CUSTOMER_ID
          AND (CS.ACCOUNT_ID = AA.ACCOUNT_ID OR (CS.ACCOUNT_ID IS NULL OR 0 >= CS.ACCOUNT_ID))
          AND AA.CREDIT_GROUP_ID =
             PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(CS.ENTITY_ID,CS.CUSTOMER_ID,CS.SALES_MAIN_TYPE_CODE,AA.ACCOUNT_ID)
          )
          Where
            AA.ENTITY_ID = IN_ENTITY_ID
            
            AND (IN_CUSTOMER_ID IS NULL OR IN_CUSTOMER_ID = AA.CUSTOMER_ID)
            AND (IN_ACCOUNT_ID  IS NULL OR IN_ACCOUNT_ID = AA.ACCOUNT_ID)
            
            AND AA.ACTIVE_FLAG = '1'
            AND NOT EXISTS (
                SELECT 1 FROM T_SALES_ACCOUNT_MX_AMOUNT T
                  WHERE T.ENTITY_ID = CS.ENTITY_ID
                    AND T.CUSTOMER_ID = CS.CUSTOMER_ID
                    AND T.ACCOUNT_ID = AA.ACCOUNT_ID
                    AND T.SALES_MAIN_TYPE = CS.SALES_MAIN_TYPE_CODE
            )) LOOP
            BEGIN
              PRC_CREDIT_AMOUNT_CONTORL_INIT(LI.ENTITY_ID,LI.CUSTOMER_ID,LI.ACCOUNT_ID,LI.PROJ_NUMBER
                  ,LI.SALES_MAIN_TYPE_CODE,'信用重算',V_CNT,P_ERR_MSG);
            EXCEPTION WHEN OTHERS THEN
              NULL;
            END;
     END LOOP;
  EXCEPTION WHEN OTHERS THEN
      P_ERR_MSG := '方法执行体异常！'|| SQLERRM;
      P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PRC_CREDIT_FUND_RERUN'
      ,'款项初始化异常',SUBSTR(P_ERR_MSG || ',主体ID=' ||IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
     || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE,1,240));
  END PRC_CREDIT_FUND_INIT;  
  
  
  --客户往来冻结
 PROCEDURE PRC_CREDIT_FUND_CONTACT(
      IN_ENTITY_ID   IN  NUMBER,    --主体ID
      IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
      IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
      IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
      IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
      IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
      IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
   -- P_ERR_MSG OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  ) IS
    P_RESULT  NUMBER ;
    P_ERR_MSG VARCHAR2(4000);
    V_PARAM_FREEZE_DATE DATE; 
  BEGIN
      P_RESULT  := V_SEC_RESULT;
      P_ERR_MSG := V_SUCCESS;
      
      IF IS_FREEZE_DATE IS NULL THEN
          V_PARAM_FREEZE_DATE := Trunc(Sysdate);
      ELSE
          V_PARAM_FREEZE_DATE := to_date(IS_FREEZE_DATE,'yyyy-mm-dd')+1;
      END IF;
      
   IF IN_CUSTOMER_ID IS NULL AND IN_ACCOUNT_ID IS NULL THEN
      DELETE FROM T_CREDIT_CONTACT_AMOUNT_FREEZE T
      WHERE T.ENTITY_ID = IN_ENTITY_ID;
      
      INSERT INTO T_CREDIT_CONTACT_AMOUNT_FREEZE
          (ENTITY_ID,
           CUSTOMER_ID,
           ACCOUNT_ID,
           SALES_MAIN_TYPE,
           SALES_AMOUNT,
           SALES_AMOUNT_FREEZE,
           DISCOUNT_AMOUNT,
           DISCOUNT_AMOUNT_FREEZE,
           RECEIVED_AMOUNT_FREEZE
           )
          SELECT T.ENTITY_ID,
                 T.CUSTOMER_ID,
                 T.ACCOUNT_ID,
                 T.SALES_MAIN_TYPE,
                 --销售明细表中，扣率折让单和扣率折让红冲单不对销售金额产生影响
                 NVL(SUM(CASE
                           WHEN T.BUSINESS_ID = 'so' AND
                               --T.BILL_TYPE_ID NOT IN (76, 77) THEN
                               --T.BILL_TYPE_CODE NOT IN (/*1024,1025,1026,1027,*/1028,1029) THEN
                                t.src_type_code Not In ('1009', '1010') Then
                            NVL(T.SETTLE_AMOUNT, 0)
                           ELSE
                            0
                         END),
                     0) V_SALES_AMOUNT, --销售金额
                 
                 NVL(SUM(CASE
                           WHEN T.BUSINESS_ID = 'so' AND T.CREATION_DATE < V_PARAM_FREEZE_DATE AND
                                t.src_type_code Not In ('1009', '1010') Then
                            NVL(T.SETTLE_AMOUNT, 0)
                           ELSE
                            0
                         END),
                     0) V_SALES_AMOUNT_FREEZE, --销售金额  冻结金额
                 NVL(SUM(CASE T.BUSINESS_ID
                               WHEN 'so' THEN
                                 --(CASE WHEN T.BILL_TYPE_CODE IN (1028,1029) THEN NVL(T.DISCOUNT_AMOUNT,0) ELSE 0 END)
                                 (CASE WHEN T.src_type_code IN ('1009','1010') THEN NVL(T.DISCOUNT_AMOUNT,0) ELSE 0 END)
                               ELSE 0 END),0) V_DISCOUNT_AMOUNT,
                 NVL(SUM(CASE T.BUSINESS_ID
                           WHEN 'so' THEN
                           --(CASE WHEN T.BILL_TYPE_CODE IN (1020,1021,1022,1023,1031,1032) THEN NVL(T.DISCOUNT_AMOUNT,0) ELSE 0 END)
                            (CASE
                              WHEN T.src_type_code IN ('1001', '1002', '1003', '1004') THEN
                               NVL(T.DISCOUNT_AMOUNT, 0)
                              ELSE
                               0
                            END)
                           ELSE
                            0
                         END),
                     0) V_APPLIED_DISCOUNT_AMOUNT, --核销扣率折让金额
                     NVL(SUM(CASE
                           WHEN T.BUSINESS_ID = 'ar' AND T.CREATION_DATE < V_PARAM_FREEZE_DATE   Then
                            NVL(T.SETTLE_AMOUNT, 0)
                           ELSE
                            0
                         END),
                     0) V_RECEIVED_AMOUNT_FREEZE --到款金额  冻结金额     
            FROM V_CREDIT_TRANSACTION_SUMMARY T
           WHERE T.ENTITY_ID = IN_ENTITY_ID
             AND T.SETTLE_FLAG = 'Y'
           GROUP BY T.ENTITY_ID, T.CUSTOMER_ID, T.ACCOUNT_ID, T.SALES_MAIN_TYPE;
           
     ELSE
           DELETE FROM T_CREDIT_CONTACT_AMOUNT_FREEZE T
              WHERE T.ENTITY_ID = IN_ENTITY_ID
               AND (IN_CUSTOMER_ID IS NULL OR IN_CUSTOMER_ID = T.CUSTOMER_ID)
               AND (IN_ACCOUNT_ID  IS NULL OR IN_ACCOUNT_ID = T.ACCOUNT_ID);
                
           INSERT INTO T_CREDIT_CONTACT_AMOUNT_FREEZE
              (ENTITY_ID,
               CUSTOMER_ID,
               ACCOUNT_ID,
               SALES_MAIN_TYPE,
               SALES_AMOUNT,
               SALES_AMOUNT_FREEZE,
               DISCOUNT_AMOUNT,
               DISCOUNT_AMOUNT_FREEZE,
               RECEIVED_AMOUNT_FREEZE
               )
              SELECT T.ENTITY_ID,
                     T.CUSTOMER_ID,
                     T.ACCOUNT_ID,
                     T.SALES_MAIN_TYPE,
                     --销售明细表中，扣率折让单和扣率折让红冲单不对销售金额产生影响
                     NVL(SUM(CASE
                               WHEN T.BUSINESS_ID = 'so' AND
                                   --T.BILL_TYPE_ID NOT IN (76, 77) THEN
                                   --T.BILL_TYPE_CODE NOT IN (/*1024,1025,1026,1027,*/1028,1029) THEN
                                    t.src_type_code Not In ('1009', '1010') Then
                                NVL(T.SETTLE_AMOUNT, 0)
                               ELSE
                                0
                             END),
                         0) V_SALES_AMOUNT, --销售金额
                     
                     NVL(SUM(CASE
                               WHEN T.BUSINESS_ID = 'so' AND T.CREATION_DATE < V_PARAM_FREEZE_DATE AND
                                    t.src_type_code Not In ('1009', '1010') Then
                                NVL(T.SETTLE_AMOUNT, 0)
                               ELSE
                                0
                             END),
                         0) V_SALES_AMOUNT_FREEZE, --销售金额  冻结金额
                     NVL(SUM(CASE T.BUSINESS_ID
                                   WHEN 'so' THEN
                                     --(CASE WHEN T.BILL_TYPE_CODE IN (1028,1029) THEN NVL(T.DISCOUNT_AMOUNT,0) ELSE 0 END)
                                     (CASE WHEN T.src_type_code IN ('1009','1010') THEN NVL(T.DISCOUNT_AMOUNT,0) ELSE 0 END)
                                   ELSE 0 END),0) V_DISCOUNT_AMOUNT,
                     NVL(SUM(CASE T.BUSINESS_ID
                               WHEN 'so' THEN
                               --(CASE WHEN T.BILL_TYPE_CODE IN (1020,1021,1022,1023,1031,1032) THEN NVL(T.DISCOUNT_AMOUNT,0) ELSE 0 END)
                                (CASE
                                  WHEN T.src_type_code IN ('1001', '1002', '1003', '1004') THEN
                                   NVL(T.DISCOUNT_AMOUNT, 0)
                                  ELSE
                                   0
                                END)
                               ELSE
                                0
                             END),
                         0) V_APPLIED_DISCOUNT_AMOUNT, --核销扣率折让金额
                    NVL(SUM(CASE
                           WHEN T.BUSINESS_ID = 'ar' AND T.CREATION_DATE < V_PARAM_FREEZE_DATE  Then
                            NVL(T.SETTLE_AMOUNT, 0)
                           ELSE
                            0
                         END),
                     0) V_RECEIVED_AMOUNT_FREEZE --到款金额  冻结金额            
               FROM V_CREDIT_TRANSACTION_SUMMARY T
               WHERE T.ENTITY_ID = IN_ENTITY_ID
                 AND (IN_CUSTOMER_ID IS NULL OR IN_CUSTOMER_ID = T.CUSTOMER_ID)
                 AND (IN_ACCOUNT_ID IS NULL OR IN_ACCOUNT_ID = T.ACCOUNT_ID)
                 AND T.SETTLE_FLAG = 'Y'
               GROUP BY T.ENTITY_ID, T.CUSTOMER_ID, T.ACCOUNT_ID, T.SALES_MAIN_TYPE;
      END IF;
   EXCEPTION WHEN OTHERS THEN
        P_ERR_MSG := '方法执行体异常！'|| SQLERRM;
        P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PRC_CREDIT_FUND_RERUN'
        ,'往来冻结异常',SUBSTR(P_ERR_MSG || ',主体ID=' ||IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
       || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE,1,240));
  END PRC_CREDIT_FUND_CONTACT;  
  
   --销售 到款明细重算
  PROCEDURE PRC_CREDIT_FUND_SA_RETURN(
      IN_ENTITY_ID   IN  NUMBER,    --主体ID
      IN_MOD IN  NUMBER,--MOD模式
      IN_MOD_REN IN  NUMBER,--MOD余数
      IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
      IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
      IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
      IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
      IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
      IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
  )IS
    P_RESULT  NUMBER ;
    P_ERR_MSG VARCHAR2(4000);
    P_MOD NUMBER;
    P_MOD_REN NUMBER;  
    V_PARAM_FREEZE_DATE DATE;    
    CURSOR CUR_T_SALES_ACCOUNT_MX_AMOUNT IS
    SELECT T.ROWID,T.* FROM T_SALES_ACCOUNT_MX_AMOUNT T
    Where
      T.ENTITY_ID = IN_ENTITY_ID
      AND (IN_CUSTOMER_ID IS NULL OR IN_CUSTOMER_ID = T.CUSTOMER_ID)
      AND (IN_ACCOUNT_ID  IS NULL OR IN_ACCOUNT_ID = T.ACCOUNT_ID)
      AND T.ACTIVE_FLAG = '1'
      and  mod(ACCOUNT_AMOUNT_MX_ID,P_MOD)= P_MOD_REN; 
      
     V_RECEIVED_AMOUNT_FREEZE  T_SALES_ACCOUNT_MX_AMOUNT.RECEIVED_AMOUNT%TYPE := 0;             --到款金额 冻结金额
     V_SALES_AMOUNT_FREEZE     T_SALES_ACCOUNT_MX_AMOUNT.SALES_AMOUNT%TYPE := 0;                --销售金额  冻结金额       
  BEGIN
      P_RESULT  := V_SEC_RESULT;
      P_ERR_MSG := V_SUCCESS;
      
      IF IS_FREEZE_DATE IS NULL THEN
          V_PARAM_FREEZE_DATE := Trunc(Sysdate);
      ELSE
          V_PARAM_FREEZE_DATE := to_date(IS_FREEZE_DATE,'yyyy-mm-dd')+1;
      END IF;
      
      IF IN_MOD IS NULL THEN
          P_MOD := 1;
          P_MOD_REN := 0;
      ELSE     
          P_MOD := IN_MOD;
          P_MOD_REN := IN_MOD_REN;
      END IF;  

      FOR I IN CUR_T_SALES_ACCOUNT_MX_AMOUNT LOOP
                BEGIN
                  /*SELECT   
                          NVL(SUM(CASE
                               WHEN T.Business_ID = 'ar' AND T.CREATION_DATE < V_PARAM_FREEZE_DATE THEN
                                NVL(T.SETTLE_AMOUNT, 0)
                               ELSE
                                0
                             END),0) RECEIVED_AMOUNT_FREEZE --收款金额   冻结金额    
                    INTO
                        V_RECEIVED_AMOUNT_FREEZE
                    FROM V_CREDIT_CONTACT_AMOUNT_NS T
                   WHERE T.SETTLE_FLAG = 'Y'
                     AND T.CUSTOMER_ID = I.CUSTOMER_ID
                     AND T.ACCOUNT_ID = I.ACCOUNT_ID
                     AND T.SALES_MAIN_TYPE = I.SALES_MAIN_TYPE
                     AND T.ENTITY_ID = I.ENTITY_ID ;  */ 
                   BEGIN 
                       SELECT 
                           SUM(NVL(RL.AMOUNT,0))
                         INTO
                           V_RECEIVED_AMOUNT_FREEZE
                       FROM CIMS.T_AR_CASH_RECEIPT_HEADERS RH, 
                              CIMS.T_AR_CASH_RECEIPT_LINES RL
                       WHERE RH.CASH_RECEIPT_ID = RL.CASH_RECEIPT_ID
                       AND RH.RECEIPT_STATUS_ID IN (0,3,5,6,15,16)
                       AND RH.CUSTOMER_ID = I.CUSTOMER_ID
                       AND RH.ACCOUNT_ID = I.ACCOUNT_ID
                       AND RL.SALES_MAIN_TYPE_CODE = I.SALES_MAIN_TYPE
                       AND RH.ENTITY_ID = I.ENTITY_ID 
                       AND NVL(RH.REVIEWED_DATE,RH.CREATION_DATE) < V_PARAM_FREEZE_DATE;
                   EXCEPTION WHEN NO_DATA_FOUND THEN
                       V_RECEIVED_AMOUNT_FREEZE := 0;
                   END;
 
                   BEGIN    
                       SELECT T.SALES_AMOUNT_FREEZE
                       INTO V_SALES_AMOUNT_FREEZE
                       FROM T_CREDIT_CONTACT_AMOUNT_FREEZE T
                       WHERE T.CUSTOMER_ID = I.CUSTOMER_ID
                       AND T.ACCOUNT_ID = I.ACCOUNT_ID
                       AND T.SALES_MAIN_TYPE = I.SALES_MAIN_TYPE
                       AND T.ENTITY_ID = I.ENTITY_ID;
                   EXCEPTION WHEN NO_DATA_FOUND THEN
                     V_SALES_AMOUNT_FREEZE := 0;
                   END;
                   
                  UPDATE T_SALES_ACCOUNT_MX_AMOUNT T SET T.FREEZE_RECEIVED_AMOUNT=V_RECEIVED_AMOUNT_FREEZE,T.FREEZE_SALES_AMOUNT= V_SALES_AMOUNT_FREEZE WHERE T.ACCOUNT_AMOUNT_MX_ID = I.ACCOUNT_AMOUNT_MX_ID;          
                  commit;
            EXCEPTION WHEN OTHERS THEN
              rollback;
              P_RESULT := -20000;
              P_ERR_MSG := '从往来视图V_CREDIT_CONTACT_AMOUNT获取对应款项信息出错！' || V_NL || SQLERRM;
            END ;
      END LOOP ;
  
     insert into T_BD_ERROR_LOG(ROW_ID,ERROR_CODE,ERROR_FROM,ERROR_DATE,ERROR_DESC,CREATED_DATE)select S_BD_EEROR_LOG.NEXTVAL,'2','CREDIT',sysdate,IN_ENTITY_ID||IN_MOD||IN_MOD_REN||'', sysdate from DUAL;
     commit;
  EXCEPTION WHEN OTHERS THEN
        P_ERR_MSG := '方法执行体异常！'|| SQLERRM;
        P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PRC_CREDIT_FUND_SA_RETURN'
        ,'款项明细重算异常',SUBSTR(P_ERR_MSG || ',主体ID=' ||IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
       || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE,1,240));
  END PRC_CREDIT_FUND_SA_RETURN;  
  
  
  --款型锁定明细重算
  PROCEDURE PRC_CREDIT_FUND_MX_RETURN(
      IN_ENTITY_ID   IN  NUMBER,    --主体ID
      IN_MOD IN  NUMBER,--MOD模式
      IN_MOD_REN IN  NUMBER,--MOD余数
      IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
      IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
      IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
      IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
      IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
      IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
   -- P_ERR_MSG OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  )IS
    P_RESULT  NUMBER ;
    P_ERR_MSG VARCHAR2(4000);
    
    P_MOD NUMBER;
    P_MOD_REN NUMBER;
    
    CURSOR CUR_T_SALES_ACCOUNT_MX_AMOUNT IS
    SELECT T.ROWID,T.* FROM T_SALES_ACCOUNT_MX_AMOUNT T
    Where
      T.ENTITY_ID = IN_ENTITY_ID
      AND (IN_CUSTOMER_ID IS NULL OR IN_CUSTOMER_ID = T.CUSTOMER_ID)
      AND (IN_ACCOUNT_ID  IS NULL OR IN_ACCOUNT_ID = T.ACCOUNT_ID)
      AND T.ACTIVE_FLAG = '1'
      and  mod(ACCOUNT_AMOUNT_MX_ID,P_MOD)= P_MOD_REN;

    TYPE TRANS_TYPE IS RECORD(R_AMOUNT_NAME  t_sales_amount_trans.Amount_Name%TYPE,
                              R_AMOUNT       t_sales_amount_trans.Amount%TYPE,
                              R_PRE_FIELD_01 t_sales_amount_trans.pre_field_01%TYPE) ;
    TYPE CUR_TRANS_TYPE IS TABLE OF TRANS_TYPE INDEX BY BINARY_INTEGER;
    TRANS_TABLE CUR_TRANS_TYPE ;

    K NUMBER := 0 ;

    V_UPDATE_TABLE VARCHAR2(4000) ;
    V_UPDATE_COLS  VARCHAR2(4000) ;
    V_UPDATE_WHERE VARCHAR2(4000) ;

    V_SQL     VARCHAR2(4000) ;
    --V_SQL_MX  VARCHAR2(4000) ;

    V_RECEIVED_AMOUNT         T_SALES_ACCOUNT_MX_AMOUNT.RECEIVED_AMOUNT%TYPE := 0 ;             --到款金额
    V_RECEIVED_AMOUNT_FREEZE  T_SALES_ACCOUNT_MX_AMOUNT.RECEIVED_AMOUNT%TYPE := 0 ;             --到款金额 冻结金额
    V_SALES_AMOUNT            T_SALES_ACCOUNT_MX_AMOUNT.SALES_AMOUNT%TYPE := 0 ;                --销售金额
    V_SALES_AMOUNT_FREEZE     T_SALES_ACCOUNT_MX_AMOUNT.SALES_AMOUNT%TYPE := 0 ;                --销售金额  冻结金额
    V_LOCK_RECEIVED_AMOUNT    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0 ;        --锁定到款金额
    V_DELAYPAY_AMOUNT         T_SALES_ACCOUNT_MX_AMOUNT.DELAYPAY_AMOUNT%TYPE := 0 ;             --铺底金额
    V_TEMP_DELAYPAY_AMOUNT    T_SALES_ACCOUNT_MX_AMOUNT.TEMP_DELAYPAY_AMOUNT%TYPE := 0 ;        --临时铺底金额
    V_DISCOUNT_AMOUNT         T_SALES_ACCOUNT_MX_AMOUNT.DISCOUNT_AMOUNT%TYPE := 0 ;             --折让金额
    V_APPLIED_DISCOUNT_AMOUNT T_SALES_ACCOUNT_MX_AMOUNT.APPLIED_DISCOUNT_AMOUNT%TYPE := 0 ;     --核销折让金额
    V_FREEZE_DISCOUNT_AMOUNT  T_SALES_ACCOUNT_MX_AMOUNT.FREEZE_DISCOUNT_AMOUNT%TYPE := 0 ;      --冻结折让金额
    V_LOCK_DISCOUNT_AMOUNT    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;        --锁定折让金额
    V_DISPAY_AMOUNT           T_SALES_ACCOUNT_MX_AMOUNT.DISPAY_AMOUNT%TYPE := 0 ;               --未解付金额
    V_THREE_NOT_PAY           T_SALES_ACCOUNT_MX_AMOUNT.THREE_NOT_PAY%TYPE := 0 ;               --三方承兑未解付金额
    --ADD BY 苏冬渊 2015-08-26
    V_RESOURCE_AMOUNT         T_SALES_ACCOUNT_MX_AMOUNT.RESOURCE_AMOUNT%Type := 0 ;
    V_LOCK_RESOURCE_AMOUNT    T_SALES_ACCOUNT_MX_AMOUNT.Lock_Resource_Amount%Type := 0 ;
    V_TRANSACTION_AMOUNT      T_SALES_ACCOUNT_MX_AMOUNT.TRANSACTION_AMOUNT%Type := 0 ;

    /*V_LOCK_RECEIVED_AMOUNT_FHCX    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0 ;        --发货通知单撤销的金额
    V_LOCK_DISCOUNT_AMOUNT_FHCX    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;        --发货通知单撤销的折让金额*/

    V_LOCK_RECEIVED_AMOUNT_SHIP    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0 ;        --发运计划未下达锁定的金额
    V_LOCK_DISCOUNT_AMOUNT_SHIP    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;        --发运计划未下达锁定的折扣
    V_LOCK_RECEIVED_AMOUNT_DOC    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0 ;        --发货通知单未生成财务单的索款
    V_LOCK_DISCOUNT_AMOUNT_DOC    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;        --发货通知单未生成财务单的折扣

    --add by 苏冬渊 2015-08-26
    V_LOCK_RESOURCE_AMOUNT_SHIP  T_SALES_ACCOUNT_MX_AMOUNT.Lock_Resource_Amount%TYPE := 0 ;  --发运计划未下达锁定的资源
    V_LOCK_RESOURCE_AMOUNT_DOC   T_SALES_ACCOUNT_MX_AMOUNT.Lock_Resource_Amount%TYPE := 0 ;  --发运通知单未生成财务单锁定的资源

    V_LOCK_RESOURCE_AMOUNT_SS    T_SALES_ACCOUNT_MX_AMOUNT.Lock_Resource_Amount%TYPE := 0 ;  --送审锁款方式下未评审造成锁定资源
    V_LOCK_RECEIVED_AMOUNT_SS    T_SALES_ACCOUNT_MX_AMOUNT.Lock_Received_Amount%TYPE := 0 ;  --送审锁款方式下未评审造成锁定到款
    V_LOCK_DISCOUNT_AMOUNT_SS    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;  --送审锁款方式下未评审造成锁定折扣

    --ADD BY LIZHEN 2015-12-07 计划订单送锁款金额
    V_LOCK_RESOURCE_AMOUNT_PLN   T_SALES_ACCOUNT_MX_AMOUNT.Lock_Resource_Amount%TYPE := 0 ;  --送审锁款方式下未评审造成锁定资源
    V_LOCK_RECEIVED_AMOUNT_PLN   T_SALES_ACCOUNT_MX_AMOUNT.Lock_Received_Amount%TYPE := 0 ;  --送审锁款方式下未评审造成锁定到款
    V_LOCK_DISCOUNT_AMOUNT_PLN   T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;  --送审锁款方式下未评审造成锁定折扣
   
    V_LOCK_RECEIVED_AMOUNT_PLN_DP   T_SALES_ACCOUNT_MX_AMOUNT.Lock_Received_Amount%TYPE := 0 ;  --计划订单送审锁款方式下未评审造成锁定订金
    V_LOCK_DISCOUNT_AMOUNT_PLN_DP   T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;  --计划订单送审锁款方式下未评审造成锁定折扣订金

    V_LOCK_RECEIVED_AMOUNT_SS_DP T_SALES_ACCOUNT_MX_AMOUNT.Lock_Received_Amount%TYPE := 0 ;  --送审锁款方式下未评审造成锁定订金
    --add by liangym2 2017-7-17
    V_LOCK_DISCOUNT_AMOUNT_SS_DP T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;  --送审锁款方式下未评审造成锁定折扣订金
    --add by liangym2 2017-7-19
    V_LOCK_RECEIVED_AMOUNT_T_SHIP T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0 ;  --制定发货需求计划下达（直发客户） 锁款 未发货
    V_LOCK_DISCOUNT_AMOUNT_T_SHIP T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;  --制定发货需求计划下达（直发客户） 折扣锁款 未发货
    V_LOCK_RECEIVED_AMOUNT_T_DOC T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0 ;  --制定发货需求计划下达（直发客户） 锁款 发货未确认
    V_LOCK_DISCOUNT_AMOUNT_T_DOC T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;  --制定发货需求计划下达（直发客户） 折扣锁款 发货未确认
    V_FREEZE_DELAY_AMOUNT  T_SALES_ACCOUNT_MX_AMOUNT.FREEZE_DELAY_AMOUNT%TYPE := 0 ;      --冻结铺底金额、冻结保证金 2017-10-11 梁颜明
    
    V_LOCK_RECEIVED_AMOUNT_HQ T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0; --送总部评审锁款需锁款金额
    V_LOCK_DISCOUNT_AMOUNT_HQ T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0; --送总部评审锁款需锁折让金额
    V_LOCK_RESOURCE_AMOUNT_HQ T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RESOURCE_AMOUNT%TYPE := 0; --送总部评审锁款需锁资源金额
    V_LOCK_RECEIVED_AMOUNT_HQ_DP T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0; --送总部评审锁款需锁订金金额
    V_LOCK_DISCOUNT_AMOUNT_HQ_DP T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0; --送总部评审锁款需锁折让订金金额
    
    V_CNT                        NUMBER;
  
    
    V_LOCK_RECEIVED_AMOUNT_PS T_SALES_ACCOUNT_MX_AMOUNT.Lock_Received_Amount%TYPE := 0 ;  --
    --add by liangym2 2017-12-12
    V_LOCK_DISCOUNT_AMOUNT_PS T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;  --
    --add by liangym2 2017-12-12
    V_LOCK_RECEIVED_AMOUNT_PS_DP T_SALES_ACCOUNT_MX_AMOUNT.Lock_Received_Amount%TYPE := 0 ;  --
    --add by liangym2 2017-12-12
    V_LOCK_DISCOUNT_AMOUNT_PS_DP T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;  --
    --add by liangym2 2017-12-12
    
    V_PARAM_FREEZE_DATE DATE;
    
    V_CRUENT_TIME NUMBER;
    V_PARAM_EXIT_TIME NUMBER;

    V_LOCK_RECEIVED_AMOUNT_NEW T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0;
    V_LOCK_DISCOUNT_AMOUNT_NEW T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0;
    V_LOCK_RESOURCE_AMOUNT_NEW T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RESOURCE_AMOUNT%TYPE := 0;
    V_LOCK_RECEIVED_AMOUNT_NEW_DP T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0;
    V_LOCK_DISCOUNT_AMOUNT_NEW_DP T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0;    
  BEGIN
      P_RESULT  := V_SEC_RESULT;
      P_ERR_MSG := V_SUCCESS;
      V_PARAM_EXIT_TIME := PKG_BD.F_GET_PARAMETER_VALUE('CREDIT_PARAM_EXIT_TIME', IN_ENTITY_ID, NULL, NULL);
      
      IF IS_FREEZE_DATE IS NULL THEN
          V_PARAM_FREEZE_DATE := Trunc(Sysdate);
      ELSE
          V_PARAM_FREEZE_DATE := to_date(IS_FREEZE_DATE,'yyyy-mm-dd')+1;
      END IF;
      
      IF IN_MOD IS NULL THEN
          P_MOD := 1;
          P_MOD_REN := 0;
      ELSE     
          P_MOD := IN_MOD;
          P_MOD_REN := IN_MOD_REN;
      END IF;
      
      SELECT COUNT(0) INTO V_CNT
      FROM UP_CODELIST C,UP_CODELIST_ENTITY CE
      WHERE CE.CODELIST_ID = C.ID
      AND CE.ENTITY_ID = IN_ENTITY_ID
      AND NVL(CE.ENABLED,'0')='0'
      AND C.CODETYPE = 'temp_all_free'--临时自由码表
      AND C.CODE_VALUE = '信用重算改动风险开关'
      AND C.CODE_NAME = '信用重算改动风险开关'
      AND C.ENTITY_FLAG = 'Y'
      AND C.ENABLED = '0';
      
      V_UPDATE_TABLE := 'UPDATE T_SALES_ACCOUNT_MX_AMOUNT T SET ' ;
      
      FOR I IN CUR_T_SALES_ACCOUNT_MX_AMOUNT LOOP
        
        SELECT TO_NUMBER(TO_CHAR(SYSDATE, 'HH24')) INTO V_CRUENT_TIME FROM DUAL;
        IF IN_ACCOUNT_ID IS NULL AND IN_CUSTOMER_ID IS NULL AND V_CRUENT_TIME>=V_PARAM_EXIT_TIME THEN
           EXIT;
        END IF;
        
        SAVEPOINT SAVEPOINT_KXMX ; --款项明细保存点
        --重置变量
        V_UPDATE_COLS := '' ;
        K := 0 ;
        TRANS_TABLE.DELETE ;

        BEGIN
          SELECT NVL(SUM(CASE
                       WHEN T.Business_ID = 'ar' THEN
                        NVL(T.SETTLE_AMOUNT, 0)
                       ELSE
                        0
                     END),0) V_RECEIVED_AMOUNT, --收款金额
                     
                  NVL(SUM(CASE
                       WHEN T.Business_ID = 'ar' AND T.CREATION_DATE < V_PARAM_FREEZE_DATE THEN
                        NVL(T.SETTLE_AMOUNT, 0)
                       ELSE
                        0
                     END),0) V_RECEIVED_AMOUNT_FREEZE, --收款金额   冻结金额  
                     
                 --销售明细表中，扣率折让单和扣率折让红冲单不对销售金额产生影响
                 NVL(SUM(CASE
                       WHEN T.BUSINESS_ID = 'so' AND
                            --T.BILL_TYPE_ID NOT IN (76, 77) THEN
                            --T.BILL_TYPE_CODE NOT IN (/*1024,1025,1026,1027,*/1028,1029) THEN
                            t.src_type_code Not In ('1009','1010') Then
                        NVL(T.SETTLE_AMOUNT, 0)
                       ELSE
                        0
                     END),0) V_SALES_AMOUNT, --销售金额
                     
                NVL(SUM(CASE
                       WHEN T.BUSINESS_ID = 'so' AND
                            T.CREATION_DATE < V_PARAM_FREEZE_DATE   AND
                            t.src_type_code Not In ('1009','1010') Then
                        NVL(T.SETTLE_AMOUNT, 0)
                       ELSE
                        0
                     END),0) V_SALES_AMOUNT_FREEZE, --销售金额  冻结金额     
                     
                 NVL(SUM(CASE T.BUSINESS_ID
                        WHEN 'ar' Then
                           --(CASE WHEN T.FUND_CTRL_MODE = 'Y' THEN --是否为承兑
                           --mod by sudy 2015-12-26 到款模块三方承兑冲销改变了方式，由之前不生成冲销单改成生成产冲销单据
                           --重算需要调整，将冲销单据剔除掉
                           /*(CASE WHEN T.FUND_CTRL_MODE = 'Y' And t.SETTLE_AMOUNT >= 0 THEN --是否为承兑
                          NVL(T.SETTLE_AMOUNT,0)-NVL(T.SOLUTION_PAY_AMOUNT,0) ELSE 0 END)*/

                          --mod by 龙鸿文 2016-1-11 区分三方承兑单据是否被冲销(T.writeoff_receipt_flag = 'Y')
                          (CASE
                           WHEN T.FUND_CTRL_MODE = 'Y' AND T.writeoff_receipt_flag = 'Y' THEN
                                NVL(T.SETTLE_AMOUNT,0)
                           WHEN T.FUND_CTRL_MODE = 'Y' AND T.writeoff_receipt_flag = 'N' THEN
                                NVL(T.SETTLE_AMOUNT,0)-NVL(T.SOLUTION_PAY_AMOUNT,0)
                           ELSE 0 END)

                        /*WHEN 'so' THEN
                           --销售单,特批销售单,工程买断销售单
                          (CASE WHEN T.BILL_TYPE_CODE IN (1020,1022,1023) AND T.CREATED_MODE = 10 THEN
                            (-1) * NVL(T.SETTLE_AMOUNT,0) ELSE 0 END)
                        WHEN 'order' THEN
                           NVL(T.SETTLE_AMOUNT,0)*/
                        ELSE 0 END),0) V_LOCK_RECEIVED_AMOUNT, --锁定到款金额
                  NVL(SUM(CASE T.BUSINESS_ID
                         WHEN 'delay' THEN
                            (CASE WHEN T.BILL_TYPE_ID IN (1,2,4) THEN NVL(T.SETTLE_AMOUNT,0) ELSE 0 END)
                         ELSE 0 END),0) V_DELAYPAY_AMOUNT, --铺底金额
                  NVL(SUM(CASE T.BUSINESS_ID
                         WHEN 'delay' THEN
                            (CASE WHEN T.BILL_TYPE_ID = 3 AND T.SRC_TYPE <> 8 THEN NVL(T.SETTLE_AMOUNT,0) ELSE 0 END)
                         ELSE 0 END),0) V_TEMP_DELAYPAY_AMOUNT, --临时铺底金额
                  NVL(SUM(CASE T.BUSINESS_ID
                         WHEN 'so' THEN
                           --(CASE WHEN T.BILL_TYPE_CODE IN (1028,1029) THEN NVL(T.DISCOUNT_AMOUNT,0) ELSE 0 END)
                           (CASE WHEN T.src_type_code IN ('1009','1010') THEN NVL(T.DISCOUNT_AMOUNT,0) ELSE 0 END)
                         ELSE 0 END),0) V_DISCOUNT_AMOUNT, --扣率折让金额
                  NVL(SUM(CASE T.BUSINESS_ID
                         WHEN 'so' THEN
                           --(CASE WHEN T.BILL_TYPE_CODE IN (1020,1021,1022,1023,1031,1032) THEN NVL(T.DISCOUNT_AMOUNT,0) ELSE 0 END)
                           (CASE WHEN T.src_type_code IN ('1001','1002','1003','1004') THEN NVL(T.DISCOUNT_AMOUNT,0) ELSE 0 END)
                         ELSE 0 END),0) V_APPLIED_DISCOUNT_AMOUNT,  --核销扣率折让金额
                 NVL(SUM(CASE T.BUSINESS_ID
                         WHEN 'delay' THEN
                            (CASE WHEN T.BILL_TYPE_ID = 3 AND T.SRC_TYPE = 8 THEN -NVL(T.SETTLE_AMOUNT,0) ELSE 0 END)
                         ELSE 0 END),0) V_FREEZE_DISCOUNT_AMOUNT, --冻结扣率折让金额
                 NVL(SUM(CASE T.BUSINESS_ID
                         WHEN 'delay' THEN
                            (CASE WHEN T.BILL_TYPE_ID = 3 AND T.SRC_TYPE = 10 THEN -NVL(T.SETTLE_AMOUNT,0) ELSE 0 END)
                         ELSE 0 END),0) V_FREEZE_DELAY_AMOUNT, --冻结保证金、冻结铺底
                 /*NVL(SUM(CASE T.BUSINESS_ID
                        WHEN 'so' THEN
                           (CASE WHEN T.BILL_TYPE_CODE IN (1020,1022,1023) AND T.CREATED_MODE = 10 THEN
                          (-1) * NVL(T.DISCOUNT_AMOUNT,0) ELSE 0 END)
                        WHEN 'order' THEN
                           NVL(T.DISCOUNT_AMOUNT,0)
                        ELSE 0 END),0)  V_LOCK_DISCOUNT_AMOUNT, --锁定扣率折让金额*/
                 NVL(SUM(CASE T.BUSINESS_ID
                         WHEN 'ar' THEN
                           (CASE WHEN T.DRAFT_FLAG = 'Y' And t.SETTLE_AMOUNT >= 0 THEN
                           NVL(T.SETTLE_AMOUNT,0)-NVL(T.SOLUTION_PAY_AMOUNT,0) ELSE 0 END)
                         ELSE 0 END),0) V_DISPAY_AMOUNT,
                 NVL(SUM(CASE T.BUSINESS_ID
                         WHEN 'ar' THEN
                           (CASE WHEN T.FUND_CTRL_MODE = 'Y' THEN
                           NVL(T.SETTLE_AMOUNT,0)-NVL(T.SOLUTION_PAY_AMOUNT,0) ELSE 0 END)
                         ELSE 0 END),0) V_THREE_NOT_PAY
            INTO
                V_RECEIVED_AMOUNT    ,
                V_RECEIVED_AMOUNT_FREEZE,
                V_SALES_AMOUNT        ,
                V_SALES_AMOUNT_FREEZE ,
                V_LOCK_RECEIVED_AMOUNT   ,
                V_DELAYPAY_AMOUNT        ,
                V_TEMP_DELAYPAY_AMOUNT   ,
                V_DISCOUNT_AMOUNT        ,
                V_APPLIED_DISCOUNT_AMOUNT ,
                V_FREEZE_DISCOUNT_AMOUNT  ,
                V_FREEZE_DELAY_AMOUNT ,
               -- V_LOCK_DISCOUNT_AMOUNT    ,
                V_DISPAY_AMOUNT           ,
                V_THREE_NOT_PAY
            FROM V_CREDIT_CONTACT_AMOUNT_NS T
           WHERE T.SETTLE_FLAG = 'Y'
             AND T.CUSTOMER_ID = I.CUSTOMER_ID
             AND T.ACCOUNT_ID = I.ACCOUNT_ID
             AND T.SALES_MAIN_TYPE = I.SALES_MAIN_TYPE
             AND T.ENTITY_ID = I.ENTITY_ID ;
         BEGIN    
             SELECT T.SALES_AMOUNT,T.SALES_AMOUNT_FREEZE,T.DISCOUNT_AMOUNT,T.DISCOUNT_AMOUNT_FREEZE
             INTO V_SALES_AMOUNT,V_SALES_AMOUNT_FREEZE,V_DISCOUNT_AMOUNT,V_APPLIED_DISCOUNT_AMOUNT
             FROM T_CREDIT_CONTACT_AMOUNT_FREEZE T
             WHERE T.CUSTOMER_ID = I.CUSTOMER_ID
             AND T.ACCOUNT_ID = I.ACCOUNT_ID
             AND T.SALES_MAIN_TYPE = I.SALES_MAIN_TYPE
             AND T.ENTITY_ID = I.ENTITY_ID;
         EXCEPTION WHEN NO_DATA_FOUND THEN
           V_SALES_AMOUNT := 0;
           V_SALES_AMOUNT_FREEZE := 0;
           V_DISCOUNT_AMOUNT := 0;
           V_APPLIED_DISCOUNT_AMOUNT := 0;
         END;
      EXCEPTION WHEN OTHERS THEN
        P_RESULT := -20000;
        P_ERR_MSG := '从往来视图V_CREDIT_CONTACT_AMOUNT获取对应款项信息出错！' || V_NL || SQLERRM;
        ROLLBACK TO SAVEPOINT_KXMX ;
        GOTO HERE ;
      END ;

       /** modify by 苏冬渊 2015-08-26
        *  由于订单增加送审锁款，所以以上的锁款重算规则需要改动。
        *  以下为修改的过程
        */
      --发运计划未下达数量产生的锁款
      Begin
        Select nvl(Sum(round(
                       Case
                         --20200314 家用直发锁款调整
                         when t.origin_type = '01' and nvl(t.direct_transport_falg, 'N') = 'Y' and 
                           (select nvl(h.amount_lock_flag, 'N')
                              from t_pln_order_head h
                             where h.order_head_id = t.origin_order_id) = 'NT'
                           then
                             0
                         When t.lock_amount_flag In ('S','Y','HQ') Then
                           --add by lizhen 2015-11-30 增加月返计算
                           Nvl(T.Unaffirm_Qty,0) * Nvl(T.Item_Price,0) * (100-nvl(t.discount_rate,0) - Nvl(t.month_discount_rate, 0))/100
                         Else 0 End
                       ,2)
                       ),0),
               nvl(Sum(round(
                       Case
                         --20200314 家用直发锁款调整
                         when t.origin_type = '01' and nvl(t.direct_transport_falg, 'N') = 'Y' and 
                           (select nvl(h.amount_lock_flag, 'N')
                              from t_pln_order_head h
                             where h.order_head_id = t.origin_order_id) = 'NT'
                           then
                             0
                         When t.lock_amount_flag In ('S','Y','HQ') Then
                           nvl(t.unaffirm_qty,0) * nvl(t.item_price,0) * nvl(t.discount_rate,0)/100
                         Else 0 End
                       ,2)
                       ),0),
               nvl(Sum(round(
                       Case When t.lock_amount_flag In ('RS','RT') Then
                        --add by lizhen 2015-11-30 增加月返计算
                        Nvl(T.Unaffirm_Qty,0) * Nvl(T.Item_Price,0) * (100-nvl(t.discount_rate,0)- Nvl(t.month_discount_rate, 0))/100
                       Else 0 End
                       ,2)
                       ),0)
          Into V_LOCK_RECEIVED_AMOUNT_SHIP,
               V_LOCK_DISCOUNT_AMOUNT_SHIP,
               V_LOCK_RESOURCE_AMOUNT_SHIP
          From T_Lg_Ship_Plan t,
               T_INV_BILL_TYPES           bill_type,  --业务单据类型
               T_INV_SOURCE_TYPES         source_type  --单据源类型
         Where T.Entity_Id = I.Entity_Id
           And T.Customer_Id = I.Customer_Id
           And T.Account_Code = I.Account_Code
           And T.Sales_Main_Type = I.Sales_Main_Type
           And t.status <> '03' --撤销单据没有锁款
           And t.status <> '02' --已确认，确认则生成发货通知单。部分确认的话，则拆单，生成两个发运计划
           and t.sales_order_type_id = bill_type.bill_type_id(+)
           and bill_type.source_type_id = source_type.source_type_id
           --梁颜明 2016-11-30 SOURCE_TYPE_CODE
           --=1008是计划订单确认下达选择调拨单类型，不应该被过滤
           AND (0 >= V_CNT OR source_type.SOURCE_TYPE_CODE <> '1008')
           AND NVL(T.CUSTOMIZE_FLAG, 'N') = 'N'
           --不包含促销品
           --And t.origin_type <> '04'
           --锁款标志:到款锁定标志：S:送审锁款 Y:发货锁定到款 N:不锁定到款 RS:资源送审锁定到款  RT:资源提货锁定到款（标志来源单据类型）
           And t.lock_amount_flag In ('S','Y','RS','RT','HQ');
      Exception When Others Then
        V_LOCK_RECEIVED_AMOUNT_SHIP := 0 ;
        V_LOCK_DISCOUNT_AMOUNT_SHIP := 0 ;
        V_LOCK_RESOURCE_AMOUNT_SHIP := 0 ;
        ROLLBACK TO SAVEPOINT_KXMX ;
        GOTO HERE ;
      End ;

      --发货通知单未生成财务单产生的锁款
      Begin
          Select nvl(Sum(round(
                         Case
                           --20200314 家用直发锁款调整
                           when b.origin_type = '01' and nvl(a.direct_transport_falg, 'N') = 'Y' and
                             (select nvl(h.amount_lock_flag, 'N')
                                from t_pln_order_head h
                               where h.order_head_id = b.origin_order_id) = 'NT'
                           then
                             0
                           When b.lock_amount_flag In ('S','Y','HQ') Then
                            --add by lizhen 2015-11-30 增加月返计算
                            (NVL(B.Item_Qty,0)- nvl(b.fact_ship_qty,0)-nvl(b.cancel_qty,0)) * NVL(B.ITEM_PRICE,0) * (100-Nvl(B.DISCOUNT_RATE,0) - Nvl(b.month_discount_rate, 0))/100
                           Else 0 End
                           ,2)
                        ),0),
                 nvl(Sum(round(
                         Case
                           --20200314 家用直发锁款调整
                           when b.origin_type = '01' and nvl(a.direct_transport_falg, 'N') = 'Y' and
                             (select nvl(h.amount_lock_flag, 'N')
                                from t_pln_order_head h
                               where h.order_head_id = b.origin_order_id) = 'NT'
                           then
                             0
                           When b.lock_amount_flag In ('S','Y','HQ') Then
                          (NVL(B.Item_Qty,0)- nvl(b.fact_ship_qty,0)-nvl(b.cancel_qty,0)) * NVL(B.ITEM_PRICE,0) * Nvl(B.DISCOUNT_RATE,0)/100
                         Else 0 End
                         ,2)
                        ),0),
                 nvl(Sum(round(
                         Case When b.lock_amount_flag In ('RS','RT') Then
                          --add by lizhen 2015-11-30 增加月返计算
                          (NVL(B.Item_Qty,0)- nvl(b.fact_ship_qty,0)-nvl(b.cancel_qty,0)) * NVL(B.ITEM_PRICE,0) * (100-Nvl(B.DISCOUNT_RATE,0) - Nvl(b.month_discount_rate, 0))/100
                         Else 0 End
                         ,2)
                        ),0)
            Into V_LOCK_RECEIVED_AMOUNT_DOC,
                 V_LOCK_DISCOUNT_AMOUNT_DOC,
                 V_LOCK_RESOURCE_AMOUNT_DOC
          From CIMS.t_lg_ship_doc A,CIMS.t_lg_ship_doc_line B,
               T_INV_BILL_TYPES           bill_type,  --业务单据类型
               T_INV_SOURCE_TYPES         source_type  --单据源类型
         Where A.SHIP_DOC_ID = B.SHIP_DOC_ID
           And A.DOC_STATUS <> '01' --单据状态 00正常 01红冲
           And A.CUSTOMER_ID = I.CUSTOMER_ID
           And A.ACCOUNT_CODE = I.ACCOUNT_CODE
           And B.SALES_MAIN_TYPE = I.SALES_MAIN_TYPE
           And A.ENTITY_ID = I.ENTITY_ID
           and B.sales_order_type_id = bill_type.bill_type_id(+)
           and bill_type.source_type_id = source_type.source_type_id
           --梁颜明 2016-11-30 SOURCE_TYPE_CODE
           --=1008是计划订单确认下达选择调拨单类型，不应该被过滤
           AND (0 >= V_CNT OR source_type.SOURCE_TYPE_CODE <> '1008')
           AND NVL(A.CUSTOMIZE_FLAG, 'N') = 'N'
           --不包含促销品
           --And b.origin_type <> '04'
           --锁款标志:到款锁定标志：S:送审锁款 Y:发货锁定到款 N:不锁定到款 RS:资源送审锁定到款  RT:资源提货锁定到款（标志来源单据类型）
           And b.lock_amount_flag In ('S','Y','RS','RT','HQ');

       Exception When Others Then
          V_LOCK_RECEIVED_AMOUNT_DOC := 0 ;
          V_LOCK_DISCOUNT_AMOUNT_DOC := 0 ;
          V_LOCK_RESOURCE_AMOUNT_DOC := 0 ;
          ROLLBACK TO SAVEPOINT_KXMX ;
          GOTO HERE ;
       End ;
       
      Begin
          --制定发货需求计划下达（直发客户） 发货计划未确认（未生成发货通知单）
          SELECT  NVL(SUM(ROUND(
                 --锁定代理商到款(未确认数量*直发列表价*(100-直发扣率-直发月返)/100)
                 NVL(TP.UNAFFIRM_QTY, 0) * NVL(TP.TRANSFER_LIST_PRICE, 0) *
                 (100 - NVL(TP.TRANSFER_DISCOUNT_RATE, 0) -
                  NVL(TP.TRANSFER_MONTH_DISCOUNT_RATE, 0)) / 100,
                 2)),
                   0),
               NVL(SUM(ROUND(NVL(TP.UNAFFIRM_QTY, 0) * NVL(TP.TRANSFER_LIST_PRICE, 0) *
                         NVL(TP.TRANSFER_DISCOUNT_RATE, 0) / 100,
                         2)),
                   0) INTO V_LOCK_RECEIVED_AMOUNT_T_SHIP,V_LOCK_DISCOUNT_AMOUNT_T_SHIP
          FROM T_LG_SHIP_PLAN TP
         WHERE TP.TRANSFER_ENTITY_ID = I.ENTITY_ID
           AND TP.TRANSFER_ACCOUNT_ID = I.ACCOUNT_ID
           AND TP.TRANSFER_CUSTOMER_ID = I.CUSTOMER_ID
           AND TP.STATUS <> '03'--撤销单据没有锁款
           AND TP.STATUS <> '02'--已确认，确认则生成发货通知单。部分确认的话，则拆单，生成两个发运计划
           --AND TP.STATUS IN ('00', '01') --撤销单据没有锁款
           AND TP.TRANSFER_LOCK_AMOUNT_FLAG = 'Y'
           AND TP.TRANSFER_ITEM_MAIN_TYPE = I.SALES_MAIN_TYPE
           ;

       Exception When Others Then
          V_LOCK_RECEIVED_AMOUNT_T_SHIP := 0 ;
          V_LOCK_DISCOUNT_AMOUNT_T_SHIP := 0 ;
          ROLLBACK TO SAVEPOINT_KXMX ;
          GOTO HERE ;
       End ;
       
      Begin
          --制定发货需求计划下达（直发客户） 发货通知单未生成销售单
          SELECT  NVL(SUM(ROUND( --锁定代理商到款((产品数量-已取消数量-已转采购数量)*直发列表价*(100-直发扣率-直发月返)/100)
                           (NVL(B.ITEM_QTY, 0) - NVL(B.CANCEL_QTY, 0) -
                           NVL(B.TRANSFER_TO_POX_QTY, 0)) *
                           NVL(B.TRANSFER_LIST_PRICE, 0) *
                           (100 - NVL(B.TRANSFER_DISCOUNT_RATE, 0) -
                           NVL(B.TRANSFER_MONTH_DISCOUNT_RATE, 0)) / 100,
                           2)),
                     0) LOCKED_AMOUNT,
                 NVL(SUM(ROUND((NVL(B.ITEM_QTY, 0) - NVL(B.FACT_SHIP_QTY, 0) -
                           NVL(B.CANCEL_QTY, 0) - NVL(B.TRANSFER_TO_POX_QTY, 0)) *
                           NVL(B.TRANSFER_LIST_PRICE, 0) *
                           NVL(B.TRANSFER_DISCOUNT_RATE, 0) / 100,
                           2)),
                     0) INTO V_LOCK_RECEIVED_AMOUNT_T_DOC,V_LOCK_DISCOUNT_AMOUNT_T_DOC
          FROM T_LG_SHIP_DOC A --发货通知单头
           INNER JOIN T_LG_SHIP_DOC_LINE B
              ON (A.SHIP_DOC_ID = B.SHIP_DOC_ID) --发货通知单行
         WHERE A.DOC_STATUS <> '01' --单据状态 00正常 01红冲
         AND B.TRANSFER_LOCK_AMOUNT_FLAG = 'Y'
         AND A.TRANSFER_ENTITY_ID = I.ENTITY_ID
         AND A.TRANSFER_ACCOUNT_ID = I.ACCOUNT_ID
         AND A.TRANSFER_CUSTOMER_ID = I.CUSTOMER_ID
         AND B.TRANSFER_ITEM_MAIN_TYPE = I.SALES_MAIN_TYPE
           ;
       Exception When Others Then
          V_LOCK_RECEIVED_AMOUNT_T_DOC := 0 ;
          V_LOCK_DISCOUNT_AMOUNT_T_DOC := 0 ;
          ROLLBACK TO SAVEPOINT_KXMX ;
          GOTO HERE ;
       End ;


      --送审锁款方式下，已经送审未评审产生的锁款
      Begin
          Select nvl(Sum(round(
                         Case
                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED THEN
                             0
                           --20200314 家用直发锁款调整
                           When (a.lock_amount_flag = 'S' AND NOT(NVL(A.DOWN_PAY_SCALE,-1) >= 0))
                             or NVL(b.is_lock_amount, 'N') = 'Y' Then
                          --add by lizhen 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                          --(NVL(B.Quantity,0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0))
                          --MODI BY LIZHEN 2016-05-12 增加已引APS产能可视状态(2225)数据计算锁款
                          --ADD YBY LIANGYM2 2017-6-18 已送审状态下销司主体结算到总部主体 Center_Affirm_Quantity可能发生变化
                          (Case When a.order_head_state In ('20', '2225', '1455') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                  NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY),0)-nvl(B.AFFIRMED_QUANTITY,0)-Nvl(B.Cancel_Qty,0)
                                    -(nvl(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                    -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                When a.order_head_state In ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                  NVL(B.Center_Affirm_Quantity, 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                    -(nvl(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                    -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0))
                                Else 0 End)
                              --20180105 hejy3 增加订金发货锁全款处理
                              /*when a.lock_amount_flag = 'S' AND A.DOWN_PAY_SCALE >= 0 THEN
                                NVL(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0)*/
                              Else 0
                          End
                          * DECODE(B.PROJECT_ORDER_TYPE,NULL,NVL(B.List_Price,0),NVL(B.APPLY_LIST_PRICE,0))
                          --add by lizhen 2015-11-30 增加月返计算
                          * (100-DECODE(B.PROJECT_ORDER_TYPE,NULL,Nvl(B.Discount_Rate,0),NVL(B.APPLY_DISCOUNT_RATE,0)) - Nvl(b.ordered_discount_rate, 0))/100
                         ,2)
                        ),0),
                 nvl(Sum(round(
                         Case
                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED THEN
                             0
                           --20200314 家用直发锁款调整
                           When (a.lock_amount_flag = 'S' AND NOT(NVL(A.DOWN_PAY_SCALE,-1) >= 0))
                             or NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' Then
                          --add by lizhen 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                          --(NVL(B.Quantity,0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.cancel_qty, 0))
                          --MODI BY LIZHEN 2016-05-12 增加已引APS产能可视状态(2225)数据计算锁款
                          (Case When a.order_head_state In ('20', '2225', '1455') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                  NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0)-nvl(B.AFFIRMED_QUANTITY,0)-Nvl(B.Cancel_Qty,0)
                                    -(nvl(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                    -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                When a.order_head_state In ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                  NVL(B.Center_Affirm_Quantity, 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                    -(nvl(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                    -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0))
                                Else 0 End)
                         --20180105 hejy3 增加订金发货锁全款处理
                         /*when a.lock_amount_flag = 'S' AND A.DOWN_PAY_SCALE >= 0 THEN
                           NVL(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0)*/
                         Else 0 End
                         * DECODE(B.PROJECT_ORDER_TYPE,NULL,NVL(B.List_Price,0),NVL(B.APPLY_LIST_PRICE,0))
                            * DECODE(B.PROJECT_ORDER_TYPE,NULL,Nvl(B.Discount_Rate,0),NVL(B.APPLY_DISCOUNT_RATE,0))/100
                         ,2)
                        ),0),
                 nvl(Sum(round(
                         Case
                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED THEN
                             0
                           When a.lock_amount_flag = 'RS' Then
                          --add by lizhen 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                          --(NVL(B.Quantity,0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0))
                          --MODI BY LIZHEN 2016-05-12 增加已引APS产能可视状态(2225)数据计算锁款
                          (Case When a.order_head_state In ('20', '2225', '1455') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                  NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                When a.order_head_state In ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                  NVL(B.Center_Affirm_Quantity, 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                Else 0 End)
                            * DECODE(B.PROJECT_ORDER_TYPE,NULL,NVL(B.List_Price,0),NVL(B.APPLY_LIST_PRICE,0))
                            --add by lizhen 2015-11-30 增加月返计算
                            * (100-DECODE(B.PROJECT_ORDER_TYPE,Null,Nvl(B.Discount_Rate,0),NVL(B.APPLY_DISCOUNT_RATE,0))- Nvl(b.ordered_discount_rate, 0))/100
                         Else 0 End
                         ,2)
                        ),0),
                        --2016-09-13 add by liangym2 锁款拆成全额以及订金部分 V_LOCK_RECEIVED_AMOUNT_SS_DP
               nvl(Sum((A.DOWN_PAY_SCALE / 100) * round(Case
                               --20200314 家用直发锁款调整
                               WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED 
                                 or NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                 0
                               When a.lock_amount_flag = 'S' AND A.DOWN_PAY_SCALE > 0 Then
                                (Case
                                  when nvl(b.is_lock_amount, 'N') = 'NT' then
                                    NVL(B.Center_Affirm_Quantity, 0) - Nvl(B.Cancel_Qty, 0)
                                  When a.order_head_state In ('20', '2225', '1455') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                   NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) - nvl(B.AFFIRMED_QUANTITY, 0) -
                                   Nvl(B.Cancel_Qty, 0) - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                   -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                  When a.order_head_state In ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                   NVL(B.Center_Affirm_Quantity, 0) - nvl(B.AFFIRMED_QUANTITY, 0) - Nvl(B.Cancel_Qty, 0)
                                   -(nvl(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                   -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                  Else
                                   0
                                End) * DECODE(B.PROJECT_ORDER_TYPE,
                                              NULL,
                                              NVL(B.List_Price, 0),
                                              NVL(B.APPLY_LIST_PRICE, 0))
                               --add by lizhen 2015-11-30 增加月返计算
                                * (100 - DECODE(B.PROJECT_ORDER_TYPE,
                                                NULL,
                                                Nvl(B.Discount_Rate, 0),
                                                NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                Nvl(b.ordered_discount_rate, 0)) / 100
                               WHEN a.lock_amount_flag = 'S' AND A.DOWN_PAY_SCALE = 0 THEN
                                 0
                               Else 0 End
                         ,2)
                        ),0),
                 nvl(Sum((A.DOWN_PAY_SCALE / 100) * round(
                         Case
                           --20200314 家用直发锁款调整
                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED 
                             or NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                             0
                           When a.lock_amount_flag = 'S' AND A.DOWN_PAY_SCALE > 0 Then
                          --add by lizhen 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                          --(NVL(B.Quantity,0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.cancel_qty, 0))
                          --MODI BY LIZHEN 2016-05-12 增加已引APS产能可视状态(2225)数据计算锁款
                          --如果订单头状态为20,1455,2225，而且订单头的hq_lg_order_head_id不为空，则取中心评审数量
                          --如果订单头状态为20,1455,2225，而且订单头的hq_lg_order_head_id为空，则取申请数量
                          --NVL(B.Center_Affirm_Quantity,B.Quantity)
                          (Case
                             when NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                               NVL(B.Center_Affirm_Quantity, 0) - Nvl(B.Cancel_Qty, 0)
                             When a.order_head_state In ('20', '2225', '1455') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                  NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                  - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                  -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                When a.order_head_state In ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED Then
                                  NVL(B.Center_Affirm_Quantity, 0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0)
                                  -(nvl(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                  -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                Else 0 End)
                            * DECODE(B.PROJECT_ORDER_TYPE,NULL,NVL(B.List_Price,0),NVL(B.APPLY_LIST_PRICE,0))
                            * DECODE(B.PROJECT_ORDER_TYPE,NULL,Nvl(B.Discount_Rate,0),NVL(B.APPLY_DISCOUNT_RATE,0))/100
                         Else 0 End
                         ,2)
                        ),0)
            Into
                 V_LOCK_RECEIVED_AMOUNT_SS ,
                 V_LOCK_DISCOUNT_AMOUNT_SS ,
                 V_LOCK_RESOURCE_AMOUNT_SS,
                 V_LOCK_RECEIVED_AMOUNT_SS_DP,
                 V_LOCK_DISCOUNT_AMOUNT_SS_DP
          From CIMS.t_Pln_Lg_Order_Head A,CIMS.t_Pln_Lg_Order_Line B
         Where a.order_head_id = b.order_head_id
           --modi by lizhen 2015-11-30 增加中心发货状态单据
           --MODI BY LIZHEN 2016-05-12 增加已引APS产能可视状态数据计算锁款
           And a.order_head_state In ('20', '23', '381', '679', '1455', '2225', '304')
           And a.entity_id = i.entity_id
           And a.customer_id = i.customer_id
           And a.account_id = i.account_id
           AND NVL(A.CUSTOMIZE_FLAG, 'N') = 'N'
           --And Nvl(b.order_line_state, 'NORMAL') <> 'CLOSED' --ADD BY LIZHEN 2016-06-20已关闭行不计算
           And b.sales_main_type = i.sales_main_type --add by lizhen 2015-09-03
           And a.lock_amount_flag In ('S','RS');

       Exception When Others Then
          V_LOCK_RECEIVED_AMOUNT_SS := 0 ;
          V_LOCK_DISCOUNT_AMOUNT_SS := 0 ;
          V_LOCK_RESOURCE_AMOUNT_SS := 0 ;
          V_LOCK_RECEIVED_AMOUNT_SS_DP := 0;
          V_LOCK_DISCOUNT_AMOUNT_SS_DP := 0;
          ROLLBACK TO SAVEPOINT_KXMX ;
          GOTO HERE ;
       End ;
       
       --hejy3 增加送总部锁款方式
      Begin
          Select nvl(Sum(round(
                         Case
                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED THEN
                             0
                           --20200314 家用直发锁款调整
                           When NVL(A.DOWN_PAY_SCALE,-1) < 0 or NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' Then
                             --单据状态为已送审、已产能可视、中心发货且总部提货订单状态为已中心评审、部分评审（销司模式）
                             --单据状态为已中心评审、部分评审（中心模式）
                             Case
                               When
                                 (a.order_head_state In ('20', '2225', '1455') and ha.submit_to_hq_flag = 'Y')
                                 or a.Submit_To_Hq_Flag = 'Y' Then
                                  greatest(NVL(B.CENTER_AFFIRM_QUANTITY,0)-nvl(B.AFFIRMED_QUANTITY,0)-Nvl(B.Cancel_Qty,0)
                                     -(nvl(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                     -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)),0) --20180328 hejy3 已预约直发数量在发货通知单重算
                               Else 0
                             End
                           Else 0
                         End
                          * DECODE(B.PROJECT_ORDER_TYPE,NULL,NVL(B.List_Price,0),NVL(B.APPLY_LIST_PRICE,0))
                          --add by lizhen 2015-11-30 增加月返计算
                          * (100-DECODE(B.PROJECT_ORDER_TYPE,NULL,Nvl(B.Discount_Rate,0),NVL(B.APPLY_DISCOUNT_RATE,0)) - Nvl(b.ordered_discount_rate, 0))/100
                         ,2)
                        ),0),
                 nvl(Sum(round(
                         Case
                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED THEN
                             0
                           --20200314 家用直发锁款调整
                           When NVL(A.DOWN_PAY_SCALE,-1) < 0 or NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' Then
                             --单据状态为已送审、已产能可视、中心发货且总部提货订单状态为已中心评审、部分评审（销司模式）
                             --单据状态为已中心评审、部分评审（中心模式）
                             Case
                               When
                                 (a.order_head_state In ('20', '2225', '1455') and ha.submit_to_hq_flag = 'Y')
                                 or a.Submit_To_Hq_Flag = 'Y' Then
                                  greatest(NVL(B.CENTER_AFFIRM_QUANTITY,0)-nvl(B.AFFIRMED_QUANTITY,0)-Nvl(B.Cancel_Qty,0)
                                     -(nvl(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                     -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)),0) --20180328 hejy3 已预约直发数量在发货通知单重算
                               Else 0
                             End
                           Else 0
                         End
                         * DECODE(B.PROJECT_ORDER_TYPE,NULL,NVL(B.List_Price,0),NVL(B.APPLY_LIST_PRICE,0))
                            * DECODE(B.PROJECT_ORDER_TYPE,NULL,Nvl(B.Discount_Rate,0),NVL(B.APPLY_DISCOUNT_RATE,0))/100
                         ,2)
                        ),0),
                  0,
                 nvl(Sum((A.DOWN_PAY_SCALE / 100) * round(
                             Case
                               --20200314 家用直发锁款调整
                               WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED 
                                 or NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                 0
                               When A.DOWN_PAY_SCALE > 0 Then
                               --
                                Case
                                  when NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' then
                                    NVL(B.CENTER_AFFIRM_QUANTITY, 0)-Nvl(B.Cancel_Qty, 0)
                                   When (a.order_head_state In ('20', '2225', '1455') and ha.Submit_To_Hq_Flag = 'Y')
                                     or a.Submit_To_Hq_Flag = 'Y' Then
                                     greatest(NVL(B.CENTER_AFFIRM_QUANTITY, 0)-nvl(B.AFFIRMED_QUANTITY, 0)-Nvl(B.Cancel_Qty, 0)
                                       -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                       -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)),0) --20180328 hejy3 已预约直发数量在发货通知单重算
                                   Else 0
                                 End
                                 * DECODE(B.PROJECT_ORDER_TYPE,
                                          NULL,
                                          NVL(B.List_Price, 0),
                                          NVL(B.APPLY_LIST_PRICE, 0))
                                 --add by lizhen 2015-11-30 增加月返计算
                                 * (100 - DECODE(B.PROJECT_ORDER_TYPE,
                                                 NULL,
                                                 Nvl(B.Discount_Rate, 0),
                                                 NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                 Nvl(b.ordered_discount_rate, 0)) / 100
                               Else 0
                             End
                         ,2)
                        ),0),
                 nvl(Sum((A.DOWN_PAY_SCALE / 100) * round(
                               Case
                                 --20200314 家用直发锁款调整
                                 WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED 
                                   or NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                   0
                                 When A.DOWN_PAY_SCALE > 0 Then
                                 --
                                  Case
                                    WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                      NVL(B.CENTER_AFFIRM_QUANTITY, 0)-Nvl(B.Cancel_Qty, 0)
                                     When (a.order_head_state In ('20', '2225', '1455') and ha.Submit_To_Hq_Flag = 'Y')
                                       or a.Submit_To_Hq_Flag = 'Y' Then
                                       greatest(NVL(B.CENTER_AFFIRM_QUANTITY, 0)-nvl(B.AFFIRMED_QUANTITY, 0)-Nvl(B.Cancel_Qty, 0)
                                         -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                         -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)),0) --20180328 hejy3 已预约直发数量在发货通知单重算
                                     Else 0
                                   End
                                   * DECODE(B.PROJECT_ORDER_TYPE,
                                            NULL,
                                            NVL(B.List_Price, 0),
                                            NVL(B.APPLY_LIST_PRICE, 0))
                                   * DECODE(B.PROJECT_ORDER_TYPE,
                                            NULL,
                                            Nvl(B.Discount_Rate, 0),
                                            NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100
                                 Else 0
                               End
                         ,2)
                        ),0)
            Into
                 V_LOCK_RECEIVED_AMOUNT_HQ,
                 V_LOCK_DISCOUNT_AMOUNT_HQ,
                 V_LOCK_RESOURCE_AMOUNT_HQ,
                 V_LOCK_RECEIVED_AMOUNT_HQ_DP,
                 V_LOCK_DISCOUNT_AMOUNT_HQ_DP
          From CIMS.t_Pln_Lg_Order_Head A,CIMS.t_Pln_Lg_Order_Line B,
               cims.t_pln_lg_order_head ha
         Where a.order_head_id = b.order_head_id
           --modi by lizhen 2015-11-30 增加中心发货状态单据
           --MODI BY LIZHEN 2016-05-12 增加已引APS产能可视状态数据计算锁款
           And a.order_head_state In ('20', '23', '381', '679', '1455', '2225', '304')
           And a.entity_id = i.entity_id
           And a.customer_id = i.customer_id
           And a.account_id = i.account_id
           --And Nvl(b.order_line_state, 'NORMAL') <> 'CLOSED' --ADD BY LIZHEN 2016-06-20已关闭行不计算
           And b.sales_main_type = i.sales_main_type --add by lizhen 2015-09-03
           and a.hq_lg_order_head_id = ha.order_head_id(+)
           AND NVL(A.CUSTOMIZE_FLAG, 'N') = 'N'
           And a.lock_amount_flag In ('HQ');
      Exception When Others Then
          V_LOCK_RECEIVED_AMOUNT_HQ := 0 ;
          V_LOCK_DISCOUNT_AMOUNT_HQ := 0 ;
          V_LOCK_RESOURCE_AMOUNT_HQ := 0 ;
          V_LOCK_RECEIVED_AMOUNT_HQ_DP := 0;
          V_LOCK_DISCOUNT_AMOUNT_HQ_DP := 0;
          ROLLBACK TO SAVEPOINT_KXMX ;
          GOTO HERE ;
       End ;
       
       --针对已结转总部主体且发货锁款的提货订单重算锁款 add by liangym2 2017-12-12
      Begin
          Select --锁定客户到款((跨主体总部评审数量-已评审数量+申请数量-送总部评审数量-已取消数量)*价格*(100-扣率-月返)/100)
                 nvl(Sum(round(
                         Case When NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT' Then
                            (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                              * DECODE(B.PROJECT_ORDER_TYPE,NULL,NVL(B.List_Price,0),NVL(B.APPLY_LIST_PRICE,0))
                              * (100-DECODE(B.PROJECT_ORDER_TYPE,NULL,Nvl(B.Discount_Rate,0),NVL(B.APPLY_DISCOUNT_RATE,0)) - Nvl(b.ordered_discount_rate, 0))/100
                         Else 0 End
                         ,2)
                        ),0),
                 nvl(Sum(round(
                         Case When NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT' Then
                            (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                            * DECODE(B.PROJECT_ORDER_TYPE,NULL,NVL(B.List_Price,0),NVL(B.APPLY_LIST_PRICE,0))
                            * DECODE(B.PROJECT_ORDER_TYPE,NULL,Nvl(B.Discount_Rate,0),NVL(B.APPLY_DISCOUNT_RATE,0))/100
                         Else 0 End
                         ,2)
                        ),0),
               0,
               0
            Into
                 V_LOCK_RECEIVED_AMOUNT_PS ,
                 V_LOCK_DISCOUNT_AMOUNT_PS ,
                 V_LOCK_RECEIVED_AMOUNT_PS_DP,
                 V_LOCK_DISCOUNT_AMOUNT_PS_DP
          From CIMS.t_Pln_Lg_Order_Head A,CIMS.t_Pln_Lg_Order_Line B
         Where a.order_head_id = b.order_head_id
           And a.order_head_state In ('20', '23', '381', '679', '1455', '2225', '304')--, '23'
           And a.entity_id = i.entity_id
           And a.customer_id = i.customer_id
           And a.account_id = i.account_id
           --And Nvl(b.order_line_state, 'NORMAL') <> 'CLOSED'
           And b.sales_main_type = i.sales_main_type
           AND B.TRANSFER_HQ_AFFIRMED_QTY > 0
           AND NVL(A.CUSTOMIZE_FLAG, 'N') = 'N'
           --AND A.HQ_LG_ORDER_HEAD_ID IS NOT NULL
           --And a.lock_amount_flag = 'Y'
           ;

       Exception When Others Then
          V_LOCK_RECEIVED_AMOUNT_PS := 0 ;
          V_LOCK_DISCOUNT_AMOUNT_PS := 0 ;
          V_LOCK_RECEIVED_AMOUNT_PS_DP := 0;
          V_LOCK_DISCOUNT_AMOUNT_PS_DP := 0;
          ROLLBACK TO SAVEPOINT_KXMX ;
          GOTO HERE ;
       End ;

       --add by lizhen 2015-12-07 增加计划订单送审锁款，未下达到物流的金额
       --UPDATE BY LHW 2016-03-04
       Begin
            Select Nvl(Sum(round(
                        (Case
                           when nvl(poh.down_pay_scale, -1) < 0 then
                             Case
                      When Poh.Form_State Not In
                           ('23', '32', '248', '303', '304', '306') Then
                       Nvl(Pol.Apply_Qty, 0) - Nvl(Pol.Carry_Qty, 0) - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                         - Nvl(Pol.Cancel_Inv_In_Qty, 0)
                      When Poh.Form_State In ('23', '32') Then
                       Nvl(Pol.Can_Produce_Qty, 0) + Nvl(Pol.Inv_Affirm_Qty, 0)
                       - Nvl(Pol.Carry_Qty, 0) - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                       - Nvl(Pol.Cancel_Inv_In_Qty, 0)
                      Else
                       0
                             End
                           else
                             0
                         end
                         ) * Pol.Item_Price *
                    (100 - Nvl(Pol.Discount_Rate, 0) -
                    Nvl(Pol.Ordered_Discount_Rate, 0)) / 100
                    ,2)
                    ), 0) Lock_Amount,
                Nvl(Sum(round(
                    (Case
                       when nvl(poh.down_pay_scale, -1) < 0 then
                         Case
                      When Poh.Form_State Not In
                           ('23', '32', '248', '303', '304') Then--, '306' 306是已完成状态，不锁款，暂时不改动
                       Nvl(Pol.Apply_Qty, 0) - Nvl(Pol.Carry_Qty, 0) - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                       - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                      When Poh.Form_State In ('23', '32', '306') Then--306是已完成状态，不锁款，暂时不改动
                       Nvl(Pol.Can_Produce_Qty, 0) + Nvl(Pol.Inv_Affirm_Qty, 0)
                       - Nvl(Pol.Carry_Qty, 0) - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                       - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                      Else
                       0
                         End
                       else
                         0
                     end
                    ) * Pol.Item_Price *
                    Nvl(Pol.Discount_Rate, 0) / 100
                    ,2)
                    ), 0) Lock_Discount_Amount,
                    0 Lock_Resource_Amount,
                Nvl(Sum((poh.down_pay_scale/100)*round(
                        (case
                           when poh.down_pay_scale > 0 then
                             Case
                              When Poh.Form_State Not In
                                   ('23', '32', '248', '303', '304', '306') Then
                               Nvl(Pol.Apply_Qty, 0) - Nvl(Pol.Carry_Qty, 0) - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                                 - Nvl(Pol.Cancel_Inv_In_Qty, 0)
                              When Poh.Form_State In ('23', '32') Then
                               Nvl(Pol.Can_Produce_Qty, 0) + Nvl(Pol.Inv_Affirm_Qty, 0)
                               - Nvl(Pol.Carry_Qty, 0) - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                               - Nvl(Pol.Cancel_Inv_In_Qty, 0)
                              Else
                               0
                             End
                           else
                             0
                         end
                         ) * Pol.Item_Price *
                    (100 - Nvl(Pol.Discount_Rate, 0) -
                    Nvl(Pol.Ordered_Discount_Rate, 0)) / 100
                    ,2)
                    ), 0) Lock_Downpay_Amount,
                Nvl(Sum((poh.down_pay_scale/100)*round(
                    (case
                       when poh.down_pay_scale > 0 then
                         Case
                          When Poh.Form_State Not In
                               ('23', '32', '248', '303', '304') Then--, '306' 306是已完成状态，不锁款，暂时不改动
                           Nvl(Pol.Apply_Qty, 0) - Nvl(Pol.Carry_Qty, 0) - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                           - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                          When Poh.Form_State In ('23', '32', '306') Then--306是已完成状态，不锁款，暂时不改动
                           Nvl(Pol.Can_Produce_Qty, 0) + Nvl(Pol.Inv_Affirm_Qty, 0)
                           - Nvl(Pol.Carry_Qty, 0) - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                           - Nvl(Pol.Cancel_Inv_Check_Qty, 0)
                          Else
                           0
                         End
                       else
                         0
                     end
                    ) * Pol.Item_Price *
                    Nvl(Pol.Discount_Rate, 0) / 100
                    ,2)
                    ), 0) Lock_Downpay_Disamount
          Into
            V_LOCK_RECEIVED_AMOUNT_PLN,
            V_LOCK_DISCOUNT_AMOUNT_PLN,
            V_LOCK_RESOURCE_AMOUNT_PLN,
            V_LOCK_RECEIVED_AMOUNT_PLN_DP,
            V_LOCK_DISCOUNT_AMOUNT_PLN_DP
           From t_Pln_Order_Head Poh,
                t_Pln_Order_Line Pol,
                t_Pln_Order_Type Pot
          Where Pot.Order_Type_Id = Poh.Order_Type_Id
            And Poh.Order_Head_Id = Pol.Order_Head_Id
            And Poh.Lock_Amount_Flag = 'S'
            And Poh.Form_State Not In ('19', '248', '303', '304', '305')
            And Poh.entity_id = i.entity_id
            And Poh.customer_id = i.customer_id
            And Poh.account_id = i.account_id
            --2017-05-18 梁颜明 锁款大类取订单行 如果为空 则取产品大类
            AND (
            POL.SALES_MAIN_TYPE = i.sales_main_type
            OR (POL.SALES_MAIN_TYPE IS NULL
            AND EXISTS (SELECT 1 FROM t_Bd_Item BI
            WHERE Bi.Item_Id = Pol.Item_Id
            And Bi.Entity_Id = Pol.Entity_Id
            AND Bi.sales_main_type = i.sales_main_type)
            )
            )
            ;
       Exception
         When Others Then
           V_LOCK_RECEIVED_AMOUNT_PLN := 0;
           V_LOCK_DISCOUNT_AMOUNT_PLN := 0;
           V_LOCK_RESOURCE_AMOUNT_PLN := 0;
           V_LOCK_RECEIVED_AMOUNT_PLN_DP := 0;
           V_LOCK_DISCOUNT_AMOUNT_PLN_DP := 0;
           ROLLBACK TO SAVEPOINT_KXMX ;
           GOTO HERE ;
       End;
       
       --锁款明细
      BEGIN
        SELECT NVL(SUM(D.LOCKED_AMOUNT), 0),
               NVL(SUM(D.LOCKED_DISCOUNT_AMOUNT), 0),
               0,
               NVL(SUM(D.LOCKED_DOWNPAY_AMOUNT), 0),
               NVL(SUM(D.LOCKED_DOWNPAY_AMOUNT), 0)
          INTO V_LOCK_RECEIVED_AMOUNT_NEW,
               V_LOCK_DISCOUNT_AMOUNT_NEW,
               V_LOCK_RESOURCE_AMOUNT_NEW,
               V_LOCK_RECEIVED_AMOUNT_NEW_DP,
               V_LOCK_DISCOUNT_AMOUNT_NEW_DP
          FROM T_CREDIT_LOCK_AMOUNT_DETAIL D
         WHERE D.ENTITY_ID = i.entity_id
           And D.CUSTOMER_ID = i.customer_id
           And D.ACCOUNT_ID = i.account_id
           And D.SALES_MAIN_TYPE = i.sales_main_type;
      EXCEPTION
        WHEN OTHERS THEN
          V_LOCK_RECEIVED_AMOUNT_NEW := 0;
          V_LOCK_DISCOUNT_AMOUNT_NEW := 0;
          V_LOCK_RESOURCE_AMOUNT_NEW := 0;
          V_LOCK_RECEIVED_AMOUNT_NEW_DP := 0;
          V_LOCK_DISCOUNT_AMOUNT_NEW_DP := 0;
          ROLLBACK TO SAVEPOINT_KXMX ;
          GOTO HERE ;
      END;
       
      --从政策转资源返利单，获取资源金额
      Begin
         Select nvl(sum(b.discount_amount),0)
           Into V_RESOURCE_AMOUNT
          From T_Pol_Discount_Order a, T_Pol_Discount_Lines b
         Where A.Discount_Order_Id = B.Discount_Order_Id
           And A.Discount_Method = '7' --折让方式：7：政策转资源
           And A.Status = '9' --已确认
           And A.ORDER_TYPE_ID In (1, 2) --1：返利单 2：红冲单
           And A.ENTITY_ID = I.ENTITY_ID
           And A.CUSTOMER_ID = I.CUSTOMER_ID
           And A.ACCOUNT_ID = I.ACCOUNT_ID
           And A.SALES_MAIN_TYPE = I.SALES_MAIN_TYPE ;

       Exception When Others Then
          V_RESOURCE_AMOUNT := 0 ;
          ROLLBACK TO SAVEPOINT_KXMX ;
          GOTO HERE ;
       End ;


       --从政策转资源返利单，获取资源金额
       Begin
         Select nvl(Sum(t.approval_amount_total),0)
           Into V_TRANSACTION_AMOUNT
          From T_PMT_COLLAR_SEND_HEAD t
         Where t.order_type = '03' --资源发放单
           --And t.status = '' --发放单状态
           And t.ENTITY_ID = I.ENTITY_ID
           And t.CUSTOMER_ID = I.CUSTOMER_ID
           And t.ACCOUNT_ID = I.ACCOUNT_ID
           And t.SALES_MAIN_TYPE = I.SALES_MAIN_TYPE ;

       Exception When Others Then
          V_TRANSACTION_AMOUNT := 0 ;
          ROLLBACK TO SAVEPOINT_KXMX ;
          GOTO HERE ;
       End ;

      V_RECEIVED_AMOUNT := ROUND(V_RECEIVED_AMOUNT,2) ;
      V_SALES_AMOUNT := ROUND(V_SALES_AMOUNT,2) ;
      --V_LOCK_RECEIVED_AMOUNT := ROUND((V_LOCK_RECEIVED_AMOUNT - V_LOCK_RECEIVED_AMOUNT_FHCX),2);
      --V_LOCK_RECEIVED_AMOUNT := ROUND((V_LOCK_RECEIVED_AMOUNT + V_LOCK_RECEIVED_AMOUNT_SHIP + V_LOCK_RECEIVED_AMOUNT_DOC),2) ;
      V_LOCK_RECEIVED_AMOUNT := ROUND((V_LOCK_RECEIVED_AMOUNT + V_LOCK_RECEIVED_AMOUNT_SHIP
                                     + V_LOCK_RECEIVED_AMOUNT_DOC + V_LOCK_RECEIVED_AMOUNT_SS
                                     --2016-09-13 add by liangym2 锁款拆成全额以及订金部分
                                     + V_LOCK_RECEIVED_AMOUNT_SS_DP
                                     + V_LOCK_RECEIVED_AMOUNT_PS + V_LOCK_RECEIVED_AMOUNT_PS_DP
                                     --2017-07-19 add by liangym2 重算增加制定发货计划（直发客户）部分
                                     + V_LOCK_RECEIVED_AMOUNT_T_SHIP + V_LOCK_RECEIVED_AMOUNT_T_DOC
                                     --ADD BY LIZHEN 2015-12-07 增加计划订单送审金额
                                     --计划订单锁订金
                                     + V_LOCK_RECEIVED_AMOUNT_PLN + V_LOCK_RECEIVED_AMOUNT_PLN_DP
                                     --hejy3 增加送总部时锁定到款方式
                                     + V_LOCK_RECEIVED_AMOUNT_HQ + V_LOCK_RECEIVED_AMOUNT_HQ_DP
                                     + V_LOCK_RECEIVED_AMOUNT_NEW + V_LOCK_RECEIVED_AMOUNT_NEW_DP),2) ;
      V_DELAYPAY_AMOUNT := ROUND(V_DELAYPAY_AMOUNT,2);
      V_TEMP_DELAYPAY_AMOUNT := ROUND(V_TEMP_DELAYPAY_AMOUNT,2);
      V_DISCOUNT_AMOUNT := ROUND(V_DISCOUNT_AMOUNT,2) ;
      V_APPLIED_DISCOUNT_AMOUNT := ROUND(V_APPLIED_DISCOUNT_AMOUNT,2);
      V_FREEZE_DISCOUNT_AMOUNT := ROUND(V_FREEZE_DISCOUNT_AMOUNT,2) ;
      V_FREEZE_DELAY_AMOUNT := ROUND(V_FREEZE_DELAY_AMOUNT,2) ;
      --V_LOCK_DISCOUNT_AMOUNT := ROUND((V_LOCK_DISCOUNT_AMOUNT_SHIP + V_LOCK_DISCOUNT_AMOUNT_DOC),2);
      V_LOCK_DISCOUNT_AMOUNT := ROUND((V_LOCK_DISCOUNT_AMOUNT_SHIP + V_LOCK_DISCOUNT_AMOUNT_DOC
                                      +V_LOCK_DISCOUNT_AMOUNT_SS
                                     --2017-07-17 add by liangym2 锁定折扣金额拆成全额以及折扣订金部分
                                     + V_LOCK_DISCOUNT_AMOUNT_SS_DP
                                     + V_LOCK_DISCOUNT_AMOUNT_PS + V_LOCK_DISCOUNT_AMOUNT_PS_DP
                                     --2017-07-19 add by liangym2 重算增加制定发货计划（直发客户）部分
                                     + V_LOCK_DISCOUNT_AMOUNT_T_SHIP + V_LOCK_DISCOUNT_AMOUNT_T_DOC
                                      --ADD BY LIZHEN 2015-12-07 增加计划订单送审折扣金额
                                      --计划订单锁订金
                                      + V_LOCK_DISCOUNT_AMOUNT_PLN + V_LOCK_DISCOUNT_AMOUNT_PLN_DP
                                      --hejy3 增加送总部时锁定到款方式
                                      + V_LOCK_DISCOUNT_AMOUNT_HQ + V_LOCK_DISCOUNT_AMOUNT_HQ_DP
                                      + V_LOCK_DISCOUNT_AMOUNT_NEW + V_LOCK_DISCOUNT_AMOUNT_NEW_DP),2);
      V_THREE_NOT_PAY := ROUND(V_THREE_NOT_PAY,2) ;
      --add by 苏冬渊 2015-08-26 资源金额
      V_RESOURCE_AMOUNT := round(V_RESOURCE_AMOUNT,2) ;
      V_LOCK_RESOURCE_AMOUNT := ROUND(V_LOCK_RESOURCE_AMOUNT_SHIP + V_LOCK_RESOURCE_AMOUNT_DOC + V_LOCK_RESOURCE_AMOUNT_SS
                                --ADD BY LIZHEN 2015-12-07 增加计划订单资源金额
                                + V_LOCK_RESOURCE_AMOUNT_PLN
                                --hejy3 增加送总部时锁定到款方式
                                + V_LOCK_RESOURCE_AMOUNT_HQ
                                + V_LOCK_RESOURCE_AMOUNT_NEW,2) ;
      V_TRANSACTION_AMOUNT := Round(V_TRANSACTION_AMOUNT,2) ;

      --到款金额
      IF I.RECEIVED_AMOUNT <> V_RECEIVED_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.RECEIVED_AMOUNT = ' || V_RECEIVED_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '到款金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_RECEIVED_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.RECEIVED_AMOUNT ;
      END IF ;
      --销售金额
      IF I.Sales_Amount <> V_SALES_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.SALES_AMOUNT = ' || V_SALES_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '销售金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_SALES_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.SALES_AMOUNT ;
      END IF ;
      --锁定到款金额
      IF I.Lock_Received_Amount <> V_LOCK_RECEIVED_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.LOCK_RECEIVED_AMOUNT = ' || V_LOCK_RECEIVED_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '锁定到款金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_LOCK_RECEIVED_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Lock_Received_Amount ;
      END IF ;
      --铺底金额
      IF I.Delaypay_Amount <> V_DELAYPAY_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.DELAYPAY_AMOUNT = ' || V_DELAYPAY_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '铺底额度' ;
         TRANS_TABLE(K).R_AMOUNT      := V_DELAYPAY_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Delaypay_Amount ;
      END IF ;
      --临时铺底金额
      IF I.Temp_Delaypay_Amount <> V_TEMP_DELAYPAY_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.TEMP_DELAYPAY_AMOUNT = ' || V_TEMP_DELAYPAY_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '临时额度' ;
         TRANS_TABLE(K).R_AMOUNT      := V_TEMP_DELAYPAY_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Temp_Delaypay_Amount ;
      END IF ;
      --扣率折让金额
      IF I.Discount_Amount <> V_DISCOUNT_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.DISCOUNT_AMOUNT = ' || V_DISCOUNT_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '折让金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_DISCOUNT_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Discount_Amount ;
      END IF ;
      --核销扣率折让金额
      IF I.Applied_Discount_Amount <> V_APPLIED_DISCOUNT_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.APPLIED_DISCOUNT_AMOUNT = ' || V_APPLIED_DISCOUNT_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '核销折让金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_APPLIED_DISCOUNT_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Applied_Discount_Amount ;
      END IF ;
      --冻结扣率折让金额
      IF I.Freeze_Discount_Amount <> V_FREEZE_DISCOUNT_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.FREEZE_DISCOUNT_AMOUNT = ' || V_FREEZE_DISCOUNT_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '冻结折让金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_FREEZE_DISCOUNT_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Freeze_Discount_Amount ;
      END IF ;
      --冻结保证金
      IF I.FREEZE_DELAY_AMOUNT <> V_FREEZE_DELAY_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.FREEZE_DELAY_AMOUNT = ' || V_FREEZE_DELAY_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '冻结保证金' ;
         TRANS_TABLE(K).R_AMOUNT      := V_FREEZE_DELAY_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.FREEZE_DELAY_AMOUNT ;
      END IF ;
      --锁定扣率折让金额
      IF I.Lock_Discount_Amount <> V_LOCK_DISCOUNT_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.LOCK_DISCOUNT_AMOUNT = ' || V_LOCK_DISCOUNT_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '锁定折让金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_LOCK_DISCOUNT_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Lock_Discount_Amount ;
      END IF ;
      --未解付金额
      /*IF I.Dispay_Amount <> V_DISPAY_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.DISPAY_AMOUNT = ' || V_DISPAY_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '未解付金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_DISPAY_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Dispay_Amount ;
      END IF ;*/
      --三方承兑未解付金额
      IF I.Three_Not_Pay <> V_THREE_NOT_PAY THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.THREE_NOT_PAY = ' || V_THREE_NOT_PAY;
         TRANS_TABLE(K).R_AMOUNT_NAME := '三方承兑未解付金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_THREE_NOT_PAY ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Three_Not_Pay ;
      END IF ;
      --资源金额
      IF I.Resource_Amount <> V_RESOURCE_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.RESOURCE_AMOUNT = ' || V_RESOURCE_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '资源金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_RESOURCE_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Resource_Amount ;
      END IF ;
      --锁定资源金额
      IF I.Lock_Resource_Amount <> V_LOCK_RESOURCE_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.LOCK_RESOURCE_AMOUNT = ' || V_LOCK_RESOURCE_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '锁定资源金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_LOCK_RESOURCE_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Lock_Resource_Amount ;
      END IF ;
      --核销资源金额
      IF I.Transaction_Amount <> V_TRANSACTION_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.TRANSACTION_AMOUNT = ' || V_TRANSACTION_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '核销资源金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_TRANSACTION_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.TRANSACTION_AMOUNT ;
      END IF ;
      
      V_UPDATE_COLS := V_UPDATE_COLS || ',T.FREEZE_RECEIVED_AMOUNT = ' || V_RECEIVED_AMOUNT_FREEZE;
      V_UPDATE_COLS := V_UPDATE_COLS || ',T.FREEZE_SALES_AMOUNT = ' || V_SALES_AMOUNT_FREEZE;
      
      --如果没有变更字段（说明金额都能对应上），则直接跳过当前循环
      IF NVL(V_UPDATE_COLS,'0') = '0' THEN
         GOTO HERE ;
      END IF ;

      IF IS_USER_CODE IS NOT NULL THEN
        V_UPDATE_COLS := V_UPDATE_COLS || ',T.LAST_UPDATE_DATE = SYSDATE';
        V_UPDATE_COLS := V_UPDATE_COLS || ',T.LAST_UPDATED_BY = ''' || NVL(IS_USER_CODE,'款项明细重算') || '''';
      END IF;
      V_UPDATE_COLS := SUBSTR(V_UPDATE_COLS,2) ;
      V_UPDATE_WHERE := ' WHERE T.ACCOUNT_AMOUNT_MX_ID = ''' || I.ACCOUNT_AMOUNT_MX_ID || '''';

      V_SQL := V_UPDATE_TABLE || V_UPDATE_COLS || V_UPDATE_WHERE ;

      BEGIN
        --执行款项明细变更
        EXECUTE IMMEDIATE V_SQL ;
        --记录变更历史
        FOR J IN 1 .. TRANS_TABLE.COUNT LOOP
        INSERT INTO t_sales_amount_trans
            ( trans_id,   --事务ID
              entity_id,   --主体ID
              sales_year_id,   --销售年度ID
              customer_id,   --客户ID
              account_id,   --账户ID
              credit_group_id, --额度组ID
              proj_number,   --项目号
              sales_main_type,   --营销大类ID
              order_id,   --单据ID
              order_type,   --单据类型
              action_flag,   --动作标识
              trans_action,   --事务动作（1：增加；2：减少；3：变更）
              amount_name,   --款项名称
              amount,   --金额
              due_flag,   --处理标识（1：成功；2：失败）
              created_by,   --创建人
              creation_date,   --创建日期
              last_updated_by,   --最后修改人
              last_update_date,   --最后修改日期
              pre_field_01,
              pre_field_02,
              pre_field_03,
              pre_field_04,
              pre_field_05,
              pre_field_06 )
       VALUES
            ( S_sales_amount_trans.Nextval ,   --事务ID
              I.ENTITY_ID,   --主体ID
              NULL ,   --销售年度ID
              I.CUSTOMER_ID,   --客户ID
              I.ACCOUNT_ID,   --账户ID
              --2017-4-22 获取额度组增加账户ID liangym2
              pkg_credit_tools.FUN_GET_CREDITGROUPID(I.ENTITY_ID,I.CUSTOMER_ID,I.SALES_MAIN_TYPE, I.ACCOUNT_ID),   --额度组ID
              NULL,   --项目号
              I.SALES_MAIN_TYPE,   --营销大类
              0,   --单据ID
              '款项明细重算',   --单据类型
              0,  --动作标识
              3,   --事务动作（1：增加；2：减少；3：变更）
              TRANS_TABLE(J).R_AMOUNT_NAME,   --款项名称
              TRANS_TABLE(J).R_AMOUNT,   --金额
              '1' ,   --处理标识（1：成功；2：失败）
              '款项明细重算',   --创建人
              SYSDATE ,   --创建日期
              NVL(IS_USER_CODE,'款项明细重算'),   --最后修改人
              SYSDATE,   --最后修改日期
              TRANS_TABLE(J).R_PRE_FIELD_01 ,
              NULL,
              NULL,
              NULL,
              NULL,
              NULL
               );
          END LOOP ;
          IF I.Lock_Received_Amount <> V_LOCK_RECEIVED_AMOUNT THEN
            FOR OL IN (
              select *
            from (Select A.ENTITY_ID,A.ORDER_NUMBER,A.ORDER_HEAD_ID,
               A.DOWN_PAY_SCALE,
               a.down_pay_amount,
               a.down_pay_dis_amount,
               a.order_head_state,
               a.lock_amount_flag,
               A.HQ_LG_ORDER_HEAD_ID,
               (A.DOWN_PAY_SCALE / 100) * nvl(Sum(round(Case
                                                          --20200314 家用直发锁款调整
                                                          WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                                            0
                                                          When a.lock_amount_flag = 'S' AND A.DOWN_PAY_SCALE > 0 Then
                                                          --add by lizhen 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                                                          --(NVL(B.Quantity,0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.Cancel_Qty, 0))
                                                          --MODI BY LIZHEN 2016-05-12 增加已引APS产能可视状态(2225)数据计算锁款
                                                           (Case
                                                             WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                               NVL(B.CENTER_AFFIRM_QUANTITY, B.QUANTITY) - NVL(B.CANCEL_QTY, 0)
                                                             When a.order_head_state In ('20', '2225', '1455') Then
                                                              NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,
                                                                         NULL,
                                                                         B.QUANTITY,
                                                                         0,
                                                                         B.QUANTITY,
                                                                         B.CENTER_AFFIRM_QUANTITY),
                                                                  0) - nvl(B.AFFIRMED_QUANTITY, 0) - Nvl(B.Cancel_Qty, 0)
                                                                   - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                                                   -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                                             When a.order_head_state In ('381', '679') Then
                                                              NVL(B.Center_Affirm_Quantity, 0) -
                                                              nvl(B.AFFIRMED_QUANTITY, 0) - Nvl(B.Cancel_Qty, 0)
                                                              -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                                             Else
                                                              0
                                                           End)
                                                          WHEN a.lock_amount_flag = 'HQ' and a.down_pay_scale > 0 then
                                                            case
                                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                                NVL(B.CENTER_AFFIRM_QUANTITY, B.QUANTITY) - NVL(B.CANCEL_QTY, 0)
                                                              when (a.order_head_state In ('20', '2225', '1455') and ha.order_head_state in ('679','381'))
                                                                or a.order_head_state in ('679','381') then
                                                                nvl(b.center_affirm_quantity,0)-nvl(b.affirmed_quantity,0)-nvl(b.cancel_qty,0)
                                                                -(nvl(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                                                -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0))
                                                            end
                                                          WHEN a.lock_amount_flag in ('S', 'HQ') AND A.DOWN_PAY_SCALE = 0 THEN
                                                           0
                                                          Else
                                                           0
                                                        End * DECODE(B.PROJECT_ORDER_TYPE,
                                                                         NULL,
                                                                         NVL(B.List_Price, 0),
                                                                         NVL(B.APPLY_LIST_PRICE, 0))
                                                          --add by lizhen 2015-11-30 增加月返计算
                                                           * (100 - DECODE(B.PROJECT_ORDER_TYPE,
                                                                           NULL,
                                                                           Nvl(B.Discount_Rate, 0),
                                                                           NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                                           Nvl(b.ordered_discount_rate, 0)) / 100,
                                                        2)),
                                              0) as down_p_amount,
               (A.DOWN_PAY_SCALE / 100) * nvl(Sum(round(Case
                                                          --20200314 家用直发锁款调整
                                                          WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                                            0
                                                          When a.lock_amount_flag = 'S' AND A.DOWN_PAY_SCALE > 0 Then
                                                          --add by lizhen 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                                                          --(NVL(B.Quantity,0)- nvl(B.AFFIRMED_QUANTITY,0) - Nvl(B.cancel_qty, 0))
                                                          --MODI BY LIZHEN 2016-05-12 增加已引APS产能可视状态(2225)数据计算锁款
                                                          --如果订单头状态为20,1455,2225，而且订单头的hq_lg_order_head_id不为空，则取中心评审数量
                                                          --如果订单头状态为20,1455,2225，而且订单头的hq_lg_order_head_id为空，则取申请数量
                                                          --NVL(B.Center_Affirm_Quantity,B.Quantity)
                                                           (Case
                                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                                NVL(B.CENTER_AFFIRM_QUANTITY, B.QUANTITY) - NVL(B.CANCEL_QTY, 0)
                                                             When a.order_head_state In ('20', '2225', '1455') Then
                                                              NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,
                                                                         NULL,
                                                                         B.QUANTITY,
                                                                         0,
                                                                         B.QUANTITY,
                                                                         B.CENTER_AFFIRM_QUANTITY),
                                                                  0) - nvl(B.AFFIRMED_QUANTITY, 0) - Nvl(B.Cancel_Qty, 0)
                                                                   - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                                                   -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                                             When a.order_head_state In ('381', '679') Then
                                                              NVL(B.Center_Affirm_Quantity, 0) -
                                                              nvl(B.AFFIRMED_QUANTITY, 0) - Nvl(B.Cancel_Qty, 0)
                                                              -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                                             Else
                                                              0
                                                           End)
                                                          WHEN a.lock_amount_flag = 'HQ' and a.down_pay_scale > 0 then
                                                            case
                                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                                NVL(B.CENTER_AFFIRM_QUANTITY, B.QUANTITY) - NVL(B.CANCEL_QTY, 0)
                                                              when (a.order_head_state In ('20', '2225', '1455') and ha.Submit_To_Hq_Flag = 'Y')
                                                                or a.Submit_To_Hq_Flag = 'Y' then
                                                                nvl(b.center_affirm_quantity,0)-nvl(b.affirmed_quantity,0)-nvl(b.cancel_qty,0)
                                                                -(nvl(b.transfer_hq_affirmed_qty,0)-nvl(b.sended_qty,0))
                                                                -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0))
                                                            end
                                                          Else
                                                           0
                                                        End * DECODE(B.PROJECT_ORDER_TYPE,
                                                                         NULL,
                                                                         NVL(B.List_Price, 0),
                                                                         NVL(B.APPLY_LIST_PRICE, 0)) *
                                                           DECODE(B.PROJECT_ORDER_TYPE,
                                                                  NULL,
                                                                  Nvl(B.Discount_Rate, 0),
                                                                  NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100,
                                                        2)),
                                              0) as dis_down_p_amount
          From CIMS.t_Pln_Lg_Order_Head A, CIMS.t_Pln_Lg_Order_Line B, cims.t_pln_lg_order_head ha
         Where a.order_head_id = b.order_head_id
              --modi by lizhen 2015-11-30 增加中心发货状态单据
              --MODI BY LIZHEN 2016-05-12 增加已引APS产能可视状态数据计算锁款
           And a.order_head_state In
               ('20', '23', '381', '679', '1455', '2225')
           And a.entity_id = I.entity_id
           And a.customer_id = i.customer_id
           And a.account_id = i.account_id
           And Nvl(b.order_line_state, 'NORMAL') <> 'CLOSED' --ADD BY LIZHEN 2016-06-20已关闭行不计算
           --hejy3 增加送总部评审锁款方式
           and a.hq_lg_order_head_id = ha.order_head_id(+)
           And a.lock_amount_flag In ('S', 'RS', 'HQ')
           AND A.DOWN_PAY_SCALE >= 0
         GROUP BY A.ENTITY_ID,A.ORDER_NUMBER,A.ORDER_HEAD_ID,
                  A.DOWN_PAY_SCALE,
                  a.down_pay_amount,
                  a.down_pay_dis_amount,
                  a.order_head_state,
                  a.lock_amount_flag,
                  A.HQ_LG_ORDER_HEAD_ID)
                  where nvl(down_pay_amount,0) <> down_p_amount or nvl(down_pay_dis_amount,0) <> dis_down_p_amount
              ) LOOP
              UPDATE t_Pln_Lg_Order_Head U SET U.down_pay_amount = OL.down_p_amount,
              U.down_pay_dis_amount = OL.dis_down_p_amount
              WHERE U.ORDER_HEAD_ID = OL.ORDER_HEAD_ID;
              
              P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PRC_CREDIT_FUND_RERUN'
                ,'提货订单头订金重算',SUBSTR('主体ID=' ||I.ENTITY_ID || '，客户ID=' ||I.CUSTOMER_ID|| '，账户ID=' ||I.ACCOUNT_ID
             ||'，订单号：'||OL.ORDER_NUMBER ||'，重算前订金、折扣订金：'||OL.down_pay_amount || '、' || OL.down_pay_dis_amount
             ||'，重算后：'||OL.down_p_amount || '、' || OL.dis_down_p_amount,1,240));
             P_ERR_MSG := NULL;
            END LOOP;
          END IF;
          commit;
      EXCEPTION WHEN OTHERS THEN
        P_RESULT := -20000;
        P_ERR_MSG := '款项重算变更款项执行出错！'|| V_NL ||'客户编码：' || I.CUSTOMER_CODE
                                                 || V_NL ||'账户编码：' || I.ACCOUNT_CODE
                                                 || V_NL ||'营销大类编码：' || I.SALES_MAIN_TYPE
                                                 || V_NL || SQLERRM;
       ROLLBACK TO SAVEPOINT_KXMX ;
       GOTO HERE ;
      END ;
      <<HERE>>
      IF V_SUCCESS <> P_ERR_MSG THEN
        P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PRC_CREDIT_FUND_RERUN'
        ,'循环运行出错',SUBSTR(P_ERR_MSG || ',主体ID=' ||IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
     || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE,1,240));
      END IF;
    END LOOP ;
    
    insert into T_BD_ERROR_LOG(ROW_ID,ERROR_CODE,ERROR_FROM,ERROR_DATE,ERROR_DESC,CREATED_DATE)select S_BD_EEROR_LOG.NEXTVAL,'0','CREDIT',sysdate,IN_ENTITY_ID||IN_MOD||IN_MOD_REN||'', sysdate from DUAL;
    commit;
  EXCEPTION WHEN OTHERS THEN
        P_ERR_MSG := '方法执行体异常！'|| SQLERRM;
        P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PRC_CREDIT_FUND_RERUN'
        ,'款项明细重算异常',SUBSTR(P_ERR_MSG || ',主体ID=' ||IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
       || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE,1,240));
  END PRC_CREDIT_FUND_MX_RETURN;   
  
    --款项冻结
  PROCEDURE PRC_CREDIT_FUND_FREEZE(
      IN_ENTITY_ID   IN  NUMBER,    --主体ID
      IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
      IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
      IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
      IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
      IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
      IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
   -- P_ERR_MSG OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  )IS
    P_RESULT  NUMBER ;
    P_ERR_MSG VARCHAR2(4000);
    V_FREEZE_DATE DATE;
  BEGIN
      P_RESULT  := V_SEC_RESULT;
      P_ERR_MSG := V_SUCCESS;
      
       --记录日冻结信息
      IF IS_PRE_ARG IS NULL OR IS_PRE_ARG = 'FREEZE' THEN
         Begin
              V_FREEZE_DATE := TRUNC(SYSDATE-1);
              
              INSERT INTO T_SALES_AMOUNT_HISTORY
              --ADD BY LIANGYM2 2017-6-9 ACCOUNT_AMOUNT_MX_ID
                    (CUST_AMOUNT_ID,ENTITY_ID,PROJ_NUMBER,FREEZE_DATE,CUSTOMER_ID,CUSTOMER_CODE,CUSTOMER_NAME,ACCOUNT_ID,ACCOUNT_CODE,ACCOUNT_NAME,SALES_CENTER_CODE,SALES_CENTER_NAME,SALES_YEAR_ID,SALES_YEAR_NAME,SALES_MAIN_TYPE,RECEIVED_AMOUNT,SALES_AMOUNT,LOCK_RECEIVED_AMOUNT,DELAYPAY_AMOUNT,TEMP_DELAYPAY_AMOUNT,DISCOUNT_AMOUNT,APPLIED_DISCOUNT_AMOUNT,FREEZE_DISCOUNT_AMOUNT,FREEZE_DELAY_AMOUNT,LOCK_DISCOUNT_AMOUNT,DISPAY_AMOUNT,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,PRE_FIELD_01,PRE_FIELD_02,PRE_FIELD_03,PRE_FIELD_04,PRE_FIELD_05,PRE_FIELD_06,THREE_NOT_PAY,RESOURCE_AMOUNT,LOCK_RESOURCE_AMOUNT,TRANSACTION_AMOUNT,FREEZE_RECEIVED_AMOUNT,FREEZE_SALES_AMOUNT,ACCOUNT_AMOUNT_ID,FREEZE_TIME,MPAY_STREAM_AMOUNT,MPAY_CASH_AMOUNT)
              SELECT CUST_AMOUNT_ID,ENTITY_ID,PROJ_NUMBER,FREEZE_DATE,CUSTOMER_ID,CUSTOMER_CODE,CUSTOMER_NAME,ACCOUNT_ID,ACCOUNT_CODE,ACCOUNT_NAME,SALES_CENTER_CODE,SALES_CENTER_NAME,SALES_YEAR_ID,SALES_YEAR_NAME,SALES_MAIN_TYPE,RECEIVED_AMOUNT,SALES_AMOUNT,LOCK_RECEIVED_AMOUNT,DELAYPAY_AMOUNT,TEMP_DELAYPAY_AMOUNT,DISCOUNT_AMOUNT,APPLIED_DISCOUNT_AMOUNT,FREEZE_DISCOUNT_AMOUNT,FREEZE_DELAY_AMOUNT,LOCK_DISCOUNT_AMOUNT,DISPAY_AMOUNT,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE,PRE_FIELD_01,PRE_FIELD_02,PRE_FIELD_03,PRE_FIELD_04,PRE_FIELD_05,PRE_FIELD_06,THREE_NOT_PAY,RESOURCE_AMOUNT,LOCK_RESOURCE_AMOUNT,TRANSACTION_AMOUNT,FREEZE_RECEIVED_AMOUNT,FREEZE_SALES_AMOUNT,ACCOUNT_AMOUNT_ID,FREEZE_TIME,MPAY_STREAM_AMOUNT,MPAY_CASH_AMOUNT
              FROM T_SALES_AMOUNT_FREEZE T
              WHERE ENTITY_ID =  IN_ENTITY_ID
               AND (IN_CUSTOMER_ID IS NULL OR IN_CUSTOMER_ID = T.CUSTOMER_ID)
               AND (IN_ACCOUNT_ID  IS NULL OR IN_ACCOUNT_ID = T.ACCOUNT_ID)
               AND   FREEZE_DATE >=V_FREEZE_DATE 
               AND   FREEZE_DATE<TRUNC(SYSDATE); --插入历史表
             
              DELETE FROM 
                 T_SALES_AMOUNT_FREEZE T
              WHERE 
                     ENTITY_ID =  IN_ENTITY_ID
            AND (IN_CUSTOMER_ID IS NULL OR IN_CUSTOMER_ID = T.CUSTOMER_ID)
            AND (IN_ACCOUNT_ID  IS NULL OR IN_ACCOUNT_ID = T.ACCOUNT_ID)
               AND   FREEZE_DATE >=V_FREEZE_DATE
               AND   FREEZE_DATE<TRUNC(SYSDATE); --删除当天冻结数据

              INSERT INTO t_sales_amount_freeze   --账户款项信息表
                ( cust_amount_id,   --款项ID
                  entity_id,   --经营主体ID
                  proj_number,   --项目号
                  freeze_date,   --冻结日期
                  customer_id,   --客户ID
                  customer_code,   --客户编码
                  customer_name,   --客户名称
                  account_id,   --客户账户ID
                  account_code,   --账户编码
                  account_name,   --账户名称
                  sales_center_code,   --营销中心编码
                  sales_center_name,   --营销中心名称
                  sales_year_id,   --销售年度ID
                  sales_year_name,   --销售年度名称
                  sales_main_type,   --营销大类
                  received_amount,   --到款金额
                  sales_amount,   --销售金额
                  lock_received_amount,   --锁定到款金额
                  delaypay_amount,   --铺底额度
                  temp_delaypay_amount,   --临时额度
                  discount_amount,   --折让金额
                  applied_discount_amount,   --核销折让金额
                  freeze_discount_amount,   --冻结折让金额
                  FREEZE_DELAY_AMOUNT,  --冻结保证金
                  lock_discount_amount,   --锁定折让金额
                  dispay_amount,   --未解付金额
                  RESOURCE_AMOUNT,
                  LOCK_RESOURCE_AMOUNT,
                  Transaction_AMOUNT,
                  created_by,   --创建人
                  creation_date,   --创建日期
                  last_updated_by,   --修改人
                  last_update_date,   --修改日期
                  three_not_pay,
                  FREEZE_RECEIVED_AMOUNT,
                  FREEZE_SALES_AMOUNT
                  --ADD BY LIANGYM2 2017-6-9 ACCOUNT_AMOUNT_MX_ID
                  ,ACCOUNT_AMOUNT_ID
                  ,MPAY_STREAM_AMOUNT--流水金额
                  ,MPAY_CASH_AMOUNT--提现金额
                  )  --三方承兑未解付金额
           Select
                  s_sales_amount_freeze.nextval,   --款项ID
                  t.entity_id,   --经营主体ID
                  t.proj_number,   --项目号
                  V_FREEZE_DATE,   --冻结日期
                  t.CUSTOMER_ID,   --客户ID
                  t.CUSTOMER_CODE,   --客户编码
                  t.CUSTOMER_NAME,   --客户名称
                  t.ACCOUNT_ID,   --客户账户ID
                  t.ACCOUNT_CODE,   --账户编码
                  t.ACCOUNT_NAME,   --账户名称
                  PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(t.ENTITY_ID,t.CUSTOMER_ID,t.ACCOUNT_ID,2),   --营销中心编码
                  PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(t.ENTITY_ID,t.CUSTOMER_ID,t.ACCOUNT_ID,3),   --营销中心名称
                  t.SALES_YEAR_ID,   --销售年度ID
                  TO_CHAR(t.SALES_YEAR_ID),   --销售年度名称
                  t.SALES_MAIN_TYPE,   --营销大类
                  --t.RECEIVED_AMOUNT,   --到款金额
                --  NVL(t.freeze_received_amount,0), --到款金额
                  NVL(f.received_amount_freeze,0), --到款金额  --guibr 20191216
                  --t.SALES_AMOUNT,   --销售金额
                 -- NVL(t.freeze_sales_amount,0), --销售金额
                  NVL(f.sales_amount_freeze,0), --销售金额  ---guibr 20191216
                  --t.LOCK_RECEIVED_AMOUNT,   --锁定到款金额
                  FUN_GET_THIS_AMOUNT(t.entity_id,t.customer_id,t.account_id,t.sales_main_type,NVL(t.lock_received_amount,0),'LOCK_RECEIVED_AMOUNT'), --锁定到款金额
                  t.DELAYPAY_AMOUNT,   --铺底额度
                  t.TEMP_DELAYPAY_AMOUNT,   --临时额度
                  FUN_GET_THIS_AMOUNT(t.entity_id,t.customer_id,t.account_id,t.sales_main_type,NVL(t.DISCOUNT_AMOUNT,0),'DISCOUNT_AMOUNT'),   --折让金额
                  --t.APPLIED_DISCOUNT_AMOUNT,   --核销折让金额
                  FUN_GET_THIS_AMOUNT(t.entity_id,t.customer_id,t.account_id,t.sales_main_type,NVL(t.applied_discount_amount,0),'APPLIED_DISCOUNT_AMOUNT'), --核销折让金额
                  t.FREEZE_DISCOUNT_AMOUNT,   --冻结折让金额
                  T.FREEZE_DELAY_AMOUNT,      --冻结保证金
                  --t.LOCK_DISCOUNT_AMOUNT,   --锁定折让金额
                  FUN_GET_THIS_AMOUNT(t.entity_id,t.customer_id,t.account_id,t.sales_main_type,NVL(t.lock_discount_amount,0),'LOCK_DISCOUNT_AMOUNT'), --锁定折让金额
                  t.DISPAY_AMOUNT,   --折让金额
                  T.RESOURCE_AMOUNT,
                  T.LOCK_RESOURCE_AMOUNT,
                  T.TRANSACTION_AMOUNT,
                  t.CREATED_BY,   --创建人
                  t.CREATION_DATE,   --创建日期
                  NVL(IS_USER_CODE,t.LAST_UPDATED_BY),   --修改人
                  t.LAST_UPDATE_DATE,   --修改日期
                  t.THREE_NOT_PAY,
                  FUN_GET_THIS_AMOUNT(t.entity_id,t.customer_id,t.account_id,t.sales_main_type,t.received_amount,'RECEIVED_AMOUNT'), --到款金额
                  FUN_GET_THIS_AMOUNT(t.entity_id,t.customer_id,t.account_id,t.sales_main_type,t.sales_amount,'SALES_AMOUNT') --销售金额
                  --ADD BY LIANGYM2 2017-6-9 ACCOUNT_AMOUNT_MX_ID
                  ,NVL((SELECT A.ACCOUNT_AMOUNT_ID FROM T_SALES_ACCOUNT_AMOUNT A
                  WHERE A.ENTITY_ID = T.ENTITY_ID
                  AND A.CUSTOMER_ID = T.CUSTOMER_ID
                  AND A.ACCOUNT_ID = T.ACCOUNT_ID
                  AND (A.PROJ_NUMBER = T.PROJ_NUMBER OR (A.PROJ_NUMBER IS NULL OR T.PROJ_NUMBER IS NULL))
                  AND A.CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(T.ENTITY_ID,T.CUSTOMER_ID,T.SALES_MAIN_TYPE,T.ACCOUNT_ID)
                  ),0)
                  ,T.MPAY_STREAM_AMOUNT--流水金额
                  ,T.MPAY_CASH_AMOUNT--提现金额
              From t_sales_account_mx_amount t
              LEFT JOIN T_CREDIT_CONTACT_AMOUNT_FREEZE F
                    ON T.ENTITY_ID = F.ENTITY_ID 
                    AND T.ACCOUNT_ID = F.ACCOUNT_ID 
                    AND T.CUSTOMER_ID = F.CUSTOMER_ID
                    AND T.SALES_MAIN_TYPE = F.SALES_MAIN_TYPE
              WHERE t.ENTITY_ID = IN_ENTITY_ID
              AND (IN_CUSTOMER_ID IS NULL OR IN_CUSTOMER_ID = T.CUSTOMER_ID)
              AND (IN_ACCOUNT_ID  IS NULL OR IN_ACCOUNT_ID = T.ACCOUNT_ID)
              AND (
               f.received_amount_freeze <> 0 OR F.Sales_Amount_Freeze <> 0 OR T.LOCK_RECEIVED_AMOUNT <> 0
              OR T.DELAYPAY_AMOUNT <> 0 OR T.TEMP_DELAYPAY_AMOUNT <> 0 OR T.DISCOUNT_AMOUNT <> 0
              OR T.APPLIED_DISCOUNT_AMOUNT <> 0 OR T.FREEZE_DISCOUNT_AMOUNT <> 0 OR T.LOCK_DISCOUNT_AMOUNT <> 0
              OR T.DISPAY_AMOUNT <> 0 OR T.RESOURCE_AMOUNT <> 0 OR T.LOCK_RESOURCE_AMOUNT <> 0
              OR T.TRANSACTION_AMOUNT <> 0 OR T.THREE_NOT_PAY <> 0 OR T.MPAY_STREAM_AMOUNT <> 0 OR T.MPAY_CASH_AMOUNT <> 0
              OR T.RECEIVED_AMOUNT <> 0 OR T.SALES_AMOUNT <> 0 OR T.FREEZE_DELAY_AMOUNT <> 0
              )
              ; --三方承兑未解付金额
              commit;
          Exception When Others Then
              P_ERR_MSG := '记录日冻结异常！'|| SQLERRM;
              P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PRC_CREDIT_FUND_RERUN'
              ,'款项明细重算异常',SUBSTR(P_ERR_MSG || ',主体ID=' ||IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
           || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE,1,240));
          End ;
      END IF;
      
  EXCEPTION WHEN OTHERS THEN
        P_ERR_MSG := '方法执行体异常！'|| SQLERRM;
        P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PRC_CREDIT_FUND_RERUN'
        ,'款项冻结异常',SUBSTR(P_ERR_MSG || ',主体ID=' ||IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
       || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE,1,240));
  END PRC_CREDIT_FUND_FREEZE;      
      
  
    --重算款项  折扣类款项
  PROCEDURE PRC_CREDIT_FUND_DIS_RETURN(
      IN_ENTITY_ID   IN  NUMBER,    --主体ID
      IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
      IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
      IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
      IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
      IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
      IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
   -- P_ERR_MSG OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  )IS
    P_RESULT  NUMBER ;
    P_ERR_MSG VARCHAR2(4000);
    VT_PARAM_VALUE  T_BD_PARAM_LIST.DEFAULT_VALUE%TYPE;
  BEGIN
      P_RESULT  := V_SEC_RESULT;
      P_ERR_MSG := V_SUCCESS;
      
        BEGIN
          PRC_CREDIT_FUND_RERUN_IMPL(IN_ENTITY_ID
          ,IN_CUSTOMER_ID,IN_ACCOUNT_ID,IS_USER_CODE,IS_REASON,IS_PRE_ARG,IS_FREEZE_DATE);
        EXCEPTION WHEN OTHERS THEN
          P_ERR_MSG := '款项重算异常！'|| SQLERRM;
          P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PRC_CREDIT_FUND_RERUN'
            ,'款项重算异常',SUBSTR(P_ERR_MSG || ',主体ID=' ||IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
             || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE,1,240));
        END;
        

      P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PRC_CREDIT_FUND_RERUN'
        ,'SUCCESS',SUBSTR('款项重算结束，主体ID=' ||IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
        || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE,1,240));
      COMMIT ;-- ADD BY LIANGYM2 2017-8-4
      
      BEGIN
        SELECT PKG_BD.F_GET_PARAM_VALUE_ENTITY_PRIOR(
        'CRE_DIS_TYPE_ENABLE',IN_ENTITY_ID,NULL,NULL) INTO VT_PARAM_VALUE FROM DUAL;
      EXCEPTION WHEN OTHERS THEN
        VT_PARAM_VALUE := 'Y';--即使异常，默认为Y，进行冻结，以防万一，避免因参数获取异常、需要冻结折让款项的主体无法冻结
      END;
      
      PKG_CREDIT_DIS.P_DIS_AMOUNT_FREEZE(IN_ENTITY_ID,VT_PARAM_VALUE
      ,IN_CUSTOMER_ID,IN_ACCOUNT_ID,IS_USER_CODE,IS_REASON,IS_PRE_ARG,IS_FREEZE_DATE);-- ADD BY LIANGYM2 2017-8-4
      COMMIT ;-- ADD BY LIANGYM2 2017-8-4
      
  EXCEPTION WHEN OTHERS THEN
        P_ERR_MSG := '方法执行体异常！'|| SQLERRM;
        P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PRC_CREDIT_FUND_RERUN'
        ,'款项重算异常',SUBSTR(P_ERR_MSG || ',主体ID=' ||IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
       || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE,1,240));
  END PRC_CREDIT_FUND_DIS_RETURN; 
   --------------------------------------------------------------------------------
  /*
  *   创建日期：2014-08-29
  *     创建者：苏冬渊
  *   功能说明：处理信用模块中的款项重算，根据重算之后的款项明细信息重算款项信息
  *   t_sales_account_amount
  *   t_sales_account_mx_amount
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_FUND_RERUN_IMPL
  (
    IN_ENTITY_ID   IN  NUMBER,    --主体ID
    IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
    IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
    IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
    IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
    IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
    IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
    -- P_ERR_MSG OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  )
  IS

    CURSOR CUR_T_SALES_ACCOUNT_AMOUNT IS
    SELECT T.ROWID,T.*
    FROM T_SALES_ACCOUNT_AMOUNT T
    WHERE T.ACTIVE_FLAG = '1' AND ENTITY_ID = IN_ENTITY_ID
      AND (IN_CUSTOMER_ID IS NULL OR IN_CUSTOMER_ID = T.CUSTOMER_ID)
      AND (IN_ACCOUNT_ID  IS NULL OR IN_ACCOUNT_ID = T.ACCOUNT_ID);

    TYPE TRANS_TYPE IS RECORD(R_AMOUNT_NAME  t_sales_amount_trans.Amount_Name%TYPE,
                              R_AMOUNT       t_sales_amount_trans.Amount%TYPE,
                              R_PRE_FIELD_01 t_sales_amount_trans.pre_field_01%TYPE) ;
    TYPE CUR_TRANS_TYPE IS TABLE OF TRANS_TYPE INDEX BY BINARY_INTEGER ;
    TRANS_TABLE CUR_TRANS_TYPE ;

    K NUMBER := 0 ;

    V_UPDATE_TABLE VARCHAR2(4000) ;
    V_UPDATE_COLS  VARCHAR2(4000) ;
    V_UPDATE_WHERE VARCHAR2(4000) ;

    V_SQL     VARCHAR2(4000) ;
    --V_SQL_MX  VARCHAR2(4000) ;


    V_RECEIVED_AMOUNT         T_SALES_ACCOUNT_MX_AMOUNT.RECEIVED_AMOUNT%TYPE := 0 ;             --到款金额
    V_SALES_AMOUNT            T_SALES_ACCOUNT_MX_AMOUNT.SALES_AMOUNT%TYPE := 0 ;                --销售金额
    V_LOCK_RECEIVED_AMOUNT    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_RECEIVED_AMOUNT%TYPE := 0 ;        --锁定到款金额
    V_DELAYPAY_AMOUNT         T_SALES_ACCOUNT_MX_AMOUNT.DELAYPAY_AMOUNT%TYPE := 0 ;             --铺底金额
    V_TEMP_DELAYPAY_AMOUNT    T_SALES_ACCOUNT_MX_AMOUNT.TEMP_DELAYPAY_AMOUNT%TYPE := 0 ;        --临时铺底金额
    V_DISCOUNT_AMOUNT         T_SALES_ACCOUNT_MX_AMOUNT.DISCOUNT_AMOUNT%TYPE := 0 ;             --折让金额
    V_APPLIED_DISCOUNT_AMOUNT T_SALES_ACCOUNT_MX_AMOUNT.APPLIED_DISCOUNT_AMOUNT%TYPE := 0 ;     --核销折让金额
    V_FREEZE_DISCOUNT_AMOUNT  T_SALES_ACCOUNT_MX_AMOUNT.FREEZE_DISCOUNT_AMOUNT%TYPE := 0 ;      --冻结折让金额
    V_LOCK_DISCOUNT_AMOUNT    T_SALES_ACCOUNT_MX_AMOUNT.LOCK_DISCOUNT_AMOUNT%TYPE := 0 ;        --锁定折让金额
    V_DISPAY_AMOUNT           T_SALES_ACCOUNT_MX_AMOUNT.DISPAY_AMOUNT%TYPE := 0 ;               --未解付金额
    V_THREE_NOT_PAY           T_SALES_ACCOUNT_MX_AMOUNT.THREE_NOT_PAY%TYPE := 0 ;               --三方承兑未解付金额
    --ADD BY 苏冬渊 2015-08-26
    V_RESOURCE_AMOUNT         T_SALES_ACCOUNT_MX_AMOUNT.RESOURCE_AMOUNT%Type := 0 ;
    V_LOCK_RESOURCE_AMOUNT    T_SALES_ACCOUNT_MX_AMOUNT.Lock_Resource_Amount%Type := 0 ;
    V_TRANSACTION_AMOUNT      T_SALES_ACCOUNT_MX_AMOUNT.TRANSACTION_AMOUNT%Type := 0 ;
    --ADD BY 梁颜明 2017-08-24
    VT_MPAY_STREAM_AMOUNT     T_SALES_ACCOUNT_MX_AMOUNT.MPAY_STREAM_AMOUNT%TYPE	:= 0;--流水金额
    VT_MPAY_CASH_AMOUNT       T_SALES_ACCOUNT_MX_AMOUNT.MPAY_CASH_AMOUNT%TYPE	:= 0;--提现金额
    -- add by liangym2 2017-10-11
    V_FREEZE_DELAY_AMOUNT  T_SALES_ACCOUNT_MX_AMOUNT.FREEZE_DELAY_AMOUNT%TYPE := 0 ;      --冻结保证金
    --V_CREDIT_GROUP_ID NUMBER ;
    P_RESULT  NUMBER ;
    P_ERR_MSG VARCHAR2(4000);
  BEGIN
    P_RESULT  := V_SEC_RESULT;
    P_ERR_MSG := V_SUCCESS;

    V_UPDATE_TABLE := 'UPDATE T_SALES_ACCOUNT_AMOUNT T SET ' ;
    --V_UPDATE_COLS  := '' ;
    --V_UPDATE_WHERE := ' WHERE T.ROWID = I.ROWID ' ;

    FOR I IN CUR_T_SALES_ACCOUNT_AMOUNT LOOP

        --设置款项重算保存点
        SAVEPOINT SAVEPOINT_KX ;
        --重置变量
        V_UPDATE_COLS  := '' ;
        K := 0 ;
        TRANS_TABLE.DELETE ;

        BEGIN
          SELECT SUM(RECEIVED_AMOUNT) RECEIVED_AMOUNT, --收款金额
                 SUM(SALES_AMOUNT) V_SALES_AMOUNT, --销售金额
                 SUM(LOCK_RECEIVED_AMOUNT) V_LOCK_RECEIVED_AMOUNT, --锁定到款金额
                 SUM(DELAYPAY_AMOUNT) V_DELAYPAY_AMOUNT, --铺底金额
                 SUM(TEMP_DELAYPAY_AMOUNT) V_TEMP_DELAYPAY_AMOUNT, --临时铺底金额
                 SUM(DISCOUNT_AMOUNT) V_DISCOUNT_AMOUNT, --扣率折让金额
                 SUM(APPLIED_DISCOUNT_AMOUNT) V_APPLIED_DISCOUNT_AMOUNT, --核销扣率折让金额
                 SUM(FREEZE_DISCOUNT_AMOUNT) V_FREEZE_DISCOUNT_AMOUNT, --冻结扣率折让金额
                 SUM(FREEZE_DELAY_AMOUNT) V_FREEZE_DELAY_AMOUNT, --冻结保证金
                 SUM(LOCK_DISCOUNT_AMOUNT) V_LOCK_DISCOUNT_AMOUNT, --锁定扣率折让金额
                 SUM(DISPAY_AMOUNT) V_DISPAY_AMOUNT,
                 SUM(THREE_NOT_PAY) V_THREE_NOT_PAY,
                 Sum(T.RESOURCE_AMOUNT) V_RESOURCE_AMOUNT,
                 Sum(T.LOCK_RESOURCE_AMOUNT) V_LOCK_RESOURCE_AMOUNT,
                 Sum(T.TRANSACTION_AMOUNT) V_TRANSACTION_AMOUNT,
                 SUM(T.MPAY_STREAM_AMOUNT) AS MPAY_STREAM_AMOUNT,
                 SUM(T.MPAY_CASH_AMOUNT) AS MPAY_CASH_AMOUNT
            INTO V_RECEIVED_AMOUNT,
                 V_SALES_AMOUNT,
                 V_LOCK_RECEIVED_AMOUNT,
                 V_DELAYPAY_AMOUNT,
                 V_TEMP_DELAYPAY_AMOUNT,
                 V_DISCOUNT_AMOUNT,
                 V_APPLIED_DISCOUNT_AMOUNT,
                 V_FREEZE_DISCOUNT_AMOUNT,
                 V_FREEZE_DELAY_AMOUNT,
                 V_LOCK_DISCOUNT_AMOUNT,
                 V_DISPAY_AMOUNT,
                 V_THREE_NOT_PAY,
                 V_RESOURCE_AMOUNT,
                 V_LOCK_RESOURCE_AMOUNT,--
                 V_TRANSACTION_AMOUNT,
                 VT_MPAY_STREAM_AMOUNT,
                 VT_MPAY_CASH_AMOUNT
            FROM T_SALES_ACCOUNT_MX_AMOUNT T
           WHERE T.ENTITY_ID = I.ENTITY_ID
             AND T.CUSTOMER_ID = I.CUSTOMER_ID
             AND T.ACCOUNT_ID = I.ACCOUNT_ID
             --2017-4-22 获取额度组增加账户ID liangym2
             AND I.CREDIT_GROUP_ID =
                 PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(T.ENTITY_ID,T.CUSTOMER_ID,
                                                        T.SALES_MAIN_TYPE,T.ACCOUNT_ID);
      EXCEPTION WHEN OTHERS THEN
        P_RESULT := -20000;
        P_ERR_MSG := '从款项明细信息表汇总款项信息出错！' || V_NL || SQLERRM;
        ROLLBACK TO SAVEPOINT_KX ;
        GOTO HERE ;
      END ;

      V_RECEIVED_AMOUNT := ROUND(V_RECEIVED_AMOUNT,2) ;
      V_SALES_AMOUNT := ROUND(V_SALES_AMOUNT,2) ;
      V_LOCK_RECEIVED_AMOUNT := ROUND(V_LOCK_RECEIVED_AMOUNT,2);
      V_DELAYPAY_AMOUNT := ROUND(V_DELAYPAY_AMOUNT,2);
      V_TEMP_DELAYPAY_AMOUNT := ROUND(V_TEMP_DELAYPAY_AMOUNT,2);
      V_DISCOUNT_AMOUNT := ROUND(V_DISCOUNT_AMOUNT,2) ;
      V_APPLIED_DISCOUNT_AMOUNT := ROUND(V_APPLIED_DISCOUNT_AMOUNT,2);
      V_FREEZE_DISCOUNT_AMOUNT := ROUND(V_FREEZE_DISCOUNT_AMOUNT,2) ;
      V_FREEZE_DELAY_AMOUNT := ROUND(V_FREEZE_DELAY_AMOUNT,2) ;
      V_LOCK_DISCOUNT_AMOUNT := ROUND(V_LOCK_DISCOUNT_AMOUNT,2);
      --V_DISPAY_AMOUNT := ROUND(V_DISPAY_AMOUNT,2) ;
      V_THREE_NOT_PAY := ROUND(V_THREE_NOT_PAY,2) ;
      --V_RESOURCE_AMOUNT := ROUND(V_RESOURCE_AMOUNT,2) ;

      --到款金额
      IF I.RECEIVED_AMOUNT <> V_RECEIVED_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.RECEIVED_AMOUNT = ' || V_RECEIVED_AMOUNT ;
         TRANS_TABLE(K).R_AMOUNT_NAME := '到款金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_RECEIVED_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.RECEIVED_AMOUNT ;
      END If ;
      --销售金额
      IF I.Sales_Amount <> V_SALES_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.SALES_AMOUNT = ' || V_SALES_AMOUNT ;
         TRANS_TABLE(K).R_AMOUNT_NAME := '销售金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_SALES_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.SALES_AMOUNT ;
      END IF ;
      --锁定到款金额
      IF I.Lock_Received_Amount <> V_LOCK_RECEIVED_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.LOCK_RECEIVED_AMOUNT = ' || V_LOCK_RECEIVED_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '锁定到款金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_LOCK_RECEIVED_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Lock_Received_Amount ;
      END IF ;
      --铺底金额
      IF I.Delaypay_Amount <> V_DELAYPAY_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.DELAYPAY_AMOUNT = ' ||V_DELAYPAY_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '铺底额度' ;
         TRANS_TABLE(K).R_AMOUNT      := V_DELAYPAY_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Delaypay_Amount ;
      END IF ;
      --临时铺底金额
      IF I.Temp_Delaypay_Amount <> V_TEMP_DELAYPAY_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.TEMP_DELAYPAY_AMOUNT = ' || V_TEMP_DELAYPAY_AMOUNT ;
         TRANS_TABLE(K).R_AMOUNT_NAME := '临时额度' ;
         TRANS_TABLE(K).R_AMOUNT      := V_TEMP_DELAYPAY_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Temp_Delaypay_Amount ;
      END IF ;
      --扣率折让金额
      IF I.Discount_Amount <> V_DISCOUNT_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.DISCOUNT_AMOUNT = ' || V_DISCOUNT_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '折让金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_DISCOUNT_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Discount_Amount ;
      END IF ;
      --核销扣率折让金额
      IF I.Applied_Discount_Amount <> V_APPLIED_DISCOUNT_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.APPLIED_DISCOUNT_AMOUNT = ' || V_APPLIED_DISCOUNT_AMOUNT ;
         TRANS_TABLE(K).R_AMOUNT_NAME := '核销折让金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_APPLIED_DISCOUNT_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Applied_Discount_Amount ;
      END IF ;
      --冻结扣率折让金额
      IF I.Freeze_Discount_Amount <> V_FREEZE_DISCOUNT_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.FREEZE_DISCOUNT_AMOUNT = ' || V_FREEZE_DISCOUNT_AMOUNT ;
         TRANS_TABLE(K).R_AMOUNT_NAME := '冻结折让金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_FREEZE_DISCOUNT_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Freeze_Discount_Amount ;
      END IF ;
      --冻结保证金
      IF I.FREEZE_DELAY_AMOUNT <> V_FREEZE_DELAY_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.FREEZE_DELAY_AMOUNT = ' || V_FREEZE_DELAY_AMOUNT ;
         TRANS_TABLE(K).R_AMOUNT_NAME := '冻结保证金' ;
         TRANS_TABLE(K).R_AMOUNT      := V_FREEZE_DELAY_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.FREEZE_DELAY_AMOUNT ;
      END IF ;
      --锁定扣率折让金额
      IF I.Lock_Discount_Amount <> V_LOCK_DISCOUNT_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.LOCK_DISCOUNT_AMOUNT = ' || V_LOCK_DISCOUNT_AMOUNT ;
         TRANS_TABLE(K).R_AMOUNT_NAME := '锁定折让金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_LOCK_DISCOUNT_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Lock_Discount_Amount ;
      END IF ;
      --未解付金额
      IF I.Dispay_Amount <> V_DISPAY_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.DISPAY_AMOUNT = ' || V_DISPAY_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '未解付金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_DISPAY_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Dispay_Amount ;
      END IF ;
      --三方承兑未解付金额
      IF I.Three_Not_Pay <> V_THREE_NOT_PAY THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.THREE_NOT_PAY = ' || V_THREE_NOT_PAY;
         TRANS_TABLE(K).R_AMOUNT_NAME := '三方承兑未解付金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_THREE_NOT_PAY ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Three_Not_Pay ;
      END IF ;

      --资源金额
      IF I.Resource_Amount <> V_RESOURCE_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.RESOURCE_AMOUNT = ' || V_RESOURCE_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '资源金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_RESOURCE_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Resource_Amount ;
      END IF ;
      --锁定资源金额
      IF I.Lock_Resource_Amount <> V_LOCK_RESOURCE_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.LOCK_RESOURCE_AMOUNT = ' || V_LOCK_RESOURCE_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '锁定资源金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_LOCK_RESOURCE_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Lock_Resource_Amount ;
      END IF ;
      --核销资源金额
      IF I.Transaction_Amount <> V_TRANSACTION_AMOUNT THEN
         K := K + 1 ;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.TRANSACTION_AMOUNT = ' || V_TRANSACTION_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '核销资源金额' ;
         TRANS_TABLE(K).R_AMOUNT      := V_TRANSACTION_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := '变更前金额：' || I.Transaction_Amount ;
      END IF ;
      
      IF I.MPAY_STREAM_AMOUNT <> VT_MPAY_STREAM_AMOUNT THEN
        K := K + 1;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.MPAY_STREAM_AMOUNT = ' || VT_MPAY_STREAM_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '流水金额' ;
         TRANS_TABLE(K).R_AMOUNT      := VT_MPAY_STREAM_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := I.MPAY_STREAM_AMOUNT ;
      END IF;
      IF I.MPAY_CASH_AMOUNT <> VT_MPAY_CASH_AMOUNT THEN
        K := K + 1;
         V_UPDATE_COLS := V_UPDATE_COLS || ',T.MPAY_CASH_AMOUNT = ' || VT_MPAY_CASH_AMOUNT;
         TRANS_TABLE(K).R_AMOUNT_NAME := '提现金额' ;
         TRANS_TABLE(K).R_AMOUNT      := VT_MPAY_CASH_AMOUNT ;
         TRANS_TABLE(K).R_PRE_FIELD_01 := I.MPAY_CASH_AMOUNT ;
      END IF;

      --如果没有变更字段（说明金额都能对应上），则直接跳过当前循环
      IF NVL(V_UPDATE_COLS,'0') = '0' THEN
         GOTO HERE ;
      END IF ;

      IF IS_USER_CODE IS NOT NULL THEN
        V_UPDATE_COLS := V_UPDATE_COLS || ',T.LAST_UPDATE_DATE = SYSDATE';
        V_UPDATE_COLS := V_UPDATE_COLS || ',T.LAST_UPDATED_BY = ''' || NVL(IS_USER_CODE,'款项重算') || '''';
      END IF;
      V_UPDATE_COLS := SUBSTR(V_UPDATE_COLS,2) ;
      V_UPDATE_WHERE := ' WHERE T.ACCOUNT_AMOUNT_ID = ''' || I.ACCOUNT_AMOUNT_ID || '''' ;
      V_SQL := V_UPDATE_TABLE || V_UPDATE_COLS || V_UPDATE_WHERE ;
      --执行款项明细变更，记录变更历史
      BEGIN
        EXECUTE IMMEDIATE V_SQL ;
        FOR J IN 1 .. TRANS_TABLE.COUNT LOOP
        INSERT INTO t_sales_amount_trans
            ( trans_id,   --事务ID
              entity_id,   --主体ID
              sales_year_id,   --销售年度ID
              customer_id,   --客户ID
              account_id,   --账户ID
              credit_group_id, --额度组ID
              proj_number,   --项目号
              sales_main_type,   --营销大类
              order_id,   --单据ID
              order_type,   --单据类型
              action_flag,   --动作标识
              trans_action,   --事务动作（1：增加；2：减少；3：变更）
              amount_name,   --款项名称
              amount,   --金额
              due_flag,   --处理标识（1：成功；2：失败）
              created_by,   --创建人
              creation_date,   --创建日期
              last_updated_by,   --最后修改人
              last_update_date,   --最后修改日期
              pre_field_01,
              pre_field_02,
              pre_field_03,
              pre_field_04,
              pre_field_05,
              pre_field_06 )
       VALUES
            ( S_sales_amount_trans.Nextval ,   --事务ID
              I.ENTITY_ID,   --主体ID
              NULL ,   --销售年度ID
              I.CUSTOMER_ID,   --客户ID
              I.ACCOUNT_ID,   --账户ID
              I.CREDIT_GROUP_ID,   --额度组ID
              NULL,   --项目号
              '额度组款项重算',   --营销大类
              0,   --单据ID
              '款项重算',   --单据类型
              0,  --动作标识
              3,   --事务动作（1：增加；2：减少；3：变更）
              TRANS_TABLE(J).R_AMOUNT_NAME,   --款项名称
              TRANS_TABLE(J).R_AMOUNT,   --金额
              '1' ,   --处理标识（1：成功；2：失败）
              '款项重算',   --创建人
              SYSDATE ,   --创建日期
              NVL(IS_USER_CODE,'款项重算'),   --最后修改人
              SYSDATE,   --最后修改日期
              TRANS_TABLE(J).R_PRE_FIELD_01 ,
              NULL,
              NULL,
              NULL,
              NULL,
              NULL
               );
          END LOOP ;
          commit;
      EXCEPTION WHEN OTHERS THEN
        P_RESULT := -20000;
        P_ERR_MSG := '款项重算变更款项执行出错！'|| V_NL ||'客户编码：' || I.CUSTOMER_CODE
                                                 || V_NL ||'账户编码：' || I.ACCOUNT_CODE
                                                 || V_NL ||'额度组ID：' || I.Credit_Group_Id
                                                 || V_NL || SQLERRM;
        ROLLBACK TO SAVEPOINT_KX ;
        GOTO HERE ;
      END ;
      <<HERE>>
      IF V_SUCCESS <> P_ERR_MSG THEN
        P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PRC_CREDIT_FUND_RERUN_IMPL'
        ,'循环运行出错',SUBSTR(P_ERR_MSG || ',主体ID=' ||IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
     || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE,1,240));
      END IF;
      END LOOP ;

  EXCEPTION WHEN OTHERS THEN
      P_ERR_MSG := '方法执行体异常！'|| SQLERRM;
      P_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('PRC_CREDIT_FUND_RERUN_IMPL'
      ,'款项重算异常',SUBSTR(P_ERR_MSG || ',主体ID=' ||IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
     || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE,1,240));
  END; --PRC_CREDIT_FUND_RERUN_IMPL
  
  /**
  *ADD BY LIANGYM2 2017-8-25 临时修复锁款标识
  */
  PROCEDURE PRC_LG_SHIP_DOCL_RERUN
  (
    IN_ENTITY_ID   IN  NUMBER,    --主体ID
    IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
    IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
    IS_ORDER_TYPE  IN  VARCHAR2,--订单类型
    IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
    IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
    IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
    IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
  )
  IS
  BEGIN
    insert into T_TMP_CRE_S_DOC_LINE (SHIP_DOC_LINE_ID
,SHIP_DOC_ID
,SALES_MAIN_TYPE
,ITEM_CODE
,ITEM_DESC
,ITEM_UOM
,ITEM_PRICE
,ITEM_QTY
,AMOUNT
,UNIT_VOLUME
,UNIT_WEIGHT
,TOTAL_VOLUME
,TOTAL_WEIGHT
,SET_FLAG
,ORIGIN_ORIGIN_TYPE
,ORIGIN_ORIGIN_DOC_CODE
,ORIGIN_ORIGIN_HEAD_ID
,ORIGIN_ORIGIN_LINE_ID
,ORIGIN_TYPE
,ORIGIN_ORDER_NUM
,ORIGIN_ORDER_ID
,ORIGIN_LINE_ID
,ORIGIN_SHIP_PLAN_ID
,SALES_ORDER_TYPE_ID
,FACT_SHIP_QTY
,FACT_SHIP_DATE
,CANCEL_QTY
,MONTH_DISCOUNT_RATE
,DISCOUNT_RATE
,CREATED_BY
,CREATION_DATE
,LAST_UPDATED_BY
,LAST_UPDATE_DATE
,REMARK
,THIS_CANCEL_QTY
,SHIP_PLAN_ID
,PROJECT_ORDER_TYPE
,PROJECT_ORDER_NUMBER
,PROJECT_ORDER_HEAD_ID
,PROJECT_ORDER_LINE_ID
,APPLY_LIST_PRICE
,APPLY_DISCOUNT_RATE
,PROJECT_ORDER_FLAG
,SALES_SUB_TYPE
,LOCK_AMOUNT_FLAG
,NEW_SHIP_DOC_ID
,LG_ORDER_REVIEW_FLAG
,AGENT_ORDER_ID
,AGENT_ORDER_NUMBER
,AGENT_ORDER_LINE_ID
,SOURCE_ORDER_NUMBER
,DISCOUNT_TYPE
,TRANSFER_SO_BILL_TYPE_ID
,TRANSFER_DISCOUNT_TYPE
,TRANSFER_PRICE_APPLY_TYPE
,TRANSFER_PRICE_APPLY_ID
,TRANSFER_PRICE_APPLY_CODE
,TRANSFER_PRICE_LINE_ID
,TRANSFER_LIST_PRICE
,TRANSFER_DISCOUNT_RATE
,TRANSFER_MONTH_DISCOUNT_RATE
,PROJ_REG_CODE
,CCS_PROJ_REG_CODE
,TRANSFER_TO_POX_QTY
,SYS_SOURCE_ORDER_NUM
,MATCH_NUMBER
,BEGIN_NUMBER
,TRANSFER_ITEM_MAIN_TYPE
,TRANSFER_LOCK_AMOUNT_FLAG
,ITEM_COMPETITE_ATTR)
select distinct B.SHIP_DOC_LINE_ID
,B.SHIP_DOC_ID
,B.SALES_MAIN_TYPE
,B.ITEM_CODE
,B.ITEM_DESC
,B.ITEM_UOM
,B.ITEM_PRICE
,B.ITEM_QTY
,B.AMOUNT
,B.UNIT_VOLUME
,B.UNIT_WEIGHT
,B.TOTAL_VOLUME
,B.TOTAL_WEIGHT
,B.SET_FLAG
,B.ORIGIN_ORIGIN_TYPE
,B.ORIGIN_ORIGIN_DOC_CODE
,B.ORIGIN_ORIGIN_HEAD_ID
,B.ORIGIN_ORIGIN_LINE_ID
,B.ORIGIN_TYPE
,B.ORIGIN_ORDER_NUM
,B.ORIGIN_ORDER_ID
,B.ORIGIN_LINE_ID
,B.ORIGIN_SHIP_PLAN_ID
,B.SALES_ORDER_TYPE_ID
,B.FACT_SHIP_QTY
,B.FACT_SHIP_DATE
,B.CANCEL_QTY
,B.MONTH_DISCOUNT_RATE
,B.DISCOUNT_RATE
,B.CREATED_BY
,B.CREATION_DATE
,B.LAST_UPDATED_BY
,B.LAST_UPDATE_DATE
,B.REMARK
,B.THIS_CANCEL_QTY
,B.SHIP_PLAN_ID
,B.PROJECT_ORDER_TYPE
,B.PROJECT_ORDER_NUMBER
,B.PROJECT_ORDER_HEAD_ID
,B.PROJECT_ORDER_LINE_ID
,B.APPLY_LIST_PRICE
,B.APPLY_DISCOUNT_RATE
,B.PROJECT_ORDER_FLAG
,B.SALES_SUB_TYPE
,B.LOCK_AMOUNT_FLAG
,B.NEW_SHIP_DOC_ID
,B.LG_ORDER_REVIEW_FLAG
,B.AGENT_ORDER_ID
,B.AGENT_ORDER_NUMBER
,B.AGENT_ORDER_LINE_ID
,B.SOURCE_ORDER_NUMBER
,B.DISCOUNT_TYPE
,B.TRANSFER_SO_BILL_TYPE_ID
,B.TRANSFER_DISCOUNT_TYPE
,B.TRANSFER_PRICE_APPLY_TYPE
,B.TRANSFER_PRICE_APPLY_ID
,B.TRANSFER_PRICE_APPLY_CODE
,B.TRANSFER_PRICE_LINE_ID
,B.TRANSFER_LIST_PRICE
,B.TRANSFER_DISCOUNT_RATE
,B.TRANSFER_MONTH_DISCOUNT_RATE
,B.PROJ_REG_CODE
,B.CCS_PROJ_REG_CODE
,B.TRANSFER_TO_POX_QTY
,B.SYS_SOURCE_ORDER_NUM
,B.MATCH_NUMBER
,B.BEGIN_NUMBER
,B.TRANSFER_ITEM_MAIN_TYPE
,B.TRANSFER_LOCK_AMOUNT_FLAG
,B.ITEM_COMPETITE_ATTR
  From CIMS.t_lg_ship_doc      A,
       CIMS.t_lg_ship_doc_line B,
       cims.T_INV_BILL_TYPES   bill_type, --业务单据类型
       cims.T_INV_SOURCE_TYPES source_type --单据源类型
      ,
       cims.t_pln_order_head   h
 Where A.SHIP_DOC_ID = B.SHIP_DOC_ID
   And A.DOC_STATUS <> '01' --单据状态 00正常 01红冲
   and h.order_head_id = b.origin_order_id
   and h.order_type_code = IS_ORDER_TYPE--'010000015'
   and h.lock_amount_flag = 'Y'
   And A.ENTITY_ID = IN_ENTITY_ID
   and B.sales_order_type_id = bill_type.bill_type_id(+)
   and bill_type.source_type_id = source_type.source_type_id
   And b.lock_amount_flag = 'Y'
   and b.origin_type = '01'
   and source_type.source_type_code = '1008'
   and a.account_code is not null
   and (NVL(B.Item_Qty, 0) - nvl(b.fact_ship_qty, 0) - nvl(b.cancel_qty, 0)) > 0
   and (a.creation_date > trunc(sysdate) or exists
        (select 1
           from cims.t_sales_amount_trans l
          where l.entity_id = IN_ENTITY_ID
            and l.account_id = h.account_id
            and l.action_flag = 0
            and l.amount_name = '锁定到款金额'
            and trunc(l.creation_date) = trunc(a.creation_date + 1)
            and l.created_by in ('款项重算', '款项明细重算')))
AND NOT EXISTS (SELECT 1 FROM T_TMP_CRE_S_DOC_LINE L
WHERE L.SHIP_DOC_LINE_ID = B.SHIP_DOC_LINE_ID
)
;

update t_lg_ship_doc_line b set b.lock_amount_flag = 'N',b.last_update_date = SYSDATE where b.ship_doc_line_id in (
select distinct b.ship_doc_line_id
  From CIMS.t_lg_ship_doc      A,
       CIMS.t_lg_ship_doc_line B,
       cims.T_INV_BILL_TYPES   bill_type, --业务单据类型
       cims.T_INV_SOURCE_TYPES source_type --单据源类型
      ,
       cims.t_pln_order_head   h
 Where A.SHIP_DOC_ID = B.SHIP_DOC_ID
   And A.DOC_STATUS <> '01' --单据状态 00正常 01红冲
   and h.order_head_id = b.origin_order_id
   and h.order_type_code = IS_ORDER_TYPE--'010000015'
   and h.lock_amount_flag = 'Y'
   And A.ENTITY_ID = IN_ENTITY_ID
   and B.sales_order_type_id = bill_type.bill_type_id(+)
   and bill_type.source_type_id = source_type.source_type_id
   And b.lock_amount_flag = 'Y'
   and b.origin_type = '01'
   and source_type.source_type_code = '1008'
   and a.account_code is not null
   and (NVL(B.Item_Qty, 0) - nvl(b.fact_ship_qty, 0) - nvl(b.cancel_qty, 0)) > 0
   and (a.creation_date > trunc(sysdate) or exists
        (select 1
           from cims.t_sales_amount_trans l
          where l.entity_id = IN_ENTITY_ID
            and l.account_id = h.account_id
            and l.action_flag = 0
            and l.amount_name = '锁定到款金额'
            and trunc(l.creation_date) = trunc(a.creation_date + 1)
            and l.created_by in ('款项重算', '款项明细重算')))
)
and b.lock_amount_flag = 'Y'
;
  EXCEPTION WHEN OTHERS THEN
    NULL;
  END PRC_LG_SHIP_DOCL_RERUN;
  

  /*PROCEDURE 以下为铺底核销的过程 is begin null ; end ;

  --------------------------------------------------------------------------------
  \*
  *   创建日期：2014-10-14
  *     创建者：苏冬渊
  *   功能说明：铺底核销，铺底利息计算调用主函数
  *   1、调用铺底到期过程
      2、调用铺底核销过程
      3、调用铺底利息计算过程
  *\
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_DELAYPAY_MAIN IS

    P_RESULT  NUMBER ;
    P_ERR_MSG VARCHAR2(4000) ;

    V_BRING_ACCRUAL_DAYS T_CREDIT_DELAYPAY.BRING_ACCRUAL_DAYS%TYPE ; --计算利息天数
    V_BRING_ACCRUAL_AMOUNT T_CREDIT_DELAYPAY.Bring_Accrual_Amount%TYPE ; --计算利息金额
    V_ACCRUAL_AMOUNT T_CREDIT_DELAYPAY.ACCRUAL_AMOUNT%TYPE ; --利息金额

  BEGIN
    P_RESULT  := V_SEC_RESULT;
    P_ERR_MSG := V_SUCCESS ;
    --1、调用铺底到期过程
    PRC_CREDIT_DELAYPAY_DUE_DATE ;
    --2、调用铺底核销过程(核销过程中会将到期的铺底进行利息计算)
    PRC_CREDIT_DELAYPAY_APPLIED ;
    --3、调用铺底利息计算过程(三方承兑，跨月的铺底)
    FOR I IN (SELECT T.ROWID,T.* FROM T_CREDIT_DELAYPAY T
               WHERE T.BILL_STATUS = '3'
                 AND NVL(T.DUE_BY,'0') = '0'
                 AND T.Delaypay_Type IN (1,3)) LOOP
      BEGIN
        PRC_CREDIT_DELAYPAY_ACCRUAL(P_BILL_ID => I.BILL_ID ,
                                    P_BRING_ACCRUAL_DAYS => V_BRING_ACCRUAL_DAYS,
                                    P_BRING_ACCRUAL_AMOUNT => V_BRING_ACCRUAL_AMOUNT,
                                    P_ACCRUAL_AMOUNT => V_ACCRUAL_AMOUNT,
                                    P_RESULT => P_RESULT,
                                    P_ERR_MSG => P_ERR_MSG) ;
        IF P_RESULT = V_SEC_RESULT THEN
          UPDATE T_CREDIT_DELAYPAY A
             SET A.BRING_ACCRUAL_DAYS   = V_BRING_ACCRUAL_DAYS,
                 A.BRING_ACCRUAL_AMOUNT = V_BRING_ACCRUAL_AMOUNT,
                 A.ACCRUAL_AMOUNT       = V_ACCRUAL_AMOUNT
           WHERE A.BILL_ID = I.BILL_ID;
        END IF ;
      EXCEPTION WHEN OTHERS THEN
        NULL ;
      END ;
    END LOOP ;

    COMMIT ;

  EXCEPTION WHEN OTHERS THEN
      NULL ;
  END; --PRC_CREDIT_DELAYPAY_MAIN

  --------------------------------------------------------------------------------
  \*
  *   创建日期：2014-10-14
  *     创建者：苏冬渊
  *   功能说明：处理信用模块中的铺底到期
                查询到期日期小于等于当前日期的铺底申请单据，进行到期操作
  *   t_sales_account_amount
  *   t_sales_account_mx_amount
      t_credit_delaypay
  *\
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_DELAYPAY_DUE_DATE IS

    CURSOR CUR_T_CREDIT_DELAYPAY IS
    SELECT T.ROWID, T.*
      FROM T_CREDIT_DELAYPAY T
     WHERE TRUNC(SYSDATE, 'DD') >
           TRUNC(NVL(T.DELAY_DATE, NVL(T.DUE_TIME, T.End_Date)), 'DD')
       AND T.BILL_STATUS = 3
       AND NVL(T.DUE_BY,'0') = '0' ;

    P_RESULT  NUMBER ;
    P_ERR_MSG VARCHAR2(4000) ;
    v_action_type NUMBER ;
    v_order_type  varchar2(30) ;
  BEGIN
    P_RESULT  := V_SEC_RESULT;
    P_ERR_MSG := V_SUCCESS ;

    FOR I IN CUR_T_CREDIT_DELAYPAY LOOP
      --单据没有进行过强制到期时，必须先进行单据的到期操作
       IF I.BILL_TYPE_ID = 1 THEN --常规铺底
          v_action_type := 25 ;
          v_order_type := '常规铺底' ;

       ELSIF I.BILL_TYPE_ID = 2 THEN --超额铺底
          v_action_type := 25 ;
          v_order_type := '超额铺底' ;

       ELSIF I.BILL_TYPE_ID = 3 AND I.DELAYPAY_TYPE <> 8 THEN
          v_action_type := 26 ;
          v_order_type := '临时铺底' ;

       ELSIF I.BILL_TYPE_ID = 3 AND I.DELAYPAY_TYPE = 8 THEN
          v_action_type := 27 ;
          v_order_type := '临时铺底(折让)' ;

       ELSE
          GOTO HERE ;
       END IF ;

       prc_credit_sales_bill(p_entity_id => I.ENTITY_ID,
                             p_action_type => v_action_type,
                             p_settlement_sum => I.APPROVAL_AMOUNT,
                             p_discount_sum => NULL,
                             p_sales_main_type => I.SALES_MAIN_TYPE,
                             p_account_id => I.ACCOUNT_ID,
                             p_customer_id => I.CUSTOMER_ID,
                             p_proj_number => NULL,
                             p_created_mode => NULL,
                             p_order_id => I.BILL_ID,
                             p_order_type => v_order_type,
                             p_username => '铺底核销',
                             p_result => p_result,
                             p_err_msg => p_err_msg);

       IF p_result <> V_SEC_RESULT THEN
          --到期操作失败，跳到下一个到期单据进行处理
          GOTO HERE ;
       END IF ;

       --更新铺底单据相关数据项信息
       BEGIN
         UPDATE T_CREDIT_DELAYPAY T
          SET T.TRANSACTION_AMOUNT = T.APPROVAL_AMOUNT, T.Due_By = '自动到期',
          T.DUE_TIME =
                NVL(I.DELAY_DATE, NVL(I.DUE_TIME, I.End_Date))
          WHERE T.BILL_ID = I.BILL_ID ;
       EXCEPTION WHEN OTHERS THEN
         GOTO HERE ;
       END ;
      <<HERE>>
      null ;
    END LOOP ;

  EXCEPTION WHEN OTHERS THEN
      NULL ;
  END; --PRC_CREDIT_DELAYPAY_DUE_DATE
  --------------------------------------------------------------------------------
  \*
  *   创建日期：2014-10-14
  *     创建者：苏冬渊
  *   功能说明：处理信用模块中的铺底核销
                查询铺底单据未核销金额>0的已经到期的单据，进行核销
  *   处理规则
      *  1、V_AMOUNT 到款余额 >= 0 ,则将所有铺底单据核销（不包括三方铺底）
         2、V_AMOUNT 到款余额 < 0 , V_TEMP_AMOUNT := V_AMOUNT + V_DUE_AMOUNT（V_DUE_AMOUNT：往期逾期金额）
            A、V_TEMP_AMOUNT > 0 : 表示逾期欠款比总欠款多
               1、将逾期的铺底按时间先后核销，将最先到期的铺底核销
               2、当期到期的铺底全部核销。（认为当前到期铺底单据没有发生提货）
            B、V_TEMP_AMOUNT = 0 : 表示逾期欠款跟总欠款一样
               1、当期到期的铺底全部核销。（认为当前到期铺底单据没有发生提货）
            C、V_TEMP_AMOUNT < 0 : 表示逾期欠款比总欠款少（本期到期铺底单据发生了欠款）
               1、将本期铺底单据按照顺序进行部分核销，因为可能提货金额只用了一部分铺底审批金额
               （跨月在先，不跨月在后）
  *\
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_DELAYPAY_APPLIED IS

    CURSOR CUR_T_CREDIT_CUST_INFO IS
    SELECT DISTINCT T.ENTITY_ID,T.CUSTOMER_ID,T.ACCOUNT_ID,PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(T.ENTITY_ID,T.CUSTOMER_ID,T.SALES_MAIN_TYPE) CREDIT_GROUP_ID
      FROM T_CREDIT_DELAYPAY T
     WHERE NVL(T.TRANSACTION_AMOUNT,0) > 0
       AND (T.BILL_STATUS = 3 OR T.BILL_STATUS = 6)
       AND NVL(T.PAYED_FLAG, '0') = 0;
       --AND TRUNC(NVL(T.DELAY_DATE, NVL(T.DUE_TIME, T.PLANPAY_DATE)), 'DD') = TRUNC(SYSDATE,'DD'); --未还清

    CURSOR CUR_T_CREDIT_DELAYPAY(P_ENTITY_ID T_CREDIT_DELAYPAY.ENTITY_ID%TYPE,
                                 P_CUSTOMER_ID T_CREDIT_DELAYPAY.CUSTOMER_ID%TYPE,
                                 P_ACCOUNT_ID T_CREDIT_DELAYPAY.ACCOUNT_ID%TYPE,
                                 P_CREDIT_GROUP_ID Number) IS
     SELECT T.ROWID,T.*,TRUNC(NVL(T.DELAY_DATE, T.PLANPAY_DATE), 'DD') DQ_DATE
       FROM T_CREDIT_DELAYPAY T
      WHERE NVL(T.TRANSACTION_AMOUNT, 0) > 0 --未核销金额
        AND (T.BILL_STATUS = 3 OR T.BILL_STATUS = 6) --单据状态
        AND NVL(T.PAYED_FLAG, '0') = 0 --是否还清
        AND TRUNC(NVL(T.DELAY_DATE,T.PLANPAY_DATE), 'DD') <
            TRUNC(SYSDATE, 'DD') --还款日期小于当前日期
        AND T.ENTITY_ID = P_ENTITY_ID
        AND T.CUSTOMER_ID = P_CUSTOMER_ID
        AND T.ACCOUNT_ID = P_ACCOUNT_ID
        And P_CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(T.ENTITY_ID,T.CUSTOMER_ID,T.SALES_MAIN_TYPE)
        AND T.DELAYPAY_TYPE <> 3 --不包含三方铺底（三方铺底只能用三方到款核销）
        ORDER BY TRUNC(NVL(T.DELAY_DATE,T.PLANPAY_DATE), 'DD') ASC,
        T.DELAYPAY_TYPE DESC ;
    P_RESULT  NUMBER ;
    P_ERR_MSG VARCHAR2(4000) ;

    V_AMOUNT NUMBER := 0 ;  --到款余额
    V_DUE_AMOUNT NUMBER := 0 ; --逾期欠款总金额
    V_TEMP_AMOUNT NUMBER := 0 ; --计算过程中的到款余额
    --V_CREDIT_GROUP_ID T_SALES_ACCOUNT_AMOUNT.CREDIT_GROUP_ID%TYPE ;
    --V_FLAG NUMBER := 0 ; --标识位，当标识位变为1之后，说明款项铺底已经还清
    V_OVERDUE_FLAG T_CREDIT_DELAYPAY.OVERDUE_FLAG%TYPE ; --是否逾期（1：是；0：否）
    V_BRING_ACCRUAL_DAYS T_CREDIT_DELAYPAY.BRING_ACCRUAL_DAYS%TYPE ; --计算利息天数
    V_BRING_ACCRUAL_AMOUNT T_CREDIT_DELAYPAY.Bring_Accrual_Amount%TYPE ; --计算利息金额
    V_ACCRUAL_AMOUNT T_CREDIT_DELAYPAY.ACCRUAL_AMOUNT%TYPE ; --利息金额

    V_PAYED_FLAG T_CREDIT_DELAYPAY.Payed_Flag%TYPE ; --还清标识
    V_PAY_DATE T_CREDIT_DELAYPAY.Pay_Date%TYPE ; --还清日期
    V_TRANSACTION_AMOUNT T_CREDIT_DELAYPAY.Transaction_Amount%TYPE ; --未核销金额

    V_YESTERDAY_DATE Date := (Sysdate - 1) ;
  BEGIN
    P_RESULT  := V_SEC_RESULT;
    P_ERR_MSG := V_SUCCESS ;

    FOR I IN CUR_T_CREDIT_CUST_INFO LOOP

      --根据客户ID和营销大类获取额度组ID
      --V_CREDIT_GROUP_ID := PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(I.CUSTOMER_ID,I.SALES_MAIN_TYPE) ;
      --获取额度组ID失败，则说明该铺底单据是无效的营销大类客户关系产生的铺底单据，不做处理
      \*IF V_CREDIT_GROUP_ID = -1 THEN
        GOTO TWO ;
      END IF;*\
      --根据额度组ID、客户ID、账户ID、主体ID，额组度ID获取到款余额
      --（到款金额RECEIVED_AMOUNT中包含了三方未解锁金额THREE_NOT_PAY，但是THREE_NOT_PAY不能用来核销一般的铺底，所以必须减去）
      BEGIN
        SELECT (T.RECEIVED_AMOUNT - T.SALES_AMOUNT - T.THREE_NOT_PAY)
          INTO V_AMOUNT
         FROM T_SALES_ACCOUNT_AMOUNT T
         WHERE T.ENTITY_ID = I.ENTITY_ID
           AND T.CUSTOMER_ID = I.CUSTOMER_ID
           AND T.ACCOUNT_ID = I.ACCOUNT_ID
           AND T.CREDIT_GROUP_ID = I.CREDIT_GROUP_ID
           AND t.active_flag = '1' ;
      EXCEPTION WHEN OTHERS THEN
        --根据客户、账户、营销大类，没有找到对应的款项信息，作为无效铺底单据处理
        GOTO TWO ;
      END ;
      --获取逾期欠款金额总额
      FOR J IN CUR_T_CREDIT_DELAYPAY(I.ENTITY_ID,I.CUSTOMER_ID,I.ACCOUNT_ID,I.CREDIT_GROUP_ID) LOOP
         IF J.DQ_DATE <> TRUNC(V_YESTERDAY_DATE,'DD') THEN
            V_DUE_AMOUNT := V_DUE_AMOUNT + NVL(J.TRANSACTION_AMOUNT,0) ;
         END IF ;
      END LOOP ;
      --本期的到款余额（不包含逾期铺底的欠款）
      V_TEMP_AMOUNT := V_AMOUNT + V_DUE_AMOUNT ;

     \*** 处理规则
      *  1、V_AMOUNT 到款余额 >= 0 ,则将所有铺底单据核销（不包括三方铺底）
         2、V_AMOUNT 到款余额 < 0 , V_TEMP_AMOUNT := V_AMOUNT + V_DUE_AMOUNT（V_DUE_AMOUNT：往期逾期金额）
            A、V_TEMP_AMOUNT > 0 : 表示逾期欠款比总欠款多
               1、将逾期的铺底按时间先后核销，将最先到期的铺底核销
               2、当期到期的铺底全部核销。（认为当前到期铺底单据没有发生提货）
            B、V_TEMP_AMOUNT = 0 : 表示逾期欠款跟总欠款一样
               1、当期到期的铺底全部核销。（认为当前到期铺底单据没有发生提货）
            C、V_TEMP_AMOUNT < 0 : 表示逾期欠款比总欠款少（本期到期铺底单据发生了欠款）
               1、将本期铺底单据按照顺序进行部分核销，因为可提货金额只用了一部分铺底审批金额
               （跨月在先，不跨月在后）
      *\
      FOR K IN CUR_T_CREDIT_DELAYPAY(I.ENTITY_ID,I.CUSTOMER_ID,I.ACCOUNT_ID,I.CREDIT_GROUP_ID) LOOP

        SAVEPOINT SAVEPOINT_APPLIED ;
        --将是否逾期初始化为逾期
        V_OVERDUE_FLAG := '1' ; --是否逾期（1：是；0：否）
        --到款余额 >= 0 ，说明所有铺底已经还清。
        --需要将所有铺底（包括当期到期的铺底单据）全部核销
        IF V_AMOUNT >= 0 THEN
            --如果今天到期，并且今天能核销，那么将是否逾期标识置为0:未逾期
            IF K.DQ_DATE = TRUNC(V_YESTERDAY_DATE,'DD') THEN
               V_OVERDUE_FLAG := '0' ;
            END IF ;

            V_PAYED_FLAG := '1' ;  --1:已还清
            V_PAY_DATE := SYSDATE ; --还清日期
            V_TRANSACTION_AMOUNT := 0 ; --未核销金额

            GOTO ONE ;
       --到款余额 <= 0
       ELSIF V_AMOUNT < 0 THEN
         \** V_TEMP_AMOUNT > 0 表示逾期欠款比总欠款（认为到款余额就是总的欠款）多
          * 1、将逾期的铺底按时间先后核销，将最先到期的铺底核销
            2、当期到期的铺底全部核销。（认为当前到期铺底单据没有发生提货）
          **\
         IF V_TEMP_AMOUNT > 0 THEN
           IF K.DQ_DATE = TRUNC(V_YESTERDAY_DATE,'DD') THEN
              V_OVERDUE_FLAG := '0' ;--是否逾期（1：是；0：否）

              V_PAYED_FLAG := '1' ;  --1:已还清
              V_PAY_DATE := SYSDATE ; --还清日期
              V_TRANSACTION_AMOUNT := 0 ; --未核销金额

              GOTO ONE ;

           ELSE
              IF V_TEMP_AMOUNT >= NVL(K.TRANSACTION_AMOUNT,0) THEN

                  V_OVERDUE_FLAG := nvl(K.OVERDUE_FLAG,'1') ; --是否逾期（1：是；0：否）
                  V_PAYED_FLAG := '1' ;  --1:已还清
                  V_PAY_DATE := SYSDATE ; --还清日期
                  V_TRANSACTION_AMOUNT := 0 ; --未核销金额
                  --将计算过程中的到款余额减去刚刚核销的金额
                  V_TEMP_AMOUNT := V_TEMP_AMOUNT - NVL(K.TRANSACTION_AMOUNT,0) ;

                  GOTO ONE ;
              ELSE

                  V_OVERDUE_FLAG := nvl(K.OVERDUE_FLAG,'1') ; --是否逾期（1：是；0：否）
                  V_PAYED_FLAG := '0' ;  --0:未还清
                  V_PAY_DATE := K.PAY_DATE ; --还清日期
                  V_TRANSACTION_AMOUNT := NVL(K.TRANSACTION_AMOUNT,0) - V_TEMP_AMOUNT ; --未核销金额

                  V_TEMP_AMOUNT := 0 ;

                  GOTO ONE ;

              END IF ;
           END IF ;
        \** V_TEMP_AMOUNT = 0 表示逾期欠款跟总欠款一样
          * 1、当期到期的铺底全部核销。（认为当前到期铺底单据没有发生提货）
         **\
        ELSIF V_TEMP_AMOUNT = 0 THEN
           IF K.DQ_DATE = TRUNC(V_YESTERDAY_DATE,'DD') THEN

              V_OVERDUE_FLAG := '0' ; --是否逾期（1：是；0：否）
              V_PAYED_FLAG := '1' ;  --1:已还清
              V_PAY_DATE := SYSDATE ; --还清日期
              V_TRANSACTION_AMOUNT := 0 ; --未核销金额

              GOTO ONE ;

            END IF ;
        \** V_TEMP_AMOUNT < 0 表示逾期欠款比总欠款(到款余额)少，那么本期到期的铺底单据就发生了欠款
          * 1、将本期铺底单据按照顺序进行部分核销（跨月在先，不跨月在后）
         **\
        ELSIF V_TEMP_AMOUNT < 0 THEN
           IF K.DQ_DATE = TRUNC(V_YESTERDAY_DATE,'DD') THEN
              --V_TEMP_AMOUNT + K.TRANSACTION_AMOUNT >= 0 说明本张铺底单据的金额只用了一部分，并没有使用完
              IF V_TEMP_AMOUNT + NVL(K.TRANSACTION_AMOUNT,0) >= 0 THEN

                  V_OVERDUE_FLAG := '1' ; --是否逾期（1：是；0：否）
                  V_PAYED_FLAG := '0' ;  --0:未还清，1:已还清
                  V_PAY_DATE := K.PAY_DATE ; --还清日期
                  V_TRANSACTION_AMOUNT := ABS(V_TEMP_AMOUNT) ; --未核销金额
                  --将V_TEMP_AMOUNT已经全分配完成，设为0.继续按V_TEMP_AMOUNT=0操作剩下的到期铺底
                  V_TEMP_AMOUNT := 0 ;

                  GOTO ONE ;
            --V_TEMP_AMOUNT + K.TRANSACTION_AMOUNT < 0 说明本张铺底单据全部用来提货
            --所以不用处理，直接将V_TEMP_AMOUNT变小（因为之前已经进行过到期处理，所以在此不用处理）
              ELSE
                 V_OVERDUE_FLAG := K.OVERDUE_FLAG ; --是否逾期（1：是；0：否）
                 V_PAYED_FLAG := K.PAYED_FLAG ;  --0:未还清，1:已还清
                 V_PAY_DATE := K.PAY_DATE ; --还清日期
                 V_TRANSACTION_AMOUNT := K.TRANSACTION_AMOUNT ; --未核销金额

                 V_TEMP_AMOUNT := V_TEMP_AMOUNT + NVL(K.TRANSACTION_AMOUNT,0) ;
              END IF ;
          END IF ;
        END IF ;
       END IF ;

       --执行利息计算，将对应铺底单据置上相应的信息
        <<ONE>>
        --计算利息
        prc_credit_delaypay_accrual(p_bill_id => K.BILL_ID,
                                    p_bring_accrual_days =>v_bring_accrual_days,
                                    p_bring_accrual_amount => v_bring_accrual_amount,
                                    p_accrual_amount => v_accrual_amount,
                                    p_result => p_result,
                                    p_err_msg => p_err_msg);

        IF p_result < 0 THEN
           ROLLBACK TO SAVEPOINT_APPLIED ;
           GOTO ONE_ONE ;
        END IF ;

        BEGIN
          UPDATE T_CREDIT_DELAYPAY T
             SET T.PAY_DATE             = V_PAY_DATE,
                 T.PAYED_FLAG           = V_PAYED_FLAG,
                 T.BRING_ACCRUAL_DAYS   = v_bring_accrual_days,
                 T.BRING_ACCRUAL_AMOUNT = v_bring_accrual_amount,
                 T.ACCRUAL_AMOUNT       = v_accrual_amount,
                 T.TRANSACTION_AMOUNT   = V_TRANSACTION_AMOUNT,
                 T.OVERDUE_FLAG = V_OVERDUE_FLAG
           WHERE T.BILL_ID = K.BILL_ID ;
        EXCEPTION WHEN OTHERS THEN
            ROLLBACK TO SAVEPOINT_APPLIED ;
            GOTO ONE_ONE ;
        END ;

        \** 如果V_OVERDUE_FLAG = '1' AND T.OVERDUE_FLAG = '0'
            则记录逾期记录
         *\
         IF NVL(V_OVERDUE_FLAG,'0') = '1' AND NVL(K.OVERDUE_FLAG,'0') = '0' THEN
            BEGIN
              INSERT INTO T_CREDIT_BAD_RECORD
                (bad_record_id,
                 entity_id,
                 customer_id,
                 customer_code,
                 customer_name,
                 account_id,
                 account_code,
                 account_name,
                 sales_region_id,
                 sales_region_code,
                 sales_region_name,
                 sales_center_id,
                 sales_center_code,
                 sales_center_name,
                 sales_main_type,
                 bad_record_type,
                 active_flag,
                 created_by,
                 creation_date,
                 last_updated_by,
                 last_update_date,
                 pay_date,
                 counter,
                 bill_id)
              VALUES
                (S_CREDIT_BAD_RECORD.NEXTVAL ,--bad_record_id,
                 K.ENTITY_ID ,--entity_id,
                 K.CUSTOMER_ID ,--customer_id,
                 K.CUSTOMER_CODE ,--customer_code,
                 K.CUSTOMER_NAME ,--customer_name,
                 K.ACCOUNT_ID ,--account_id,
                 K.ACCOUNT_CODE ,--account_code,
                 K.ACCOUNT_NAME ,--account_name,
                 K.SALES_REGION_ID ,--sales_region_id,
                 K.SALES_REGION_CODE ,--sales_region_code,
                 K.SALES_REGION_NAME ,--sales_region_name,
                 K.SALES_CENTER_ID ,--sales_center_id,
                 K.SALES_CENTER_CODE ,--sales_center_code,
                 K.SALES_CENTER_NAME ,--sales_center_name,
                 K.SALES_MAIN_TYPE ,--sales_main_type,
                 '1' ,--bad_record_type, --1-逾期
                 '1' ,--active_flag, --1-有效
                 '自动计算' ,--created_by,
                 SYSDATE ,--creation_date,
                 '自动计算' ,--last_updated_by,
                 SYSDATE ,--last_update_date,
                 NULL ,--pay_date,
                 2 ,--counter, --逾期记2次不良记录，延期记1次
                 K.BILL_ID --bill_id
                 );
              EXCEPTION WHEN OTHERS THEN
                 ROLLBACK TO SAVEPOINT_APPLIED ;
                 GOTO ONE_ONE ;
              END ;
         --如果还清，将不良记录中还清日期记上，有效标识标为无效
         --V_OVERDUE_FLAG  --是否逾期（1：是；0：否）
         --V_PAYED_FLAG 0:未还清，1:已还清
         ELSIF NVL(K.OVERDUE_FLAG,'0') = '1' AND V_PAYED_FLAG = '1' THEN
            BEGIN
              UPDATE T_CREDIT_BAD_RECORD T SET
                  T.PAY_DATE = SYSDATE ,
                  T.ACTIVE_FLAG = '2'
                WHERE T.BILL_ID = K.BILL_ID ;
            EXCEPTION WHEN OTHERS THEN
                ROLLBACK TO SAVEPOINT_APPLIED ;
                GOTO ONE_ONE ;
            END ;
         END IF ;
        <<ONE_ONE>>
        NULL ;
      END LOOP ;
      <<TWO>>
      null ;
    END LOOP ;
  EXCEPTION WHEN OTHERS THEN
      NULL ;
  END; --PRC_CREDIT_DELAYPAY_APPLIED

  --------------------------------------------------------------------------------
  \*
  *   创建日期：2014-10-14
  *     创建者：苏冬渊
  *   功能说明：处理信用模块中的铺底核销
                查询铺底单据到期日期是当天并且未核销金额>0的单据，进行核销
  *   1、用到款余额不能核销逾期的铺底单据，否则到款余额会反复循环的被利用来核销已经逾期的不同的铺底单据
      2、三方承兑的铺底单据只能在解付的时候进行核销，因为解付之后无法区分到款余额中解付的部分
      t_credit_delaypay

      15：收款确认（不包括三方承兑）
      16：收款冲销
      19：三方承兑解付
      20：三方承兑解付冲销
  *\
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_DELAYPAY_APPLIED_AT(P_ACTION_TYPE NUMBER, --动作标识
                                           P_SETTLE_AMOUNT NUMBER, --结算金额
                                           P_ENTITY_ID NUMBER, --主体ID
                                           P_CUSTOMER_ID NUMBER, --客户ID
                                           P_ACCOUNT_ID NUMBER , --账户ID
                                           P_SALES_MAIN_TYPE VARCHAR2, --营销大类
                                           P_CASH_RECEIPT_ID NUMBER , --收款单据ID
                                           P_THREE_PAY_ID NUMBER, --三方承兑ID
                                           P_USERNAME VARCHAR2,
                                           P_RESULT   IN OUT NUMBER, --返回错误ID
                                           P_ERR_MSG  IN OUT VARCHAR2 --返回错误信息
                                           ) IS

    CURSOR CUR_T_CREDIT_DELAYPAY(P_ENTITY_ID T_CREDIT_DELAYPAY.ENTITY_ID%TYPE,
                                 P_CUSTOMER_ID T_CREDIT_DELAYPAY.CUSTOMER_ID%TYPE,
                                 P_ACCOUNT_ID T_CREDIT_DELAYPAY.ACCOUNT_ID%TYPE,
                                 P_SALES_MAIN_TYPE T_CREDIT_DELAYPAY.SALES_MAIN_TYPE%TYPE) IS
     SELECT T.ROWID,
            T.*,
            TRUNC(NVL(T.DELAY_DATE, NVL(T.DUE_TIME, T.PLANPAY_DATE)), 'DD') DQ_DATE
       FROM T_CREDIT_DELAYPAY T
      WHERE NVL(T.TRANSACTION_AMOUNT, 0) > 0
        AND (T.BILL_STATUS = 3 OR T.BILL_STATUS = 6)
        AND NVL(T.PAYED_FLAG, '0') = '0' --未还清
        AND TRUNC(NVL(T.DELAY_DATE, NVL(T.DUE_TIME, T.PLANPAY_DATE)), 'DD') <=
            TRUNC(SYSDATE, 'DD')
        AND T.ENTITY_ID = P_ENTITY_ID
        AND T.CUSTOMER_ID = P_CUSTOMER_ID
        AND T.ACCOUNT_ID = P_ACCOUNT_ID
        AND T.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
      --AND T.DELAYPAY_TYPE <> 3 --不包含三方铺底（三方铺底只能用三方到款核销）
      ORDER BY TRUNC(NVL(T.DELAY_DATE, NVL(T.DUE_TIME, T.PLANPAY_DATE)),
                     'DD') ASC,
               T.DELAYPAY_TYPE DESC;

    V_TEMP_AMOUNT NUMBER := 0 ; --计算过程中的到款余额
    V_THIS_AMOUNT NUMBER := 0 ;  --本次核销金额
    --V_DUE_AMOUNT NUMBER := 0 ; --逾期欠款总金额

    --V_CREDIT_GROUP_ID T_SALES_ACCOUNT_AMOUNT.CREDIT_GROUP_ID%TYPE ;
    --V_FLAG NUMBER := 0 ; --标识位，当标识位变为1之后，说明款项铺底已经还清
    V_OVERDUE_FLAG T_CREDIT_DELAYPAY.OVERDUE_FLAG%TYPE ; --是否逾期（1：是；0：否）
    V_BRING_ACCRUAL_DAYS T_CREDIT_DELAYPAY.BRING_ACCRUAL_DAYS%TYPE ; --计算利息天数
    V_BRING_ACCRUAL_AMOUNT T_CREDIT_DELAYPAY.Bring_Accrual_Amount%TYPE ; --计算利息金额
    V_ACCRUAL_AMOUNT T_CREDIT_DELAYPAY.ACCRUAL_AMOUNT%TYPE ; --利息金额

    V_PAYED_FLAG T_CREDIT_DELAYPAY.Payed_Flag%TYPE ; --还清标识
    V_PAY_DATE T_CREDIT_DELAYPAY.Pay_Date%TYPE ; --还清日期
    V_TRANSACTION_AMOUNT T_CREDIT_DELAYPAY.Transaction_Amount%TYPE ; --未核销金额

  BEGIN
    P_RESULT  := V_SEC_RESULT;
    P_ERR_MSG := V_SUCCESS ;

    V_TEMP_AMOUNT := P_SETTLE_AMOUNT ;

    IF P_ACTION_TYPE NOT IN (15,16,19,20) THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '传入动作标识有问题，铺底即时核销只能是：15-到款，16-到款冲销，19-三方承兑解付，20-三方解付冲销！';
       --RAISE V_BASE_EXCEPTION ;
       RETURN ;
    END IF ;

    IF NVL(P_SETTLE_AMOUNT,-1) = -1 THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '参数结算金额不能为空，请了解！';
       --RAISE V_BASE_EXCEPTION ;
       RETURN ;
    END IF ;
    IF NVL(P_ENTITY_ID,-1) = -1 THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '参数主体ID不能为空，请了解！';
       --RAISE V_BASE_EXCEPTION ;
       RETURN ;
    END IF ;
    IF NVL(P_CUSTOMER_ID,-1) = -1 THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '参数客户ID不能为空，请了解！';
       --RAISE V_BASE_EXCEPTION ;
       RETURN ;
    END IF ;
    IF NVL(P_ACCOUNT_ID,-1) = -1 THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '参数账户ID不能为空，请了解！';
       --RAISE V_BASE_EXCEPTION ;
       RETURN ;
    END IF ;
    IF NVL(P_SALES_MAIN_TYPE,'-1') = '-1' THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '参数营销大类编码不能为空，请了解！';
       --RAISE V_BASE_EXCEPTION ;
       RETURN ;
    END IF ;
    IF NVL(P_CASH_RECEIPT_ID,-1) = -1 THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '参数收款单据ID不能为空，请了解！';
       --RAISE V_BASE_EXCEPTION ;
       RETURN ;
    END IF ;
    IF NVL(P_USERNAME,'-1') = '-1' THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '参数登陆账户名称为空!请检查！';
       --RAISE V_BASE_EXCEPTION ;
       RETURN ;
    END IF ;
    IF P_ACTION_TYPE IN (19,20) AND nvl(P_THREE_PAY_ID,-1) = -1 THEN
         P_RESULT  := -20000;
         P_ERR_MSG := '三方承兑铺底核销时候，三方承兑解付ID不能为空！';
         --RAISE V_BASE_EXCEPTION ;
         RETURN ;
    END IF ;

    IF P_ACTION_TYPE = 15 THEN --收款确认
      FOR I IN CUR_T_CREDIT_DELAYPAY(P_ENTITY_ID,P_CUSTOMER_ID,P_ACCOUNT_ID,P_SALES_MAIN_TYPE) LOOP
          --将是否逾期初始化为逾期
          V_OVERDUE_FLAG := '1' ; --是否逾期（1：是；0：否）
          --假如是三方承兑铺底,则跳过,因为本次动作标识是收款确认，遇到三方逾期铺底单据，则不处理。
          IF I.DELAYPAY_TYPE <> 3 THEN  --3：三方承兑铺底
             IF I.TRANSACTION_AMOUNT <= V_TEMP_AMOUNT THEN
                IF I.DQ_DATE = TRUNC(SYSDATE,'DD') THEN
                   V_OVERDUE_FLAG := '0' ; --是否逾期（1：是；0：否）
                END IF ;

                V_PAYED_FLAG := '1' ;  --1:已还清
                V_PAY_DATE := SYSDATE ; --还清日期
                V_TRANSACTION_AMOUNT := 0 ; --未核销金额

                V_THIS_AMOUNT := I.TRANSACTION_AMOUNT ;
                --V_TEMP_AMOUNT := V_TEMP_AMOUNT - I.TRANSACTION_AMOUNT ;
             ELSE

                V_OVERDUE_FLAG := I.OVERDUE_FLAG ;
                V_PAYED_FLAG := '0' ;  --0:未还清
                V_PAY_DATE := null ; --还清日期
                V_TRANSACTION_AMOUNT := I.TRANSACTION_AMOUNT - V_TEMP_AMOUNT ; --未核销金额
                V_THIS_AMOUNT :=  V_TEMP_AMOUNT ;
                --V_TEMP_AMOUNT := 0 ;
             END IF ;

              V_TEMP_AMOUNT := CASE WHEN (I.TRANSACTION_AMOUNT <= V_TEMP_AMOUNT) THEN (V_TEMP_AMOUNT - I.TRANSACTION_AMOUNT) ELSE 0 END ;
          END IF ;

          --执行利息计算，更新铺底单据信息，记录铺底核销记录历史
          prc_credit_delaypay_accrual(p_bill_id => I.BILL_ID,
                                    p_bring_accrual_days =>v_bring_accrual_days,
                                    p_bring_accrual_amount => v_bring_accrual_amount,
                                    p_accrual_amount => v_accrual_amount,
                                    p_result => p_result,
                                    p_err_msg => p_err_msg);
          --计算利息失败，跳过当前条铺底单据
          IF p_result <> V_SEC_RESULT THEN
             GOTO ONE ;
          END IF ;
          --更新铺底单据核销信息，利息信息
          BEGIN
            UPDATE T_CREDIT_DELAYPAY T
               SET T.PAY_DATE             = V_PAY_DATE,
                   T.PAYED_FLAG           = V_PAYED_FLAG,
                   T.BRING_ACCRUAL_DAYS   = v_bring_accrual_days,
                   T.BRING_ACCRUAL_AMOUNT = v_bring_accrual_amount,
                   T.ACCRUAL_AMOUNT       = v_accrual_amount,
                   T.TRANSACTION_AMOUNT   = V_TRANSACTION_AMOUNT,
                   T.OVERDUE_FLAG         = V_OVERDUE_FLAG
             WHERE T.BILL_ID = I.BILL_ID ;
          EXCEPTION WHEN OTHERS THEN
              GOTO ONE ;
          END ;

         --记录铺底核销表
         BEGIN
            INSERT INTO T_CREDIT_DELAYPA_APPLIED T
              (bill_id,
               applied_id,
               cash_receipt_id,
               three_pay_id,
               applied_amount,
               applied_status,
               created_by,
               creation_date,
               last_updated_by,
               last_update_date)
            VALUES
              (I.BILL_ID,
               S_CREDIT_DELAYPA_APPLIED.NEXTVAL,
               P_CASH_RECEIPT_ID,
               P_THREE_PAY_ID,
               V_THIS_AMOUNT, --本次核销金额
               '1', --核销状态：1：已核销
               P_USERNAME,
               SYSDATE,
               P_USERNAME,
               SYSDATE);
          EXCEPTION WHEN OTHERS THEN
            GOTO ONE ;
          END ;

          --计算过程中的到款余额 V_TEMP_AMOUNT = 0 ，说明到款已经核销完，直接跳出循环
          IF V_TEMP_AMOUNT = 0 THEN
            GOTO TWO ;
          END IF ;
          <<ONE>>
          NULL ;
      END LOOP ;
      <<TWO>>
      NULL ;

    \** 到款冲销，触发铺底核销 回退
        1、根据铺底核销记录表，查找到被核销的铺底单据，将相关标识（还清日期、是否还清、未核销金额）位置上
        2、根据改变之后的状态，计算该铺底的利息信息
        3、将利息信息，更新到该铺底单据上
     *\
    ELSIF P_ACTION_TYPE = 16  THEN --到款冲销
      FOR I IN (SELECT T.ROWID, T.*
                  FROM T_CREDIT_DELAYPA_APPLIED T
                 WHERE T.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID
                   AND NVL(T.APPLIED_STATUS, '1') = '1' --已核销
                   AND NOT EXISTS (SELECT 1
                          FROM T_CREDIT_DELAYPA_APPLIED A
                         WHERE A.CASH_RECEIPT_ID = T.CASH_RECEIPT_ID
                           AND NVL(A.APPLIED_STATUS, '1') = '2')
                   ORDER BY T.APPLIED_ID DESC) LOOP

          IF NVL(I.APPLIED_AMOUNT,0) <= V_TEMP_AMOUNT THEN

             V_PAYED_FLAG := '0' ;  --0:未还清
             V_PAY_DATE := NULL ; --还清日期
             V_TRANSACTION_AMOUNT := NVL(I.APPLIED_AMOUNT,0) ; --未核销金额

             V_THIS_AMOUNT := NVL(I.APPLIED_AMOUNT,0) ;
             V_TEMP_AMOUNT := V_TEMP_AMOUNT - NVL(I.APPLIED_AMOUNT,0) ;

          ELSIF NVL(I.APPLIED_AMOUNT,0) > V_TEMP_AMOUNT THEN

             V_PAYED_FLAG := '0' ;  --0:未还清
             V_PAY_DATE := NULL ; --还清日期
             V_TRANSACTION_AMOUNT := V_TEMP_AMOUNT ; --未核销金额

             V_THIS_AMOUNT := V_TEMP_AMOUNT ;
             V_TEMP_AMOUNT := 0 ;

          END IF ;
          --1、根据铺底核销记录表，查找到被核销的铺底单据，将相关标识（还清日期、是否还清、未核销金额）位置上
          BEGIN
             UPDATE T_CREDIT_DELAYPAY T
               SET T.PAY_DATE             = V_PAY_DATE,
                   T.PAYED_FLAG           = V_PAYED_FLAG,
                   T.TRANSACTION_AMOUNT   = T.TRANSACTION_AMOUNT + V_TRANSACTION_AMOUNT
             WHERE T.BILL_ID = I.BILL_ID ;
         EXCEPTION WHEN OTHERS THEN
           GOTO THREE ;
         END ;

         --2、根据改变之后的状态，计算该铺底的利息信息
         prc_credit_delaypay_accrual(p_bill_id => I.BILL_ID,
                                  p_bring_accrual_days =>v_bring_accrual_days,
                                  p_bring_accrual_amount => v_bring_accrual_amount,
                                  p_accrual_amount => v_accrual_amount,
                                  p_result => p_result,
                                  p_err_msg => p_err_msg);
              --计算利息失败，跳过当前条铺底单据
               IF p_result <> V_SEC_RESULT THEN
                  GOTO THREE ;
               END IF ;

         --3、将利息信息，更新到该铺底单据上
         BEGIN
             UPDATE T_CREDIT_DELAYPAY T
               SET T.BRING_ACCRUAL_DAYS = v_bring_accrual_days,
                   T.Bring_Accrual_Amount = v_bring_accrual_amount,
                   T.Accrual_Amount   = v_accrual_amount
             WHERE T.BILL_ID = I.BILL_ID ;
         EXCEPTION WHEN OTHERS THEN
           GOTO THREE ;
         END ;

         --4、记录铺底核销表
         BEGIN
           INSERT INTO T_CREDIT_DELAYPA_APPLIED T
                    (bill_id,
                     applied_id,
                     cash_receipt_id,
                     three_pay_id,
                     applied_amount,
                     applied_status,
                     created_by,
                     creation_date,
                     last_updated_by,
                     last_update_date)
                  VALUES
                    (I.BILL_ID,
                     S_CREDIT_DELAYPA_APPLIED.NEXTVAL,
                     P_CASH_RECEIPT_ID,
                     P_THREE_PAY_ID,
                     V_THIS_AMOUNT, --本次核销金额
                     '2', --核销状态：1：已冲销
                     P_USERNAME,
                     SYSDATE,
                     P_USERNAME,
                     SYSDATE);
          EXCEPTION WHEN OTHERS THEN
            GOTO THREE ;
          END ;

          IF V_TEMP_AMOUNT = 0 THEN
            GOTO FOUR ;
          END IF ;
          <<THREE>>
          NULL ;
      END LOOP ;
      <<FOUR>>
      NULL ;
    ELSIF P_ACTION_TYPE = 19 THEN --三方承兑解付
      FOR I IN CUR_T_CREDIT_DELAYPAY(P_ENTITY_ID,
                                     P_CUSTOMER_ID,
                                     P_ACCOUNT_ID,
                                     P_SALES_MAIN_TYPE) LOOP
        IF I.DELAYPAY_TYPE = 3 THEN  --3：三方承兑铺底
             IF I.TRANSACTION_AMOUNT <= V_TEMP_AMOUNT THEN

                IF I.DQ_DATE = TRUNC(SYSDATE,'DD') THEN
                    V_OVERDUE_FLAG := '0' ; --是否逾期（1：是；0：否）
                END IF ;

                V_PAYED_FLAG := '1' ;  --1:已还清
                V_PAY_DATE := SYSDATE ; --还清日期
                V_TRANSACTION_AMOUNT := 0 ; --未核销金额

                V_THIS_AMOUNT := I.TRANSACTION_AMOUNT ;
                V_TEMP_AMOUNT := V_TEMP_AMOUNT - I.TRANSACTION_AMOUNT ;
             ELSE
               V_OVERDUE_FLAG := I.OVERDUE_FLAG ;
               V_PAYED_FLAG := '0'; --0:未还清
               V_PAY_DATE := NULL ; --还清日期
               V_TRANSACTION_AMOUNT := I.TRANSACTION_AMOUNT - V_TEMP_AMOUNT ; --未核销金额

               V_THIS_AMOUNT := V_TEMP_AMOUNT ;
               V_TEMP_AMOUNT := 0 ;
             END IF ;

             --计算利息
             prc_credit_delaypay_accrual(p_bill_id => I.BILL_ID,
                                        p_bring_accrual_days =>v_bring_accrual_days,
                                        p_bring_accrual_amount => v_bring_accrual_amount,
                                        p_accrual_amount => v_accrual_amount,
                                        p_result => p_result,
                                        p_err_msg => p_err_msg);
                     --计算利息失败，跳过当前条铺底单据
                     IF p_result <> V_SEC_RESULT THEN
                        GOTO FIVE ;
                     END IF ;
             BEGIN
                UPDATE T_CREDIT_DELAYPAY T
                   SET T.PAY_DATE             = V_PAY_DATE ,
                       T.PAYED_FLAG           = V_PAYED_FLAG,
                       T.BRING_ACCRUAL_DAYS   = v_bring_accrual_days,
                       T.BRING_ACCRUAL_AMOUNT = v_bring_accrual_amount,
                       T.ACCRUAL_AMOUNT       = v_accrual_amount,
                       T.TRANSACTION_AMOUNT   = V_TRANSACTION_AMOUNT,
                       T.OVERDUE_FLAG         = V_OVERDUE_FLAG
                 WHERE T.BILL_ID = I.BILL_ID ;
             EXCEPTION WHEN OTHERS THEN
                GOTO FIVE ;
             END ;
             --记录铺底核销表
             BEGIN
                INSERT INTO T_CREDIT_DELAYPA_APPLIED T
                  (bill_id,
                   applied_id,
                   cash_receipt_id,
                   three_pay_id,
                   applied_amount,
                   applied_status,
                   created_by,
                   creation_date,
                   last_updated_by,
                   last_update_date)
                VALUES
                  (I.BILL_ID,
                   S_CREDIT_DELAYPA_APPLIED.NEXTVAL,
                   P_CASH_RECEIPT_ID,
                   P_THREE_PAY_ID,
                   V_THIS_AMOUNT, --本次核销金额
                   '1', --核销状态：1：已核销
                   P_USERNAME,
                   SYSDATE,
                   P_USERNAME,
                   SYSDATE);
              EXCEPTION WHEN OTHERS THEN
                GOTO FIVE ;
              END ;
          END IF ;

          --计算过程中的到款余额 V_TEMP_AMOUNT = 0 ，说明到款已经核销完，直接跳出循环
          IF V_TEMP_AMOUNT = 0 THEN
            GOTO SIX ;
          END IF ;
          <<FIVE>>
          NULL ;
      END LOOP ;
      <<SIX>>
      NULL ;
    ELSIF P_ACTION_TYPE = 20  THEN --三方承兑解付冲销
      FOR I IN (SELECT T.ROWID, T.*
                  FROM T_CREDIT_DELAYPA_APPLIED T
                 WHERE T.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID
                   AND T.THREE_PAY_ID = P_THREE_PAY_ID
                   AND NVL(T.APPLIED_STATUS, '1') = '1' --已核销
                   AND NOT EXISTS (SELECT 1
                          FROM T_CREDIT_DELAYPA_APPLIED A
                         WHERE A.CASH_RECEIPT_ID = T.CASH_RECEIPT_ID
                           AND A.THREE_PAY_ID = T.THREE_PAY_ID
                           AND NVL(A.APPLIED_STATUS, '1') = '2')
                   ORDER BY T.APPLIED_ID DESC) LOOP
          IF NVL(I.APPLIED_AMOUNT,0) <= V_TEMP_AMOUNT THEN

             V_PAYED_FLAG := '0' ;  --0:未还清
             V_PAY_DATE := NULL ; --还清日期
             V_TRANSACTION_AMOUNT := NVL(I.APPLIED_AMOUNT,0) ; --未核销金额

             V_THIS_AMOUNT := NVL(I.APPLIED_AMOUNT,0) ;
             V_TEMP_AMOUNT := V_TEMP_AMOUNT - NVL(I.APPLIED_AMOUNT,0) ;

          ELSIF NVL(I.APPLIED_AMOUNT,0) > V_TEMP_AMOUNT THEN

             V_PAYED_FLAG := '0' ;  --0:未还清
             V_PAY_DATE := NULL ; --还清日期
             V_TRANSACTION_AMOUNT := V_TEMP_AMOUNT ; --未核销金额

             V_THIS_AMOUNT := V_TEMP_AMOUNT ;
             V_TEMP_AMOUNT := 0 ;

          END IF ;
          --1、根据铺底核销记录表，查找到被核销的铺底单据，将相关标识（还清日期、是否还清、未核销金额）位置上
          BEGIN
             UPDATE T_CREDIT_DELAYPAY T
               SET T.PAY_DATE             = V_PAY_DATE,
                   T.PAYED_FLAG           = V_PAYED_FLAG,
                   T.TRANSACTION_AMOUNT   = T.TRANSACTION_AMOUNT + V_TRANSACTION_AMOUNT
             WHERE T.BILL_ID = I.BILL_ID ;
         EXCEPTION WHEN OTHERS THEN
           GOTO SEVEN ;
         END ;

         --2、根据改变之后的状态，计算该铺底的利息信息
         prc_credit_delaypay_accrual(p_bill_id => I.BILL_ID,
                                  p_bring_accrual_days =>v_bring_accrual_days,
                                  p_bring_accrual_amount => v_bring_accrual_amount,
                                  p_accrual_amount => v_accrual_amount,
                                  p_result => p_result,
                                  p_err_msg => p_err_msg);
              --计算利息失败，跳过当前条铺底单据
               IF p_result <> V_SEC_RESULT THEN
                  GOTO SEVEN ;
               END IF ;

         --3、将利息信息，更新到该铺底单据上
         BEGIN
             UPDATE T_CREDIT_DELAYPAY T
               SET T.BRING_ACCRUAL_DAYS = v_bring_accrual_days,
                   T.Bring_Accrual_Amount = v_bring_accrual_amount,
                   T.Accrual_Amount   = v_accrual_amount
             WHERE T.BILL_ID = I.BILL_ID ;
         EXCEPTION WHEN OTHERS THEN
           GOTO SEVEN ;
         END ;
         --4、记录铺底核销表
         BEGIN
           INSERT INTO T_CREDIT_DELAYPA_APPLIED T
                    (bill_id,
                     applied_id,
                     cash_receipt_id,
                     three_pay_id,
                     applied_amount,
                     applied_status,
                     created_by,
                     creation_date,
                     last_updated_by,
                     last_update_date)
                  VALUES
                    (I.BILL_ID,
                     S_CREDIT_DELAYPA_APPLIED.NEXTVAL,
                     P_CASH_RECEIPT_ID,
                     P_THREE_PAY_ID,
                     V_THIS_AMOUNT, --本次核销金额
                     '2', --核销状态：1：已冲销
                     P_USERNAME,
                     SYSDATE,
                     P_USERNAME,
                     SYSDATE);
          EXCEPTION WHEN OTHERS THEN
            GOTO SEVEN ;
          END ;

          IF V_TEMP_AMOUNT = 0 THEN
            GOTO EIGTH ;
          END IF ;
          <<SEVEN>>
          NULL ;
      END LOOP ;
      <<EIGTH>>
      NULL ;
    END IF ;
  EXCEPTION WHEN OTHERS THEN
      NULL ;
  END; --PRC_CREDIT_DELAYPAY_APPLIED_AT

 PROCEDURE 以下铺底利息的计算 is begin null ; end ;

 --------------------------------------------------------------------------------
  \*
  *   创建日期：2014-10-18
  *     创建者：苏冬渊
  *   功能说明：处理信用模块中的逾期铺底利息的计算
      计算规则：
  *
      t_credit_delaypay
  *\
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_DELAYPAY_ACCRUAL(P_BILL_ID T_CREDIT_DELAYPAY.BILL_ID%TYPE,
                                        P_BRING_ACCRUAL_DAYS OUT NUMBER,
                                        P_BRING_ACCRUAL_AMOUNT OUT NUMBER,
                                        P_ACCRUAL_AMOUNT OUT NUMBER,
                                        P_RESULT IN OUT NUMBER,
                                        P_ERR_MSG IN OUT VARCHAR2) IS
    V_DQ_DATE DATE ;
    ROW_CREDIT_DELAYPAY T_CREDIT_DELAYPAY%ROWTYPE ;
    entityGroupCode Varchar2(100) ;
  BEGIN
    --初始化输出参数
    P_RESULT  := V_SEC_RESULT;
    P_ERR_MSG := V_SUCCESS ;

    BEGIN
      SELECT T.*
        INTO ROW_CREDIT_DELAYPAY
        FROM T_CREDIT_DELAYPAY T
       WHERE T.BILL_ID = P_BILL_ID;
    EXCEPTION WHEN OTHERS THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '根据传进的铺底单据ID查询铺底单据报错！'|| V_NL || SQLERRM ;
      RETURN ;
    END ;
    --获取主体组编码
    entityGroupCode := pkg_bd.F_GET_PARAMETER_VALUE('ar_entity_group',ROW_CREDIT_DELAYPAY.Entity_Id,null,null);
    --获取到期日期
    V_DQ_DATE := NVL(ROW_CREDIT_DELAYPAY.DELAY_DATE, NVL(ROW_CREDIT_DELAYPAY.DUE_TIME, ROW_CREDIT_DELAYPAY.PLANPAY_DATE)) ;
    \** 家用事业部，利息计算办法
     *  处理规则：
            月底客户铺底欠款金额*1%（每月按1%收取利息，每次均按整一个月计算）
     *\
    IF entityGroupCode = 'XSGS' THEN --家用事业部
       --判断是否逾期，是否延期.家用事业部，只对到期的欠款征收利息
       IF nvl(ROW_CREDIT_DELAYPAY.Overdue_Flag,'0') = '1' OR nvl(ROW_CREDIT_DELAYPAY.DELAY_FLAG,'0') = '1' THEN
           --目前计算利息都是在铺底核销完成的时候计算，计算利息金额取的是这个时候的未核销金额
           --若是之前有部分还款，则认为是在铺底过期的时候还的款
           P_BRING_ACCRUAL_AMOUNT := ROW_CREDIT_DELAYPAY.TRANSACTION_AMOUNT ; --计算利息金额
           --因为家用以月计算利息，所以利息计算天数，记录的是月数
           P_BRING_ACCRUAL_DAYS := trunc(nvl(ROW_CREDIT_DELAYPAY.PAY_DATE,sysdate)) - trunc(V_DQ_DATE) ;
           --CEIL(MONTHS_BETWEEN(nvl(ROW_CREDIT_DELAYPAY.PAY_DATE,sysdate),V_DQ_DATE)) ;
           --根据利息计算天数和利息计算金额计算出来的利息金额
           P_ACCRUAL_AMOUNT := ROUND(P_BRING_ACCRUAL_AMOUNT * CEIL(MONTHS_BETWEEN(nvl(ROW_CREDIT_DELAYPAY.PAY_DATE,sysdate),V_DQ_DATE)) * 0.01 ,2) ;
        ELSE
           P_BRING_ACCRUAL_DAYS := 0 ;
           P_BRING_ACCRUAL_AMOUNT := 0 ;
           P_ACCRUAL_AMOUNT := 0 ;
        END IF ;
    \** 厨电事业部
     *  业务规则：
            需要计息的铺底包括：铺底延期、铺底逾期、跨月铺底和三方承兑铺底。
              1、铺底利息的利率和铺底逾期的利率如下：
                    序号	铺底类型	年利率	逾期利息(年利率)
                    1	铺底（不跨月）	0%	18%
                    2	铺底（跨月）	8%
                    3	三方承兑铺底	12%
              2、铺底延期利息：规定期限内的延期按年利率12%收取利息，且从首次铺底申请日开始计算；
              3、铺底利息计算公式：
              铺底利息金额=审批的铺底金额*天数（最后全部实际还款时间-申请时间）*日利率；
              铺底逾期利息金额=审批的铺底金额*天数（最后全部实际还款时间-申请时间）*日利率；
              铺底利息计算（含逾期）在每月兑现一次，以“折让红冲方式”兑现；
     *
     *\
    ELSIF entityGroupCode = 'JXS' THEN --厨电事业部

       --计算利息天数 = 还清日期 - 申请日期
       P_BRING_ACCRUAL_DAYS := nvl(ROW_CREDIT_DELAYPAY.Pay_Date,sysdate) - ROW_CREDIT_DELAYPAY.Requis_Date ;
       --计算利息金额都已审批金额为准
       P_BRING_ACCRUAL_AMOUNT := ROW_CREDIT_DELAYPAY.APPROVAL_AMOUNT ;

       --是否逾期，若逾期，则所有单据按照18%计算利息
       IF nvl(ROW_CREDIT_DELAYPAY.Overdue_Flag,'0') = '1' THEN --逾期
          P_ACCRUAL_AMOUNT := P_BRING_ACCRUAL_AMOUNT * P_BRING_ACCRUAL_DAYS * 0.18/360 ;
       --没有逾期，但是存在延期时
       ELSIF NVL(ROW_CREDIT_DELAYPAY.DELAY_FLAG,'0') = '1' THEN --存在延期
          P_ACCRUAL_AMOUNT := P_BRING_ACCRUAL_AMOUNT * P_BRING_ACCRUAL_DAYS * 0.12/360 ;
       --三方承兑铺底（不延期，不逾期）
       ELSIF ROW_CREDIT_DELAYPAY.DELAYPAY_TYPE = 3 THEN
          P_ACCRUAL_AMOUNT := P_BRING_ACCRUAL_AMOUNT * P_BRING_ACCRUAL_DAYS * 0.12/360 ;
       --跨月铺底（不延期，不逾期）
       ELSIF ROW_CREDIT_DELAYPAY.DELAYPAY_TYPE = 1 THEN
          P_ACCRUAL_AMOUNT := P_BRING_ACCRUAL_AMOUNT * P_BRING_ACCRUAL_DAYS * 0.08/360 ;
       ELSE
          P_BRING_ACCRUAL_AMOUNT := 0 ;
          P_BRING_ACCRUAL_DAYS := 0 ;
          P_ACCRUAL_AMOUNT := 0 ;
       END IF ;

    END IF ;

  EXCEPTION WHEN OTHERS THEN
      P_RESULT  := -20000;
      P_ERR_MSG := '计算利息出错，铺底单据ID = ！'|| P_BILL_ID || V_NL || SQLERRM ;
      RETURN ;
  END; --PRC_CREDIT_DELAYPAY_ACCRUAL*/

  PROCEDURE 订单检查不锁款调用 is begin null ; end ;


  Procedure PRC_CREDIT_ORDER_CHECK(P_ENTITY_ID               IN NUMBER, --主体ID
                                    P_ACTION_TYPE          IN NUMBER, --动作标示
                                    P_Settlement_SUM       IN NUMBER, --结算金额
                                    P_Discount_SUM         IN NUMBER, --折让金额
                                    P_SALES_MAIN_TYPE   IN VARCHAR2, --营销大类
                                    P_ACCOUNT_ID           IN NUMBER, --账户ID
                                    P_CUSTOMER_ID          IN NUMBER, --客户ID
                                    P_PROJ_NUMBER          IN VARCHAR2, --项目号
                                    P_ORDER_ID             IN NUMBER,   --单据ID
                                    P_RESULT            IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG           IN OUT VARCHAR2 --返回错误信息
                            ) Is
  Begin
    Savepoint SAVEPOINT_CREDIT ;
    PRC_CREDIT_VERIFICATION(P_ENTITY_ID => P_ENTITY_ID,
                            P_ACTION_TYPE => P_ACTION_TYPE,
                            P_Settlement_SUM => P_Settlement_SUM,
                            P_Discount_SUM => P_Discount_SUM,
                            P_ORDER_ID => P_ORDER_ID,
                            P_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE,
                            P_ACCOUNT_ID => P_ACCOUNT_ID,
                            P_CUSTOMER_ID => P_CUSTOMER_ID,
                            P_PROJ_NUMBER => P_PROJ_NUMBER,
                            P_CREATED_MODE => Null ,
                            P_RESULT => P_RESULT,
                            P_ERR_MSG => P_ERR_MSG ) ;
   --以上调用过程客户款项记录数据被for update 锁定，回滚
   Rollback To SAVEPOINT_CREDIT ;
  End ;
  
  PROCEDURE PRC_UPD_ACCOUNT_AMOUNT_FLAG(P_ACCOUNT_ID        IN NUMBER,
                                        P_CREDIT_GROUP_ID   IN NUMBER,
                                        P_USER_CODE         IN VARCHAR2,
                                        P_AMOUNT_CRTL_FLAG  IN VARCHAR2,
                                        P_DISCONT_CRTL_FLAG IN VARCHAR2,
                                        P_REMARK            IN VARCHAR2
                                         ) is
  
    V_OLD_AMOUNT_CRTL_FLAG  VARCHAR2(2);
    V_OLD_DISCONT_CRTL_FLAG VARCHAR2(2);
    V_AMOUNT_ACCOUNT_ID     NUMBER;
  BEGIN
    --取当前客户款项控制标志
    SELECT T.ACCOUNT_AMOUNT_ID, T.AMOUNT_CRTL_FLAG, T.Discont_Crtl_Flag
      INTO V_AMOUNT_ACCOUNT_ID,
           V_OLD_AMOUNT_CRTL_FLAG,
           V_OLD_DISCONT_CRTL_FLAG
      FROM T_SALES_ACCOUNT_AMOUNT T
     WHERE T.ACCOUNT_ID = P_ACCOUNT_ID
       AND T.CREDIT_GROUP_ID = P_CREDIT_GROUP_ID
       AND ROWNUM = 1;
    --如果控制标志改变，则修改正式表和插入修改历史表
    IF V_OLD_AMOUNT_CRTL_FLAG <> P_AMOUNT_CRTL_FLAG OR
       V_OLD_DISCONT_CRTL_FLAG <> P_DISCONT_CRTL_FLAG THEN
      --修改正式表
      UPDATE T_SALES_ACCOUNT_AMOUNT T
         SET T.DISCONT_CRTL_FLAG = P_DISCONT_CRTL_FLAG,
             T.AMOUNT_CRTL_FLAG  = P_AMOUNT_CRTL_FLAG
       WHERE T.ACCOUNT_AMOUNT_ID = V_AMOUNT_ACCOUNT_ID;
      --插入历史表
      INSERT INTO T_SALES_ACCOUNT_AMOUNT_HIS
       (account_amount_id,
        updated_by,
        update_date,
        amount_crtl_flag,
        discont_crtl_flag,
        remark)
      VALUES
        (V_AMOUNT_ACCOUNT_ID,
         P_USER_CODE,
         SYSDATE,
         P_AMOUNT_CRTL_FLAG,
         P_DISCONT_CRTL_FLAG,
         P_REMARK
         );
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
  
  PROCEDURE P_CREDIT_LOCK_HAND(IN_ENTITY_ID       IN NUMBER, --主体ID
                               IN_CUSTOMER_ID     IN NUMBER, --客户ID
                               IN_ACCOUNT_ID      IN NUMBER, --账户ID
                               IN_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                               IN_PROJ_NUMBER     IN VARCHAR2, --项目号
                               IN_AMOUNT_SUM      IN NUMBER, --结算金额(需传正负号)
                               IN_DISAMOUNT_SUM   IN NUMBER, --折让金额(需传正负号)
                               IN_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 COMMON/DISCOUNT
                               IN_ORDER_ID        IN NUMBER, --单据ID
                               IN_ORDER_NUMBER    IN VARCHAR2, --单据号
                               IN_DOWNPAY_RATE    IN NUMBER, --订金比例
                               IN_SRC_TYPE        IN VARCHAR2, --来源类型
                               IN_USER_ACCOUNT    IN VARCHAR2, --操作用户
                               OUT_RESULT         IN OUT NUMBER, --返回错误ID
                               OUT_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                               )
 IS
   V_CURR_AMOUNT_SUM NUMBER;
   V_CURR_DISAMOUNT_SUM NUMBER;
 BEGIN
   OUT_RESULT := V_SEC_RESULT;
   OUT_ERR_MSG := V_SUCCESS;
   
   --金额为0，返回成功
   V_CURR_AMOUNT_SUM := NVL(IN_AMOUNT_SUM, 0);
   V_CURR_DISAMOUNT_SUM := NVL(IN_DISAMOUNT_SUM, 0);
   IF V_CURR_AMOUNT_SUM = 0 AND V_CURR_DISAMOUNT_SUM = 0 THEN
     RETURN;
   END IF;
   
   --余额金额校验
   PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_CHECK_AMOUNT(IN_ENTITY_ID       => IN_ENTITY_ID,
                                                    IN_CUSTOMER_ID     => IN_CUSTOMER_ID,
                                                    IN_ACCOUNT_ID      => IN_ACCOUNT_ID,
                                                    IN_SALES_MAIN_TYPE => IN_SALES_MAIN_TYPE,
                                                    IN_PROJ_NUMBER     => IN_PROJ_NUMBER,
                                                    IN_AMOUNT_SUM      => V_CURR_AMOUNT_SUM,
                                                    IN_DISAMOUNT_SUM   => V_CURR_DISAMOUNT_SUM,
                                                    IN_DISCOUNT_TYPE   => IN_DISCOUNT_TYPE,
                                                    IN_USER_ACCOUNT    => IN_USER_ACCOUNT,
                                                    OUT_RESULT         => OUT_RESULT,
                                                    OUT_ERR_MSG        => OUT_ERR_MSG);
   --校验不通过直接返回
   IF OUT_RESULT <> V_SEC_RESULT THEN
     RETURN;
   END IF;
   
   SAVEPOINT SAVEPOINT_CREDIT;
   --锁款金额处理
   PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_LOCK_DETAIL_HAND(IN_ENTITY_ID        => IN_ENTITY_ID,
                                                        IN_CUSTOMER_ID      => IN_CUSTOMER_ID,
                                                        IN_ACCOUNT_ID       => IN_ACCOUNT_ID,
                                                        IN_SALES_MAIN_TYPE  => IN_SALES_MAIN_TYPE,
                                                        IN_PROJ_NUMBER      => IN_PROJ_NUMBER,
                                                        IN_AMOUNT_SUM       => V_CURR_AMOUNT_SUM,
                                                        IN_DISAMOUNT_SUM    => V_CURR_DISAMOUNT_SUM,
                                                        IN_DP_AMOUNT_SUM    => 0,
                                                        IN_DP_DISAMOUNT_SUM => 0,
                                                        IN_DISCOUNT_TYPE    => IN_DISCOUNT_TYPE,
                                                        IN_ORDER_ID         => IN_ORDER_ID,
                                                        IN_ORDER_NUMBER     => IN_ORDER_NUMBER,
                                                        IN_DOWNPAY_RATE     => IN_DOWNPAY_RATE,
                                                        IN_SRC_TYPE         => IN_SRC_TYPE,
                                                        IN_USER_ACCOUNT     => IN_USER_ACCOUNT,
                                                        OUT_RESULT          => OUT_RESULT,
                                                        OUT_ERR_MSG         => OUT_ERR_MSG);
   IF OUT_RESULT <> V_SEC_RESULT THEN
     OUT_RESULT := '-20000';
     OUT_ERR_MSG := '更新客户款项失败！' || V_NL || '错误信息：' || OUT_ERR_MSG;
     ROLLBACK TO SAVEPOINT SAVEPOINT_CREDIT;
     RETURN;
   END IF; 
   
 EXCEPTION
    WHEN OTHERS THEN
      OUT_RESULT := '-20000';
      OUT_ERR_MSG := '处理客户款项出错！' || V_NL || '错误信息：' || sqlerrm;
      ROLLBACK TO SAVEPOINT SAVEPOINT_CREDIT;
 END P_CREDIT_LOCK_HAND;
 
 PROCEDURE P_CREDIT_CHECK_AMOUNT(IN_ENTITY_ID       IN NUMBER, --主体ID
                                 IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                 IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                 IN_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                 IN_PROJ_NUMBER     IN VARCHAR2, --项目号
                                 IN_AMOUNT_SUM      IN NUMBER, --结算金额(需传正负号)
                                 IN_DISAMOUNT_SUM   IN NUMBER, --折让金额(需传正负号)
                                 IN_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 COMMON/DISCOUNT
                                 IN_USER_ACCOUNT    IN VARCHAR2, --操作用户
                                 OUT_RESULT         IN OUT NUMBER, --返回错误ID
                                 OUT_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                 )
 IS
   V_CREDIT_GROUP_ID NUMBER; --额度组ID
   V_COUNT NUMBER;
   R_SALES_ACCOUNT_AMOUNT T_SALES_ACCOUNT_AMOUNT%ROWTYPE;
   R_CREDIT_DISCOUNT_AMOUNT T_CREDIT_DISCOUNT_AMOUNT%ROWTYPE;
   V_AMOUNT_CRTL_FLAG T_SALES_ACCOUNT_AMOUNT.AMOUNT_CRTL_FLAG%TYPE; --金额控制标志
   V_DISCONT_CRTL_FLAG T_SALES_ACCOUNT_AMOUNT.DISCONT_CRTL_FLAG%TYPE; --折让控制标志
   V_RECEIVABLE_CRTL_FLAG T_SALES_ACCOUNT_AMOUNT.RECEIVABLE_CRTL_FLAG%TYPE; --收款控制标志
   V_AMOUNT_CHK_DIS_FLAG T_BD_PARAM_LIST.DEFAULT_VALUE%TYPE;
   
    --折让款项上账金额
    V_DIS_RECEIPT_AMOUNT NUMBER := 0;
    --折让款项销售金额
    V_DIS_SALES_AMOUNT NUMBER := 0;
    --折让款项锁款金额
    V_DIS_LOCK_AMOUNT NUMBER := 0;
    --折让到款到款金额
    V_DIS_RECEIVED_AMOUNT NUMBER := 0;
    V_SALES_AMOUNT NUMBER := 0;
    V_LOCK_RECEIVED_AMOUNT NUMBER := 0;
    V_LOCK_DISCOUNT_AMOUNT NUMBER := 0;
    V_RECEIVED_AMOUNT NUMBER := 0;
    V_AMOUNT_SUM NUMBER := 0;
    V_DISCONT_SUM NUMBER := 0;
    V_CHK_DIS_AMOUNT NUMBER := 0;
    V_AMOUNT_CHECK_PASS BOOLEAN := TRUE;
    V_DISAMOUNT_CHECK_PASS BOOLEAN := TRUE;
 BEGIN
   OUT_RESULT := V_SEC_RESULT;
   OUT_ERR_MSG := V_SUCCESS;
   
   --金额为0，返回成功
   IF NVL(IN_AMOUNT_SUM, 0) = 0 AND NVL(IN_DISAMOUNT_SUM, 0) = 0 THEN
     RETURN;
   END IF;
   
   --校验传入参数是否正确
   IF IN_CUSTOMER_ID IS NULL OR IN_ACCOUNT_ID IS NULL THEN
     OUT_RESULT  := -20000;
     OUT_ERR_MSG := '传入客户ID或者账户ID不能为空！';
     RETURN;
   END IF;
  
   IF IN_SALES_MAIN_TYPE IS NULL THEN
     OUT_RESULT  := -20000;
     OUT_ERR_MSG := '传入营销大类不能为空！';
     RETURN;
   END IF;
   
   --获取额度组
   V_CREDIT_GROUP_ID := pkg_credit_tools.FUN_GET_CREDITGROUPID(IN_ENTITY_ID, IN_CUSTOMER_ID, IN_SALES_MAIN_TYPE, IN_ACCOUNT_ID);
 
   IF V_CREDIT_GROUP_ID = -2 THEN
     OUT_RESULT := -20002;
     OUT_ERR_MSG := '该客户已经存在特殊额度组，请到额度组维护模块维护特殊额度组与'|| IN_SALES_MAIN_TYPE ||'的关系！' || V_NL || SQLERRM;
     RETURN;
   ELSIF V_CREDIT_GROUP_ID = -1 THEN
     OUT_RESULT := -20002;
     OUT_ERR_MSG := '根据营销大类查询额度组出错，请到额度组管理模块维护！' || V_NL || SQLERRM;
     RETURN;
   END IF;
   
   --锁定款项明细信息
   SELECT COUNT(1) INTO V_COUNT
     FROM T_SALES_ACCOUNT_MX_AMOUNT T
    WHERE T.ENTITY_ID = IN_ENTITY_ID
      AND T.CUSTOMER_ID = IN_CUSTOMER_ID
      AND T.ACCOUNT_ID = IN_ACCOUNT_ID
      AND NVL(T.PROJ_NUMBER, -1) = -1
      AND T.SALES_MAIN_TYPE = IN_SALES_MAIN_TYPE;
        
   --缺少客户款项明细信息，初始化该客户该账户下的营销大类款项明细信息
   IF V_COUNT < 1 THEN
     PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_AMOUNT_CONTORL_INIT(
       P_ENTITY_ID => IN_ENTITY_ID,
       P_CUSTOMER_ID => IN_CUSTOMER_ID,
       P_ACCOUNT_ID => IN_ACCOUNT_ID,
       P_PROJ_NUMBER => NULL,
       P_SALES_MAIN_TYPE => IN_SALES_MAIN_TYPE,
       P_USERNAME => '初始化',
       P_RESULT => OUT_RESULT,
       P_ERR_MSG => OUT_ERR_MSG);
     IF OUT_RESULT <> V_SEC_RESULT THEN
       RETURN;
     END IF;
   END IF;

   --锁定款项信息
   BEGIN
     SELECT * INTO R_SALES_ACCOUNT_AMOUNT
        FROM T_SALES_ACCOUNT_AMOUNT T
       WHERE T.ENTITY_ID = IN_ENTITY_ID
         AND nvl(T.CREDIT_GROUP_ID,-1) = V_CREDIT_GROUP_ID
         AND nvl(T.PROJ_NUMBER,-1) = -1
         AND T.CUSTOMER_ID = IN_CUSTOMER_ID
         AND T.ACCOUNT_ID = IN_ACCOUNT_ID
         FOR UPDATE NOWAIT;
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       R_SALES_ACCOUNT_AMOUNT := NULL;
   END;

   IF R_SALES_ACCOUNT_AMOUNT.ACCOUNT_AMOUNT_ID IS NULL THEN
     OUT_RESULT  := -20004;
     OUT_ERR_MSG := '系统中不存在该客户在该账户下，营销大类为'|| IN_SALES_MAIN_TYPE ||'的客户款项信息！' || V_NL || SQLERRM;
     RETURN;
   END IF;

   /*BEGIN       
     SELECT *
       INTO R_CREDIT_DISCOUNT_AMOUNT
       FROM T_CREDIT_DISCOUNT_AMOUNT T
      WHERE T.ENTITY_ID = IN_ENTITY_ID
        AND T.CUSTOMER_ID = IN_CUSTOMER_ID
        AND T.ACCOUNT_ID = IN_ACCOUNT_ID
        AND V_CREDIT_GROUP_ID = V_CREDIT_GROUP_ID
        AND (IN_DISCOUNT_TYPE IS NULL OR IN_DISCOUNT_TYPE = 'COMMON' OR IN_DISCOUNT_TYPE = T.DISCOUNT_TYPE); 
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
   END;*/
          
   --获取控制方式
   V_AMOUNT_CRTL_FLAG :=  NVL(R_SALES_ACCOUNT_AMOUNT.AMOUNT_CRTL_FLAG,'-1');
   V_DISCONT_CRTL_FLAG := NVL(R_SALES_ACCOUNT_AMOUNT.DISCONT_CRTL_FLAG,'-1');
   V_RECEIVABLE_CRTL_FLAG := NVL(R_SALES_ACCOUNT_AMOUNT.RECEIVABLE_CRTL_FLAG,'-1');
    
   --金额不控制直接返回成功
    IF V_AMOUNT_CRTL_FLAG = '-1' AND V_DISCONT_CRTL_FLAG = '-1' THEN
      OUT_RESULT  := V_SEC_RESULT;
      OUT_ERR_MSG := V_SUCCESS;
      RETURN ;
    Elsif V_AMOUNT_CRTL_FLAG Not In ('0','-1') Then
      OUT_RESULT  := -20006;
      OUT_ERR_MSG := '该客户款项金额控制方式上的值只能为[0]或者[-1]' || V_NL || SQLERRM;
      RETURN ;
    Elsif V_DISCONT_CRTL_FLAG Not In ('0','-1') Then
      OUT_RESULT  := -20006;
      OUT_ERR_MSG := '该客户款项折扣控制方式上的值只能为[0]或者[-1]' || V_NL || SQLERRM;
      RETURN;
    Elsif V_RECEIVABLE_CRTL_FLAG Not In ('0','-1') Then
      OUT_RESULT  := -20006;
      OUT_ERR_MSG := '该客户款项应收控制方式上的值只能为[0]或者[-1]' || V_NL || SQLERRM;
      RETURN;
    END IF;
    
    --获取参数值
    V_AMOUNT_CHK_DIS_FLAG := PKG_BD.F_GET_PARAMETER_VALUE('PLCY_AMOUNT_CHECK_DIS', IN_ENTITY_ID);
    
    SELECT SUM(T.RECEIPT_AMOUNT),
           SUM(T.SALES_AMOUNT),
           SUM(T.LOCK_AMOUNT),
           SUM(T.RECEIVED_AMOUNT)
      INTO V_DIS_RECEIPT_AMOUNT,
           V_DIS_SALES_AMOUNT,
           V_DIS_LOCK_AMOUNT,
           V_DIS_RECEIVED_AMOUNT
      FROM T_CREDIT_DISCOUNT_AMOUNT T
     WHERE T.ENTITY_ID = IN_ENTITY_ID
       AND T.CUSTOMER_ID = IN_CUSTOMER_ID
       AND T.ACCOUNT_ID = IN_ACCOUNT_ID
       AND V_CREDIT_GROUP_ID = V_CREDIT_GROUP_ID
       AND (IN_DISCOUNT_TYPE IS NULL OR IN_DISCOUNT_TYPE = 'COMMON' OR IN_DISCOUNT_TYPE = T.DISCOUNT_TYPE);
    
    IF IN_DISCOUNT_TYPE IS NULL OR IN_DISCOUNT_TYPE = 'COMMON' THEN
      V_SALES_AMOUNT := R_SALES_ACCOUNT_AMOUNT.SALES_AMOUNT + NVL(V_DIS_RECEIPT_AMOUNT,0) - NVL(V_DIS_SALES_AMOUNT,0);
      V_LOCK_RECEIVED_AMOUNT := R_SALES_ACCOUNT_AMOUNT.LOCK_RECEIVED_AMOUNT - NVL(V_DIS_LOCK_AMOUNT,0);
      V_RECEIVED_AMOUNT := R_SALES_ACCOUNT_AMOUNT.RECEIVED_AMOUNT - NVL(V_DIS_RECEIVED_AMOUNT,0);
    END IF;
    
    --到款余额-锁定到款金额+铺底额度+临时额度
    --到款余额=到款金额 - 销售金额
    V_AMOUNT_SUM := V_RECEIVED_AMOUNT - V_SALES_AMOUNT - V_LOCK_RECEIVED_AMOUNT +
                    NVL(R_SALES_ACCOUNT_AMOUNT.DELAYPAY_AMOUNT, 0) +
                    NVL(R_SALES_ACCOUNT_AMOUNT.TEMP_DELAYPAY_AMOUNT, 0);   --结算控制金额

    --折让余额-锁定折让金额+冻结折让金额
    --扣率折让余额 = 扣率折让金额 - 核销扣率折让金额
    V_DISCONT_SUM := NVL(R_SALES_ACCOUNT_AMOUNT.DISCOUNT_AMOUNT, 0) -
                     NVL(R_SALES_ACCOUNT_AMOUNT.APPLIED_DISCOUNT_AMOUNT, 0) -
                     NVL(R_SALES_ACCOUNT_AMOUNT.LOCK_DISCOUNT_AMOUNT, 0) +
                     NVL(R_SALES_ACCOUNT_AMOUNT.FREEZE_DISCOUNT_AMOUNT, 0);  --折扣控制金额
       
    /*=====================================
    --add by sudy 2016-01-06
      由于上游从订单、物流、财务、销售过来的金额，四舍五入造成金额不对等。出现由于几分钱而发
      不出货，开不了单。所以应老马的要求，在相关资金校验项上加5分钱
      造成的结果是：差5分钱内的单，直接让单据过去。
    */
    V_AMOUNT_SUM  := V_AMOUNT_SUM + 0.05 ;
    V_DISCONT_SUM := V_DISCONT_SUM + 0.05 ;
    V_LOCK_RECEIVED_AMOUNT := V_LOCK_RECEIVED_AMOUNT + 0.05;
    V_LOCK_DISCOUNT_AMOUNT := V_LOCK_DISCOUNT_AMOUNT + 0.05;
    V_AMOUNT_SUM  := V_AMOUNT_SUM +
                     (NVL(R_SALES_ACCOUNT_AMOUNT.MPAY_STREAM_AMOUNT, 0) -
                      NVL(R_SALES_ACCOUNT_AMOUNT.MPAY_CASH_AMOUNT, 0));

    IF NVL(V_AMOUNT_CHK_DIS_FLAG,'Y') = 'Y' THEN
      V_CHK_DIS_AMOUNT := LEAST(0, V_DISCONT_SUM);
    ELSE
      V_CHK_DIS_AMOUNT := 0;
    END IF;
    
    --加锁
    IF IN_AMOUNT_SUM > 0 THEN
      IF V_AMOUNT_CRTL_FLAG = '0' THEN --金额控制
        --若结算金额小于（到款余额-锁定到款金额+铺底额度+临时额度），校验结果为是
        IF IN_AMOUNT_SUM <= V_AMOUNT_SUM + V_CHK_DIS_AMOUNT THEN  --对于折让余额小于0，则合并到到款余额中检查
          V_AMOUNT_CHECK_PASS := TRUE;
        ELSE
          V_AMOUNT_CHECK_PASS := FALSE;
        END IF ;
      ELSIF V_AMOUNT_CRTL_FLAG = '-1' THEN --金额控制标识为-1，不用校验直接通过
        V_AMOUNT_CHECK_PASS := TRUE;
      END IF;
    END IF;
    
    IF IN_DISAMOUNT_SUM > 0 THEN
      IF V_DISCONT_CRTL_FLAG = '0' THEN --折扣控制
        --若折扣金额小于（折让余额-锁定折让金额+冻结折让金额）
        IF IN_DISAMOUNT_SUM <= V_DISCONT_SUM THEN
          V_DISAMOUNT_CHECK_PASS := TRUE;
        ELSE
          V_DISAMOUNT_CHECK_PASS := FALSE;
        END IF ;
      ELSIF V_DISCONT_CRTL_FLAG = '-1' THEN  ----折扣控制标识为-1，不用校验直接通过
        V_DISAMOUNT_CHECK_PASS := TRUE;
      END IF ;
    END IF;
    
    --余额和折让余额都校验通过
    IF V_AMOUNT_CHECK_PASS AND V_DISAMOUNT_CHECK_PASS THEN
      OUT_RESULT  := V_SEC_RESULT;
      OUT_ERR_MSG := V_SUCCESS;
    ELSE
      OUT_RESULT  := -20000;
      OUT_ERR_MSG := '金额校验不通过!';
      IF NOT V_AMOUNT_CHECK_PASS THEN
        IF V_DISCONT_SUM >= 0 THEN
          OUT_ERR_MSG := OUT_ERR_MSG || V_NL || '【原因：客户可用到款余额('|| V_AMOUNT_SUM ||')小于需锁定金额('|| IN_AMOUNT_SUM ||')！';
        ELSE
          OUT_ERR_MSG := OUT_ERR_MSG || V_NL || '【原因：客户可用到款余额('|| V_AMOUNT_SUM ||')+折让余额('|| (V_DISCONT_SUM-0.05) ||')小于需锁定金额('|| IN_AMOUNT_SUM ||')！';
        END IF;
      END IF;
      IF NOT V_DISAMOUNT_CHECK_PASS THEN
        OUT_ERR_MSG := OUT_ERR_MSG ||V_NL|| '【原因：客户可用折让余额('|| V_DISCONT_SUM ||')小于需锁定折让金额('|| IN_DISAMOUNT_SUM ||')！';
      END IF;
      RETURN;
    END IF;
    
    IF IN_AMOUNT_SUM < 0 THEN
      IF V_AMOUNT_CRTL_FLAG = '0' THEN --金额控制
        IF ABS(IN_AMOUNT_SUM) <= V_LOCK_RECEIVED_AMOUNT Then
          V_AMOUNT_CHECK_PASS := TRUE;
        ELSE
          V_AMOUNT_CHECK_PASS := FALSE;
        End If ;
      Elsif V_AMOUNT_CRTL_FLAG = '-1' Then
         V_AMOUNT_CHECK_PASS := TRUE;
      End If;
    END IF;
    
    IF IN_DISAMOUNT_SUM < 0 THEN
      IF V_DISCONT_CRTL_FLAG = '0' THEN --折扣控制
        If ABS(IN_DISAMOUNT_SUM) <= V_LOCK_DISCOUNT_AMOUNT THEN
          V_DISAMOUNT_CHECK_PASS := TRUE;
        ELSE
          V_DISAMOUNT_CHECK_PASS := FALSE;
        End If ;
      Elsif V_DISCONT_CRTL_FLAG = '-1' Then
        V_DISAMOUNT_CHECK_PASS := TRUE;
      End If;
    END IF;
    
    --判断最终的校验结果：金额控制=0 折扣控制=0 通过，其他都不通过
     IF V_AMOUNT_CHECK_PASS AND V_DISAMOUNT_CHECK_PASS THEN
       OUT_RESULT  := V_SEC_RESULT;
       OUT_ERR_MSG := V_SUCCESS;
     ELSE
       OUT_RESULT  := -20000;
       OUT_ERR_MSG := '金额校验不通过!';
       IF NOT V_AMOUNT_CHECK_PASS THEN
         OUT_ERR_MSG := OUT_ERR_MSG || V_NL || '【原因：客户锁款金额('|| V_LOCK_RECEIVED_AMOUNT ||')小于需解锁金额('|| ABS(IN_AMOUNT_SUM) ||')！';
       END IF;
       IF NOT V_DISAMOUNT_CHECK_PASS THEN
         OUT_ERR_MSG := OUT_ERR_MSG || V_NL || '【原因：客户锁定折让金额('|| V_LOCK_DISCOUNT_AMOUNT ||')小于需解锁折让金额('|| ABS(IN_DISAMOUNT_SUM) ||')！';
       END IF;
       RETURN;
     END IF;
 EXCEPTION
   WHEN OTHERS THEN
     OUT_RESULT := '-20000';
     OUT_ERR_MSG := '校验客户款项出错！' || V_NL || '错误信息：' || sqlerrm;
 END P_CREDIT_CHECK_AMOUNT;
 
  PROCEDURE P_CREDIT_LOCK_DETAIL_HAND(IN_ENTITY_ID       IN NUMBER, --主体ID
                                      IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                      IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                      IN_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                      IN_PROJ_NUMBER     IN VARCHAR2, --项目号
                                      IN_AMOUNT_SUM      IN NUMBER, --结算金额(需传正负号)
                                      IN_DISAMOUNT_SUM   IN NUMBER, --折让金额(需传正负号)
                                      IN_DP_AMOUNT_SUM   IN NUMBER, --订金金额(需传正负号)
                                      IN_DP_DISAMOUNT_SUM IN NUMBER, --折让订金金额(需传正负号)
                                      IN_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 COMMON/DISCOUNT
                                      IN_ORDER_ID        IN NUMBER, --单据ID
                                      IN_ORDER_NUMBER    IN VARCHAR2, --单据号
                                      IN_DOWNPAY_RATE    IN NUMBER, --订金比例（提货订单、计划订单使用）
                                      IN_SRC_TYPE        IN VARCHAR2, --来源类型
                                      IN_USER_ACCOUNT    IN VARCHAR2, --操作用户
                                      OUT_RESULT         IN OUT NUMBER, --返回错误ID
                                      OUT_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                      )
  IS
    V_CURR_AMOUNT NUMBER := 0;
    V_CURR_DISAMOUNT NUMBER := 0;
    V_CURR_DP_AMOUNT NUMBER := 0;
    V_CURR_DP_DISAMOUNT NUMBER := 0;
    V_CREDIT_GROUP_ID NUMBER; --额度组ID
    R_LOCK_DETAIL T_CREDIT_LOCK_AMOUNT_DETAIL%ROWTYPE;
  BEGIN
    OUT_RESULT := V_SEC_RESULT;
    OUT_ERR_MSG := V_SUCCESS;
   
    --获取额度组
    V_CREDIT_GROUP_ID := pkg_credit_tools.FUN_GET_CREDITGROUPID(IN_ENTITY_ID, IN_CUSTOMER_ID, IN_SALES_MAIN_TYPE, IN_ACCOUNT_ID);
    
    DELETE FROM T_CREDIT_LOCK_AMOUNT_DETAIL D
     WHERE D.ENTITY_ID = IN_ENTITY_ID
       AND D.SRC_TYPE = IN_SRC_TYPE
       AND D.ORIGIN_ORDER_ID = IN_ORDER_ID
       --AND NVL(D.PROJ_NUMBER, '-1') = NVL(IN_PROJ_NUMBER, '-1')
       AND D.LOCKED_AMOUNT = 0
       AND D.LOCKED_DISCOUNT_AMOUNT = 0
       AND D.LOCKED_DOWNPAY_AMOUNT = 0
       AND D.LOCKED_DIS_DP_AMOUNT = 0;
    
    SELECT S.CUSTOMER_ID, S.CUSTOMER_CODE, S.CUSTOMER_NAME,
           S.account_id, S.account_code, S.account_name,
           S.sales_center_id, S.sales_center_code, S.sales_center_name
      INTO R_LOCK_DETAIL.CUSTOMER_ID,
           R_LOCK_DETAIL.CUSTOMER_CODE,
           R_LOCK_DETAIL.CUSTOMER_NAME,
           R_LOCK_DETAIL.ACCOUNT_ID,
           R_LOCK_DETAIL.ACCOUNT_CODE,
           R_LOCK_DETAIL.ACCOUNT_NAME,
           R_LOCK_DETAIL.SALES_CENTER_ID,
           R_LOCK_DETAIL.SALES_CENTER_CODE,
           R_LOCK_DETAIL.SALES_CENTER_NAME
      FROM V_CUSTOMER_ACCOUNT_SALECENTER S
     WHERE S.entity_id = IN_ENTITY_ID
       AND S.CUSTOMER_ID = IN_CUSTOMER_ID
       AND S.account_id = IN_ACCOUNT_ID;
    
    BEGIN
      SELECT C.CLASS_CODE, C.CLASS_NAME
        INTO R_LOCK_DETAIL.SALES_MAIN_TYPE,
             R_LOCK_DETAIL.SALES_MAIN_TYPE_NAME
        FROM T_BD_ITEM_CLASS C
       WHERE C.ENTITY_ID = IN_ENTITY_ID
         AND C.CLASS_CODE = IN_SALES_MAIN_TYPE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        R_LOCK_DETAIL.SALES_MAIN_TYPE := NULL;
        R_LOCK_DETAIL.SALES_MAIN_TYPE_NAME := NULL;
    END;
    
    BEGIN
      SELECT G.CREDIT_GROUP_ID, G.CREDIT_GROUP_NUM
        INTO R_LOCK_DETAIL.CREDIT_GROUP_ID,
             R_LOCK_DETAIL.CREDIT_GROUP_NAME
        FROM T_CREDIT_GROUP G
       WHERE G.CREDIT_GROUP_ID = V_CREDIT_GROUP_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        R_LOCK_DETAIL.SALES_MAIN_TYPE := NULL;
        R_LOCK_DETAIL.SALES_MAIN_TYPE_NAME := NULL;
    END;
    
    BEGIN
      SELECT CASE
               WHEN IN_SRC_TYPE = '02' THEN
                 (SELECT UC.CODE_NAME
                    FROM T_PLN_LG_ORDER_HEAD H, UP_CODELIST UC
                   WHERE H.ORDER_HEAD_ID = IN_ORDER_ID
                     AND H.LOCK_AMOUNT_FLAG = UC.CODE_VALUE
                     AND UC.CODETYPE = 'plnlockMoneyFlag')
               WHEN IN_SRC_TYPE = '01' THEN
                 (SELECT UC.CODE_NAME
                    FROM T_PLN_ORDER_HEAD H, UP_CODELIST UC
                   WHERE H.ORDER_HEAD_ID = IN_ORDER_ID
                     AND H.LOCK_AMOUNT_FLAG = UC.CODE_VALUE
                     AND UC.CODETYPE = 'plnlockMoneyFlag')
               ELSE
                 NULL
             END
        INTO R_LOCK_DETAIL.LOCK_METHOD
        FROM DUAL;
    END;
    
    --更新锁定明细
    UPDATE T_CREDIT_LOCK_AMOUNT_DETAIL D
       SET D.CUSTOMER_ID = R_LOCK_DETAIL.CUSTOMER_ID,
           D.CUSTOMER_CODE = R_LOCK_DETAIL.CUSTOMER_CODE,
           D.CUSTOMER_NAME = R_LOCK_DETAIL.CUSTOMER_NAME,
           D.ACCOUNT_ID = R_LOCK_DETAIL.ACCOUNT_ID,
           D.ACCOUNT_CODE = R_LOCK_DETAIL.ACCOUNT_CODE,
           D.ACCOUNT_NAME = R_LOCK_DETAIL.ACCOUNT_NAME,
           D.SALES_CENTER_ID = R_LOCK_DETAIL.SALES_CENTER_ID,
           D.SALES_CENTER_CODE = R_LOCK_DETAIL.SALES_CENTER_CODE,
           D.SALES_CENTER_NAME = R_LOCK_DETAIL.SALES_CENTER_NAME,
           D.SALES_MAIN_TYPE = R_LOCK_DETAIL.SALES_MAIN_TYPE,
           D.SALES_MAIN_TYPE_NAME = R_LOCK_DETAIL.SALES_MAIN_TYPE_NAME,
           D.CREDIT_GROUP_ID = R_LOCK_DETAIL.CREDIT_GROUP_ID,
           D.CREDIT_GROUP_NAME = R_LOCK_DETAIL.CREDIT_GROUP_NAME,
           D.LOCK_METHOD = R_LOCK_DETAIL.LOCK_METHOD,
           D.SRC_TYPE = IN_SRC_TYPE,
           D.ORIGIN_ORDER_ID = IN_ORDER_ID,
           D.ORIGIN_ORDER_NUM = IN_ORDER_NUMBER,
           D.LOCKED_AMOUNT = D.LOCKED_AMOUNT + IN_AMOUNT_SUM,
           D.LOCKED_DISCOUNT_AMOUNT = D.LOCKED_DISCOUNT_AMOUNT + IN_DISAMOUNT_SUM,
           D.LOCKED_DOWNPAY_AMOUNT = D.LOCKED_DOWNPAY_AMOUNT + IN_DP_AMOUNT_SUM,
           D.LOCKED_DIS_DP_AMOUNT = D.LOCKED_DISCOUNT_AMOUNT + IN_DP_DISAMOUNT_SUM,
           D.DOWN_PAY_SCALE = IN_DOWNPAY_RATE,
           D.DISCOUNT_TYPE = NVL(IN_DISCOUNT_TYPE, 'COMMON'),
           D.LAST_UPDATED_BY = IN_USER_ACCOUNT,
           D.LAST_UPDATE_DATE = SYSDATE
     WHERE D.ENTITY_ID = IN_ENTITY_ID
       AND D.CUSTOMER_ID = IN_CUSTOMER_ID
       AND D.ACCOUNT_ID = IN_ACCOUNT_ID
       AND D.SRC_TYPE = IN_SRC_TYPE
       AND D.ORIGIN_ORDER_ID = IN_ORDER_ID
       AND D.SALES_MAIN_TYPE = IN_SALES_MAIN_TYPE
       AND D.DISCOUNT_TYPE = NVL(IN_DISCOUNT_TYPE, 'COMMON')
       AND NVL(D.DOWN_PAY_SCALE, -99) = NVL(IN_DOWNPAY_RATE, -99)
       AND NVL(D.PROJ_NUMBER, '-1') = NVL(IN_PROJ_NUMBER, '-1')
     RETURNING D.LOCKED_AMOUNT, D.LOCKED_DISCOUNT_AMOUNT, D.LOCKED_DOWNPAY_AMOUNT, D.LOCKED_DIS_DP_AMOUNT
          INTO V_CURR_AMOUNT, V_CURR_DISAMOUNT, V_CURR_DP_AMOUNT, V_CURR_DP_DISAMOUNT;
          
    IF V_CURR_AMOUNT < 0 OR V_CURR_DISAMOUNT < 0 OR V_CURR_DP_AMOUNT < 0 OR V_CURR_DP_DISAMOUNT < 0 THEN
      OUT_RESULT := -20000;
      OUT_ERR_MSG := '更新后的锁定明细锁定金额为负数';
      RETURN;
    END IF;
    
    IF SQL%NOTFOUND THEN
      IF IN_AMOUNT_SUM < 0 OR IN_DISAMOUNT_SUM < 0 OR IN_DP_AMOUNT_SUM < 0 OR IN_DP_DISAMOUNT_SUM < 0 THEN
        OUT_RESULT := -20000;
        OUT_ERR_MSG := '更新后的锁定明细锁定金额为负数';
        RETURN;
      END IF;
      INSERT INTO T_CREDIT_LOCK_AMOUNT_DETAIL
        (LOCK_DETAIL_ID,
         ENTITY_ID,
         CUSTOMER_ID,
         CUSTOMER_CODE,
         CUSTOMER_NAME,
         ACCOUNT_ID,
         ACCOUNT_CODE,
         ACCOUNT_NAME,
         SALES_MAIN_TYPE,
         SALES_MAIN_TYPE_NAME,
         SRC_TYPE,
         ORIGIN_ORDER_ID,
         ORIGIN_ORDER_NUM,
         --ORDER_NUM,
         PROJ_NUMBER,
         LOCK_METHOD,
         LOCKED_AMOUNT,
         LOCKED_DISCOUNT_AMOUNT,
         LOCKED_DOWNPAY_AMOUNT,
         LOCKED_DIS_DP_AMOUNT,
         SALES_CENTER_ID,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         CREDIT_GROUP_ID,
         CREDIT_GROUP_NAME,
         DISCOUNT_TYPE,
         DOWN_PAY_SCALE,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
      VALUES
        (S_CREDIT_LOCK_AMOUNT_DETAIL.NEXTVAL,
         IN_ENTITY_ID,
         R_LOCK_DETAIL.CUSTOMER_ID,
         R_LOCK_DETAIL.CUSTOMER_CODE,
         R_LOCK_DETAIL.CUSTOMER_NAME,
         R_LOCK_DETAIL.ACCOUNT_ID,
         R_LOCK_DETAIL.ACCOUNT_CODE,
         R_LOCK_DETAIL.ACCOUNT_NAME,
         R_LOCK_DETAIL.SALES_MAIN_TYPE,
         R_LOCK_DETAIL.SALES_MAIN_TYPE_NAME,
         IN_SRC_TYPE,
         IN_ORDER_ID,
         IN_ORDER_NUMBER,
         --V_ORDER_NUM,
         IN_PROJ_NUMBER,
         R_LOCK_DETAIL.LOCK_METHOD,
         IN_AMOUNT_SUM,
         IN_DISAMOUNT_SUM,
         IN_DP_AMOUNT_SUM,
         IN_DP_DISAMOUNT_SUM,
         R_LOCK_DETAIL.SALES_CENTER_ID,
         R_LOCK_DETAIL.SALES_CENTER_CODE,
         R_LOCK_DETAIL.SALES_CENTER_NAME,
         R_LOCK_DETAIL.CREDIT_GROUP_ID,
         R_LOCK_DETAIL.CREDIT_GROUP_NAME,
         NVL(IN_DISCOUNT_TYPE, 'COMMON'),
         IN_DOWNPAY_RATE,
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_USER_ACCOUNT,
         SYSDATE);
    END IF;
    
    --增加客户款项明细锁定到款金额
    UPDATE T_SALES_ACCOUNT_MX_AMOUNT T
       SET T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT + NVL(IN_AMOUNT_SUM, 0) + NVL(IN_DP_AMOUNT_SUM, 0),
           T.LOCK_DISCOUNT_AMOUNT = T.LOCK_DISCOUNT_AMOUNT + NVL(IN_DISAMOUNT_SUM, 0) + NVL(IN_DP_DISAMOUNT_SUM, 0),
           T.LAST_UPDATED_BY      = IN_USER_ACCOUNT,
           T.LAST_UPDATE_DATE     = SYSDATE
     WHERE T.ENTITY_ID = IN_ENTITY_ID
       AND T.CUSTOMER_ID = IN_CUSTOMER_ID
       AND T.ACCOUNT_ID = IN_ACCOUNT_ID
       AND T.SALES_MAIN_TYPE = IN_SALES_MAIN_TYPE
       AND NVL(T.PROJ_NUMBER, '-1') = '-1';
       
    --增加客户款项锁定到款金额
    UPDATE T_SALES_ACCOUNT_AMOUNT T
       SET T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT + NVL(IN_AMOUNT_SUM, 0) + NVL(IN_DP_AMOUNT_SUM, 0),
           T.LOCK_DISCOUNT_AMOUNT = T.LOCK_DISCOUNT_AMOUNT + NVL(IN_DISAMOUNT_SUM, 0) + NVL(IN_DP_DISAMOUNT_SUM, 0),
           T.LAST_UPDATED_BY      = IN_USER_ACCOUNT,
           T.LAST_UPDATE_DATE     = SYSDATE
     WHERE T.ENTITY_ID = IN_ENTITY_ID
       AND T.CUSTOMER_ID = IN_CUSTOMER_ID
       AND T.ACCOUNT_ID = IN_ACCOUNT_ID
       AND NVL(T.CREDIT_GROUP_ID, -1) = NVL(V_CREDIT_GROUP_ID, -1);
       
    --记录锁款事务
    PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_LOCK_TRANS_ADD(IN_ENTITY_ID        => IN_ENTITY_ID,
                                                       IN_CUSTOMER_ID      => IN_CUSTOMER_ID,
                                                       IN_ACCOUNT_ID       => IN_ACCOUNT_ID,
                                                       IN_SALES_MAIN_TYPE  => IN_SALES_MAIN_TYPE,
                                                       IN_CREDIT_GROUP_ID  => V_CREDIT_GROUP_ID,
                                                       IN_PROJ_NUMBER      => IN_PROJ_NUMBER,
                                                       IN_AMOUNT_SUM       => IN_AMOUNT_SUM,
                                                       IN_DISAMOUNT_SUM    => IN_DISAMOUNT_SUM,
                                                       IN_DP_AMOUNT_SUM    => IN_DP_AMOUNT_SUM,
                                                       IN_DP_DISAMOUNT_SUM => IN_DP_DISAMOUNT_SUM,
                                                       IN_DISCOUNT_TYPE    => IN_DISCOUNT_TYPE,
                                                       IN_ORDER_ID         => IN_ORDER_ID,
                                                       IN_ORDER_NUMBER     => IN_ORDER_NUMBER,
                                                       IN_SRC_TYPE         => IN_SRC_TYPE,
                                                       IN_USER_ACCOUNT     => IN_USER_ACCOUNT,
                                                       OUT_RESULT          => OUT_RESULT,
                                                       OUT_ERR_MSG         => OUT_ERR_MSG);
    IF OUT_RESULT <> V_SEC_RESULT THEN
      OUT_RESULT := -20000;
      OUT_ERR_MSG := '记录锁款事务失败！' || V_NL || '错误信息：' || OUT_ERR_MSG;
    END IF;
  END P_CREDIT_LOCK_DETAIL_HAND;
  
  PROCEDURE P_CREDIT_LOCK_TRANS_ADD(IN_ENTITY_ID       IN NUMBER, --主体ID
                                    IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                    IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                    IN_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                    IN_CREDIT_GROUP_ID IN NUMBER, --额度组ID
                                    IN_PROJ_NUMBER     IN VARCHAR2, --项目号
                                    IN_AMOUNT_SUM      IN NUMBER, --结算金额(需传正负号)
                                    IN_DISAMOUNT_SUM   IN NUMBER, --折让金额(需传正负号)
                                    IN_DP_AMOUNT_SUM   IN NUMBER, --订金金额(需传正负号)
                                    IN_DP_DISAMOUNT_SUM IN NUMBER, --折让订金金额(需传正负号)
                                    IN_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 COMMON/DISCOUNT
                                    IN_ORDER_ID        IN NUMBER, --单据ID
                                    IN_ORDER_NUMBER    IN VARCHAR2, --单据号
                                    IN_SRC_TYPE        IN VARCHAR2, --来源类型
                                    IN_USER_ACCOUNT    IN VARCHAR2, --操作用户
                                    OUT_RESULT         IN OUT NUMBER, --返回错误ID
                                    OUT_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                    )
  IS
    R_AMOUNT_TRANS T_SALES_AMOUNT_TRANS%ROWTYPE;
  BEGIN
    OUT_RESULT := V_SEC_RESULT;
    OUT_ERR_MSG := V_SUCCESS;
    
    IF IN_AMOUNT_SUM <> 0 THEN
      INSERT INTO T_SALES_AMOUNT_TRANS
        (TRANS_ID,
         ENTITY_ID,
         CUSTOMER_ID,
         ACCOUNT_ID,
         CREDIT_GROUP_ID,
         PROJ_NUMBER,
         SALES_MAIN_TYPE,
         ORDER_ID,
         ORDER_TYPE,
         ACTION_FLAG,
         TRANS_ACTION,
         AMOUNT_NAME,
         AMOUNT,
         DUE_FLAG,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         ORDER_NUM)
      VALUES
        (S_SALES_AMOUNT_TRANS.NEXTVAL,
         IN_ENTITY_ID,
         IN_CUSTOMER_ID,
         IN_ACCOUNT_ID,
         IN_CREDIT_GROUP_ID,
         IN_PROJ_NUMBER,
         IN_SALES_MAIN_TYPE,
         IN_ORDER_ID,
         IN_SRC_TYPE,
         DECODE(SIGN(IN_AMOUNT_SUM), 1, 1, -1, 2),
         DECODE(SIGN(IN_AMOUNT_SUM), 1, '1', -1, '2'),
         '锁定到款金额',
         IN_AMOUNT_SUM,
         '1',
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_ORDER_NUMBER);
    END IF;
    
    IF IN_DISAMOUNT_SUM <> 0 THEN
      INSERT INTO T_SALES_AMOUNT_TRANS
        (TRANS_ID,
         ENTITY_ID,
         CUSTOMER_ID,
         ACCOUNT_ID,
         CREDIT_GROUP_ID,
         PROJ_NUMBER,
         SALES_MAIN_TYPE,
         ORDER_ID,
         ORDER_TYPE,
         ACTION_FLAG,
         TRANS_ACTION,
         AMOUNT_NAME,
         AMOUNT,
         DUE_FLAG,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         ORDER_NUM)
      VALUES
        (S_SALES_AMOUNT_TRANS.NEXTVAL,
         IN_ENTITY_ID,
         IN_CUSTOMER_ID,
         IN_ACCOUNT_ID,
         IN_CREDIT_GROUP_ID,
         IN_PROJ_NUMBER,
         IN_SALES_MAIN_TYPE,
         IN_ORDER_ID,
         IN_SRC_TYPE,
         DECODE(SIGN(IN_DISAMOUNT_SUM), 1, 1, -1, 2),
         DECODE(SIGN(IN_DISAMOUNT_SUM), 1, '1', -1, '2'),
         '锁定折让金额',
         IN_DISAMOUNT_SUM,
         '1',
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_ORDER_NUMBER);
    END IF;
    
    IF IN_DP_AMOUNT_SUM <> 0 THEN
      INSERT INTO T_SALES_AMOUNT_TRANS
        (TRANS_ID,
         ENTITY_ID,
         CUSTOMER_ID,
         ACCOUNT_ID,
         CREDIT_GROUP_ID,
         PROJ_NUMBER,
         SALES_MAIN_TYPE,
         ORDER_ID,
         ORDER_TYPE,
         ACTION_FLAG,
         TRANS_ACTION,
         AMOUNT_NAME,
         AMOUNT,
         DUE_FLAG,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         ORDER_NUM)
      VALUES
        (S_SALES_AMOUNT_TRANS.NEXTVAL,
         IN_ENTITY_ID,
         IN_CUSTOMER_ID,
         IN_ACCOUNT_ID,
         IN_CREDIT_GROUP_ID,
         IN_PROJ_NUMBER,
         IN_SALES_MAIN_TYPE,
         IN_ORDER_ID,
         IN_SRC_TYPE,
         DECODE(SIGN(IN_DP_AMOUNT_SUM), 1, 1, -1, 2),
         DECODE(SIGN(IN_DP_AMOUNT_SUM), 1, '1', -1, '2'),
         '锁定到款金额(订金)',
         IN_DP_AMOUNT_SUM,
         '1',
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_ORDER_NUMBER);
    END IF;
    
    IF IN_DP_DISAMOUNT_SUM <> 0 THEN
      INSERT INTO T_SALES_AMOUNT_TRANS
        (TRANS_ID,
         ENTITY_ID,
         CUSTOMER_ID,
         ACCOUNT_ID,
         CREDIT_GROUP_ID,
         PROJ_NUMBER,
         SALES_MAIN_TYPE,
         ORDER_ID,
         ORDER_TYPE,
         ACTION_FLAG,
         TRANS_ACTION,
         AMOUNT_NAME,
         AMOUNT,
         DUE_FLAG,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         ORDER_NUM)
      VALUES
        (S_SALES_AMOUNT_TRANS.NEXTVAL,
         IN_ENTITY_ID,
         IN_CUSTOMER_ID,
         IN_ACCOUNT_ID,
         IN_CREDIT_GROUP_ID,
         IN_PROJ_NUMBER,
         IN_SALES_MAIN_TYPE,
         IN_ORDER_ID,
         IN_SRC_TYPE,
         DECODE(SIGN(IN_DP_DISAMOUNT_SUM), 1, 1, -1, 2),
         DECODE(SIGN(IN_DP_DISAMOUNT_SUM), 1, '1', -1, '2'),
         '锁定折让金额(订金)',
         IN_DP_DISAMOUNT_SUM,
         '1',
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_ORDER_NUMBER);
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
  
  PROCEDURE P_CREDIT_LOCK_HAND_TCC(IN_ENTITY_ID       IN NUMBER, --主体ID
                               IN_CUSTOMER_ID     IN NUMBER, --客户ID
                               IN_ACCOUNT_ID      IN NUMBER, --账户ID
                               IN_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                               IN_PROJ_NUMBER     IN VARCHAR2, --项目号
                               IN_AMOUNT_SUM      IN NUMBER, --结算金额(需传正负号)
                               IN_DISAMOUNT_SUM   IN NUMBER, --折让金额(需传正负号)
                               IN_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 COMMON/DISCOUNT
                               IN_ORDER_ID        IN NUMBER, --单据ID
                               IN_ORDER_NUMBER    IN VARCHAR2, --单据号
                               IN_DOWNPAY_RATE    IN NUMBER, --订金比例
                               IN_SRC_TYPE        IN VARCHAR2, --来源类型
                               IN_USER_ACCOUNT    IN VARCHAR2, --操作用户
                               OUT_RESULT         IN OUT NUMBER, --返回错误ID
                               OUT_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                               ,IN_TCC_ID         IN VARCHAR2 --分布式事务ID
                               ,IN_TCC_IDEMPOTENT_ID  IN VARCHAR2 --分布式幂等性ID
                               )
 IS
   V_CURR_AMOUNT_SUM NUMBER;
   V_CURR_DISAMOUNT_SUM NUMBER;
 BEGIN
   OUT_RESULT := V_SEC_RESULT;
   OUT_ERR_MSG := V_SUCCESS;
   
   --金额为0，返回成功
   V_CURR_AMOUNT_SUM := NVL(IN_AMOUNT_SUM, 0);
   V_CURR_DISAMOUNT_SUM := NVL(IN_DISAMOUNT_SUM, 0);
   IF V_CURR_AMOUNT_SUM = 0 AND V_CURR_DISAMOUNT_SUM = 0 THEN
     RETURN;
   END IF;
   
   --余额金额校验
   PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_CHECK_AMOUNT(IN_ENTITY_ID       => IN_ENTITY_ID,
                                                    IN_CUSTOMER_ID     => IN_CUSTOMER_ID,
                                                    IN_ACCOUNT_ID      => IN_ACCOUNT_ID,
                                                    IN_SALES_MAIN_TYPE => IN_SALES_MAIN_TYPE,
                                                    IN_PROJ_NUMBER     => IN_PROJ_NUMBER,
                                                    IN_AMOUNT_SUM      => V_CURR_AMOUNT_SUM,
                                                    IN_DISAMOUNT_SUM   => V_CURR_DISAMOUNT_SUM,
                                                    IN_DISCOUNT_TYPE   => IN_DISCOUNT_TYPE,
                                                    IN_USER_ACCOUNT    => IN_USER_ACCOUNT,
                                                    OUT_RESULT         => OUT_RESULT,
                                                    OUT_ERR_MSG        => OUT_ERR_MSG);
   --校验不通过直接返回
   IF OUT_RESULT <> V_SEC_RESULT THEN
     RETURN;
   END IF;
   
   SAVEPOINT SAVEPOINT_CREDIT;
   --锁款金额处理
   PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_LOCK_DETAIL_HAND_TCC(IN_ENTITY_ID        => IN_ENTITY_ID,
                                                        IN_CUSTOMER_ID      => IN_CUSTOMER_ID,
                                                        IN_ACCOUNT_ID       => IN_ACCOUNT_ID,
                                                        IN_SALES_MAIN_TYPE  => IN_SALES_MAIN_TYPE,
                                                        IN_PROJ_NUMBER      => IN_PROJ_NUMBER,
                                                        IN_AMOUNT_SUM       => V_CURR_AMOUNT_SUM,
                                                        IN_DISAMOUNT_SUM    => V_CURR_DISAMOUNT_SUM,
                                                        IN_DP_AMOUNT_SUM    => 0,
                                                        IN_DP_DISAMOUNT_SUM => 0,
                                                        IN_DISCOUNT_TYPE    => IN_DISCOUNT_TYPE,
                                                        IN_ORDER_ID         => IN_ORDER_ID,
                                                        IN_ORDER_NUMBER     => IN_ORDER_NUMBER,
                                                        IN_DOWNPAY_RATE     => IN_DOWNPAY_RATE,
                                                        IN_SRC_TYPE         => IN_SRC_TYPE,
                                                        IN_USER_ACCOUNT     => IN_USER_ACCOUNT,
                                                        OUT_RESULT          => OUT_RESULT,
                                                        OUT_ERR_MSG         => OUT_ERR_MSG
                                                        ,IN_TCC_ID           => IN_TCC_ID
                                                        ,IN_TCC_IDEMPOTENT_ID   => IN_TCC_IDEMPOTENT_ID);
   IF OUT_RESULT <> V_SEC_RESULT THEN
     OUT_RESULT := '-20000';
     OUT_ERR_MSG := '更新客户款项失败！' || V_NL || '错误信息：' || OUT_ERR_MSG;
     ROLLBACK TO SAVEPOINT SAVEPOINT_CREDIT;
     RETURN;
   END IF; 
   
 EXCEPTION
    WHEN OTHERS THEN
      OUT_RESULT := '-20000';
      OUT_ERR_MSG := '处理客户款项出错！' || V_NL || '错误信息：' || sqlerrm;
      ROLLBACK TO SAVEPOINT SAVEPOINT_CREDIT;
 END P_CREDIT_LOCK_HAND_TCC;
 
 
 PROCEDURE P_CREDIT_LOCK_DETAIL_HAND_TCC(IN_ENTITY_ID       IN NUMBER, --主体ID
                                      IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                      IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                      IN_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                      IN_PROJ_NUMBER     IN VARCHAR2, --项目号
                                      IN_AMOUNT_SUM      IN NUMBER, --结算金额(需传正负号)
                                      IN_DISAMOUNT_SUM   IN NUMBER, --折让金额(需传正负号)
                                      IN_DP_AMOUNT_SUM   IN NUMBER, --订金金额(需传正负号)
                                      IN_DP_DISAMOUNT_SUM IN NUMBER, --折让订金金额(需传正负号)
                                      IN_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 COMMON/DISCOUNT
                                      IN_ORDER_ID        IN NUMBER, --单据ID
                                      IN_ORDER_NUMBER    IN VARCHAR2, --单据号
                                      IN_DOWNPAY_RATE    IN NUMBER, --订金比例（提货订单、计划订单使用）
                                      IN_SRC_TYPE        IN VARCHAR2, --来源类型
                                      IN_USER_ACCOUNT    IN VARCHAR2, --操作用户
                                      OUT_RESULT         IN OUT NUMBER, --返回错误ID
                                      OUT_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                      ,IN_TCC_ID         IN VARCHAR2 --分布式事务ID
                                      ,IN_TCC_IDEMPOTENT_ID  IN VARCHAR2 --分布式幂等性ID
                                      )
  IS
    V_CURR_AMOUNT NUMBER := 0;
    V_CURR_DISAMOUNT NUMBER := 0;
    V_CURR_DP_AMOUNT NUMBER := 0;
    V_CURR_DP_DISAMOUNT NUMBER := 0;
    V_CREDIT_GROUP_ID NUMBER; --额度组ID
    R_LOCK_DETAIL T_CREDIT_LOCK_AMOUNT_DETAIL%ROWTYPE;
  BEGIN
    OUT_RESULT := V_SEC_RESULT;
    OUT_ERR_MSG := V_SUCCESS;
   
    --获取额度组
    V_CREDIT_GROUP_ID := pkg_credit_tools.FUN_GET_CREDITGROUPID(IN_ENTITY_ID, IN_CUSTOMER_ID, IN_SALES_MAIN_TYPE, IN_ACCOUNT_ID);
    
    DELETE FROM T_CREDIT_LOCK_AMOUNT_DETAIL D
     WHERE D.ENTITY_ID = IN_ENTITY_ID
       AND D.SRC_TYPE = IN_SRC_TYPE
       AND D.ORIGIN_ORDER_ID = IN_ORDER_ID
       --AND NVL(D.PROJ_NUMBER, '-1') = NVL(IN_PROJ_NUMBER, '-1')
       AND D.LOCKED_AMOUNT = 0
       AND D.LOCKED_DISCOUNT_AMOUNT = 0
       AND D.LOCKED_DOWNPAY_AMOUNT = 0
       AND D.LOCKED_DIS_DP_AMOUNT = 0;
    
    SELECT S.CUSTOMER_ID, S.CUSTOMER_CODE, S.CUSTOMER_NAME,
           S.account_id, S.account_code, S.account_name,
           S.sales_center_id, S.sales_center_code, S.sales_center_name
      INTO R_LOCK_DETAIL.CUSTOMER_ID,
           R_LOCK_DETAIL.CUSTOMER_CODE,
           R_LOCK_DETAIL.CUSTOMER_NAME,
           R_LOCK_DETAIL.ACCOUNT_ID,
           R_LOCK_DETAIL.ACCOUNT_CODE,
           R_LOCK_DETAIL.ACCOUNT_NAME,
           R_LOCK_DETAIL.SALES_CENTER_ID,
           R_LOCK_DETAIL.SALES_CENTER_CODE,
           R_LOCK_DETAIL.SALES_CENTER_NAME
      FROM V_CUSTOMER_ACCOUNT_SALECENTER S
     WHERE S.entity_id = IN_ENTITY_ID
       AND S.CUSTOMER_ID = IN_CUSTOMER_ID
       AND S.account_id = IN_ACCOUNT_ID;
    
    BEGIN
      SELECT C.CLASS_CODE, C.CLASS_NAME
        INTO R_LOCK_DETAIL.SALES_MAIN_TYPE,
             R_LOCK_DETAIL.SALES_MAIN_TYPE_NAME
        FROM T_BD_ITEM_CLASS C
       WHERE C.ENTITY_ID = IN_ENTITY_ID
         AND C.CLASS_CODE = IN_SALES_MAIN_TYPE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        R_LOCK_DETAIL.SALES_MAIN_TYPE := NULL;
        R_LOCK_DETAIL.SALES_MAIN_TYPE_NAME := NULL;
    END;
    
    BEGIN
      SELECT G.CREDIT_GROUP_ID, G.CREDIT_GROUP_NUM
        INTO R_LOCK_DETAIL.CREDIT_GROUP_ID,
             R_LOCK_DETAIL.CREDIT_GROUP_NAME
        FROM T_CREDIT_GROUP G
       WHERE G.CREDIT_GROUP_ID = V_CREDIT_GROUP_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        R_LOCK_DETAIL.SALES_MAIN_TYPE := NULL;
        R_LOCK_DETAIL.SALES_MAIN_TYPE_NAME := NULL;
    END;
    
    BEGIN
      SELECT CASE
               WHEN IN_SRC_TYPE = '02' THEN
                 (SELECT UC.CODE_NAME
                    FROM T_PLN_LG_ORDER_HEAD H, UP_CODELIST UC
                   WHERE H.ORDER_HEAD_ID = IN_ORDER_ID
                     AND H.LOCK_AMOUNT_FLAG = UC.CODE_VALUE
                     AND UC.CODETYPE = 'plnlockMoneyFlag')
               WHEN IN_SRC_TYPE = '01' THEN
                 (SELECT UC.CODE_NAME
                    FROM T_PLN_ORDER_HEAD H, UP_CODELIST UC
                   WHERE H.ORDER_HEAD_ID = IN_ORDER_ID
                     AND H.LOCK_AMOUNT_FLAG = UC.CODE_VALUE
                     AND UC.CODETYPE = 'plnlockMoneyFlag')
               ELSE
                 NULL
             END
        INTO R_LOCK_DETAIL.LOCK_METHOD
        FROM DUAL;
    END;
    
    --更新锁定明细
    UPDATE T_CREDIT_LOCK_AMOUNT_DETAIL D
       SET D.CUSTOMER_ID = R_LOCK_DETAIL.CUSTOMER_ID,
           D.CUSTOMER_CODE = R_LOCK_DETAIL.CUSTOMER_CODE,
           D.CUSTOMER_NAME = R_LOCK_DETAIL.CUSTOMER_NAME,
           D.ACCOUNT_ID = R_LOCK_DETAIL.ACCOUNT_ID,
           D.ACCOUNT_CODE = R_LOCK_DETAIL.ACCOUNT_CODE,
           D.ACCOUNT_NAME = R_LOCK_DETAIL.ACCOUNT_NAME,
           D.SALES_CENTER_ID = R_LOCK_DETAIL.SALES_CENTER_ID,
           D.SALES_CENTER_CODE = R_LOCK_DETAIL.SALES_CENTER_CODE,
           D.SALES_CENTER_NAME = R_LOCK_DETAIL.SALES_CENTER_NAME,
           D.SALES_MAIN_TYPE = R_LOCK_DETAIL.SALES_MAIN_TYPE,
           D.SALES_MAIN_TYPE_NAME = R_LOCK_DETAIL.SALES_MAIN_TYPE_NAME,
           D.CREDIT_GROUP_ID = R_LOCK_DETAIL.CREDIT_GROUP_ID,
           D.CREDIT_GROUP_NAME = R_LOCK_DETAIL.CREDIT_GROUP_NAME,
           D.LOCK_METHOD = R_LOCK_DETAIL.LOCK_METHOD,
           D.SRC_TYPE = IN_SRC_TYPE,
           D.ORIGIN_ORDER_ID = IN_ORDER_ID,
           D.ORIGIN_ORDER_NUM = IN_ORDER_NUMBER,
           D.LOCKED_AMOUNT = D.LOCKED_AMOUNT + IN_AMOUNT_SUM,
           D.LOCKED_DISCOUNT_AMOUNT = D.LOCKED_DISCOUNT_AMOUNT + IN_DISAMOUNT_SUM,
           D.LOCKED_DOWNPAY_AMOUNT = D.LOCKED_DOWNPAY_AMOUNT + IN_DP_AMOUNT_SUM,
           D.LOCKED_DIS_DP_AMOUNT = D.LOCKED_DISCOUNT_AMOUNT + IN_DP_DISAMOUNT_SUM,
           D.DOWN_PAY_SCALE = IN_DOWNPAY_RATE,
           D.DISCOUNT_TYPE = NVL(IN_DISCOUNT_TYPE, 'COMMON'),
           D.LAST_UPDATED_BY = IN_USER_ACCOUNT,
           D.LAST_UPDATE_DATE = SYSDATE
     WHERE D.ENTITY_ID = IN_ENTITY_ID
       AND D.CUSTOMER_ID = IN_CUSTOMER_ID
       AND D.ACCOUNT_ID = IN_ACCOUNT_ID
       AND D.SRC_TYPE = IN_SRC_TYPE
       AND D.ORIGIN_ORDER_ID = IN_ORDER_ID
       AND D.SALES_MAIN_TYPE = IN_SALES_MAIN_TYPE
       AND D.DISCOUNT_TYPE = NVL(IN_DISCOUNT_TYPE, 'COMMON')
       AND NVL(D.DOWN_PAY_SCALE, -99) = NVL(IN_DOWNPAY_RATE, -99)
       AND NVL(D.PROJ_NUMBER, '-1') = NVL(IN_PROJ_NUMBER, '-1')
     RETURNING D.LOCKED_AMOUNT, D.LOCKED_DISCOUNT_AMOUNT, D.LOCKED_DOWNPAY_AMOUNT, D.LOCKED_DIS_DP_AMOUNT
          INTO V_CURR_AMOUNT, V_CURR_DISAMOUNT, V_CURR_DP_AMOUNT, V_CURR_DP_DISAMOUNT;
          
    IF V_CURR_AMOUNT < 0 OR V_CURR_DISAMOUNT < 0 OR V_CURR_DP_AMOUNT < 0 OR V_CURR_DP_DISAMOUNT < 0 THEN
      OUT_RESULT := -20000;
      OUT_ERR_MSG := '更新后的锁定明细锁定金额为负数';
      RETURN;
    END IF;
    
    IF SQL%NOTFOUND THEN
      IF IN_AMOUNT_SUM < 0 OR IN_DISAMOUNT_SUM < 0 OR IN_DP_AMOUNT_SUM < 0 OR IN_DP_DISAMOUNT_SUM < 0 THEN
        OUT_RESULT := -20000;
        OUT_ERR_MSG := '更新后的锁定明细锁定金额为负数';
        RETURN;
      END IF;
      INSERT INTO T_CREDIT_LOCK_AMOUNT_DETAIL
        (LOCK_DETAIL_ID,
         ENTITY_ID,
         CUSTOMER_ID,
         CUSTOMER_CODE,
         CUSTOMER_NAME,
         ACCOUNT_ID,
         ACCOUNT_CODE,
         ACCOUNT_NAME,
         SALES_MAIN_TYPE,
         SALES_MAIN_TYPE_NAME,
         SRC_TYPE,
         ORIGIN_ORDER_ID,
         ORIGIN_ORDER_NUM,
         --ORDER_NUM,
         PROJ_NUMBER,
         LOCK_METHOD,
         LOCKED_AMOUNT,
         LOCKED_DISCOUNT_AMOUNT,
         LOCKED_DOWNPAY_AMOUNT,
         LOCKED_DIS_DP_AMOUNT,
         SALES_CENTER_ID,
         SALES_CENTER_CODE,
         SALES_CENTER_NAME,
         CREDIT_GROUP_ID,
         CREDIT_GROUP_NAME,
         DISCOUNT_TYPE,
         DOWN_PAY_SCALE,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
      VALUES
        (S_CREDIT_LOCK_AMOUNT_DETAIL.NEXTVAL,
         IN_ENTITY_ID,
         R_LOCK_DETAIL.CUSTOMER_ID,
         R_LOCK_DETAIL.CUSTOMER_CODE,
         R_LOCK_DETAIL.CUSTOMER_NAME,
         R_LOCK_DETAIL.ACCOUNT_ID,
         R_LOCK_DETAIL.ACCOUNT_CODE,
         R_LOCK_DETAIL.ACCOUNT_NAME,
         R_LOCK_DETAIL.SALES_MAIN_TYPE,
         R_LOCK_DETAIL.SALES_MAIN_TYPE_NAME,
         IN_SRC_TYPE,
         IN_ORDER_ID,
         IN_ORDER_NUMBER,
         --V_ORDER_NUM,
         IN_PROJ_NUMBER,
         R_LOCK_DETAIL.LOCK_METHOD,
         IN_AMOUNT_SUM,
         IN_DISAMOUNT_SUM,
         IN_DP_AMOUNT_SUM,
         IN_DP_DISAMOUNT_SUM,
         R_LOCK_DETAIL.SALES_CENTER_ID,
         R_LOCK_DETAIL.SALES_CENTER_CODE,
         R_LOCK_DETAIL.SALES_CENTER_NAME,
         R_LOCK_DETAIL.CREDIT_GROUP_ID,
         R_LOCK_DETAIL.CREDIT_GROUP_NAME,
         NVL(IN_DISCOUNT_TYPE, 'COMMON'),
         IN_DOWNPAY_RATE,
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_USER_ACCOUNT,
         SYSDATE);
    END IF;
    
    --增加客户款项明细锁定到款金额
    UPDATE T_SALES_ACCOUNT_MX_AMOUNT T
       SET T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT + NVL(IN_AMOUNT_SUM, 0) + NVL(IN_DP_AMOUNT_SUM, 0),
           T.LOCK_DISCOUNT_AMOUNT = T.LOCK_DISCOUNT_AMOUNT + NVL(IN_DISAMOUNT_SUM, 0) + NVL(IN_DP_DISAMOUNT_SUM, 0),
           T.LAST_UPDATED_BY      = IN_USER_ACCOUNT,
           T.LAST_UPDATE_DATE     = SYSDATE
     WHERE T.ENTITY_ID = IN_ENTITY_ID
       AND T.CUSTOMER_ID = IN_CUSTOMER_ID
       AND T.ACCOUNT_ID = IN_ACCOUNT_ID
       AND T.SALES_MAIN_TYPE = IN_SALES_MAIN_TYPE
       AND NVL(T.PROJ_NUMBER, '-1') = '-1';
       
    --增加客户款项锁定到款金额
    UPDATE T_SALES_ACCOUNT_AMOUNT T
       SET T.LOCK_RECEIVED_AMOUNT = T.LOCK_RECEIVED_AMOUNT + NVL(IN_AMOUNT_SUM, 0) + NVL(IN_DP_AMOUNT_SUM, 0),
           T.LOCK_DISCOUNT_AMOUNT = T.LOCK_DISCOUNT_AMOUNT + NVL(IN_DISAMOUNT_SUM, 0) + NVL(IN_DP_DISAMOUNT_SUM, 0),
           T.LAST_UPDATED_BY      = IN_USER_ACCOUNT,
           T.LAST_UPDATE_DATE     = SYSDATE
     WHERE T.ENTITY_ID = IN_ENTITY_ID
       AND T.CUSTOMER_ID = IN_CUSTOMER_ID
       AND T.ACCOUNT_ID = IN_ACCOUNT_ID
       AND NVL(T.CREDIT_GROUP_ID, -1) = NVL(V_CREDIT_GROUP_ID, -1);
       
    --记录锁款事务
    PKG_CREDIT_ACCOUNT_CONTROL.P_CREDIT_LOCK_TRANS_ADD_TCC(IN_ENTITY_ID        => IN_ENTITY_ID,
                                                       IN_CUSTOMER_ID      => IN_CUSTOMER_ID,
                                                       IN_ACCOUNT_ID       => IN_ACCOUNT_ID,
                                                       IN_SALES_MAIN_TYPE  => IN_SALES_MAIN_TYPE,
                                                       IN_CREDIT_GROUP_ID  => V_CREDIT_GROUP_ID,
                                                       IN_PROJ_NUMBER      => IN_PROJ_NUMBER,
                                                       IN_AMOUNT_SUM       => IN_AMOUNT_SUM,
                                                       IN_DISAMOUNT_SUM    => IN_DISAMOUNT_SUM,
                                                       IN_DP_AMOUNT_SUM    => IN_DP_AMOUNT_SUM,
                                                       IN_DP_DISAMOUNT_SUM => IN_DP_DISAMOUNT_SUM,
                                                       IN_DISCOUNT_TYPE    => IN_DISCOUNT_TYPE,
                                                       IN_ORDER_ID         => IN_ORDER_ID,
                                                       IN_ORDER_NUMBER     => IN_ORDER_NUMBER,
                                                       IN_SRC_TYPE         => IN_SRC_TYPE,
                                                       IN_USER_ACCOUNT     => IN_USER_ACCOUNT,
                                                       OUT_RESULT          => OUT_RESULT,
                                                       OUT_ERR_MSG         => OUT_ERR_MSG
                                                       ,IN_TCC_ID           => IN_TCC_ID
                                                       ,IN_TCC_IDEMPOTENT_ID   => IN_TCC_IDEMPOTENT_ID);
    IF OUT_RESULT <> V_SEC_RESULT THEN
      OUT_RESULT := -20000;
      OUT_ERR_MSG := '记录锁款事务失败！' || V_NL || '错误信息：' || OUT_ERR_MSG;
    END IF;
  END P_CREDIT_LOCK_DETAIL_HAND_TCC;
  
  PROCEDURE P_CREDIT_LOCK_TRANS_ADD_TCC(IN_ENTITY_ID       IN NUMBER, --主体ID
                                    IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                    IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                    IN_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                    IN_CREDIT_GROUP_ID IN NUMBER, --额度组ID
                                    IN_PROJ_NUMBER     IN VARCHAR2, --项目号
                                    IN_AMOUNT_SUM      IN NUMBER, --结算金额(需传正负号)
                                    IN_DISAMOUNT_SUM   IN NUMBER, --折让金额(需传正负号)
                                    IN_DP_AMOUNT_SUM   IN NUMBER, --订金金额(需传正负号)
                                    IN_DP_DISAMOUNT_SUM IN NUMBER, --折让订金金额(需传正负号)
                                    IN_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 COMMON/DISCOUNT
                                    IN_ORDER_ID        IN NUMBER, --单据ID
                                    IN_ORDER_NUMBER    IN VARCHAR2, --单据号
                                    IN_SRC_TYPE        IN VARCHAR2, --来源类型
                                    IN_USER_ACCOUNT    IN VARCHAR2, --操作用户
                                    OUT_RESULT         IN OUT NUMBER, --返回错误ID
                                    OUT_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                    ,IN_TCC_ID         IN VARCHAR2 --分布式事务ID
                                    ,IN_TCC_IDEMPOTENT_ID  IN VARCHAR2 --分布式幂等性ID
                                    )
  IS
    R_AMOUNT_TRANS T_SALES_AMOUNT_TRANS%ROWTYPE;
    V_TRANS_ID T_SALES_AMOUNT_TRANS.TRANS_ID%TYPE;
  BEGIN
    OUT_RESULT := V_SEC_RESULT;
    OUT_ERR_MSG := V_SUCCESS;
    
    IF IN_AMOUNT_SUM <> 0 THEN
      V_TRANS_ID := S_SALES_AMOUNT_TRANS.NEXTVAL;
      INSERT INTO T_SALES_AMOUNT_TRANS
        (TRANS_ID,
         ENTITY_ID,
         CUSTOMER_ID,
         ACCOUNT_ID,
         CREDIT_GROUP_ID,
         PROJ_NUMBER,
         SALES_MAIN_TYPE,
         ORDER_ID,
         ORDER_TYPE,
         ACTION_FLAG,
         TRANS_ACTION,
         AMOUNT_NAME,
         AMOUNT,
         DUE_FLAG,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         ORDER_NUM)
      VALUES
        (V_TRANS_ID,
         IN_ENTITY_ID,
         IN_CUSTOMER_ID,
         IN_ACCOUNT_ID,
         IN_CREDIT_GROUP_ID,
         IN_PROJ_NUMBER,
         IN_SALES_MAIN_TYPE,
         IN_ORDER_ID,
         IN_SRC_TYPE,
         DECODE(SIGN(IN_AMOUNT_SUM), 1, 1, -1, 2),
         DECODE(SIGN(IN_AMOUNT_SUM), 1, '1', -1, '2'),
         '锁定到款金额',
         IN_AMOUNT_SUM,
         '1',
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_ORDER_NUMBER);
         
       INSERT INTO T_SALES_AMOUNT_TRANS_TCC
         (TRANS_ID
         ,TCC_ID
         ,TCC_RESULT
         ,TCC_IDEMPOTENT_ID)
       VALUES
        (V_TRANS_ID
         ,IN_TCC_ID
         ,'2'
         ,IN_TCC_IDEMPOTENT_ID);
    END IF;
    
    IF IN_DISAMOUNT_SUM <> 0 THEN
      V_TRANS_ID := S_SALES_AMOUNT_TRANS.NEXTVAL;
      INSERT INTO T_SALES_AMOUNT_TRANS
        (TRANS_ID,
         ENTITY_ID,
         CUSTOMER_ID,
         ACCOUNT_ID,
         CREDIT_GROUP_ID,
         PROJ_NUMBER,
         SALES_MAIN_TYPE,
         ORDER_ID,
         ORDER_TYPE,
         ACTION_FLAG,
         TRANS_ACTION,
         AMOUNT_NAME,
         AMOUNT,
         DUE_FLAG,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         ORDER_NUM)
      VALUES
        (V_TRANS_ID,
         IN_ENTITY_ID,
         IN_CUSTOMER_ID,
         IN_ACCOUNT_ID,
         IN_CREDIT_GROUP_ID,
         IN_PROJ_NUMBER,
         IN_SALES_MAIN_TYPE,
         IN_ORDER_ID,
         IN_SRC_TYPE,
         DECODE(SIGN(IN_DISAMOUNT_SUM), 1, 1, -1, 2),
         DECODE(SIGN(IN_DISAMOUNT_SUM), 1, '1', -1, '2'),
         '锁定折让金额',
         IN_DISAMOUNT_SUM,
         '1',
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_ORDER_NUMBER);
         
       INSERT INTO T_SALES_AMOUNT_TRANS_TCC
         (TRANS_ID
         ,TCC_ID
         ,TCC_RESULT
         ,TCC_IDEMPOTENT_ID)
       VALUES
        (V_TRANS_ID
         ,IN_TCC_ID
         ,'2'
         ,IN_TCC_IDEMPOTENT_ID);
    END IF;
    
    IF IN_DP_AMOUNT_SUM <> 0 THEN
      V_TRANS_ID := S_SALES_AMOUNT_TRANS.NEXTVAL;
      INSERT INTO T_SALES_AMOUNT_TRANS
        (TRANS_ID,
         ENTITY_ID,
         CUSTOMER_ID,
         ACCOUNT_ID,
         CREDIT_GROUP_ID,
         PROJ_NUMBER,
         SALES_MAIN_TYPE,
         ORDER_ID,
         ORDER_TYPE,
         ACTION_FLAG,
         TRANS_ACTION,
         AMOUNT_NAME,
         AMOUNT,
         DUE_FLAG,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         ORDER_NUM)
      VALUES
        (V_TRANS_ID,
         IN_ENTITY_ID,
         IN_CUSTOMER_ID,
         IN_ACCOUNT_ID,
         IN_CREDIT_GROUP_ID,
         IN_PROJ_NUMBER,
         IN_SALES_MAIN_TYPE,
         IN_ORDER_ID,
         IN_SRC_TYPE,
         DECODE(SIGN(IN_DP_AMOUNT_SUM), 1, 1, -1, 2),
         DECODE(SIGN(IN_DP_AMOUNT_SUM), 1, '1', -1, '2'),
         '锁定到款金额(订金)',
         IN_DP_AMOUNT_SUM,
         '1',
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_ORDER_NUMBER);
         
       INSERT INTO T_SALES_AMOUNT_TRANS_TCC
         (TRANS_ID
         ,TCC_ID
         ,TCC_RESULT
         ,TCC_IDEMPOTENT_ID)
       VALUES
        (V_TRANS_ID
         ,IN_TCC_ID
         ,'2'
         ,IN_TCC_IDEMPOTENT_ID);
    END IF;
    
    IF IN_DP_DISAMOUNT_SUM <> 0 THEN
      V_TRANS_ID := S_SALES_AMOUNT_TRANS.NEXTVAL;
      INSERT INTO T_SALES_AMOUNT_TRANS
        (TRANS_ID,
         ENTITY_ID,
         CUSTOMER_ID,
         ACCOUNT_ID,
         CREDIT_GROUP_ID,
         PROJ_NUMBER,
         SALES_MAIN_TYPE,
         ORDER_ID,
         ORDER_TYPE,
         ACTION_FLAG,
         TRANS_ACTION,
         AMOUNT_NAME,
         AMOUNT,
         DUE_FLAG,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE,
         ORDER_NUM)
      VALUES
        (V_TRANS_ID,
         IN_ENTITY_ID,
         IN_CUSTOMER_ID,
         IN_ACCOUNT_ID,
         IN_CREDIT_GROUP_ID,
         IN_PROJ_NUMBER,
         IN_SALES_MAIN_TYPE,
         IN_ORDER_ID,
         IN_SRC_TYPE,
         DECODE(SIGN(IN_DP_DISAMOUNT_SUM), 1, 1, -1, 2),
         DECODE(SIGN(IN_DP_DISAMOUNT_SUM), 1, '1', -1, '2'),
         '锁定折让金额(订金)',
         IN_DP_DISAMOUNT_SUM,
         '1',
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_USER_ACCOUNT,
         SYSDATE,
         IN_ORDER_NUMBER);
       
      INSERT INTO T_SALES_AMOUNT_TRANS_TCC
         (TRANS_ID
         ,TCC_ID
         ,TCC_RESULT
         ,TCC_IDEMPOTENT_ID)
       VALUES
        (V_TRANS_ID
         ,IN_TCC_ID
         ,'2'
         ,IN_TCC_IDEMPOTENT_ID);
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
  

end PKG_CREDIT_ACCOUNT_CONTROL;
/

