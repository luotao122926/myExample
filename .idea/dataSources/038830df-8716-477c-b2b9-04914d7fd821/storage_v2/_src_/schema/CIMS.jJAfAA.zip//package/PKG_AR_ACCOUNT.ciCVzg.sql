create package      PKG_AR_ACCOUNT is

  V_SUCCESS                  CONSTANT VARCHAR2(20) := 'SUCCESS';
  V_EXECUTE_MODE_REQUEST     CONSTANT VARCHAR2(20) := '手工请求';
  V_EXECUTE_MODE_AUTO_SYSTEM CONSTANT VARCHAR2(20) := '系统生成';

-----------------------------------------------------------------------
  -- Author  :
  -- Created :
  --执行往来对账单数据生成
  --      P_ENTITY_ID  （处理该主体所有可以计算往来对账单的客户）
  --
  -----------------------------------------------------------------------
  PROCEDURE P_CUSG_SOA_COUNT_ALL(P_ENTITY_ID              NUMBER, --主体ID
                                 P_COUNT_PERIOD           DATE, --对账日期
                                 --P_USER_CODE              VARCHAR2, --用户ID
                                 --P_SALES_CENTER_ID        NUMBER, --营销中心ID
                                 --P_CUSTOMER_ID            NUMBER, --客户ID
                                 --P_HANDMODE_FLAG          VARCHAR2, --手工请求标志
                                 --P_COUNT_START_DATE       DATE, --对账开始日期
                                 --P_COUNT_END_DATE         DATE, --对账结束日期
                                 P_RESULT                 IN OUT VARCHAR2);

-----------------------------------------------------------------------
  -- Author  :
  -- Created :
  --手动执行往来对账单数据生成
  --参数P_CUSTOMER_ID可以传：
  --      客户ID（单独处理一个客户）
  --
  -----------------------------------------------------------------------
  PROCEDURE P_CUSG_SOA_COUNT_HAND(P_ENTITY_ID              NUMBER, --主体ID
                                 --P_COUNT_PERIOD           VARCHAR2, --对账期间
                                 P_CUSTOMER_ID            NUMBER, --客户ID
                                 P_ACCOUNT_ID     NUMBER, --账户ID
                                 --P_SALES_CENTER_ID        NUMBER, --营销中心ID
                                 --P_USER_CODE              VARCHAR2, --用户ID
                                 --P_HANDMODE_FLAG          VARCHAR2, --手工请求标志
                                 --P_ORDER_TYPE             VARCHAR2, --对账单类型
                                 P_COUNT_START_DATE       DATE, --对账开始日期
                                 P_COUNT_END_DATE         DATE, --对账结束日期
                                 P_RESULT                 IN OUT VARCHAR2);

-----------------------------------------------------------------------
  -- Author  :
  -- Created :
  --启用独立事务，插入往来对账客户表
  --参数 ：
  --
  -----------------------------------------------------------------------
  FUNCTION F_ADD_SOA_HISTORY(F_HEADER_ID IN NUMBER,
                             F_CUSTOMER_ID IN NUMBER,
                             F_CUSTOMER_CODE in varchar2,
                             F_CUSTOMER_NAME in varchar2,
                             F_CUSTOMER_FLAG in varchar2,
                             F_SALES_CENTER_ID in NUMBER,
                             F_HANDMODE_FLAG in varchar2,
                             F_COUNT_START_DATE in DATE,
                             F_COUNT_END_DATE in DATE,
                             F_COUNT_PERIOD in varchar2,
                             F_ORDER_TYPE in varchar2,
                             F_ORDER_NUMBER in varchar2,
                             F_SOA_RECEIPT_BATCH_ID in NUMBER,
                             F_SOA_SO_ORDER_BATHC_ID in NUMBER,
                             F_SOA_DISCOUNT_BACHT_ID in NUMBER,
                             F_STATES in varchar2,
                             F_COUNT_RESULT in varchar2,
                             F_COMMENTS in varchar2,
                             F_ENTITY_ID in NUMBER,
                             F_CREATED_BY in varchar2,
                             F_CREATION_DATE in DATE,
                             F_LAST_UPDATED_BY in varchar2,
                             F_LAST_UPDATE_DATE in DATE,
                             F_SOA_COUNT_BATCH_ID in NUMBER
                             ) RETURN VARCHAR2;



end PKG_AR_ACCOUNT;
/

