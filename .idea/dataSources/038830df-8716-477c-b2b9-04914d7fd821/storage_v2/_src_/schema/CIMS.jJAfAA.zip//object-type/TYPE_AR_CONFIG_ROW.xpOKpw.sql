create Type Type_Ar_Config_Row As object(
  entity_id              NUMBER,   --主体ID
  sales_center_id        NUMBER,   --营销中心ID
  customer_id            NUMBER,   --客户ID
  ar_conf_initial        VARCHAR2(20),  --
  apply_flag             VARCHAR2(2),
  approval_flag          VARCHAR2(2),
  auto_settle_flag       VARCHAR2(2),
  settle_next_month_flag VARCHAR2(2),
  so_order_type          VARCHAR2(100),
  max_trx_amount         NUMBER(20,2),  --最大开票额
  max_month_amount       NUMBER(20,2),  --
  limt_day               NUMBER,        --每月开票日期
  max_discount_limt      NUMBER(20,2),  --最大折扣率
  trx_rate               NUMBER,        --税率
  trx_type               VARCHAR2(40),--发票类型
  dis_trx_type           VARCHAR2(10),--是否折扣方式开票
  discount_line          VARCHAR2(10)--不同折扣率是否分行显示
  )
/

