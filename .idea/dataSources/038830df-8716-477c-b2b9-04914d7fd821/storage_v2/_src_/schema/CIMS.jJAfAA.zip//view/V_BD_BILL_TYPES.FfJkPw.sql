create view V_BD_BILL_TYPES as
select bt.entity_id,
       bt.source_type_id,
       bt.bill_type_id,
       bt.bill_type_code,
       bt.bill_type_name
  from t_inv_bill_types bt
union all
select ot.entity_id,
       ot.source_order_type_id source_type_id,
       ot.order_type_id bill_type_id,
       ot.order_type_code bill_type_code,
       ot.order_type_name bill_type_name
  from t_pln_order_type ot
  where ot.source_order_type_id is not null
/

