create view V_AR_CUST_ACC_SALES_CENTER as
select
d.entity_id || a.customer_id || c.account_id || b.unit_id ID,
a.customer_id,a.customer_code,a.customer_name,
b.unit_id sales_center_id ,b.code sales_center_code, b.name sales_center_name,
c.account_id,c.account_code,c.account_name,
d.entity_id
from t_customer_header a,up_org_unit b,t_customer_account c,t_customer_org d ,t_customer_acc_org_relation e
where d.customer_id = a.customer_id
and b.unit_id = d.sales_center_id
and d.customer_org_id = e.customer_org_id
and e.account_id = c.account_id
--order by a.customer_code
/

comment on column V_AR_CUST_ACC_SALES_CENTER.CUSTOMER_ID is '客户Id'
/

comment on column V_AR_CUST_ACC_SALES_CENTER.CUSTOMER_CODE is '客户编码'
/

comment on column V_AR_CUST_ACC_SALES_CENTER.CUSTOMER_NAME is '客户名称'
/

comment on column V_AR_CUST_ACC_SALES_CENTER.SALES_CENTER_ID is '营销中心id'
/

comment on column V_AR_CUST_ACC_SALES_CENTER.SALES_CENTER_CODE is '营销中心编码'
/

comment on column V_AR_CUST_ACC_SALES_CENTER.SALES_CENTER_NAME is '营销中心名称'
/

comment on column V_AR_CUST_ACC_SALES_CENTER.ACCOUNT_ID is '账户id'
/

comment on column V_AR_CUST_ACC_SALES_CENTER.ACCOUNT_CODE is '账户编码'
/

comment on column V_AR_CUST_ACC_SALES_CENTER.ACCOUNT_NAME is '账户名称'
/

comment on column V_AR_CUST_ACC_SALES_CENTER.ENTITY_ID is '主体id'
/

