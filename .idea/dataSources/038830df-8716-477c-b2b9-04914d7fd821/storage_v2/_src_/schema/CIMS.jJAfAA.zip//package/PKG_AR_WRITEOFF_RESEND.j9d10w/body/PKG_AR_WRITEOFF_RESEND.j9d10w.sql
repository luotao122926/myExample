create Package Body PKG_AR_WRITEOFF_RESEND Is

-----------------------------------------------------------------------------
  --  检测没生成SO变更记录原因                                                    --
  -----------------------------------------------------------------------------


   -- 核销关系推送ERP校验。一张收款单和一张财务单只能核销一次
  PROCEDURE P_AR_WRITEOFF_RESEND
  (
     IS_ORG_ID      IN   VARCHAR2  --主体
    ,S_USER_ACCOUNT    IN   VARCHAR2  --用户账号
    ,OS_MESSAGE       OUT  VARCHAR2  --成功则返回“OK”，否则返回出错信息
  ) IS
  ROW_AR_WRITEOFF                INTF_AR_WRITEOFF%ROWTYPE;
  ROW_AR_WRITEOFF_INV            INTF_AR_WRITEOFF_INV%ROWTYPE;
  V_BDESBSERIALNO                VARCHAR2(32);
  V_ENTITY                       NUMBER;
  V_COUNT                        NUMBER;
  V_ID                           NUMBER;
  BEGIN
    -- 收款到发票推送ERP校验(INTF_AR_WRITEOFF)
    FOR ROW_AR_WRITEOFF_NUMBER IN (SELECT I.ORG_ID, I.RECEIPT_NUMBER, I.TRX_NUMBER, SUM(APPLIED_AMOUNT) AS TOTAL_MATCH_AMOUNT, COUNT(*)
                           FROM CIMS.INTF_AR_WRITEOFF I
                           WHERE I.ORG_ID = IS_ORG_ID -- 新生成汇总的核销关系没有ORDER_RECEIPT_ID
                           and I.ORDER_RECEIPT_ID IS NOT NULL
                           GROUP BY I.ORG_ID, I.RECEIPT_NUMBER, I.TRX_NUMBER
                           HAVING COUNT(*) > 1) LOOP
      BEGIN
        SELECT COUNT(*) INTO V_COUNT FROM CIMS.INTF_AR_WRITEOFF I
        WHERE I.ORDER_RECEIPT_ID IS NOT NULL
         --     AND I.INTF_STATUS <> 'S'
              AND I.ORG_ID = ROW_AR_WRITEOFF_NUMBER.ORG_ID
              AND I.RECEIPT_NUMBER = ROW_AR_WRITEOFF_NUMBER.RECEIPT_NUMBER
              AND I.TRX_NUMBER = ROW_AR_WRITEOFF_NUMBER.TRX_NUMBER;
        IF V_COUNT > 0 THEN
          SELECT S_AR_WRITE_OFF.NEXTVAL INTO V_ID FROM DUAL;
          -- 原核销关系已经发送ERP需取消推送ERP
          UPDATE CIMS.INTF_AR_WRITEOFF I
          SET I.AFTER_CANCEL_TRX_ID = V_ID, I.CANCEL_FLAG = 'Y',
              I.INTF_STATUS = 'S', -- 需取消的核销关系接口状态设置为S
              I.COMMENTS = I.COMMENTS||'#核销关系取消，新核销关系：'||V_ID
          WHERE I.RECEIPT_NUMBER = ROW_AR_WRITEOFF_NUMBER.RECEIPT_NUMBER
                AND I.TRX_NUMBER = ROW_AR_WRITEOFF_NUMBER.TRX_NUMBER
                AND I.ORG_ID = ROW_AR_WRITEOFF_NUMBER.ORG_ID;
          -- 获取主体
          SELECT DISTINCT H.ENTITY_ID INTO V_ENTITY
          FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
          WHERE H.CASH_RECEIPT_CODE = ROW_AR_WRITEOFF_NUMBER.RECEIPT_NUMBER
                AND H.ERP_OU_ID = ROW_AR_WRITEOFF_NUMBER.ORG_ID;
          -- 生成ESB交易流水号
          PKG_BD.P_GET_BILL_NO('BdEsbSerialNo', NULL, V_ENTITY, NULL, V_BDESBSERIALNO);
          -- 生成新的核销关系
          SELECT V_ID
                ,V_BDESBSERIALNO            --交易流水号：统一调用单位规则号”BDESBSERIALNO 进行生成
                ,'Q'                        --接口处理状态(固定值'N')
                ,ORG_ID                     --取OU_ID
                ,RECEIPT_NUMBER             --收款编号
                ,'CNY'                      --币种(固定值'CNY')
                ,AMOUNT                     --收款金额
                ,CUSTOMER_TRX_ID            --AR发票头ID '+'转入【财务单据ERP_ARINVOICE_ID  ERP(AR)发票头ID】)
                ,'CNY'                      --发票核销币种(固定值'CNY')
                ,ROW_AR_WRITEOFF_NUMBER.TOTAL_MATCH_AMOUNT         --本次核销金额
                ,trunc(sysdate)            --核销总账日期
                ,trunc(sysdate)            --核销日期
                ,CUSTOMER_NUMBER            --客户编码
                ,CUSTOMER_NAME              --客户名称
                ,TRX_NUMBER                 --发票编号'+’转入【财务单据ERP_ARINVOICE_CODE   ERP应收(AR)发票号】)
                ,CASH_RECEIPT_ID            --收款表ID
                ,'SYSTEM'                   --创建人
                ,TRUNC(SYSDATE,'DD')        --创建时间
                ,'SYSTEM'                   --最后修改人
                ,TRUNC(SYSDATE,'DD')        --最后修改时间
               ,'Y'                         --是否开始推送ERP。Y：开始推送，N暂不推送
               ,'N'                         --是否取消推送ERP。Y：取消推送，N不取消推送
               ,'S'                         --处理成功
               ,'N'
          INTO ROW_AR_WRITEOFF.TRX_ID
               ,ROW_AR_WRITEOFF.TRX_NO
               ,ROW_AR_WRITEOFF.INTF_STATUS
               ,ROW_AR_WRITEOFF.ORG_ID
               ,ROW_AR_WRITEOFF.RECEIPT_NUMBER
               ,ROW_AR_WRITEOFF.CURRENCY_CODE
               ,ROW_AR_WRITEOFF.AMOUNT
               ,ROW_AR_WRITEOFF.CUSTOMER_TRX_ID
               ,ROW_AR_WRITEOFF.TRX_CURRENCY_CODE
               ,ROW_AR_WRITEOFF.APPLIED_AMOUNT
               ,ROW_AR_WRITEOFF.APPLIED_GL_DATE
               ,ROW_AR_WRITEOFF.APPLIED_DATE
               ,ROW_AR_WRITEOFF.CUSTOMER_NUMBER
               ,ROW_AR_WRITEOFF.CUSTOMER_NAME
               ,ROW_AR_WRITEOFF.TRX_NUMBER
               ,ROW_AR_WRITEOFF.CASH_RECEIPT_ID
               ,ROW_AR_WRITEOFF.CREATED_BY
               ,ROW_AR_WRITEOFF.CREATION_DATE
               ,ROW_AR_WRITEOFF.LAST_UPDATED_BY
               ,ROW_AR_WRITEOFF.LAST_UPDATE_DATE
               ,ROW_AR_WRITEOFF.START_PUSH_TO_ERP
               ,ROW_AR_WRITEOFF.CANCEL_FLAG
               ,ROW_AR_WRITEOFF.PROCESS_STATUS
               ,ROW_AR_WRITEOFF.HANDLE_FLAG
          FROM (SELECT * FROM CIMS.INTF_AR_WRITEOFF IAW
                WHERE IAW.RECEIPT_NUMBER = ROW_AR_WRITEOFF_NUMBER.RECEIPT_NUMBER
                      AND IAW.TRX_NUMBER = ROW_AR_WRITEOFF_NUMBER.TRX_NUMBER
                      AND IAW.ORG_ID = ROW_AR_WRITEOFF_NUMBER.ORG_ID
                ORDER BY IAW.CREATION_DATE DESC
                ) I
          WHERE ROWNUM = 1;
          -- 插入新的汇总核销关系
          INSERT INTO INTF_AR_WRITEOFF VALUES ROW_AR_WRITEOFF;
          COMMIT;
        END IF;

      EXCEPTION WHEN OTHERS THEN
        ROLLBACK;
           RAISE_APPLICATION_ERROR(-20123,
                                '异常' ||
                                SQLERRM,
                                FALSE);
      END;
    END LOOP;


    -- 发票到发票推送ERP校验(INTF_AR_WRITEOFF_INV)
    FOR ROW_AR_WRITEOFF_INV_NUMBER IN (SELECT I.ORG_ID, I.CM_TRX_NUMBER, I.INVOICE_TRX_NUMBER, SUM(APPLIED_AMOUNT) AS TOTAL_MATCH_AMOUNT, COUNT(*)
                           FROM CIMS.INTF_AR_WRITEOFF_INV I
                           WHERE I.ORG_ID= IS_ORG_ID-- 新生成汇总的核销关系没有ORDER_RECEIPT_ID

                           GROUP BY I.ORG_ID, I.CM_TRX_NUMBER, I.INVOICE_TRX_NUMBER
                           HAVING COUNT(*) > 1) LOOP
      BEGIN
        SELECT COUNT(*) INTO V_COUNT FROM CIMS.INTF_AR_WRITEOFF_INV I
        WHERE I.ORDER_RECEIPT_ID IS NOT NULL
           --   AND I.INTF_STATUS <> 'S'
              AND I.ORG_ID = ROW_AR_WRITEOFF_INV_NUMBER.ORG_ID
              AND I.CM_TRX_NUMBER = ROW_AR_WRITEOFF_INV_NUMBER.CM_TRX_NUMBER
              AND I.INVOICE_TRX_NUMBER = ROW_AR_WRITEOFF_INV_NUMBER.INVOICE_TRX_NUMBER;
        IF V_COUNT > 0 THEN
          SELECT S_INTF_AR_WRITEOFF_INV.NEXTVAL INTO V_ID FROM DUAL;
          -- 原核销关系已经发送ERP需取消推送ERP
          UPDATE CIMS.INTF_AR_WRITEOFF_INV I SET I.AFTER_CANCEL_TRX_ID = V_ID, I.CANCEL_FLAG = 'Y',
                 I.INTF_STATUS = 'S', -- 需取消的核销关系接口状态设置为S
                 I.COMMENTS = I.COMMENTS||'#核销关系取消，新核销关系：'||V_ID
          WHERE I.CM_TRX_NUMBER = ROW_AR_WRITEOFF_INV_NUMBER.CM_TRX_NUMBER
                AND I.INVOICE_TRX_NUMBER = ROW_AR_WRITEOFF_INV_NUMBER.INVOICE_TRX_NUMBER
                AND I.ORG_ID = ROW_AR_WRITEOFF_INV_NUMBER.ORG_ID;
          -- 获取主体
          SELECT DISTINCT H.ENTITY_ID INTO V_ENTITY
          FROM CIMS.T_SO_HEADER H
          WHERE H.ERP_ARINVOICE_CODE = ROW_AR_WRITEOFF_INV_NUMBER.CM_TRX_NUMBER
                AND H.ERP_OU_ID = ROW_AR_WRITEOFF_INV_NUMBER.ORG_ID;
          -- 生成ESB交易流水号
          PKG_BD.P_GET_BILL_NO('BdEsbSerialNo', NULL, V_ENTITY, NULL, V_BDESBSERIALNO);
          SELECT ORG_ID                         --业务ou
                 ,'Q'                    --接口处理状态：N 新建；P 已提；S 返回成功；E 返回失败
                 ,V_ID
                 ,V_BDESBSERIALNO                --交易流水号：统一调用单位规则号”BdEsbSerialNo 进行生成
                 ,CUSTOMER_NUMBER                --客户编码
                 ,CUSTOMER_NAME                  --客户名称
                 ,CM_TRX_NUMBER                  --贷项发票编号
                 ,INVOICE_TRX_NUMBER             --借项发票编号
                 ,ROW_AR_WRITEOFF_INV_NUMBER.TOTAL_MATCH_AMOUNT                 --本次核销金额
                 ,to_char(sysdate,'yyyy-mm-dd')                     --核销日期
                 ,to_char(sysdate,'yyyy-mm-dd')                      --核销总账日期
                 ,'SYSTEM'                     --创建人
                 ,TRUNC(SYSDATE, 'DD')                  --创建时间
                 ,'SYSTEM'                --最后修改人
                 ,TRUNC(SYSDATE, 'DD')               --最后修改时间
                 ,'Y'              --是否开始推送ERP。Y：开始推送，N暂不推送
                 ,'N'                    --是否取消推送ERP。Y：取消推送，N不取消推送
                 ,'S'
                 ,'N'
          INTO ROW_AR_WRITEOFF_INV.ORG_ID        --业务ou
                 ,ROW_AR_WRITEOFF_INV.INTF_STATUS--接口处理状态：N 新建；P 已提；S 返回成功；E 返回失败
                 ,ROW_AR_WRITEOFF_INV.TRX_ID
                 ,ROW_AR_WRITEOFF_INV.TRX_NO     --交易流水号：统一调用单位规则号”BdEsbSerialNo 进行生成
                 ,ROW_AR_WRITEOFF_INV.CUSTOMER_NUMBER                --客户编码
                 ,ROW_AR_WRITEOFF_INV.CUSTOMER_NAME                  --客户名称
                 ,ROW_AR_WRITEOFF_INV.CM_TRX_NUMBER                  --贷项发票编号
                 ,ROW_AR_WRITEOFF_INV.INVOICE_TRX_NUMBER             --借项发票编号
                 ,ROW_AR_WRITEOFF_INV.APPLIED_AMOUNT                 --本次核销金额
                 ,ROW_AR_WRITEOFF_INV.APPLY_DATE                     --核销日期
                 ,ROW_AR_WRITEOFF_INV.GL_DATE                        --核销总账日期
                 ,ROW_AR_WRITEOFF_INV.CREATED_BY                     --创建人
                 ,ROW_AR_WRITEOFF_INV.CREATION_DATE                  --创建时间
                 ,ROW_AR_WRITEOFF_INV.LAST_UPDATED_BY                --最后修改人
                 ,ROW_AR_WRITEOFF_INV.LAST_UPDATE_DATE               --最后修改时间
                 ,ROW_AR_WRITEOFF_INV.START_PUSH_TO_ERP              --是否开始推送ERP。Y：开始推送，N暂不推送
                 ,ROW_AR_WRITEOFF_INV.CANCEL_FLAG                    --是否取消推送ERP。Y：取消推送，N不取消推送
                 ,ROW_AR_WRITEOFF_INV.PROCESS_STATUS
                 ,ROW_AR_WRITEOFF_INV.HANDLE_FLAG
          FROM (SELECT * FROM CIMS.INTF_AR_WRITEOFF_INV IAW
                  WHERE IAW.CM_TRX_NUMBER = ROW_AR_WRITEOFF_INV_NUMBER.CM_TRX_NUMBER
                        AND IAW.INVOICE_TRX_NUMBER = ROW_AR_WRITEOFF_INV_NUMBER.INVOICE_TRX_NUMBER
                        AND IAW.ORG_ID = ROW_AR_WRITEOFF_INV_NUMBER.ORG_ID
                  ORDER BY IAW.CREATION_DATE DESC
                  ) I
          WHERE ROWNUM = 1;
          -- 插入新的汇总核销关系
          INSERT INTO INTF_AR_WRITEOFF_INV VALUES ROW_AR_WRITEOFF_INV;
          COMMIT;
        END IF;
        
        UPDATE CIMS.INTF_AR_WRITEOFF U SET U.SOURCE_NUM = U.TRX_ID WHERE U.SOURCE_NUM IS NULL;
        UPDATE CIMS.INTF_AR_WRITEOFF_INV U SET U.SOURCE_NUM = U.TRX_ID WHERE U.SOURCE_NUM IS NULL;

      EXCEPTION WHEN OTHERS THEN
        ROLLBACK;
        OS_MESSAGE := PKG_CROSSOUTURNFEE.V_ERROR;
              RAISE_APPLICATION_ERROR(-20123,
                                '异常' ||
                                SQLERRM,
                                FALSE);
      END;
    END LOOP;

  END P_AR_WRITEOFF_RESEND;


 -- 取消核销关系推送ER

  -- 取消核销关系推送ER
  PROCEDURE P_SO_ORDER_RECEIPT_CANCEL
  (
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
  BEGIN
    P_MESSAGE := PKG_CROSSOUTURNFEE.V_SUCCESS;
    -- 取消收款核销发票
    INSERT INTO INTF_AR_WRITEOFF_UN(
        BILL_TO,  --客户收单方
        CREATED_BY,  --创建人
        CREATION_DATE,  --创建日期
        CUSTOMER_NAME,  --客户名称
        CUSTOMER_NUMBER,  --客户编码
        ERROR_FLAG,  --错误标志
        ERR_MESSAGE,  --错误信息
        ESB_DATA_SOURCE,  --ESB数据来源
        ESB_SERIAL_NUM,  --ESB流水号
        INTF_STATUS,  --接口处理状态：N 新建；P 已提；S 返回成功；E 返回失败
        LAST_UPDATED_BY,  --修改人
        LAST_UPDATE_DATE,  --修改日期
        OPERSTATUS,  --更新业务表的处理状态  0：成功，1：失败 2：处理中
        ORG_ID,  --业务实体ID
        ORIGINAL_TRX_ID,  --原单ID
        POST_DATE,  --提交时间
        RECEIPT_NUMBER,  --收款编号
        RESPNOSECODE,  --提供方填写，返回的状态代码。错误码规范见文档《美的财务_新一代企业服务总线_ESB接入错误码》
        RESPONSEMESSAGE,  --提供方填写，返回的状态信息
        RESPONSETYPE,  --提供方填写：N-成功，E-失败，W-警告，A-授权
        RETURN_DATE,  --返回时间
        REVERSAL_DATE,  --冲销日期
        REVERSAL_GL_DATE,  --冲销总帐日期
        SOURCE_CODE,  --来源系统代码
        SOURCE_LINE_NUM,  --来源行编号
        SOURCE_NUM,  --来源编号
        TRX_ID,  --主键ID
        TRX_NUMBER  --发票编号
        )
     SELECT
        NULL
        ,'SYSTEM'
        ,TRUNC(SYSDATE, 'DD')
        ,IAW.CUSTOMER_NAME
        ,IAW.CUSTOMER_NUMBER
        ,NULL
        ,NULL
        ,NULL
        ,NULL
        ,'N'
        ,'SYSTEM'
        ,TRUNC(SYSDATE, 'DD')
        ,NULL
        ,IAW.ORG_ID
        ,IAW.TRX_ID
        ,NULL
        ,IAW.RECEIPT_NUMBER
        ,NULL
        ,NULL
        ,NULL
        ,NULL
        ,TO_CHAR(SYSDATE, 'yyyy-MM-dd')
        ,TO_CHAR(SYSDATE, 'yyyy-MM-dd')
        ,'CIMS'
        ,NULL
        ,NULL
        ,S_INTF_AR_WRITEOFF_UN.NEXTVAL
        ,IAW.TRX_NUMBER
      FROM CIMS.INTF_AR_WRITEOFF IAW
      WHERE IAW.TRX_ID IN
              (SELECT TMP.MAX_TRX_ID FROM (
                  SELECT IAWI_.ORG_ID, IAWI_.RECEIPT_NUMBER, IAWI_.TRX_NUMBER, MAX(IAWI_.TRX_ID) AS MAX_TRX_ID
                  FROM CIMS.INTF_AR_WRITEOFF IAWI_
                  WHERE IAWI_.CANCEL_FLAG = 'Y' AND IAWI_.HANDLE_FLAG = 'N'
                  GROUP BY IAWI_.ORG_ID, IAWI_.RECEIPT_NUMBER, IAWI_.TRX_NUMBER
              ) TMP
            )
            AND IAW.CANCEL_FLAG = 'Y'
            AND IAW.HANDLE_FLAG = 'N'
            ;

    -- 取消发票核销发票
    INSERT INTO INTF_AR_WRITEOFF_INV_UN(
      BILL_TO,  --客户收单方
      CM_TRX_NUMBER,  --贷项通知单编号
      CREATED_BY,  --创建人
      CREATION_DATE,  --创建日期
      CUSTOMER_NAME,  --客户名称
      CUSTOMER_NUMBER,  --客户编码
      ERROR_FLAG,  --错误标志
      ERR_MESSAGE,  --错误信息
      ESB_DATA_SOURCE,  --ESB数据来源
      ESB_SERIAL_NUM,  --ESB流水号
      INTF_STATUS,  --接口处理状态：N 新建；P 已提；S 返回成功；E 返回失败
      LAST_UPDATED_BY,  --修改人
      LAST_UPDATE_DATE,  --修改日期
      OPERSTATUS,  --更新业务表的处理状态  0：成功，1：失败 2：处理中
      ORG_ID,  --业务实体ID
      ORIGINAL_TRX_ID,  --原单ID
      POST_DATE,  --提交时间
      RESPNOSECODE,  --提供方填写，返回的状态代码。错误码规范见文档《美的财务_新一代企业服务总线_ESB接入错误码》
      RESPONSEMESSAGE,  --提供方填写，返回的状态信息
      RESPONSETYPE,  --提供方填写：N-成功，E-失败，W-警告，A-授权
      RETURN_DATE,  --返回时间
      REVERSAL_DATE,  --冲销日期
      REVERSAL_GL_DATE,  --冲销总帐日期
      SOURCE_CODE,  --来源系统代码
      SOURCE_LINE_NUM,  --来源行编号
      SOURCE_NUM,  --来源编号
      TRX_ID,  --主键ID
      TRX_NUMBER  --发票编号
      )
    SELECT
      NULL        --客户收单方
      ,IAWI.CM_TRX_NUMBER  --贷项通知单编号
      ,'SYSTEM'--创建人
      ,TRUNC(SYSDATE, 'DD') --创建日期
      ,IAWI.CUSTOMER_NAME--客户名称
      ,IAWI.CUSTOMER_NUMBER--客户编码
      ,NULL--错误标志
      ,NULL--错误信息
      ,NULL--ESB数据来源
      ,NULL--ESB流水号
      ,'N'--接口处理状态：N 新建；P 已提；S 返回成功；E 返回失败
      ,'SYSTEM'--修改人
      ,TRUNC(SYSDATE, 'DD') --修改日期
      ,NULL--更新业务表的处理状态  0：成功，1：失败 2：处理中
      ,IAWI.ORG_ID--业务实体ID
      ,IAWI.TRX_ID--原单ID
      ,NULL--提交时间
      ,NULL--提供方填写，返回的状态代码。错误码规范见文档《美的财务_新一代企业服务总线_ESB接入错误码》
      ,NULL--提供方填写，返回的状态信息
      ,NULL--提供方填写：N-成功，E-失败，W-警告，A-授权
      ,NULL--返回时间
      ,TO_CHAR(SYSDATE, 'yyyy-MM-dd') --冲销日期
      ,TO_CHAR(SYSDATE, 'yyyy-MM-dd') --冲销总帐日期
      ,'CIMS'--来源系统代码
      ,NULL--来源行编号
      ,NULL--来源编号
      ,S_INTF_AR_WRITEOFF_INV_UN.NEXTVAL--主键ID
      ,IAWI.INVOICE_TRX_NUMBER--发票编号
    FROM CIMS.INTF_AR_WRITEOFF_INV IAWI
    WHERE IAWI.TRX_ID IN
            (SELECT TMP.MAX_TRX_ID FROM (
                SELECT IAWI_.ORG_ID, IAWI_.INVOICE_TRX_NUMBER, IAWI_.CM_TRX_NUMBER, MAX(IAWI_.TRX_ID) AS MAX_TRX_ID
                FROM CIMS.INTF_AR_WRITEOFF_INV IAWI_
                WHERE IAWI_.CANCEL_FLAG = 'Y' AND IAWI_.HANDLE_FLAG = 'N'
                GROUP BY IAWI_.ORG_ID, IAWI_.INVOICE_TRX_NUMBER, IAWI_.CM_TRX_NUMBER
            ) TMP
          )
          AND IAWI.CANCEL_FLAG = 'Y'
          AND IAWI.HANDLE_FLAG = 'N'
--          AND NOT EXISTS (SELECT * FROM cims.INTF_AR_WRITEOFF_INV_UN IAWU WHERE IAWU.TRX_NUMBER = IAWI.INVOICE_TRX_NUMBER AND IAWU.CM_TRX_NUMBER = IAWI.CM_TRX_NUMBER)
          ;

    UPDATE CIMS.INTF_AR_WRITEOFF I SET I.HANDLE_FLAG = 'Y' WHERE I.CANCEL_FLAG = 'Y' AND I.HANDLE_FLAG = 'N';
    UPDATE CIMS.INTF_AR_WRITEOFF_INV I SET I.HANDLE_FLAG = 'Y' WHERE I.CANCEL_FLAG = 'Y' AND I.HANDLE_FLAG = 'N';

    UPDATE CIMS.INTF_AR_WRITEOFF_UN U SET U.SOURCE_NUM = U.TRX_ID WHERE U.SOURCE_NUM IS NULL;
    UPDATE CIMS.INTF_AR_WRITEOFF_INV_UN U SET U.SOURCE_NUM = U.TRX_ID WHERE U.SOURCE_NUM IS NULL;
    COMMIT;
    P_RESULT := '取消核销关系推送ERP执行成功！';
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    P_MESSAGE := PKG_CROSSOUTURNFEE.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_CROSSOUTURNFEE.P_SO_ORDER_RECEIPT_CANCEL',
      SQLCODE,
      '取消核销关系推送ERP执行失败！错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    RETURN ;
  END P_SO_ORDER_RECEIPT_CANCEL;

END PKG_AR_WRITEOFF_RESEND;
/

