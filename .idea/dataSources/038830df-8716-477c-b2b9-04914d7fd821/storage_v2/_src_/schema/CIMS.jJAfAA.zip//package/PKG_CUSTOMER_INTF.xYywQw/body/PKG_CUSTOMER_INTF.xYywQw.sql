create PACKAGE BODY PKG_CUSTOMER_INTF IS
	V_NL CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
  PROCEDURE P_CUSTOMER_INTF_PROCLOV(P_INTF_TRANSCODE IN VARCHAR2, --接口流水号
                                    P_MESSAGE        OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                    ) IS
    V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常
    V_CODELIST_COUNT NUMBER;
    V_CODEVALUE      VARCHAR2(100);
    V_CODETYPE_NAME  UP_CODELIST.CODETYPE_NAME%TYPE;
    CURSOR C_INTFCUST_CODELIST IS
      SELECT *
        FROM INTF_CUSTOMER_UPCODELIST
       WHERE TRANSCODE = P_INTF_TRANSCODE;
  BEGIN
    P_MESSAGE := 'SUCCESS';
  
    FOR R_INTFCUST_CODELIST IN C_INTFCUST_CODELIST LOOP
      BEGIN
        SELECT REPLACE(R_INTFCUST_CODELIST.NAME, ' ', '')
          INTO V_CODEVALUE
          FROM DUAL;
      
        --add by liangym2 码表名称以数据库存在的为准 2018-7-2
        SELECT MAX(CL.CODETYPE_NAME)
              ,COUNT(DECODE(CL.CODE_VALUE, V_CODEVALUE, 0, NULL))
          INTO V_CODETYPE_NAME, V_CODELIST_COUNT
          FROM UP_CODELIST CL
         WHERE CL.CODETYPE = R_INTFCUST_CODELIST.TYPE;
        /*SELECT COUNT(0)
          INTO V_CODELIST_COUNT
          FROM UP_CODELIST CL
         WHERE CL.CODE_VALUE = V_CODEVALUE
           AND CL.CODETYPE = R_INTFCUST_CODELIST.TYPE;*/
      
        IF (V_CODELIST_COUNT = 0) THEN
          INSERT INTO UP_CODELIST
            (ID,
             CODE_VALUE,
             CODE_NAME,
             CODETYPE,
             PARENT,
             CODE_ORDER,
             ENABLED,
             REMARK,
             LANGUAGE,
             CODETYPE_NAME,
             FILTER,
             CREATED_BY,
             CREATION_TIME,
             MODIFIED_BY,
             MODIFICATION_TIME,
             ENTITY_FLAG)
          VALUES
            ('CRM' || R_INTFCUST_CODELIST.ID,
             V_CODEVALUE,
             R_INTFCUST_CODELIST.VALUE,
             R_INTFCUST_CODELIST.TYPE,
             '-1',
             NULL,
             '0',
             R_INTFCUST_CODELIST.DESCRIPTION,
             'zh_CN',
             NVL(V_CODETYPE_NAME,R_INTFCUST_CODELIST.LANGUAGE),
             --R_INTFCUST_CODELIST.LANGUAGE,
             NULL,
             'CRM',
             NULL,
             NULL,
             R_INTFCUST_CODELIST.UPDATED,
             'N');
        
          UPDATE INTF_CUSTOMER_UPCODELIST
             SET RESPONSETYPE    = 'N',
                 RESPNOSECODE    = '000000',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '0'
           WHERE TRANSCODE = P_INTF_TRANSCODE
             AND ID = R_INTFCUST_CODELIST.ID;
        
          COMMIT;
        ELSE
          UPDATE UP_CODELIST CL
             SET CL.CODE_NAME         = R_INTFCUST_CODELIST.VALUE,
                 CL.MODIFICATION_TIME = R_INTFCUST_CODELIST.UPDATED,
                 CL.ENABLED           = DECODE(R_INTFCUST_CODELIST.ACTIVE,
                                               'Y',
                                               '0',
                                               'N',
                                               '1')
           WHERE CL.CODE_VALUE = V_CODEVALUE
             AND CL.CODETYPE = R_INTFCUST_CODELIST.TYPE;
        
          UPDATE INTF_CUSTOMER_UPCODELIST
             SET RESPONSETYPE    = 'N',
                 RESPNOSECODE    = '000000',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '0'
           WHERE TRANSCODE = P_INTF_TRANSCODE
             AND ID = R_INTFCUST_CODELIST.ID;
             
          COMMIT;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROCLOV',
                                              SQLCODE,
                                              '插入字典表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_UPCODELIST
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE TRANSCODE = P_INTF_TRANSCODE
             AND ID = R_INTFCUST_CODELIST.ID;
          COMMIT;
      END;
    END LOOP;
  
    --RAISE V_BIZ_EXCEPTION;
  END P_CUSTOMER_INTF_PROCLOV;

  PROCEDURE P_CUSTOMER_INTF_PROC(P_INTF_HEADER_ID_LIST IN VARCHAR2, --接口表中的客户头ID，用逗号分隔
                                 P_MESSAGE             OUT VARCHAR2, --成功则返回“SUCCESS”，否则返回出错信息
                                 IS_CTRL_PARAM         IN  VARCHAR2 DEFAULT NULL--NOTGTWIDTH 不联动失效
                                 --NOTGTWIDTHANDNODEPT 不联动失效也不处理客户头、事业部、OU
                                 ) IS
    V_INTF_HEADER_ID_LIST PKG_BD_UTIL.T_VARRAY := PKG_BD_UTIL.T_VARRAY(); --声明集合,接口表客户ID
    V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常
    V_INTF_HEADER_COUNT         NUMBER; --接口表中头信息数量
    V_INTF_ADDRESS_COUNT        NUMBER; --接口表中地址数量
    V_INTF_BANK_COUNT           NUMBER; --接口表中银行数量
    V_INTF_BRAND_COUNT          NUMBER; --接口表中品牌数量
    V_INTF_CHANNEL_TYPE_COUNT   NUMBER; --接口表中业态类型（渠道类型）数量
    V_INTF_CONNECTION_COUNT     NUMBER; --接口表中关联关系数量
    V_INTF_CONTACTS_COUNT       NUMBER; --接口表中联系人数量
    V_INTF_DEPT_COUNT           NUMBER; --接口表中事业部数量
    V_INTF_ORG_COUNT            NUMBER; --接口表中组织（营销中心）数量
    V_INTF_OU_COUNT             NUMBER; --接口表中OU数量
    V_INTF_SALE_MAIN_TYPE_COUNT NUMBER; --接口表中营销大类（CRM产品信息）数量
  
    V_CUST_DEPT_COUNT VARCHAR2(2); --业务表中的事业部的数量
    V_INTF_HEADER     INTF_CUSTOMER_HEADER%ROWTYPE;
  
    V_CUST_HEADER_ID     NUMBER; --客户头ID
    V_HEADER_ID          NUMBER; --客户头ID
    V_CUST_HEADER_STATUS VARCHAR2(30); --客户头状态
    VT_MESSAGE           VARCHAR2(4000);
    VT_HEAD_ERRMSG       VARCHAR2(4000);
    VT_DEPT_ERRMSG       VARCHAR2(4000);
  
  BEGIN
    V_INTF_HEADER_ID_LIST := PKG_BD_UTIL.STR_SPLIT(P_INTF_HEADER_ID_LIST, ',');
    FOR K IN 1 .. V_INTF_HEADER_ID_LIST.COUNT() LOOP
      V_CUST_DEPT_COUNT := '1';
      --查询数量
      SELECT COUNT(0)
        INTO V_INTF_HEADER_COUNT
        FROM INTF_CUSTOMER_HEADER
       WHERE CUSTOMER_ID = TO_NUMBER(V_INTF_HEADER_ID_LIST(K));
      SELECT COUNT(0)
        INTO V_INTF_ADDRESS_COUNT
        FROM INTF_CUSTOMER_ADDRESS
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
      SELECT COUNT(0)
        INTO V_INTF_BANK_COUNT
        FROM INTF_CUSTOMER_BANK
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
      SELECT COUNT(0)
        INTO V_INTF_BRAND_COUNT
        FROM INTF_CUSTOMER_BRAND
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
      SELECT COUNT(0)
        INTO V_INTF_CHANNEL_TYPE_COUNT
        FROM INTF_CUSTOMER_CHANNEL_TYPE
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
      SELECT COUNT(0)
        INTO V_INTF_CONNECTION_COUNT
        FROM INTF_CUSTOMER_CONNECTION
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
      SELECT COUNT(0)
        INTO V_INTF_CONTACTS_COUNT
        FROM INTF_CUSTOMER_CONTACTS
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
      SELECT COUNT(0)
        INTO V_INTF_DEPT_COUNT
        FROM INTF_CUSTOMER_DEPT
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);     
      SELECT COUNT(0)
        INTO V_INTF_ORG_COUNT
        FROM INTF_CUSTOMER_ORG
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
      SELECT COUNT(0)
        INTO V_INTF_OU_COUNT
        FROM INTF_CUSTOMER_OU
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
      SELECT COUNT(0)
        INTO V_INTF_SALE_MAIN_TYPE_COUNT
        FROM INTF_CUSTOMER_SALES_MAIN_TYPE
       WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
    
      --插入客户头业务表
      BEGIN
        IF (IS_CTRL_PARAM IS NULL OR IS_CTRL_PARAM <> 'NOTGTWIDTHANDNODEPT')
          AND (V_INTF_HEADER_COUNT > 0) THEN 
          SELECT H.*
            INTO V_INTF_HEADER
            FROM INTF_CUSTOMER_HEADER H
           WHERE CUSTOMER_ID = TO_NUMBER(V_INTF_HEADER_ID_LIST(K));
        
          --调用函数插入或者更新客户头表
          PRC_INSERT_OR_UPDATE_HEADER(V_INTF_HEADER,
                                      V_CUST_HEADER_ID,
                                      V_CUST_HEADER_STATUS,
                                      V_HEADER_ID,
                                      VT_MESSAGE);
          IF 'SUCCESS' <> VT_MESSAGE THEN
            IF VT_HEAD_ERRMSG IS NULL THEN
              VT_HEAD_ERRMSG := VT_MESSAGE;
            ELSE
              VT_HEAD_ERRMSG := VT_HEAD_ERRMSG || V_NL || VT_MESSAGE;
            END IF;
            UPDATE INTF_CUSTOMER_HEADER
               SET RESPONSETYPE    = 'E',
                   RESPNOSECODE    = '000013',
                   RESPONSEMESSAGE = VT_MESSAGE,
                   OPERSTATUS      = '1'
             WHERE CUSTOMER_ID = TO_NUMBER(V_INTF_HEADER_ID_LIST(K));
            COMMIT;
            GOTO LPEND;
          ELSE
            VT_MESSAGE := 'SUCCESS';
            UPDATE INTF_CUSTOMER_HEADER
               SET RESPONSETYPE    = 'N',
                   RESPNOSECODE    = '000000',
                   RESPONSEMESSAGE = VT_MESSAGE,
                   OPERSTATUS      = '0'
             WHERE CUSTOMER_ID = TO_NUMBER(V_INTF_HEADER_ID_LIST(K));
            COMMIT;
          END IF;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          VT_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_BANK',
                                              SQLCODE,
                                              '插入客户头表失败！：' || SQLERRM);
          IF VT_HEAD_ERRMSG IS NULL THEN
            VT_HEAD_ERRMSG := VT_MESSAGE;
          ELSE
            VT_HEAD_ERRMSG := VT_HEAD_ERRMSG || V_NL || VT_MESSAGE;
          END IF;
          UPDATE INTF_CUSTOMER_HEADER
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = VT_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE CUSTOMER_ID = TO_NUMBER(V_INTF_HEADER_ID_LIST(K));
          COMMIT;
          GOTO LPEND;
          --RAISE V_BIZ_EXCEPTION;
      END;
    
      --插入事业部业务表
      BEGIN
        IF (IS_CTRL_PARAM IS NULL OR IS_CTRL_PARAM <> 'NOTGTWIDTHANDNODEPT')
          AND (V_INTF_DEPT_COUNT > 0) THEN
          --调用函数插入或者更新事业部表
          VT_MESSAGE := F_INSERT_OR_UPDATE_DEPT(V_INTF_HEADER_ID_LIST(K));
          IF VT_MESSAGE <> 'SUCCESS' AND VT_MESSAGE NOT LIKE '%不是内销%' THEN
            IF VT_DEPT_ERRMSG IS NULL THEN
              VT_DEPT_ERRMSG := VT_MESSAGE;
            ELSE
              VT_DEPT_ERRMSG := VT_DEPT_ERRMSG || V_NL || VT_MESSAGE;
            END IF;
          END IF;
        
          /*UPDATE INTF_CUSTOMER_DEPT
             SET RESPONSETYPE    = 'N'
                ,RESPNOSECODE    = '000000'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '0'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
        END IF;
      /*
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROCF_INSERT_OR_UPDATE_DEPT',
                                              SQLCODE,
                                              '插入客户事业部表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_DEPT
             SET RESPONSETYPE    = 'E'
                ,RESPNOSECODE    = '000013'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '1'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
          --RAISE V_BIZ_EXCEPTION;
      END;
    
      BEGIN
        --插入联系人业务表
        IF (V_INTF_CONTACTS_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_CONTACTS(V_INTF_HEADER_ID_LIST(K));
          /*UPDATE INTF_CUSTOMER_CONTACTS
             SET RESPONSETYPE    = 'N'
                ,RESPNOSECODE    = '000000'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '0'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
        END IF;
      /*
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_CONTACTS',
                                              SQLCODE,
                                              '插入客户联系人表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_CONTACTS
             SET RESPONSETYPE    = 'E'
                ,RESPNOSECODE    = '000013'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '1'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;
          --RAISE V_BIZ_EXCEPTION;*/
      END;
    
      BEGIN
        --插入银行业务表
        IF (V_INTF_BANK_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_BANK(V_INTF_HEADER_ID_LIST(K));
          /*UPDATE INTF_CUSTOMER_BANK
             SET RESPONSETYPE    = 'N'
                ,RESPNOSECODE    = '000000'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '1'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
        END IF;
      /*
      EXCEPTION
        WHEN OTHERS THEN       
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_BANK',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_BANK
             SET RESPONSETYPE    = 'E'
                ,RESPNOSECODE    = '000013'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '1'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
          --RAISE V_BIZ_EXCEPTION;
      END;
    
      BEGIN
        --插入渠道类型（业态类型）业务表
        IF (V_INTF_CHANNEL_TYPE_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_CHANN_TYPE(V_INTF_HEADER_ID_LIST(K));
          /*UPDATE INTF_CUSTOMER_CHANNEL_TYPE
             SET RESPONSETYPE    = 'N'
                ,RESPNOSECODE    = '000000'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '1'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
        END IF;
      /*
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_CHANN_TYPE',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_CHANNEL_TYPE
             SET RESPONSETYPE    = 'E'
                ,RESPNOSECODE    = '000013'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '1'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
          --RAISE V_BIZ_EXCEPTION;
      END;
    
      BEGIN
        --插入组织业务表
        IF (V_INTF_ORG_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_ORG(V_INTF_HEADER_ID_LIST(K));
          /*UPDATE INTF_CUSTOMER_ORG
             SET RESPONSETYPE    = 'N'
                ,RESPNOSECODE    = '000000'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '1'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
        END IF;
      /*
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_ORG',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_ORG
             SET RESPONSETYPE    = 'E'
                ,RESPNOSECODE    = '000013'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '1'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
          --RAISE V_BIZ_EXCEPTION;
      END;
    
      BEGIN
        --插入品牌业务表
        IF (V_INTF_BRAND_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_BRAND(V_INTF_HEADER_ID_LIST(K));
          /*UPDATE INTF_CUSTOMER_BRAND
             SET RESPONSETYPE    = 'N'
                ,RESPNOSECODE    = '000000'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '1'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
        END IF;
      /*
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_BRAND',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_BRAND
             SET RESPONSETYPE    = 'E'
                ,RESPNOSECODE    = '000013'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '1'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
          --RAISE V_BIZ_EXCEPTION;
      END;
    
      BEGIN
        --插入关联关系业务表
        IF (V_INTF_CONNECTION_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_CONNECTION(V_INTF_HEADER_ID_LIST(K));
          /*UPDATE INTF_CUSTOMER_CONNECTION
             SET RESPONSETYPE    = 'N'
                ,RESPNOSECODE    = '000000'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '1'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
        END IF;
      /*
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_CONNECTION',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_CONNECTION
             SET RESPONSETYPE    = 'E'
                ,RESPNOSECODE    = '000013'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '1'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
         --RAISE V_BIZ_EXCEPTION;
      END;
    
      BEGIN
        --插入客户地址业务表
        IF (V_INTF_ADDRESS_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_ADDRESS(V_INTF_HEADER_ID_LIST(K));
          /*UPDATE INTF_CUSTOMER_ADDRESS
             SET RESPONSETYPE    = 'N'
                ,RESPNOSECODE    = '000000'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '0'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
          /*
          BEGIN
            SELECT ADDR.ERROR_INFO
              INTO VT_MESSAGE
              FROM INTF_CUSTOMER_ADDRESS ADDR
             WHERE ADDR.PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K)
               AND 'N' <> ADDR.RESPONSETYPE
               AND '000000' <> ADDR.RESPNOSECODE
               AND ADDR.RESPONSEMESSAGE IS NOT NULL
               AND ADDR.ERROR_INFO IS NOT NULL
               AND 1 = ROWNUM;
            VT_DEPT_ERRMSG := VT_MESSAGE;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;*/
        END IF;
      /*
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_ADDRESS',
                                              SQLCODE,
                                              '插入客户地址表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_ADDRESS
             SET RESPONSETYPE    = 'E'
                ,RESPNOSECODE    = '000013'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '1'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
          --RAISE V_BIZ_EXCEPTION;
      END;
    
      --插入OU业务表
      BEGIN
        IF (IS_CTRL_PARAM IS NULL OR IS_CTRL_PARAM <> 'NOTGTWIDTHANDNODEPT')
          AND (V_INTF_OU_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_OU(V_INTF_HEADER_ID_LIST(K));
          /*UPDATE INTF_CUSTOMER_OU
             SET RESPONSETYPE    = 'N'
                ,RESPNOSECODE    = '000000'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '1'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
        END IF;
      /*
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_OU',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_OU
             SET RESPONSETYPE    = 'E'
                ,RESPNOSECODE    = '000013'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '1'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
          --RAISE V_BIZ_EXCEPTION;
      END;
    
      --插入营销大类业务表
      BEGIN
        IF (V_INTF_SALE_MAIN_TYPE_COUNT > 0) THEN
          P_MESSAGE := F_INSERT_OR_UPDATE_MAIN_TYPE(V_INTF_HEADER_ID_LIST(K));
          /*UPDATE INTF_CUSTOMER_SALES_MAIN_TYPE
             SET RESPONSETYPE    = 'N'
                ,RESPNOSECODE    = '000000'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '1'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;*/
        END IF;
      /*
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_MAIN_TYPE',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_SALES_MAIN_TYPE
             SET RESPONSETYPE    = 'E'
                ,RESPNOSECODE    = '000013'
                ,RESPONSEMESSAGE = P_MESSAGE
                ,OPERSTATUS      = '1'
           WHERE PRE_FIELD_01 = V_INTF_HEADER_ID_LIST(K);
          COMMIT;
          --RAISE V_BIZ_EXCEPTION;*/
      END;
    
      --联动失效
      IF (IS_CTRL_PARAM IS NULL)
        OR (IS_CTRL_PARAM <> 'NOTGTWIDTH' AND IS_CTRL_PARAM <> 'NOTGTWIDTHANDNODEPT') THEN
        BEGIN
          PRC_UPDATE_STATUS_CHANGED(V_INTF_HEADER_ID_LIST(K), V_HEADER_ID);
          COMMIT;
        EXCEPTION
          WHEN OTHERS THEN
            ROLLBACK;
            --记录出错信息
            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.PRC_UPDATE_STATUS_CHANGED',
                                                SQLCODE,
                                                '冻结失效处理出错！：' || SQLERRM);
            UPDATE INTF_CUSTOMER_HEADER
               SET RESPONSETYPE    = 'E',
                   RESPNOSECODE    = '000013',
                   RESPONSEMESSAGE = P_MESSAGE,
                   OPERSTATUS      = '1'
             WHERE CUSTOMER_ID = TO_NUMBER(V_INTF_HEADER_ID_LIST(K));
            COMMIT;
        END;
      END IF;
      
      BEGIN
        MERGE INTO T_CUSTOMER_COOPERATE_MODEL MT USING (
          SELECT T.*
                ,CL.CODE_NAME AS COOPERATION_MODEL_NAME
            FROM (
            SELECT OT.ENTITY_ID,
                   OT.CUSTOMER_ID,
                   OT.SALES_CENTER_ID,
                   OT.CUSTOMER_CODE,
                   OT.CUSTOMER_NAME,
                   OT.HEAD_STATUS,
                   OT.SALES_CENTER_CODE,
                   OT.SALES_CENTER_NAME,
                   OT.ORG_ACTIVE_FLAG,
                   CT.SALES_MAIN_TYPE_CODE,
                   CT.SALES_MAIN_TYPE_NAME,
                   CT.ACTIVE_FLAG,
                   NVL(OT.COOPERATION_MODEL, CT.COOPERATION_MODEL_ID) AS COOPERATION_MODEL,
                   NVL((CASE
                         WHEN CT.LAST_UPDATE_DATE > OT.LAST_UPDATE_DATE THEN
                           CT.LAST_UPDATE_BY
                         ELSE
                           OT.LAST_UPDATE_BY
                        END)
                     ,CT.CREATED_BY) AS LAST_UPDATE_BY,
                   NVL((CASE
                         WHEN CT.LAST_UPDATE_DATE > OT.LAST_UPDATE_DATE THEN
                           CT.LAST_UPDATE_DATE
                         ELSE
                           OT.LAST_UPDATE_DATE
                         END)
                     ,NVL(CT.CREATION_DATE,SYSDATE)) AS LAST_UPDATE_DATE,
                   CT.NET_BATCH_FLAG
              FROM (SELECT CO.ENTITY_ID,
                           CO.CUSTOMER_ID,
                           CO.SALES_CENTER_ID,
                           CO.ACTIVE_FLAG AS ORG_ACTIVE_FLAG,
                           (CASE
                             WHEN CO.ACTIVE_FLAG NOT IN
                                  ('Active', 'Freezing', 'Inactive') THEN
                              NULL
                             ELSE
                              CO.COOPERATION_MODEL
                             END) AS COOPERATION_MODEL,
                           CO.CUSTOMER_CODE,
                           H.CUSTOMER_NAME,
                           H.ACTIVE_FLAG AS HEAD_STATUS,
                           CO.SALES_CENTER_CODE,
                           CO.SALES_CENTER_NAME,
                           ROW_NUMBER() OVER(PARTITION BY CO.ENTITY_ID, CO.CUSTOMER_ID, CO.SALES_CENTER_ID ORDER BY
                             (CASE
                               WHEN CO.ACTIVE_FLAG IN ('Active','Freezing') THEN
                                0
                               WHEN CO.ACTIVE_FLAG = 'Inactive' THEN
                                1
                               ELSE
                                2
                               END), CO.LAST_UPDATE_DATE DESC, CO.CUSTOMER_ORG_ID DESC) AS RN,
                           NVL((CASE
                                 WHEN H.LAST_UPDATE_DATE > CO.LAST_UPDATE_DATE THEN
                                   H.LAST_UPDATE_BY
                                 ELSE
                                   CO.LAST_UPDATE_BY
                                 END),NVL(CO.CREATED_BY,H.CREATED_BY)) AS LAST_UPDATE_BY,
                           NVL((CASE
                                 WHEN H.LAST_UPDATE_DATE > CO.LAST_UPDATE_DATE THEN
                                   H.LAST_UPDATE_DATE
                                 ELSE
                                   CO.LAST_UPDATE_DATE
                                 END),NVL(GREATEST(CO.CREATION_DATE,H.CREATION_DATE),SYSDATE)) AS LAST_UPDATE_DATE
                      FROM INTF_CUSTOMER_HEADER IH
                     INNER JOIN T_CUSTOMER_HEADER H
                        ON (H.SIEBEL_CUSTOMER_ID = IH.SIEBEL_CUSTOMER_ID)
                     INNER JOIN T_CUSTOMER_ORG CO
                        ON (CO.CUSTOMER_ID = H.CUSTOMER_ID AND CO.ENTITY_ID IS NOT NULL AND CO.SALES_CENTER_ID IS NOT NULL AND CO.SALES_CENTER_CODE IS NOT NULL)
                     WHERE IH.CUSTOMER_ID IN 
                       (
                         SELECT TO_NUMBER(REGEXP_SUBSTR(P_INTF_HEADER_ID_LIST,'[^,]{1,}',1,LEVEL)) AS LI
                           FROM DUAL
                         CONNECT BY LEVEL <=
                           (1 + LENGTH(REGEXP_REPLACE(P_INTF_HEADER_ID_LIST,'[^,]','')))
                       )
                   ) OT
             INNER JOIN T_CUSTOMER_SALES_MAIN_TYPE CT
                ON (CT.ENTITY_ID = OT.ENTITY_ID
                    AND CT.CUSTOM_ID = OT.CUSTOMER_ID)
             WHERE 1 = OT.RN AND CT.SALES_MAIN_TYPE_NAME IS NOT NULL
          ) T 
            LEFT JOIN UP_CODELIST CL
                ON (CL.CODETYPE = 'MIDEA_MARKET_MODE'
                    AND CL.CODE_VALUE = T.COOPERATION_MODEL)
           WHERE LENGTHB(T.COOPERATION_MODEL) = LENGTH(T.COOPERATION_MODEL)
        ) UT
        ON (MT.ENTITY_ID = UT.ENTITY_ID
            AND MT.CUSTOMER_ID = UT.CUSTOMER_ID
            AND MT.SALES_CENTER_ID = UT.SALES_CENTER_ID
            AND MT.SALES_MAIN_TYPE_CODE = UT.SALES_MAIN_TYPE_CODE)
        WHEN MATCHED THEN
          UPDATE
             SET MT.CUSTOMER_CODE     = UT.CUSTOMER_CODE
                ,MT.CUSTOMER_NAME     = UT.CUSTOMER_NAME
                ,MT.SALES_CENTER_CODE = UT.SALES_CENTER_CODE
                ,MT.SALES_CENTER_NAME = UT.SALES_CENTER_NAME
                ,MT.CUSTOMER_STATUS   = UT.HEAD_STATUS
                ,MT.ORG_STATUS        = UT.ORG_ACTIVE_FLAG
              --,MT.SALES_MAIN_TYPE_CODE = UT.SALES_MAIN_TYPE_CODE
                ,MT.SALES_MAIN_TYPE_NAME = UT.SALES_MAIN_TYPE_NAME
                ,MT.ACTIVE_FLAG          = NVL(UT.ACTIVE_FLAG, 'Inactive')
                ,MT.COOPERATION_MODEL    = UT.COOPERATION_MODEL,
                 MT.COOPERATION_MODEL_NAME = UT.COOPERATION_MODEL_NAME
                ,MT.LAST_UPDATE_BY         = NVL(UT.LAST_UPDATE_BY, 'CRM')
                ,MT.LAST_UPDATE_DATE       = UT.LAST_UPDATE_DATE
                ,MT.NET_BATCH_FLAG         = UT.NET_BATCH_FLAG
        WHEN NOT MATCHED THEN
          INSERT
            (MT.CUST_COOPERATE_MODEL_ID
            ,MT.ENTITY_ID
            ,MT.CUSTOMER_ID
            ,MT.SALES_CENTER_ID
            ,MT.SALES_MAIN_TYPE_CODE
            ,MT.CUSTOMER_CODE
            ,MT.CUSTOMER_NAME
            ,MT.SALES_CENTER_CODE
            ,MT.SALES_CENTER_NAME
            ,MT.CUSTOMER_STATUS
            ,MT.ORG_STATUS
            ,MT.SALES_MAIN_TYPE_NAME
            ,MT.ACTIVE_FLAG
            ,MT.COOPERATION_MODEL
            ,MT.COOPERATION_MODEL_NAME
            ,MT.CREATED_BY
            ,MT.CREATION_DATE
            ,MT.NET_BATCH_FLAG)
          VALUES
            (S_CUSTOMER_COOPERATE_MODEL.NEXTVAL
            ,UT.ENTITY_ID
            ,UT.CUSTOMER_ID
            ,UT.SALES_CENTER_ID
            ,UT.SALES_MAIN_TYPE_CODE
            ,UT.CUSTOMER_CODE
            ,UT.CUSTOMER_NAME
            ,UT.SALES_CENTER_CODE
            ,UT.SALES_CENTER_NAME
            ,UT.HEAD_STATUS
            ,UT.ORG_ACTIVE_FLAG
            ,UT.SALES_MAIN_TYPE_NAME
            ,NVL(UT.ACTIVE_FLAG, 'Inactive')
            ,UT.COOPERATION_MODEL
            ,UT.COOPERATION_MODEL_NAME
            ,NVL(UT.LAST_UPDATE_BY, 'CRM')
            ,NVL(UT.LAST_UPDATE_DATE, SYSDATE)
            ,UT.NET_BATCH_FLAG)
        ;
        
        DELETE FROM T_CUSTOMER_COOPERATE_MODEL T
         WHERE T.COOPERATION_MODEL_NAME IS NULL
           AND LENGTHB(T.COOPERATION_MODEL) <> LENGTH(T.COOPERATION_MODEL);
        
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
            --记录出错信息
            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC',
                                                SQLCODE,
                                                '更新客户中心经营品类合作类型T_CUSTOMER_COOPERATE_MODEL出错！：' || SQLERRM);
            COMMIT;
      END;
      
      --2017 4 17 梁颜明 对接财务系统如果是NC，将客户头、银行信息插入NC接口表
      FOR ENTITY_ID_ARR IN (
        SELECT ENTITY_ID ENTITY_ID
          FROM V_BD_ENTITY V
         WHERE 'NC' = PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS', V.ENTITY_ID, NULL, NULL)
      ) LOOP
        BEGIN
          PKG_CUSTOMER_INTF_NC.P_CUSTOMER_INTF_NC_PROC(ENTITY_ID_ARR.ENTITY_ID,
                                                       V_INTF_HEADER_ID_LIST(K),
                                                       V_HEADER_ID,
                                                       P_MESSAGE);
          COMMIT;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
      END LOOP;
      
      <<LPEND>>
      NULL;
    END LOOP;
    
    IF VT_HEAD_ERRMSG <> 'SUCCESS' THEN
      P_MESSAGE := VT_HEAD_ERRMSG;
    ELSIF VT_DEPT_ERRMSG <> 'SUCCESS' THEN
      P_MESSAGE := VT_DEPT_ERRMSG;
    ELSE
      P_MESSAGE := 'SUCCESS';
    END IF;
    /*IF P_MESSAGE IS NULL THEN
      P_MESSAGE := 'SUCCESS';
    END IF;*/
  END P_CUSTOMER_INTF_PROC;

  PROCEDURE P_CUSTOMER_CHECK_CANVALID_PROC(P_INVALID_ID    in NUMBER, --失效历史ID
                                           P_CUSTOMER_CODE in varchar2, --客户编码
                                           P_INVALID_TYPE  in varchar2, --失效类型
                                           --001代表客户头失效，002代表事业部层失效，003代表客户OU失效
                                           P_DEPT_CODE      in varchar2, --事业部编码
                                           P_DEPT_NAME      in varchar2, --事业部名称
                                           P_CUSTOMER_OU_ID in varchar2, --客户OU ID
                                           P_TRANSCODE      in varchar2, --流水号
                                           P_SOURCE_CODE    in varchar2, --来源系统
                                           P_REQUEST_ID     in varchar2, --请求ID
                                           P_RESULT         OUT varchar2,
                                           --返回结果：Y 可以失效 N不可以失效 W未处理 E异常
                                           P_MESSAGE out varchar2
                                           --P_RESULT等于2时返回，或者有错误时返回
                                           ) IS
    V_MESSAGE1 VARCHAR2(4000);
    V_MESSAGE2 VARCHAR2(4000);
    V_MESSAGE3 VARCHAR2(4000);
    V_MESSAGE4 VARCHAR2(4000);
    V_COUNT    NUMBER;
    V_LAST_MANUAL_DATE                     INTF_CUSTOMER_INVALID_HIS.LAST_UPDATE_DATE%TYPE;
  BEGIN
    P_RESULT  := 'N';
    P_MESSAGE := '无';
    
    --取打开手工开关的最新时间
    SELECT MAX(S.LAST_UPDATE_DATE) INTO V_LAST_MANUAL_DATE FROM INTF_CUSTOMER_INVALID_HIS S
    WHERE 'Y' = S.PRE_FIELD_01
    AND EXISTS (SELECT 1 FROM INTF_CUSTOMER_INVALID_HIS H
    WHERE H.INVALID_ID = P_INVALID_ID
    AND H.CUSTOMER_CODE = S.CUSTOMER_CODE
    AND H.SOURCE_CODE = S.SOURCE_CODE
    AND H.INVALID_TYPE = S.INVALID_TYPE
    AND ((H.DEPT_CODE IS NULL AND S.DEPT_CODE IS NULL)
    OR H.DEPT_CODE = S.DEPT_CODE)
    AND ((H.CUSTOMER_OU_ID IS NULL AND S.CUSTOMER_OU_ID IS NULL)
    OR H.CUSTOMER_OU_ID = S.CUSTOMER_OU_ID)
    );
    SELECT count(0)
      INTO V_COUNT
      FROM T_CUSTOMER_HEADER H
     WHERE H.Customer_Code = P_CUSTOMER_CODE
    --and H.Dept_Id IS NOT NULL
    ;
    IF 0 = V_COUNT THEN
      P_RESULT  := 'Y';
      P_MESSAGE := NULL;
      --P_MESSAGE := 'CIMS客户头表不存在';
      /*UPDATE INTF_CUSTOMER_INVALID_HIS T
         SET T.Can_Invalid = P_RESULT, T.REASON_DESC = P_MESSAGE
       WHERE T.INVALID_ID = P_INVALID_ID;
      COMMIT;*/
      RETURN;
    END IF;
    /*
       ①  检查余款：检查客户是否存在可提货金额（不为零）。如果有，则反馈不能失效，
       原因：该客户在CIMS中存在可提货金额，无法进行客户失效。
    ② 未结业务：检查客户在OU下是否存在未引入ERP的销售单（检查范围为销售单表中OU_ID is not null），
    或者ERP中存在不是最终状态的销售单。如果有，则反馈不能失效，
    原因：该客户在CIMS中存在未结算完成的销售单，无法进行客户失效
    */
    --
    BEGIN
      /*
          客户头失效：按所有主体检查条件①校验；按客户对应OU检查条件②校验。
      客户事业部失效：按事业部编码所在主体检查条件①校验；按客户对应OU检查条件②校验。
      客户OU失效：按传入的客户、OU进行检查条件②校验
      */
      if '001' = P_INVALID_TYPE OR '002' = P_INVALID_TYPE then
        --可提货金额：到款金额-销售金额+铺底额度+临时额度-锁定到款金额 
        --折让金额-核销折让金额+冻结扣率折让金额-锁定扣率折让金额
        BEGIN
          with m as
           (select be.entity_id,
                   be.entity_name,
                   be.entity_code,
                   t.credit_group_id,
                   cg.credit_group_name
                   || '(' || t.account_code || '/' || a.sales_center_name || ')' as credit_group_name,
                   sum(t.received_amount - t.sales_amount +
                       t.delaypay_amount + t.temp_delaypay_amount -
                       t.lock_received_amount + t.discount_amount +
                       t.freeze_discount_amount - t.lock_discount_amount -
                       t.applied_discount_amount
                       + t.mpay_stream_amount - t.mpay_cash_amount) as delivery_amount,
                   sum(t.received_amount - t.sales_amount) as account_balance,
                   sum(t.discount_amount - t.applied_discount_amount) as allowance_balance
              from t_sales_account_amount t,
                   v_bd_entity            be,
                   t_credit_group         cg,
                   t_customer_account     a
             where t.entity_id = be.entity_id
               and t.credit_group_id = cg.credit_group_id
               and t.customer_code = P_CUSTOMER_CODE
               and a.account_id = t.account_id
               and ('001' = P_INVALID_TYPE OR
                   ('002' = P_INVALID_TYPE AND EXISTS
                    (SELECT 1
                        FROM UP_ORG_UNIT U
                       WHERE U.CODE = P_DEPT_CODE
                         AND U.ENTITY_ID = be.ENTITY_ID)
                   --
                   ))
             group by be.entity_id,
                      be.entity_name,
                      be.entity_code,
                      t.credit_group_id,
                      cg.credit_group_name
                      || '(' || t.account_code || '/' || a.sales_center_name || ')'
            having 0 <> sum(t.received_amount - t.sales_amount + t.delaypay_amount
            --
            +t.temp_delaypay_amount - t.lock_received_amount + t.discount_amount
            --
            +t.freeze_discount_amount - t.lock_discount_amount - t.applied_discount_amount
            + t.mpay_stream_amount -t.mpay_cash_amount) OR 0 <> sum(t.received_amount - t.sales_amount) OR 0 <> sum(t.discount_amount - t.applied_discount_amount)
            --
            ),
          m2 as
           (select m.entity_name,
                   listagg(m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id) as credit_group_name,
                   '可提货金额' as amount_name,
                   listagg(m.delivery_amount, ',') WITHIN GROUP(order by m.credit_group_id) as delivery_amount
              from m
             where 0 <> m.delivery_amount
             group by m.entity_name
            union all
            select m.entity_name,
                   listagg(m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id) as credit_group_name,
                   '到款余额' as amount_name,
                   listagg(m.account_balance, ',') WITHIN GROUP(order by m.credit_group_id) as delivery_amount
              from m
             where 0 = m.delivery_amount
               and 0 <> m.account_balance
             group by m.entity_name
            union all
            select m.entity_name,
                   listagg(m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id) as credit_group_name,
                   '折让余额' as amount_name,
                   listagg(m.allowance_balance, ',') WITHIN GROUP(order by m.credit_group_id) as delivery_amount
              from m
             where 0 = m.delivery_amount
               and 0 = m.account_balance
               and 0 <> m.allowance_balance
             group by m.entity_name)
          select listagg(m2.entity_name || ',额度组:' || m2.credit_group_name || ',' ||
                          m2.amount_name || ':' || m2.delivery_amount,
                          chr(10))
                 --
                  WITHIN GROUP(order by m2.entity_name, m2.amount_name)
            INTO V_MESSAGE1
            from m2 -- where 10 >= rownum
          ;
        EXCEPTION
          WHEN VALUE_ERROR THEN
            V_MESSAGE1 := '查询可提货金额SQL异常' || SQLERRM;
          WHEN OTHERS THEN
            V_MESSAGE1 := '查询可提货金额SQL异常' || SQLERRM;
        END;
      end if;
      BEGIN
        with ou as
         (select min(nvl(t.entity_id, 0)) as min_entity_id,
                 max(nvl(t.entity_id, 0)) as max_entity_id,
                 count(distinct nvl(t.entity_id, 0)) as cnt_entity_id,
                 t.operating_unit,
                 t.operating_unit_code,
                 t.operating_unit_name
            from t_inv_organization t
           where t.operating_unit not in (715) --小天鹅OU切换,单据不引ERP,不做检查 2020-02-20
           group by t.operating_unit,
                    t.operating_unit_code,
                    t.operating_unit_name),
        m as
         (select rank() over(partition by be.entity_id, order_cims.erp_ou_name order by order_cims.so_header_id) as rn,
                 be.entity_id,
                 be.entity_name,
                 be.entity_code,
                 cus_ou.customer_code,
                 order_cims.erp_ou_name,
                 order_cims.so_num
            from t_so_header      order_cims,
                 t_so_type_extend order_type_cims,
                 t_customer_ou    cus_ou,
                 v_bd_entity      be
           where order_cims.bill_type_id = order_type_cims.bill_type_id
             and order_type_cims.to_erp_flag = 'Y'
             and cus_ou.customer_id = order_cims.customer_id
             and cus_ou.customer_code = order_cims.customer_code
             and to_number(cus_ou.erpou) = order_cims.erp_ou_id
             and 'Active' = cus_ou.active_flag
             and order_cims.entity_id = be.entity_id
             and order_type_cims.entity_id = be.entity_id
             and order_cims.customer_code = P_CUSTOMER_CODE
             AND (V_LAST_MANUAL_DATE IS NULL OR order_cims.Creation_Date >= V_LAST_MANUAL_DATE)
             and ('001' = P_INVALID_TYPE OR
                 ('002' = P_INVALID_TYPE AND EXISTS
                  (SELECT 1
                      FROM UP_ORG_UNIT U
                     WHERE U.CODE = P_DEPT_CODE
                       AND U.ENTITY_ID = be.ENTITY_ID)
                 --
                 ) OR ('003' = P_INVALID_TYPE AND
                 P_CUSTOMER_OU_ID = cus_ou.erpou))
             AND EXISTS
           (SELECT 1
                    FROM ou
                   WHERE ou.operating_unit = order_cims.erp_ou_id --cus_ou.erpou
                     AND be.entity_id =
                         DECODE(ou.min_entity_id,
                                0,
                                decode(ou.max_entity_id,
                                       0,
                                       null,
                                       ou.max_entity_id),
                                ou.min_entity_id)
                  --
                  )
             and exists
           (select 1
                    from t_so_line l
                   where l.so_header_id = order_cims.so_header_id
                     and l.item_qty > 0)
             and ( ('NC' = PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS',order_cims.Entity_Id,NULL,NULL) AND NOT('Y' = order_cims.Settle_Flag OR ('12' = order_cims.So_Status AND order_cims.Settle_Date IS NOT NULL)) )
              or ('ERP' = PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS',order_cims.Entity_Id,NULL,NULL) AND NOT exists
                  (select 1
                          from apps.oe_order_headers_all@mdims2mderp a
                         where a.order_number = order_cims.so_num
                           and a.org_id = order_cims.erp_ou_id
                           and a.flow_status_code in ('BOOKED', 'CLOSED')) 
                   and exists (select 1 from intf_oe_headers_iface_all sh 
                        where sh.global_attribute12 = order_cims.so_num))
            )
          --
          ),
        m2 as
         (select m.entity_name,
                 m.erp_ou_name,
                 wm_concat((case
                             when m.rn <= 5 then
                              m.so_num
                             else
                              null
                           end)) as so_nums,
                 count(distinct m.so_num) as so_num_cnt
            from m
           group by m.entity_name, m.erp_ou_name)
        
        select listagg(m2.entity_name || ',' || m2.erp_ou_name || '共' ||
                        m2.so_num_cnt || '笔，' || m2.so_nums || (case
                          when m2.so_num_cnt <= 5 then
                           ''
                          else
                           '......'
                        end),
                        chr(10))
               --
                WITHIN GROUP(order by m2.entity_name, m2.erp_ou_name) as msg
          INTO V_MESSAGE2
          from m2;
      EXCEPTION
        WHEN VALUE_ERROR THEN
          V_MESSAGE2 := '查询未结单据SQL异常' || SQLERRM;
        WHEN OTHERS THEN
          V_MESSAGE2 := '查询未结单据SQL异常' || SQLERRM;
      END;
      --VALUE_ERROR
      /*
      核销关系对应，收款（收款单） 核销 发票（销售单，退款单等）
 select * from cims.intf_ar_writeoff where INTF_STATUS='E' and CANCEL_FLAG='N' and customer_number='';
*/
      /*BEGIN
        with ou as
         (select min(nvl(t.entity_id, 0)) as min_entity_id,
                 max(nvl(t.entity_id, 0)) as max_entity_id,
                 count(distinct nvl(t.entity_id, 0)) as cnt_entity_id,
                 t.operating_unit,
                 t.operating_unit_code,
                 t.operating_unit_name
            from t_inv_organization t
           group by t.operating_unit,
                    t.operating_unit_code,
                    t.operating_unit_name),
        m as
         (select rank() over(partition by be.entity_id, ou.operating_unit_name order by wo.trx_id) as rn,
                 be.entity_id,
                 be.entity_name,
                 be.entity_code,
                 cus_ou.customer_code,
                 ou.operating_unit_name as erp_ou_name,
                 wo.receipt_number as so_num
            from intf_ar_writeoff      wo,
                 t_customer_ou    cus_ou,
                 v_bd_entity      be,
                 ou
           where cus_ou.customer_id = wo.customer_id
             and cus_ou.customer_code = wo.customer_number
             and to_number(cus_ou.erpou) = wo.org_id
             and 'Active' = cus_ou.active_flag
             and wo.customer_number = P_CUSTOMER_CODE
             AND (V_LAST_MANUAL_DATE IS NULL
             OR (wo.return_date is null and wo.post_date is null)
             OR wo.return_date >= V_LAST_MANUAL_DATE
             )
             and wo.INTF_STATUS in ('N','E') and wo.CANCEL_FLAG='N'
             and ('001' = P_INVALID_TYPE OR
                 ('002' = P_INVALID_TYPE AND EXISTS
                  (SELECT 1
                      FROM UP_ORG_UNIT U
                     WHERE U.CODE = P_DEPT_CODE
                       AND U.ENTITY_ID = be.ENTITY_ID)
                 --
                 ) OR ('003' = P_INVALID_TYPE AND
                 P_CUSTOMER_OU_ID = cus_ou.erpou))
                 
             AND ou.operating_unit = wo.org_id
                     AND be.entity_id =
                         DECODE(ou.min_entity_id,
                                0,
                                decode(ou.max_entity_id,
                                       0,
                                       null,
                                       ou.max_entity_id),
                                ou.min_entity_id)
          --
          ),
        m2 as
         (select m.entity_name,
                 m.erp_ou_name,
                 wm_concat((case
                             when m.rn <= 5 then
                              m.so_num
                             else
                              null
                           end)) as so_nums,
                 count(distinct m.so_num) as so_num_cnt
            from m
           group by m.entity_name, m.erp_ou_name)
        
        select listagg(m2.entity_name || ',' || m2.erp_ou_name || '共' ||
                        m2.so_num_cnt || '笔，' || m2.so_nums || (case
                          when m2.so_num_cnt <= 5 then
                           ''
                          else
                           '......'
                        end),
                        chr(10))
               --
                WITHIN GROUP(order by m2.entity_name, m2.erp_ou_name) as msg
          INTO V_MESSAGE3
          from m2;
      EXCEPTION
        WHEN VALUE_ERROR THEN
          V_MESSAGE3 := '查询异常收款核销发票关系SQL异常' || SQLERRM;
        WHEN OTHERS THEN
          V_MESSAGE3 := '查询异常收款核销发票关系SQL异常' || SQLERRM;
      END;*/
      /*核销关系对应  负数发票（折让单，退货单等）核销发票（销售单，退款单等）
select * from cims.intf_ar_writeoff_inv where INTF_STATUS='E' and CANCEL_FLAG='N' and  customer_number='';
*/
      /*BEGIN
        with ou as
         (select min(nvl(t.entity_id, 0)) as min_entity_id,
                 max(nvl(t.entity_id, 0)) as max_entity_id,
                 count(distinct nvl(t.entity_id, 0)) as cnt_entity_id,
                 t.operating_unit,
                 t.operating_unit_code,
                 t.operating_unit_name
            from t_inv_organization t
           group by t.operating_unit,
                    t.operating_unit_code,
                    t.operating_unit_name),
        m as
         (select rank() over(partition by be.entity_id, ou.operating_unit_name order by wo.trx_id) as rn,
                 be.entity_id,
                 be.entity_name,
                 be.entity_code,
                 cus_ou.customer_code,
                 ou.operating_unit_name as erp_ou_name,
                 wo.cm_trx_number || '(' || wo.invoice_trx_number || ')' as so_num
            from intf_ar_writeoff_inv      wo,
                 t_customer_ou    cus_ou,
                 v_bd_entity      be,
                 ou
           where cus_ou.customer_id = wo.customer_id
             and cus_ou.customer_code = wo.customer_number
             and to_number(cus_ou.erpou) = wo.org_id
             and 'Active' = cus_ou.active_flag
             and wo.customer_number = P_CUSTOMER_CODE
             AND (V_LAST_MANUAL_DATE IS NULL
             OR (wo.return_date is null and wo.post_date is null)
             OR wo.return_date >= V_LAST_MANUAL_DATE
             )
             and wo.INTF_STATUS in ('N','E') and wo.CANCEL_FLAG='N'
             and ('001' = P_INVALID_TYPE OR
                 ('002' = P_INVALID_TYPE AND EXISTS
                  (SELECT 1
                      FROM UP_ORG_UNIT U
                     WHERE U.CODE = P_DEPT_CODE
                       AND U.ENTITY_ID = be.ENTITY_ID)
                 --
                 ) OR ('003' = P_INVALID_TYPE AND
                 P_CUSTOMER_OU_ID = cus_ou.erpou))
                 
             AND ou.operating_unit = wo.org_id
                     AND be.entity_id =
                         DECODE(ou.min_entity_id,
                                0,
                                decode(ou.max_entity_id,
                                       0,
                                       null,
                                       ou.max_entity_id),
                                ou.min_entity_id)
          --
          ),
        m2 as
         (select m.entity_name,
                 m.erp_ou_name,
                 wm_concat((case
                             when m.rn <= 5 then
                              m.so_num
                             else
                              null
                           end)) as so_nums,
                 count(distinct m.so_num) as so_num_cnt
            from m
           group by m.entity_name, m.erp_ou_name)
        
        select listagg(m2.entity_name || ',' || m2.erp_ou_name || '共' ||
                        m2.so_num_cnt || '笔，' || m2.so_nums || (case
                          when m2.so_num_cnt <= 5 then
                           ''
                          else
                           '......'
                        end),
                        chr(10))
               --
                WITHIN GROUP(order by m2.entity_name, m2.erp_ou_name) as msg
          INTO V_MESSAGE4
          from m2;
      EXCEPTION
        WHEN VALUE_ERROR THEN
          V_MESSAGE4 := '查询异常负数发票核销发票关系SQL异常' || SQLERRM;
        WHEN OTHERS THEN
          V_MESSAGE4 := '查询异常负数发票核销发票关系SQL异常' || SQLERRM;
      END;
      */
    
      IF V_MESSAGE1 IS NULL AND V_MESSAGE2 IS NULL
        AND V_MESSAGE3 IS NULL
        AND V_MESSAGE4 IS NULL THEN
        P_RESULT  := 'Y';
        P_MESSAGE := null;
      ELSE
        /*
           ①  检查余款： 原因：该客户在CIMS中存在可提货金额，无法进行客户失效。
        ② 未结业务：原因：该客户在CIMS中存在未结算完成的销售单，无法进行客户失效
        */
        P_RESULT  := 'N';
        P_MESSAGE := '';
        IF V_MESSAGE1 IS NOT NULL THEN
          P_MESSAGE := '存在可提货金额、到款余额、折让余额，无法进行失效。额度组如下：';
          P_MESSAGE := P_MESSAGE || chr(10);
          P_MESSAGE := P_MESSAGE || V_MESSAGE1;
        END IF;
        IF V_MESSAGE2 IS NOT NULL THEN
          IF P_MESSAGE IS NOT NULL THEN
            P_MESSAGE := P_MESSAGE || chr(10);
          END IF;
          P_MESSAGE := P_MESSAGE || '存在未结算完成的销售单，无法进行失效。';
          P_MESSAGE := P_MESSAGE || chr(10);
          P_MESSAGE := P_MESSAGE || V_MESSAGE2;
        END IF;
        IF V_MESSAGE3 IS NOT NULL THEN
          IF P_MESSAGE IS NOT NULL THEN
            P_MESSAGE := P_MESSAGE || chr(10);
          END IF;
          P_MESSAGE := P_MESSAGE || '存在异常收款核销发票关系，无法进行失效。';
          P_MESSAGE := P_MESSAGE || chr(10);
          P_MESSAGE := P_MESSAGE || V_MESSAGE3;
        END IF;
        IF V_MESSAGE4 IS NOT NULL THEN
          IF P_MESSAGE IS NOT NULL THEN
            P_MESSAGE := P_MESSAGE || chr(10);
          END IF;
          P_MESSAGE := P_MESSAGE || '存在异常负数发票（折让单，退货单等）核销发票（销售单，退款单等）关系，无法进行失效。';
          P_MESSAGE := P_MESSAGE || chr(10);
          P_MESSAGE := P_MESSAGE || V_MESSAGE4;
        END IF;
      END IF;
    
      /*BEGIN
        UPDATE INTF_CUSTOMER_INVALID_HIS T
           SET T.Can_Invalid = P_RESULT, T.REASON_DESC = P_MESSAGE
         WHERE T.INVALID_ID = P_INVALID_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;*/
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT  := 'N';
        P_MESSAGE := '客户失效校验数据库层异常：' || SQLERRM;
        /*UPDATE INTF_CUSTOMER_INVALID_HIS T
           SET T.Can_Invalid = P_RESULT, T.REASON_DESC = P_MESSAGE
         WHERE T.INVALID_ID = P_INVALID_ID;
        COMMIT;*/
    END;
  END P_CUSTOMER_CHECK_CANVALID_PROC;

  FUNCTION F_CUSTORG_CHECK_CANVALID(P_CUSTOMER_CODE      in varchar2, --客户编码
                                    P_DEPT_CODE          in varchar2, --事业部编码
                                    P_SALES_CENTER_ID    in number, --中心ID
                                    P_SALES_CENTER_CODE  in varchar2, --中心编码
                                    P_CUST_ORG_ID        in number, --客户中心关系ID
                                    P_SIEBEL_CUST_ORG_ID in varchar2, --客户中心关系主数据ID
                                    P_ACCOUNT_ID         in number --账户ID
                                    ) return VARCHAR2 IS
    V_MESSAGE1 VARCHAR2(4000);
    V_MESSAGE2 VARCHAR2(4000);
    V_MESSAGE3 VARCHAR2(4000);
    V_MESSAGE4 VARCHAR2(4000);
    P_MESSAGE  VARCHAR2(4000);
  BEGIN
    P_MESSAGE := NULL;
    /*
       ①  检查余款：检查客户是否存在可提货金额（不为零）。如果有，则反馈不能失效，
       原因：该客户在CIMS中存在可提货金额，无法进行客户失效。
    ② 未结业务：检查客户在OU下是否存在未引入ERP的销售单（检查范围为销售单表中OU_ID is not null），
    或者ERP中存在不是最终状态的销售单。如果有，则反馈不能失效，
    原因：该客户在CIMS中存在未结算完成的销售单，无法进行客户失效
    */
    /*
        客户头失效：按所有主体检查条件①校验；按客户对应OU检查条件②校验。
    客户事业部失效：按事业部编码所在主体检查条件①校验；按客户对应OU检查条件②校验。
    客户OU失效：按传入的客户、OU进行检查条件②校验
    */
    --可提货金额：到款金额-销售金额+铺底额度+临时额度-锁定到款金额 
    --折让金额-核销折让金额+冻结扣率折让金额-锁定扣率折让金额
    BEGIN
      BEGIN
        with m as
         (select be.entity_id,
                 be.entity_name,
                 be.entity_code,
                 t.credit_group_id,
                 cg.credit_group_name,
                 A.ACCOUNT_ID,
                 A.ACCOUNT_CODE,
                 sum(t.received_amount - t.sales_amount + t.delaypay_amount +
                     t.temp_delaypay_amount - t.lock_received_amount +
                     t.discount_amount + t.freeze_discount_amount -
                     t.lock_discount_amount - t.applied_discount_amount
                     + t.mpay_stream_amount -t.mpay_cash_amount) as delivery_amount,
                 sum(t.received_amount - t.sales_amount) as account_balance,
                 sum(t.discount_amount - t.applied_discount_amount) as allowance_balance
            from t_sales_account_amount      t,
                 v_bd_entity                 be,
                 t_credit_group              cg,
                 t_customer_org              co,
                 t_customer_account          a
                 --,t_customer_acc_org_relation ar
           where t.entity_id = be.entity_id
             --AND co.entity_id = be.entity_id
             AND a.entity_id = be.entity_id
             and t.credit_group_id = cg.credit_group_id
             --AND A.ACCOUNT_ID = AR.ACCOUNT_ID
             AND A.ACCOUNT_ID = T.ACCOUNT_ID
             AND A.CUSTOMER_ORG_ID = CO.CUSTOMER_ORG_ID
             --AND CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID
             --AND CO.ACTIVE_FLAG <> 'Inactive'
             AND 'Y' = A.ACTIVE_FLAG
                --AND ('1' = A.ACCOUNT_STATUS OR '-1' = A.ACCOUNT_STATUS)
             and (P_DEPT_CODE IS NULL OR EXISTS
                  (SELECT 1
                     FROM UP_ORG_UNIT U
                    WHERE U.CODE = P_DEPT_CODE
                      AND U.ENTITY_ID = be.ENTITY_ID))
             AND ((P_CUSTOMER_CODE IS NOT NULL AND
                 T.CUSTOMER_CODE = P_CUSTOMER_CODE) OR
                 (P_CUSTOMER_CODE IS NULL AND
                 T.CUSTOMER_ID = A.CUSTOMER_ID))
             and a.sales_center_id =
                 NVL(P_SALES_CENTER_ID, a.sales_center_id)
             and a.sales_center_code =
                 NVL(P_SALES_CENTER_CODE, a.sales_center_code)
             and a.customer_org_id = NVL(P_CUST_ORG_ID, a.customer_org_id)
             and co.SIEBEL_ORG_ID =
                 NVL(P_SIEBEL_CUST_ORG_ID, co.SIEBEL_ORG_ID)
             /*AND ((P_CUSTOMER_CODE IS NOT NULL AND
                 T.CUSTOMER_CODE = P_CUSTOMER_CODE) OR
                 (P_CUSTOMER_CODE IS NULL AND
                 T.CUSTOMER_ID = CO.CUSTOMER_ID))
             and co.sales_center_id =
                 NVL(P_SALES_CENTER_ID, co.sales_center_id)
             and co.sales_center_code =
                 NVL(P_SALES_CENTER_CODE, co.sales_center_code)
             and co.customer_org_id = NVL(P_CUST_ORG_ID, co.customer_org_id)
             and co.SIEBEL_ORG_ID =
                 NVL(P_SIEBEL_CUST_ORG_ID, co.SIEBEL_ORG_ID)*/
             and A.ACCOUNT_ID = NVL(P_ACCOUNT_ID, A.ACCOUNT_ID)
           group by be.entity_id,
                    be.entity_name,
                    be.entity_code,
                    t.credit_group_id,
                    cg.credit_group_name,
                    A.ACCOUNT_ID,
                    A.ACCOUNT_CODE
          having 0 <> sum(t.received_amount - t.sales_amount + t.delaypay_amount
          --
          +t.temp_delaypay_amount - t.lock_received_amount + t.discount_amount
          --
          +t.freeze_discount_amount - t.lock_discount_amount - t.applied_discount_amount
          + t.mpay_stream_amount -t.mpay_cash_amount) OR 0 <> sum(t.received_amount - t.sales_amount) OR 0 <> sum(t.discount_amount - t.applied_discount_amount)
          --
          ),
        m2 as
         (select m.entity_name,
                 listagg(M.ACCOUNT_CODE || '_' || m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id, M.ACCOUNT_ID) as credit_group_name,
                 '可提货金额' as amount_name,
                 listagg(m.delivery_amount, ',') WITHIN GROUP(order by m.credit_group_id, M.ACCOUNT_ID) as delivery_amount
            from m
           where 0 <> m.delivery_amount
           group by m.entity_name
          union all
          select m.entity_name,
                 listagg(M.ACCOUNT_CODE || '_' || m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id, M.ACCOUNT_ID) as credit_group_name,
                 '到款余额' as amount_name,
                 listagg(m.account_balance, ',') WITHIN GROUP(order by m.credit_group_id) as delivery_amount
            from m
           where 0 = m.delivery_amount
             and 0 <> m.account_balance
           group by m.entity_name
          union all
          select m.entity_name,
                 listagg(M.ACCOUNT_CODE || '_' || m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id, M.ACCOUNT_ID) as credit_group_name,
                 '折让余额' as amount_name,
                 listagg(m.allowance_balance, ',') WITHIN GROUP(order by m.credit_group_id) as delivery_amount
            from m
           where 0 = m.delivery_amount
             and 0 = m.account_balance
             and 0 <> m.allowance_balance
           group by m.entity_name)
        select listagg(m2.entity_name || ',账户_额度组:' || m2.credit_group_name || ',' ||
                        m2.amount_name || ':' || m2.delivery_amount,
                        chr(10))
               --
                WITHIN GROUP(order by m2.entity_name, m2.amount_name)
          INTO V_MESSAGE1
          from m2 -- where 10 >= rownum
        ;
      EXCEPTION
        WHEN VALUE_ERROR THEN
          V_MESSAGE1 := '查询可提货金额SQL异常' || SQLERRM;
        WHEN OTHERS THEN
          V_MESSAGE1 := '查询可提货金额SQL异常' || SQLERRM;
      END;
      BEGIN
        with ou as
         (select min(nvl(t.entity_id, 0)) as min_entity_id,
                 max(nvl(t.entity_id, 0)) as max_entity_id,
                 count(distinct nvl(t.entity_id, 0)) as cnt_entity_id,
                 t.operating_unit,
                 t.operating_unit_code,
                 t.operating_unit_name
            from t_inv_organization t
           group by t.operating_unit,
                    t.operating_unit_code,
                    t.operating_unit_name),
        m as
         (select rank() over(partition by be.entity_id, A.ACCOUNT_ID, A.ACCOUNT_CODE, order_cims.erp_ou_name order by order_cims.so_header_id) as rn,
                 be.entity_id,
                 be.entity_name,
                 be.entity_code,
                 cus_ou.customer_code,
                 order_cims.erp_ou_name,
                 A.ACCOUNT_ID,
                 A.ACCOUNT_CODE,
                 order_cims.so_num
            from t_so_header                 order_cims,
                 t_so_type_extend            order_type_cims,
                 t_customer_ou               cus_ou,
                 v_bd_entity                 be,
                 t_customer_org              co,
                 t_customer_account          a,
                 t_customer_acc_org_relation ar
           where order_cims.bill_type_id = order_type_cims.bill_type_id
             and order_type_cims.to_erp_flag = 'Y'
             and cus_ou.customer_id = order_cims.customer_id
             and cus_ou.customer_code = order_cims.customer_code
             and to_number(cus_ou.erpou) = order_cims.erp_ou_id
             and 'Active' = cus_ou.active_flag
             and order_cims.entity_id = be.entity_id
             and order_type_cims.entity_id = be.entity_id
             AND co.entity_id = be.entity_id
             AND a.entity_id = be.entity_id
             AND A.ACCOUNT_ID = AR.ACCOUNT_ID
             AND A.ACCOUNT_ID = order_cims.ACCOUNT_ID
             AND CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID
             AND CO.ACTIVE_FLAG <> 'Inactive'
             AND 'Y' = A.ACTIVE_FLAG
                --AND ('1' = A.ACCOUNT_STATUS OR '-1' = A.ACCOUNT_STATUS)
             and (P_DEPT_CODE IS NULL OR EXISTS
                  (SELECT 1
                     FROM UP_ORG_UNIT U
                    WHERE U.CODE = P_DEPT_CODE
                      AND U.ENTITY_ID = be.ENTITY_ID))
             AND ((P_CUSTOMER_CODE IS NOT NULL AND
                 order_cims.CUSTOMER_CODE = P_CUSTOMER_CODE) OR
                 (P_CUSTOMER_CODE IS NULL AND
                 order_cims.CUSTOMER_ID = CO.CUSTOMER_ID))
             and co.sales_center_id =
                 NVL(P_SALES_CENTER_ID, co.sales_center_id)
             and co.sales_center_code =
                 NVL(P_SALES_CENTER_CODE, co.sales_center_code)
             and co.customer_org_id = NVL(P_CUST_ORG_ID, co.customer_org_id)
             and co.SIEBEL_ORG_ID =
                 NVL(P_SIEBEL_CUST_ORG_ID, co.SIEBEL_ORG_ID)
             AND A.ACCOUNT_ID = NVL(P_ACCOUNT_ID, A.ACCOUNT_ID)
             AND order_cims.Creation_Date >= NVL(
             (
             --取打开手工开关的最新时间
    SELECT MAX(S.LAST_UPDATE_DATE) FROM INTF_CUSTOMER_INVALID_HIS S
    WHERE 'Y' = S.PRE_FIELD_01
    AND order_cims.customer_code = S.CUSTOMER_CODE
             )
             ,(-1+order_cims.Creation_Date))--不能加1而是减1，因为要确保取不到开关时间时通过，取到时直接比较就可以了
             AND EXISTS
           (SELECT 1
                    FROM ou
                   WHERE ou.operating_unit = order_cims.erp_ou_id --cus_ou.erpou
                     AND be.entity_id =
                         DECODE(ou.min_entity_id,
                                0,
                                decode(ou.max_entity_id,
                                       0,
                                       null,
                                       ou.max_entity_id),
                                ou.min_entity_id)
                  --
                  )
             and exists
           (select 1
                    from t_so_line l
                   where l.so_header_id = order_cims.so_header_id
                     and l.item_qty > 0)
             and ( ('NC' = PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS',order_cims.Entity_Id,NULL,NULL) AND NOT('Y' = order_cims.Settle_Flag OR ('12' = order_cims.So_Status AND order_cims.Settle_Date IS NOT NULL)) )
             or ('ERP' = PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS',order_cims.Entity_Id,NULL,NULL) AND NOT exists
           (select 1
                    from apps.oe_order_headers_all@mdims2mderp a
                   where a.order_number = order_cims.so_num
                     and a.org_id = order_cims.erp_ou_id
                     and a.flow_status_code in ('BOOKED', 'CLOSED')) )
                     )
          --
          ),
        m2 as
         (select m.entity_name,
                 m.erp_ou_name,
                 M.ACCOUNT_ID,
                 M.ACCOUNT_CODE,
                 wm_concat((case
                             when m.rn <= 5 then
                              m.so_num
                             else
                              null
                           end)) as so_nums,
                 count(distinct m.so_num) as so_num_cnt
            from m
           group by m.entity_name,
                    m.erp_ou_name,
                    M.ACCOUNT_ID,
                    M.ACCOUNT_CODE)
        
        select listagg(m2.entity_name || ',' || m2.ACCOUNT_CODE || ',' ||
                        m2.erp_ou_name || '共' || m2.so_num_cnt || '笔，' ||
                        m2.so_nums || (case
                          when m2.so_num_cnt <= 5 then
                           ''
                          else
                           '......'
                        end),
                        chr(10))
               --
                WITHIN GROUP(order by m2.entity_name, m2.erp_ou_name, M2.ACCOUNT_CODE) as msg
          INTO V_MESSAGE2
          from m2;
      EXCEPTION
        WHEN VALUE_ERROR THEN
          V_MESSAGE2 := '查询未结单据SQL异常' || SQLERRM;
        WHEN OTHERS THEN
          V_MESSAGE2 := '查询未结单据SQL异常' || SQLERRM;
      END;
      --VALUE_ERROR
      /*
      核销关系对应，收款（收款单） 核销 发票（销售单，退款单等）
 select * from cims.intf_ar_writeoff where INTF_STATUS='E' and CANCEL_FLAG='N' and customer_number='';
*//*
      BEGIN
        with ou as
         (select min(nvl(t.entity_id, 0)) as min_entity_id,
                 max(nvl(t.entity_id, 0)) as max_entity_id,
                 count(distinct nvl(t.entity_id, 0)) as cnt_entity_id,
                 t.operating_unit,
                 t.operating_unit_code,
                 t.operating_unit_name
            from t_inv_organization t
           group by t.operating_unit,
                    t.operating_unit_code,
                    t.operating_unit_name),
        m as
         (select rank() over(partition by be.entity_id, ou.operating_unit_name order by wo.trx_id) as rn,
                 be.entity_id,
                 be.entity_name,
                 be.entity_code,
                 cus_ou.customer_code,
                 ou.operating_unit_name as erp_ou_name,
                 wo.receipt_number as so_num,
                 --wo.cm_trx_number || '(' || wo.invoice_trx_number || ')' as so_num
                 A.ACCOUNT_ID,
                 A.ACCOUNT_CODE
            from ou,intf_ar_writeoff   wo,
                 t_customer_ou               cus_ou,
                 v_bd_entity                 be,
                 t_customer_org              co,
                 t_customer_account          a,
                 t_customer_acc_org_relation ar
           where cus_ou.customer_id = wo.customer_id
             and cus_ou.customer_code = wo.customer_number
             
             and to_number(cus_ou.erpou) = wo.org_id
             and 'Active' = cus_ou.active_flag
             
             AND co.entity_id = be.entity_id
             AND a.entity_id = be.entity_id
             AND A.ACCOUNT_ID = AR.ACCOUNT_ID
             --AND A.ACCOUNT_ID = order_cims.ACCOUNT_ID
             AND CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID
             AND CO.ACTIVE_FLAG <> 'Inactive'
             AND 'Y' = A.ACTIVE_FLAG
                --AND ('1' = A.ACCOUNT_STATUS OR '-1' = A.ACCOUNT_STATUS)
             and (P_DEPT_CODE IS NULL OR EXISTS
                  (SELECT 1
                     FROM UP_ORG_UNIT U
                    WHERE U.CODE = P_DEPT_CODE
                      AND U.ENTITY_ID = be.ENTITY_ID))
             AND ((P_CUSTOMER_CODE IS NOT NULL AND
                 wo.customer_number = P_CUSTOMER_CODE) OR
                 (P_CUSTOMER_CODE IS NULL AND
                 wo.customer_id = CO.CUSTOMER_ID))
             and co.sales_center_id =
                 NVL(P_SALES_CENTER_ID, co.sales_center_id)
             and co.sales_center_code =
                 NVL(P_SALES_CENTER_CODE, co.sales_center_code)
             and co.customer_org_id = NVL(P_CUST_ORG_ID, co.customer_org_id)
             and co.SIEBEL_ORG_ID =
                 NVL(P_SIEBEL_CUST_ORG_ID, co.SIEBEL_ORG_ID)
             AND A.ACCOUNT_ID = NVL(P_ACCOUNT_ID, A.ACCOUNT_ID)
             
             and wo.INTF_STATUS in ('N','E') and wo.CANCEL_FLAG='N'
             
             AND (
             (wo.return_date is null and wo.post_date is null)
             OR wo.return_date >= NVL(
             (
             --取打开手工开关的最新时间
    SELECT MAX(S.LAST_UPDATE_DATE) FROM INTF_CUSTOMER_INVALID_HIS S
    WHERE 'Y' = S.PRE_FIELD_01
    AND wo.customer_number = S.CUSTOMER_CODE
             )
             ,(-1+wo.return_date)--不能加1而是减1，因为要确保取不到开关时间时通过，取到时直接比较就可以了
             )
             )
             AND ou.operating_unit = wo.org_id
                     AND be.entity_id =
                         DECODE(ou.min_entity_id,
                                0,
                                decode(ou.max_entity_id,
                                       0,
                                       null,
                                       ou.max_entity_id),
                                ou.min_entity_id)
          --
          ),
        m2 as
         (select m.entity_name,
                 m.erp_ou_name,
                 M.ACCOUNT_ID,
                 M.ACCOUNT_CODE,
                 wm_concat((case
                             when m.rn <= 5 then
                              m.so_num
                             else
                              null
                           end)) as so_nums,
                 count(distinct m.so_num) as so_num_cnt
            from m
           group by m.entity_name,
                    m.erp_ou_name,
                    M.ACCOUNT_ID,
                    M.ACCOUNT_CODE)
        
        select listagg(m2.entity_name || ',' || m2.ACCOUNT_CODE || ',' ||
                        m2.erp_ou_name || '共' || m2.so_num_cnt || '笔，' ||
                        m2.so_nums || (case
                          when m2.so_num_cnt <= 5 then
                           ''
                          else
                           '......'
                        end),
                        chr(10))
               --
                WITHIN GROUP(order by m2.entity_name, m2.erp_ou_name, M2.ACCOUNT_CODE) as msg
          INTO V_MESSAGE3
          from m2;
      EXCEPTION
        WHEN VALUE_ERROR THEN
          V_MESSAGE3 := '查询收款核销发票关系SQL异常' || SQLERRM;
        WHEN OTHERS THEN
          V_MESSAGE3 := '查询收款核销发票关系SQL异常' || SQLERRM;
      END;*/
      /*
      核销关系对应，收款（收款单） 核销 发票（销售单，退款单等）
 select * from cims.intf_ar_writeoff where INTF_STATUS='E' and CANCEL_FLAG='N' and customer_number='';
*/
      /*BEGIN
        with ou as
         (select min(nvl(t.entity_id, 0)) as min_entity_id,
                 max(nvl(t.entity_id, 0)) as max_entity_id,
                 count(distinct nvl(t.entity_id, 0)) as cnt_entity_id,
                 t.operating_unit,
                 t.operating_unit_code,
                 t.operating_unit_name
            from t_inv_organization t
           group by t.operating_unit,
                    t.operating_unit_code,
                    t.operating_unit_name),
        m as
         (select rank() over(partition by be.entity_id, ou.operating_unit_name order by wo.trx_id) as rn,
                 be.entity_id,
                 be.entity_name,
                 be.entity_code,
                 cus_ou.customer_code,
                 ou.operating_unit_name as erp_ou_name,
                 --wo.receipt_number as so_num,
                 wo.cm_trx_number || '(' || wo.invoice_trx_number || ')' as so_num,
                 A.ACCOUNT_ID,
                 A.ACCOUNT_CODE
            from ou,intf_ar_writeoff_inv   wo,
                 t_customer_ou               cus_ou,
                 v_bd_entity                 be,
                 t_customer_org              co,
                 t_customer_account          a,
                 t_customer_acc_org_relation ar
           where cus_ou.customer_id = wo.customer_id
             and cus_ou.customer_code = wo.customer_number
             
             and to_number(cus_ou.erpou) = wo.org_id
             and 'Active' = cus_ou.active_flag
             
             AND co.entity_id = be.entity_id
             AND a.entity_id = be.entity_id
             AND A.ACCOUNT_ID = AR.ACCOUNT_ID
             --AND A.ACCOUNT_ID = order_cims.ACCOUNT_ID
             AND CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID
             AND CO.ACTIVE_FLAG <> 'Inactive'
             AND 'Y' = A.ACTIVE_FLAG
                --AND ('1' = A.ACCOUNT_STATUS OR '-1' = A.ACCOUNT_STATUS)
             and (P_DEPT_CODE IS NULL OR EXISTS
                  (SELECT 1
                     FROM UP_ORG_UNIT U
                    WHERE U.CODE = P_DEPT_CODE
                      AND U.ENTITY_ID = be.ENTITY_ID))
             AND ((P_CUSTOMER_CODE IS NOT NULL AND
                 wo.customer_number = P_CUSTOMER_CODE) OR
                 (P_CUSTOMER_CODE IS NULL AND
                 wo.customer_id = CO.CUSTOMER_ID))
             and co.sales_center_id =
                 NVL(P_SALES_CENTER_ID, co.sales_center_id)
             and co.sales_center_code =
                 NVL(P_SALES_CENTER_CODE, co.sales_center_code)
             and co.customer_org_id = NVL(P_CUST_ORG_ID, co.customer_org_id)
             and co.SIEBEL_ORG_ID =
                 NVL(P_SIEBEL_CUST_ORG_ID, co.SIEBEL_ORG_ID)
             AND A.ACCOUNT_ID = NVL(P_ACCOUNT_ID, A.ACCOUNT_ID)
             
             and wo.INTF_STATUS in ('N','E') and wo.CANCEL_FLAG='N'
             
             AND (
             (wo.return_date is null and wo.post_date is null)
             OR wo.return_date >= NVL(
             (
             --取打开手工开关的最新时间
    SELECT MAX(S.LAST_UPDATE_DATE) FROM INTF_CUSTOMER_INVALID_HIS S
    WHERE 'Y' = S.PRE_FIELD_01
    AND wo.customer_number = S.CUSTOMER_CODE
             )
             ,(-1+wo.return_date)--不能加1而是减1，因为要确保取不到开关时间时通过，取到时直接比较就可以了
             )
             )
             AND ou.operating_unit = wo.org_id
                     AND be.entity_id =
                         DECODE(ou.min_entity_id,
                                0,
                                decode(ou.max_entity_id,
                                       0,
                                       null,
                                       ou.max_entity_id),
                                ou.min_entity_id)
          --
          ),
        m2 as
         (select m.entity_name,
                 m.erp_ou_name,
                 M.ACCOUNT_ID,
                 M.ACCOUNT_CODE,
                 wm_concat((case
                             when m.rn <= 5 then
                              m.so_num
                             else
                              null
                           end)) as so_nums,
                 count(distinct m.so_num) as so_num_cnt
            from m
           group by m.entity_name,
                    m.erp_ou_name,
                    M.ACCOUNT_ID,
                    M.ACCOUNT_CODE)
        
        select listagg(m2.entity_name || ',' || m2.ACCOUNT_CODE || ',' ||
                        m2.erp_ou_name || '共' || m2.so_num_cnt || '笔，' ||
                        m2.so_nums || (case
                          when m2.so_num_cnt <= 5 then
                           ''
                          else
                           '......'
                        end),
                        chr(10))
               --
                WITHIN GROUP(order by m2.entity_name, m2.erp_ou_name, M2.ACCOUNT_CODE) as msg
          INTO V_MESSAGE4
          from m2;
      EXCEPTION
        WHEN VALUE_ERROR THEN
          V_MESSAGE4 := '查询负数发票（折让单，退货单等）核销发票（销售单，退款单等）关系SQL异常' || SQLERRM;
        WHEN OTHERS THEN
          V_MESSAGE4 := '查询负数发票（折让单，退货单等）核销发票（销售单，退款单等）关系SQL异常' || SQLERRM;
      END;*/
    
      IF V_MESSAGE1 IS NULL AND V_MESSAGE2 IS NULL
        AND V_MESSAGE3 IS NULL
        AND V_MESSAGE4 IS NULL THEN
        RETURN NULL;
      ELSE
        /*
           ①  检查余款： 原因：该客户在CIMS中存在可提货金额，无法进行客户失效。
        ② 未结业务：原因：该客户在CIMS中存在未结算完成的销售单，无法进行客户失效
        */
        P_MESSAGE := '';
        IF V_MESSAGE1 IS NOT NULL THEN
          P_MESSAGE := '存在可提货金额、到款余额、折让余额，无法进行失效。额度组如下：';
          P_MESSAGE := P_MESSAGE || chr(10);
          P_MESSAGE := P_MESSAGE || V_MESSAGE1;
        END IF;
        IF V_MESSAGE2 IS NOT NULL THEN
          IF P_MESSAGE IS NOT NULL THEN
            P_MESSAGE := P_MESSAGE || chr(10);
          END IF;
          P_MESSAGE := P_MESSAGE || '存在未结算完成的销售单，无法进行失效。';
          P_MESSAGE := P_MESSAGE || chr(10);
          P_MESSAGE := P_MESSAGE || V_MESSAGE2;
        END IF;
        IF V_MESSAGE3 IS NOT NULL THEN
          IF P_MESSAGE IS NOT NULL THEN
            P_MESSAGE := P_MESSAGE || chr(10);
          END IF;
          P_MESSAGE := P_MESSAGE || '存在异常收款核销发票关系，无法进行失效。';
          P_MESSAGE := P_MESSAGE || chr(10);
          P_MESSAGE := P_MESSAGE || V_MESSAGE3;
        END IF;
        IF V_MESSAGE4 IS NOT NULL THEN
          IF P_MESSAGE IS NOT NULL THEN
            P_MESSAGE := P_MESSAGE || chr(10);
          END IF;
          P_MESSAGE := P_MESSAGE || '存在异常负数发票（折让单，退货单等）核销发票（销售单，退款单等）关系，无法进行失效。';
          P_MESSAGE := P_MESSAGE || chr(10);
          P_MESSAGE := P_MESSAGE || V_MESSAGE4;
        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN '客户中心失效校验数据库层异常：' || SQLERRM;
    END;
    RETURN P_MESSAGE;
  END F_CUSTORG_CHECK_CANVALID;

  FUNCTION F_CUSTORG_CHECK_UNDO(P_CUSTOMER_CODE      in varchar2, --客户编码
                                P_DEPT_CODE          in varchar2, --事业部编码
                                P_SALES_CENTER_ID    in number, --中心ID
                                P_SALES_CENTER_CODE  in varchar2, --中心编码
                                P_CUST_ORG_ID        in number, --客户中心关系ID
                                P_SIEBEL_CUST_ORG_ID in varchar2, --客户中心关系主数据ID
                                P_ACCOUNT_ID         in number, --账户ID
                                IN_INTF_OR_BUSI      IN NUMBER DEFAULT NULL,
                                --1或空非系统初始化账户 2系统初始化 3不区分
                                IN_AMOUNT_NOCHK IN NUMBER DEFAULT NULL
                                --1不检查余额
                                ) return VARCHAR2 IS
    V_MESSAGE1 VARCHAR2(4000);
    P_MESSAGE  VARCHAR2(4000);
    V_CNT      NUMBER;
    V_CNT1     NUMBER;
    V_CNT2     NUMBER;
  BEGIN
    IF (P_CUSTOMER_CODE IS NULL AND P_DEPT_CODE IS NULL AND
       P_CUST_ORG_ID IS NULL AND P_SIEBEL_CUST_ORG_ID IS NULL) THEN
      RETURN '客户编码参数为空，事业部编码、客户中心关系ID和客户中心关系主数据ID不能为空';
    END IF;
    P_MESSAGE := NULL;
    /*
       ①  检查余款：检查客户是否存在可提货金额（不为零）。如果有，则反馈不能失效，
       原因：该客户在CIMS中存在可提货金额，无法进行客户失效。
    */
    --可提货金额：到款金额-销售金额+铺底额度+临时额度-锁定到款金额 
    --折让金额-核销折让金额+冻结扣率折让金额-锁定扣率折让金额
    BEGIN
      BEGIN
        SELECT COUNT(DECODE((SELECT COUNT(0)
                  FROM T_CREDIT_GROUP CG, T_SALES_ACCOUNT_AMOUNT T --T_SALES_ACCOUNT_MX_AMOUNT
                 WHERE T.ENTITY_ID = BE.ENTITY_ID
                   AND T.CREDIT_GROUP_ID = CG.CREDIT_GROUP_ID
                   AND A.ACCOUNT_ID = T.ACCOUNT_ID),0,0,NULL)),
               NVL(MAX((SELECT COUNT(0)
                         FROM T_CUSTOMER_ORG O
                        WHERE O.ENTITY_ID = CO.ENTITY_ID
                          AND O.CUSTOMER_ID = CO.CUSTOMER_ID
                          AND 'Inactive' <> O.ACTIVE_FLAG
                          AND O.SALES_CENTER_ID <> CO.SALES_CENTER_ID)),
                   0),
               COUNT(PKG_CUSTOMER_PUB.F_CHECK_CUST_H_UNDO_SHIP(BE.ENTITY_ID,
                                                               NULL,
                                                               A.ACCOUNT_CODE))
          INTO V_CNT, V_CNT1, V_CNT2
          FROM V_BD_ENTITY                 BE,
               T_CUSTOMER_ORG              CO,
               T_CUSTOMER_ACCOUNT          A,
               T_CUSTOMER_ACC_ORG_RELATION AR
         WHERE CO.ENTITY_ID = BE.ENTITY_ID
           AND A.ENTITY_ID = BE.ENTITY_ID
           AND A.ACCOUNT_ID = AR.ACCOUNT_ID
           AND CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID
           AND CO.ACTIVE_FLAG <> 'Inactive'
           AND (3 = IN_INTF_OR_BUSI OR
               (2 = IN_INTF_OR_BUSI AND
               ('INTF' = NVL(A.CREATED_BY, 'INTF') AND
               'INTF' = NVL(A.LAST_UPDATE_BY, 'INTF')
               --
               )) OR (1 = NVL(IN_INTF_OR_BUSI, 1) AND
               NOT ('INTF' = NVL(A.CREATED_BY, 'INTF') AND
                'INTF' = NVL(A.LAST_UPDATE_BY, 'INTF'))
               --
               ))
           AND 'Y' = A.ACTIVE_FLAG
              --AND ('1' = A.ACCOUNT_STATUS OR '-1' = A.ACCOUNT_STATUS)
           AND (P_DEPT_CODE IS NULL OR EXISTS
                (SELECT 1
                   FROM UP_ORG_UNIT U
                  WHERE U.CODE = P_DEPT_CODE
                    AND U.ENTITY_ID = BE.ENTITY_ID))
           AND ((P_CUSTOMER_CODE IS NOT NULL AND
               CO.CUSTOMER_CODE = P_CUSTOMER_CODE) OR
               (P_CUSTOMER_CODE IS NULL AND A.CUSTOMER_ID = CO.CUSTOMER_ID))
           AND CO.SALES_CENTER_ID =
               NVL(P_SALES_CENTER_ID, CO.SALES_CENTER_ID)
           AND CO.SALES_CENTER_CODE =
               NVL(P_SALES_CENTER_CODE, CO.SALES_CENTER_CODE)
           AND CO.CUSTOMER_ORG_ID = NVL(P_CUST_ORG_ID, CO.CUSTOMER_ORG_ID)
           AND CO.SIEBEL_ORG_ID =
               NVL(P_SIEBEL_CUST_ORG_ID, CO.SIEBEL_ORG_ID)
           AND A.ACCOUNT_ID = NVL(P_ACCOUNT_ID, A.ACCOUNT_ID);
        IF 0 < V_CNT2 THEN
          RETURN '中心所挂账户存在未完成的发货计划或者发货通知单，不能失效';
        END IF;
        IF 0 < V_CNT AND 1 <> NVL(IN_AMOUNT_NOCHK,0) THEN
          RETURN '中心所在账户未初始化任何客户款项，不允许直接将中心失效（可在CIMS将账户失效' ||(CASE WHEN
                                                              0 < V_CNT1 THEN '' ELSE
                                                              '、或在CRM将事业部或客户失效' END) || '）';
        END IF;
        IF 1 = IN_AMOUNT_NOCHK THEN
          RETURN NULL;
        END IF;
        WITH m AS
         (select be.entity_id,
                 be.entity_name,
                 be.entity_code,
                 t.credit_group_id,
                 cg.credit_group_name,
                 A.ACCOUNT_ID,
                 A.ACCOUNT_CODE,
                 sum(t.received_amount - t.sales_amount + t.delaypay_amount +
                     t.temp_delaypay_amount - t.lock_received_amount +
                     t.discount_amount + t.freeze_discount_amount -
                     t.lock_discount_amount - t.applied_discount_amount) as delivery_amount,
                 sum(t.received_amount - t.sales_amount) as account_balance,
                 sum(t.discount_amount - t.applied_discount_amount) as allowance_balance
            from t_sales_account_amount      t,
                 v_bd_entity                 be,
                 t_credit_group              cg,
                 t_customer_org              co,
                 t_customer_account          a,
                 t_customer_acc_org_relation ar
           where t.entity_id = be.entity_id
             AND co.entity_id = be.entity_id
             AND a.entity_id = be.entity_id
             and t.credit_group_id = cg.credit_group_id
             AND A.ACCOUNT_ID = AR.ACCOUNT_ID
             AND A.ACCOUNT_ID = T.ACCOUNT_ID
             AND CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID
             AND CO.ACTIVE_FLAG <> 'Inactive'
             AND (3 = IN_INTF_OR_BUSI OR
                 (2 = IN_INTF_OR_BUSI AND
                 ('INTF' = NVL(UPPER(A.CREATED_BY), 'INTF') AND
                  'INTF' = NVL(UPPER(A.LAST_UPDATE_BY), 'INTF')
                  --
                  )) OR (1 = NVL(IN_INTF_OR_BUSI, 1) AND
                  NOT(
                 'INTF' = NVL(UPPER(A.CREATED_BY), 'INTF') AND
                 'INTF' = NVL(UPPER(A.LAST_UPDATE_BY), 'INTF'))
                 --
                 ))
             AND 'Y' = A.ACTIVE_FLAG
                --AND ('1' = A.ACCOUNT_STATUS OR '-1' = A.ACCOUNT_STATUS)
             and (P_DEPT_CODE IS NULL OR EXISTS
                  (SELECT 1
                     FROM UP_ORG_UNIT U
                    WHERE U.CODE = P_DEPT_CODE
                      AND U.ENTITY_ID = be.ENTITY_ID))
             AND ((P_CUSTOMER_CODE IS NOT NULL AND
                 T.CUSTOMER_CODE = P_CUSTOMER_CODE) OR
                 (P_CUSTOMER_CODE IS NULL AND
                 T.CUSTOMER_ID = CO.CUSTOMER_ID))
             and co.sales_center_id =
                 NVL(P_SALES_CENTER_ID, co.sales_center_id)
             and co.sales_center_code =
                 NVL(P_SALES_CENTER_CODE, co.sales_center_code)
             and co.customer_org_id = NVL(P_CUST_ORG_ID, co.customer_org_id)
             and co.SIEBEL_ORG_ID =
                 NVL(P_SIEBEL_CUST_ORG_ID, co.SIEBEL_ORG_ID)
             and A.ACCOUNT_ID = NVL(P_ACCOUNT_ID, A.ACCOUNT_ID)
           group by be.entity_id,
                    be.entity_name,
                    be.entity_code,
                    t.credit_group_id,
                    cg.credit_group_name,
                    A.ACCOUNT_ID,
                    A.ACCOUNT_CODE
          having 0 <> sum(t.received_amount - t.sales_amount + t.delaypay_amount
          --
          +t.temp_delaypay_amount - t.lock_received_amount + t.discount_amount
          --
          +t.freeze_discount_amount - t.lock_discount_amount - t.applied_discount_amount) OR 0 <> sum(t.received_amount - t.sales_amount) OR 0 <> sum(t.discount_amount - t.applied_discount_amount)
          --
          ),
        m2 as
         (select m.entity_name,
                 listagg(M.ACCOUNT_CODE || '_' || m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id, M.ACCOUNT_ID) as credit_group_name,
                 '可提货金额' as amount_name,
                 listagg(m.delivery_amount, ',') WITHIN GROUP(order by m.credit_group_id, M.ACCOUNT_ID) as delivery_amount
            from m
           where 0 <> m.delivery_amount
           group by m.entity_name
          union all
          select m.entity_name,
                 listagg(M.ACCOUNT_CODE || '_' || m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id, M.ACCOUNT_ID) as credit_group_name,
                 '到款余额' as amount_name,
                 listagg(m.account_balance, ',') WITHIN GROUP(order by m.credit_group_id) as delivery_amount
            from m
           where 0 = m.delivery_amount
             and 0 <> m.account_balance
           group by m.entity_name
          union all
          select m.entity_name,
                 listagg(M.ACCOUNT_CODE || '_' || m.credit_group_name, ',') WITHIN GROUP(order by m.credit_group_id, M.ACCOUNT_ID) as credit_group_name,
                 '折让余额' as amount_name,
                 listagg(m.allowance_balance, ',') WITHIN GROUP(order by m.credit_group_id) as delivery_amount
            from m
           where 0 = m.delivery_amount
             and 0 = m.account_balance
             and 0 <> m.allowance_balance
           group by m.entity_name)
        select listagg(m2.entity_name || ',账户_额度组:' || m2.credit_group_name || ',' ||
                        m2.amount_name || ':' || m2.delivery_amount,
                        chr(10))
               --
                WITHIN GROUP(order by m2.entity_name, m2.amount_name)
          INTO V_MESSAGE1
          from m2 -- where 10 >= rownum
        ;
      EXCEPTION
        WHEN VALUE_ERROR THEN
          V_MESSAGE1 := '查询可提货金额SQL异常' || SQLERRM;
        WHEN OTHERS THEN
          V_MESSAGE1 := '查询可提货金额SQL异常' || SQLERRM;
      END;
    
      IF V_MESSAGE1 IS NOT NULL THEN
        P_MESSAGE := '';
        P_MESSAGE := '存在可提货金额、到款余额、折让余额，无法进行失效。额度组如下：';
        P_MESSAGE := P_MESSAGE || chr(10);
        P_MESSAGE := P_MESSAGE || V_MESSAGE1;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN '客户中心失效校验数据库层异常：' || SQLERRM;
    END;
    RETURN P_MESSAGE;
  END F_CUSTORG_CHECK_UNDO;

  FUNCTION F_INSERT_OR_UPDATE_HEADER
  --更新或插入客户头业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2 IS
    V_INTF_HEADER        INTF_CUSTOMER_HEADER%ROWTYPE;
    V_CUST_HEADER_ID     NUMBER; --客户头ID
    V_CUST_HEADER_STATUS VARCHAR2(30); --客户头状态
    V_MESSAGE            VARCHAR2(1000);
  BEGIN
    SELECT H.*
      INTO V_INTF_HEADER
      FROM INTF_CUSTOMER_HEADER H
     WHERE CUSTOMER_ID = P_INTF_HEAD_ID;
    PRC_INSERT_OR_UPDATE_HEADER(V_INTF_HEADER,
                                V_CUST_HEADER_ID,
                                V_CUST_HEADER_STATUS,
                                V_CUST_HEADER_ID,
                                V_MESSAGE);
    RETURN V_MESSAGE;
  END F_INSERT_OR_UPDATE_HEADER;

  PROCEDURE PRC_INSERT_OR_UPDATE_HEADER
  --更新或插入客户头业务表
  (P_INTF_HEADER        IN INTF_CUSTOMER_HEADER%ROWTYPE, --客户头
   P_CUST_HEADER_ID     OUT NUMBER, --客户头ID
   P_CUST_HEADER_STATUS OUT VARCHAR2, --客户头状态
   P_HEADER_ID          OUT NUMBER, --客户头ID
   P_MESSAGE            OUT VARCHAR2) IS
   V_CNT                NUMBER;
   V_ERR_MSG            INTF_CUSTOMER_HEADER.RESPONSEMESSAGE%TYPE;
  BEGIN
    --查看主数据客户头ID是否存在
    SELECT H.CUSTOMER_ID, H.CUSTOMER_STATUS
      INTO P_CUST_HEADER_ID, P_CUST_HEADER_STATUS
      FROM T_CUSTOMER_HEADER H
     RIGHT JOIN INTF_CUSTOMER_HEADER IH
        ON (H.SIEBEL_CUSTOMER_ID = IH.SIEBEL_CUSTOMER_ID)
     WHERE IH.CUSTOMER_ID = P_INTF_HEADER.CUSTOMER_ID;

    /*SELECT COUNT(0)
      INTO V_CNT
      FROM INTF_CUSTOMER_DEPT ID
     WHERE ID.SIEBEL_CUSTOMER_ID = P_INTF_HEADER.SIEBEL_CUSTOMER_ID
       AND ID.TRANSCODE = P_INTF_HEADER.TRANSCODE
       AND EXISTS
     (SELECT 1 FROM UP_ORG_UNIT U WHERE U.CODE = ID.DEPT_CODE)
    ;
    IF 0 = V_CNT THEN
      P_MESSAGE := '本次没有推送事业部的数据';
      RETURN ;
    END IF;*/
    
    P_HEADER_ID := P_CUST_HEADER_ID;
    --如果不存在，则插入
    IF (P_CUST_HEADER_ID IS NULL) THEN
      SELECT S_CUSTOMER_HEADER.NEXTVAL INTO P_HEADER_ID FROM DUAL;
      INSERT INTO T_CUSTOMER_HEADER
        (CUSTOMER_ID,
         CUSTOMER_CODE,
         CUSTOMER_NAME,
         CUSTOMER_SHORT_NAME,
         CUSTOMER_PHONES,
         CUSTOMER_FAX,
         CUSTOMER_MAIL,
         CUSTOMER_POSTAL_CODE,
         CUSTOMER_REGIST_ADDRESS,
         CUSTOMER_BUSINESS_LICENSE,
         CUSTOMER_ORGANIZATION_CODE,
         CUSTOMER_REGISTRATION_CODE,
         CUSTOMER_ENTERPRISE_NATURE,
         CUSTOMER_REGISTERED_FUNDS,
         CUSTOMER_REGISTRATION,
         CUSTOMER_LEGAL_PERSON,
         CUSTOMER_REGISTRATION_TYPE,
         CUSTOMER_FOUNDED_DATE,
         CUSTOMER_STATUS,
         CUSTOMER_COMMENTS,
         CUSTOMER_IS_TOP,
         CUSTOMER_IS_VENDOR,
         CUSTOMER_VENDOR_CODE,
         CUSTOMER_IS_INTERNAL,
         CUSTOMER_IS_AFTERSALES,
         CUSTOMER_PROP_COUNT,
         CUSTOMER_REGIST_COUNTRY,
         CUSTOMER_REGIST_PROVINCE,
         CUSTOMER_REGIST_CITY,
         CUSTOMER_REGIST_AREA,
         CUSTOMER_REGIST_TOWNS,
         CUSTOMER_REGADDRESS_COMMENTS,
         CUSTOMER_URL,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATE_DATE,
         LAST_UPDATE_BY,
         LAST_INTERFACE_DATE,
         CUSTOMER_SYSTEM_NAME,
         CUSTOMER_FATHER_CODE,
         CUSTOMER_MANAGER,
         CUSTOMER_MANAGER_PHONES,
         CUSTOMER_OFFICE_ADDRESS,
         SIEBEL_CUSTOMER_ID,
         IS_VIRTUAL_CUSTOMER,
         ACTIVE_FLAG,
         PRE_FIELD_01,
         PRE_FIELD_02,
         PRE_FIELD_03,
         PRE_FIELD_04,
         PRE_FIELD_05,
         PRE_FIELD_06,
         CUSTOMER_USCC)
        SELECT P_HEADER_ID,
               P_INTF_HEADER.CUSTOMER_CODE,
               P_INTF_HEADER.CUSTOMER_NAME,
               P_INTF_HEADER.CUSTOMER_SHORT_NAME,
               P_INTF_HEADER.CUSTOMER_PHONES,
               P_INTF_HEADER.CUSTOMER_FAX,
               P_INTF_HEADER.CUSTOMER_MAIL,
               P_INTF_HEADER.CUSTOMER_POSTAL_CODE,
               P_INTF_HEADER.CUSTOMER_REGIST_ADDRESS,
               P_INTF_HEADER.CUSTOMER_BUSINESS_LICENSE,
               P_INTF_HEADER.CUSTOMER_ORGANIZATION_CODE,
               P_INTF_HEADER.CUSTOMER_REGISTRATION_CODE,
               P_INTF_HEADER.CUSTOMER_ENTERPRISE_NATURE,
               P_INTF_HEADER.CUSTOMER_REGISTERED_FUNDS,
               P_INTF_HEADER.CUSTOMER_REGISTRATION,
               P_INTF_HEADER.CUSTOMER_LEGAL_PERSON,
               P_INTF_HEADER.CUSTOMER_REGISTRATION_TYPE,
               P_INTF_HEADER.CUSTOMER_FOUNDED_DATE,
               P_INTF_HEADER.CUSTOMER_STATUS,
               P_INTF_HEADER.CUSTOMER_COMMENTS,
               P_INTF_HEADER.CUSTOMER_IS_TOP,
               P_INTF_HEADER.CUSTOMER_IS_VENDOR,
               P_INTF_HEADER.CUSTOMER_VENDOR_CODE,
               P_INTF_HEADER.CUSTOMER_IS_INTERNAL,
               P_INTF_HEADER.CUSTOMER_IS_AFTERSALES,
               P_INTF_HEADER.CUSTOMER_PROP_COUNT,
               P_INTF_HEADER.CUSTOMER_REGIST_COUNTRY,
               P_INTF_HEADER.CUSTOMER_REGIST_PROVINCE,
               P_INTF_HEADER.CUSTOMER_REGIST_CITY,
               P_INTF_HEADER.CUSTOMER_REGIST_AREA,
               P_INTF_HEADER.CUSTOMER_REGIST_TOWNS,
               P_INTF_HEADER.CUSTOMER_REGADDRESS_COMMENTS,
               P_INTF_HEADER.CUSTOMER_URL,
               P_INTF_HEADER.CREATED_BY,
               P_INTF_HEADER.CREATION_DATE,
               P_INTF_HEADER.LAST_UPDATE_DATE,
               P_INTF_HEADER.LAST_UPDATE_BY,
               P_INTF_HEADER.LAST_INTERFACE_DATE,
               P_INTF_HEADER.CUSTOMER_SYSTEM_NAME,
               P_INTF_HEADER.CUSTOMER_FATHER_CODE,
               P_INTF_HEADER.CUSTOMER_MANAGER,
               P_INTF_HEADER.CUSTOMER_MANAGER_PHONES,
               P_INTF_HEADER.CUSTOMER_OFFICE_ADDRESS,
               P_INTF_HEADER.SIEBEL_CUSTOMER_ID,
               P_INTF_HEADER.IS_VIRTUAL_CUSTOMER,
               P_INTF_HEADER.ACTIVE_FLAG,
               P_INTF_HEADER.PRE_FIELD_01,
               P_INTF_HEADER.CUSTOMER_ID,
               P_INTF_HEADER.PRE_FIELD_03,
               P_INTF_HEADER.PRE_FIELD_04,
               P_INTF_HEADER.PRE_FIELD_05,
               P_INTF_HEADER.PRE_FIELD_06,
               P_INTF_HEADER.CUSTOMER_USCC
          FROM DUAL;
      --COMMIT;
    ELSE
      --若存在，则更新
      UPDATE T_CUSTOMER_HEADER HEAD
         SET (HEAD.CUSTOMER_CODE,
              HEAD.CUSTOMER_NAME,
              HEAD.CUSTOMER_SHORT_NAME,
              HEAD.CUSTOMER_PHONES,
              HEAD.CUSTOMER_FAX,
              HEAD.CUSTOMER_MAIL,
              HEAD.CUSTOMER_POSTAL_CODE,
              HEAD.CUSTOMER_REGIST_ADDRESS,
              HEAD.CUSTOMER_BUSINESS_LICENSE,
              HEAD.CUSTOMER_ORGANIZATION_CODE,
              HEAD.CUSTOMER_REGISTRATION_CODE,
              HEAD.CUSTOMER_ENTERPRISE_NATURE,
              HEAD.CUSTOMER_REGISTERED_FUNDS,
              HEAD.CUSTOMER_REGISTRATION,
              HEAD.CUSTOMER_LEGAL_PERSON,
              HEAD.CUSTOMER_REGISTRATION_TYPE,
              HEAD.CUSTOMER_FOUNDED_DATE,
              HEAD.CUSTOMER_STATUS,
              HEAD.CUSTOMER_COMMENTS,
              HEAD.CUSTOMER_IS_TOP,
              HEAD.CUSTOMER_IS_VENDOR,
              HEAD.CUSTOMER_VENDOR_CODE,
              HEAD.CUSTOMER_IS_INTERNAL,
              HEAD.CUSTOMER_IS_AFTERSALES,
              HEAD.CUSTOMER_PROP_COUNT,
              HEAD.CUSTOMER_REGIST_COUNTRY,
              HEAD.CUSTOMER_REGIST_PROVINCE,
              HEAD.CUSTOMER_REGIST_CITY,
              HEAD.CUSTOMER_REGIST_AREA,
              HEAD.CUSTOMER_REGIST_TOWNS,
              HEAD.CUSTOMER_REGADDRESS_COMMENTS,
              HEAD.CUSTOMER_URL,
              HEAD.CREATED_BY,
              HEAD.CREATION_DATE,
              HEAD.LAST_UPDATE_DATE,
              HEAD.LAST_UPDATE_BY,
              HEAD.LAST_INTERFACE_DATE,
              HEAD.CUSTOMER_SYSTEM_NAME,
              HEAD.CUSTOMER_FATHER_CODE,
              HEAD.CUSTOMER_MANAGER,
              HEAD.CUSTOMER_MANAGER_PHONES,
              HEAD.CUSTOMER_OFFICE_ADDRESS,
              HEAD.SIEBEL_CUSTOMER_ID,
              HEAD.IS_VIRTUAL_CUSTOMER,
              HEAD.ACTIVE_FLAG,
              HEAD.PRE_FIELD_01,
              HEAD.PRE_FIELD_02,
              HEAD.PRE_FIELD_03,
              HEAD.PRE_FIELD_04,
              HEAD.PRE_FIELD_05,
              HEAD.PRE_FIELD_06,
              HEAD.CUSTOMER_USCC) =
             (SELECT P_INTF_HEADER.CUSTOMER_CODE,
                     P_INTF_HEADER.CUSTOMER_NAME,
                     P_INTF_HEADER.CUSTOMER_SHORT_NAME,
                     P_INTF_HEADER.CUSTOMER_PHONES,
                     P_INTF_HEADER.CUSTOMER_FAX,
                     P_INTF_HEADER.CUSTOMER_MAIL,
                     P_INTF_HEADER.CUSTOMER_POSTAL_CODE,
                     P_INTF_HEADER.CUSTOMER_REGIST_ADDRESS,
                     P_INTF_HEADER.CUSTOMER_BUSINESS_LICENSE,
                     P_INTF_HEADER.CUSTOMER_ORGANIZATION_CODE,
                     P_INTF_HEADER.CUSTOMER_REGISTRATION_CODE,
                     P_INTF_HEADER.CUSTOMER_ENTERPRISE_NATURE,
                     P_INTF_HEADER.CUSTOMER_REGISTERED_FUNDS,
                     P_INTF_HEADER.CUSTOMER_REGISTRATION,
                     P_INTF_HEADER.CUSTOMER_LEGAL_PERSON,
                     P_INTF_HEADER.CUSTOMER_REGISTRATION_TYPE,
                     P_INTF_HEADER.CUSTOMER_FOUNDED_DATE,
                     P_INTF_HEADER.CUSTOMER_STATUS,
                     P_INTF_HEADER.CUSTOMER_COMMENTS,
                     P_INTF_HEADER.CUSTOMER_IS_TOP,
                     P_INTF_HEADER.CUSTOMER_IS_VENDOR,
                     P_INTF_HEADER.CUSTOMER_VENDOR_CODE,
                     P_INTF_HEADER.CUSTOMER_IS_INTERNAL,
                     P_INTF_HEADER.CUSTOMER_IS_AFTERSALES,
                     P_INTF_HEADER.CUSTOMER_PROP_COUNT,
                     P_INTF_HEADER.CUSTOMER_REGIST_COUNTRY,
                     P_INTF_HEADER.CUSTOMER_REGIST_PROVINCE,
                     P_INTF_HEADER.CUSTOMER_REGIST_CITY,
                     P_INTF_HEADER.CUSTOMER_REGIST_AREA,
                     P_INTF_HEADER.CUSTOMER_REGIST_TOWNS,
                     P_INTF_HEADER.CUSTOMER_REGADDRESS_COMMENTS,
                     P_INTF_HEADER.CUSTOMER_URL,
                     P_INTF_HEADER.CREATED_BY,
                     P_INTF_HEADER.CREATION_DATE,
                     P_INTF_HEADER.LAST_UPDATE_DATE,
                     P_INTF_HEADER.LAST_UPDATE_BY,
                     P_INTF_HEADER.LAST_INTERFACE_DATE,
                     P_INTF_HEADER.CUSTOMER_SYSTEM_NAME,
                     P_INTF_HEADER.CUSTOMER_FATHER_CODE,
                     P_INTF_HEADER.CUSTOMER_MANAGER,
                     P_INTF_HEADER.CUSTOMER_MANAGER_PHONES,
                     P_INTF_HEADER.CUSTOMER_OFFICE_ADDRESS,
                     P_INTF_HEADER.SIEBEL_CUSTOMER_ID,
                     P_INTF_HEADER.IS_VIRTUAL_CUSTOMER,
                     P_INTF_HEADER.ACTIVE_FLAG,
                     P_INTF_HEADER.PRE_FIELD_01,
                     P_INTF_HEADER.CUSTOMER_ID,
                     P_INTF_HEADER.PRE_FIELD_03,
                     P_INTF_HEADER.PRE_FIELD_04,
                     P_INTF_HEADER.PRE_FIELD_05,
                     P_INTF_HEADER.PRE_FIELD_06,
                     P_INTF_HEADER.CUSTOMER_USCC
                FROM DUAL)
       WHERE CUSTOMER_ID = P_CUST_HEADER_ID;
      --COMMIT;
    END IF;
    
    --更新客户组织信息中关联客户的ID及名称
    UPDATE T_CUSTOMER_ORG UO
       SET (UO.ORG_CUSTOMER_FATHER_ID, UO.ORG_CUSTOMER_FATHER_NAME) =
           (SELECT H.CUSTOMER_ID, H.CUSTOMER_NAME
              FROM T_CUSTOMER_HEADER H
             WHERE H.CUSTOMER_CODE = UO.ORG_CUSTOMER_FATHER_CODE
               AND 1 = ROWNUM)
     WHERE UO.ORG_CUSTOMER_FATHER_CODE = P_INTF_HEADER.CUSTOMER_CODE
       AND (P_CUST_HEADER_ID IS NULL OR 0 >= UO.ORG_CUSTOMER_FATHER_ID OR
           P_CUST_HEADER_ID = UO.ORG_CUSTOMER_FATHER_ID)
       AND EXISTS (SELECT 1
              FROM T_CUSTOMER_HEADER H
             WHERE H.CUSTOMER_CODE = UO.ORG_CUSTOMER_FATHER_CODE);
    
    IF P_INTF_HEADER.ACTIVE_FLAG NOT IN ('Inactive','Delete') THEN
      SELECT COUNT(0)
        INTO V_CNT
        FROM UP_CODELIST C
       WHERE C.CODETYPE = 'temp_all_free' --临时自由码表
         AND C.CODE_VALUE = '临时主体无关'
         AND C.CODE_NAME = '临时主体无关'
         AND C.ENTITY_FLAG = 'N'
         AND C.ENABLED = '0';
      IF 0 = V_CNT THEN
        SELECT COUNT(0)
          INTO V_CNT
          FROM DUAL
         WHERE NOT EXISTS (SELECT 1
                  FROM T_CUSTOMER_HEADER H
                 INNER JOIN T_CUSTOMER_OU OU
                    ON (OU.CUSTOMER_CODE = H.CUSTOMER_CODE
                       AND H.SIEBEL_CUSTOMER_ID = P_INTF_HEADER.SIEBEL_CUSTOMER_ID
                       AND OU.ACTIVE_FLAG = P_INTF_HEADER.ACTIVE_FLAG
                       /* AND EXISTS (SELECT 1
                                        FROM T_INV_ORGANIZATION IO
                                       WHERE IO.ENTITY_ID IS NOT NULL
                                         AND IO.OPERATING_UNIT = OU.ERPOU)*/
                       AND EXISTS (SELECT 1
                                     FROM V_UP_CODELIST CL
                                    WHERE CL.CODETYPE = 'ar_ou_id'
                                      AND CL.ENTITY_ID IS NOT NULL
                                      AND CL.CODE_VALUE = OU.ERPOU) --modify by liangym2 2017-6-14
                       ))
           AND NOT EXISTS (SELECT 1
                  FROM INTF_CUSTOMER_OU OU
                 WHERE OU.CUSTOMER_CODE = P_INTF_HEADER.CUSTOMER_CODE
                   AND OU.TRANSCODE = P_INTF_HEADER.TRANSCODE
                   AND OU.ACTIVE_FLAG = P_INTF_HEADER.ACTIVE_FLAG
                   /* AND EXISTS (SELECT 1
                                    FROM T_INV_ORGANIZATION IO
                                   WHERE IO.ENTITY_ID IS NOT NULL
                                     AND IO.OPERATING_UNIT = OU.ERPOU)*/
                   AND EXISTS (SELECT 1
                          FROM V_UP_CODELIST CL
                         WHERE CL.CODETYPE = 'ar_ou_id'
                           AND CL.ENTITY_ID IS NOT NULL
                           AND CL.CODE_VALUE = OU.ERPOU) --modify by liangym2 2017-6-14
                )
           AND (EXISTS (SELECT 1
                   FROM T_CUSTOMER_DEPT CD
                  WHERE CD.SIEBEL_CUSTOMER_ID = P_INTF_HEADER.SIEBEL_CUSTOMER_ID
                    AND CD.ACTIVE_FLAG NOT IN ('Inactive', 'Delete')
                    AND CD.DEPT_ID IS NOT NULL
                    AND NOT EXISTS (SELECT 1
                           FROM INTF_CUSTOMER_DEPT ICD
                          WHERE ICD.SIEBEL_ID = CD.SIEBEL_ID
                            AND ICD.TRANSCODE = P_INTF_HEADER.TRANSCODE
                            AND ICD.ACTIVE_FLAG IN ('Inactive', 'Delete')))
                OR EXISTS (SELECT 1
                   FROM INTF_CUSTOMER_DEPT ICD
                  WHERE ICD.SIEBEL_CUSTOMER_ID = P_INTF_HEADER.SIEBEL_CUSTOMER_ID
                    AND ICD.ACTIVE_FLAG NOT IN ('Inactive', 'Delete')
                    AND ICD.TRANSCODE = P_INTF_HEADER.TRANSCODE
                    AND EXISTS (SELECT 1
                           FROM UP_ORG_UNIT U
                          WHERE U.CODE = ICD.DEPT_CODE
                            AND U.ENTITY_ID IS NOT NULL)))
           --推送数据不存在非有效、非冻结，或者压根不推送事业部
           AND (NOT EXISTS (SELECT 1
                   FROM INTF_CUSTOMER_DEPT ICD
                  WHERE ICD.SIEBEL_CUSTOMER_ID = P_INTF_HEADER.SIEBEL_CUSTOMER_ID
                    AND ICD.ACTIVE_FLAG NOT IN ('Active', 'Freezing')
                    AND ICD.TRANSCODE = P_INTF_HEADER.TRANSCODE
                    AND EXISTS (SELECT 1
                           FROM UP_ORG_UNIT U
                          WHERE U.CODE = ICD.DEPT_CODE
                            AND U.ENTITY_ID IS NOT NULL))
                --不推送事业部，前面条件成立，还有判断正式表不存在非有效、非冻结
                AND NOT EXISTS (SELECT 1
                   FROM T_CUSTOMER_DEPT CD
                  WHERE CD.SIEBEL_CUSTOMER_ID = P_INTF_HEADER.SIEBEL_CUSTOMER_ID
                    AND CD.ACTIVE_FLAG NOT IN ('Active', 'Freezing')
                    AND CD.DEPT_ID IS NOT NULL
                    AND NOT EXISTS (SELECT 1
                           FROM INTF_CUSTOMER_DEPT ICD
                          WHERE ICD.SIEBEL_ID = CD.SIEBEL_ID
                            AND ICD.TRANSCODE = P_INTF_HEADER.TRANSCODE
                            AND ICD.ACTIVE_FLAG IN ('Active', 'Freezing'))))
         /*AND EXISTS (SELECT 1
                               FROM T_CUSTOMER_HEADER H
                              INNER JOIN T_SALES_ACCOUNT_MX_AMOUNT MX
                                 ON (H.CUSTOMER_ID = MX.CUSTOMER_ID AND
                                    H.SIEBEL_CUSTOMER_ID = P_INTF_HEADER.SIEBEL_CUSTOMER_ID)
                              WHERE MX.ENTITY_ID IS NOT NULL)*/
        ;
        IF 0 < V_CNT THEN
          P_MESSAGE := P_INTF_HEADER.CUSTOMER_CODE || '，客户头没有推送（包括历史）有效的OU;';
          UPDATE T_CUSTOMER_DEPT D
             SET D.DEPT_CUSTOMER_STATUS = 'Inactive'
                ,D.LAST_UPDATE_BY       = P_INTF_HEADER.LAST_UPDATE_BY
                ,D.LAST_UPDATE_DATE     = P_INTF_HEADER.LAST_INTERFACE_DATE
                ,D.LAST_INTERFACE_DATE  = P_INTF_HEADER.LAST_INTERFACE_DATE
           WHERE D.SIEBEL_CUSTOMER_ID = P_INTF_HEADER.SIEBEL_CUSTOMER_ID;
          
          BEGIN
            P_CUSTOMER_INTF_PROC(P_INTF_HEADER_ID_LIST => P_INTF_HEADER.CUSTOMER_ID,
                                 P_MESSAGE             => V_ERR_MSG,
                                 IS_CTRL_PARAM         => 'NOTGTWIDTHANDNODEPT');
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
          
          RETURN ;
        END IF;
      END IF;
    END IF;
    
    P_MESSAGE := 'SUCCESS';
  END PRC_INSERT_OR_UPDATE_HEADER;

  FUNCTION F_INSERT_OR_UPDATE_DEPT
  --更新或插入客户事业部业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2 IS
    V_CUST_DEPT_COUNT        NUMBER; --业务表中的事业部的数量
    P_MESSAGE                VARCHAR2(1000);
    --VS_MESSAGE               VARCHAR2(4000);
    V_ERR_MSG                VARCHAR2(4000);--循环中出现的所有错误
    P_ERR_MESSAGE            VARCHAR2(1000);--本次错误
    P_PARENT_ID              VARCHAR2(1000); --客户事业部ID
    V_ACCOUNT_COUNT          NUMBER; --账户数量
    V_ACCOUNT_CODE           VARCHAR2(100); --账户编码
    V_ACCOUNT_CODE_TMP       VARCHAR2(100); --账户编码(后缀)
    V_ACCOUNT_ID             NUMBER; --账户ID
    V_ENTITY_ID              NUMBER; --主体ID
    V_CUSTOMER_ID            NUMBER; --客户ID
    V_CUSTOMER_CODE          VARCHAR2(100); --客户编码
    V_ORG_INDEX              NUMBER; --S_CUSTOMER_ORG.NEXTVAL
    --V_SALES_CENTER_CODE      VARCHAR2(100); --中心编码
    --V_SALES_CENTER_ID        NUMBER; --中心ID
    --V_SALES_CENTER_TYPE_CODE UP_ORG_UNIT.Type_Code%type;
    DEPT                     INTF_CUSTOMER_DEPT%ROWTYPE;
    INTF_ORG                 INTF_CUSTOMER_ORG%ROWTYPE;
    VR_SALES_CENTER          UP_ORG_UNIT%ROWTYPE;
    CUST_ORG                 T_CUSTOMER_ORG%ROWTYPE;
    V_ACC_ORG_REL_ID         T_CUSTOMER_ACC_ORG_RELATION.RELATION_ID%TYPE;
    --V_CUST_ORG_COUNT           NUMBER; --推送报表各事业部下的组织个数
    CURSOR C_INTF_CUSTOMER_DEPT IS
      SELECT *
        FROM INTF_CUSTOMER_DEPT
       WHERE PRE_FIELD_01 = TO_CHAR(P_INTF_HEAD_ID);
  
    CURSOR C_INTF_CUSTOMER_ORG IS
      SELECT *
        FROM INTF_CUSTOMER_ORG O
       WHERE O.PRE_FIELD_01 = TO_CHAR(P_INTF_HEAD_ID)
         AND O.PARENT_ID = P_PARENT_ID
         AND 'Active' = O.ACTIVE_FLAG
         AND EXISTS (SELECT 1
                FROM UP_ORG_UNIT UNIT
               WHERE UNIT.CODE = O.SALES_CENTER_CODE
                 AND UNIT.ENTITY_ID IS NOT NULL
                 AND UNIT.TYPE_CODE NOT IN ('MC', 'BU'));
   
    TYPE T_INTF_DEPT IS TABLE OF INTF_CUSTOMER_DEPT%ROWTYPE INDEX BY BINARY_INTEGER;
    V_INTF_DEPT T_INTF_DEPT;
    V_INDEX     NUMBER;
   
    TYPE T_INTF_ORG IS TABLE OF INTF_CUSTOMER_ORG%ROWTYPE INDEX BY BINARY_INTEGER;
    V_INTF_ORG T_INTF_ORG;
    V_INDEX1     NUMBER;
  BEGIN
    --查看主数据ID是否存在
    OPEN C_INTF_CUSTOMER_DEPT;
    FETCH C_INTF_CUSTOMER_DEPT BULK COLLECT INTO V_INTF_DEPT;
    CLOSE C_INTF_CUSTOMER_DEPT;
    V_INDEX := (V_INTF_DEPT.FIRST - 1);
    LOOP
      <<LP_DEPT>>
      V_INDEX := (1 + V_INDEX);
      IF V_INDEX IS NULL OR V_INDEX > V_INTF_DEPT.LAST THEN
        EXIT;
      END IF;
      DEPT := V_INTF_DEPT(V_INDEX);
      P_MESSAGE := 'SUCCESS';
      BEGIN
        V_ACCOUNT_COUNT := 0;
        SELECT (SELECT UNIT.ENTITY_ID
                  FROM UP_ORG_UNIT UNIT
                 WHERE UNIT.CODE = DEPT.DEPT_CODE)
              ,(SELECT CUSTOMER_ID
                 FROM T_CUSTOMER_HEADER HEAD
                WHERE HEAD.CUSTOMER_CODE = DEPT.CUSTOMER_CODE)
          INTO DEPT.DEPT_ID, DEPT.CUSTOMER_ID
          FROM DUAL;
        IF DEPT.DEPT_ID IS NULL THEN
           P_ERR_MESSAGE := '该事业部不是内销的';
           UPDATE INTF_CUSTOMER_DEPT
              SET RESPONSETYPE    = 'E',
                  RESPNOSECODE    = '000013',
                  RESPONSEMESSAGE = P_ERR_MESSAGE,
                  OPERSTATUS      = '1'
            WHERE ID = DEPT.ID;
           COMMIT;
           GOTO LP_DEPT ;
        END IF;
        IF DEPT.CUSTOMER_ID IS NULL THEN
           P_ERR_MESSAGE := '该事业部对应推送报文的客户编码有误：' || DEPT.CUSTOMER_CODE;
           UPDATE INTF_CUSTOMER_DEPT
              SET RESPONSETYPE    = 'E',
                  RESPNOSECODE    = '000013',
                  RESPONSEMESSAGE = P_ERR_MESSAGE,
                  OPERSTATUS      = '1'
            WHERE ID = DEPT.ID;
           COMMIT;
           GOTO LP_DEPT ;
        END IF;
        
        IF DEPT.ACTIVE_FLAG IN ('Active','Freezing') THEN
          SELECT COUNT(0)
            INTO V_CUST_DEPT_COUNT
            FROM UP_CODELIST C, UP_CODELIST_ENTITY CE
           WHERE CE.CODELIST_ID = C.ID
             AND CE.ENTITY_ID = DEPT.DEPT_ID
             AND NVL(CE.ENABLED, '0') = '0'
             AND C.CODETYPE = 'temp_all_free' --临时自由码表
             AND C.CODE_VALUE = '临时主体相关'
             AND C.CODE_NAME = '临时主体相关'
             AND C.ENTITY_FLAG = 'Y'
             AND C.ENABLED = '0';
          IF DEPT.DEPT_ID IS NOT NULL AND 0 = V_CUST_DEPT_COUNT THEN
            SELECT COUNT(0)
              INTO V_CUST_DEPT_COUNT
              FROM T_CUSTOMER_HEADER H
             WHERE H.SIEBEL_CUSTOMER_ID = DEPT.SIEBEL_CUSTOMER_ID
               AND NOT EXISTS
             (SELECT 1
                      FROM T_CUSTOMER_OU OU
                     WHERE OU.CUSTOMER_CODE = H.CUSTOMER_CODE
                       AND ((OU.ACTIVE_FLAG = DEPT.ACTIVE_FLAG AND
                           'Active' = DEPT.ACTIVE_FLAG) OR
                           ('Active' <> DEPT.ACTIVE_FLAG AND
                           OU.ACTIVE_FLAG IN ('Active', 'Freezing')))
                       /*AND EXISTS (SELECT 1
                                       FROM T_INV_ORGANIZATION IO
                                      WHERE IO.ENTITY_ID = DEPT.DEPT_ID
                                        AND IO.OPERATING_UNIT = OU.ERPOU)*/
                       AND EXISTS
                     (SELECT 1
                              FROM V_UP_CODELIST CL
                             WHERE CL.CODETYPE = 'ar_ou_id'
                               AND CL.ENTITY_ID = DEPT.DEPT_ID
                               AND CL.CODE_VALUE = OU.ERPOU) --modify by liangym2 2017-6-14
                    )
               AND NOT EXISTS
             (SELECT 1
                      FROM INTF_CUSTOMER_OU OU
                     WHERE OU.CUSTOMER_CODE = DEPT.CUSTOMER_CODE
                       AND OU.TRANSCODE = DEPT.TRANSCODE
                       AND ((OU.ACTIVE_FLAG = DEPT.ACTIVE_FLAG AND
                           'Active' = DEPT.ACTIVE_FLAG) OR
                           ('Active' <> DEPT.ACTIVE_FLAG AND
                           OU.ACTIVE_FLAG IN ('Active', 'Freezing')))
                       /*AND EXISTS (SELECT 1
                                       FROM T_INV_ORGANIZATION IO
                                      WHERE IO.ENTITY_ID = DEPT.DEPT_ID
                                        AND IO.OPERATING_UNIT = OU.ERPOU)*/
                       AND EXISTS
                     (SELECT 1
                              FROM V_UP_CODELIST CL
                             WHERE CL.CODETYPE = 'ar_ou_id'
                               AND CL.ENTITY_ID = DEPT.DEPT_ID
                               AND CL.CODE_VALUE = OU.ERPOU) --modify by liangym2 2017-6-14
                    )
               --只对新增客户、事业部才做检查
               --AND NOT EXISTS (SELECT 1 FROM T_CUSTOMER_DEPT ND WHERE ND.SIEBEL_ID = DEPT.SIEBEL_ID)
            ;
            
            IF 0 < V_CUST_DEPT_COUNT THEN
              P_ERR_MESSAGE := DEPT.CUSTOMER_CODE || '，事业部' || DEPT.DEPT_CODE
                               || '，没有推送（包括历史）事业部的有效OU';
              UPDATE INTF_CUSTOMER_DEPT
                 SET RESPONSETYPE    = 'E',
                     RESPNOSECODE    = '000013',
                     RESPONSEMESSAGE = P_ERR_MESSAGE,
                     OPERSTATUS      = '1'
               WHERE ID = DEPT.ID;
              COMMIT;
              UPDATE T_CUSTOMER_DEPT D
                 SET D.DEPT_CUSTOMER_STATUS = 'Inactive'
                    ,D.LAST_UPDATE_BY       = DEPT.LAST_UPDATE_BY
                    ,D.LAST_UPDATE_DATE     = DEPT.LAST_INTERFACE_DATE
                    ,D.LAST_INTERFACE_DATE  = DEPT.LAST_INTERFACE_DATE
               WHERE D.SIEBEL_ID = DEPT.SIEBEL_ID
                   --D.SIEBEL_CUSTOMER_ID = DEPT.SIEBEL_CUSTOMER_ID
              ;
              
              IF V_ERR_MSG IS NULL THEN
                V_ERR_MSG := P_ERR_MESSAGE;
              ELSE
                V_ERR_MSG := V_ERR_MSG ||V_NL || P_ERR_MESSAGE;
              END IF;
              GOTO LP_DEPT ;
            END IF;
          END IF;      
        END IF;
    
        SELECT COUNT(0)
          INTO V_CUST_DEPT_COUNT
          FROM T_CUSTOMER_DEPT
         WHERE SIEBEL_ID = DEPT.SIEBEL_ID;
        /* (SELECT SIEBEL_ID
         FROM INTF_CUSTOMER_DEPT
        WHERE PRE_FIELD_01 = P_INTF_HEAD_ID);*/
      
        --若不存在，则插入
        IF (V_CUST_DEPT_COUNT = 0) THEN
          INSERT INTO T_CUSTOMER_DEPT
            (ID,
             DEPT_ID,
             DEPT_CODE,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_SHORT_NAME,
             DEPT_CUSTOM_LEVEL,
             CUSTOMER_MARKET_HIERARCHY,
             DEPT_CUSTOMER_STATUS,
             CUSTOMER_ACTIVE_DATE,
             CUSTOMER_END_DATE,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             YEAR_SCALE,
             BAKE_YEAR_REAL_SCALE,
             SIEBEL_ID,
             SIEBEL_CUSTOMER_ID,
             ACTIVE_FLAG,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06)
          VALUES
            (S_CUSTOMER_DEPT.NEXTVAL,
             DEPT.DEPT_ID,
             dept.DEPT_CODE,
             DEPT.CUSTOMER_ID,
             DEPT.CUSTOMER_CODE,
             DEPT.CUSTOMER_SHORT_NAME,
             DEPT.DEPT_CUSTOM_LEVEL,
             DEPT.CUSTOMER_MARKET_HIERARCHY,
             DEPT.DEPT_CUSTOMER_STATUS,
             DEPT.CUSTOMER_ACTIVE_DATE,
             DEPT.CUSTOMER_END_DATE,
             DEPT.CREATED_BY,
             DEPT.CREATION_DATE,
             DEPT.LAST_UPDATE_DATE,
             DEPT.LAST_UPDATE_BY,
             DEPT.LAST_INTERFACE_DATE,
             DEPT.YEAR_SCALE,
             DEPT.BAKE_YEAR_REAL_SCALE,
             DEPT.SIEBEL_ID,
             DEPT.SIEBEL_CUSTOMER_ID,
             NVL(DEPT.ACTIVE_FLAG, 'Active'),
             DEPT.PRE_FIELD_01,
             DEPT.PRE_FIELD_02,
             DEPT.PRE_FIELD_03,
             DEPT.PRE_FIELD_04,
             DEPT.PRE_FIELD_05,
             DEPT.PRE_FIELD_06);
          COMMIT;
        
        --若存在，则更新
        ELSE
          UPDATE T_CUSTOMER_DEPT
             SET (DEPT_ID,
                  DEPT_CODE,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  CUSTOMER_SHORT_NAME,
                  DEPT_CUSTOM_LEVEL,
                  CUSTOMER_MARKET_HIERARCHY,
                  DEPT_CUSTOMER_STATUS,
                  CUSTOMER_ACTIVE_DATE,
                  CUSTOMER_END_DATE,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_ID,
                  SIEBEL_CUSTOMER_ID,
                  ACTIVE_FLAG,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06) =
                 (SELECT DEPT.DEPT_ID,
                         DEPT.DEPT_CODE,
                         DEPT.CUSTOMER_ID,
                         DEPT.CUSTOMER_CODE,
                         DEPT.CUSTOMER_SHORT_NAME,
                         DEPT.DEPT_CUSTOM_LEVEL,
                         DEPT.CUSTOMER_MARKET_HIERARCHY,
                         DEPT.DEPT_CUSTOMER_STATUS,
                         DEPT.CUSTOMER_ACTIVE_DATE,
                         DEPT.CUSTOMER_END_DATE,
                         DEPT.CREATED_BY,
                         DEPT.CREATION_DATE,
                         DEPT.LAST_UPDATE_DATE,
                         DEPT.LAST_UPDATE_BY,
                         DEPT.LAST_INTERFACE_DATE,
                         DEPT.SIEBEL_ID,
                         DEPT.SIEBEL_CUSTOMER_ID,
                         NVL(DEPT.ACTIVE_FLAG, 'Active'),
                         DEPT.PRE_FIELD_01,
                         DEPT.PRE_FIELD_02,
                         DEPT.PRE_FIELD_03,
                         DEPT.PRE_FIELD_04,
                         DEPT.PRE_FIELD_05,
                         DEPT.PRE_FIELD_06
                    FROM DUAL)
           WHERE SIEBEL_ID = DEPT.SIEBEL_ID;
          /*FROM INTF_CUSTOMER_DEPT INTF
                   WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID
                     AND INTF.SIEBEL_ID = DEPT.SIEBEL_ID)
                   WHERE EXISTS (SELECT 1 FROM INTF_CUSTOMER_DEPT INTFX WHERE INTFX.PRE_FIELD_01 = P_INTF_HEAD_ID AND INTFX.SIEBEL_ID = DEPT.SIEBEL_ID);
          */
          COMMIT;
        END IF;
      
        --增加账户
        --取主体，客户
        SELECT D.DEPT_ID, D.CUSTOMER_ID, D.CUSTOMER_CODE
          INTO V_ENTITY_ID, V_CUSTOMER_ID, V_CUSTOMER_CODE
          FROM T_CUSTOMER_DEPT D
         WHERE D.SIEBEL_ID = DEPT.SIEBEL_ID
           AND ROWNUM = 1;
      
        IF V_ENTITY_ID IS NULL THEN
          GOTO SUCC_DEPT_LG;
        END IF;
          
        P_PARENT_ID := DEPT.SIEBEL_ID;
      
        IF (V_CUST_DEPT_COUNT > 0) THEN
          --20151120 梁颜明 判断是否不存在账户
          SELECT COUNT(0)
            INTO V_ACCOUNT_COUNT
            FROM T_CUSTOMER_ACCOUNT T
           WHERE T.ENTITY_ID = V_ENTITY_ID
             AND T.CUSTOMER_CODE = DEPT.CUSTOMER_CODE;
        END IF;
      
        --如果是第一次插入该事业部、或者账户不存在、或者只有一个分部
        IF (V_CUST_DEPT_COUNT = 0) OR (V_ACCOUNT_COUNT = 0) -- OR (V_CUST_ORG_COUNT = 1)
        THEN
          BEGIN
            OPEN C_INTF_CUSTOMER_ORG;
            FETCH C_INTF_CUSTOMER_ORG BULK COLLECT INTO V_INTF_ORG;
            CLOSE C_INTF_CUSTOMER_ORG;
            V_INDEX1 := (V_INTF_ORG.FIRST - 1);
            LOOP
              <<LP_INTF_ORG>>
              V_INDEX1 := (1 + V_INDEX1);
              IF V_INDEX1 IS NULL OR V_INDEX1 > V_INTF_ORG.LAST THEN
                EXIT;
              END IF;
              INTF_ORG := V_INTF_ORG(V_INDEX1);
              --取中心
              SELECT UNIT.*
                INTO VR_SALES_CENTER
                FROM UP_ORG_UNIT UNIT
               WHERE UNIT.CODE = INTF_ORG.SALES_CENTER_CODE;
              /*SELECT UNIT.UNIT_ID,
                     INTF_ORG.SALES_CENTER_CODE,
                     UNIT.TYPE_CODE
                INTO V_SALES_CENTER_ID,
                     V_SALES_CENTER_CODE,
                     V_SALES_CENTER_TYPE_CODE
                FROM UP_ORG_UNIT UNIT
               WHERE UNIT.CODE = INTF_ORG.SALES_CENTER_CODE;*/
            
              IF 'SC' <> VR_SALES_CENTER.TYPE_CODE THEN
                GOTO LP_INTF_ORG;
              END IF;
            
              BEGIN
                SELECT *
                  INTO CUST_ORG
                  FROM T_CUSTOMER_ORG
                 WHERE SIEBEL_ORG_ID = INTF_ORG.SIEBEL_ORG_ID;
              EXCEPTION WHEN NO_DATA_FOUND THEN
                NULL;
              END;
              --梁颜明 2017-09-27 万一事业部推送、中心处理无先后顺序 可能存在 所以不能假定不是第一次插入事业部、不存在账户的情形下
              --相应的中心已经插入到正式表
              V_ORG_INDEX := CUST_ORG.CUSTOMER_ORG_ID;
              /*V_ORG_INDEX := null;
              IF (0 < V_CUST_DEPT_COUNT) THEN
                V_ORG_INDEX := CUST_ORG.CUSTOMER_ORG_ID;
              END IF;*/
              IF (V_ORG_INDEX IS NULL) THEN
                --取组织序列，并赋值给组织接口表保留字段2，在插入组织的时候，获取序列
                SELECT S_CUSTOMER_ORG.NEXTVAL INTO V_ORG_INDEX FROM DUAL;
              ELSIF CUST_ORG.CUSTOMER_ID <> DEPT.CUSTOMER_ID THEN
                GOTO LP_INTF_ORG;
              END IF;
              UPDATE INTF_CUSTOMER_ORG U
                 SET PRE_FIELD_02 = V_ORG_INDEX
               WHERE CUSTOMER_ORG_ID = INTF_ORG.CUSTOMER_ORG_ID
                 AND NOT EXISTS
               (SELECT 1
                        FROM INTF_CUSTOMER_ORG EI
                       WHERE EI.PRE_FIELD_02 = V_ORG_INDEX
                         AND EI.CUSTOMER_ORG_ID <> U.CUSTOMER_ORG_ID);
              IF 0 = SQL%ROWCOUNT THEN
                GOTO LP_INTF_ORG;
              END IF;
              COMMIT;
              /*INTF_ORG.PRE_FIELD_02 := V_ORG_INDEX;*/
            
              --取账户表序列
              SELECT S_CUSTOMER_ACCOUNT.NEXTVAL
                INTO V_ACCOUNT_ID
                FROM DUAL;
            
              --取主体，客户
              /*
              SELECT DEPT.DEPT_ID, DEPT.CUSTOMER_ID, DEPT.CUSTOMER_CODE
                INTO V_ENTITY_ID, V_CUSTOMER_ID, V_CUSTOMER_CODE
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = INTF_ORG.PARENT_ID;
              */
            
              IF (V_ACCOUNT_COUNT = 0) THEN
                V_ACCOUNT_CODE := V_CUSTOMER_CODE;
              ELSE
                SELECT LPAD(TO_CHAR(V_ACCOUNT_COUNT), 3, '0')
                  INTO V_ACCOUNT_CODE_TMP
                  FROM DUAL;
                V_ACCOUNT_CODE := V_CUSTOMER_CODE || '-' ||
                                  V_ACCOUNT_CODE_TMP;
              END IF;
            
              SELECT S_CUSTOMER_ACC_ORG_RELATION.NEXTVAL INTO V_ACC_ORG_REL_ID FROM DUAL;
              --插入账户表
              INSERT INTO T_CUSTOMER_ACCOUNT
                (ACCOUNT_ID,
                 ENTITY_ID,
                 ACCOUNT_CODE,
                 ACCOUNT_NAME,
                 ACCOUNT_STATUS,
                 CUSTOMER_ID,
                 CUSTOMER_CODE,
                 --APPROVE_STATUS,
                 /*APPROVE_OPINION,
                 LAST_APPROVE_TIME,*/
                 CREATED_BY,
                 CREATION_DATE,
                 LAST_UPDATE_BY,
                 LAST_UPDATE_DATE,
                 ACTIVE_FLAG,
                 SALES_CENTER_ID,
                 SALES_CENTER_CODE,
                 SALES_CENTER_NAME,
                 CUSTOMER_ORG_ID,
                 RELATION_ID
                 /* PRE_FIELD_01,
                 PRE_FIELD_02,
                 PRE_FIELD_03,
                 PRE_FIELD_04,
                 PRE_FIELD_05,
                 PRE_FIELD_06*/)
              VALUES
                (V_ACCOUNT_ID,
                 V_ENTITY_ID,
                 V_ACCOUNT_CODE,
                 NULL,
                 '1',
                 V_CUSTOMER_ID,
                 V_CUSTOMER_CODE,
                 --'1',
                 'INTF',
                 SYSDATE,
                 'INTF',
                 SYSDATE,
                 'Y',
                 VR_SALES_CENTER.UNIT_ID,
                 INTF_ORG.SALES_CENTER_CODE,
                 VR_SALES_CENTER.NAME,
                 V_ORG_INDEX,
                 V_ACC_ORG_REL_ID);
            
              --插入账户和组织对应关系表
              INSERT INTO T_CUSTOMER_ACC_ORG_RELATION
                (RELATION_ID,
                 ACCOUNT_ID,
                 CUSTOMER_ORG_ID,
                 CREATED_BY,
                 CREATION_DATE)
              VALUES
                (V_ACC_ORG_REL_ID,
                 V_ACCOUNT_ID,
                 V_ORG_INDEX,
                 'INTF',
                 SYSDATE);  
              COMMIT;
              
              BEGIN
                --客户信用等级、账户修改时更新客户账户额度（或插入）
                PKG_CREDIT_DOWN_PAY.PRC_CREDIT_ACC_LIMIT_UPDATE(V_ENTITY_ID,
                                                                V_CUSTOMER_ID,
                                                                V_ACCOUNT_ID,
                                                                'CRM推送事业部' || DEPT.TRANSCODE,
                                                                P_ERR_MESSAGE);
              EXCEPTION
                WHEN OTHERS THEN
                  P_ERR_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROCF_INSERT_OR_UPDATE_DEPT',
                                                          SQLCODE,
                                                          '初始化客户账户额度失败！：' || P_ERR_MESSAGE || SQLERRM);
              END;
              COMMIT;
            
              V_ACCOUNT_COUNT := V_ACCOUNT_COUNT + 1;
            END LOOP;
          EXCEPTION
            WHEN OTHERS THEN
              --CLOSE C_INTF_CUSTOMER_ORG;
              ROLLBACK;
              --记录出错信息
              P_ERR_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROCF_INSERT_OR_UPDATE_DEPT',
                                                      SQLCODE,
                                                      '插入客户事业部表分配账户异常：' ||
                                                      SQLERRM);
              UPDATE INTF_CUSTOMER_DEPT
                 SET RESPONSETYPE    = 'E',
                     RESPNOSECODE    = '000013',
                     RESPONSEMESSAGE = P_ERR_MESSAGE,
                     OPERSTATUS      = '1'
               WHERE ID = DEPT.ID;
              COMMIT;
              GOTO LP_DEPT;
          END;
        ELSE
          --信用额度客户信息初始化
          FOR LI IN (
           SELECT CUSTOMER_ID, ACCOUNT_ID
             FROM T_CUSTOMER_ACCOUNT T
            WHERE T.ENTITY_ID = V_ENTITY_ID
              AND T.CUSTOMER_CODE = DEPT.CUSTOMER_CODE)
          LOOP
            BEGIN
              PKG_CREDIT_SETTING.P_CREDIT_CUSTOMER_INIT(V_ENTITY_ID,
                                                        LI.CUSTOMER_ID,
                                                        LI.ACCOUNT_ID,
                                                        P_ERR_MESSAGE);
            EXCEPTION
              WHEN OTHERS THEN
                NULL; --默认值
            END;
          END LOOP;
        END IF;
      
        <<SUCC_DEPT_LG>>
        UPDATE INTF_CUSTOMER_DEPT
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = P_MESSAGE,
               OPERSTATUS      = '0'
         WHERE ID = DEPT.ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROCF_INSERT_OR_UPDATE_DEPT',
                                              SQLCODE,
                                              '插入客户事业部表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_DEPT
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE ID = DEPT.ID;
          COMMIT;
          --RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
    
    IF V_ERR_MSG IS NOT NULL THEN
      IF V_ERR_MSG LIKE '%没有推送（包括历史）事业部的有效OU%' THEN
        BEGIN
          P_CUSTOMER_INTF_PROC(P_INTF_HEADER_ID_LIST => P_INTF_HEAD_ID,
                               P_MESSAGE             => P_ERR_MESSAGE,
                               IS_CTRL_PARAM         => 'NOTGTWIDTHANDNODEPT');
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
      END IF;
      RETURN V_ERR_MSG;
    END IF;
    RETURN P_MESSAGE;
  END F_INSERT_OR_UPDATE_DEPT;

  FUNCTION F_INSERT_OR_UPDATE_ADDRESS
  --更新或插入客户地址业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2 IS
  
    V_CUST_ADDRESS_COUNT  NUMBER; --业务表中地址的数量
    V_CUST_ACC_ADDR_COUNT NUMBER; --业务表中客户地址在账户地址中的数量
    P_MESSAGE             VARCHAR2(1000);
    P_ERROR_MESSAGE       VARCHAR2(1000);
    V_S_CUSTOMER_ADDRESS  NUMBER; --存序列
    V_ENTITY_ID           NUMBER; --主体ID
    V_CUSTOMER_ID         NUMBER; --客户ID
    V_DEPT_ID             NUMBER; --事业部ID
    V_DEPT_CODE           VARCHAR2(100); --事业部编码
    V_CUSTOMER_CODE       VARCHAR2(100); --客户编码
  
    V_ACCOUNT_COUNT NUMBER; --客户账户数量
    V_ACCOUNT_CODE  VARCHAR2(100); --账户编码
    V_ACCOUNT_ID    NUMBER; --账户ID
    V_DISTRICT_CODE VARCHAR2(32); --区域编码
  
    CURSOR C_INTF_CUSTOMER_ADDRESS IS
      SELECT *
        FROM INTF_CUSTOMER_ADDRESS
       WHERE PRE_FIELD_01 = TO_CHAR(P_INTF_HEAD_ID);
    ADDRESS INTF_CUSTOMER_ADDRESS%ROWTYPE;
    TYPE T_INTF_ADDR IS TABLE OF INTF_CUSTOMER_ADDRESS%ROWTYPE INDEX BY BINARY_INTEGER;
    V_INTF_ADDR T_INTF_ADDR;
    V_INDEX     NUMBER;
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --查看主数据客户头ID是否存在
    OPEN C_INTF_CUSTOMER_ADDRESS;
    FETCH C_INTF_CUSTOMER_ADDRESS BULK COLLECT INTO V_INTF_ADDR;
    CLOSE C_INTF_CUSTOMER_ADDRESS;
    V_INDEX := (V_INTF_ADDR.FIRST - 1);
    LOOP
      <<LOOP_HERE>>
      V_INDEX := (1 + V_INDEX);
      IF V_INDEX IS NULL OR V_INDEX > V_INTF_ADDR.LAST THEN
        EXIT;
      END IF;
      ADDRESS := V_INTF_ADDR(V_INDEX);
      BEGIN
        P_MESSAGE := NULL;
        --地址进行校验
        IF ('Inactive' <> ADDRESS.ACTIVE_FLAG) THEN
          FOR LI IN (
            SELECT D.DISTRICT_CODE
                  ,D.FULL_NAME
                  ,D.ACTIVE_FLAG
                  ,D.LEVEL_SEQ
                  ,MAX(D1.DISTRICT_CODE) OVER(PARTITION BY D1.ROW_ID ORDER BY DECODE(D.ACTIVE_FLAG, 'Y', 0, 1), DECODE(D1.ACTIVE_FLAG, 'Y', 0, 1)) AS P_DISTRICT_CODE
                  ,MAX(D1.DISTRICT_NAME) OVER(PARTITION BY D1.ROW_ID ORDER BY DECODE(D.ACTIVE_FLAG, 'Y', 0, 1), DECODE(D1.ACTIVE_FLAG, 'Y', 0, 1)) AS P_DISTRICT_NAME
                  ,DECODE(D.LEVEL_SEQ,
                          1,
                          '国家地区编码',
                          2,
                          '省份编码',
                          3,
                          '地级市编码',
                          4,
                          '县区编码',
                          5,
                          '乡镇编码') AS D_KIND
                  ,DECODE(D.LEVEL_SEQ,
                          1,
                          NULL,
                          2,
                          '国家地区编码',
                          3,
                          '省份编码',
                          4,
                          '地级市编码',
                          5,
                          '县区编码') AS P_D_KIND
                  ,MAX(D2.DISTRICT_CODE) OVER(PARTITION BY D2.ROW_ID ORDER BY DECODE(D.ACTIVE_FLAG, 'Y', 0, 1), DECODE(D2.ACTIVE_FLAG, 'Y', 0, 1)) AS P_DISTRICT_CODE1
                  ,MAX(D2.DISTRICT_NAME) OVER(PARTITION BY D2.ROW_ID ORDER BY DECODE(D.ACTIVE_FLAG, 'Y', 0, 1), DECODE(D2.ACTIVE_FLAG, 'Y', 0, 1)) AS P_DISTRICT_NAME1
                  ,MAX(D2.FULL_NAME) OVER(PARTITION BY D2.ROW_ID ORDER BY DECODE(D.ACTIVE_FLAG, 'Y', 0, 1), DECODE(D2.ACTIVE_FLAG, 'Y', 0, 1)) AS P_FULL_NAME1
              FROM T_BD_DISTRICT D
              LEFT JOIN T_BD_DISTRICT D1
                ON (D.PAR_ROW_ID = D1.ROW_ID)
              LEFT JOIN T_BD_DISTRICT D2
                ON (D2.DISTRICT_CODE =
                   DECODE(D.LEVEL_SEQ,
                           1,
                           NULL,
                           2,
                           NULL,
                           3,
                           ADDRESS.PROVINCE,
                           4,
                           ADDRESS.CITY,
                           5,
                           ADDRESS.AREA))
             WHERE D.DISTRICT_CODE IN (ADDRESS.PROVINCE,
                                       ADDRESS.CITY,
                                       ADDRESS.AREA,
                                       ADDRESS.TOWNS)
             ORDER BY D.LEVEL_SEQ)
          LOOP
            IF 'Y' <> LI.ACTIVE_FLAG THEN
              P_MESSAGE := '客户地址' || LI.D_KIND || LI.DISTRICT_CODE
                        || '[' || LI.FULL_NAME || ']'|| '不是有效状态';
            ELSIF LI.P_DISTRICT_CODE1 IS NOT NULL AND LI.P_DISTRICT_CODE <> LI.P_DISTRICT_CODE1 THEN
              P_MESSAGE := '客户地址' || LI.D_KIND || LI.DISTRICT_CODE
                        || '[' || LI.FULL_NAME || ']'
                        || '的上级行政区域' || LI.P_D_KIND || LI.P_DISTRICT_CODE
                        || '[' || LI.P_DISTRICT_NAME || ']'
                        || '，与客户地址的上级编码' || LI.P_DISTRICT_CODE1
                        || '[' || LI.P_FULL_NAME1 || ']' || '不一致';
            END IF;
          END LOOP;
          /*IF ADDRESS.CITY IS NOT NULL AND ADDRESS.PROVINCE IS NOT NULL AND
             1 <> INSTR(ADDRESS.CITY, ADDRESS.PROVINCE) THEN
            P_MESSAGE := '客户地址地级市编码' || ADDRESS.CITY || '必须以省份编码开头';
          END IF;
          IF ADDRESS.AREA IS NOT NULL AND ADDRESS.CITY IS NOT NULL AND
             1 <> INSTR(ADDRESS.AREA, ADDRESS.CITY) THEN
            P_MESSAGE := '客户地址县区编码' || ADDRESS.AREA || '必须以地级市编码开头';
          END IF;
          IF ADDRESS.TOWNS IS NOT NULL AND ADDRESS.AREA IS NOT NULL THEN
            SELECT MAX(T1.DISTRICT_CODE) OVER(ORDER BY DECODE(T.ACTIVE_FLAG, 'Y', 0, 1), DECODE(T1.ACTIVE_FLAG, 'Y', 0, 1))
              INTO V_DISTRICT_CODE
              FROM T_BD_DISTRICT T
             INNER JOIN T_BD_DISTRICT T1
                ON (T.PAR_ROW_ID = T1.ROW_ID AND
                   ADDRESS.TOWNS = T.DISTRICT_CODE);
            IF V_DISTRICT_CODE <> ADDRESS.AREA THEN
              P_MESSAGE := '客户地址乡镇编码' || ADDRESS.TOWNS || '必须以县区编码' ||
                           V_DISTRICT_CODE || '开头';
            END IF;
          END IF;*/
        END IF;
        IF (P_MESSAGE IS NOT NULL) THEN
          P_ERROR_MESSAGE := P_MESSAGE;
          UPDATE INTF_CUSTOMER_ADDRESS
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 ERROR_INFO      = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE ADDRESS_ID = ADDRESS.ADDRESS_ID;
          COMMIT;
        END IF;
      
        SELECT COUNT(0), MAX(ADDRESS_ID)
          INTO V_CUST_ADDRESS_COUNT, V_S_CUSTOMER_ADDRESS
          FROM T_CUSTOMER_ADDRESS
         WHERE SIEBEL_ADDRESS_ID = ADDRESS.SIEBEL_ADDRESS_ID;
        /*(SELECT SIEBEL_ADDRESS_ID
         FROM INTF_CUSTOMER_ADDRESS
        WHERE PRE_FIELD_01 = P_INTF_HEAD_ID);*/
      
        --取客户和主体
        SELECT DEPT.DEPT_ID
              ,DEPT.CUSTOMER_ID
              ,DEPT.CUSTOMER_CODE
              ,DEPT.DEPT_CODE
              ,DEPT.ID
          INTO V_ENTITY_ID
              ,V_CUSTOMER_ID
              ,V_CUSTOMER_CODE
              ,V_DEPT_CODE
              ,V_DEPT_ID
          FROM T_CUSTOMER_DEPT DEPT
         WHERE DEPT.SIEBEL_ID = ADDRESS.PARENT_ID;
        --如果不存在，则插入
        IF (V_CUST_ADDRESS_COUNT = 0) AND (P_MESSAGE IS NULL) THEN
          --取序列
          SELECT S_CUSTOMER_ADDRESS.NEXTVAL
            INTO V_S_CUSTOMER_ADDRESS
            FROM DUAL;
        
          INSERT INTO T_CUSTOMER_ADDRESS
            (ADDRESS_ID,
             ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             DEPT_ID,
             DEPT_CODE,
             COUNTRY,
             PROVINCE,
             CITY,
             AREA,
             TOWNS,
             ADDRESS,
             ADDRESS_COMMENTS,
             IS_MAIN,
             CONTACTS_ID,
             CONTACTS_NAME,
             CONTACTS_PHONES,
             ADDRESS_TYPE,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_ADDRESS_ID,
             SIEBEL_CUSTOMER_ID,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06,
             DELIVERY_ADDRESS_TYPE,
             PREAPPOINT_FLAG,
             PARENT_ID)
          VALUES
            (V_S_CUSTOMER_ADDRESS, --ADDRESS_ID,
             V_ENTITY_ID, --(SELECT DEPT.DEPT_ID FROM T_CUSTOMER_DEPT DEPT WHERE DEPT.SIEBEL_ID = ADDRESS.PARENT_ID),-- ENTITY_ID,
             V_CUSTOMER_ID, --(SELECT DEPT.CUSTOMER_ID FROM T_CUSTOMER_DEPT DEPT WHERE DEPT.SIEBEL_ID = ADDRESS.PARENT_ID),-- CUSTOMER_ID,
             V_CUSTOMER_CODE, --(SELECT DEPT.CUSTOMER_CODE FROM T_CUSTOMER_DEPT DEPT WHERE DEPT.SIEBEL_ID = ADDRESS.PARENT_ID),-- CUSTOMER_CODE,
             V_ENTITY_ID, --DEPT_ID,
             V_DEPT_CODE, --DEPT_CODE,
             ADDRESS.COUNTRY,
             ADDRESS.PROVINCE,
             ADDRESS.CITY,
             ADDRESS.AREA,
             ADDRESS.TOWNS,
             ADDRESS.ADDRESS,
             ADDRESS.ADDRESS_COMMENTS,
             ADDRESS.IS_MAIN,
             NVL((SELECT NVL(CON.CONTACTS_ID, 0)
                   FROM T_CUSTOMER_CONTACTS CON
                  WHERE CON.SIEBEL_CONTACTS_ID =
                        TO_CHAR(NVL(ADDRESS.CONTACTS_ID, '0'))),
                 0), --CONTACTS_ID,
             ADDRESS.CONTACTS_NAME,
             ADDRESS.CONTACTS_PHONES,
             ADDRESS.ADDRESS_TYPE,
             NVL(ADDRESS.ACTIVE_FLAG, 'Active'),
             ADDRESS.CREATED_BY,
             ADDRESS.CREATION_DATE,
             ADDRESS.LAST_UPDATE_DATE,
             ADDRESS.LAST_UPDATE_BY,
             ADDRESS.LAST_INTERFACE_DATE,
             ADDRESS.SIEBEL_ADDRESS_ID,
             ADDRESS.SIEBEL_CUSTOMER_ID,
             ADDRESS.PRE_FIELD_01,
             ADDRESS.PRE_FIELD_02,
             ADDRESS.PRE_FIELD_03,
             ADDRESS.PRE_FIELD_04,
             ADDRESS.PRE_FIELD_05,
             ADDRESS.PRE_FIELD_06,
             ADDRESS.DELIVERY_ADDRESS_TYPE,
             ADDRESS.PREAPPOINT_FLAG,
             V_DEPT_ID); --PARENT_ID
        
          /* FROM INTF_CUSTOMER_ADDRESS INTF
          WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        ELSIF (V_CUST_ADDRESS_COUNT <> 0) THEN
          UPDATE T_CUSTOMER_ADDRESS A
             SET (ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  DEPT_ID,
                  DEPT_CODE,
                  COUNTRY,
                  PROVINCE,
                  CITY,
                  AREA,
                  TOWNS,
                  ADDRESS,
                  ADDRESS_COMMENTS,
                  IS_MAIN,
                  CONTACTS_ID,
                  CONTACTS_NAME,
                  CONTACTS_PHONES,
                  ADDRESS_TYPE,
                  ACTIVE_FLAG,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_ADDRESS_ID,
                  SIEBEL_CUSTOMER_ID,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06,
                  DELIVERY_ADDRESS_TYPE,
                  PREAPPOINT_FLAG,
                  PARENT_ID) =
                 (SELECT
                  --(SELECT UNIT.ENTITY_ID FROM UP_ORG_UNIT UNIT WHERE UNIT.CODE = (SELECT DEPT.DEPT_CODE FROM T_CUSTOMER_DEPT DEPT WHERE DEPT.SIEBEL_ID = INTF.PARENT_ID)) ENTITY_ID,
                   V_ENTITY_ID,
                   V_CUSTOMER_ID,
                   V_CUSTOMER_CODE,
                   V_ENTITY_ID,
                   V_DEPT_CODE,
                   DECODE(P_MESSAGE, NULL, ADDRESS.COUNTRY, A.COUNTRY),
                   DECODE(P_MESSAGE, NULL, ADDRESS.PROVINCE, A.PROVINCE),
                   DECODE(P_MESSAGE, NULL, ADDRESS.CITY, A.CITY),
                   DECODE(P_MESSAGE, NULL, ADDRESS.AREA, A.AREA),
                   DECODE(P_MESSAGE, NULL, ADDRESS.TOWNS, A.TOWNS),
                   ADDRESS.ADDRESS,
                   ADDRESS.ADDRESS_COMMENTS,
                   DECODE(P_MESSAGE, NULL, ADDRESS.IS_MAIN, A.IS_MAIN),
                   NVL((SELECT NVL(CON.CONTACTS_ID, 0)
                         FROM T_CUSTOMER_CONTACTS CON
                        WHERE CON.SIEBEL_CONTACTS_ID =
                              TO_CHAR(NVL(ADDRESS.CONTACTS_ID, '0'))),
                       0) CONTACTS_ID,
                   ADDRESS.CONTACTS_NAME,
                   ADDRESS.CONTACTS_PHONES,
                   ADDRESS.ADDRESS_TYPE,
                   NVL(ADDRESS.ACTIVE_FLAG, 'Active'),
                   ADDRESS.CREATED_BY,
                   ADDRESS.CREATION_DATE,
                   ADDRESS.LAST_UPDATE_DATE,
                   ADDRESS.LAST_UPDATE_BY,
                   ADDRESS.LAST_INTERFACE_DATE,
                   ADDRESS.SIEBEL_ADDRESS_ID,
                   ADDRESS.SIEBEL_CUSTOMER_ID,
                   ADDRESS.PRE_FIELD_01,
                   ADDRESS.PRE_FIELD_02,
                   ADDRESS.PRE_FIELD_03,
                   ADDRESS.PRE_FIELD_04,
                   ADDRESS.PRE_FIELD_05,
                   ADDRESS.PRE_FIELD_06,
                   ADDRESS.DELIVERY_ADDRESS_TYPE,
                   ADDRESS.PREAPPOINT_FLAG,
                   V_DEPT_ID
                  FROM DUAL)
           WHERE SIEBEL_ADDRESS_ID = ADDRESS.SIEBEL_ADDRESS_ID;
          /*  FROM INTF_CUSTOMER_ADDRESS INTF
                 WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID
                 AND INTF.SIEBEL_ADDRESS_ID = ADDRESS.SIEBEL_ADDRESS_ID)
                 WHERE EXISTS (SELECT 1 FROM INTF_CUSTOMER_ADDRESS INTFX WHERE INTFX.PRE_FIELD_01 = P_INTF_HEAD_ID AND INTFX.SIEBEL_ADDRESS_ID = ADDRESS.SIEBEL_ADDRESS_ID);
          */ --COMMIT;
        END IF;
      
        --无效的地址能不能insert 缺少主要地址不检查
        --更新账户地址的状态，必须更新否则需要删除账户地址再重新选
        IF (0 < V_CUST_ADDRESS_COUNT) THEN
          UPDATE T_CUSTOMER_ACCOUNT_ADDRESS ADDR
             SET ADDR.ACTIVE_FLAG = ADDRESS.ACTIVE_FLAG,
                 ADDR.IS_DEFAULT  = NVL(ADDRESS.IS_MAIN, 'N')
           WHERE ADDR.ADDRESS_ID = V_S_CUSTOMER_ADDRESS
             AND ADDR.ENTITY_ID = V_ENTITY_ID
             AND EXISTS
           (SELECT 1
                    FROM T_CUSTOMER_ACCOUNT ACC
                   WHERE ACC.ACCOUNT_ID = ADDR.ACCOUNT_ID
                     AND ACC.CUSTOMER_ID = V_CUSTOMER_ID);
          V_CUST_ACC_ADDR_COUNT := SQL%ROWCOUNT;
        END IF;
      
        --如果检验有错误
        IF (P_MESSAGE IS NOT NULL) THEN
          GOTO LOOP_HERE;
        END IF;
        IF ('Active' = ADDRESS.ACTIVE_FLAG) AND
           ((0 = V_CUST_ADDRESS_COUNT) OR (0 = V_CUST_ACC_ADDR_COUNT)) THEN
          --如果该客户该主体下只存在一个账户，则把这个地址分配到这个账户上面
          SELECT COUNT(0)
            INTO V_ACCOUNT_COUNT
            FROM T_CUSTOMER_ACCOUNT ACC
           WHERE ACC.CUSTOMER_ID = V_CUSTOMER_ID
             AND ACC.ENTITY_ID = V_ENTITY_ID
             AND ACC.ACCOUNT_STATUS = '1';
        
          IF (V_ACCOUNT_COUNT = 1) THEN
            SELECT ACC.ACCOUNT_ID, ACC.ACCOUNT_CODE
              INTO V_ACCOUNT_ID, V_ACCOUNT_CODE
              FROM T_CUSTOMER_ACCOUNT ACC
             WHERE ACC.CUSTOMER_ID = V_CUSTOMER_ID
               AND ACC.ENTITY_ID = V_ENTITY_ID
               AND ACC.ACCOUNT_STATUS = '1';
          
            INSERT INTO T_CUSTOMER_ACCOUNT_ADDRESS
              (ACCOUNT_ADDRESS_ID,
               ENTITY_ID,
               ACCOUNT_ID,
               ACCOUNT_CODE,
               ADDRESS_ID,
               LAST_UPDATE_DATE,
               ACTIVE_FLAG,
               APPROVE_STATUS,
               IS_DEFAULT)
            VALUES
              (S_CUSTOMER_ACCOUNT_ADDRESS.NEXTVAL,
               V_ENTITY_ID,
               V_ACCOUNT_ID,
               V_ACCOUNT_CODE,
               V_S_CUSTOMER_ADDRESS,
               SYSDATE,
               ADDRESS.ACTIVE_FLAG,
               '1',
               NVL(ADDRESS.IS_MAIN, 'N'));
          END IF;
        END IF;
      
        UPDATE INTF_CUSTOMER_ADDRESS
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = 'SUCCESS',
               OPERSTATUS      = '0'
         WHERE ADDRESS_ID = ADDRESS.ADDRESS_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_ADDRESS',
                                              SQLCODE,
                                              '插入客户地址表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_ADDRESS
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE ADDRESS_ID = ADDRESS.ADDRESS_ID;
          COMMIT;
          --RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
  
    IF P_ERROR_MESSAGE IS NOT NULL THEN
      RETURN P_ERROR_MESSAGE;
    END IF;
    P_MESSAGE := 'SUCCESS';
    RETURN P_MESSAGE;
  END F_INSERT_OR_UPDATE_ADDRESS;

  FUNCTION F_INSERT_OR_UPDATE_CONTACTS
  --更新或插入客户联系人业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2 IS
    V_CUST_CONTACTS_COUNT NUMBER; --业务表中的联系人数量
    P_MESSAGE             VARCHAR2(500);
  
    CURSOR C_INTF_CUSTOMER_CONTACTS IS
      SELECT *
        FROM INTF_CUSTOMER_CONTACTS
       WHERE PRE_FIELD_01 = TO_CHAR(P_INTF_HEAD_ID);
   /*TYPE T_INTF_CONTACTS IS TABLE OF INTF_CUSTOMER_CONTACTS%ROWTYPE INDEX BY BINARY_INTEGER;
   V_INTF_CONTACTS T_INTF_CONTACTS;
   V_INDEX NUMBER;*/  
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --查看主数据客户头ID是否存在
    FOR CONTACTS IN C_INTF_CUSTOMER_CONTACTS LOOP
      BEGIN
        SELECT COUNT(0)
          INTO V_CUST_CONTACTS_COUNT
          FROM T_CUSTOMER_CONTACTS
         WHERE SIEBEL_CONTACTS_ID = CONTACTS.SIEBEL_CONTACTS_ID;
        /*(SELECT SIEBEL_CONTACTS_ID
         FROM INTF_CUSTOMER_CONTACTS
        WHERE PRE_FIELD_01 = P_INTF_HEAD_ID);*/
      
        IF (V_CUST_CONTACTS_COUNT = 0) THEN
          INSERT INTO T_CUSTOMER_CONTACTS
            (CONTACTS_ID,
             ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             DEPT_ID,
             DEPT_CODE,
             CONTACTS_POSITION,
             CONTACTS_NAME,
             CONTACTS_PHONES,
             CONTACTS_MAIL,
             CONTACTS_PHONE_NUMBER,
             MESSAGE_TYPE,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_CONTACTS_ID,
             SIEBEL_CUSTOMER_ID,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06,
             PARENT_ID)
          VALUES
            (
             --SELECT
             S_CUSTOMER_CONTACTS.NEXTVAL, --CONTACTS_ID,
             --(SELECT UNIT.ENTITY_ID FROM UP_ORG_UNIT UNIT WHERE UNIT.CODE = (SELECT DEPT.DEPT_CODE FROM T_CUSTOMER_DEPT DEPT WHERE DEPT.SIEBEL_ID = INTF.PARENT_ID)) ENTITY_ID,
             (SELECT DEPT.DEPT_ID
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = CONTACTS.PARENT_ID), --ENTITY_ID,
             (SELECT DEPT.CUSTOMER_ID
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = CONTACTS.PARENT_ID), --CUSTOMER_ID,
             (SELECT DEPT.CUSTOMER_CODE
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = CONTACTS.PARENT_ID), --CUSTOMER_CODE,
             (SELECT DEPT.DEPT_ID
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = CONTACTS.PARENT_ID), --DEPT_ID,
             (SELECT DEPT.DEPT_CODE
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = CONTACTS.PARENT_ID), --DEPT_CODE,
             CONTACTS.CONTACTS_POSITION,
             CONTACTS.CONTACTS_NAME,
             CONTACTS.CONTACTS_PHONES,
             CONTACTS.CONTACTS_MAIL,
             CONTACTS.CONTACTS_PHONE_NUMBER,
             CONTACTS.MESSAGE_TYPE,
             NVL(CONTACTS.ACTIVE_FLAG, 'Active'),
             CONTACTS.CREATED_BY,
             CONTACTS.CREATION_DATE,
             CONTACTS.LAST_UPDATE_DATE,
             CONTACTS.LAST_UPDATE_BY,
             CONTACTS.LAST_INTERFACE_DATE,
             CONTACTS.SIEBEL_CONTACTS_ID,
             CONTACTS.SIEBEL_CUSTOMER_ID,
             CONTACTS.PRE_FIELD_01,
             CONTACTS.PRE_FIELD_02,
             CONTACTS.PRE_FIELD_03,
             CONTACTS.PRE_FIELD_04,
             CONTACTS.PRE_FIELD_05,
             CONTACTS.PRE_FIELD_06,
             (SELECT DEPT.ID
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = CONTACTS.PARENT_ID)); --PARENT_ID
          /* FROM INTF_CUSTOMER_CONTACTS INTF
          WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        
        ELSE
          UPDATE T_CUSTOMER_CONTACTS
             SET (ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  DEPT_ID,
                  DEPT_CODE,
                  CONTACTS_POSITION,
                  CONTACTS_NAME,
                  CONTACTS_PHONES,
                  CONTACTS_MAIL,
                  CONTACTS_PHONE_NUMBER,
                  MESSAGE_TYPE,
                  ACTIVE_FLAG,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_CONTACTS_ID,
                  SIEBEL_CUSTOMER_ID,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06,
                  PARENT_ID) =
                 (SELECT
                  --(SELECT UNIT.ENTITY_ID FROM UP_ORG_UNIT UNIT WHERE UNIT.CODE = (SELECT DEPT.DEPT_CODE FROM T_CUSTOMER_DEPT DEPT WHERE DEPT.SIEBEL_ID = INTF.PARENT_ID)) ENTITY_ID,
                   (SELECT DEPT.DEPT_ID
                      FROM T_CUSTOMER_DEPT DEPT
                     WHERE DEPT.SIEBEL_ID = CONTACTS.PARENT_ID) ENTITY_ID,
                   (SELECT DEPT.CUSTOMER_ID
                      FROM T_CUSTOMER_DEPT DEPT
                     WHERE DEPT.SIEBEL_ID = CONTACTS.PARENT_ID) CUSTOMER_ID,
                   (SELECT DEPT.CUSTOMER_CODE
                      FROM T_CUSTOMER_DEPT DEPT
                     WHERE DEPT.SIEBEL_ID = CONTACTS.PARENT_ID) CUSTOMER_CODE,
                   (SELECT DEPT.DEPT_ID
                      FROM T_CUSTOMER_DEPT DEPT
                     WHERE DEPT.SIEBEL_ID = CONTACTS.PARENT_ID) DEPT_ID,
                   (SELECT DEPT.DEPT_CODE
                      FROM T_CUSTOMER_DEPT DEPT
                     WHERE DEPT.SIEBEL_ID = CONTACTS.PARENT_ID) DEPT_CODE,
                   CONTACTS.CONTACTS_POSITION,
                   CONTACTS.CONTACTS_NAME,
                   CONTACTS.CONTACTS_PHONES,
                   CONTACTS.CONTACTS_MAIL,
                   CONTACTS.CONTACTS_PHONE_NUMBER,
                   CONTACTS.MESSAGE_TYPE,
                   NVL(CONTACTS.ACTIVE_FLAG, 'Active'),
                   CONTACTS.CREATED_BY,
                   CONTACTS.CREATION_DATE,
                   CONTACTS.LAST_UPDATE_DATE,
                   CONTACTS.LAST_UPDATE_BY,
                   CONTACTS.LAST_INTERFACE_DATE,
                   CONTACTS.SIEBEL_CONTACTS_ID,
                   CONTACTS.SIEBEL_CUSTOMER_ID,
                   CONTACTS.PRE_FIELD_01,
                   CONTACTS.PRE_FIELD_02,
                   CONTACTS.PRE_FIELD_03,
                   CONTACTS.PRE_FIELD_04,
                   CONTACTS.PRE_FIELD_05,
                   CONTACTS.PRE_FIELD_06,
                   (SELECT DEPT.ID
                      FROM T_CUSTOMER_DEPT DEPT
                     WHERE DEPT.SIEBEL_ID = CONTACTS.PARENT_ID) PARENT_ID
                  FROM DUAL)
           WHERE SIEBEL_CONTACTS_ID = CONTACTS.SIEBEL_CONTACTS_ID;
          /*FROM INTF_CUSTOMER_CONTACTS INTF
                 WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID
                 AND INTF.SIEBEL_CONTACTS_ID = CONTACTS.SIEBEL_CONTACTS_ID)
                 WHERE EXISTS (SELECT 1 FROM INTF_CUSTOMER_CONTACTS INTFX  WHERE INTFX.PRE_FIELD_01 = P_INTF_HEAD_ID AND INTFX.SIEBEL_CONTACTS_ID = CONTACTS.SIEBEL_CONTACTS_ID);
          */
        END IF;
      
        UPDATE INTF_CUSTOMER_CONTACTS
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = P_MESSAGE,
               OPERSTATUS      = '0'
         WHERE CONTACTS_ID = CONTACTS.CONTACTS_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_CONTACTS',
                                              SQLCODE,
                                              '插入客户联系人表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_CONTACTS
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE CONTACTS_ID = CONTACTS.CONTACTS_ID;
          COMMIT;
          --RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
    ---COMMIT;
    RETURN P_MESSAGE;
  END F_INSERT_OR_UPDATE_CONTACTS;

  FUNCTION F_INSERT_OR_UPDATE_BANK
  --更新或插入客户银行业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2 IS
    V_CUST_BANK_COUNT NUMBER; --业务表中的银行数量
    P_MESSAGE         VARCHAR2(500);
  
    CURSOR C_INTF_CUSTOMER_BANK IS
      SELECT *
        FROM INTF_CUSTOMER_BANK
       WHERE PRE_FIELD_01 = TO_CHAR(P_INTF_HEAD_ID);
   /*TYPE T_INTF_BANK IS TABLE OF INTF_CUSTOMER_BANK%ROWTYPE INDEX BY BINARY_INTEGER;
   V_INTF_BANK T_INTF_BANK;
   V_INDEX NUMBER;*/
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --查看主数据客户头ID是否存在
    FOR BANK IN C_INTF_CUSTOMER_BANK LOOP
      BEGIN
        SELECT COUNT(0)
          INTO V_CUST_BANK_COUNT
          FROM T_CUSTOMER_BANK
         WHERE SIEBEL_BANK_ID = BANK.SIEBEL_BANK_ID;
        /*(SELECT SIEBEL_BANK_ID
         FROM INTF_CUSTOMER_BANK
        WHERE PRE_FIELD_01 = P_INTF_HEAD_ID);*/
      
        IF (V_CUST_BANK_COUNT = 0) THEN
          INSERT INTO T_CUSTOMER_BANK
            (BANK_ID,
             ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             DEPT_ID,
             DEPT_CODE,
             BANK,
             BRANCH,
             ACCOUNTS_NAME,
             BANK_ACCOUNT,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_BANK_ID,
             SIEBEL_CUSTOMER_ID,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06,
             PARENT_ID,
             SSA_PRIMARY_FIELD)
          --SELECT
          VALUES
            (S_CUSTOMER_BANK.NEXTVAL, --BANK_ID,
             --(SELECT UNIT.ENTITY_ID FROM UP_ORG_UNIT UNIT WHERE UNIT.CODE = (SELECT DEPT.DEPT_CODE FROM T_CUSTOMER_DEPT DEPT WHERE DEPT.SIEBEL_ID = INTF.PARENT_ID)) ENTITY_ID,
             (SELECT DEPT.DEPT_ID
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = BANK.PARENT_ID), --ENTITY_ID,
             (SELECT DEPT.CUSTOMER_ID
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = BANK.PARENT_ID), --CUSTOMER_ID,
             (SELECT DEPT.CUSTOMER_CODE
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = BANK.PARENT_ID), --CUSTOMER_CODE,
             (SELECT DEPT.DEPT_ID
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = BANK.PARENT_ID), --DEPT_ID,
             (SELECT DEPT.DEPT_CODE
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = BANK.PARENT_ID), --DEPT_CODE,
             BANK.BANK,
             BANK.BRANCH,
             BANK.ACCOUNTS_NAME,
             BANK.BANK_ACCOUNT,
             NVL(BANK.ACTIVE_FLAG, 'Active'),
             BANK.CREATED_BY,
             BANK.CREATION_DATE,
             BANK.LAST_UPDATE_DATE,
             BANK.LAST_UPDATE_BY,
             BANK.LAST_INTERFACE_DATE,
             BANK.SIEBEL_BANK_ID,
             BANK.SIEBEL_CUSTOMER_ID,
             BANK.PRE_FIELD_01,
             BANK.PRE_FIELD_02,
             BANK.PRE_FIELD_03,
             BANK.PRE_FIELD_04,
             BANK.PRE_FIELD_05,
             BANK.PRE_FIELD_06,
             (SELECT DEPT.ID
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = BANK.PARENT_ID), --PARENT_ID,
             BANK.SSA_PRIMARY_FIELD);
          /* FROM INTF_CUSTOMER_BANK INTF
          WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        
        ELSE
          UPDATE T_CUSTOMER_BANK
             SET (ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  DEPT_ID,
                  DEPT_CODE,
                  BANK,
                  BRANCH,
                  ACCOUNTS_NAME,
                  BANK_ACCOUNT,
                  ACTIVE_FLAG,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_BANK_ID,
                  SIEBEL_CUSTOMER_ID,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06,
                  PARENT_ID,
                  SSA_PRIMARY_FIELD) =
                 (SELECT
                  --(SELECT UNIT.ENTITY_ID FROM UP_ORG_UNIT UNIT WHERE UNIT.CODE = (SELECT DEPT.DEPT_CODE FROM T_CUSTOMER_DEPT DEPT WHERE DEPT.SIEBEL_ID = INTF.PARENT_ID)) ENTITY_ID,
                   (SELECT DEPT.DEPT_ID
                      FROM T_CUSTOMER_DEPT DEPT
                     WHERE DEPT.SIEBEL_ID = BANK.PARENT_ID) ENTITY_ID,
                   (SELECT DEPT.CUSTOMER_ID
                      FROM T_CUSTOMER_DEPT DEPT
                     WHERE DEPT.SIEBEL_ID = BANK.PARENT_ID) CUSTOMER_ID,
                   (SELECT DEPT.CUSTOMER_CODE
                      FROM T_CUSTOMER_DEPT DEPT
                     WHERE DEPT.SIEBEL_ID = BANK.PARENT_ID) CUSTOMER_CODE,
                   (SELECT DEPT.DEPT_ID
                      FROM T_CUSTOMER_DEPT DEPT
                     WHERE DEPT.SIEBEL_ID = BANK.PARENT_ID) DEPT_ID,
                   (SELECT DEPT.DEPT_CODE
                      FROM T_CUSTOMER_DEPT DEPT
                     WHERE DEPT.SIEBEL_ID = BANK.PARENT_ID) DEPT_CODE,
                   BANK.BANK,
                   BANK.BRANCH,
                   BANK.ACCOUNTS_NAME,
                   BANK.BANK_ACCOUNT,
                   NVL(BANK.ACTIVE_FLAG, 'Active'),
                   BANK.CREATED_BY,
                   BANK.CREATION_DATE,
                   BANK.LAST_UPDATE_DATE,
                   BANK.LAST_UPDATE_BY,
                   BANK.LAST_INTERFACE_DATE,
                   BANK.SIEBEL_BANK_ID,
                   BANK.SIEBEL_CUSTOMER_ID,
                   BANK.PRE_FIELD_01,
                   BANK.PRE_FIELD_02,
                   BANK.PRE_FIELD_03,
                   BANK.PRE_FIELD_04,
                   BANK.PRE_FIELD_05,
                   BANK.PRE_FIELD_06,
                   (SELECT DEPT.ID
                      FROM T_CUSTOMER_DEPT DEPT
                     WHERE DEPT.SIEBEL_ID = BANK.PARENT_ID) PARENT_ID,
                   BANK.SSA_PRIMARY_FIELD
                  FROM DUAL)
           WHERE SIEBEL_BANK_ID = BANK.SIEBEL_BANK_ID;
          /*FROM INTF_CUSTOMER_BANK INTF
                       WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID
                         AND INTF.SIEBEL_BANK_ID = BANK.SIEBEL_BANK_ID)
                        WHERE EXISTS (SELECT 1 FROM INTF_CUSTOMER_BANK INTFX WHERE INTFX.PRE_FIELD_01 = P_INTF_HEAD_ID AND INTFX.SIEBEL_BANK_ID = BANK.SIEBEL_BANK_ID);
          */
        END IF;
        UPDATE INTF_CUSTOMER_BANK
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = P_MESSAGE,
               OPERSTATUS      = '0'
         WHERE BANK_ID = BANK.BANK_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_BANK',
                                              SQLCODE,
                                              '插入银行业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_BANK
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE BANK_ID = BANK.BANK_ID;
          COMMIT;
          --RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
    RETURN P_MESSAGE;
  END F_INSERT_OR_UPDATE_BANK;

  FUNCTION F_INSERT_OR_UPDATE_BRAND
  --更新或插入客户品牌业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2 IS
    V_CUST_BRAND               T_CUSTOMER_BRAND%ROWTYPE;
    V_CUST_BRAND_SALES_CODE    T_CUSTOMER_BRAND.SALES_MAIN_TYPE_CODE%TYPE; --业务表中的营销大类编码
    BRAND                      INTF_CUSTOMER_BRAND%ROWTYPE;
    DEPT                       T_CUSTOMER_DEPT%ROWTYPE;
    V_COUNT                    NUMBER;
    V_ACTIVE_COOPERATION_MODEL T_CUSTOMER_BRAND.COOPERATION_MODEL%TYPE;
    P_MESSAGE                  VARCHAR2(500);
    P_ERR_MESSAGE              VARCHAR2(2000);--本次错误
    V_SALES_MAIN_TYPE_NAME     VARCHAR2(100);
    V_SALES_MAIN_TYPE_NAME_CL  VARCHAR2(100);
    V_CLASS_MAIN_IS_PMT        VARCHAR(100);
    V_SALES_MAIN_CNT1          NUMBER; --业务表中的营销大类数量
    V_SALES_MAIN_CNT2          NUMBER; --业务表中的营销大类数量
    VN_RESULT                  NUMBER;
    VN_CREDIT_GROUP_ID         NUMBER;
    VV_INIT                    VARCHAR2(100);
    V_COUNT_S                  NUMBER;
    V_ACTIVE_COOPERATION_MODEL_S T_CUSTOMER_BRAND.COOPERATION_MODEL%TYPE;
  
    CURSOR C_INTF_CUSTOMER_BRAND IS
      WITH T1 AS (SELECT *
                    FROM INTF_CUSTOMER_BRAND
                   WHERE PRE_FIELD_01 = TO_CHAR(P_INTF_HEAD_ID))
      ,T2 AS (SELECT I.*
                FROM INTF_CUSTOMER_BRAND I
               WHERE TO_NUMBER(I.PRE_FIELD_01) < P_INTF_HEAD_ID
                 AND I.RESPONSETYPE <> 'N'
                 AND I.RESPNOSECODE = 'MAYNOERR'
                 AND I.ACTIVE_FLAG = 'Active'
                 AND EXISTS (SELECT 1 FROM T1
                              WHERE T1.PARENT_ID = I.PARENT_ID
                                AND T1.ACTIVE_FLAG <> 'Active'
                                AND T1.BRAND_CODE = I.BRAND_CODE
                                AND T1.SALES_MAIN_TYPE_CODE = I.SALES_MAIN_TYPE_CODE
                              --AND T1.COOPERATION_MODEL <> I.COOPERATION_MODEL
                            )
                 AND NOT EXISTS (SELECT 1 FROM T1
                                  WHERE T1.SIEBEL_BRAND_ID = I.SIEBEL_BRAND_ID
                                    AND T1.ACTIVE_FLAG = I.ACTIVE_FLAG))
      ,T3 AS (SELECT T2.PARENT_ID
                    ,MAX(TO_NUMBER(T2.PRE_FIELD_01)) AS LAST_PRE_FIELD_01
                FROM T2
               GROUP BY T2.PARENT_ID)
      ,T4 AS (SELECT T1.* FROM T1
              UNION ALL
              SELECT T2.*
                FROM T2
               INNER JOIN T3
                  ON (T3.PARENT_ID = T2.PARENT_ID
                      AND T2.PRE_FIELD_01 = T3.LAST_PRE_FIELD_01))
      SELECT *
        FROM T4
       ORDER BY TO_NUMBER(T4.PRE_FIELD_01) DESC
               ,DECODE(T4.ACTIVE_FLAG,
                       'Inactive',
                       0,
                       'Deleted',
                       0,
                       'Freezing',
                       1,
                       'Active',
                       99,
                       2);
      /*SELECT *
        FROM INTF_CUSTOMER_BRAND I
       WHERE PRE_FIELD_01 = P_INTF_HEAD_ID
       ORDER BY DECODE(I.Active_Flag,
                       'Inactive',
                       0,
                       'Deleted',
                       0,
                       'Freezing',
                       1,
                       'Active',
                       99,
                       2)*/

   TYPE T_INTF_BRAND
     IS TABLE OF INTF_CUSTOMER_BRAND%ROWTYPE
     INDEX BY BINARY_INTEGER;

   V_INTF_BRAND T_INTF_BRAND;
   V_INDEX NUMBER;
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --查看主数据客户头ID是否存在
    OPEN C_INTF_CUSTOMER_BRAND;
    FETCH C_INTF_CUSTOMER_BRAND BULK COLLECT INTO V_INTF_BRAND;
    CLOSE C_INTF_CUSTOMER_BRAND;
    V_INDEX := (V_INTF_BRAND.FIRST - 1);
    LOOP
      <<LP_INTF_BRAND>>
      V_INDEX := (1 + V_INDEX);
      IF V_INDEX IS NULL OR V_INDEX > V_INTF_BRAND.LAST THEN
        EXIT;
      END IF;
      BRAND := V_INTF_BRAND(V_INDEX);
      P_MESSAGE := 'SUCCESS';
      BEGIN
        SELECT D.*
          INTO DEPT
          FROM T_CUSTOMER_DEPT D
         WHERE D.SIEBEL_ID = BRAND.PARENT_ID;
        BEGIN
          V_CUST_BRAND            := NULL;
          V_CUST_BRAND_SALES_CODE := NULL;
          SELECT *
            INTO V_CUST_BRAND
            FROM T_CUSTOMER_BRAND
           WHERE SIEBEL_BRAND_ID = BRAND.SIEBEL_BRAND_ID;
          V_CUST_BRAND_SALES_CODE := V_CUST_BRAND.SALES_MAIN_TYPE_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
      
        IF (V_CUST_BRAND_SALES_CODE IS NULL) THEN
          INSERT INTO T_CUSTOMER_BRAND
            (BRAND_ID,
             ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             DEPT_ID,
             DEPT_CODE,
             BRAND_CODE,
             CUSTOMER_LEVEL,
             CUSTOMER_CREDIT_LEVEL,
             CREDIT_LINE,
             COOPERATION_MODEL,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_BRAND_ID,
             SIEBEL_CUSTOMER_ID,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06,
             SALES_MAIN_TYPE_CODE,
             PARENT_ID,
             NET_BATCH_FLAG)
          VALUES
            (S_CUSTOMER_BRAND.NEXTVAL, --BRAND_ID,
             --(SELECT UNIT.ENTITY_ID FROM UP_ORG_UNIT UNIT WHERE UNIT.CODE = (SELECT DEPT.DEPT_CODE FROM T_CUSTOMER_DEPT DEPT WHERE DEPT.SIEBEL_ID = INTF.PARENT_ID)) ENTITY_ID,
             DEPT.DEPT_ID, --ENTITY_ID,
             DEPT.CUSTOMER_ID, --CUSTOMER_ID,
             DEPT.CUSTOMER_CODE, --CUSTOMER_CODE,
             DEPT.DEPT_ID, --DEPT_ID,
             DEPT.DEPT_CODE, --DEPT_CODE,
             BRAND.BRAND_CODE,
             BRAND.CUSTOMER_LEVEL,
             BRAND.CUSTOMER_CREDIT_LEVEL,
             BRAND.CREDIT_LINE,
             BRAND.COOPERATION_MODEL,
             NVL(BRAND.ACTIVE_FLAG, 'Active'),
             BRAND.CREATED_BY,
             BRAND.CREATION_DATE,
             BRAND.LAST_UPDATE_DATE,
             BRAND.LAST_UPDATE_BY,
             BRAND.LAST_INTERFACE_DATE,
             BRAND.SIEBEL_BRAND_ID,
             BRAND.SIEBEL_CUSTOMER_ID,
             BRAND.PRE_FIELD_01,
             BRAND.PRE_FIELD_02,
             BRAND.PRE_FIELD_03,
             BRAND.PRE_FIELD_04,
             BRAND.PRE_FIELD_05,
             BRAND.PRE_FIELD_06,
             BRAND.SALES_MAIN_TYPE_CODE,
             (SELECT DEPT.ID
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = BRAND.PARENT_ID), --PARENT_ID
             BRAND.NET_BATCH_FLAG);
          /* FROM INTF_CUSTOMER_BRAND INTF
          WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        ELSE
          UPDATE T_CUSTOMER_BRAND
             SET (ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  DEPT_ID,
                  DEPT_CODE,
                  BRAND_CODE,
                  COOPERATION_MODEL,
                  ACTIVE_FLAG,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_BRAND_ID,
                  SIEBEL_CUSTOMER_ID,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06,
                  SALES_MAIN_TYPE_CODE,
                  PARENT_ID,
                  NET_BATCH_FLAG)
               = (SELECT
                    --(SELECT UNIT.ENTITY_ID FROM UP_ORG_UNIT UNIT WHERE UNIT.CODE = (SELECT DEPT.DEPT_CODE FROM T_CUSTOMER_DEPT DEPT WHERE DEPT.SIEBEL_ID = INTF.PARENT_ID)) ENTITY_ID,
                    DEPT.DEPT_ID       ENTITY_ID,
                    DEPT.CUSTOMER_ID   CUSTOMER_ID,
                    DEPT.CUSTOMER_CODE CUSTOMER_CODE,
                    DEPT.DEPT_ID       DEPT_ID,
                    DEPT.DEPT_CODE     DEPT_CODE,
                    BRAND.BRAND_CODE,
                    BRAND.COOPERATION_MODEL,
                    NVL(BRAND.ACTIVE_FLAG, 'Active'),
                    BRAND.CREATED_BY,
                    BRAND.CREATION_DATE,
                    BRAND.LAST_UPDATE_DATE,
                    BRAND.LAST_UPDATE_BY,
                    BRAND.LAST_INTERFACE_DATE,
                    BRAND.SIEBEL_BRAND_ID,
                    BRAND.SIEBEL_CUSTOMER_ID,
                    BRAND.PRE_FIELD_01,
                    BRAND.PRE_FIELD_02,
                    BRAND.PRE_FIELD_03,
                    BRAND.PRE_FIELD_04,
                    BRAND.PRE_FIELD_05,
                    BRAND.PRE_FIELD_06,
                    BRAND.SALES_MAIN_TYPE_CODE,
                    (SELECT DEPT.ID
                      FROM T_CUSTOMER_DEPT DEPT
                     WHERE DEPT.SIEBEL_ID = BRAND.PARENT_ID) PARENT_ID,
                    BRAND.NET_BATCH_FLAG
                  FROM DUAL)
           WHERE SIEBEL_BRAND_ID = BRAND.SIEBEL_BRAND_ID;
          /* FROM INTF_CUSTOMER_BRAND INTF
                       WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID
                         AND INTF.SIEBEL_BRAND_ID = BRAND.SIEBEL_BRAND_ID)
                       WHERE EXISTS (SELECT 1 FROM INTF_CUSTOMER_BRAND INTFX  WHERE INTFX.PRE_FIELD_01 = P_INTF_HEAD_ID AND INTFX.SIEBEL_BRAND_ID = BRAND.SIEBEL_BRAND_ID);
          */
        END IF;
        
        --2016-4-13 仅为有效时判断
        --IF 'Active' = BRAND.ACTIVE_FLAG THEN
        /*DECODE(BRAND_CODE,BRAND.BRAND_CODE,DECODE(ACTIVE_FLAG, 'Active', COOPERATION_MODEL, NULL
        , NULL)*/
          SELECT COUNT(DECODE(BRAND_CODE,
                              BRAND.BRAND_CODE,
                              DECODE(ACTIVE_FLAG, 'Active', 0, NULL),
                              NULL))
                 /*,MAX(DECODE(ACTIVE_FLAG,
                               'Active',
                             --COOPERATION_MODEL
                               DECODE(BRAND_CODE, BRAND.BRAND_CODE, COOPERATION_MODEL, NULL),
                               NULL))
                 */
                 ,COUNT(DECODE(ACTIVE_FLAG, 'Active', 0, NULL))
                 /*
                 ,MAX(DECODE(ACTIVE_FLAG, 'Active', COOPERATION_MODEL, NULL))
                 */
            INTO V_COUNT
              --,V_ACTIVE_COOPERATION_MODEL
                ,V_COUNT_S --
              --,V_ACTIVE_COOPERATION_MODEL_S
            FROM T_CUSTOMER_BRAND
           WHERE ENTITY_ID = DEPT.DEPT_ID
             AND CUSTOMER_ID = DEPT.CUSTOMER_ID
           --AND BRAND_CODE = BRAND.BRAND_CODE
             AND SALES_MAIN_TYPE_CODE = BRAND.SALES_MAIN_TYPE_CODE;
             
          --ENTITY_ID CUSTOMER_ID BRAND_CODE SALES_MAIN_TYPE_CODE COOPERATION_MODEL ACTIVE_FLAG
          --V_ACTIVE_COOPERATION_MODEL := NVL(V_ACTIVE_COOPERATION_MODEL,V_ACTIVE_COOPERATION_MODEL_S);
          
          V_ACTIVE_COOPERATION_MODEL := NULL;
          V_ACTIVE_COOPERATION_MODEL_S := NULL;
          IF 1 < V_COUNT THEN
            ROLLBACK;
            UPDATE INTF_CUSTOMER_BRAND
               SET RESPONSETYPE    = 'E'
                  ,RESPNOSECODE    = 'MAYNOERR'
                  ,RESPONSEMESSAGE = '客户同一主体、大类不允许多个有效的品牌'
                  ,OPERSTATUS      = '1'
             WHERE BRAND_ID = BRAND.BRAND_ID;
            COMMIT;
            GOTO LP_INTF_BRAND;
          END IF;
          IF 0 < V_COUNT_S THEN
            SELECT COOPERATION_MODEL, COOPERATION_MODEL
              INTO V_ACTIVE_COOPERATION_MODEL, V_ACTIVE_COOPERATION_MODEL_S
              FROM (SELECT *
                      FROM T_CUSTOMER_BRAND
                     WHERE ENTITY_ID = DEPT.DEPT_ID
                       AND CUSTOMER_ID = DEPT.CUSTOMER_ID
                       AND SALES_MAIN_TYPE_CODE = BRAND.SALES_MAIN_TYPE_CODE
                     --AND BRAND_CODE = BRAND.BRAND_CODE
                       AND ACTIVE_FLAG = 'Active'
                     ORDER BY LAST_UPDATE_DATE DESC)
             WHERE 1 = ROWNUM;
          END IF;
        --END IF;
        
        BEGIN
          SELECT IC.CLASS_NAME,IC.PROMOTION_FLAG,CODELIST.CODE_NAME
            INTO V_SALES_MAIN_TYPE_NAME,V_CLASS_MAIN_IS_PMT,V_SALES_MAIN_TYPE_NAME_CL
            FROM T_BD_ITEM_CLASS IC
           LEFT JOIN UP_CODELIST CODELIST
              ON (CODELIST.CODE_VALUE = IC.CLASS_CODE AND
                 CODELIST.CODETYPE = 'MIDEA_ACCOUNT_PROD_TYPE')
           WHERE IC.CLASS_CODE = BRAND.SALES_MAIN_TYPE_CODE
             AND IC.ENTITY_ID = DEPT.DEPT_ID
             AND IC.CLASS_TYPE = 'M'
             AND IC.ACTIVE_FLAG = 'Y';
          IF V_SALES_MAIN_TYPE_NAME_CL IS NULL THEN
            ROLLBACK;
            UPDATE INTF_CUSTOMER_BRAND
               SET RESPONSETYPE    = 'E'
                  ,RESPNOSECODE    = '000002'
                  ,RESPONSEMESSAGE = '营销大类在CRM推送码表不存在，ENTITY_ID=' ||
                                     DEPT.DEPT_ID || '，大类编码：' ||
                                     BRAND.SALES_MAIN_TYPE_CODE ||
                                     '，码值：MIDEA_ACCOUNT_PROD_TYPE'
                  ,OPERSTATUS      = '1'
             WHERE BRAND_ID = BRAND.BRAND_ID;
            COMMIT;
            GOTO LP_INTF_BRAND;
          /*ELSIF V_SALES_MAIN_TYPE_NAME_CL <> V_SALES_MAIN_TYPE_NAME THEN
            ROLLBACK;
            UPDATE INTF_CUSTOMER_BRAND
               SET RESPONSETYPE    = 'E'
                  ,RESPNOSECODE    = '000002'
                  ,RESPONSEMESSAGE = '营销大类在CRM推送码表的名称与在T_BD_ITEM_CLASS的名称不一致，ENTITY_ID=' ||
                                     DEPT.DEPT_ID || '，大类编码：' ||
                                     BRAND.SALES_MAIN_TYPE_CODE
                  ,OPERSTATUS      = '1'
             WHERE BRAND_ID = BRAND.BRAND_ID;
            COMMIT;
            GOTO LP_INTF_BRAND;*/
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            ROLLBACK;
            UPDATE INTF_CUSTOMER_BRAND
               SET RESPONSETYPE    = 'E'
                  ,RESPNOSECODE    = '000002'
                  ,RESPONSEMESSAGE = '营销大类在T_BD_ITEM_CLASS不存在（甚至可能是“CRM推送码表或T_BD_ITEM_CLASS”重复），ENTITY_ID=' ||
                                     DEPT.DEPT_ID || '，大类编码：' ||
                                     BRAND.SALES_MAIN_TYPE_CODE
                  ,OPERSTATUS      = '1'
             WHERE BRAND_ID = BRAND.BRAND_ID;
            COMMIT;
            GOTO LP_INTF_BRAND;
        END;
        
        UPDATE INTF_CUSTOMER_BRAND
           SET RESPONSETYPE    = 'N'
              ,RESPNOSECODE    = '000000'
              ,RESPONSEMESSAGE = P_MESSAGE
              ,OPERSTATUS      = '0'
         WHERE BRAND_ID = BRAND.BRAND_ID;
        COMMIT;
        
        SELECT COUNT(DECODE(MTYPE.SALES_MAIN_TYPE_CODE,
                            NVL(V_CUST_BRAND_SALES_CODE,
                                BRAND.SALES_MAIN_TYPE_CODE),
                            0)) --需要插入的记录数
              ,COUNT(DECODE(MTYPE.SALES_MAIN_TYPE_CODE,
                            (CASE
                              WHEN V_CUST_BRAND_SALES_CODE <> BRAND.SALES_MAIN_TYPE_CODE THEN
                               BRAND.SALES_MAIN_TYPE_CODE
                              ELSE
                               NULL
                            END),
                            0)) --需要更改大类的记录数（对于同一客户+品类下对应多个品牌，则以最新一次推送数据更新客户营销大类表）
          INTO V_SALES_MAIN_CNT1, V_SALES_MAIN_CNT2
          FROM T_CUSTOMER_SALES_MAIN_TYPE MTYPE
         WHERE MTYPE.CUSTOM_CODE = DEPT.CUSTOMER_CODE
           AND MTYPE.ENTITY_ID = DEPT.DEPT_ID;
      
        IF (0 = V_SALES_MAIN_CNT1) THEN
          INSERT INTO T_CUSTOMER_SALES_MAIN_TYPE
            (SALES_MAIN_TYPE_ID,
             ENTITY_ID,
             CUSTOM_ID,
             CUSTOM_CODE,
             DEPT_ID,
             DEPT_CODE,
             SALES_MAIN_TYPE_NAME,
             COOPERATION_MODEL_ID,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SALES_MAIN_TYPE_CODE,
             PARENT_ID,
             CUSTOMER_NAME,
             NET_BATCH_FLAG)
          VALUES
            (S_CUSTOMER_SALES_MAIN_TYPE.NEXTVAL,
             DEPT.DEPT_ID,
             DEPT.CUSTOMER_ID,
             DEPT.CUSTOMER_CODE,
             DEPT.DEPT_ID,
             DEPT.DEPT_CODE,
             V_SALES_MAIN_TYPE_NAME,
             BRAND.COOPERATION_MODEL,
             NVL(BRAND.ACTIVE_FLAG, 'Active'),
             BRAND.CREATED_BY,
             BRAND.CREATION_DATE,
             /*BRAND.LAST_UPDATE_DATE,*/ SYSDATE,
             BRAND.LAST_UPDATE_BY,
             BRAND.LAST_INTERFACE_DATE,
             BRAND.SALES_MAIN_TYPE_CODE,
             DEPT.ID,
             NVL((SELECT H.CUSTOMER_NAME
                   FROM T_CUSTOMER_HEADER H
                  WHERE H.CUSTOMER_ID = DEPT.CUSTOMER_ID)
                 ,NVL(''||DEPT.CUSTOMER_ID, DEPT.CUSTOMER_CODE)),
             BRAND.NET_BATCH_FLAG
            );
        ELSIF (0 = V_SALES_MAIN_CNT2) THEN
          --主数据对经营品牌如果不做校验控制，客户同一个品牌、大类存在多条有效数据的情况
          UPDATE T_CUSTOMER_SALES_MAIN_TYPE MTYPE
             SET LAST_UPDATE_DATE     = /*BRAND.LAST_UPDATE_DATE,*/ SYSDATE,
                 LAST_UPDATE_BY       = BRAND.LAST_UPDATE_BY,
                 LAST_INTERFACE_DATE  = BRAND.LAST_INTERFACE_DATE,
                 SALES_MAIN_TYPE_NAME = V_SALES_MAIN_TYPE_NAME,
                 SALES_MAIN_TYPE_CODE = BRAND.SALES_MAIN_TYPE_CODE,
                 --ACTIVE_FLAG = NVL(BRAND.ACTIVE_FLAG,'Active'),
                 ACTIVE_FLAG = DECODE(V_COUNT,
                                      1,
                                      'Active',
                                      NVL(BRAND.ACTIVE_FLAG, 'Active')),
                 --COOPERATION_MODEL_ID = BRAND.COOPERATION_MODEL
                 COOPERATION_MODEL_ID = DECODE(V_COUNT,
                                               1,
                                               V_ACTIVE_COOPERATION_MODEL,
                                               BRAND.COOPERATION_MODEL),
                 CUSTOMER_NAME = NVL((SELECT H.CUSTOMER_NAME
                                         FROM T_CUSTOMER_HEADER H
                                        WHERE H.CUSTOMER_ID = DEPT.CUSTOMER_ID)
                                     ,NVL(''||DEPT.CUSTOMER_ID, DEPT.CUSTOMER_CODE)),
                 NET_BATCH_FLAG = BRAND.NET_BATCH_FLAG
           WHERE MTYPE.SALES_MAIN_TYPE_CODE =
                 NVL(V_CUST_BRAND_SALES_CODE, BRAND.SALES_MAIN_TYPE_CODE)
             AND MTYPE.CUSTOM_CODE = DEPT.CUSTOMER_CODE
             AND MTYPE.ENTITY_ID = DEPT.DEPT_ID;
        ELSE
          UPDATE T_CUSTOMER_SALES_MAIN_TYPE MTYPE
             SET LAST_UPDATE_DATE    = /*BRAND.LAST_UPDATE_DATE,*/ SYSDATE,
                 LAST_UPDATE_BY      = BRAND.LAST_UPDATE_BY,
                 LAST_INTERFACE_DATE = BRAND.LAST_INTERFACE_DATE,
                 ACTIVE_FLAG         = 'Inactive',
                 CUSTOMER_NAME = NVL((SELECT H.CUSTOMER_NAME
                                        FROM T_CUSTOMER_HEADER H
                                       WHERE H.CUSTOMER_ID = DEPT.CUSTOMER_ID)
                                     ,NVL(''||DEPT.CUSTOMER_ID, DEPT.CUSTOMER_CODE)),
                 NET_BATCH_FLAG = BRAND.NET_BATCH_FLAG
           WHERE MTYPE.SALES_MAIN_TYPE_CODE = V_CUST_BRAND_SALES_CODE
             AND MTYPE.CUSTOM_CODE = DEPT.CUSTOMER_CODE
             AND MTYPE.ENTITY_ID = DEPT.DEPT_ID;
        
          UPDATE T_CUSTOMER_SALES_MAIN_TYPE MTYPE
             SET LAST_UPDATE_DATE     = /*BRAND.LAST_UPDATE_DATE,*/ SYSDATE,
                 LAST_UPDATE_BY       = BRAND.LAST_UPDATE_BY,
                 LAST_INTERFACE_DATE  = BRAND.LAST_INTERFACE_DATE,
                 SALES_MAIN_TYPE_NAME = V_SALES_MAIN_TYPE_NAME,
                 SALES_MAIN_TYPE_CODE = BRAND.SALES_MAIN_TYPE_CODE,
                 ACTIVE_FLAG          = DECODE(V_COUNT,
                                               1,
                                               'Active',
                                               NVL(BRAND.ACTIVE_FLAG,
                                                   'Active')),
                 COOPERATION_MODEL_ID = DECODE(V_COUNT,
                                               1,
                                               V_ACTIVE_COOPERATION_MODEL,
                                               BRAND.COOPERATION_MODEL),
                 CUSTOMER_NAME = NVL((SELECT H.CUSTOMER_NAME
                                        FROM T_CUSTOMER_HEADER H
                                       WHERE H.CUSTOMER_ID = DEPT.CUSTOMER_ID)
                                     ,NVL(''||DEPT.CUSTOMER_ID, DEPT.CUSTOMER_CODE)),
                 NET_BATCH_FLAG = BRAND.NET_BATCH_FLAG
           WHERE MTYPE.SALES_MAIN_TYPE_CODE = BRAND.SALES_MAIN_TYPE_CODE
             AND MTYPE.CUSTOM_CODE = DEPT.CUSTOMER_CODE
             AND MTYPE.ENTITY_ID = DEPT.DEPT_ID;
        END IF;
        IF (0 < V_COUNT_S) THEN
          UPDATE T_CUSTOMER_SALES_MAIN_TYPE S
             SET S.ACTIVE_FLAG          = 'Active'
                ,S.COOPERATION_MODEL_ID = V_ACTIVE_COOPERATION_MODEL
                ,S.LAST_UPDATE_BY       = BRAND.LAST_UPDATE_BY
                ,S.LAST_UPDATE_DATE     = /*BRAND.LAST_UPDATE_DATE*/ SYSDATE
                ,S.LAST_INTERFACE_DATE  = BRAND.LAST_INTERFACE_DATE
                ,S.NET_BATCH_FLAG       = BRAND.NET_BATCH_FLAG
           WHERE S.ENTITY_ID = DEPT.DEPT_ID
             AND S.CUSTOM_ID = DEPT.CUSTOMER_ID
             AND S.SALES_MAIN_TYPE_CODE = BRAND.SALES_MAIN_TYPE_CODE
             AND (S.ACTIVE_FLAG IS NULL OR 'Active' <> S.ACTIVE_FLAG);
          COMMIT;
        END IF;
          
        --2017-04-28 生成信用额度客户信息表
        BEGIN
          PKG_CREDIT_SETTING.P_CREDIT_CUSTOMER_INIT(DEPT.DEPT_ID,
                                                    DEPT.CUSTOMER_ID,
                                                    BRAND.SALES_MAIN_TYPE_CODE,
                                                    NULL,
                                                    P_ERR_MESSAGE);
        EXCEPTION
          WHEN OTHERS THEN
            NULL; --默认值
        END;
        VV_INIT := 'Y';
        BEGIN
          PKG_BD.P_GET_PARAMETER_VALUE('CUST_ACCOUNT_CREDIT_AMOUNT_INIT',
                                       DEPT.DEPT_ID,
                                       NULL,
                                       NULL,
                                       VV_INIT);
        EXCEPTION
          WHEN OTHERS THEN
            VV_INIT := 'Y'; --默认值
        END;
        
        IF 'Y' = VV_INIT AND 'Active' = BRAND.ACTIVE_FLAG
          AND (V_CLASS_MAIN_IS_PMT IS NULL OR V_CLASS_MAIN_IS_PMT <> 'Y') THEN
      
          /*
          SELECT COUNT(0)
            INTO VN_RESULT
            FROM DUAL
           WHERE 1 = NVL((SELECT MIN(DECODE(A.CREATED_BY, 'INTF', 1, 0))
                           FROM T_CUSTOMER_ACCOUNT A
                          WHERE A.ENTITY_ID = DEPT.DEPT_ID
                            AND A.CUSTOMER_ID = DEPT.CUSTOMER_ID),
                         0);
          --当存在全部是推送初始化的账户，自动初始化该大类的客户款项
          IF 0 < VN_RESULT THEN*/
            BEGIN
              PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ACC_AMOUNT_INIT(DEPT.DEPT_ID,
                                                                    DEPT.CUSTOMER_ID,
                                                                    NULL,
                                                                    NULL,
                                                                    NULL,
                                                                    'CRM_BRAND_INIT',
                                                                    VN_RESULT,
                                                                    P_ERR_MESSAGE);
              --,DEPT.CUSTOMER_ID,NULL,NULL,BRAND.SALES_MAIN_TYPE_CODE,'CRM_BRAND_INIT',VN_RESULT,P_ERR_MESSAGE);
            EXCEPTION
              WHEN OTHERS THEN
                P_ERR_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.F_INSERT_OR_UPDATE_BRAND',
                                                        SQLCODE,
                                                        '初始化客户款项失败！：' ||
                                                        P_ERR_MESSAGE ||
                                                        SQLERRM);
            END;
          --END IF;
          
          --梁颜明 2017 5 26
          /*FOR GL IN (
              SELECT G.CREDIT_GROUP_ID
                FROM T_CREDIT_CATEGORY_GROUP_REL T, T_CREDIT_GROUP G
               WHERE G.CREDIT_GROUP_ID = T.CREDIT_GROUP_ID
                 AND T.SALES_MAIN_TYPE = BRAND.SALES_MAIN_TYPE_CODE
                 AND G.ENTITY_ID = DEPT.DEPT_ID)
          LOOP
            FOR LI IN (
              SELECT M.ACCOUNT_ID
                FROM T_SALES_ACCOUNT_AMOUNT M
               WHERE M.ENTITY_ID = DEPT.DEPT_ID
                 AND M.CUSTOMER_ID = DEPT.CUSTOMER_ID
               GROUP BY M.ACCOUNT_ID
              --对已存在的账户，如果已经存在该大类其他额度组的客户款项，但是不存在该大类所在额度组的客户款项，自动初始化
              HAVING 0 = MAX(DECODE(M.CREDIT_GROUP_ID, GL.CREDIT_GROUP_ID, 1, 0))
            )
            LOOP
              BEGIN
                PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ACC_AMOUNT_INIT(DEPT.DEPT_ID,
                                                                      DEPT.CUSTOMER_ID,
                                                                      LI.ACCOUNT_ID,
                                                                      NULL,
                                                                      BRAND.SALES_MAIN_TYPE_CODE,
                                                                      'CRM_BRAND_INIT',
                                                                      VN_RESULT,
                                                                      P_ERR_MESSAGE);
              EXCEPTION
                WHEN OTHERS THEN
                  P_ERR_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.F_INSERT_OR_UPDATE_BRAND',
                                                          SQLCODE,
                                                          '初始化客户款项失败！：' ||
                                                          P_ERR_MESSAGE ||
                                                          SQLERRM);
              END;
            END LOOP;
          END LOOP;*/
        END IF;
        
        BEGIN
          PKG_CREDIT_DOWN_PAY.PRC_CREDIT_ACC_LIMIT_UPDATE(DEPT.DEPT_ID,
                                                          DEPT.CUSTOMER_ID,
                                                          NULL,
                                                          'CRM_BRAND_INIT',
                                                          P_ERR_MESSAGE);
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.F_INSERT_OR_UPDATE_BRAND',
                                                    SQLCODE,
                                                    '初始化客户账户额度失败！：' ||
                                                    P_ERR_MESSAGE || SQLERRM);
        END;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_BRAND',
                                              SQLCODE,
                                              '插入自定义营销大类业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_BRAND
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE BRAND_ID = BRAND.BRAND_ID;
          COMMIT;
          --RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
    RETURN P_MESSAGE;
  END F_INSERT_OR_UPDATE_BRAND;

  FUNCTION F_INSERT_OR_UPDATE_CHANN_TYPE
  --更新或插入客户业态类型（渠道类型）业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2 IS
    V_CUST_CHANNEL_TYPE_COUNT NUMBER; --业务表中的渠道类型（业态类型）数量
    P_MESSAGE                 VARCHAR2(500);
    V_ERR_MESSAGE             VARCHAR2(500);
  
    V_ACTIVE_CNT NUMBER;
    DEPT T_CUSTOMER_DEPT%ROWTYPE;
    CHANNEL INTF_CUSTOMER_CHANNEL_TYPE%ROWTYPE;
    CURSOR C_INTF_CUSTOMER_CHANNEL_TYPE IS
      SELECT *
        FROM INTF_CUSTOMER_CHANNEL_TYPE I
       WHERE PRE_FIELD_01 = TO_CHAR(P_INTF_HEAD_ID)
       ORDER BY DECODE(I.Active_Flag,
                       'Inactive',
                       0,
                       'Deleted',
                       0,
                       'Freezing',
                       1,
                       'Active',
                       99,
                       2) --I.CREATION_DATE DESC
      ;
    TYPE T_INTF_CHN_TYPE IS TABLE OF INTF_CUSTOMER_CHANNEL_TYPE%ROWTYPE INDEX BY BINARY_INTEGER;
    V_INTF_CHN_TYPE T_INTF_CHN_TYPE;
    V_INDEX NUMBER;  
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --查看主数据客户头ID是否存在
    OPEN C_INTF_CUSTOMER_CHANNEL_TYPE;
    FETCH C_INTF_CUSTOMER_CHANNEL_TYPE BULK COLLECT INTO V_INTF_CHN_TYPE;
    CLOSE C_INTF_CUSTOMER_CHANNEL_TYPE;
    V_INDEX := (V_INTF_CHN_TYPE.FIRST - 1);
    LOOP
      <<LP_INTF_CHANNEL_TYPE>>
      V_INDEX := (1 + V_INDEX);
      IF V_INDEX IS NULL OR V_INDEX > V_INTF_CHN_TYPE.LAST THEN
        EXIT;
      END IF;
      CHANNEL := V_INTF_CHN_TYPE(V_INDEX);
    
      BEGIN
        SELECT D.*
          INTO DEPT
          FROM T_CUSTOMER_DEPT D
         WHERE D.SIEBEL_ID = CHANNEL.PARENT_ID;
        SELECT COUNT(0)
          INTO V_CUST_CHANNEL_TYPE_COUNT
          FROM T_CUSTOMER_CHANNEL_TYPE
         WHERE SIEBEL_CHANNEL_TYPE_ID = CHANNEL.SIEBEL_CHANNEL_TYPE_ID;
      
        --2016-4-13 增加校验 因为IT不知道哪个业态类型是有效的 业务也不管这个规则 所以有必要进行校验
        IF 'Active' = CHANNEL.ACTIVE_FLAG THEN
          SELECT COUNT(DECODE(T.ACTIVE_FLAG, 'Active', 0))
            INTO V_ACTIVE_CNT
            FROM T_CUSTOMER_CHANNEL_TYPE T
           WHERE T.ENTITY_ID = DEPT.DEPT_ID
             AND T.CUSTOMER_ID = DEPT.CUSTOMER_ID
             AND T.SIEBEL_CHANNEL_TYPE_ID <> CHANNEL.SIEBEL_CHANNEL_TYPE_ID;
          IF 0 < V_ACTIVE_CNT THEN
            ROLLBACK;
            IF 0 < V_CUST_CHANNEL_TYPE_COUNT THEN
              UPDATE T_CUSTOMER_CHANNEL_TYPE T
                 SET T.ACTIVE_FLAG = 'Inactive'
               WHERE T.SIEBEL_CHANNEL_TYPE_ID =
                     CHANNEL.SIEBEL_CHANNEL_TYPE_ID;
            END IF;
            V_ERR_MESSAGE := '同一客户同一主体只能保留最多一个有效的业态类型';
            UPDATE INTF_CUSTOMER_CHANNEL_TYPE
               SET RESPONSETYPE    = 'E',
                   RESPNOSECODE    = '000013',
                   RESPONSEMESSAGE = V_ERR_MESSAGE,
                   OPERSTATUS      = '1'
             WHERE CHANNEL_TYPE_ID = CHANNEL.CHANNEL_TYPE_ID;
            COMMIT;
            GOTO LP_INTF_CHANNEL_TYPE;
          END IF;
        END IF;
        /* (SELECT SIEBEL_CHANNEL_TYPE_ID
         FROM INTF_CUSTOMER_CHANNEL_TYPE
        WHERE PRE_FIELD_01 = P_INTF_HEAD_ID);*/
      
        IF (V_CUST_CHANNEL_TYPE_COUNT = 0) THEN
          INSERT INTO T_CUSTOMER_CHANNEL_TYPE
            (CHANNEL_TYPE_ID,
             ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             DEPT_ID,
             DEPT_CODE,
             INDUSTRY_TYPE,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_CUSTOMER_ID,
             SIEBEL_CHANNEL_TYPE_ID,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06,
             PARENT_ID)
          --SELECT
          VALUES
            (S_CUSTOMER_CHANNEL_TYPE.NEXTVAL, --CHANNEL_TYPE_ID,
             --(SELECT UNIT.ENTITY_ID FROM UP_ORG_UNIT UNIT WHERE UNIT.CODE = (SELECT DEPT.DEPT_CODE FROM T_CUSTOMER_DEPT DEPT WHERE DEPT.SIEBEL_ID = INTF.PARENT_ID)) ENTITY_ID,
             DEPT.DEPT_ID, --ENTITY_ID,
             DEPT.CUSTOMER_ID, --CUSTOMER_ID,
             DEPT.CUSTOMER_CODE, --CUSTOMER_CODE,
             DEPT.DEPT_ID, --DEPT_ID,
             DEPT.DEPT_CODE, --DEPT_CODE,
             CHANNEL.INDUSTRY_TYPE,
             NVL(CHANNEL.ACTIVE_FLAG, 'Active'),
             CHANNEL.CREATED_BY,
             CHANNEL.CREATION_DATE,
             CHANNEL.LAST_UPDATE_DATE,
             CHANNEL.LAST_UPDATE_BY,
             CHANNEL.LAST_INTERFACE_DATE,
             CHANNEL.SIEBEL_CUSTOMER_ID,
             CHANNEL.SIEBEL_CHANNEL_TYPE_ID,
             CHANNEL.PRE_FIELD_01,
             CHANNEL.PRE_FIELD_02,
             CHANNEL.PRE_FIELD_03,
             CHANNEL.PRE_FIELD_04,
             CHANNEL.PRE_FIELD_05,
             CHANNEL.PRE_FIELD_06,
             DEPT.ID); --PARENT_ID
          /*
          FROM INTF_CUSTOMER_CHANNEL_TYPE INTF
          WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        
        ELSE
          UPDATE T_CUSTOMER_CHANNEL_TYPE
             SET (ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  DEPT_ID,
                  DEPT_CODE,
                  INDUSTRY_TYPE,
                  ACTIVE_FLAG,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_CUSTOMER_ID,
                  SIEBEL_CHANNEL_TYPE_ID,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06,
                  PARENT_ID) =
                 (SELECT
                  --(SELECT UNIT.ENTITY_ID FROM UP_ORG_UNIT UNIT WHERE UNIT.CODE = (SELECT DEPT.DEPT_CODE FROM T_CUSTOMER_DEPT DEPT WHERE DEPT.SIEBEL_ID = INTF.PARENT_ID)) ENTITY_ID,
                   DEPT.DEPT_ID ENTITY_ID,
                   DEPT.CUSTOMER_ID CUSTOMER_ID,
                   DEPT.CUSTOMER_CODE CUSTOMER_CODE,
                   DEPT.DEPT_ID DEPT_ID,
                   DEPT.DEPT_CODE DEPT_CODE,
                   CHANNEL.INDUSTRY_TYPE,
                   NVL(CHANNEL.ACTIVE_FLAG, 'Active'),
                   CHANNEL.CREATED_BY,
                   CHANNEL.CREATION_DATE,
                   CHANNEL.LAST_UPDATE_DATE,
                   CHANNEL.LAST_UPDATE_BY,
                   CHANNEL.LAST_INTERFACE_DATE,
                   CHANNEL.SIEBEL_CUSTOMER_ID,
                   CHANNEL.SIEBEL_CHANNEL_TYPE_ID,
                   CHANNEL.PRE_FIELD_01,
                   CHANNEL.PRE_FIELD_02,
                   CHANNEL.PRE_FIELD_03,
                   CHANNEL.PRE_FIELD_04,
                   CHANNEL.PRE_FIELD_05,
                   CHANNEL.PRE_FIELD_06,
                   DEPT.ID PARENT_ID
                  FROM DUAL)
           WHERE SIEBEL_CHANNEL_TYPE_ID = CHANNEL.SIEBEL_CHANNEL_TYPE_ID;
          /*   FROM INTF_CUSTOMER_CHANNEL_TYPE INTF
                    WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID
                      AND INTF.SIEBEL_CHANNEL_TYPE_ID = CHANNEL.SIEBEL_CHANNEL_TYPE_ID)
                    WHERE EXISTS (SELECT 1 FROM INTF_CUSTOMER_CHANNEL_TYPE INTFX WHERE INTFX.PRE_FIELD_01 = P_INTF_HEAD_ID AND INTFX.SIEBEL_CHANNEL_TYPE_ID = CHANNEL.SIEBEL_CHANNEL_TYPE_ID);
          */
        
        END IF;
        UPDATE INTF_CUSTOMER_CHANNEL_TYPE
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = P_MESSAGE,
               OPERSTATUS      = '0'
         WHERE CHANNEL_TYPE_ID = CHANNEL.CHANNEL_TYPE_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_CHANN_TYPE',
                                              SQLCODE,
                                              '插入业态类型业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_CHANNEL_TYPE
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE CHANNEL_TYPE_ID = CHANNEL.CHANNEL_TYPE_ID;
          COMMIT;
          --RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
    RETURN P_MESSAGE;
  END F_INSERT_OR_UPDATE_CHANN_TYPE;

  FUNCTION F_INSERT_OR_UPDATE_CONNECTION
  --更新或插入客户关联关系业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2 IS
    V_CUST_CONNECTION_COUNT NUMBER; --业务表中的关联关系数量
    P_MESSAGE               VARCHAR2(500);
  
    CURSOR C_INTF_CUSTOMER_CONNECTION IS
      SELECT *
        FROM INTF_CUSTOMER_CONNECTION
       WHERE PRE_FIELD_01 = TO_CHAR(P_INTF_HEAD_ID);
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --查看主数据客户头ID是否存在
    FOR CONNECTION IN C_INTF_CUSTOMER_CONNECTION LOOP
      BEGIN
        SELECT COUNT(0)
          INTO V_CUST_CONNECTION_COUNT
          FROM T_CUSTOMER_CONNECTION
         WHERE SIEBEL_CONNECTION_ID = CONNECTION.SIEBEL_CONNECTION_ID;
        /* (SELECT SIEBEL_CONNECTION_ID
         FROM INTF_CUSTOMER_CONNECTION
        WHERE PRE_FIELD_01 = P_INTF_HEAD_ID);*/
      
        IF (V_CUST_CONNECTION_COUNT = 0) THEN
          INSERT INTO T_CUSTOMER_CONNECTION
            (CONNECTION_ID,
             --ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CONNECTION_RELATION,
             CONNECTION_CUSTOM_CODE,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_CUSTOMER_ID,
             SIEBEL_CONNECTION_ID,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06)
          --SELECT
          VALUES
            (S_CUSTOMER_CONNECTION.Nextval, --CONNECTION_ID,
             --(SELECT UNIT.ENTITY_ID FROM UP_ORG_UNIT UNIT WHERE UNIT.CODE = (SELECT DEPT.DEPT_CODE FROM T_CUSTOMER_DEPT DEPT WHERE DEPT.SIEBEL_ID = INTF.PARENT_ID)) ENTITY_ID,
             (SELECT CUSTOMER_ID
                FROM T_CUSTOMER_HEADER HEAD
               WHERE CONNECTION.CUSTOMER_CODE = HEAD.CUSTOMER_CODE), --CUSTOMER_ID, AND HEAD.ACTIVE_FLAG = 'Active'
             CONNECTION.CUSTOMER_CODE,
             CONNECTION.CONNECTION_RELATION,
             CONNECTION.CONNECTION_CUSTOM_CODE,
             NVL(CONNECTION.ACTIVE_FLAG, 'Active'),
             CONNECTION.CREATED_BY,
             CONNECTION.CREATION_DATE,
             CONNECTION.LAST_UPDATE_DATE,
             CONNECTION.LAST_UPDATE_BY,
             CONNECTION.LAST_INTERFACE_DATE,
             CONNECTION.SIEBEL_CUSTOMER_ID,
             CONNECTION.SIEBEL_CONNECTION_ID,
             CONNECTION.PRE_FIELD_01,
             CONNECTION.PRE_FIELD_02,
             CONNECTION.PRE_FIELD_03,
             CONNECTION.PRE_FIELD_04,
             CONNECTION.PRE_FIELD_05,
             CONNECTION.PRE_FIELD_06);
          /*
          FROM INTF_CUSTOMER_CONNECTION INTF
          WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        
        ELSE
          UPDATE T_CUSTOMER_CONNECTION
             SET (
                  --ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  CONNECTION_RELATION,
                  CONNECTION_CUSTOM_CODE,
                  ACTIVE_FLAG,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_CUSTOMER_ID,
                  SIEBEL_CONNECTION_ID,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06) =
                 (SELECT (SELECT CUSTOMER_ID
                            FROM T_CUSTOMER_HEADER HEAD
                           WHERE CONNECTION.CUSTOMER_CODE =
                                 HEAD.CUSTOMER_CODE) CUSTOMER_ID, --AND HEAD.ACTIVE_FLAG = 'Active'
                         CONNECTION.CUSTOMER_CODE,
                         CONNECTION.CONNECTION_RELATION,
                         CONNECTION.CONNECTION_CUSTOM_CODE,
                         NVL(CONNECTION.ACTIVE_FLAG, 'Active'),
                         CONNECTION.CREATED_BY,
                         CONNECTION.CREATION_DATE,
                         CONNECTION.LAST_UPDATE_DATE,
                         CONNECTION.LAST_UPDATE_BY,
                         CONNECTION.LAST_INTERFACE_DATE,
                         CONNECTION.SIEBEL_CUSTOMER_ID,
                         CONNECTION.SIEBEL_CONNECTION_ID,
                         CONNECTION.PRE_FIELD_01,
                         CONNECTION.PRE_FIELD_02,
                         CONNECTION.PRE_FIELD_03,
                         CONNECTION.PRE_FIELD_04,
                         CONNECTION.PRE_FIELD_05,
                         CONNECTION.PRE_FIELD_06
                    FROM DUAL)
           WHERE SIEBEL_CONNECTION_ID = CONNECTION.SIEBEL_CONNECTION_ID;
          /* FROM INTF_CUSTOMER_CONNECTION INTF
                       WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID
                         AND INTF.SIEBEL_CONNECTION_ID = CONNECTION.SIEBEL_CONNECTION_ID)
                       WHERE EXISTS (SELECT 1 FROM INTF_CUSTOMER_CONNECTION INTFX WHERE INTFX.PRE_FIELD_01 = P_INTF_HEAD_ID  AND INTFX.SIEBEL_CONNECTION_ID = CONNECTION.SIEBEL_CONNECTION_ID);
          */
        END IF;
        UPDATE INTF_CUSTOMER_CONNECTION
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = P_MESSAGE,
               OPERSTATUS      = '0'
         WHERE CONNECTION_ID = CONNECTION.CONNECTION_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_CONNECTION',
                                              SQLCODE,
                                              '插入管理关系业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_CONNECTION
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE CONNECTION_ID = CONNECTION.CONNECTION_ID;
          COMMIT;
          --RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
    RETURN P_MESSAGE;
  END F_INSERT_OR_UPDATE_CONNECTION;

  FUNCTION F_INSERT_OR_UPDATE_OU
  --更新或插入客户OU业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2 IS
    V_CUST_OU_COUNT NUMBER; --业务表中的OU信息的数量
    P_MESSAGE       VARCHAR2(500);
    OU              INTF_CUSTOMER_OU%ROWTYPE;
  
    CURSOR C_INTF_CUSTOMER_OU IS
      SELECT *
        FROM INTF_CUSTOMER_OU
       WHERE PRE_FIELD_01 = TO_CHAR(P_INTF_HEAD_ID);
    TYPE T_INTF_OU IS TABLE OF INTF_CUSTOMER_OU%ROWTYPE INDEX BY BINARY_INTEGER;
    V_INTF_OU T_INTF_OU;
    V_INDEX NUMBER;
  BEGIN
    UPDATE INTF_CUSTOMER_OU O
       SET O.SIEBEL_CUSTOMER_ID =
           (SELECT HEAD.SIEBEL_CUSTOMER_ID
              FROM INTF_CUSTOMER_HEADER HEAD
             WHERE HEAD.CUSTOMER_ID = TO_NUMBER(O.PRE_FIELD_01))
     WHERE O.PRE_FIELD_01 = TO_CHAR(P_INTF_HEAD_ID)
       AND O.SIEBEL_CUSTOMER_ID IS NULL;
    --查看主数据客户头ID是否存在
    OPEN C_INTF_CUSTOMER_OU;
    FETCH C_INTF_CUSTOMER_OU BULK COLLECT INTO V_INTF_OU;
    CLOSE C_INTF_CUSTOMER_OU;
    V_INDEX := (V_INTF_OU.FIRST - 1);
    LOOP
      <<LOOP_HERE>>
      V_INDEX := (1 + V_INDEX);
      IF V_INDEX IS NULL OR V_INDEX > V_INTF_OU.LAST THEN
        EXIT;
      END IF;
      OU := V_INTF_OU(V_INDEX);
      P_MESSAGE := 'SUCCESS';
      BEGIN
        IF 'Inactive' = OU.ACTIVE_FLAG THEN
          SELECT COUNT(0)
            INTO V_CUST_OU_COUNT
            FROM V_UP_CODELIST CL
           WHERE OU.ERPOU = CL.CODE_VALUE
           AND CL.CODETYPE = 'ar_ou_id'; --modify by liangym2 2017-6-14
        ElSE
          SELECT COUNT(DISTINCT D.SIEBEL_ID)
            INTO V_CUST_OU_COUNT
            FROM INTF_CUSTOMER_DEPT D, V_UP_CODELIST CL, UP_ORG_UNIT U
           WHERE D.SIEBEL_CUSTOMER_ID =
                 (SELECT H.SIEBEL_CUSTOMER_ID
                    FROM INTF_CUSTOMER_HEADER IH, T_CUSTOMER_HEADER H
                   WHERE H.SIEBEL_CUSTOMER_ID = IH.SIEBEL_CUSTOMER_ID
                     AND IH.CUSTOMER_ID = P_INTF_HEAD_ID)
             AND D.DEPT_CODE = U.CODE
             AND U.TYPE_CODE IN ('BU','MC')
             AND U.ENTITY_ID = CL.ENTITY_ID
             AND OU.ERPOU = CL.CODE_VALUE
             AND CL.CODETYPE = 'ar_ou_id' --modify by liangym2 2017-6-14
             AND D.DEPT_CUSTOMER_STATUS IN ('Active', 'Freezing');
        END IF;
        IF 0 = V_CUST_OU_COUNT THEN
          UPDATE INTF_CUSTOMER_OU
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = 'OU在内销不存在:' || OU.ERPOU || '（如果存在就是相关事业部没有推送、有效，码表：ar_ou_id）',
                 OPERSTATUS      = '1'
           WHERE ERPOU_ID = OU.ERPOU_ID;
          COMMIT;
          GOTO LOOP_HERE;
        END IF;
      
        SELECT COUNT(0)
          INTO V_CUST_OU_COUNT
          FROM T_CUSTOMER_OU
         WHERE SIEBEL_ERPOU_ID = OU.SIEBEL_ERPOU_ID;
        /* (SELECT SIEBEL_ERPOU_ID
         FROM INTF_CUSTOMER_OU
        WHERE PRE_FIELD_01 = P_INTF_HEAD_ID);*/
        /*
        SELECT *
          FROM CIMS.T_CUSTOMER_OU T
         WHERE EXISTS (SELECT 1
                 FROM CIMS.T_CUSTOMER_DEPT D, CIMS.T_INV_ORGANIZATION O
                WHERE D.CUSTOMER_ID = T.CUSTOMER_ID
                AND D.DEPT_ID = O.ENTITY_ID
                AND T.ERPOU = O.OPERATING_UNIT)*/
      
        IF (V_CUST_OU_COUNT = 0) THEN
          INSERT INTO T_CUSTOMER_OU
            (ERPOU_ID,
             --ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             ERPOU,
             COUNTRY,
             PROVINCE,
             ADDRESS,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_ERPOU_ID,
             SIEBEL_CUSTOMER_ID,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06)
          --SELECT
          VALUES
            (S_CUSTOMER_OU.NEXTVAL, --ERPOU_ID,
             --ENTITY_ID,
             (SELECT CUSTOMER_ID
                FROM T_CUSTOMER_HEADER HEAD
               WHERE OU.CUSTOMER_CODE = HEAD.CUSTOMER_CODE), --CUSTOMER_ID,AND HEAD.ACTIVE_FLAG = 'Active'
             OU.CUSTOMER_CODE,
             OU.ERPOU,
             OU.COUNTRY,
             OU.PROVINCE,
             OU.ADDRESS,
             NVL(OU.ACTIVE_FLAG, 'Active'),
             OU.CREATED_BY,
             OU.CREATION_DATE,
             OU.LAST_UPDATE_DATE,
             OU.LAST_UPDATE_BY,
             OU.LAST_INTERFACE_DATE,
             OU.SIEBEL_ERPOU_ID,
             OU.SIEBEL_CUSTOMER_ID,
             OU.PRE_FIELD_01,
             OU.PRE_FIELD_02,
             OU.PRE_FIELD_03,
             OU.PRE_FIELD_04,
             OU.PRE_FIELD_05,
             OU.PRE_FIELD_06);
          /* FROM INTF_CUSTOMER_OU INTF
          WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        
        ELSE
          UPDATE T_CUSTOMER_OU
             SET (
                  --ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  ERPOU,
                  COUNTRY,
                  PROVINCE,
                  ADDRESS,
                  ACTIVE_FLAG,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_ERPOU_ID,
                  SIEBEL_CUSTOMER_ID,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06) =
                 (SELECT (SELECT CUSTOMER_ID
                            FROM T_CUSTOMER_HEADER HEAD
                           WHERE OU.CUSTOMER_CODE = HEAD.CUSTOMER_CODE) CUSTOMER_ID, --AND HEAD.ACTIVE_FLAG = 'Active'
                         OU.CUSTOMER_CODE,
                         OU.ERPOU,
                         OU.COUNTRY,
                         OU.PROVINCE,
                         OU.ADDRESS,
                         NVL(OU.ACTIVE_FLAG, 'Active'),
                         OU.CREATED_BY,
                         OU.CREATION_DATE,
                         OU.LAST_UPDATE_DATE,
                         OU.LAST_UPDATE_BY,
                         OU.LAST_INTERFACE_DATE,
                         OU.SIEBEL_ERPOU_ID,
                         OU.SIEBEL_CUSTOMER_ID,
                         OU.PRE_FIELD_01,
                         OU.PRE_FIELD_02,
                         OU.PRE_FIELD_03,
                         OU.PRE_FIELD_04,
                         OU.PRE_FIELD_05,
                         OU.PRE_FIELD_06
                    FROM DUAL)
           WHERE SIEBEL_ERPOU_ID = OU.SIEBEL_ERPOU_ID;
          /* FROM INTF_CUSTOMER_OU INTF
                       WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID
                         AND INTF.SIEBEL_ERPOU_ID = OU.SIEBEL_ERPOU_ID)
                       WHERE EXISTS (SELECT 1 FROM INTF_CUSTOMER_OU INTFX WHERE INTFX.PRE_FIELD_01 = P_INTF_HEAD_ID AND INTFX.SIEBEL_ERPOU_ID = OU.SIEBEL_ERPOU_ID);
          */
        END IF;
        UPDATE INTF_CUSTOMER_OU
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = P_MESSAGE,
               OPERSTATUS      = '0'
         WHERE ERPOU_ID = OU.ERPOU_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN      
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_OU',
                                              SQLCODE,
                                              '插入OU失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_OU
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE ERPOU_ID = OU.ERPOU_ID;
          COMMIT;
          --RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
    RETURN P_MESSAGE;
  END F_INSERT_OR_UPDATE_OU;

  FUNCTION F_INSERT_OR_UPDATE_ORG
  --更新或插入客户组织业务表
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2 IS
    VT_ORG_FATHER_TIME     UP_CODELIST.CODE_VALUE%TYPE;
    VT_ORG_FATHER_TIME_FM  UP_CODELIST.CODE_VALUE%TYPE;
    VT_CUST_FATHER_CODE    T_CUSTOMER_HEADER.CUSTOMER_FATHER_CODE%TYPE;
    V_CUST_ORG_ACTIVE_FLAG T_CUSTOMER_ORG.ACTIVE_FLAG%TYPE;
    V_CUST_ORG_NAME        T_CUSTOMER_ORG.SALES_CENTER_NAME%TYPE; --业务表中的组织名称
    P_MESSAGE              VARCHAR2(500);
    V_CHECK_MSG            VARCHAR2(4000);
    V_SALES_CENTER_ID      UP_ORG_UNIT.UNIT_ID%TYPE;
    ORG                    INTF_CUSTOMER_ORG%ROWTYPE;
  
    --V_COUNT  NUMBER;
    --V_COUNT1 NUMBER;
  
    DEPT    T_CUSTOMER_DEPT%ROWTYPE;
    UNIT    UP_ORG_UNIT%ROWTYPE;
    UNIT_SR UP_ORG_UNIT%ROWTYPE;
    CURSOR C_INTF_CUSTOMER_ORG IS
      SELECT *
        FROM INTF_CUSTOMER_ORG
       WHERE PRE_FIELD_01 = TO_CHAR(P_INTF_HEAD_ID)
         AND (RESPONSETYPE IS NULL);
   
    TYPE T_INTF_ORG IS TABLE OF INTF_CUSTOMER_ORG%ROWTYPE INDEX BY BINARY_INTEGER;
    V_INTF_ORG T_INTF_ORG;
    V_INDEX     NUMBER; 

    V_ACCOUNT_COUNT NUMBER; --账户数（当前客户、主体）
    V_INTF_CUSTOMER_DEPT INTF_CUSTOMER_DEPT%ROWTYPE;
    V_ACTIVE_ACCOUNT_FALG VARCHAR2(2); --生效账户标识
  BEGIN
    --如果不满足先决条件，执行如下更新后，后面游标取不到数据，相当于执行结束
    UPDATE INTF_CUSTOMER_ORG U
       SET U.RESPONSETYPE    = 'E'
          ,U.RESPNOSECODE    = '000013'
          ,U.RESPONSEMESSAGE = '处理前提：中心所在事业部[SIEBEL_ID=' || U.PARENT_ID ||
                               ']在正式表T_CUSTOMER_DEPT不存在记录，即INTF_CUSTOMER_DEPT【三（事业部信息）】不存在处理成功的记录'
          ,U.OPERSTATUS      = '1'
     WHERE U.PRE_FIELD_01 = TO_CHAR(P_INTF_HEAD_ID)
       AND NOT EXISTS
     (SELECT 1 FROM T_CUSTOMER_DEPT D WHERE D.SIEBEL_ID = U.PARENT_ID);
    
    --查看主数据客户头ID是否存在
    OPEN C_INTF_CUSTOMER_ORG;
    FETCH C_INTF_CUSTOMER_ORG BULK COLLECT INTO V_INTF_ORG;
    CLOSE C_INTF_CUSTOMER_ORG;
    V_INDEX := (V_INTF_ORG.FIRST - 1);
    LOOP
      <<LOOP_HERE>>
      V_INDEX := (1 + V_INDEX);
      IF V_INDEX IS NULL OR V_INDEX > V_INTF_ORG.LAST THEN
        EXIT;
      END IF;
      ORG := V_INTF_ORG(V_INDEX);
      P_MESSAGE := 'SUCCESS';
      BEGIN       
        SELECT (SELECT UNIT.UNIT_ID
                  FROM UP_ORG_UNIT UNIT
                 WHERE UNIT.CODE = ORG.SALES_CENTER_CODE
                   AND 'T' = UNIT.IS_ENABLED
                   AND 'T' = UNIT.ACTIVE_FLAG)
          INTO V_SALES_CENTER_ID
          FROM DUAL;

        IF V_SALES_CENTER_ID IS NULL THEN
          UPDATE INTF_CUSTOMER_ORG
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = '中心编码在内销不存在:' || ORG.SALES_CENTER_CODE
                                   || '(在UP_ORG_UNIT表不存在或已失效，需要在CRM走客户主数据流程)',
                 OPERSTATUS      = '1'
           WHERE CUSTOMER_ORG_ID = ORG.CUSTOMER_ORG_ID;
          COMMIT;
          GOTO LOOP_HERE;
        END IF;
        
        SELECT T.*
          INTO UNIT
          FROM UP_ORG_UNIT T
         WHERE T.UNIT_ID = V_SALES_CENTER_ID;

        IF UNIT.ENTITY_ID IS NULL THEN
          UPDATE INTF_CUSTOMER_ORG
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = '中心在UP_ORG_UNIT表中主体（ENTITY_ID）字段为空:' || ORG.SALES_CENTER_CODE,
                 OPERSTATUS      = '1'
           WHERE CUSTOMER_ORG_ID = ORG.CUSTOMER_ORG_ID;
          COMMIT;
          GOTO LOOP_HERE;
        END IF;

        IF UNIT.TYPE_CODE IS NULL THEN
          UPDATE INTF_CUSTOMER_ORG
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = '中心在UP_ORG_UNIT表中组织类型（TYPE_CODE）字段为空:' || ORG.SALES_CENTER_CODE,
                 OPERSTATUS      = '1'
           WHERE CUSTOMER_ORG_ID = ORG.CUSTOMER_ORG_ID;
          COMMIT;
          GOTO LOOP_HERE;
        END IF;

        IF UNIT.TYPE_CODE IN ('BU', 'MC') THEN
          UPDATE INTF_CUSTOMER_ORG
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = '组织编码不能是事业部或内销总公司编码:' || ORG.SALES_CENTER_CODE,
                 OPERSTATUS      = '1'
           WHERE CUSTOMER_ORG_ID = ORG.CUSTOMER_ORG_ID;
          COMMIT;
          GOTO LOOP_HERE;
        END IF;
        
        SELECT D.*
          INTO DEPT
          FROM T_CUSTOMER_DEPT D
         WHERE D.SIEBEL_ID = ORG.PARENT_ID;

        IF DEPT.DEPT_ID IS NOT NULL AND UNIT.ENTITY_ID <> DEPT.DEPT_ID THEN
          UPDATE INTF_CUSTOMER_ORG
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = '中心编码在对应主体不存在:' || ORG.SALES_CENTER_CODE,
                 OPERSTATUS      = '1'
           WHERE CUSTOMER_ORG_ID = ORG.CUSTOMER_ORG_ID;
          COMMIT;
          GOTO LOOP_HERE;
        END IF;
      
        --关联销售大区
        BEGIN
          SELECT R.*
            INTO UNIT_SR
            FROM UP_ORG_UNIT R
           WHERE R.UNIT_ID = UNIT.PAR_UNIT_ID
             AND R.TYPE_CODE = 'SR'
             AND R.IS_ENABLED = 'T';
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
      
        SELECT T.SALES_CENTER_NAME, T.ACTIVE_FLAG
          INTO V_CUST_ORG_NAME, V_CUST_ORG_ACTIVE_FLAG
          FROM DUAL
          LEFT JOIN T_CUSTOMER_ORG T
            ON (T.SIEBEL_ORG_ID = ORG.SIEBEL_ORG_ID);

        V_ACTIVE_ACCOUNT_FALG := 'N';
        --正式表中心已失效，本次接口推送生效中心，且只有一个账户，则自动生效账户
        IF V_CUST_ORG_ACTIVE_FLAG = 'Inactive'
          AND ORG.ACTIVE_FLAG = 'Active' THEN
          --判断是否【只有一个账户并且分配给当前推送的营销中心】
          SELECT COUNT(0)
            INTO V_ACCOUNT_COUNT
            FROM T_CUSTOMER_ACCOUNT T
           WHERE T.ENTITY_ID = UNIT.ENTITY_ID
             AND T.CUSTOMER_CODE = DEPT.CUSTOMER_CODE
             AND EXISTS
           (SELECT 1
                    FROM T_CUSTOMER_ACCOUNT A1
                   WHERE A1.ACCOUNT_ID = T.ACCOUNT_ID
                     AND A1.SALES_CENTER_CODE = ORG.SALES_CENTER_CODE)
             AND NOT EXISTS
           (SELECT 1
                    FROM T_CUSTOMER_ACCOUNT A2
                   WHERE A2.ACCOUNT_ID = T.ACCOUNT_ID
                     AND A2.SALES_CENTER_CODE <> ORG.SALES_CENTER_CODE)
          ;
          --如果本次推送是生效事业部或者没有推送事业部信息而正式表事业部是有效的，则自动生效账户
          IF V_ACCOUNT_COUNT = 1 THEN
            BEGIN
              SELECT *
                INTO V_INTF_CUSTOMER_DEPT
                FROM INTF_CUSTOMER_DEPT D
               WHERE D.PRE_FIELD_01 = TO_CHAR(P_INTF_HEAD_ID)
                 AND D.SIEBEL_ID = ORG.PARENT_ID;
              IF V_INTF_CUSTOMER_DEPT.ACTIVE_FLAG = 'Active' THEN
                V_ACTIVE_ACCOUNT_FALG := 'Y';
              END IF;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                IF DEPT.ACTIVE_FLAG = 'Active' THEN
                  V_ACTIVE_ACCOUNT_FALG := 'Y';
                END IF;
            END;
          END IF;
          --生效账户
          IF V_ACTIVE_ACCOUNT_FALG = 'Y' THEN
            UPDATE T_CUSTOMER_ACCOUNT A
               SET A.ACCOUNT_STATUS = '1'
                  ,A.ACTIVE_FLAG = 'Y'
                  ,A.LAST_UPDATE_DATE = SYSDATE
                  ,A.LAST_UPDATE_BY = 'system'
             WHERE A.ACCOUNT_STATUS = '2'
               AND A.ACTIVE_FLAG = 'N'
               AND A.ENTITY_ID = UNIT.ENTITY_ID
               AND A.CUSTOMER_CODE = DEPT.CUSTOMER_CODE
               AND A.SALES_CENTER_CODE = ORG.SALES_CENTER_CODE
            ;
          END IF;
        END IF;

        IF ORG.ACTIVE_FLAG = 'Inactive' AND
           'Inactive' <> V_CUST_ORG_ACTIVE_FLAG THEN
          --系统初始化账户，CIMS业务、CRM业务没有感知，如果上游失效
          --避免CIMS、CRM的中心不一致，又避免业务处理账务的麻烦，保守的检查未完成单据，不检查余额
          SELECT DECODE(M,
                        NULL,
                        (F_CUSTORG_CHECK_UNDO(NULL,
                                              NULL,
                                              NULL,
                                              NULL,
                                              NULL,
                                              ORG.SIEBEL_ORG_ID,
                                              NULL,
                                              2,
                                              1)),--系统初始化账户，仅检查未完成发货计划、发货通知单
                        '业务账户' || M)
            INTO V_CHECK_MSG
            FROM (SELECT F_CUSTORG_CHECK_UNDO(NULL,
                                              NULL,
                                              NULL,
                                              NULL,
                                              NULL,
                                              ORG.SIEBEL_ORG_ID,
                                              NULL,
                                              1) AS M--非系统初始化账户，检查所有
                    FROM DUAL);
          
          IF 'SUCCESS' <> NVL(V_CHECK_MSG, 'SUCCESS') THEN
            IF '业务账户' = SUBSTR(V_CHECK_MSG,1,4) THEN
              V_CHECK_MSG := SUBSTR(V_CHECK_MSG,5);
            ELSE
              ORG.ACTIVE_FLAG := 'Freezing';
              P_MESSAGE := P_MESSAGE || '：' || V_CHECK_MSG;
              GOTO IN_UP;
            END IF;
            BEGIN
              UPDATE INTF_CUSTOMER_ORG
                 SET RESPONSETYPE    = 'E',
                     RESPNOSECODE    = '000013',
                     RESPONSEMESSAGE = '失效校验错误:' || V_CHECK_MSG,
                     OPERSTATUS      = '1'
               WHERE CUSTOMER_ORG_ID = ORG.CUSTOMER_ORG_ID;
              COMMIT;
            EXCEPTION
              WHEN OTHERS THEN
                UPDATE INTF_CUSTOMER_ORG
                   SET RESPONSETYPE    = 'E',
                       RESPNOSECODE    = '000013',
                       RESPONSEMESSAGE = '失效校验错误:' ||
                                         SUBSTR(V_CHECK_MSG, 1, 400),
                       OPERSTATUS      = '1'
                 WHERE CUSTOMER_ORG_ID = ORG.CUSTOMER_ORG_ID;
                COMMIT;
            END;
            GOTO LOOP_HERE;
          END IF;
        END IF;
        <<IN_UP>>
      
        SELECT (SELECT CL.CODE_VALUE
                  FROM UP_CODELIST CL
                 WHERE CL.CODETYPE = 'cust_org_fathercode'
                   AND CL.CODE_NAME = '中心关联客户切换时间')
          INTO VT_ORG_FATHER_TIME
          FROM DUAL;
        SELECT (SELECT CL.CODE_VALUE
                  FROM UP_CODELIST CL
                 WHERE CL.CODETYPE = 'cust_org_fathercode'
                   AND CL.CODE_NAME = '中心关联客户切换时间格式')
          INTO VT_ORG_FATHER_TIME_FM
          FROM DUAL;
        
        IF VT_ORG_FATHER_TIME IS NOT NULL OR VT_ORG_FATHER_TIME IS NOT NULL THEN 
          VT_ORG_FATHER_TIME := NVL(VT_ORG_FATHER_TIME,'2017-11-24 23:00:00');
          VT_ORG_FATHER_TIME_FM := NVL(VT_ORG_FATHER_TIME_FM,'YYYY-MM-DD HH24:MI:SS');
          --2017-11-24 23之前，取客户头的关联客户编码作为中心关联客户编码
          --2017-11-24 23之后，当客户所在事业部存在中心关联客户编码不为空的客户中心推送记录才取推送记录
          --否则仍然取客户头的关联客户编码作为中心关联客户编码
          SELECT DECODE(CUST_FATHER_CODE,
                        NULL,
                        ORG.ORG_CUSTOMER_FATHER_CODE,
                        CUST_FATHER_CODE)
            INTO ORG.ORG_CUSTOMER_FATHER_CODE
            FROM (SELECT --CH.CUSTOMER_FATHER_CODE,ET.*,
                   DECODE(ET.CUSTOMER_CODE, NULL, CH.CUSTOMER_FATHER_CODE) AS CUST_FATHER_CODE
                 --DECODE(ET.CUSTOMER_CODE,NULL,CH.CUSTOMER_FATHER_CODE) INTO VT_CUST_FATHER_CODE
                    FROM T_CUSTOMER_HEADER CH
                    LEFT JOIN (SELECT *
                                FROM (SELECT H.CUSTOMER_CODE
                                        FROM INTF_CUSTOMER_ORG ICO
                                       INNER JOIN T_CUSTOMER_HEADER H
                                          ON (H.CUSTOMER_CODE =
                                             ICO.ORG_CUSTOMER_FATHER_CODE)
                                       WHERE ICO.PARENT_ID = ORG.PARENT_ID
                                         AND LENGTH(ICO.ORG_CUSTOMER_FATHER_CODE) =
                                             LENGTHB(ICO.ORG_CUSTOMER_FATHER_CODE)
                                         AND ICO.LAST_INTERFACE_DATE >=
                                             TO_DATE(VT_ORG_FATHER_TIME,
                                                     VT_ORG_FATHER_TIME_FM)
                                       GROUP BY H.CUSTOMER_CODE
                                      HAVING COUNT(0) > 0)
                               WHERE 1 = ROWNUM) ET
                      ON (1 = 1)
                  --) ET ON (ET.CUSTOMER_CODE IS NULL)
                   WHERE CH.CUSTOMER_ID = DEPT.CUSTOMER_ID);
          /*IF VT_CUST_FATHER_CODE IS NOT NULL THEN
            ORG.ORG_CUSTOMER_FATHER_CODE := VT_CUST_FATHER_CODE;
          END IF;*/  
        END IF;
        
        IF (V_CUST_ORG_NAME IS NULL) THEN
          INSERT INTO T_CUSTOMER_ORG
            (CUSTOMER_ORG_ID,
             ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             SALES_CENTER_ID,
             SALES_CENTER_CODE,
             SALES_REGION_ID,
             SALES_REGION_CODE,
             DEPT_ID,
             DEPT_CODE,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_ORG_ID,
             SIEBEL_CUSTOMER_ID,
             ACTIVE_FLAG,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06,
             SALES_CENTER_NAME,
             PARENT_ID,
             ORG_CUSTOMER_FATHER_CODE,
             COOPERATION_MODEL)
          --SELECT
          VALUES
            (NVL(ORG.PRE_FIELD_02, S_CUSTOMER_ORG.NEXTVAL), --CUSTOMER_ORG_ID,
             --(SELECT UNIT.ENTITY_ID FROM UP_ORG_UNIT UNIT WHERE UNIT.CODE = (SELECT DEPT.DEPT_CODE FROM T_CUSTOMER_DEPT DEPT WHERE DEPT.SIEBEL_ID = INTF.PARENT_ID)) ENTITY_ID,
             DEPT.DEPT_ID, --ENTITY_ID,
             DEPT.CUSTOMER_ID, --CUSTOMER_ID,
             DEPT.CUSTOMER_CODE, --CUSTOMER_CODE,
             V_SALES_CENTER_ID, --SALES_CENTER_ID,
             ORG.SALES_CENTER_CODE,
             UNIT_SR.UNIT_ID, --SALES_REGION_ID,
             UNIT_SR.CODE, --SALES_REGION_CODE,
             DEPT.DEPT_ID, --DEPT_ID,
             DEPT.DEPT_CODE, --DEPT_CODE,
             ORG.CREATED_BY,
             ORG.CREATION_DATE,
             ORG.LAST_UPDATE_DATE,
             ORG.LAST_UPDATE_BY,
             ORG.LAST_INTERFACE_DATE,
             ORG.SIEBEL_ORG_ID,
             ORG.SIEBEL_CUSTOMER_ID,
             NVL(ORG.ACTIVE_FLAG, 'Active'),
             ORG.PRE_FIELD_01,
             ORG.PRE_FIELD_02,
             ORG.PRE_FIELD_03,
             ORG.PRE_FIELD_04,
             ORG.PRE_FIELD_05,
             ORG.PRE_FIELD_06,
             UNIT.NAME, --SALES_CENTER_NAME,
             DEPT.ID,
             --add by liangym2 2017-11-20 中心关联客户编码，取报文预留字段1，保存到接口表的预留字段5
             DECODE(LENGTH(ORG.ORG_CUSTOMER_FATHER_CODE),
                    LENGTHB(ORG.ORG_CUSTOMER_FATHER_CODE),
                    ORG.ORG_CUSTOMER_FATHER_CODE,
                    NULL),
             ORG.COOPERATION_MODEL
             --(CASE WHEN ORG.ACTIVE_FLAG IN ('Active', 'Freezing') THEN ORG.COOPERATION_MODEL ELSE NULL END)
             ); --PARENT_ID);
        
          /* FROM INTF_CUSTOMER_ORG INTF
          WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        
        ELSE
          UPDATE T_CUSTOMER_ORG
             SET (ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  SALES_CENTER_ID,
                  SALES_CENTER_CODE,
                  SALES_REGION_ID,
                  SALES_REGION_CODE,
                  DEPT_ID,
                  DEPT_CODE,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_ORG_ID,
                  SIEBEL_CUSTOMER_ID,
                  ACTIVE_FLAG,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06,
                  SALES_CENTER_NAME,
                  PARENT_ID,
                  ORG_CUSTOMER_FATHER_CODE,
                  COOPERATION_MODEL) =
                 (SELECT
                  --(SELECT UNIT.ENTITY_ID FROM UP_ORG_UNIT UNIT WHERE UNIT.CODE = (SELECT DEPT.DEPT_CODE FROM T_CUSTOMER_DEPT DEPT WHERE DEPT.SIEBEL_ID = INTF.PARENT_ID)) ENTITY_ID,
                   DEPT.DEPT_ID ENTITY_ID,
                   DEPT.CUSTOMER_ID CUSTOMER_ID,
                   DEPT.CUSTOMER_CODE CUSTOMER_CODE,
                   V_SALES_CENTER_ID,
                   ORG.SALES_CENTER_CODE,
                   UNIT_SR.UNIT_ID SALES_REGION_ID,
                   UNIT_SR.CODE SALES_REGION_CODE,
                   DEPT.DEPT_ID DEPT_ID,
                   DEPT.DEPT_CODE DEPT_CODE,
                   ORG.CREATED_BY,
                   ORG.CREATION_DATE,
                   ORG.LAST_UPDATE_DATE,
                   ORG.LAST_UPDATE_BY,
                   ORG.LAST_INTERFACE_DATE,
                   ORG.SIEBEL_ORG_ID,
                   ORG.SIEBEL_CUSTOMER_ID,
                   NVL(ORG.ACTIVE_FLAG, 'Active'),
                   ORG.PRE_FIELD_01,
                   ORG.PRE_FIELD_02,
                   ORG.PRE_FIELD_03,
                   ORG.PRE_FIELD_04,
                   ORG.PRE_FIELD_05,
                   ORG.PRE_FIELD_06,
                   UNIT.NAME SALES_CENTER_NAME,
                   DEPT.ID PARENT_ID,
                   --add by liangym2 2017-11-20 中心关联客户编码，取报文预留字段1
                   DECODE(LENGTH(org.ORG_CUSTOMER_FATHER_CODE),
                          LENGTHB(org.ORG_CUSTOMER_FATHER_CODE),
                          ORG.ORG_CUSTOMER_FATHER_CODE,
                          NULL),
                   ORG.COOPERATION_MODEL
                   --(CASE WHEN ORG.ACTIVE_FLAG IN ('Active', 'Freezing') THEN ORG.COOPERATION_MODEL ELSE NULL END)
                    FROM DUAL)
           WHERE SIEBEL_ORG_ID = ORG.SIEBEL_ORG_ID;
          /*  FROM INTF_CUSTOMER_ORG INTF
                       WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID
                         AND INTF.SIEBEL_ORG_ID = ORG.SIEBEL_ORG_ID)
                       WHERE EXISTS (SELECT 1 FROM INTF_CUSTOMER_ORG INTFX  WHERE INTFX.PRE_FIELD_01 = P_INTF_HEAD_ID  AND INTFX.SIEBEL_ORG_ID = ORG.SIEBEL_ORG_ID);
          */
          IF V_CUST_ORG_NAME <> UNIT.NAME THEN
            --当基础数据中心名称更改时，仅更新业务表时更新冗余字段 2016-4-13
            UPDATE T_CUSTOMER_ORG O
               SET O.SALES_CENTER_NAME = UNIT.NAME,
                   O.LAST_UPDATE_DATE  = SYSDATE
             WHERE O.ENTITY_ID = DEPT.DEPT_ID
               AND O.SALES_CENTER_CODE = ORG.SALES_CENTER_CODE --UNIT.CODE
               AND O.SALES_CENTER_NAME = V_CUST_ORG_NAME;
            UPDATE T_CREDIT_DISCOUNT_AMOUNT O
               SET O.SALES_CENTER_NAME = UNIT.NAME,
                   O.LAST_UPDATE_DATE  = SYSDATE
             WHERE O.ENTITY_ID = DEPT.DEPT_ID
               AND O.SALES_CENTER_CODE = ORG.SALES_CENTER_CODE --UNIT.CODE
               AND O.SALES_CENTER_NAME = V_CUST_ORG_NAME;
            UPDATE T_BD_PRICE_LIST O
               SET O.UNIT_NAME = UNIT.NAME,
                   O.LAST_UPDATE_DATE  = SYSDATE
             WHERE O.ENTITY_ID = DEPT.DEPT_ID
               AND O.UNIT_CODE = ORG.SALES_CENTER_CODE --UNIT.CODE
               AND O.UNIT_NAME = V_CUST_ORG_NAME;
            UPDATE T_BD_PRICE_LIST O
               SET O.USER_UNIT_NAME = UNIT.NAME,
                   O.LAST_UPDATE_DATE  = SYSDATE
             WHERE O.ENTITY_ID = DEPT.DEPT_ID
               AND O.USER_UNIT_CODE = ORG.SALES_CENTER_CODE --UNIT.CODE
               AND O.USER_UNIT_NAME = V_CUST_ORG_NAME;
            UPDATE T_CUSTOMER_ACCOUNT O
               SET O.SALES_CENTER_NAME = UNIT.NAME,
                   O.LAST_UPDATE_DATE  = SYSDATE
             WHERE O.ENTITY_ID = DEPT.DEPT_ID
               AND O.SALES_CENTER_CODE = ORG.SALES_CENTER_CODE --UNIT.CODE
               AND O.SALES_CENTER_NAME = V_CUST_ORG_NAME;
            UPDATE T_BD_PRICE_SYSTEM_ORG O
               SET O.SALES_CENTER_NAME = UNIT.NAME,
                   O.LAST_UPDATE_DATE  = SYSDATE
             WHERE O.ENTITY_ID = DEPT.DEPT_ID
               AND O.SALES_CENTER_CODE = ORG.SALES_CENTER_CODE --UNIT.CODE
               AND O.SALES_CENTER_NAME = V_CUST_ORG_NAME;
          END IF;
        END IF;

        IF LENGTH(ORG.ORG_CUSTOMER_FATHER_CODE) = LENGTHB(ORG.ORG_CUSTOMER_FATHER_CODE) THEN
        --IF ORG.ORG_CUSTOMER_FATHER_CODE IS NOT NULL THEN
          UPDATE T_CUSTOMER_ORG UO
             SET (UO.ORG_CUSTOMER_FATHER_ID, UO.ORG_CUSTOMER_FATHER_NAME) =
                 (SELECT H.CUSTOMER_ID, H.CUSTOMER_NAME
                    FROM T_CUSTOMER_HEADER H
                   WHERE H.CUSTOMER_CODE = UO.ORG_CUSTOMER_FATHER_CODE
                     AND 1 = ROWNUM)
           WHERE UO.SIEBEL_ORG_ID = ORG.SIEBEL_ORG_ID
             AND UO.ORG_CUSTOMER_FATHER_CODE = ORG.ORG_CUSTOMER_FATHER_CODE;
        END IF;
        
        UPDATE INTF_CUSTOMER_ORG
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = P_MESSAGE,
               OPERSTATUS      = '0'
         WHERE CUSTOMER_ORG_ID = ORG.CUSTOMER_ORG_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_ORG',
                                              SQLCODE,
                                              '插入客户中心关系业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_ORG
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE CUSTOMER_ORG_ID = ORG.CUSTOMER_ORG_ID;
          COMMIT;
          BEGIN
            DELETE FROM T_CUSTOMER_ACCOUNT A
             WHERE EXISTS
             (SELECT 1
                      FROM T_CUSTOMER_ACC_ORG_RELATION R
                     WHERE EXISTS
                     (SELECT 1
                              FROM INTF_CUSTOMER_ORG IO
                             WHERE IO.CUSTOMER_ORG_ID = ORG.CUSTOMER_ORG_ID
                               AND TO_NUMBER(IO.PRE_FIELD_02) = R.CUSTOMER_ORG_ID
                               AND '000000' <> IO.RESPNOSECODE
                               AND NOT EXISTS (SELECT 1 FROM T_CUSTOMER_ORG CO
                                     WHERE '' || CO.CUSTOMER_ORG_ID = IO.PRE_FIELD_02
                                       AND IO.SIEBEL_ORG_ID = CO.SIEBEL_ORG_ID))
                       AND R.ACCOUNT_ID = A.ACCOUNT_ID);
            IF 0 = SQL%ROWCOUNT THEN
              ROLLBACK;
              GOTO LOOP_HERE;
            END IF;
          
            DELETE FROM T_CUSTOMER_ACC_ORG_RELATION R
             WHERE EXISTS
             (SELECT 1
                      FROM INTF_CUSTOMER_ORG IO
                     WHERE IO.CUSTOMER_ORG_ID = ORG.CUSTOMER_ORG_ID
                       AND TO_NUMBER(IO.PRE_FIELD_02) = R.CUSTOMER_ORG_ID
                       AND '000000' <> IO.RESPNOSECODE
                       AND NOT EXISTS (SELECT 1 FROM T_CUSTOMER_ORG CO
                             WHERE '' || CO.CUSTOMER_ORG_ID = IO.PRE_FIELD_02
                               AND IO.SIEBEL_ORG_ID = CO.SIEBEL_ORG_ID));
            IF 0 = SQL%ROWCOUNT THEN
              ROLLBACK;
              --GOTO LOOP_HERE;
            END IF;
          
            COMMIT;
          EXCEPTION
            WHEN OTHERS THEN
              ROLLBACK;
          END;
          --RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
  
    RETURN P_MESSAGE;
  END F_INSERT_OR_UPDATE_ORG;

  FUNCTION F_INSERT_OR_UPDATE_MAIN_TYPE
  --更新或插入客户营销大类业务表（实际上营销大类接收是在品牌接收中处理的）
  (P_INTF_HEAD_ID NUMBER --客户头ID
   ) RETURN VARCHAR2 IS
    V_CUST_SALE_MAIN_TYPE_COUNT NUMBER; --业务表中营销大类信息数量
    P_MESSAGE                   VARCHAR2(500);
  
    CURSOR C_INTF_CUSTOMER_MAIN_TYPE IS
      SELECT *
        FROM INTF_CUSTOMER_SALES_MAIN_TYPE
       WHERE PRE_FIELD_01 = TO_CHAR(P_INTF_HEAD_ID);  
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --查看主数据客户头ID是否存在
    FOR MAINTYPE IN C_INTF_CUSTOMER_MAIN_TYPE LOOP
      BEGIN
        SELECT COUNT(0)
          INTO V_CUST_SALE_MAIN_TYPE_COUNT
          FROM T_CUSTOMER_SALES_MAIN_TYPE
         WHERE SIEBEL_PRODUCT_ID = MAINTYPE.SIEBEL_PRODUCT_ID;
      
        IF (V_CUST_SALE_MAIN_TYPE_COUNT = 0) THEN
          INSERT INTO T_CUSTOMER_SALES_MAIN_TYPE
            (SALES_MAIN_TYPE_ID,
             ENTITY_ID,
             CUSTOM_ID,
             CUSTOM_CODE,
             DEPT_ID,
             DEPT_CODE,
             SALES_MAIN_TYPE_NAME,
             CUSTOM_LEVEL,
             CUSTOM_CREDIT_LEVEL,
             CREDIT_LINE,
             COOPERATION_MODEL_ID,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATE_DATE,
             LAST_UPDATE_BY,
             LAST_INTERFACE_DATE,
             SIEBEL_PRODUCT_ID,
             SIEBEL_CUSTOMER_ID,
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06,
             SALES_MAIN_TYPE_CODE,
             PARENT_ID)
          --SELECT
          VALUES
            (S_CUSTOMER_SALES_MAIN_TYPE.NEXTVAL, --SALES_MAIN_TYPE_ID,
             (SELECT DEPT.DEPT_ID
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = MAINTYPE.PARENT_ID), --ENTITY_ID,
             (SELECT DEPT.CUSTOMER_ID
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = MAINTYPE.PARENT_ID), --CUSTOMER_ID,
             (SELECT DEPT.CUSTOMER_CODE
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = MAINTYPE.PARENT_ID), --CUSTOMER_CODE,
             (SELECT DEPT.DEPT_ID
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = MAINTYPE.PARENT_ID), --DEPT_ID,
             (SELECT DEPT.DEPT_CODE
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = MAINTYPE.PARENT_ID), --DEPT_CODE,
             (SELECT CODELIST.CODE_NAME
                FROM UP_CODELIST CODELIST
               WHERE CODELIST.CODE_VALUE = MAINTYPE.SALES_MAIN_TYPE_CODE
                 AND CODELIST.CODETYPE = 'MIDEA_ACCOUNT_PROD_TYPE'), --SALES_MAIN_TYPE_NAME,
             MAINTYPE.CUSTOM_LEVEL,
             MAINTYPE.CUSTOM_CREDIT_LEVEL,
             MAINTYPE.CREDIT_LINE,
             MAINTYPE.COOPERATION_MODEL_ID,
             NVL(MAINTYPE.ACTIVE_FLAG, 'Active'),
             MAINTYPE.CREATED_BY,
             MAINTYPE.CREATION_DATE,
             MAINTYPE.LAST_UPDATE_DATE,
             MAINTYPE.LAST_UPDATE_BY,
             MAINTYPE.LAST_INTERFACE_DATE,
             MAINTYPE.SIEBEL_PRODUCT_ID,
             MAINTYPE.SIEBEL_CUSTOMER_ID,
             MAINTYPE.PRE_FIELD_01,
             MAINTYPE.PRE_FIELD_02,
             MAINTYPE.PRE_FIELD_03,
             MAINTYPE.PRE_FIELD_04,
             MAINTYPE.PRE_FIELD_05,
             MAINTYPE.PRE_FIELD_06,
             MAINTYPE.SALES_MAIN_TYPE_CODE,
             (SELECT DEPT.ID
                FROM T_CUSTOMER_DEPT DEPT
               WHERE DEPT.SIEBEL_ID = MAINTYPE.PARENT_ID)); --PARENT_ID
          /*  FROM INTF_CUSTOMER_SALES_MAIN_TYPE INTF
          WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID;*/
        
        ELSE
          UPDATE T_CUSTOMER_SALES_MAIN_TYPE MAINTYPE
             SET (
                  --ENTITY_ID,
                  ENTITY_ID,
                  CUSTOM_ID,
                  CUSTOM_CODE,
                  DEPT_ID,
                  DEPT_CODE,
                  SALES_MAIN_TYPE_NAME,
                  CUSTOM_LEVEL,
                  CUSTOM_CREDIT_LEVEL,
                  CREDIT_LINE,
                  COOPERATION_MODEL_ID,
                  ACTIVE_FLAG,
                  CREATED_BY,
                  CREATION_DATE,
                  LAST_UPDATE_DATE,
                  LAST_UPDATE_BY,
                  LAST_INTERFACE_DATE,
                  SIEBEL_PRODUCT_ID,
                  SIEBEL_CUSTOMER_ID,
                  PRE_FIELD_01,
                  PRE_FIELD_02,
                  PRE_FIELD_03,
                  PRE_FIELD_04,
                  PRE_FIELD_05,
                  PRE_FIELD_06,
                  SALES_MAIN_TYPE_CODE,
                  PARENT_ID) =
                 (SELECT (SELECT DEPT.DEPT_ID
                            FROM T_CUSTOMER_DEPT DEPT
                           WHERE DEPT.SIEBEL_ID = MAINTYPE.PARENT_ID) ENTITY_ID,
                         (SELECT DEPT.CUSTOMER_ID
                            FROM T_CUSTOMER_DEPT DEPT
                           WHERE DEPT.SIEBEL_ID = MAINTYPE.PARENT_ID) CUSTOMER_ID,
                         (SELECT DEPT.CUSTOMER_CODE
                            FROM T_CUSTOMER_DEPT DEPT
                           WHERE DEPT.SIEBEL_ID = MAINTYPE.PARENT_ID) CUSTOMER_CODE,
                         (SELECT DEPT.DEPT_ID
                            FROM T_CUSTOMER_DEPT DEPT
                           WHERE DEPT.SIEBEL_ID = MAINTYPE.PARENT_ID) DEPT_ID,
                         (SELECT DEPT.DEPT_CODE
                            FROM T_CUSTOMER_DEPT DEPT
                           WHERE DEPT.SIEBEL_ID = MAINTYPE.PARENT_ID) DEPT_CODE,
                         (SELECT CODELIST.CODE_NAME
                            FROM UP_CODELIST CODELIST
                           WHERE CODELIST.CODE_VALUE =
                                 MAINTYPE.SALES_MAIN_TYPE_CODE
                             AND CODELIST.CODETYPE =
                                 'MIDEA_ACCOUNT_PROD_TYPE') SALES_MAIN_TYPE_NAME,
                         MAINTYPE.CUSTOM_LEVEL,
                         MAINTYPE.CUSTOM_CREDIT_LEVEL,
                         MAINTYPE.CREDIT_LINE,
                         MAINTYPE.COOPERATION_MODEL_ID,
                         NVL(MAINTYPE.ACTIVE_FLAG, 'Active'),
                         MAINTYPE.CREATED_BY,
                         MAINTYPE.CREATION_DATE,
                         MAINTYPE.LAST_UPDATE_DATE,
                         MAINTYPE.LAST_UPDATE_BY,
                         MAINTYPE.LAST_INTERFACE_DATE,
                         MAINTYPE.SIEBEL_PRODUCT_ID,
                         MAINTYPE.SIEBEL_CUSTOMER_ID,
                         MAINTYPE.PRE_FIELD_01,
                         MAINTYPE.PRE_FIELD_02,
                         MAINTYPE.PRE_FIELD_03,
                         MAINTYPE.PRE_FIELD_04,
                         MAINTYPE.PRE_FIELD_05,
                         MAINTYPE.PRE_FIELD_06,
                         MAINTYPE.SALES_MAIN_TYPE_CODE,
                         (SELECT DEPT.ID
                            FROM T_CUSTOMER_DEPT DEPT
                           WHERE DEPT.SIEBEL_ID = MAINTYPE.PARENT_ID) PARENT_ID
                    FROM DUAL)
           WHERE SIEBEL_PRODUCT_ID = MAINTYPE.SIEBEL_PRODUCT_ID;
          /* FROM INTF_CUSTOMER_SALES_MAIN_TYPE INTF
                       WHERE INTF.PRE_FIELD_01 = P_INTF_HEAD_ID
                         AND INTF.SIEBEL_PRODUCT_ID = MAINTYPE.SIEBEL_PRODUCT_ID)
                       WHERE EXISTS (SELECT 1 FROM INTF_CUSTOMER_SALES_MAIN_TYPE INTFX WHERE INTFX.PRE_FIELD_01 = P_INTF_HEAD_ID AND INTFX.SIEBEL_PRODUCT_ID = MAINTYPE.SIEBEL_PRODUCT_ID);
          */
        END IF;
        UPDATE INTF_CUSTOMER_SALES_MAIN_TYPE
           SET RESPONSETYPE    = 'N',
               RESPNOSECODE    = '000000',
               RESPONSEMESSAGE = P_MESSAGE,
               OPERSTATUS      = '0'
         WHERE SALES_MAIN_TYPE_ID = MAINTYPE.SALES_MAIN_TYPE_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --记录出错信息
          P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CUSTOMER_INTF.P_CUSTOMER_INTF_PROC.F_INSERT_OR_UPDATE_MAIN_TYPE',
                                              SQLCODE,
                                              '插入营销大类业务表失败！：' || SQLERRM);
          UPDATE INTF_CUSTOMER_SALES_MAIN_TYPE
             SET RESPONSETYPE    = 'E',
                 RESPNOSECODE    = '000013',
                 RESPONSEMESSAGE = P_MESSAGE,
                 OPERSTATUS      = '1'
           WHERE SALES_MAIN_TYPE_ID = MAINTYPE.SALES_MAIN_TYPE_ID;
          COMMIT;
          --RAISE V_BIZ_EXCEPTION;
      END;
    END LOOP;
    RETURN P_MESSAGE;
  END F_INSERT_OR_UPDATE_MAIN_TYPE;

  PROCEDURE PRC_UPDATE_STATUS_CHANGED
  --当客户头状态、事业部有效状态、事业部客户状态、组织状态变为失效、冻结时更新
  (P_INTF_HEAD_ID IN NUMBER, --客户头ID
   P_HEAD_ID      IN NUMBER --客户头ID
   ) IS
    V_COUNT                    NUMBER;
    V_CUSTOMER_ID              NUMBER;
    V_CUSTOMER_CODE            VARCHAR2(100);
    V_ACTIVE_FLAG              VARCHAR2(32);
    V_LOG_ACTIVE_FLAG          VARCHAR2(32);
    V_LOG_DEPT_CUSTOMER_STATUS VARCHAR2(32);
    V_DATETIME_CHAR            VARCHAR2(32) := TO_CHAR(SYSDATE,
                                                       'YYYYMMDDHH24MISS');
    CURSOR C_H_CHANGED(P_CUSTOMER_ID NUMBER) IS
      SELECT H.CUSTOMER_ID, H.CUSTOMER_STATUS, H.ACTIVE_FLAG
        FROM T_CUSTOMER_HEADER H
       WHERE H.CUSTOMER_ID = P_CUSTOMER_ID
         AND ((H.ACTIVE_FLAG = 'Inactive') OR
             (H.CUSTOMER_STATUS = 'Freezing' AND
             (H.ACTIVE_FLAG = 'Active' OR H.ACTIVE_FLAG = 'Freezing')))
         AND NOT EXISTS (SELECT 1
                FROM T_CUSTOMER_HEADER T
               WHERE T.SIEBEL_CUSTOMER_ID <> H.SIEBEL_CUSTOMER_ID
                 AND T.CUSTOMER_ID = H.CUSTOMER_ID
                 AND T.CUSTOMER_STATUS NOT IN ('Freezing', 'Inactive'));
    
    CURSOR C_H_DEPT_CHANGED(P_CUSTOMER_ID NUMBER, P_ACTIVE_FLAG VARCHAR2) IS
      SELECT D.ID, D.DEPT_ID, D.DEPT_CUSTOMER_STATUS, D.ACTIVE_FLAG
        FROM T_CUSTOMER_DEPT D
       WHERE D.CUSTOMER_ID = P_CUSTOMER_ID
         AND D.DEPT_ID IS NOT NULL
         AND ((P_ACTIVE_FLAG = 'Inactive' AND
             D.ACTIVE_FLAG <> P_ACTIVE_FLAG) OR
             (P_ACTIVE_FLAG = 'Freezing' AND
             (D.ACTIVE_FLAG <> 'Inactive' OR
             D.DEPT_CUSTOMER_STATUS <> 'Inactive') AND
             (D.ACTIVE_FLAG <> 'Active' OR
             D.DEPT_CUSTOMER_STATUS <> P_ACTIVE_FLAG)));
    
    CURSOR C_DEPT_CHANGED(P_CUSTOMER_ID NUMBER) IS
      SELECT D.ID, D.DEPT_ID, D.DEPT_CUSTOMER_STATUS, D.ACTIVE_FLAG
        FROM T_CUSTOMER_DEPT D
       WHERE D.CUSTOMER_ID = P_CUSTOMER_ID
         AND D.DEPT_ID IS NOT NULL
         AND ((D.ACTIVE_FLAG = 'Inactive') OR
             (D.DEPT_CUSTOMER_STATUS = 'Freezing' AND
             (D.ACTIVE_FLAG = 'Active' OR D.ACTIVE_FLAG = 'Freezing')))
         AND NOT EXISTS (SELECT 1
                FROM T_CUSTOMER_DEPT T
               WHERE T.SIEBEL_ID <> D.SIEBEL_ID
                 AND T.CUSTOMER_ID = D.CUSTOMER_ID
                 AND T.DEPT_ID = D.DEPT_ID
                 AND T.DEPT_CUSTOMER_STATUS NOT IN ('Freezing', 'Inactive'));
    
    CURSOR C_H_ORG_CHANGED(P_CUSTOMER_ID NUMBER,
                           P_ENTITY_ID   NUMBER,
                           P_ACTIVE_FLAG VARCHAR2) IS
      SELECT O.CUSTOMER_ORG_ID, O.ENTITY_ID, O.ACTIVE_FLAG
        FROM T_CUSTOMER_ORG O
       WHERE O.CUSTOMER_ID = P_CUSTOMER_ID
         AND P_ACTIVE_FLAG = 'Inactive'
         AND O.ACTIVE_FLAG <> P_ACTIVE_FLAG
         AND NVL(P_ENTITY_ID, O.ENTITY_ID) = O.ENTITY_ID
         AND O.SALES_CENTER_ID IS NOT NULL;
       --AND (P_ACTIVE_FLAG <> 'Freezing' OR (O.ACTIVE_FLAG <> 'Inactive'))

    CURSOR C_ORG_CHANGED(P_CUSTOMER_ID NUMBER) IS
      SELECT O.CUSTOMER_ORG_ID,
             O.ENTITY_ID,
             O.ACTIVE_FLAG,
             O.SALES_CENTER_CODE,
             O.SALES_CENTER_NAME
        FROM T_CUSTOMER_ORG O
       WHERE O.CUSTOMER_ID = P_CUSTOMER_ID
         AND O.ACTIVE_FLAG IN ('Freezing', 'Inactive')
         AND O.ENTITY_ID IS NOT NULL
         AND O.SALES_CENTER_ID IS NOT NULL
         AND NOT EXISTS (SELECT 1
                FROM T_CUSTOMER_ORG T
               WHERE T.SIEBEL_ORG_ID <> O.SIEBEL_ORG_ID
                 AND T.CUSTOMER_ID = O.CUSTOMER_ID
                 AND T.ENTITY_ID = O.ENTITY_ID
                 AND T.SALES_CENTER_ID = O.SALES_CENTER_ID
                 AND T.ACTIVE_FLAG NOT IN ('Freezing', 'Inactive'));
    
    CURSOR C_H_ACC_CHANGED(P_CUSTOMER_ID NUMBER,
                           P_ENTITY_ID   NUMBER,
                           P_ORG_ID      NUMBER,
                           P_ACTIVE_FLAG VARCHAR2) IS
      SELECT A.ACCOUNT_ID,
             A.ENTITY_ID,
             A.ACTIVE_FLAG,
             A.ACCOUNT_STATUS,
             A1.CUSTOMER_ORG_ID
        FROM T_CUSTOMER_ACCOUNT A
       INNER JOIN T_CUSTOMER_ACC_ORG_RELATION A1
          ON (A1.ACCOUNT_ID = A.ACCOUNT_ID)
       WHERE P_CUSTOMER_ID = A.CUSTOMER_ID
         AND NVL(P_ENTITY_ID, A.ENTITY_ID) = A.ENTITY_ID
         AND NVL(P_ORG_ID, A1.CUSTOMER_ORG_ID) = A1.CUSTOMER_ORG_ID
         AND ((P_ACTIVE_FLAG <> 'Freezing'
             --
             AND A.ACTIVE_FLAG <> DECODE(P_ACTIVE_FLAG, 'Active', 'Y', 'N')
             --
             AND A.ACCOUNT_STATUS <> DECODE(P_ACTIVE_FLAG, 'Active', '1', '2'))
             --冻结时仅将正常的账户冻结，对于失效的不能改为冻结
             OR (P_ACTIVE_FLAG = 'Freezing' AND A.ACCOUNT_STATUS = '1'
             --AND A.ACTIVE_FLAG = 'Y'
             ))
         AND (--集团、事业部冻结联动 必须检查中心有效，因为如果中心失效了，不能把账户改为有效
              (P_ACTIVE_FLAG = 'Freezing' AND EXISTS (SELECT 1
                          FROM T_CUSTOMER_ORG O
                         WHERE O.CUSTOMER_ORG_ID = A1.CUSTOMER_ORG_ID
                           AND O.ACTIVE_FLAG NOT IN ('Freezing','Inactive')))
             OR (P_ACTIVE_FLAG IS NOT NULL)
             --集团、事业部失效联动，不需要检查未完成发货通知单，因为CRM会调用失效校验接口
             /*OR (P_ACTIVE_FLAG = 'Inactive' AND EXISTS (SELECT 1
                          FROM T_CUSTOMER_ORG O
                         WHERE O.CUSTOMER_ORG_ID = A1.CUSTOMER_ORG_ID
                         AND F_CUSTORG_CHECK_UNDO(NULL,
                                              NULL,
                                              NULL,
                                              NULL,
                                              NULL,
                                              ORG.SIEBEL_ORG_ID,
                                              NULL,
                                              2,
                                              1) IS NULL
                         ))*/
             )
      /*AND (A.ACTIVE_FLAG <>
          DECODE(P_ACTIVE_FLAG, 'Active', 'Y', 'Freezing', 'Y', 'N') OR
          A.ACCOUNT_STATUS <>
          DECODE(P_ACTIVE_FLAG, 'Active', '1', 'Freezing', '-1', '2'))
      AND (P_ACTIVE_FLAG <> 'Freezing' OR (A.ACTIVE_FLAG <> 'N' OR A.ACCOUNT_STATUS <> '2'))*/
      ;
  BEGIN
    V_CUSTOMER_ID := P_HEAD_ID;
    IF 0 >= NVL(P_HEAD_ID, 0) THEN
      SELECT H1.CUSTOMER_ID, H1.CUSTOMER_CODE
        INTO V_CUSTOMER_ID, V_CUSTOMER_CODE
        FROM INTF_CUSTOMER_HEADER IH
       INNER JOIN T_CUSTOMER_HEADER H1
          ON (H1.SIEBEL_CUSTOMER_ID = IH.SIEBEL_CUSTOMER_ID)
       WHERE IH.CUSTOMER_ID = P_INTF_HEAD_ID;
    ELSE
      SELECT H.CUSTOMER_CODE
        INTO V_CUSTOMER_CODE
        FROM T_CUSTOMER_HEADER H
       WHERE H.Customer_Id = V_CUSTOMER_ID;
    END IF;
  
    V_COUNT := 0;
    FOR LH IN C_H_CHANGED(V_CUSTOMER_ID) LOOP
      FOR LH_DEPT IN C_H_DEPT_CHANGED(V_CUSTOMER_ID, LH.CUSTOMER_STATUS) LOOP
        UPDATE T_CUSTOMER_DEPT D
           SET D.ACTIVE_FLAG          = DECODE(LH.CUSTOMER_STATUS,
                                               'Freezing',
                                               'Active',
                                               LH.CUSTOMER_STATUS)
              ,D.DEPT_CUSTOMER_STATUS = LH.CUSTOMER_STATUS
         WHERE D.ID = LH_DEPT.ID;
        V_COUNT := (1 + V_COUNT);
        INSERT INTO T_CUSTOMER_STATUS_LOG
          (ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           ACTIVE_FLAG,
           ENTITY_ID,
           DEPT_ID,
           DEPT_ACTIVE_FLAG,
           DEPT_CUSTOMER_STATUS,
           CUSTOMER_ORG_ID,
           ORG_ACTIVE_FLAG,
           ACCOUNT_ID,
           ACC_ACTIVE_FLAG,
           ACCOUNT_STATUS,
           ACC_CUSTOMER_ORG_ID,
           TAB_NAME,
           TAB_ID,
           REMARK)
        VALUES
          (SEQ_BD_ROW_ID.NEXTVAL,
           V_CUSTOMER_ID,
           V_CUSTOMER_CODE,
           LH.ACTIVE_FLAG,
           LH_DEPT.DEPT_ID,
           LH_DEPT.ID,
           LH_DEPT.ACTIVE_FLAG,
           LH_DEPT.DEPT_CUSTOMER_STATUS,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           'T_CUSTOMER_DEPT',
           LH_DEPT.ID,
           '客户' || DECODE(LH.CUSTOMER_STATUS,
                          'Freezing',
                          '冻结',
                          'Inactive',
                          '失效'));
      
        FOR LH_ORG IN C_H_ORG_CHANGED(V_CUSTOMER_ID,
                                      LH_DEPT.DEPT_ID,
                                      LH.CUSTOMER_STATUS) LOOP
          UPDATE T_CUSTOMER_ORG O
             SET O.ACTIVE_FLAG = LH.CUSTOMER_STATUS
           WHERE O.CUSTOMER_ORG_ID = LH_ORG.CUSTOMER_ORG_ID; 
          INSERT INTO T_CUSTOMER_STATUS_LOG
            (ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             ACTIVE_FLAG,
             ENTITY_ID,
             DEPT_ID,
             DEPT_ACTIVE_FLAG,
             DEPT_CUSTOMER_STATUS,
             CUSTOMER_ORG_ID,
             ORG_ACTIVE_FLAG,
             ACCOUNT_ID,
             ACC_ACTIVE_FLAG,
             ACCOUNT_STATUS,
             ACC_CUSTOMER_ORG_ID,
             TAB_NAME,
             TAB_ID,
             REMARK)
          VALUES
            (SEQ_BD_ROW_ID.NEXTVAL,
             V_CUSTOMER_ID,
             V_CUSTOMER_CODE,
             LH.ACTIVE_FLAG,
             LH_ORG.Entity_Id,
             LH_DEPT.ID,
             LH_DEPT.ACTIVE_FLAG,
             LH_DEPT.DEPT_CUSTOMER_STATUS,
             LH_ORG.CUSTOMER_ORG_ID,
             LH_ORG.Active_Flag,
             NULL,
             NULL,
             NULL,
             NULL,
             'T_CUSTOMER_ORG',
             LH_ORG.CUSTOMER_ORG_ID,
             '客户' || DECODE(LH.CUSTOMER_STATUS,
                            'Freezing',
                            '冻结',
                            'Inactive',
                            '失效'));
        END LOOP;
      
        FOR LH_ACC IN C_H_ACC_CHANGED(V_CUSTOMER_ID,
                                      LH_DEPT.DEPT_ID,
                                      NULL,
                                      LH.CUSTOMER_STATUS) LOOP
          UPDATE T_CUSTOMER_ACCOUNT A
             SET A.ACTIVE_FLAG    = DECODE(LH.ACTIVE_FLAG,
                                           'Active',
                                           'Y',
                                           'Freezing',
                                           'Y',
                                           'N'),
                 A.ACCOUNT_STATUS = DECODE(LH.CUSTOMER_STATUS,
                                           'Active',
                                           '1',
                                           'Freezing',
                                           '-1',
                                           '2'),
                 A.REMARK         = 'CIMS接收CRM推送的客户状态' ||
                                    DECODE(LH.CUSTOMER_STATUS,
                                           'Freezing',
                                           '已冻结，CIMS联动将账户冻结（自动），时间：',
                                           'Inactive',
                                           '已失效，CIMS联动将账户失效（自动），时间：') ||
                                    V_DATETIME_CHAR ||
                                    '。若有误请找到误操作人在CRM维护客户状态并推送给CIMS后再手工在CIMS手工维护账户状态（非自动），请自己掌握操作',
                 A.LAST_UPDATE_DATE = SYSDATE
           WHERE A.ACCOUNT_ID = LH_ACC.ACCOUNT_ID;
          INSERT INTO T_CUSTOMER_STATUS_LOG
            (ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             ACTIVE_FLAG,
             ENTITY_ID,
             DEPT_ID,
             DEPT_ACTIVE_FLAG,
             DEPT_CUSTOMER_STATUS,
             CUSTOMER_ORG_ID,
             ORG_ACTIVE_FLAG,
             ACCOUNT_ID,
             ACC_ACTIVE_FLAG,
             ACCOUNT_STATUS,
             ACC_CUSTOMER_ORG_ID,
             TAB_NAME,
             TAB_ID,
             REMARK)
          VALUES
            (SEQ_BD_ROW_ID.NEXTVAL,
             V_CUSTOMER_ID,
             V_CUSTOMER_CODE,
             LH.ACTIVE_FLAG,
             LH_ACC.Entity_Id,
             LH_DEPT.Id,
             LH_DEPT.ACTIVE_FLAG,
             LH_DEPT.DEPT_CUSTOMER_STATUS,
             NULL,
             NULL,
             LH_ACC.ACCOUNT_ID,
             LH_ACC.ACTIVE_FLAG,
             LH_ACC.ACCOUNT_STATUS,
             LH_ACC.CUSTOMER_ORG_ID,
             'T_CUSTOMER_ACCOUNT',
             LH_ACC.ACCOUNT_ID,
             '客户' || DECODE(LH.CUSTOMER_STATUS,
                            'Freezing',
                            '冻结',
                            'Inactive',
                            '失效'));
        END LOOP;
      END LOOP;

      FOR LH_ORG IN C_H_ORG_CHANGED(V_CUSTOMER_ID, NULL, LH.CUSTOMER_STATUS) LOOP
        UPDATE T_CUSTOMER_ORG O
           SET O.ACTIVE_FLAG = LH.CUSTOMER_STATUS
         WHERE O.CUSTOMER_ORG_ID = LH_ORG.CUSTOMER_ORG_ID;
        V_COUNT := (1 + V_COUNT);
        INSERT INTO T_CUSTOMER_STATUS_LOG
          (ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           ACTIVE_FLAG,
           ENTITY_ID,
           DEPT_ID,
           DEPT_ACTIVE_FLAG,
           DEPT_CUSTOMER_STATUS,
           CUSTOMER_ORG_ID,
           ORG_ACTIVE_FLAG,
           ACCOUNT_ID,
           ACC_ACTIVE_FLAG,
           ACCOUNT_STATUS,
           ACC_CUSTOMER_ORG_ID,
           TAB_NAME,
           TAB_ID,
           REMARK)
        VALUES
          (SEQ_BD_ROW_ID.NEXTVAL,
           V_CUSTOMER_ID,
           V_CUSTOMER_CODE,
           LH.ACTIVE_FLAG,
           LH_ORG.Entity_Id,
           NULL,
           NULL,
           NULL,
           LH_ORG.CUSTOMER_ORG_ID,
           LH_ORG.Active_Flag,
           NULL,
           NULL,
           NULL,
           NULL,
           'T_CUSTOMER_ORG',
           LH_ORG.CUSTOMER_ORG_ID,
           '客户' || DECODE(LH.CUSTOMER_STATUS,
                          'Freezing',
                          '冻结',
                          'Inactive',
                          '失效'));
      
        FOR LH_ACC IN C_H_ACC_CHANGED(V_CUSTOMER_ID,
                                      LH_ORG.Entity_Id,
                                      LH_ORG.CUSTOMER_ORG_ID,
                                      LH.CUSTOMER_STATUS) LOOP
          UPDATE T_CUSTOMER_ACCOUNT A
             SET A.ACTIVE_FLAG    = DECODE(LH.ACTIVE_FLAG,
                                           'Active',
                                           'Y',
                                           'Freezing',
                                           'Y',
                                           'N'),
                 A.ACCOUNT_STATUS = DECODE(LH.CUSTOMER_STATUS,
                                           'Active',
                                           '1',
                                           'Freezing',
                                           '-1',
                                           '2'),
                 A.REMARK         = 'CIMS接收CRM推送的客户状态' ||
                                    DECODE(LH.CUSTOMER_STATUS,
                                           'Freezing',
                                           '已冻结，CIMS联动将账户冻结（自动），时间：',
                                           'Inactive',
                                           '已失效，CIMS联动将账户失效（自动），时间：') ||
                                    V_DATETIME_CHAR ||
                                    '。若有误请找到误操作人在CRM维护客户状态并推送给CIMS后再手工在CIMS手工维护账户状态（非自动），请自己掌握操作',
                 A.LAST_UPDATE_DATE = SYSDATE
           WHERE A.ACCOUNT_ID = LH_ACC.ACCOUNT_ID;
          INSERT INTO T_CUSTOMER_STATUS_LOG
            (ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             ACTIVE_FLAG,
             ENTITY_ID,
             DEPT_ID,
             DEPT_ACTIVE_FLAG,
             DEPT_CUSTOMER_STATUS,
             CUSTOMER_ORG_ID,
             ORG_ACTIVE_FLAG,
             ACCOUNT_ID,
             ACC_ACTIVE_FLAG,
             ACCOUNT_STATUS,
             ACC_CUSTOMER_ORG_ID,
             TAB_NAME,
             TAB_ID,
             REMARK)
          VALUES
            (SEQ_BD_ROW_ID.NEXTVAL,
             V_CUSTOMER_ID,
             V_CUSTOMER_CODE,
             LH.ACTIVE_FLAG,
             LH_ACC.Entity_Id,
             NULL,
             NULL,
             NULL,
             LH_ORG.CUSTOMER_ORG_ID,
             LH_ORG.ACTIVE_FLAG,
             LH_ACC.ACCOUNT_ID,
             LH_ACC.ACTIVE_FLAG,
             LH_ACC.ACCOUNT_STATUS,
             LH_ACC.CUSTOMER_ORG_ID,
             'T_CUSTOMER_ACCOUNT',
             LH_ACC.ACCOUNT_ID,
             '客户' || DECODE(LH.CUSTOMER_STATUS,
                            'Freezing',
                            '冻结',
                            'Inactive',
                            '失效'));
        END LOOP;
      END LOOP;
    
      FOR LH_ACC IN C_H_ACC_CHANGED(V_CUSTOMER_ID,
                                    NULL,
                                    NULL,
                                    LH.CUSTOMER_STATUS) LOOP
        UPDATE T_CUSTOMER_ACCOUNT A
           SET A.ACTIVE_FLAG    = DECODE(LH.ACTIVE_FLAG,
                                         'Active',
                                         'Y',
                                         'Freezing',
                                         'Y',
                                         'N'),
               A.ACCOUNT_STATUS = DECODE(LH.CUSTOMER_STATUS,
                                         'Active',
                                         '1',
                                         'Freezing',
                                         '-1',
                                         '2'),
               A.REMARK         = 'CIMS接收CRM推送的客户状态' ||
                                  DECODE(LH.CUSTOMER_STATUS,
                                         'Freezing',
                                         '已冻结，CIMS联动将账户冻结（自动），时间：',
                                         'Inactive',
                                         '已失效，CIMS联动将账户失效（自动），时间：') ||
                                  V_DATETIME_CHAR ||
                                  '。若有误请找到误操作人在CRM维护客户状态并推送给CIMS后再手工在CIMS手工维护账户状态（非自动），请自己掌握操作',
               A.LAST_UPDATE_DATE = SYSDATE
         WHERE A.ACCOUNT_ID = LH_ACC.ACCOUNT_ID;
        V_COUNT := (1 + V_COUNT);
        INSERT INTO T_CUSTOMER_STATUS_LOG
          (ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           ACTIVE_FLAG,
           ENTITY_ID,
           DEPT_ID,
           DEPT_ACTIVE_FLAG,
           DEPT_CUSTOMER_STATUS,
           CUSTOMER_ORG_ID,
           ORG_ACTIVE_FLAG,
           ACCOUNT_ID,
           ACC_ACTIVE_FLAG,
           ACCOUNT_STATUS,
           ACC_CUSTOMER_ORG_ID,
           TAB_NAME,
           TAB_ID,
           REMARK)
        VALUES
          (SEQ_BD_ROW_ID.NEXTVAL,
           V_CUSTOMER_ID,
           V_CUSTOMER_CODE,
           LH.ACTIVE_FLAG,
           LH_ACC.Entity_Id,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           LH_ACC.ACCOUNT_ID,
           LH_ACC.ACTIVE_FLAG,
           LH_ACC.ACCOUNT_STATUS,
           LH_ACC.CUSTOMER_ORG_ID,
           'T_CUSTOMER_ACCOUNT',
           LH_ACC.ACCOUNT_ID,
           '客户' || DECODE(LH.CUSTOMER_STATUS,
                          'Freezing',
                          '冻结',
                          'Inactive',
                          '失效'));
      END LOOP;
    END LOOP;
  
    IF (0 < V_COUNT) THEN
      COMMIT;
      RETURN;
    END IF;

    FOR LH_DEPT IN C_DEPT_CHANGED(V_CUSTOMER_ID) LOOP
      V_ACTIVE_FLAG := LH_DEPT.DEPT_CUSTOMER_STATUS;
      IF (LH_DEPT.ACTIVE_FLAG <> 'Inactive' AND
         LH_DEPT.DEPT_CUSTOMER_STATUS = 'Inactive') THEN
        V_ACTIVE_FLAG := 'Inactive';
        UPDATE T_CUSTOMER_DEPT D
           SET D.ACTIVE_FLAG = V_ACTIVE_FLAG
         WHERE D.ID = LH_DEPT.ID;
        V_LOG_ACTIVE_FLAG          := NULL;
        V_LOG_DEPT_CUSTOMER_STATUS := V_ACTIVE_FLAG;
      ELSIF (LH_DEPT.DEPT_CUSTOMER_STATUS <> 'Inactive' AND
            LH_DEPT.ACTIVE_FLAG = 'Inactive') THEN
        V_ACTIVE_FLAG := 'Inactive';
        UPDATE T_CUSTOMER_DEPT D
           SET D.DEPT_CUSTOMER_STATUS = V_ACTIVE_FLAG
         WHERE D.ID = LH_DEPT.ID;
        V_LOG_ACTIVE_FLAG          := V_ACTIVE_FLAG;
        V_LOG_DEPT_CUSTOMER_STATUS := NULL;
      ELSIF (LH_DEPT.ACTIVE_FLAG = 'Freezing') THEN
        V_ACTIVE_FLAG := LH_DEPT.ACTIVE_FLAG;
        UPDATE T_CUSTOMER_DEPT D
           SET D.DEPT_CUSTOMER_STATUS = V_ACTIVE_FLAG,
               D.ACTIVE_FLAG          = DECODE(V_ACTIVE_FLAG,
                                               'Freezing',
                                               'Active',
                                               V_ACTIVE_FLAG)
         WHERE D.ID = LH_DEPT.ID;
        V_LOG_ACTIVE_FLAG          := V_ACTIVE_FLAG;
        V_LOG_DEPT_CUSTOMER_STATUS := NULL;
      ELSIF (LH_DEPT.DEPT_CUSTOMER_STATUS = 'Freezing' AND
            LH_DEPT.ACTIVE_FLAG <> 'Active') THEN
        V_ACTIVE_FLAG := LH_DEPT.DEPT_CUSTOMER_STATUS;
        UPDATE T_CUSTOMER_DEPT D
           SET D.ACTIVE_FLAG = DECODE(V_ACTIVE_FLAG,
                                      'Freezing',
                                      'Active',
                                      V_ACTIVE_FLAG)
         WHERE D.ID = LH_DEPT.ID;
        V_LOG_ACTIVE_FLAG          := NULL;
        V_LOG_DEPT_CUSTOMER_STATUS := V_ACTIVE_FLAG;
      END IF;
    
      IF (V_LOG_ACTIVE_FLAG IS NOT NULL) OR
         (V_LOG_DEPT_CUSTOMER_STATUS IS NOT NULL) THEN
        INSERT INTO T_CUSTOMER_STATUS_LOG
          (ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           ACTIVE_FLAG,
           ENTITY_ID,
           DEPT_ID,
           DEPT_ACTIVE_FLAG,
           DEPT_CUSTOMER_STATUS,
           CUSTOMER_ORG_ID,
           ORG_ACTIVE_FLAG,
           ACCOUNT_ID,
           ACC_ACTIVE_FLAG,
           ACCOUNT_STATUS,
           ACC_CUSTOMER_ORG_ID,
           TAB_NAME,
           TAB_ID,
           REMARK)
        VALUES
          (SEQ_BD_ROW_ID.NEXTVAL,
           V_CUSTOMER_ID,
           V_CUSTOMER_CODE,
           NULL,
           LH_DEPT.DEPT_ID,
           LH_DEPT.ID,
           V_LOG_ACTIVE_FLAG,
           V_LOG_DEPT_CUSTOMER_STATUS,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           'T_CUSTOMER_DEPT',
           LH_DEPT.ID,
           '事业部' ||
           DECODE(V_ACTIVE_FLAG, 'Freezing', '冻结', 'Inactive', '失效'));
      END IF;
    
      FOR LH_ORG IN C_H_ORG_CHANGED(V_CUSTOMER_ID,
                                    LH_DEPT.DEPT_ID,
                                    V_ACTIVE_FLAG) LOOP
        UPDATE T_CUSTOMER_ORG O
           SET O.ACTIVE_FLAG = V_ACTIVE_FLAG
         WHERE O.CUSTOMER_ORG_ID = LH_ORG.CUSTOMER_ORG_ID;
        V_COUNT := (1 + V_COUNT);
        INSERT INTO T_CUSTOMER_STATUS_LOG
          (ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           ACTIVE_FLAG,
           ENTITY_ID,
           DEPT_ID,
           DEPT_ACTIVE_FLAG,
           DEPT_CUSTOMER_STATUS,
           CUSTOMER_ORG_ID,
           ORG_ACTIVE_FLAG,
           ACCOUNT_ID,
           ACC_ACTIVE_FLAG,
           ACCOUNT_STATUS,
           ACC_CUSTOMER_ORG_ID,
           TAB_NAME,
           TAB_ID,
           REMARK)
        VALUES
          (SEQ_BD_ROW_ID.NEXTVAL,
           V_CUSTOMER_ID,
           V_CUSTOMER_CODE,
           NULL,
           LH_ORG.ENTITY_ID,
           LH_DEPT.ID,
           LH_DEPT.ACTIVE_FLAG,
           LH_DEPT.DEPT_CUSTOMER_STATUS,
           LH_ORG.CUSTOMER_ORG_ID,
           LH_ORG.ACTIVE_FLAG,
           NULL,
           NULL,
           NULL,
           NULL,
           'T_CUSTOMER_ORG',
           LH_ORG.CUSTOMER_ORG_ID,
           '事业部' ||
           DECODE(V_ACTIVE_FLAG, 'Freezing', '冻结', 'Inactive', '失效'));
      
        FOR LH_ACC IN C_H_ACC_CHANGED(V_CUSTOMER_ID,
                                      LH_DEPT.DEPT_ID,
                                      LH_ORG.CUSTOMER_ORG_ID,
                                      V_ACTIVE_FLAG) LOOP
          UPDATE T_CUSTOMER_ACCOUNT A
             SET A.ACTIVE_FLAG    = DECODE(V_ACTIVE_FLAG,
                                           'Active',
                                           'Y',
                                           'Freezing',
                                           'Y',
                                           'N'),
                 A.ACCOUNT_STATUS = DECODE(V_ACTIVE_FLAG,
                                           'Active',
                                           '1',
                                           'Freezing',
                                           '-1',
                                           '2'),
                 A.REMARK         = 'CIMS接收CRM推送的客户事业部状态' ||
                                    DECODE(V_ACTIVE_FLAG,
                                           'Freezing',
                                           '已冻结，CIMS联动将账户冻结（自动），时间：',
                                           'Inactive',
                                           '已失效，CIMS联动将账户失效（自动），时间：') ||
                                    V_DATETIME_CHAR ||
                                    '。若有误请找到误操作人在CRM维护客户事业部状态并推送给CIMS后再手工在CIMS手工维护账户状态（非自动），请自己掌握操作',
                 A.LAST_UPDATE_DATE = SYSDATE
           WHERE A.ACCOUNT_ID = LH_ACC.ACCOUNT_ID;
          INSERT INTO T_CUSTOMER_STATUS_LOG
            (ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             ACTIVE_FLAG,
             ENTITY_ID,
             DEPT_ID,
             DEPT_ACTIVE_FLAG,
             DEPT_CUSTOMER_STATUS,
             CUSTOMER_ORG_ID,
             ORG_ACTIVE_FLAG,
             ACCOUNT_ID,
             ACC_ACTIVE_FLAG,
             ACCOUNT_STATUS,
             ACC_CUSTOMER_ORG_ID,
             TAB_NAME,
             TAB_ID,
             REMARK)
          VALUES
            (SEQ_BD_ROW_ID.NEXTVAL,
             V_CUSTOMER_ID,
             V_CUSTOMER_CODE,
             NULL,
             LH_DEPT.Dept_Id,
             LH_DEPT.ID,
             LH_DEPT.ACTIVE_FLAG,
             LH_DEPT.DEPT_CUSTOMER_STATUS,
             LH_ORG.CUSTOMER_ORG_ID,
             LH_ORG.ACTIVE_FLAG,
             LH_ACC.ACCOUNT_ID,
             LH_ACC.ACTIVE_FLAG,
             LH_ACC.ACCOUNT_STATUS,
             LH_ACC.CUSTOMER_ORG_ID,
             'T_CUSTOMER_ACCOUNT',
             LH_ACC.ACCOUNT_ID,
             '事业部' ||
             DECODE(V_ACTIVE_FLAG, 'Freezing', '冻结', 'Inactive', '失效'));
        END LOOP;
      END LOOP;
    
      FOR LH_ACC IN C_H_ACC_CHANGED(V_CUSTOMER_ID,
                                    LH_DEPT.DEPT_ID,
                                    NULL,
                                    V_ACTIVE_FLAG) LOOP
        UPDATE T_CUSTOMER_ACCOUNT A
           SET A.ACTIVE_FLAG    = DECODE(V_ACTIVE_FLAG,
                                         'Active',
                                         'Y',
                                         'Freezing',
                                         'Y',
                                         'N'),
               A.ACCOUNT_STATUS = DECODE(V_ACTIVE_FLAG,
                                         'Active',
                                         '1',
                                         'Freezing',
                                         '-1',
                                         '2'),
               A.REMARK         = 'CIMS接收CRM推送的客户事业部状态' ||
                                  DECODE(V_ACTIVE_FLAG,
                                         'Freezing',
                                         '已冻结，CIMS联动将账户冻结（自动），时间：',
                                         'Inactive',
                                         '已失效，CIMS联动将账户失效（自动），时间：') ||
                                  V_DATETIME_CHAR ||
                                  '。若有误请找到误操作人在CRM维护客户事业部状态并推送给CIMS后再手工在CIMS手工维护账户状态（非自动），请自己掌握操作',
               A.LAST_UPDATE_DATE = SYSDATE
         WHERE A.ACCOUNT_ID = LH_ACC.ACCOUNT_ID;
        INSERT INTO T_CUSTOMER_STATUS_LOG
          (ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           ACTIVE_FLAG,
           ENTITY_ID,
           DEPT_ID,
           DEPT_ACTIVE_FLAG,
           DEPT_CUSTOMER_STATUS,
           CUSTOMER_ORG_ID,
           ORG_ACTIVE_FLAG,
           ACCOUNT_ID,
           ACC_ACTIVE_FLAG,
           ACCOUNT_STATUS,
           ACC_CUSTOMER_ORG_ID,
           TAB_NAME,
           TAB_ID,
           REMARK)
        VALUES
          (SEQ_BD_ROW_ID.NEXTVAL,
           V_CUSTOMER_ID,
           V_CUSTOMER_CODE,
           NULL,
           LH_ACC.ENTITY_ID,
           LH_DEPT.ID,
           LH_DEPT.ACTIVE_FLAG,
           LH_DEPT.DEPT_CUSTOMER_STATUS,
           NULL,
           NULL,
           LH_ACC.ACCOUNT_ID,
           LH_ACC.ACTIVE_FLAG,
           LH_ACC.ACCOUNT_STATUS,
           LH_ACC.CUSTOMER_ORG_ID,
           'T_CUSTOMER_ACCOUNT',
           LH_ACC.ACCOUNT_ID,
           '事业部' ||
           DECODE(V_ACTIVE_FLAG, 'Freezing', '冻结', 'Inactive', '失效'));
      END LOOP;
    END LOOP;
  
    IF (0 < V_COUNT) THEN
      COMMIT;
      RETURN;
    END IF;

    FOR LH_ORG IN C_ORG_CHANGED(V_CUSTOMER_ID) LOOP
      V_ACTIVE_FLAG := LH_ORG.ACTIVE_FLAG;
    
      FOR LH_ACC IN C_H_ACC_CHANGED(V_CUSTOMER_ID,
                                    LH_ORG.ENTITY_ID,
                                    LH_ORG.CUSTOMER_ORG_ID,
                                    V_ACTIVE_FLAG) LOOP
        UPDATE T_CUSTOMER_ACCOUNT A
           SET A.ACTIVE_FLAG    = DECODE(V_ACTIVE_FLAG,
                                         'Active',
                                         'Y',
                                         'Freezing',
                                         'Y',
                                         'N'),
               A.ACCOUNT_STATUS = DECODE(V_ACTIVE_FLAG,
                                         'Active',
                                         '1',
                                         'Freezing',
                                         '-1',
                                         '2'),
               A.REMARK         = 'CIMS接收CRM推送的客户中心状态' ||
                                  DECODE(V_ACTIVE_FLAG,
                                         'Freezing',
                                         '已冻结，CIMS联动将账户冻结（自动），时间：',
                                         'Inactive',
                                         '已失效，CIMS联动将账户失效（自动），时间：') ||
                                  V_DATETIME_CHAR ||
                                  '。若有误请找到误操作人在CRM维护客户中心状态并推送给CIMS后再手工在CIMS手工维护账户状态（非自动），请自己掌握操作' ||
                                  '。所挂客户中心：' || LH_ORG.SALES_CENTER_NAME,
               A.LAST_UPDATE_DATE = SYSDATE
         WHERE A.ACCOUNT_ID = LH_ACC.ACCOUNT_ID;
        V_COUNT := (1 + V_COUNT);
        INSERT INTO T_CUSTOMER_STATUS_LOG
          (ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           ACTIVE_FLAG,
           ENTITY_ID,
           DEPT_ID,
           DEPT_ACTIVE_FLAG,
           DEPT_CUSTOMER_STATUS,
           CUSTOMER_ORG_ID,
           ORG_ACTIVE_FLAG,
           ACCOUNT_ID,
           ACC_ACTIVE_FLAG,
           ACCOUNT_STATUS,
           ACC_CUSTOMER_ORG_ID,
           TAB_NAME,
           TAB_ID,
           REMARK)
        VALUES
          (SEQ_BD_ROW_ID.NEXTVAL,
           V_CUSTOMER_ID,
           V_CUSTOMER_CODE,
           NULL,
           LH_ORG.ENTITY_ID,
           NULL,
           NULL,
           NULL,
           LH_ORG.CUSTOMER_ORG_ID,
           V_ACTIVE_FLAG,
           LH_ACC.ACCOUNT_ID,
           LH_ACC.ACTIVE_FLAG,
           LH_ACC.ACCOUNT_STATUS,
           LH_ACC.CUSTOMER_ORG_ID,
           'T_CUSTOMER_ACCOUNT',
           LH_ACC.ACCOUNT_ID,
           '客户中心' ||
           DECODE(V_ACTIVE_FLAG, 'Freezing', '冻结', 'Inactive', '失效'));
      END LOOP;
    END LOOP;
  
    IF (0 < V_COUNT) THEN
      COMMIT;
    END IF;
  END PRC_UPDATE_STATUS_CHANGED;

  PROCEDURE P_CUSTOMER_INTF_PROC(IS_WHAT           IN VARCHAR2,
                                 IS_USER_ACCOUNT   IN VARCHAR2,
                                 IS_INTF_HEADER_ID IN VARCHAR2,
                                 OS_MESSAGE        OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                 ) IS
    V_MAX_INTF_HEADER_ID NUMBER;
    V_WHAT               VARCHAR2(100);
    V_WHAT1              VARCHAR2(100);
    V_MAX_TRANSCODE      INTF_CUSTOMER_HEADER.TRANSCODE%TYPE;
  BEGIN
    V_WHAT1 := LOWER(IS_WHAT);
    V_WHAT  := V_WHAT1;
    IF V_WHAT = 'header' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户头';
      OS_MESSAGE := F_INSERT_OR_UPDATE_HEADER(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'addr' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户地址';
      OS_MESSAGE := F_INSERT_OR_UPDATE_ADDRESS(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'contacts' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户联系人';
      OS_MESSAGE := F_INSERT_OR_UPDATE_CONTACTS(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'brand' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户经营品牌';
      OS_MESSAGE := F_INSERT_OR_UPDATE_BRAND(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'bank' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户银行信息';
      OS_MESSAGE := F_INSERT_OR_UPDATE_BANK(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'org' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户营销中心';
      OS_MESSAGE := F_INSERT_OR_UPDATE_ORG(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'dept' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户事业部';
      OS_MESSAGE := F_INSERT_OR_UPDATE_DEPT(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'channeltype' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户业态类型';
      OS_MESSAGE := F_INSERT_OR_UPDATE_CHANN_TYPE(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'ou' OR V_WHAT = 'all' THEN
      V_WHAT1     := '客户OU';
      OS_MESSAGE := F_INSERT_OR_UPDATE_OU(IS_INTF_HEADER_ID);
    END IF;
    IF V_WHAT = 'all' THEN
      V_WHAT1     := '客户';
    END IF;
    V_WHAT  := V_WHAT1;
    WITH WT AS
     (SELECT IH.CUSTOMER_ID,
             IH.TRANSCODE,
             DENSE_RANK() OVER(PARTITION BY IH.SIEBEL_CUSTOMER_ID ORDER BY IH.LAST_UPDATE_DATE DESC, IH.TRANSCODE DESC, IH.CUSTOMER_ID DESC) AS RK
        FROM INTF_CUSTOMER_HEADER IH
       WHERE EXISTS
       (SELECT 1
                FROM INTF_CUSTOMER_HEADER H
               WHERE H.CUSTOMER_ID = IS_INTF_HEADER_ID
                 AND IH.SIEBEL_CUSTOMER_ID = H.SIEBEL_CUSTOMER_ID))
    SELECT CUSTOMER_ID, TRANSCODE
      INTO V_MAX_INTF_HEADER_ID, V_MAX_TRANSCODE
      FROM WT
     WHERE RK = 1
       AND 1 = ROWNUM;
    
    --SUCCESS
    IF V_WHAT = '客户头' THEN
      UPDATE INTF_CUSTOMER_HEADER
         SET RESPONSETYPE    = DECODE(OS_MESSAGE,'SUCCESS', 'N','E'),
             RESPNOSECODE    = DECODE(OS_MESSAGE,'SUCCESS', '000000','000013'),
             RESPONSEMESSAGE = OS_MESSAGE,
             OPERSTATUS      = DECODE(OS_MESSAGE,'SUCCESS', '0','1')
       WHERE CUSTOMER_ID = IS_INTF_HEADER_ID;
    END IF;
    IF OS_MESSAGE = 'SUCCESS' THEN
      OS_MESSAGE := '处理成功';
    ELSE
      OS_MESSAGE := '处理失败：' || OS_MESSAGE;
    END IF;
    OS_MESSAGE := V_WHAT || OS_MESSAGE;
    IF V_MAX_INTF_HEADER_ID <> IS_INTF_HEADER_ID THEN
      OS_MESSAGE := OS_MESSAGE || '。处理的不是最新的数据，最新的流水号：' || V_MAX_TRANSCODE;
    END IF;
  
  END P_CUSTOMER_INTF_PROC;

  PROCEDURE P_INVALID_HIS_PRE01_PROC(IS_USER_ACCOUNT   IN VARCHAR2,
                                     IS_INVALID_HIS_ID IN VARCHAR2,
                                     OS_MESSAGE        OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                     ) IS
  BEGIN
    UPDATE INTF_CUSTOMER_INVALID_HIS H
       SET H.PRE_FIELD_01     = DECODE(H.PRE_FIELD_01, 'Y', 'N', 'Y')
          ,H.LAST_UPDATE_DATE = SYSDATE
          ,H.LAST_UPDATE_BY   = IS_USER_ACCOUNT
     WHERE H.INVALID_ID = TO_NUMBER(IS_INVALID_HIS_ID)
       AND (H.PRE_FIELD_01 IS NULL OR H.PRE_FIELD_01 = 'Y')
       AND 'N' = H.CAN_INVALID;
    
    SELECT DECODE(CAN_INVALID,
                  'Y',
                  '已允许失效，不需手工处理',
                  DECODE(PRE_FIELD_01,
                         'Y',
                         '开关生效：手工可失效请重推',
                         '开关关闭：不可手工失效'))
      INTO OS_MESSAGE
      FROM INTF_CUSTOMER_INVALID_HIS
     WHERE INVALID_ID = TO_NUMBER(IS_INVALID_HIS_ID);
  END P_INVALID_HIS_PRE01_PROC;
  
  /**
  *客户主数据接口超时处理（无响应）
  */
  PROCEDURE P_CUST_INTF_TIMEOUT_HANDLE(IN_BEFORE_DAYS     IN VARCHAR2,
                                      IN_CLEAR_OVER_COUNT IN NUMBER,
                                      IN_BF_MONTHS_CLR    IN NUMBER,
                                      OS_MESSAGE          OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                      ) IS
    TYPE REC_FL IS RECORD
    (
    I1 INTF_CUSTOMER_HEADER.CUSTOMER_ID%TYPE,
    I2 INTF_CUSTOMER_HEADER.CUSTOMER_ID%TYPE
    );
   
    TYPE T_FL IS TABLE OF REC_FL
    INDEX BY BINARY_INTEGER
    --INDEX BY [BINARY_INTEGER|PLS_INTEGER|VARRAY2]
    ;
   
    V_FL T_FL;
    VN_BEFORE_DAYS NUMBER := TO_NUMBER(NVL(IN_BEFORE_DAYS, '1'));
  BEGIN
    OS_MESSAGE := 'SUCCESS';
    SELECT H.CUSTOMER_ID, MAX(H0.CUSTOMER_ID) AS CUSTOMER_ID_NEW
    BULK COLLECT INTO V_FL
                FROM (SELECT T.CUSTOMER_ID
                        FROM CIMS.INTF_CUSTOMER_HEADER T
                       WHERE T.RESPONSETYPE IS NULL
                         AND T.LAST_INTERFACE_DATE > SYSDATE - VN_BEFORE_DAYS
                      UNION
                      SELECT TO_NUMBER(T.PRE_FIELD_01) AS CUSTOMER_ID
                        FROM CIMS.INTF_CUSTOMER_DEPT T
                       WHERE T.RESPONSETYPE IS NULL
                         AND T.LAST_INTERFACE_DATE > SYSDATE - VN_BEFORE_DAYS
                      UNION
                      SELECT TO_NUMBER(T.PRE_FIELD_01) AS CUSTOMER_ID
                        FROM CIMS.INTF_CUSTOMER_ADDRESS T
                       WHERE T.RESPONSETYPE IS NULL
                         AND T.LAST_INTERFACE_DATE > SYSDATE - VN_BEFORE_DAYS
                      UNION
                      SELECT TO_NUMBER(T.PRE_FIELD_01) AS CUSTOMER_ID
                        FROM CIMS.INTF_CUSTOMER_BANK T
                       WHERE T.RESPONSETYPE IS NULL
                         AND T.LAST_INTERFACE_DATE > SYSDATE - VN_BEFORE_DAYS
                      UNION
                      SELECT TO_NUMBER(T.PRE_FIELD_01) AS CUSTOMER_ID
                        FROM CIMS.INTF_CUSTOMER_BRAND T
                       WHERE T.RESPONSETYPE IS NULL
                         AND T.LAST_INTERFACE_DATE > SYSDATE - VN_BEFORE_DAYS
                      UNION
                      SELECT TO_NUMBER(T.PRE_FIELD_01) AS CUSTOMER_ID
                        FROM CIMS.INTF_CUSTOMER_CHANNEL_TYPE T
                       WHERE T.RESPONSETYPE IS NULL
                         AND T.LAST_INTERFACE_DATE > SYSDATE - VN_BEFORE_DAYS
                      UNION
                      SELECT TO_NUMBER(T.PRE_FIELD_01) AS CUSTOMER_ID
                        FROM CIMS.INTF_CUSTOMER_CONNECTION T
                       WHERE T.RESPONSETYPE IS NULL
                         AND T.LAST_INTERFACE_DATE > SYSDATE - VN_BEFORE_DAYS
                      UNION
                      SELECT TO_NUMBER(T.PRE_FIELD_01) AS CUSTOMER_ID
                        FROM CIMS.INTF_CUSTOMER_CONTACTS T
                       WHERE T.RESPONSETYPE IS NULL
                         AND T.LAST_INTERFACE_DATE > SYSDATE - VN_BEFORE_DAYS
                      UNION
                      SELECT TO_NUMBER(T.PRE_FIELD_01) AS CUSTOMER_ID
                        FROM CIMS.INTF_CUSTOMER_ORG T
                       WHERE T.RESPONSETYPE IS NULL
                         AND T.LAST_INTERFACE_DATE > SYSDATE - VN_BEFORE_DAYS
                      UNION
                      SELECT TO_NUMBER(T.PRE_FIELD_01) AS CUSTOMER_ID
                        FROM CIMS.INTF_CUSTOMER_OU T
                       WHERE T.RESPONSETYPE IS NULL
                         AND T.LAST_INTERFACE_DATE > SYSDATE - VN_BEFORE_DAYS) NT
               INNER JOIN CIMS.INTF_CUSTOMER_HEADER H
                  ON (H.CUSTOMER_ID = NT.CUSTOMER_ID)
                LEFT JOIN CIMS.INTF_CUSTOMER_HEADER H0
                  ON (H0.CUSTOMER_ID > H.CUSTOMER_ID AND
                     H0.SIEBEL_CUSTOMER_ID = H.SIEBEL_CUSTOMER_ID AND H0.RESPONSETYPE IS NOT NULL)
               GROUP BY H.CUSTOMER_ID
               ORDER BY H.CUSTOMER_ID;
    IF 0 < V_FL.COUNT THEN
      FOR V_INDEX IN V_FL.FIRST .. V_FL.LAST LOOP
        P_CUSTOMER_INTF_PROC(V_FL(V_INDEX).I1, OS_MESSAGE, 'NOTGTWIDTH');
        IF V_FL(V_INDEX).I2 > 0 THEN
          P_CUSTOMER_INTF_PROC(V_FL(V_INDEX).I2, OS_MESSAGE, 'NOTGTWIDTH');
        END IF;
      END LOOP;
    END IF;
  END P_CUST_INTF_TIMEOUT_HANDLE;
  
  /**
  *客户主数据接口失败处理
  */
  PROCEDURE P_CUST_INTF_FAILURE_HANDLE(OS_MESSAGE OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                      ) IS
  BEGIN
    --推送组织没有插入到正式表的处理
    FOR LI IN (SELECT ICO.SIEBEL_ORG_ID,
                     D.CUSTOMER_CODE,
                     DU.ENTITY_ID,
                     SU.NAME,
                     MAX(TO_NUMBER(ICO.PRE_FIELD_01)) AS ID
                FROM INTF_CUSTOMER_ORG ICO
               INNER JOIN INTF_CUSTOMER_DEPT ICD
                  ON (ICD.SIEBEL_ID = ICO.PARENT_ID)
               INNER JOIN UP_ORG_UNIT DU
                  ON (DU.CODE = ICD.DEPT_CODE AND
                     DU.TYPE_CODE IN ('BU', 'MC'))
               INNER JOIN UP_ORG_UNIT SU
                  ON (SU.CODE = ICO.SALES_CENTER_CODE AND
                     SU.ENTITY_ID = DU.ENTITY_ID AND
                     SU.TYPE_CODE IN ('SC', 'SD'))
               INNER JOIN T_CUSTOMER_DEPT D
                  ON (D.SIEBEL_ID = ICD.SIEBEL_ID)
               WHERE NOT EXISTS
               (SELECT 1
                        FROM T_CUSTOMER_ORG CO
                       WHERE CO.ENTITY_ID = DU.ENTITY_ID
                         AND CO.SIEBEL_ORG_ID = ICO.SIEBEL_ORG_ID)
               GROUP BY ICO.SIEBEL_ORG_ID,
                        D.CUSTOMER_CODE,
                        DU.ENTITY_ID,
                        SU.NAME) LOOP
      OS_MESSAGE := F_INSERT_OR_UPDATE_ORG(LI.ID);
    END LOOP;
    --推送组织名称冗余字段与正式表不一致的处理
    FOR LI IN (SELECT CO.CUSTOMER_ORG_ID,
                     MAX(TO_NUMBER(ICO.PRE_FIELD_01)) AS ID
                FROM T_CUSTOMER_ORG CO
               INNER JOIN INTF_CUSTOMER_ORG ICO
                  ON (CO.SIEBEL_ORG_ID = ICO.SIEBEL_ORG_ID)
               INNER JOIN UP_ORG_UNIT U
                  ON (CO.ENTITY_ID = U.ENTITY_ID AND
                     CO.SALES_CENTER_ID = U.UNIT_ID AND
                     U.NAME <> CO.SALES_CENTER_NAME)
               GROUP BY CO.CUSTOMER_ORG_ID) LOOP
      OS_MESSAGE := F_INSERT_OR_UPDATE_ORG(LI.ID);
    END LOOP;
  END P_CUST_INTF_FAILURE_HANDLE;

END PKG_CUSTOMER_INTF;
/

