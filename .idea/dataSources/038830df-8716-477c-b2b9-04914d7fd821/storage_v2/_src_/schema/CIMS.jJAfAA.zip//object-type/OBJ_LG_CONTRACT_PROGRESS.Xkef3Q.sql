create Type      Obj_Lg_Contract_Progress As Object
(
  Contract_Code    Varchar2(32),
  So_Contract_Code Varchar2(60),
  Receive_Flag     Varchar2(32),
  Fact_Ship_Date   Date,
  Cl_Fact_Ship_Qty Number,
  Total_Volume     Number,
  Receive_Date     Date,
  Affirm_Qty       Number,
  Diff_Qty         Number,
  Origin_Type      Varchar2(32),
  Origin_Order_Id  Number,
  Origin_Order_Num Varchar2(60),
  Origin_Line_Id   Number,
  Ship_Doc_Line_Id Number,
  Entity_Id        Number

--后续增加其他字段

)
/

