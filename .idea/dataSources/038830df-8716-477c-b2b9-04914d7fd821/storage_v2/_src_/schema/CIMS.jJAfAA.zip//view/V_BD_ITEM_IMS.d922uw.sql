create view V_BD_ITEM_IMS as
select sales_main_type MATERIAL_TYPE_CODE,    --大类编码
       (select c.class_name
          from t_bd_item_class c
         where c.class_code = sales_main_type
           and c.active_flag = 'Y') MATERIAL_TYPE, --大类名称
       sales_sub_type SMALL_CATEGORY_CODE,     --小类编码
       (select c.class_name
          from t_bd_item_class c
         where c.class_code = sales_sub_type
           and c.active_flag = 'Y') SMALL_CATEGORY,  --小类名称
       item_code MATERIAL_CODE,
       item_name DESCRIPTION,
       --defaultunit UOM_CODE,
       (select um.uom_name from t_bd_uom um where um.uom_code = defaultunit) UOM_CODE,
       decode(entity_id,10,'空调',productType)  MATERIAL_CATEGORY,
       ( select l.code_name  from t_bd_item_codelist l
         where l.codetype = 'GE_MPL_BRAND' and l.code_value = brand
         ) MATERIAL_BRAND,
       --brand MATERIAL_BRAND,
       productForm PRODUCT_FORM,
       packinglength LENGTH,
       packingwidth WIDTH,
       packingheight HEIGHT,
       packingsize UNIT_VOLUME,
       grossweight UNIT_WEIGHT,
       purchase_flag PURCHASE_ENABLED_FLAG,
       sale_flag SALEABLE_ENABLED_FLAG,
       plan_flag PLAN_ENABLED_FLAG,
       invstran_flag TRANSACTION_ENABLED_FLAG,
       invoice_flag INVOICE_ENABLED_FLAG,
       ENTITY_ID FINANCE_ENTITY_ID,
       --   assemble_flag    ASSEMBLED_ENABLED_FLAG,
       created_by,
       creation_date,
       last_updated_by,
       last_update_date,
       DECODE(IS_ROUNDING, 'Y', ROUNDING_CNT, 1) PACKINGAMOUNT
  from T_BD_ITEM
 where IS_MATERIAL IN ('N','W')
/

