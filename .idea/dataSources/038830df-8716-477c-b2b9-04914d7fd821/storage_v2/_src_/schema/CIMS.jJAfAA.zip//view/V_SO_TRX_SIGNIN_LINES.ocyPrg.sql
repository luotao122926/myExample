create view V_SO_TRX_SIGNIN_LINES as
select sig.SIL_ID,
       sig.SIH_ID,
       sig.TRX_ID,
       nvl(sig.TRX_CODE,trx.trx_code) trx_code,
       sig.TRX_DATE,
       sig.ENTITY_ID,
       sig.HAVE_CANCELLED_FLAG,
       trx.TRX_HEADER_CODE,
       trx.TRX_ACCOUNT,
       trx.EMS_CODE,
       trx.COMMENTS,
       trx.CENTER_SIGN_FLAG,
       trx.customer_sign_flag
  from t_so_trx_signin_lines sig
  left join t_so_trx_headers trx on sig.trx_id = trx.idtrx_id
/

