create view V_BD_ITEM_SUBCLASS as
SELECT a.item_class_id,a.class_code, a.class_name, b.class_code par_class_code,
          b.class_name par_class_name, a.entity_id
     FROM t_bd_item_class a, t_bd_item_class b
    WHERE a.parentc_lass_id = b.item_class_id
      AND a.active_flag = 'Y'
      AND a.class_type = 'S'
/

