create procedure P_INV_PMT_TRANSACTION(I_ENTITY_ID IN INTEGER) IS
  /** v1.0
   推广物料(采购)对账逻辑：
     合并查询ERP库存事务非常慢，实用单单核对方式处理(目前采购单量较少)
  */

  --declare
  -- Local variables here

  -- 单据符合条件记录数
  i_bill_num integer;
  -- 单据重复次数
  i_inv_bill_count integer;

  -- 备注长度，1000个字(数字、字母、汉字均按照1个字计算)
  i_remark_length number := 1000;

  -- CIMS库存事务记录数
  count_po_inv_cims integer;
  -- GERP库存事务记录数
  count_po_inv_gerp integer;
  -- 主体
  v_entity_id integer;
  --数量
  i_qty_temp number;

  b_immediate_commit boolean; -- 执行SQL后是否及时提交事务

  -- 对账是否成功标志
  str_status varchar2(2);
  -- 对账开始日期(包含)
  str_start_date varchar2(20);
  -- 对账结束日期(不包含)
  str_end_date varchar2(20);
  -- 对账结果
  str_msg varchar2(2000);
  -- 对账结果-过程比较
  str_bill_line_msg varchar2(2000);
  -- 对账中间结果
  str_bill_line_msg2 varchar2(2000);
  --单据最终状态-接收
  str_status_end varchar2(2);
  --单据状态名称
  str_status_meaning varchar2(20);

  -- PO单、仓库、产品编码、CIMS数量、GERP数量，差异原因
  str_select_sql varchar2(4000);
  -- 插入对照表SQL
  str_insert_sql varchar2(4000);
  ---调账SQL
  str_select_sql_rec varchar2(8000);
  ---调账SQL
  str_insert_sql_rec varchar2(32000);
  -- 删除标记为错误的单据
  str_delete_sql varchar2(4000);

  -- 查询单据、子库、产品、库存临时SQL
  str_select_sql_tmp varchar2(4000);

  --对账程序开始时间-用于纠正更新
  str_start_time varchar2(200);
  --对账程序结束时间-用于纠正更新
  str_end_time varchar2(200);

  var_bill_no_debug varchar2(20) := 'P140010520Test';

  i_transaction_type number; -- 库存事务类型
  STATIC_ICP_TYPE    number := 3; -- 关联交易
  STATIC_BILL_TYPE   number := 2; -- 采购
  STATIC_INTF_TYPE   number := 1; -- 库存事务接口
  STATIC_NOT_TYPE    number := 0; -- 未定义库存事务类型

  --推广物料发放单
  cursor c_reconciliation_diffpmt(in_entity_id in number, in_start_time in varchar2, in_end_time in varchar2) is
    select distinct rec.business_num bill_no
    --rec.inv_code,
    --rec.item_code,
    --rec.cims_qty,
    --rec.gerp_qty
      from cims.t_inv_taction_reconciliation rec
     where rec.entity_id = in_entity_id
          --and rec.cims_qty <> rec.gerp_qty
       and rec.creation_date >=
           to_date(in_start_time, 'yyyy-mm-dd hh24:mi:ss') - 1 / (24 * 60)
       and rec.creation_date <=
           to_date(in_end_time, 'yyyy-mm-dd hh24:mi:ss') + 1 / (24 * 60)
       and rec.reconciliation_type = 'PMT_OUT'
       and rec.status = '01'
       and exists (select 1
              from cims.t_pmt_collar_send_head pmt_cims
             where rec.business_num = pmt_cims.pmt_send_num
               and pmt_cims.entity_id = in_entity_id);

  -- 推广物料采购单(含采购红冲)
  cursor c_reconciliation_pmtin_bills(in_entity_id_f in number, in_status_end_f in varchar2, in_start_date_f in varchar2, in_end_date_f in varchar2) is
    select distinct h.business_num, inv_bill.bill_type_name business_type
      from cims.t_inv_transaction_history h, cims.t_inv_bill_types inv_bill
     where h.entity_id = in_entity_id_f
       and h.bill_type_id = inv_bill.bill_type_id
       and h.entity_id = inv_bill.entity_id
       and h.transaction_date >
           to_date(in_start_date_f, 'yyyy-mm-dd hh24:mi:ss') -
           1 / (24 * 60)
       and h.transaction_date <
           to_date(in_end_date_f, 'yyyy-mm-dd hh24:mi:ss') + 1 / (24 * 60)
          --and h.business_num = 'P140000577'
       and not exists (select 1
              from cims.t_inv_taction_reconciliation rec
             where rec.business_num = h.business_num
               and rec.entity_id = h.entity_id
               and rec.reconciliation_type = 'PMT_IN')
       and exists
     (select 1
              from cims.t_inv_po_headers po, cims.t_pmt_order_header pmt
             where po.sched_order_num = pmt.order_num
               and po.po_num = h.business_num
               and po.entity_id = in_entity_id_f
               and pmt.entity_id = in_entity_id_f
               and po.old_po_num is null);

  cursor c_reconciliation_pmtin_bill(in_entity_id_f in number, in_bill_no_f in varchar2) is
    select business_num,
           inv_code,
           item_code,
           sum(cims_qty) cims_qty,
           0 gerp_qty
      from (select h.business_num,
                   h.inventory_code inv_code,
                   h.item_code,
                   h.transaction_quantity cims_qty,
                   0 gerp_qty
              from cims.t_inv_transaction_history h
             where h.entity_id = in_entity_id_f
               and h.business_num = in_bill_no_f
               and not exists
             (select 1
                      from cims.t_inv_taction_reconciliation rec
                     where rec.business_num = h.business_num
                       and rec.entity_id = h.entity_id
                       and rec.reconciliation_type = 'PMT_IN')
               and exists (select 1
                      from cims.t_inv_po_headers   po,
                           cims.t_pmt_order_header pmt
                     where po.sched_order_num = pmt.order_num
                       and po.po_num = h.business_num
                       and po.entity_id = in_entity_id_f
                       and pmt.entity_id = in_entity_id_f
                       and po.old_po_num is null)
            
            union all
            
            select po.old_po_num business_num,
                   h.inventory_code inv_code,
                   h.item_code,
                   h.transaction_quantity cims_qty, --,po.po_num
                   0 gerp_qty
              from cims.t_inv_transaction_history h,
                   cims.t_inv_po_headers          po
             where h.entity_id = in_entity_id_f
               and po.old_po_num is not null
               and po.po_num = h.business_num
               and po.old_po_num = in_bill_no_f
               and not exists
             (select 1
                      from cims.t_inv_taction_reconciliation rec
                     where rec.business_num = h.business_num
                       and rec.entity_id = h.entity_id
                       and rec.reconciliation_type = 'PMT_IN')
               and exists (select *
                      from cims.t_pmt_order_header pmt
                     where po.sched_order_num = pmt.order_num
                       and po.entity_id = h.entity_id
                       and po.entity_id = pmt.entity_id))
     group by business_num, inv_code, item_code;

  -- 获取单据接口错误原因-单据成功才会库存事务
  function f_get_billin_result(in_entity_id_f in number,
                               in_bill_no_f   in varchar2) return varchar2 is
    return_msg_f          varchar2(2000);
    str_msg_f             varchar2(2000);
    i_count_f             number;
    i_error_f             number;
    i_responsemessage_e_f number;
    i_responsemessage_w_f number;
  begin
    return_msg_f := null;
    str_msg_f    := null;
  
    select count(*),
           sum(decode(po_intf.error_flag, 'Y', 1, 0)),
           sum(decode(po_intf.response_type, 'E', 1, 0)),
           sum(decode(po_intf.response_type, 'W', 1, 0))
      into i_count_f,
           i_error_f,
           i_responsemessage_e_f,
           i_responsemessage_w_f
      from cims.intf_cux_po_order po_intf
     where po_intf.po_number = in_bill_no_f
          --and po_intf.error_flag = 'Y'
          --and po_intf.item_code is null
       and exists
     (select *
              from cims.t_inv_po_headers po
             where po.entity_id = in_entity_id_f
               and po.po_num = in_bill_no_f
               and po_intf.po_number = po.po_num
               and po.finance_operating_id = po_intf.org_id);
  
    if (i_count_f > 0) and
       ((i_error_f + i_responsemessage_e_f + i_responsemessage_w_f) > 0) then
    
      select decode(po_intf.error_flag,
                    'Y',
                    po_intf.error_msg,
                    decode(po_intf.response_type,
                           'W',
                           po_intf.responsemessage,
                           'E',
                           po_intf.responsemessage,
                           decode(po_intf.esb_serial_num,
                                  null,
                                  '单据未发送给GERP',
                                  '具体原因需人工进一步核实')))
        into str_msg_f
        from cims.intf_cux_po_order po_intf
       where po_intf.po_number = in_bill_no_f
         and ((po_intf.error_flag =
             decode(sign(i_error_f - 1), 1, 'Y', 0, 'Y', 'E')) or
             (po_intf.response_type =
             decode(sign(i_responsemessage_e_f - 1), 1, 'E', 0, 'E', 'E')) or
             (po_intf.response_type =
             decode(sign(i_responsemessage_w_f - 1), 1, 'W', 0, 'W', 'W')) or
             (i_error_f = 0 and i_responsemessage_e_f = 0 and
             i_responsemessage_w_f = 0))
            --and po_intf.item_code is null
         and rownum < 2
         and exists
       (select 1
                from cims.t_inv_po_headers po
               where po.entity_id = in_entity_id_f
                 and po.po_num = in_bill_no_f
                 and po_intf.po_number = po.po_num
                 and po.finance_operating_id = po_intf.org_id);
    else
      begin
      
        select count(*)
          into i_count_f
          from cims.intf_cux_po_order po_intf
         where po_intf.po_number = in_bill_no_f
              --and po_intf.response_type = 'W'
           and po_intf.item_code is not null
           and exists (select *
                  from cims.t_inv_po_headers po
                 where po.entity_id = in_entity_id_f
                   and po.po_num = in_bill_no_f
                   and po_intf.po_number = po.po_num
                   and po.finance_operating_id = po_intf.org_id)
           and rownum < 2;
      
        if (i_count_f > 0) then
          select decode(po_intf.error_flag,
                        'Y',
                        po_intf.error_msg,
                        decode(po_intf.response_type,
                               'W',
                               po_intf.responsemessage,
                               'E',
                               po_intf.responsemessage,
                               decode(po_intf.esb_serial_num,
                                      null,
                                      '单据未发送给GERP',
                                      decode(po_intf.Status_Rav,
                                             'P',
                                             '等待ERP异步回调',
                                             '具体原因需人工进一步核实'))))
            into str_msg_f
            from cims.intf_cux_po_order po_intf
           where po_intf.po_number = in_bill_no_f
                --and po_intf.response_type = 'W'
             and po_intf.item_code is not null
             and exists
           (select *
                    from cims.t_inv_po_headers po
                   where po.entity_id = in_entity_id_f
                     and po.po_num = in_bill_no_f
                     and po_intf.po_number = po.po_num
                     and po.finance_operating_id = po_intf.org_id)
             and rownum < 2;
        end if;
      end;
    end if;
  
    if str_msg_f is null then
      return_msg_f := 'PO单接口没有错误，原因待人工进一步处理';
    
      select count(*)
        into i_count_f
        from cims.t_inv_transaction_history h
       where h.business_num = in_bill_no_f
         and h.entity_id = in_entity_id_f;
    
      if i_count_f = 0 then
        return_msg_f := 'PO单在CIMS未产生库存事务';
      end if;
    else
      return_msg_f := str_msg_f;
    
    end if;
  
    return return_msg_f;
  end;

  function f_get_erpin_qty(in_entity_id_f in number,
                           in_bill_no_f   in varchar2,
                           in_inv_code_f  in varchar2,
                           in_item_code_f in varchar2) return number is
    return_qty number;
  begin
    return_qty := 0;
  
    select nvl(sum(inv_erp.transaction_quantity), 0) gerp_qty
      into return_qty
      from apps.po_headers_all@mdims2mderp            po_erp,
           apps.rcv_transactions@mdims2mderp          po_rcv,
           apps.mtl_material_transactions@mdims2mderp inv_erp,
           apps.mtl_system_items_b@mdims2mderp        mtl
     where po_erp.po_header_id = po_rcv.po_header_id
       and inv_erp.transaction_source_id = po_rcv.po_header_id
       and inv_erp.source_line_id = po_rcv.transaction_id
       and inv_erp.rcv_transaction_id = po_rcv.transaction_id
       and inv_erp.inventory_item_id = mtl.inventory_item_id
       and inv_erp.organization_id = mtl.organization_id
       and inv_erp.subinventory_code = in_inv_code_f
       and mtl.segment1 = in_item_code_f
       and po_rcv.transaction_type in
           ('DELIVER', 'RETURN TO RECEIVING', 'ACCEPT', 'RETURN TO VENDOR')
          --DELIVER/REJECT/RETURN TO RECEIVING/ACCEPT/RETURN TO VENDOR/TRANSFER/RECEIVE
          --and inv_erp.transaction_date > to_date('2015-01-01', 'yyyy-mm-dd')
       and po_erp.segment1 = in_bill_no_f
       and exists
     (select 1
              from cims.t_inv_po_headers po, cims.t_pmt_order_header pmt
             where po.sched_order_num = pmt.order_num
               and po.po_num = po_erp.segment1
               and po.entity_id = in_entity_id_f
               and po.entity_id = pmt.entity_id)
       and exists (select 1
              from cims.t_inv_organization p
             where inv_erp.organization_id = p.organization_id
               and p.entity_id = in_entity_id_f);
  
    return return_qty;
  end;

  -- 返回不对账的SQL
  function f_get_n_reconciliation(in_entity_id_f in varchar2) return varchar2 is
    return_sql      varchar2(4000);
    return_sql_temp varchar2(4000);
  begin
    return_sql_temp := 'select inv_bill.bill_type_name business_type, ' ||
                       '       h.business_num, ' ||
                       '       h.inventory_code inv_code, ' ||
                       '       h.item_code item_code, ' ||
                       '       sum(h.transaction_quantity) cims_qty, ' ||
                       '       sum(h.transaction_quantity) gerp_qty ' ||
                       '  from cims.t_inv_transaction_history h, cims.t_inv_bill_types inv_bill ' ||
                       ' where h.entity_id = ' || in_entity_id_f ||
                       '   and h.bill_type_id = inv_bill.bill_type_id ' ||
                       '   and h.entity_id = inv_bill.entity_id ' ||
                       '  and not exists(select 1 from cims.t_inv_taction_reconciliation rec ' ||
                       '  where rec.entity_id=' || in_entity_id_f ||
                       '    and rec.business_num=h.business_num ' ||
                       '    and rec.inv_code=h.inventory_code ' ||
                       '    and rec.reconciliation_type = ''PMT_IN''' ||
                       '    and rec.item_code=h.item_code)' ||
                       '   and exists (select 1 ' ||
                       '          from cims.t_inv_taction_reconcil_line recl ' ||
                       '         where h.business_num = recl.business_num ' ||
                       '           and recl.reconciliation_type = ''PMT_IN'') ' ||
                       ' group by inv_bill.bill_type_name, ' ||
                       '          h.business_num, ' ||
                       '          h.inventory_code, ' ||
                       '          h.item_code ';
  
    return_sql := ' insert into cims.t_inv_taction_reconciliation ' ||
                  '  (entity_id, ' || '   business_type, ' ||
                  '   business_num, ' || '   reconciliation_time, ' ||
                  '   reconciliation_flag, ' || '   status, ' ||
                  '   inv_code, ' || '   item_code, ' || '   cims_qty, ' ||
                  '   gerp_qty, ' || '   remark, ' || '   created_by, ' ||
                  '   creation_date, ' || '   last_updated_by, ' ||
                  '   last_update_date,reconciliation_type,' ||
                  'erp_order_header_id,erp_logist_header_id) ' ||
                  ' select ' || in_entity_id_f ||
                  ' entity_id, business_type, business_num, ' ||
                  ' sysdate  reconciliation_time, ' ||
                  ' ''00''  reconciliation_flag, decode(sign(cims_qty-cims_qty),0,''00'',''01'')  status, ' ||
                  '   inv_code, ' || '   item_code, ' || '   cims_qty, ' ||
                  ' cims_qty gerp_qty, ' ||
                  '   ''采购单账务调整-无差异'' remark, ' ||
                  ' ''SYS''  created_by, ' || ' sysdate  creation_date, ' ||
                  ' ''SYS''  last_updated_by, ' ||
                  ' sysdate  last_update_date,''PMT_IN'' reconciliation_type,0 erp_order_header_id,0 erp_logist_header_id from (' ||
                  return_sql_temp || ') bill_all ' || '  where 1=1 ';
  
    return return_sql;
  end;

  -- 返回写入对账单据头信息
  function f_get_select_head(in_entity_id_f in varchar2) return varchar2 is
    return_sql      varchar2(4000);
    return_sql_temp varchar2(4000);
  begin
    return_sql := 'insert into cims.t_inv_taction_reconciliation ' ||
                  '  (entity_id, ' || '   business_type, ' ||
                  '   business_num, ' || '   reconciliation_time, ' ||
                  '   reconciliation_flag, ' || '   status, ' ||
                  '   inv_code, ' || '   item_code, ' || '   cims_qty, ' ||
                  '   gerp_qty, ' || '   remark, ' || '   created_by, ' ||
                  '   creation_date, ' || '   last_updated_by, ' ||
                  '   last_update_date, ' || '   reconciliation_type) ' ||
                  '  select ' || in_entity_id_f || ' entity_id, ' ||
                  '         business_type, ' || '         business_num, ' ||
                  '         sysdate reconciliation_time, ' ||
                  '         ''00'' reconciliation_flag, ' ||
                  '         decode(sign(cims_qty - gerp_qty), 0, ''00'', ''01'') status, ' ||
                  '         inv_code, ' || '         item_code, ' ||
                  '         cims_qty, ' || '         gerp_qty, ' ||
                  '         decode(sign(nvl(cims_qty, 0) - nvl(gerp_qty, 0)), ' ||
                  '                -1, ' || '                remark, ' ||
                  '                0, ' ||
                  '                ''采购单无差异'', ' ||
                  '                1, ' ||
                  '                remark) remark, ' ||
                  '         ''SYS'' created_by, ' ||
                  '         sysdate creation_date, ' ||
                  '         ''SYS'' last_updated_by, ' ||
                  '         sysdate last_update_date, ' ||
                  '         ''PMT_IN'' reconciliation_type ' || ' from ';
  
    return return_sql;
  end;

  -- 获取库存事务接口错误原因
  function f_get_intf_result(in_entity_id_f in number,
                             in_bill_no_f   in varchar2) return varchar2 is
    return_msg varchar2(2000);
    i_count_f  number;
  begin
    select count(*)
      into i_count_f
      from cims.intf_inv_transaction_head invh
     where invh.order_num = in_bill_no_f
       and nvl(invh.entity_id, in_entity_id_f) = in_entity_id_f;
  
    if i_count_f = 0 then
      return_msg := '库存事务接口表没有记录';
    end if;
  
    if i_count_f > 0 then
      select decode(nvl(invh.error_flag, 'N'),
                    'Y',
                    decode(invh.error_msg,
                           null,
                           invh.response_message,
                           invh.error_msg),
                    decode(nvl(invh.response_type, 'N'),
                           'E',
                           invh.response_message,
                           decode(invh.status,
                                  'S',
                                  'GERP异步回调正常，原因待人工进一步处理',
                                  '等待GERP异步回调处理结果')))
        into return_msg
        from cims.intf_inv_transaction_head invh
       where invh.order_num = in_bill_no_f
         and nvl(invh.entity_id, in_entity_id_f) = in_entity_id_f
         and rownum < 2;
    end if;
  
    return return_msg;
  end;

  -- 返回库存事务对账SQL-费用化出库
  function f_get_pmtout_sql(in_entity_id_f  in number,
                            in_start_date_f in varchar2,
                            in_end_date_f   in varchar2) return varchar2 is
    return_result_sql varchar2(30000);
  begin
    return_result_sql := 'insert into cims.t_inv_taction_reconciliation ' ||
                         '  (entity_id, ' || '   business_type, ' ||
                         '   business_num, ' || '   reconciliation_time, ' ||
                         '   reconciliation_flag, ' || '   status, ' ||
                         '   inv_code, ' || '   item_code, ' ||
                         '   cims_qty, ' || '   gerp_qty, ' ||
                         '   remark, ' || '   created_by, ' ||
                         '   creation_date, ' || '   last_updated_by, ' ||
                         '   last_update_date, ' ||
                         '   reconciliation_type) ' || '  select ' ||
                         in_entity_id_f || ' entity_id, ' ||
                         '        ''费用化出库'' business_type, ' ||
                         '         bill_no business_num, ' ||
                         '         sysdate reconciliation_time, ' ||
                         '         ''00'' reconciliation_flag, ' ||
                         '         decode(sign(cims_qty - gerp_qty), 0, ''00'', ''01'') status, ' ||
                         '         inv_code, ' || '         item_code, ' ||
                         '         cims_qty, ' || '         gerp_qty, ' ||
                         '         decode(sign(nvl(cims_qty, 0) - nvl(gerp_qty, 0)), ' ||
                         '                -1, ' ||
                         '                ''费用化出库有差异'', ' ||
                         '                0, ' ||
                         '                ''费用化出库无差异'', ' ||
                         '                1, ' ||
                         '                ''费用化出库有差异-待确认'') remark, ' ||
                         '         ''SYS'' created_by, ' ||
                         '         sysdate creation_date, ' ||
                         '         ''SYS'' last_updated_by, ' ||
                         '         sysdate last_update_date, ' ||
                         '         ''PMT_OUT'' reconciliation_type ' ||
                         '    from (select bill_no, ' ||
                         '                 inv_code, ' ||
                         '                 item_code, ' ||
                         '                 sum(cims_qty) cims_qty, ' ||
                         '                 sum(gerp_qty) gerp_qty ' ||
                         '            from (select /*+ DRIVING_SITE(inv_erp) */ ''GERP'' sys_name, ' ||
                         '                         inv_erp.transaction_reference bill_no, ' ||
                         '                         inv_erp.subinventory_code inv_code, ' ||
                         '                         mtl.segment1 item_code, ' ||
                         '                         inv_erp.transaction_quantity gerp_qty, ' ||
                         '                         0 cims_qty ' ||
                         '                    from apps.mtl_material_transactions@mdims2mderp inv_erp, ' ||
                         '                         apps.mtl_system_items_b@mdims2mderp        mtl ' ||
                         '                   where 1 = 1 ' ||
                         '                     and inv_erp.inventory_item_id = mtl.inventory_item_id ' ||
                         '                     and inv_erp.organization_id = mtl.organization_id ' ||
                        --'                     and inv_erp.attribute13 is null ' ||
                         '                     and inv_erp.transaction_date > ' ||
                         '                         to_date(''' ||
                         in_start_date_f || ''', ''yyyy-mm-dd'') ' ||
                         '                     and inv_erp.transaction_date < ' ||
                         '                         to_date(''' ||
                         in_end_date_f || ''', ''yyyy-mm-dd'') ' ||
                         '                     and inv_erp.organization_id in (select p.organization_id from cims.t_inv_organization p where p.entity_id=' ||
                         in_entity_id_f ||
                         '                      )  and inv_erp.transaction_reference in ' ||
                         '                   (select pmt_cims.pmt_send_num  ' ||
                         '                            from cims.t_pmt_collar_send_head pmt_cims ' ||
                         '                               where 1=1 ' ||
                        -- '                           and pmt_cims.pmt_send_num = ' ||
                        -- '                                 inv_erp.transaction_reference ' ||
                         '                             and pmt_cims.entity_id=' ||
                         in_entity_id_f ||
                         '                             and not exists ' ||
                         '                           (select 1 ' ||
                         '                                    from cims.t_inv_taction_reconciliation recc ' ||
                         '                                   where recc.entity_id = ' ||
                         in_entity_id_f ||
                         '                                     and recc.business_num = pmt_cims.pmt_send_num ' ||
                         '                                     and recc.reconciliation_type = ''PMT_OUT'')) ' ||
                         '                     and inv_erp.source_code=''CIMS'' ' || --by zxs 20150918 add
                         '                  union all ' ||
                         '                  select ''CIMS'' sys_name, ' ||
                         '                         invh.business_num bill_no, ' ||
                         '                         invh.inventory_code inv_code, ' ||
                         '                         invh.item_code, ' ||
                         '                         0 gerp_qty, ' ||
                         '                         invh.transaction_quantity cims_qty ' ||
                         '                    from cims.t_inv_transaction_history invh ' ||
                         '                   where 1 = 1 ' ||
                         '                     and invh.transaction_date > ' ||
                         '                         to_date(''' ||
                         in_start_date_f || ''', ''yyyy-mm-dd'') ' ||
                         '                     and invh.transaction_date < ' ||
                         '                         to_date(''' ||
                         in_end_date_f || ''', ''yyyy-mm-dd'') ' ||
                         '                     and invh.entity_id=' ||
                         in_entity_id_f ||
                         '                     and exists ' ||
                         '                   (select  pmt_cims.pmt_send_num ' ||
                         '                            from cims.t_pmt_collar_send_head pmt_cims, ' ||
                         '                                 cims.up_codelist up ' ||
                         '                           where pmt_cims.status = up.code_value ' ||
                         '                             and up.codetype=''BD_BILL_STATUS'' ' ||
                         '                             and up.code_value=''23''    ' ||
                         '                             and pmt_cims.entity_id = ' ||
                         in_entity_id_f ||
                         '           and pmt_cims.pmt_send_num = invh.business_num ' ||
                         '                             and  not exists (select 1 ' ||
                         '                                    from cims.t_inv_taction_reconciliation recc ' ||
                         '                                   where recc.entity_id = ' ||
                         in_entity_id_f || ' ' ||
                         '                                     and recc.business_num = pmt_cims.pmt_send_num ' ||
                         '                                     and recc.reconciliation_type = ''PMT_OUT'') ' ||
                         '                             )) ' ||
                         '           group by bill_no, inv_code, item_code) bill_all ' ||
                         '   where 1 = 1 ' ||
                         '        and not exists(select 1 from cims.t_inv_taction_reconciliation rec ' ||
                         '          where rec.business_num=bill_all.bill_no and rec.reconciliation_type=''PMT_OUT'' and rec.entity_id=' ||
                         in_entity_id_f || ')';
  
    return return_result_sql;
  end;

begin
  -- Test statements here

  -- 初始化参数
  --v_entity_id := 10;
  v_entity_id    := I_ENTITY_ID;
  str_start_date := to_char(sysdate - 180, 'yyyy-mm-dd');
  --str_end_date   := '2015-01-23';
  str_end_date := to_char(sysdate + 1, 'yyyy-mm-dd');

  str_status_end := '14'; --单据最终状态-接收

  b_immediate_commit := true; -- 全过程处理一次完成

  --- 删除对账不成功单据
  str_delete_sql := ' delete cims.t_inv_taction_reconciliation rec ' ||
                    '  where rec.entity_id = ' || v_entity_id ||
                    '   and rec.reconciliation_type like ''PMT%''' ||
                    '   and exists (select 1 ' ||
                    '          from cims.t_inv_taction_reconciliation rec2 ' ||
                    '         where rec.business_num = rec2.business_num ' ||
                    '           and rec2.status = ''01'' ' ||
                    '           and rec2.reconciliation_type in (''PMT_IN'',''PMT_OUT'')) ';

  --dbms_output.put_line('11');
  execute immediate str_delete_sql;
  if b_immediate_commit then
    commit;
  end if;

  --不参与对账单据
  str_insert_sql_rec := f_get_n_reconciliation(v_entity_id);

  --dbms_output.put_line(str_insert_sql_rec);

  if str_insert_sql_rec is not null then
    execute immediate str_insert_sql_rec;
    if b_immediate_commit then
      commit;
    end if;
  end if;

  --记录开始时间,用于限定更新范围
  select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
    into str_start_time
    from dual;

  /*str_insert_sql_rec := null;
  str_insert_sql_rec := f_get_all_inv_transaction_sql(v_entity_id,
                                                      str_start_date,
                                                      str_end_date);
  if str_insert_sql_rec is not null then
    execute immediate str_insert_sql_rec;
    if b_immediate_commit then
      commit;
    end if;
  end if;
  
  --记录结束时间
  select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
    into str_end_time
    from dual;*/

  --所有单据: c_reconciliation_pmt_bills
  --单个单据库存事务： c_reconciliation_pmt_bill
  --单据、子库、产品对应数量 f_get_erp_qty
  -- in_status_end_f in varchar2, in_start_date_f in varchar2, in_end_date_f in varchar2
  for c_reconciliation_pmtin_bills01 in c_reconciliation_pmtin_bills(v_entity_id,
                                                                     str_status_end,
                                                                     str_start_date,
                                                                     str_end_date) loop
  
    -- select_header:f_get_select_head      
    -- str_select_sql  
    str_select_sql_tmp := null;
  
    for c_reconciliation_pmtin_bill01 in c_reconciliation_pmtin_bill(v_entity_id,
                                                                     c_reconciliation_pmtin_bills01.business_num) loop
    
      i_qty_temp := f_get_erpin_qty(v_entity_id,
                                    c_reconciliation_pmtin_bill01.business_num,
                                    c_reconciliation_pmtin_bill01.inv_code,
                                    c_reconciliation_pmtin_bill01.item_code);
    
      if i_qty_temp <> c_reconciliation_pmtin_bill01.cims_qty then
        str_msg := f_get_billin_result(v_entity_id,
                                       c_reconciliation_pmtin_bills01.business_num);
      else
        str_msg := '采购单库存事务无差异';
      end if;
    
      if str_select_sql_tmp is null then
        str_select_sql_tmp := ' select ''' ||
                              c_reconciliation_pmtin_bill01.business_num ||
                              ''' business_num, ''' ||
                              c_reconciliation_pmtin_bill01.inv_code ||
                              ''' inv_code,''' ||
                              c_reconciliation_pmtin_bill01.item_code ||
                              ''' item_code, ' ||
                              c_reconciliation_pmtin_bill01.cims_qty ||
                              ' cims_qty, ' || i_qty_temp || ' gerp_qty,''' ||
                              str_msg || ''' remark,''' ||
                              c_reconciliation_pmtin_bills01.business_type ||
                              ''' business_type from dual ';
      else
        str_select_sql_tmp := str_select_sql_tmp || ' union all ' ||
                              ' select ''' ||
                              c_reconciliation_pmtin_bill01.business_num ||
                              ''' business_num, ''' ||
                              c_reconciliation_pmtin_bill01.inv_code ||
                              ''' inv_code,''' ||
                              c_reconciliation_pmtin_bill01.item_code ||
                              ''' item_code, ' ||
                              c_reconciliation_pmtin_bill01.cims_qty ||
                              ' cims_qty, ' || i_qty_temp || ' gerp_qty,''' ||
                              str_msg || ''' remark,''' ||
                              c_reconciliation_pmtin_bills01.business_type ||
                              ''' business_type from dual ';
      end if;
    
    end loop; -- c_reconciliation_pmt_bill
  
    if str_select_sql_tmp is not null then
      str_select_sql := null;
      str_select_sql := f_get_select_head(v_entity_id);
    
      str_select_sql := str_select_sql || '(' || str_select_sql_tmp || ')';
    
      if str_select_sql is not null then
        execute immediate str_select_sql;
        if b_immediate_commit then
          commit;
        end if;
      end if;
    end if;
  end loop; -- c_reconciliation_pmt_bills

  --- 费用化出库
  str_insert_sql_rec := f_get_pmtout_sql(v_entity_id,
                                         str_start_date,
                                         str_end_date);

  if str_insert_sql_rec is not null then
    execute immediate str_insert_sql_rec;
    if b_immediate_commit then
      commit;
    end if;
  end if;

  --记录结束时间
  select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
    into str_end_time
    from dual;

  -- c_reconciliation_diffpmt
  -- 获取差异原因
  for c_reconciliation_diffpmt01 in c_reconciliation_diffpmt(v_entity_id,
                                                             str_start_time,
                                                             str_end_time) loop
    str_msg := f_get_intf_result(v_entity_id,
                                 c_reconciliation_diffpmt01.bill_no);
  
    str_select_sql_tmp := 'update cims.t_inv_taction_reconciliation rec ' ||
                          ' set rec.remark = ''' || str_msg ||
                          ''' where rec.entity_id = ' || v_entity_id ||
                          ' and rec.business_num=''' ||
                          c_reconciliation_diffpmt01.bill_no ||
                          ''' and rec.reconciliation_type = ''PMT_OUT''';
  
    if str_select_sql_tmp is not null then
      execute immediate str_select_sql_tmp;
      if b_immediate_commit then
        commit;
      end if;
    end if;
  
  end loop;

end P_INV_PMT_TRANSACTION;

  /*** 参考SQL
  
  select po_erp.segment1              business_num,
         inv_erp.subinventory_code    inv_code,
         mtl.segment1                 item_code,
         inv_erp.transaction_quantity gerp_qty,
         0                            cims_qty
    from apps.po_headers_all@mdims2mderp            po_erp,
         apps.rcv_transactions@mdims2mderp          po_rcv,
         apps.mtl_material_transactions@mdims2mderp inv_erp,
         apps.mtl_system_items_b@mdims2mderp        mtl
   where po_erp.po_header_id = po_rcv.po_header_id
     and inv_erp.transaction_source_id = po_rcv.po_header_id
     and inv_erp.source_line_id = po_rcv.transaction_id
     and inv_erp.rcv_transaction_id = po_rcv.transaction_id
     and inv_erp.inventory_item_id = mtl.inventory_item_id
     and inv_erp.organization_id = mtl.organization_id
     and po_rcv.transaction_type = 'DELIVER'
     and inv_erp.transaction_date > to_date('2015-01-01', 'yyyy-mm-dd')
     and po_erp.segment1 = 'P140000577'
     and exists
   (select *
            from cims.t_inv_po_headers po, cims.t_pmt_order_header pmt
           where po.sched_order_num = pmt.order_num
             and po.po_num = po_erp.segment1
             and po.entity_id = 14
             and po.entity_id = pmt.entity_id)
     and exists (select 1
            from cims.t_inv_organization p
           where inv_erp.organization_id = p.organization_id
             and p.entity_id = 14)
  union all
  select h.business_num,
         h.inventory_code inv_code,
         h.item_code,
         0 gerp_qty,
         h.transaction_quantity cims_qty
    from cims.t_inv_transaction_history h
   where h.entity_id = 14
     and h.business_num = 'P140000577'
     and not exists (select 1
            from cims.t_inv_taction_reconciliation rec
           where rec.business_num = h.business_num
             and rec.entity_id = h.entity_id
             and rec.reconciliation_type = 'PMT')
     and exists
   (select *
            from cims.t_inv_po_headers po, cims.t_pmt_order_header pmt
           where po.sched_order_num = pmt.order_num
             and po.po_num = h.business_num
             and po.entity_id = h.entity_id
             and po.entity_id = pmt.entity_id
             and po.old_po_num is null);
  
  
  **/
/

