create PACKAGE      PKG_AR_BOND IS

  -- AUTHOR  : TIANMENGZHU
  -- CREATED : 2015/8/1 10:55:32
  -- PURPOSE : 保函价差转到款、价差退款接口

  V_CONTROL_RP   CONSTANT VARCHAR2(5) := 'RP'; --触发信控方式：收款
  V_CONTROL_RF   CONSTANT VARCHAR2(5) := 'RF'; --触发信控方式：退款
  V_CONTROL_TP   CONSTANT VARCHAR2(5) := 'TP'; --触发信控方式：三方收款
  V_CONTROL_WO   CONSTANT VARCHAR2(5) := 'WO'; --触发信控方式：收款冲销
  V_CONTROL_TPWO CONSTANT VARCHAR2(5) := 'TPWO'; --触发信控方式：三方收款冲销
  V_CONTROL_RFRK CONSTANT VARCHAR2(5) := 'RFRK'; --触发信控方式：退款撤销

  V_R_VENDOR_SITE_INSIDE CONSTANT VARCHAR2(30) := '内部'; --供需关系的供应商地点值为内部
  V_R_VENDOR_SITE_NOT_TRADE CONSTANT VARCHAR2(30) := '非贸易型'; --供需关系的供应商地点值为非贸易型

  V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常

  --转款单保存校验
  PROCEDURE P_VALIDATE_TURNFEE_SAVE(P_CASH_TURNFEE_ID IN NUMBER, --转款头ID
                                    P_MESSAGE         OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                    );

  --核销：转款单保存校验
  PROCEDURE P_VALI_TURNFEE_SAVE_WRITE_OFF(P_CASH_TURNFEE_ID IN NUMBER, --转款头ID
                                              P_MESSAGE         OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                              );

  --转款单确认校验
  PROCEDURE P_VALIDATE_TURNFEE_CONFIRM(P_CASH_TURNFEE_ID        IN NUMBER, --转款头ID
                                       P_ERP_RECEIPT_METHOD_ID  OUT NUMBER, --ERP收款方法ID
                                       P_ERP_BANK_ACCT_USE_ID   OUT NUMBER, --ERP收款方银行账户ID
                                       P_ERP_BANK_ACCTOUNT_ID   OUT NUMBER, --ERP收款银行账户ID
                                       P_ERP_BANK_ACCTOUNT_NAME OUT VARCHAR2, --ERP收款银行账户名称
                                       P_SET_BOOK_ID            OUT NUMBER, --账套ID
                                       P_MESSAGE                OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                       );

  --触发信控
  PROCEDURE P_CREDIT_CONTRL(P_CASH_RECEIPT_ID IN NUMBER, --收款头ID
                            P_ENTITY_ID       IN NUMBER, --主体ID
                            P_ACCOUNT_ID      IN NUMBER, --账户ID
                            P_CUSTOMER_ID     IN NUMBER, --客户ID
                            P_CONTROL_FLAG    IN VARCHAR2, --触发信控方式：收款、退款、三方收款、收款冲销、三方冲销、退款撤销
                            P_USER_ACCOUNT    IN VARCHAR2,
                            P_MESSAGE         OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                            );

  --转款确认更改状态，制单->确认，更改状态，确认人，确认日期
  PROCEDURE P_UPDATE_TURNFEE_STATUS(P_CASH_TURNFEE_ID IN NUMBER, --转款头ID
                                    P_USER_ACCOUNT    IN VARCHAR2, --用户账户
                                    P_MESSAGE         OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                    );
  --转款单生成收款单
  PROCEDURE P_TURNFEE_TO_RECEIPT(P_CASH_TURNFEE_ID       IN NUMBER, --转款头ID
                                 P_MESSAGE               OUT VARCHAR2, --成功则返回“SUCCESS”，否则返回出错信息
                                 P_CASH_RECEIPT_ID       OUT NUMBER, --成功则返回收款单ID（客户内）
                                 P_OUT_CASH_RECEIPT_ID   OUT NUMBER, --成功则返回转出收款单ID（客户间）
                                 P_IN_CASH_RECEIPT_ID    OUT NUMBER, --成功则返回转入收款单ID（客户间）
                                 P_CASH_RECEIPT_CODE     OUT VARCHAR2, --成功则返回收款单号（客户内）
                                 P_OUT_CASH_RECEIPT_CODE OUT VARCHAR2, --成功则返回转出收款单号（客户间）
                                 P_IN_CASH_RECEIPT_CODE  OUT VARCHAR2 --成功则返回转入收款单号（客户间）
                                 );

  --转款确认（包括保存校验，确认校验，制单-确认，生成收款单，触发信控）
  PROCEDURE P_TURNFEE_CONFIRM(P_CASH_TURNFEE_ID       IN NUMBER, --转款头ID
                              P_USER_ACCOUNT          IN VARCHAR2, --用户账户
                              P_MESSAGE               OUT VARCHAR2, --成功则返回“SUCCESS”，否则返回出错信息
                              P_CASH_RECEIPT_CODE     OUT VARCHAR2, --成功则返回收款单号（客户内）
                              P_OUT_CASH_RECEIPT_CODE OUT VARCHAR2, --成功则返回转出收款单号（客户间）
                              P_IN_CASH_RECEIPT_CODE  OUT VARCHAR2 --成功则返回转入收款单号（客户间）
                              );

  --核销时，转款确认（包括保存校验，确认校验，制单-确认，生成收款单，触发信控）
  PROCEDURE P_TURNFEE_CONFIRM_WRITE_OFF(P_CASH_TURNFEE_ID       IN NUMBER, --转款头ID
                                        P_USER_ACCOUNT          IN VARCHAR2, --用户账户
                                        P_MESSAGE               OUT VARCHAR2, --成功则返回“SUCCESS”，否则返回出错信息
                                        P_CASH_RECEIPT_CODE     OUT VARCHAR2, --成功则返回收款单号（客户内）
                                        P_OUT_CASH_RECEIPT_CODE OUT VARCHAR2, --成功则返回转出收款单号（客户间）
                                        P_IN_CASH_RECEIPT_CODE  OUT VARCHAR2 --成功则返回转入收款单号（客户间）
                                        );

  /*
  * 跨OU转款引关联交易
  */
  PROCEDURE P_CROSS_OU_CONNECT_TARNSACTION(P_CASH_TURNFEE_ID              IN NUMBER, --转款头ID
                                           P_MESSAGE                      OUT VARCHAR2, --成功则返回“SUCCESS”，否则返回出错信息
                                           P_REL_INV_APPLY_HEADERS_TRX_NO OUT VARCHAR2 --成功则返回关联交易流水号
                                           );

  -- 收款方法校验（价差）
  FUNCTION F_RECEIPT_METHOD_VERIFY(P_HEAD_ID           NUMBER, --收款头接口表ID
                                   P_BUSINESS_TYPE     VARCHAR2, --业务分类
                                   P_RECEIPT_METHOD_ID NUMBER --收款方法ID
                                   ) RETURN VARCHAR2; --成功返回'SUCCESS'，否则返回出错信息

  -- 收款单制单校验（价差）
  FUNCTION F_RECEIPT_SAVE_VERIFY(P_HEAD_ID NUMBER --收款头接口表ID
                                 ) RETURN VARCHAR2; --成功返回'SUCCESS'，否则返回出错信息

  /*
    -- 收款单确认校验（价差）
    PROCEDURE P_RECEIPT_CONFIRM_VERIFY(P_CASH_RECEIPT_ID       IN NUMBER, --收款头ID
                                       P_INTO_ERP_FLAG         IN VARCHAR2, --引入ERP标志
                                       P_INTO_BAN_FLAG         IN VARCHAR2, --引入资金标志
                                       P_INTO_ERP_HANDLE       IN VARCHAR2, --引入ERP方式：发票、收款
                                       P_ERP_RECEIPT_METHOD_ID OUT NUMBER, --ERP收款方法ID
                                       P_ERP_BANK_ACCT_USE_ID  OUT NUMBER, --ERP收款方银行账户ID
                                       P_ERP_BANK_ACCOUNT_ID   OUT NUMBER, --GTSP收款方银行账户ID
                                       P_ERP_BANK_ACCOUNT_NAME OUT VARCHAR2, --ERP收款方银行账户名称
                                       P_CUST_BANK_ACCOUNT     OUT VARCHAR2, --客户银行账户
                                       P_CUST_BANK             OUT VARCHAR2, --客户银行名称
                                       P_SET_OUT_ID            OUT NUMBER, --账套ID
                                       P_MESSAGE               OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                       );
  */

  -- 收款单制单（价差）
  PROCEDURE P_RECEIPT_HEAD_SAVE(P_HEAD_ID                   IN NUMBER, --收款头接口表ID
                                P_MESSAGE                   OUT VARCHAR2, --成功返回'SUCCESS'，否则返回出错信息
                                P_CASH_RECEIPT_ID           OUT NUMBER, --返回生成的收款单ID
                                P_REVERSE_CASH_RECEIPT_ID   OUT NUMBER, --返回生成的逆向收款单ID
                                P_CASH_RECEIPT_CODE         OUT VARCHAR2, --返回生成的收款单号
                                P_REVERSE_CASH_RECEIPT_CODE OUT VARCHAR2 --返回生成的逆向收款单号，若不生成逆向收款单则为 NULL
                                );

  -- 收款单确认（价差）
  PROCEDURE P_RECEIPT_HEAD_CONFIRM(P_CASH_RECEIPT_ID   IN NUMBER, --收款头ID
                                   P_USER_ACCOUNT      IN VARCHAR2, --用户账户
                                   P_MESSAGE           OUT VARCHAR2, --成功则返回“SUCCESS”，否则返回出错信息
                                   P_CASH_RECEIPT_CODE OUT VARCHAR2 --成功则返回收款单号
                                   );

  -- 正向、逆向收款优先核销（价差）
  PROCEDURE P_PRIORITY_WRITE_OFF(P_HEAD_ID IN NUMBER, --收款头接口表ID
                                 P_MESSAGE OUT VARCHAR2 --成功返回'SUCCESS'，否则返回出错信息
                                 );

END PKG_AR_BOND;
/

