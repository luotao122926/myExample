create PACKAGE PKG_INV_LOCKIN AS


  --------------------------------------------------------------------------
   --Author: guibr
   --Created: 2019-02-18
   --锁定库存|解锁库存  处理
   --------------------------------------------------------------------------
   Procedure P_LOCKIN_MAIN_BY_DISTRICT(
               IS_DISTRICT_CODE  IN  VARCHAR2
               ,IS_ITEM_CODE      IN  VARCHAR2
               ,IS_ITEM_CLASS_CODE     IN out  VARCHAR2
               ,IN_ENTITY_ID     IN  NUMBER
              ,IS_INVENTORY_CODE   IN VARCHAR2
               ,IS_SHARE_VENDOR_CODE IN VARCHAR2   
               ,IN_LOCK_QTY      IN  NUMBER
               ,IS_LOCK_TYPE     IN  VARCHAR2
               ,IN_LOCK_LEVEL    IN  NUMBER
               ,IS_DELIVERY_NUMBER  IN  VARCHAR2
               ,IS_ORDER_NUMBER  IN  VARCHAR2
               ,IS_CHILD_ORDER_NUMBER  IN  VARCHAR2
               ,IS_USER_CODE     IN  varchar2
               ,IS_sales_center_code in varchar2
               ,OS_INVENTORY_LOCK  OUT VARCHAR2 --返回锁定释放仓库及对应数量
               ,OS_MESSAGE   OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
               ,OS_JSON_MSG   OUT VARCHAR2 --成功则返回“OK”，否则返回格式化出错信息
   );


   --------------------------------------------------------------------------
   --Author: guibr
   --Created: 2019-02-18
   --锁定库存|解锁库存  入口
   --------------------------------------------------------------------------
   Procedure P_LOCKIN_MAIN(
                IN_BATCH_NUM     IN  NUMBER
               ,IS_LOCK_TYPE     IN  VARCHAR2
               ,IN_LOCK_LEVEL    IN  NUMBER
               ,IS_USER_CODE     IN  VARCHAR2
               ,OS_MESSAGE   OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
   ); 
     
   
   

  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-02-18
  --锁定库存|解锁库存  处理
  --------------------------------------------------------------------------
  Procedure P_LOCKIN_HAND(
                 IN_TRANSACTION_ID     IN  NUMBER
               ,IN_ENTITY_ID     IN  NUMBER
               ,IN_INVENTORY_ID  IN  NUMBER
               ,IS_INVENTORY_CODE  IN  VARCHAR2
               ,IN_ITEM_ID       IN  NUMBER
               ,IS_ITEM_CODE     IN  VARCHAR2
               ,IS_ITEM_UOM      IN  VARCHAR2
               ,IS_ITEM_NAME     IN  VARCHAR2
               ,IS_PRODUCTMODEL   IN  VARCHAR2
               ,IN_LOCK_QTY      IN  NUMBER
               ,NEED_LOCK        IN  VARCHAR2  --Y|N 按需锁定，仓库有多少锁定多少，不检查仓库库存
               ,IS_LOCK_TYPE     IN  VARCHAR2
               ,IN_LOCK_LEVEL    IN  NUMBER
               ,IS_USER_CODE     IN  VARCHAR2
               ,ON_FACT_LOCK_QTY OUT  NUMBER  --按需锁定需要 返回实际锁定数量
               ,OS_MESSAGE   OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
               ,OS_JSON_MSG   OUT VARCHAR2 --成功则返回“OK”，否则返回格式化出错信息
  ); 
  
  
  
   --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-03-02
  --按订单  区域锁定库存
  --------------------------------------------------------------------------
  Procedure P_LOCKIN_ADD_HAND(
                IN_ENTITY_ID     IN  NUMBER
               ,IS_SHARE_VENDOR_CODE  IN VARCHAR2
               ,IS_INVENTORY_CODE   IN VARCHAR2
               ,IS_DISTRICT_CODE  IN  VARCHAR2
               ,IN_ITEM_ID       IN  NUMBER
               ,IS_ITEM_CODE     IN  VARCHAR2
               ,IS_ITEM_UOM      IN  VARCHAR2
               ,IS_ITEM_NAME     IN  VARCHAR2
                ,IS_PRODUCTMODEL   IN  VARCHAR2
               ,IN_LOCK_QTY      IN  NUMBER
               ,IS_LOCK_TYPE     IN  VARCHAR2
               ,IN_LOCK_LEVEL    IN  NUMBER
               ,IS_DELIVERY_NUMBER  IN  VARCHAR2
               ,IS_ORDER_NUMBER  IN  VARCHAR2
               ,IS_CHILD_ORDER_NUMBER  IN  VARCHAR2
               ,IS_USER_CODE     IN  varchar2
               ,IS_sales_center_code in varchar2
               ,OS_UNLOCK_COMPLETION OUT VARCHAR2  --返回是否解锁完成标志
               ,ON_FACT_LOCK_QTY OUT NUMBER  --返回实际解锁数量
               ,OS_INVENTORY_LOCK  OUT VARCHAR2 --返回锁定释放仓库及对应数量
               ,OS_MESSAGE   OUT VARCHAR2    --成功则返回“OK”，否则返回出错信息
               ,OS_JSON_MSG   OUT VARCHAR2 --成功则返回“OK”，否则返回格式化出错信息
    );--返回值      

  
  
  
  
  
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-03-02
  --按订单解锁库存
  --------------------------------------------------------------------------
  Procedure P_LOCKIN_SUB_HAND(
               IN_ENTITY_ID     IN  NUMBER
               ,IS_SHARE_VENDOR_CODE  IN VARCHAR2
               ,IN_ITEM_ID       IN  NUMBER
               ,IS_ITEM_CODE     IN  VARCHAR2
               ,IS_ITEM_UOM      IN  VARCHAR2
               ,IS_ITEM_NAME     IN  VARCHAR2
                ,IS_PRODUCTMODEL   IN  VARCHAR2
               ,IN_LOCK_QTY      IN  NUMBER
               ,IS_LOCK_TYPE     IN  VARCHAR2
               ,IN_LOCK_LEVEL    IN  NUMBER
               ,IS_DELIVERY_NUMBER  IN  VARCHAR2
               ,IS_ORDER_NUMBER  IN  VARCHAR2
               ,IS_CHILD_ORDER_NUMBER  IN  VARCHAR2
               ,IS_USER_CODE     IN  VARCHAR2
               ,OS_UNLOCK_COMPLETION OUT VARCHAR2  --返回是否解锁完成标志
               ,ON_FACT_UNLOCK_QTY OUT NUMBER  --返回实际解锁数量
               ,OS_INVENTORY_LOCK  OUT VARCHAR2 --返回锁定释放仓库及对应数量
               ,OS_MESSAGE   OUT VARCHAR2    --成功则返回“OK”，否则返回出错信息
               ,OS_JSON_MSG   OUT VARCHAR2 --成功则返回“OK”，否则返回格式化出错信息
    ); --返回值 
       
  
  
     --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-02-18
  --插入锁定事物历史
  --------------------------------------------------------------------------
  Procedure P_LOCKIN_HISTORY_ADD(
               IN_ENTITY_ID     IN  NUMBER
                ,IS_SHARE_VENDOR_CODE IN VARCHAR2   
               ,IN_INVENTORY_ID  IN  NUMBER
               ,IS_INVENTORY_CODE  IN  VARCHAR2
               ,IN_ITEM_ID       IN  NUMBER
               ,IS_ITEM_CODE     IN  VARCHAR2
               ,IS_ITEM_UOM      IN  VARCHAR2
               ,IN_LOCK_QTY      IN  NUMBER
               ,IN_SET_ITEM_ID   IN  NUMBER
               ,IN_SET_QTY   IN  NUMBER
               ,IS_LOCK_TYPE     IN  VARCHAR2
               ,IN_LOCK_LEVEL    IN  NUMBER
               ,IS_DELIVERY_NUMBER  IN  VARCHAR2
               ,IS_ORDER_NUMBER  IN  VARCHAR2
               ,IS_CHILD_ORDER_NUMBER  IN  VARCHAR2
               ,IS_USER_CODE     IN  VARCHAR2
               ,OS_MESSAGE   OUT VARCHAR2    --成功则返回“OK”，否则返回出错信息
   );--返回值  
   
   
   
     
 ------------------------------------------------------------
  /*   根据锁定类型获取不同的仓库列表         */
  ------------------------------------------------------------
  FUNCTION F_GET_INV_LIST(P_ENTITY_ID     IN NUMBER,
                          P_LOCKIN_TYPE   IN VARCHAR2, --网批 standard|库存共享 share|仓库 inv
                          P_DISTRICT_CODE IN VARCHAR2,
                          P_SALES_CENTER_CODE IN VARCHAR2,
                          P_INVENTORY_CODE   IN VARCHAR2
                          )
  RETURN TBL_INV_INVENTORY 
  PIPELINED;
       

END PKG_INV_LOCKIN;
/

