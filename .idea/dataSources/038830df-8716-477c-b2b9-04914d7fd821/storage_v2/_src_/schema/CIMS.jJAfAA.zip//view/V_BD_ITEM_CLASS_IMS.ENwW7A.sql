create view V_BD_ITEM_CLASS_IMS as
select ITEM_CLASS_ID,
       CLASS_CODE,
       CLASS_NAME,
       CLASS_TYPE,
       PARENTC_LASS_ID PARENT_CLASS_ID,
       CODE_ORDER,
       ENTITY_ID,
       created_by,
       creation_date,
       last_updated_by,
       last_update_date
  from T_BD_ITEM_CLASS
 -- where PROMOTION_FLAG = 'N'
/

