create Package      Pkg_Pln_Shares Is
 
  v_True  Constant Varchar2(2) := 'Y';
  v_False Constant Varchar2(2) := 'N';
  -- Author  : NICRO.LI
  -- Created : 2014-08-20 10:43:59
  -- Purpose : 订单管理 制定发货计划相关功能包

  ---------------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2014-08-20 10:43:59
  -- Purpose : 订单管理 自动生成发货计划
  ---------------------------------------------------------------------------------
  Procedure p_Auto_Create_Share(p_Pln_Order_Line_Id In Number, --订单行ID
                                p_Inventory_Id      In Number, --仓库ID(财务仓)
                                p_Trans_Sign_Flag   In Number, --生成发货计划方向，1：生成发货计划  -1：取消发货计划
                                p_Trans_Share_Qty   In Number, --分配数量（只传正数）
                                p_Entity_Id         In Number, --主体ID
                                p_Pln_Wip_Ord_Match In Varchar, --工单与订单新匹配模式
                                p_User_Code         In Varchar2,
                                p_Result            Out Varchar2,
                                p_Inv_Affirm_Flag   In Varchar2 Default v_False, --库存评审标志
                                p_Sub_Item_id       In Number Default Null       --散件产品ID
                                );

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose:生成订单库存发货计划
  -----------------------------------------------------------------------------------------
  Procedure p_Create_Share_Shipment(p_Entity_Id       In Number, --主体ID
                                    p_Order_Line_Id   In Number, --订单行
                                    p_Inventory_Id    In Number, --仓库ID
                                    p_Trans_Qty       In Number, --分配数量
                                    p_User_Code       In Varchar2, --用户ID
                                    p_Result          Out Varchar2, --正
                                    p_Ord_Share_Id    Out Number, --返回分配行ID
                                    p_Inv_Affirm_Flag In Varchar2 Default v_False, --库存评审标志
                                    p_Source_Order_Share_Id In Number Default Null --来源分配行ID
                                    );

  ---------------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2014-10-20 10:43:59
  -- Purpose : 订单管理 调拨单接收按来源发货计划ID生成新发货计划行
  ---------------------------------------------------------------------------------
  Procedure p_Transfer_To_Shipment(p_Transfer_Head_Id In Number, --调拨单头ID
                                   p_Operation_Type   In Varchar2, --操作类型：AUDITING:审核、RECEIVING:接收
                                   p_Entity_Id        In Number, --主体ID
                                   p_User_Code        In Varchar2, --用户编码
                                   p_Result           Out Varchar2);

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 计划订单发货计划下达到物流运力计划
  -----------------------------------------------------------------------------------------
  Procedure p_Share_To_Lgshipplan(p_Entity_Id        In Number, --主体ID,
                                  p_Order_Share_Id   In Number, --明细行ID
                                  p_Order_Type       In Varchar2, --运力任务单据下达类型  1006:销售  1008：调拨
                                  p_User_Code        In Varchar2, --用户ID
                                  p_Lg_Plan_Batch_Id In Number, --物流批次ID
                                  p_Result           Out Varchar2,
                                  p_Msg              Out Varchar2);

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 计划订单发货计划下达到物流运力计划
  -----------------------------------------------------------------------------------------
  Procedure p_Share_To_Lgshipplan_All(p_Entity_Id        In Number, --主体ID,
                                      p_Order_Shares     In Varchar2, --发货计划ID列表
                                      p_User_Code        In Varchar2, --用户编码
                                      p_Result           In Out Varchar2, --成功返回“SUCCESS”
                                      p_Msg              In Out Varchar2,
                                      p_Lg_Plan_Batch_Id Out Number --物流批次ID
                                      );

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 计划订单特殊占用释放库存  特殊占用含：破损调拨、采购退货、库存盘点
  -----------------------------------------------------------------------------------------
  Procedure p_Order_Special_Occupy(p_Entity_Id     In Number,
                                   p_Order_Head_Id In Number,
                                   p_Bill_Type_Id  In Number,
                                   p_User_Code     In Varchar2,
                                   p_Result        Out Varchar2);

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 计划订单特殊占用释放特殊占用数据  特殊占用含：破损调拨、采购退货、库存盘点
  -----------------------------------------------------------------------------------------
  Procedure p_Release_Special_Occ_Single(p_Entity_Id            In Number, --主体ID,
                                         p_Item_Id              In Number, --产品ID
                                         p_Inventory_Id         In Number, --仓库ID
                                         p_Trans_Date           In Date, --特殊占用事务日期
                                         p_Origin_Order_Type_Id In Number, --单据类型ID
                                         p_Origin_Order_Line_Id In Number, --单据行ID
                                         p_User_Code            In Varchar2, --用户编码
                                         p_Result               In Out Varchar2 --成功返回“SUCCESS”
                                         );

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 计划订单特殊占用释放特殊占用数据,每日晚上JOB自动执行
  -----------------------------------------------------------------------------------------
  Procedure p_Release_Special_Occ_All(p_Entity_Id In Number);

  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 计划订单特殊占用释放特殊占用数据,每日晚上JOB
  -----------------------------------------------------------------------------------------
  Procedure p_Release_Special_Occ_Job;
  -----------------------------------------------------------------------------------------
  --Author: Nicro.Li
  --Purpose: 重计订单发货计划已分配数量与库存占用量数量不一致数据
  --         每日晚上JOB，占用量JOB处理完后，处理该功能
  -----------------------------------------------------------------------------------------
  Procedure p_Recalculation_Share_Ship(p_Entity_Id Number);
  Procedure p_Recalculation_Share_Ship_Job;


End Pkg_Pln_Shares;
/

