create view V_BD_ITEM_CODELIST_CCS as
select CODETYPE         CODE_TYPE,
       CODETYPE_NAME    CODE_TYPE_NAME,
       CODE_VALUE,
       CODE_NAME,
       CODE_ORDER,
       created_by,
       creation_date,
       last_updated_by,
       last_update_date
  from T_BD_ITEM_CODELIST
/

comment on column V_BD_ITEM_CODELIST_CCS.CODE_TYPE is '代码类型'
/

comment on column V_BD_ITEM_CODELIST_CCS.CODE_TYPE_NAME is '代码类型名称'
/

comment on column V_BD_ITEM_CODELIST_CCS.CODE_VALUE is '代码值'
/

comment on column V_BD_ITEM_CODELIST_CCS.CODE_NAME is '显示名'
/

comment on column V_BD_ITEM_CODELIST_CCS.CODE_ORDER is '顺序'
/

