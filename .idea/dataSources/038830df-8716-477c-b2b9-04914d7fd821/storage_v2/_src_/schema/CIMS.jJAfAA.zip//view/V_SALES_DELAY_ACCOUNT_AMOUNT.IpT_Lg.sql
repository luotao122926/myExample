create view V_SALES_DELAY_ACCOUNT_AMOUNT as
SELECT NVL((SELECT SUM(X.COUNTER)
          FROM T_CREDIT_BAD_RECORD X
         WHERE X.ENTITY_ID = CA.ENTITY_ID
           AND X.CUSTOMER_ID = CA.CUSTOMER_ID
           AND X.ACCOUNT_ID = CA.ACCOUNT_ID),0) bad_record_count,
       C.CUSTOM_LEVEL,
       c.custom_credit_level credit_level,
       C.SALES_MAIN_TYPE_CODE SALES_MAIN_TYPE,
       --NVL(c.credit_line,0) credit_line,
       pkg_credit_tools.FUN_GET_DELAY_CU_AMOUNT(c.entity_id,C.CUSTOMER_ID,c.sales_main_type_code,C.ACCOUNT_ID) credit_line ,
       (a.received_amount - a.sales_amount) account_balance,
       (a.discount_amount - a.applied_discount_amount) allowance_balance,
       NVL((SELECT COUNT(1)
          FROM T_CREDIT_DELAYPAY X
         WHERE X.ENTITY_ID = CA.ENTITY_ID
           AND X.CUSTOMER_ID = CA.CUSTOMER_ID
           AND X.ACCOUNT_ID = CA.ACCOUNT_ID
           AND X.CANCEL_TIME IS NULL
           AND TRUNC(X.REQUIS_DATE, 'YYYY') = TRUNC(SYSDATE, 'YYYY')),0) y_delay_count, --本年铺底次数
       NVL((SELECT SUM(X.APPROVAL_AMOUNT)
          FROM T_CREDIT_DELAYPAY X
         WHERE X.ENTITY_ID = CA.ENTITY_ID
           AND X.CUSTOMER_ID = CA.CUSTOMER_ID
           AND X.ACCOUNT_ID = CA.ACCOUNT_ID
           AND X.CANCEL_TIME IS NULL
           AND TRUNC(X.REQUIS_DATE, 'YYYY') = TRUNC(SYSDATE, 'YYYY')),0) y_delay_amount, --本年累计铺底金额
       (CASE NVL(credit_line,0) WHEN 0 THEN 0 ELSE ROUND(nvl((SELECT SUM(X.APPROVAL_AMOUNT)
          FROM T_CREDIT_DELAYPAY X
         WHERE X.ENTITY_ID = CA.ENTITY_ID
           AND X.CUSTOMER_ID = CA.CUSTOMER_ID
           AND X.ACCOUNT_ID = CA.ACCOUNT_ID
           AND X.CANCEL_TIME IS NULL
           AND X.PAYED_FLAG = '0'),0)/credit_line,2) END) delay_ratio, --铺底占比
       a."ACCOUNT_AMOUNT_ID",
       c."ENTITY_ID",
       a."CREDIT_GROUP_ID",
       a."PROJ_NUMBER",
       C.CUSTOMER_ID CUSTOMER_ID,
       C.CUSTOMER_CODE CUSTOMER_CODE,
       a."CUSTOMER_NAME",
       CA.ACCOUNT_ID,
       --a."ACCOUNT_ID",
       CA."ACCOUNT_CODE",
       CA."ACCOUNT_NAME",
       a."SALES_YEAR_ID",
       a."RECEIVED_AMOUNT",
       a."SALES_AMOUNT",
       a."LOCK_RECEIVED_AMOUNT",
       a."DELAYPAY_AMOUNT",
       a."TEMP_DELAYPAY_AMOUNT",
       a."DISCOUNT_AMOUNT",
       a."APPLIED_DISCOUNT_AMOUNT",
       a."FREEZE_DISCOUNT_AMOUNT",
       -- ADD BY LIANGYM2 梁颜明 增加冻结保证金字段 2017-10-11
       a."FREEZE_DELAY_AMOUNT",
       --铺底保存成功时就要触发生成保存之前没有的款项明细、款项 (add by liangym2 20171115：触发器trg_credit_delaypay)
       nvl((SELECT SUM((CASE WHEN X.APPROVALED_AMOUNT IS NULL THEN GREATEST(0,X.REQUIS_AMOUNT)
       ELSE LEAST(GREATEST(0,X.APPROVALED_AMOUNT),GREATEST(0,X.REQUIS_AMOUNT)) END))
          FROM T_CREDIT_DELAYPAY X
         WHERE X.ENTITY_ID = CA.ENTITY_ID
           AND X.CUSTOMER_ID = CA.CUSTOMER_ID
           AND X.ACCOUNT_ID = CA.ACCOUNT_ID
           AND X.CANCEL_TIME IS NULL
           AND X.DUE_BY IS NULL AND X.DUE_TIME IS NULL
           AND X.PAYED_FLAG = '0' AND (X.BILL_STATUS <> '5' OR X.BILL_STATUS <> '6')--作废、强制到期
           AND X.BILL_TYPE_ID = 3 AND X.DELAYPAY_TYPE = 10 AND X.BILL_STATUS <> '3'
           AND (0 < X.REQUIS_AMOUNT OR 0 < X.APPROVALED_AMOUNT)--
           AND A.CREDIT_GROUP_ID = PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(X.ENTITY_ID,X.CUSTOMER_ID,X.SALES_MAIN_TYPE,X.ACCOUNT_ID)
           ),0) AS TO_FREEZE_DELAY_AMOUNT, --待释放保证金
       a."LOCK_DISCOUNT_AMOUNT",
       a."DISPAY_AMOUNT",
       a."AMOUNT_CRTL_FLAG",
       a."DISCONT_CRTL_FLAG",
       a."CREATION_DATE",
       a."CREATED_BY",
       a."LAST_UPDATE_DATE",
       a."LAST_UPDATED_BY",
       a."PRE_FIELD_01",
       a."PRE_FIELD_02",
       a."PRE_FIELD_03",
       a."PRE_FIELD_04",
       a."PRE_FIELD_05",
       a."PRE_FIELD_06",
       --新增可用到款余额，龙鸿文 2016-01-08
       --ADD BY LIANGYM2 可用到款金额 加上美的付内容
       (a.received_amount - a.sales_amount + a.delaypay_amount + a.temp_delaypay_amount - a.lock_received_amount + A.MPAY_STREAM_AMOUNT - A.MPAY_CASH_AMOUNT) CAN_USE_AMOUNT
       ,c.copper_date
       ,CAST(0 AS NUMERIC) AS  CUS_CREDIT_LINE
       ,CAST(0 AS NUMERIC) AS USER_DELAYPAY
       ,C.LASTYEAR_CREDIT_LINE
       ,C.THISYEAR_CREDIT_LINE
       ,C.LASTYEAR_CREDIT_LINE AS LAST_YEAR_CREDIT_LINE
       ,C.THISYEAR_CREDIT_LINE AS THIS_YEAR_CREDIT_LINE
       ,C.TWELVE_AMOUNT
   FROM T_CREDIT_CUSTOMER C
   INNER JOIN T_CUSTOMER_ACCOUNT CA
   ON (
   CA.ENTITY_ID = C.ENTITY_ID
   AND C.CUSTOMER_ID = CA.CUSTOMER_ID
   AND (
   (C.ACCOUNT_ID = CA.ACCOUNT_ID)
   OR ((C.ACCOUNT_ID IS NULL OR 0 >= C.ACCOUNT_ID))
   )
   )
   LEFT JOIN T_SALES_ACCOUNT_AMOUNT A
 /*,
 t_credit_category_group_rel d,
 T_CREDIT_GROUP_CUST         e*/
     ON (c.entity_id = a.entity_id And C.CUSTOMER_ID = a.customer_id AND
        PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(c.entity_id,
                                                C.CUSTOMER_ID,
                                                C.SALES_MAIN_TYPE_CODE,
                                                C.ACCOUNT_ID) =
        A.CREDIT_GROUP_ID AND A.ACCOUNT_ID = CA.ACCOUNT_ID AND (A.ACCOUNT_ID = C.ACCOUNT_ID OR
        (C.ACCOUNT_ID IS NULL OR 0 >= C.ACCOUNT_ID)))
/

