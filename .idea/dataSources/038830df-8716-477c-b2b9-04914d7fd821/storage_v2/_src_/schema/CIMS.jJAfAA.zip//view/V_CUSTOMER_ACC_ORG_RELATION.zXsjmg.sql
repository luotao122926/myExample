create view V_CUSTOMER_ACC_ORG_RELATION as
select RELATION_ID,
       ACCOUNT_ID,
       CUSTOMER_ORG_ID,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATE_BY,
       LAST_UPDATE_DATE,
       PRE_FIELD_01,
       PRE_FIELD_02,
       PRE_FIELD_03,
       PRE_FIELD_04,
       PRE_FIELD_05,
       PRE_FIELD_06
  from T_CUSTOMER_ACC_ORG_RELATION with read only
/

comment on column V_CUSTOMER_ACC_ORG_RELATION.RELATION_ID is '关系ID'
/

comment on column V_CUSTOMER_ACC_ORG_RELATION.ACCOUNT_ID is '账户ID'
/

comment on column V_CUSTOMER_ACC_ORG_RELATION.CUSTOMER_ORG_ID is '客户组织ID'
/

comment on column V_CUSTOMER_ACC_ORG_RELATION.CREATED_BY is '创建人'
/

comment on column V_CUSTOMER_ACC_ORG_RELATION.CREATION_DATE is '创建日期'
/

comment on column V_CUSTOMER_ACC_ORG_RELATION.LAST_UPDATE_BY is '最后修改人'
/

comment on column V_CUSTOMER_ACC_ORG_RELATION.LAST_UPDATE_DATE is '最后修改日期'
/

comment on column V_CUSTOMER_ACC_ORG_RELATION.PRE_FIELD_01 is '预留字段1'
/

comment on column V_CUSTOMER_ACC_ORG_RELATION.PRE_FIELD_02 is '预留字段2'
/

comment on column V_CUSTOMER_ACC_ORG_RELATION.PRE_FIELD_03 is '预留字段3'
/

comment on column V_CUSTOMER_ACC_ORG_RELATION.PRE_FIELD_04 is '预留字段4'
/

comment on column V_CUSTOMER_ACC_ORG_RELATION.PRE_FIELD_05 is '预留字段5'
/

comment on column V_CUSTOMER_ACC_ORG_RELATION.PRE_FIELD_06 is '预留字段6'
/

