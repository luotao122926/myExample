create view V_CREDIT_CONTACT_AMOUNT_AR as
SELECT 'ar' Business_ID ,  --业务类型
       '' AS biz_src_bill_type_code, -- 业务单据源类型编码
       '' AS biz_src_bill_type_name, -- 业务单据源类型名称
       ar_header.cash_receipt_id      BILL_ID, --单据id
       ar_header.cash_receipt_code    BILL_NUM, --单据编号
       ar_header.cash_receipt_date    BILL_DATE, --单据日期
       to_char(ar_header.receipt_status_id)    BILL_STATUS, --单据状态
       ar_methods.receipt_method_id   bill_type_id, --收款方法id
       TO_CHAR(ar_methods.receipt_method_id) bill_type_code, --收款方法编码
       ar_methods.receipt_method_name bill_type_name, --收款方法名称
       ar_header.reviewed_date        settle_date, --确认日期
       ar_header.cash_date            account_date, --客户对帐日期
       ar_header.gl_date              checked_account_date, --财务对帐日期
       ar_header.customer_id, --客户id
       ar_header.customer_code, --客户编码
       cus_header.customer_name, --客户名称
       CPH.CUSTOMER_CODE AS CUSTOMER_CODE_P,
       CPH.CUSTOMER_NAME AS CUSTOMER_NAME_P,
       ar_header.Account_Id,   --账户ID
       ar_header.account_code, --账户编码
       ar_header.account_name, --账户名称
       PKG_CREDIT_TOOLS.FUN_GET_CODELIST(cus_main_type.cooperation_model_id,
                                         'MIDEA_MARKET_MODE',
                                         2) customer_type, --客户类型
       --NVL (precus.customer_id, cih.customer_id)     pre_customer_id,    --上级单位ID
       --NVL (precus.customer_code, cih.customer_code) pre_customer_code,  --上级单位编码
       --NVL (precus.customer_name, cih.customer_name) pre_customer_name,  --上级单位名称
       --soh.finance_main_entity_id,              --主主体
       ar_header.entity_id, --主体
       CL.Name entity_name,--主体名称
       ar_header.sales_center_id, --营销中心id
       v_center.sales_center_code, --营销中心编码
       v_center.Sales_Center_Name, --营销中心名称
       v_center.sales_region_id, --销售区域ID
       v_center.sales_region_name, --销售区域名称
       ar_lines.brand_code, --品牌
       ar_lines.brand_code brand_name, --品牌名称
       ar_lines.sales_main_type_code sales_main_type, --营销大类
       ar_lines.sales_main_type_name,  --营销大类名称
       --soh.small_category,                        --营销小类
       null                    project_num, --批文编码
       null                    project_name, --批文名称
       ar_header.cash_code, --票据号
       ar_header.cash_date, --票据日期
       ar_header.due_date, --到期日期
       null                    invoice_num_list, --发票号串（税控发票）
       null                    invoice_date, --发票日期（税控日期）
       ar_header.sales_year_id, --销售年度ID
       ar_header.sales_year_id sales_year, --销售年度
       ar_header.source_type   src_type, --来源类型
       ar_header.source_type   src_type_name, --来源类型名称
       ar_header.contract_num  src_bill_num, --来源号
       NULL discount_type_id,                   --折扣id
       NULL discount_type_name,            --折扣名称
       null discount_item, --折让项目
       null discount_mode, --折让方式
        /*0  GTMS-未付
          1  制单
          2  作废
          3  已确认
          5  已审核
          6  已汇
          10  GTMS-已驳回
          11  CIMS-撤销修改
          12  CIMS-撤销作废
          15  GTMS-付款成功
          16  已冲销
          19  GTSP-审批拒绝*/
       (case
         when ar_header.receipt_status_id in (0,3,5,6,15,16) then
          'Y'
         else
          'N'
       end) settle_flag,--是否结算
       NULL list_amount, --列表金额
       NULL discount_amount, --折让金额
       ar_lines.amount settle_amount, --结算金额
       0 as delaypay_amount, --使用铺底额度
       /*(select sum(t.SOLUTION_PAY_AMOUNT)
          FROM T_AR_ACCE_SOLU_PAY t
         where t.cash_receipt_lines_id = ar_lines.cash_receipt_lines_id
           and t.solution_pay_status = '2')*/
       PKG_CREDIT_TOOLS.FUN_GET_THREE_AMOUNT(ar_header.cash_receipt_id,ar_lines.sales_main_type_code,2) SOLUTION_PAY_AMOUNT, --三方承兑已解付金额
       /*DECODE (itt.transaction_source_type_id, 1, -1, 2, 1, 0)
       * DECODE (DECODE (soh.presales_flag, 'N', 0, 1)* DECODE (soh.account_flag, 'Y', 0, 1),
                0,
                soh.instant_dis_amount,
                1,
                0) instant_dis_amount,           --即返额 */
       ar_lines.remark, --备注
       ar_header.ATTRIBUTE3 CREATED_BY,
       nvl(ar_header.REVIEWED_DATE,ar_header.creation_date) creation_date, --录入日期
       1                       sales_receipt,
       --soh.patch_amount,                         --补息（去掉）
       --0 paste_amount,                           --贴息（去掉）
       --sy.item_type,                             --产品类型
       --NVL (soh.ora_intooiflag_c, 'N') intooiflag, --是否引入财务
       1 cnt,
       decode(ar_methods.receipt_type, 1, 'N', 3, 'Y', 'N') fund_ctrl_mode, --控制方式
       null created_mode,  --制单方式
       decode(ar_methods.receipt_type, 1, 'Y', 3, 'Y', 'N') draft_flag, --是否为承兑
       null audit_flag, --审核标识
       decode(ar_header.INTO_ERP_DATE,null,'N','Y') import_erp,--引入
       Null src_type_id,
       Null src_type_code,
       ar_header.erp_ou_id,
       ar_header.erp_ou_name,
       'N' AS project_flag, --工程机标识：N 否；Y 是
       '' AS entity_cust_flag,  --事业部客户标识
        --龙鸿文，2016-1-11，三方单据锁款重算
       decode(ar_header.writeoff_receipt_code,NULL,'N','Y') writeoff_receipt_flag --单据是否已被冲销
       ,ar_header.discount_type--折让方式 add by liangym2 20171030
--SOH.NC_OI_FLAG,                                   --引入NC接口标示
--cih.FINANCIAL_STATISTICAL_TYPE                    --财务统计属性 <客户属性控制>
  FROM t_ar_cash_receipt_headers ar_header, --收款头表
       t_ar_cash_receipt_lines   ar_lines, --收款行表
       T_AR_RECEIPT_METHODS      ar_methods, --收款方法表
       v_bd_sales_center         v_center, --营销中心视图
       t_customer_header         cus_header,--客户头表
      -- v_bd_item_class_ims       item_class,
       T_CUSTOMER_HEADER CPH,
       T_CUSTOMER_SALES_MAIN_TYPE cus_main_type, --客户营销大类关系表
         UP_ORG_UNIT CL
/*T_CUSTOMER_ORG cur_org,  --客户组织信息
v_bd_sales_region v_region --营销区域视图*/
 WHERE ar_header.entity_id = ar_methods.entity_id(+)
   AND ar_header.receipt_method_id = ar_methods.receipt_method_id(+)
   AND ar_header.Sales_Center_Id = v_center.sales_center_id(+)
   AND ar_header.customer_id = cus_header.customer_id
   AND NVL(cus_header.CUSTOMER_FATHER_CODE,' ') = CPH.CUSTOMER_CODE(+)
  -- AND ar_lines.Sales_Main_Type_Code = item_class.CLASS_CODE
  -- AND item_class.CLASS_TYPE = 'M'
  -- AND ar_header.Entity_Id = ITEM_CLASS.ENTITY_ID
   AND ar_header.cash_receipt_id = ar_lines.cash_receipt_id
   AND ar_header.entity_id = cus_main_type.entity_id
   AND ar_header.customer_id = cus_main_type.CUSTOM_ID
   AND ar_lines.SALES_MAIN_TYPE_CODE = cus_main_type.SALES_MAIN_TYPE_CODE
   AND ar_header.entity_id = cl.unit_id
/

