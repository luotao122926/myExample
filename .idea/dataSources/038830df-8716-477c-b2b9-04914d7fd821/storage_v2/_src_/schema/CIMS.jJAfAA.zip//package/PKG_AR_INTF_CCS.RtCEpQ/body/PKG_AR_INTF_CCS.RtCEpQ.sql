create PACKAGE BODY      PKG_AR_INTF_CCS IS

  -- CCS对账接口表数据插入业务表
  PROCEDURE P_ACCOUNT_CCS(P_MESSAGE out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                          ) is
    --PRAGMA AUTONOMOUS_TRANSACTION;

    P_HEADER_ID number; --定义HEADER_ID变量

    CURSOR C_HEADS IS
      SELECT * FROM INTF_AR_SOA_ORDER_HEADS t WHERE t.flag = '0';

    CURSOR C_DIFFERENCES IS
      SELECT *
        FROM INTF_AR_SOA_ORDER_DIFFERENCES t
       WHERE t.header_id = P_HEADER_ID
         AND t.flag = '0';

    CURSOR C_FILES IS
      SELECT *
        FROM INTF_AR_SOA_ORDER_FILES t
       WHERE t.header_id = P_HEADER_ID
         AND t.flag = '0';

    CURSOR C_LINES IS
      SELECT *
        FROM INTF_AR_SOA_RECEIPT_LINES t
       WHERE t.header_id = P_HEADER_ID
         AND t.flag = '0';

    HEADS_ROW C_HEADS%ROWTYPE; --待处理头表数据
    DIFFERENCES_ROW C_DIFFERENCES%ROWTYPE; --待处理差异行表数据
    FILES_ROW C_FILES%ROWTYPE; --待处理附件行表数据
    LINES_ROW C_LINES%ROWTYPE; --处理成功的差异行表数据

    DATACOUNT number; --待处理数据总量
    DATACOUNT0 number;
    DATACOUNT1 number; --CCS对账单数据在IMS系统到款行表是否存在
    DATACOUNT2 number; --CCS对账单数据在IMS系统折让行表是否存在
    DATACOUNT4 number; --CCS对账单接口行表数据是否存在

    V_CONFIRM_FLAG varchar2(2);

    --V_HEADER_ID_IMS number; --业务表对账单ID
    V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常

  BEGIN

    P_MESSAGE := '执行处理';

    FOR HEADS_ROW IN C_HEADS LOOP

      P_HEADER_ID := HEADS_ROW.HEADER_ID;

      SELECT count(*)
        INTO DATACOUNT0
        FROM T_AR_SOA_ORDER_HEADS t
       WHERE t.header_id = P_HEADER_ID;

      if (DATACOUNT0 > 0) then
        SELECT t.confirm_flag
          INTO V_CONFIRM_FLAG
          FROM T_AR_SOA_ORDER_HEADS t
         WHERE t.header_id = P_HEADER_ID;

        if (V_CONFIRM_FLAG = 'Y') then
          P_MESSAGE := 'HEADER_ID：' || P_HEADER_ID || '，该对账单已确认，不能重复确认。';

          --更新接口表INTF_AR_SOA_ORDER_DIFFERENCES状态为1：失败
          UPDATE INTF_AR_SOA_ORDER_DIFFERENCES
             SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
           WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

          --更新接口表INTF_AR_SOA_ORDER_FILES状态为1：失败
          UPDATE INTF_AR_SOA_ORDER_FILES
             SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
           WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

          --更新接口表intf_ar_soa_order_heads状态为1：失败
          UPDATE intf_ar_soa_order_heads
             SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
           WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

          --更新接口表INTF_AR_SOA_ORDER_FILES状态为1：失败
          UPDATE INTF_AR_SOA_RECEIPT_LINES
             SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
           WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';
        elsif (V_CONFIRM_FLAG = 'E') then
          P_MESSAGE := 'HEADER_ID：' || P_HEADER_ID || '，该对账单已作废，不能进行确认。';

          --更新接口表INTF_AR_SOA_ORDER_DIFFERENCES状态为1：失败
          UPDATE INTF_AR_SOA_ORDER_DIFFERENCES
             SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
           WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

          --更新接口表INTF_AR_SOA_ORDER_FILES状态为1：失败
          UPDATE INTF_AR_SOA_ORDER_FILES
             SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
           WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

          --更新接口表intf_ar_soa_order_heads状态为1：失败
          UPDATE intf_ar_soa_order_heads
             SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
           WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

          --更新接口表INTF_AR_SOA_ORDER_FILES状态为1：失败
          UPDATE INTF_AR_SOA_RECEIPT_LINES
             SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
           WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';
        else
          delete from T_AR_SOA_ORDER_DIFFERENCES t where t.header_id = P_HEADER_ID;

          --周锦群2015.9.9 改bug对账单客户确认失败
          --delete from IMS_FILEINFO_INTERFACE f where f.business_id = P_HEADER_ID;
          delete from IMS_FILEINFO_INTERFACE f where f.business_id = to_char(P_HEADER_ID);

          UPDATE T_AR_SOA_ORDER_RECEIPT_LINES t
             SET t.cus_receivable_amount = null, t.DIFFERENACE_AMOUNT = null
           WHERE t.header_id = P_HEADER_ID;

          UPDATE T_AR_SOA_ORDER_HEADS
             SET CONFIRM_USER_NAME = '',
                 CONFIRM_FLAG = '',
                 CONFIRM_DATE = null,
                 DIFF_CHECK_FLAG = '',
                 DIFF_CHECK_DATE = null,
                 DIFF_CHECK_BY = ''
           WHERE HEADER_ID = P_HEADER_ID;

        --获取接口表数据数量
        SELECT count(*)
          INTO DATACOUNT
          FROM INTF_AR_SOA_ORDER_DIFFERENCES t
         WHERE t.header_id = P_HEADER_ID;
         
        FOR DIS_LINES_ROW IN (select  
                                 DISCOUNT_LINE_ID 
                              from T_AR_SOA_ORDER_DIS_LINES t
                              where t.HEADER_ID = P_HEADER_ID
                              and  t.SOA_TYPE = 2 
                              and  t.CUS_DISCOUNT_AMOUNT is null
           ) LOOP
             begin
                                --2016.6.8
                  UPDATE T_AR_SOA_ORDER_DIS_LINES t
                     SET t.CUS_DISCOUNT_AMOUNT = NVL(t.CURRENT_AMOUNT, 0)
                  WHERE t.DISCOUNT_LINE_ID = DIS_LINES_ROW.DISCOUNT_LINE_ID;
             end;
         END LOOP;  
         

        --有差异数据
        if (DATACOUNT > 0) THEN
          BEGIN

            FOR DIFFERENCES_ROW IN C_DIFFERENCES LOOP
                DIFFERENCES_ROW.DEFFERENCE_AMOUNT :=nvl(DIFFERENCES_ROW.DEFFERENCE_AMOUNT,0);

              SELECT count(*)
                INTO DATACOUNT4
                FROM intf_ar_soa_receipt_lines t
               WHERE t.header_id = DIFFERENCES_ROW.HEADER_ID;

              if (DATACOUNT4 = 0) then
                P_MESSAGE := 'DIFFERENCE_ID：' ||
                             DIFFERENCES_ROW.DIFFERENCE_ID || '在到款行接口表不存在。';

                --更新接口表INTF_AR_SOA_ORDER_DIFFERENCES状态为1：失败
                UPDATE INTF_AR_SOA_ORDER_DIFFERENCES
                   SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                 WHERE DIFFERENCE_ID = DIFFERENCES_ROW.DIFFERENCE_ID AND FLAG = '0';

                --更新接口表INTF_AR_SOA_ORDER_FILES状态为1：失败
                UPDATE INTF_AR_SOA_ORDER_FILES
                   SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                 WHERE HEADER_ID = DIFFERENCES_ROW.HEADER_ID AND FLAG = '0';

                --更新接口表intf_ar_soa_order_heads状态为1：失败
                UPDATE intf_ar_soa_order_heads
                   SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                 WHERE HEADER_ID = DIFFERENCES_ROW.HEADER_ID AND FLAG = '0';

                --更新接口表INTF_AR_SOA_ORDER_FILES状态为1：失败
                UPDATE INTF_AR_SOA_RECEIPT_LINES
                   SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                 WHERE HEADER_ID = DIFFERENCES_ROW.HEADER_ID AND FLAG = '0';

              else

                if (DIFFERENCES_ROW.Order_Type = '1') THEN

                  SELECT count(*)
                    INTO DATACOUNT1
                    FROM t_ar_soa_order_receipt_lines t
                   WHERE t.header_id = DIFFERENCES_ROW.HEADER_ID
                     AND t.receipt_line_id = DIFFERENCES_ROW.LINE_ID
                     AND t.sales_main_id = DIFFERENCES_ROW.Sales_Main_Id;

                  if (DATACOUNT1 > 0) THEN

                    BEGIN
                      --插入确认式往来对账单差异表
                      INSERT INTO T_AR_SOA_ORDER_DIFFERENCES
                        (DIFFERENCE_ID,
                         LINE_ID,
                         HEADER_ID,
                         SERIAL_NUMBER,
                         ITEM,
                         DEFFERENCE_AMOUNT,
                         COMMENTS,
                         ENTITY_ID,
                         CREATED_BY,
                         CREATION_DATE)
                      VALUES
                        (S_AR_SOA_ORDER_DIFFERENCES.NEXTVAL,
                         DIFFERENCES_ROW.LINE_ID,
                         DIFFERENCES_ROW.HEADER_ID,
                         DIFFERENCES_ROW.SERIAL_NUMBER,
                         DIFFERENCES_ROW.ITEM,
                         DIFFERENCES_ROW.DEFFERENCE_AMOUNT,
                         DIFFERENCES_ROW.COMMENTS,
                         DIFFERENCES_ROW.ENTITY_ID,
                         DIFFERENCES_ROW.CREATED_BY,
                         SYSDATE);

                      P_MESSAGE := 'SUCCESS';

                      --更新接口表INTF_AR_SOA_ORDER_DIFFERENCES状态为0：成功
                      UPDATE INTF_AR_SOA_ORDER_DIFFERENCES
                         SET STATUS = '0', ERROR_INFO = P_MESSAGE, FLAG = '1'
                       WHERE DIFFERENCE_ID = DIFFERENCES_ROW.DIFFERENCE_ID AND FLAG = '0';

                      COMMIT;

                    EXCEPTION
                      WHEN OTHERS THEN
                        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_CCS.P_ACCOUNT_CCS',
                                                            SQLCODE,
                                                            '对账单' || P_HEADER_ID || '客户确认失败, 插入确认式往来对账单差异表失败：' ||
                                                            substr(dbms_utility.format_error_backtrace,1,100) || SQLERRM);

                        UPDATE INTF_AR_SOA_ORDER_DIFFERENCES
                           SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                         WHERE DIFFERENCE_ID = DIFFERENCES_ROW.DIFFERENCE_ID AND FLAG = '0';

                        UPDATE intf_ar_soa_receipt_lines
                           SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                         WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

                        UPDATE intf_ar_soa_order_heads
                           SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                         WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

                        UPDATE INTF_AR_SOA_ORDER_FILES
                           SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                         WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

                         CONTINUE;
                    END;

                  else

                    P_MESSAGE := 'DIFFERENCE_ID：' ||
                                 DIFFERENCES_ROW.DIFFERENCE_ID || '与对账单' ||
                                 DIFFERENCES_ROW.ORDER_NUMBER ||
                                 'HEADER_ID、LINE_ID、SALES_MAIN_ID不一致。';

                    UPDATE INTF_AR_SOA_ORDER_DIFFERENCES
                       SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                     WHERE DIFFERENCE_ID = DIFFERENCES_ROW.DIFFERENCE_ID AND FLAG = '0';

                    UPDATE INTF_AR_SOA_ORDER_FILES
                       SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                     WHERE HEADER_ID = DIFFERENCES_ROW.HEADER_ID AND FLAG = '0';

                    UPDATE intf_ar_soa_receipt_lines
                       SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                     WHERE HEADER_ID = DIFFERENCES_ROW.HEADER_ID AND FLAG = '0';

                    UPDATE intf_ar_soa_order_heads
                       SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                     WHERE HEADER_ID = DIFFERENCES_ROW.HEADER_ID AND FLAG = '0';

                  end if;

                elsif (DIFFERENCES_ROW.Order_Type = '2') THEN

                  SELECT count(*)
                    INTO DATACOUNT2
                    FROM t_ar_soa_order_dis_lines t
                   WHERE t.header_id = DIFFERENCES_ROW.HEADER_ID
                     AND t.discount_line_id = DIFFERENCES_ROW.LINE_ID
                     AND t.sales_main_id = DIFFERENCES_ROW.Sales_Main_Id;

                  if (DATACOUNT2 > 0) THEN
                    BEGIN
                      --插入确认式往来对账单差异表
                      INSERT INTO T_AR_SOA_ORDER_DIFFERENCES
                        (DIFFERENCE_ID,
                         LINE_ID,
                         HEADER_ID,
                         SERIAL_NUMBER,
                         ITEM,
                         DEFFERENCE_AMOUNT,
                         COMMENTS,
                         ENTITY_ID,
                         CREATED_BY,
                         CREATION_DATE)
                      VALUES
                        (S_AR_SOA_ORDER_DIFFERENCES.NEXTVAL,
                         DIFFERENCES_ROW.LINE_ID,
                         DIFFERENCES_ROW.HEADER_ID,
                         DIFFERENCES_ROW.SERIAL_NUMBER,
                         DIFFERENCES_ROW.ITEM,
                         DIFFERENCES_ROW.DEFFERENCE_AMOUNT,
                         DIFFERENCES_ROW.COMMENTS,
                         DIFFERENCES_ROW.ENTITY_ID,
                         DIFFERENCES_ROW.CREATED_BY,
                         SYSDATE);

                    -- 2016.4.6
                    UPDATE T_AR_SOA_ORDER_DIS_LINES t
                       SET t.CUS_DISCOUNT_AMOUNT = NVL(t.CURRENT_AMOUNT, 0) + DIFFERENCES_ROW.DEFFERENCE_AMOUNT,
                           t.DIFFERENACE_AMOUNT = DIFFERENCES_ROW.DEFFERENCE_AMOUNT
                    WHERE t.header_id = DIFFERENCES_ROW.HEADER_ID
                       AND t.discount_line_id = DIFFERENCES_ROW.LINE_ID
                       AND t.sales_main_id = DIFFERENCES_ROW.Sales_Main_Id;

                      P_MESSAGE := 'SUCCESS';

                      --更新接口表INTF_AR_SOA_ORDER_DIFFERENCES状态为0：成功
                      UPDATE INTF_AR_SOA_ORDER_DIFFERENCES
                         SET STATUS = '0', ERROR_INFO = P_MESSAGE, FLAG = '1'
                       WHERE DIFFERENCE_ID = DIFFERENCES_ROW.DIFFERENCE_ID AND FLAG = '0';

                      COMMIT;

                    EXCEPTION
                      WHEN OTHERS THEN
                        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_CCS.P_ACCOUNT_CCS',
                                                            SQLCODE,
                                                            '对账单' || P_HEADER_ID || '客户确认失败, 插入确认式往来对账单差异表失败：' ||
                                                            substr(dbms_utility.format_error_backtrace,1,100) || SQLERRM);

                        UPDATE INTF_AR_SOA_ORDER_DIFFERENCES
                           SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                         WHERE DIFFERENCE_ID = DIFFERENCES_ROW.DIFFERENCE_ID AND FLAG = '0';

                    END;

                  else
                    P_MESSAGE := 'DIFFERENCE_ID：' ||
                                 DIFFERENCES_ROW.DIFFERENCE_ID || '与对账单' ||
                                 DIFFERENCES_ROW.ORDER_NUMBER ||
                                 'HEADER_ID、LINE_ID、SALES_MAIN_ID不一致。';

                    --更新接口表INTF_AR_SOA_ORDER_DIFFERENCES状态为1：失败
                    UPDATE INTF_AR_SOA_ORDER_DIFFERENCES
                       SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                     WHERE DIFFERENCE_ID = DIFFERENCES_ROW.DIFFERENCE_ID AND FLAG = '0';

                    --更新接口表INTF_AR_SOA_ORDER_FILES状态为1：失败
                    UPDATE INTF_AR_SOA_ORDER_FILES
                       SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                     WHERE HEADER_ID = DIFFERENCES_ROW.HEADER_ID AND FLAG = '0';

                  end if;

                end if;

              end if;

            END LOOP;

            FOR FILES_ROW IN C_FILES LOOP

              BEGIN

                --插入往来对账单附件信息表
                /*INSERT INTO T_AR_SOA_ORDER_FILES
                  (ORDER_FILE_ID,
                   HEADER_ID,
                   UPDATE_FILE_DATE,
                   FILE_NAME,
                   REMOTE_PATH,
                   LOAD_PATH,
                   UPDATE_FILE_BY,
                   COMMENTS,
                   ENTITY_ID,
                   CREATION_DATE)
                VALUES
                  (S_AR_SOA_ORDER_FILES.NEXTVAL,
                   P_HEADER_ID,
                   FILES_ROW.UPDATE_FILE_DATE,
                   FILES_ROW.FILE_NAME,
                   FILES_ROW.REMOTE_PATH,
                   FILES_ROW.LOAD_PATH,
                   FILES_ROW.UPDATE_FILE_BY,
                   FILES_ROW.COMMENTS,
                   FILES_ROW.ENTITY_ID,
                   SYSDATE);*/

                INSERT INTO IMS_FILEINFO_INTERFACE
                  (ID,
                   BUSINESS_ID,
                   BUSINESS_TYPE,
                   FILE_PATH,
                   FILE_NAME
                   )
                VALUES
                  (SEQ_IMS_FILEINFO.NEXTVAL,
                   P_HEADER_ID,
                   'ar_soa_order_header',
                   FILES_ROW.LOAD_PATH,
                   FILES_ROW.FILE_NAME
                   );

                P_MESSAGE := 'SUCCESS';

                --更新接口表INTF_AR_SOA_ORDER_FILES状态为0：成功
                UPDATE INTF_AR_SOA_ORDER_FILES
                   SET STATUS = '0', ERROR_INFO = P_MESSAGE, FLAG = '1'
                 WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';
                 
                 --2017-09-15 tianmzh 修改，有附件则更新头表附件标志
                 UPDATE CIMS.T_AR_SOA_ORDER_HEADS
                 SET APPENDIX_FLAG = 'Y'
                 WHERE HEADER_ID = P_HEADER_ID;

                COMMIT;

              EXCEPTION
                WHEN OTHERS THEN
                  P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_CCS.P_ACCOUNT_CCS',
                                                      SQLCODE,
                                                      '对账单' || P_HEADER_ID || '客户确认失败, 插入往来对账单附件信息表失败：' ||
                                                      substr(dbms_utility.format_error_backtrace,1,100) || SQLERRM);

                  UPDATE INTF_AR_SOA_ORDER_FILES
                     SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                   WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

              END;

            END LOOP;

            FOR LINES_ROW IN C_LINES LOOP

              BEGIN

                UPDATE T_AR_SOA_ORDER_RECEIPT_LINES t
                   SET t.cus_receivable_amount = LINES_ROW.CUS_RECEIVABLE_AMOUNT,
                       t.DIFFERENACE_AMOUNT = LINES_ROW.Differenace_Amount
                 WHERE t.receipt_line_id = LINES_ROW.LINE_ID;

                P_MESSAGE := 'SUCCESS';

                --更新接口表intf_ar_soa_receipt_lines状态为0：成功
                UPDATE intf_ar_soa_receipt_lines
                   SET STATUS = '0', ERROR_INFO = P_MESSAGE, FLAG = '1'
                 WHERE LINE_ID = LINES_ROW.LINE_ID AND FLAG = '0';

              EXCEPTION
                WHEN OTHERS THEN

                  P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_CCS.P_ACCOUNT_CCS',
                                                      SQLCODE,
                                                      '对账单' || P_HEADER_ID || '客户确认失败, 数据插入确认式往来对账单到款结算行失败：' ||
                                                      substr(dbms_utility.format_error_backtrace,1,100) || SQLERRM);

                  UPDATE intf_ar_soa_receipt_lines
                     SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                   WHERE LINE_ID = LINES_ROW.LINE_ID AND FLAG = '0';

              END;

            END LOOP;

            BEGIN

              UPDATE T_AR_SOA_ORDER_HEADS
                 SET CONFIRM_USER_NAME = HEADS_ROW.CONFIRM_USER_NAME,
                     CONFIRM_FLAG = HEADS_ROW.Confirm_Flag,
                     CONFIRM_DATE = HEADS_ROW.Confirm_Date,
                     DIFF_CHECK_FLAG = HEADS_ROW.Diff_Check_Flag,
                     DIFF_CHECK_DATE = HEADS_ROW.Diff_Check_Date,
                     DIFF_CHECK_BY = HEADS_ROW.Diff_Check_By
               WHERE HEADER_ID = P_HEADER_ID;

              P_MESSAGE := 'SUCCESS';

              --更新接口表INTF_AR_SOA_ORDER_HEADS状态为0：成功
              UPDATE INTF_AR_SOA_ORDER_HEADS
                 SET STATUS = '0', ERROR_INFO = P_MESSAGE, FLAG = '1'
               WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

            EXCEPTION
              WHEN OTHERS THEN

                P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_CCS.P_ACCOUNT_CCS',
                                                    SQLCODE,
                                                    '对账单' || P_HEADER_ID || '客户确认失败, 数据插入确认式往来对账单头表失败：' ||
                                                    substr(dbms_utility.format_error_backtrace,1,100) || SQLERRM);

                UPDATE INTF_AR_SOA_ORDER_HEADS
                   SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                 WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

            END;

            --异常处理

          EXCEPTION
            WHEN OTHERS THEN

              ROLLBACK;

              --记录出错信息
              P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_CCS.P_ACCOUNT_CCS',
                                                  SQLCODE,
                                                  '对账单' || P_HEADER_ID || '客户确认失败：' || substr(dbms_utility.format_error_backtrace,1,100) || SQLERRM);

              --更新接口表INTF_AR_SOA_ORDER_DIFFERENCES状态为1：失败
              UPDATE INTF_AR_SOA_ORDER_DIFFERENCES
                 SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
               WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

              --更新接口表INTF_AR_SOA_ORDER_FILES状态为1：失败
              UPDATE INTF_AR_SOA_ORDER_FILES
                 SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
               WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

              UPDATE intf_ar_soa_receipt_lines
                 SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
               WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

              UPDATE intf_ar_soa_order_heads
                 SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
               WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

            --RAISE V_BIZ_EXCEPTION;

          END;

          COMMIT;

          --没有差异数据
        else

          FOR FILES_ROW IN C_FILES LOOP

            BEGIN
              --插入往来对账单附件信息表
              /*INSERT INTO T_AR_SOA_ORDER_FILES
                (ORDER_FILE_ID,
                 HEADER_ID,
                 UPDATE_FILE_DATE,
                 FILE_NAME,
                 REMOTE_PATH,
                 LOAD_PATH,
                 UPDATE_FILE_BY,
                 COMMENTS,
                 ENTITY_ID,
                 CREATION_DATE)
              VALUES
                (S_AR_SOA_ORDER_FILES.NEXTVAL,
                 P_HEADER_ID,
                 FILES_ROW.UPDATE_FILE_DATE,
                 FILES_ROW.FILE_NAME,
                 FILES_ROW.REMOTE_PATH,
                 FILES_ROW.LOAD_PATH,
                 FILES_ROW.UPDATE_FILE_BY,
                 FILES_ROW.COMMENTS,
                 FILES_ROW.ENTITY_ID,
                 SYSDATE);*/
                 
                 --tianmzh 2017-11-03 修改，增加文件名
              INSERT INTO IMS_FILEINFO_INTERFACE
                (ID,
                 BUSINESS_ID,
                 BUSINESS_TYPE,
                 FILE_PATH,
                 FILE_NAME)
              VALUES
                (SEQ_IMS_FILEINFO.NEXTVAL,
                 P_HEADER_ID,
                 'ar_soa_order_header',
                 FILES_ROW.LOAD_PATH,
                 FILES_ROW.FILE_NAME);

              P_MESSAGE := 'SUCCESS';

              --更新接口表INTF_AR_SOA_ORDER_FILES状态为0：成功
              UPDATE INTF_AR_SOA_ORDER_FILES
                 SET STATUS = '0', ERROR_INFO = P_MESSAGE, FLAG = '1'
               WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';
               
                --2017-09-15 tianmzh 修改，有附件则更新头表附件标志
                 UPDATE CIMS.T_AR_SOA_ORDER_HEADS
                 SET APPENDIX_FLAG = 'Y'
                 WHERE HEADER_ID = P_HEADER_ID;

              COMMIT;

            EXCEPTION
              WHEN OTHERS THEN

                P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_CCS.P_ACCOUNT_CCS',
                                                    SQLCODE,
                                                    '对账单' || P_HEADER_ID || '客户确认失败, 插入往来对账单附件信息表失败：' ||
                                                    substr(dbms_utility.format_error_backtrace,1,100) || SQLERRM);

                UPDATE INTF_AR_SOA_ORDER_FILES
                   SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                 WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

            END;

          END LOOP;

          FOR LINES_ROW IN C_LINES LOOP

            BEGIN
              UPDATE T_AR_SOA_ORDER_RECEIPT_LINES t
                 SET t.cus_receivable_amount = LINES_ROW.CUS_RECEIVABLE_AMOUNT,
                     t.DIFFERENACE_AMOUNT = LINES_ROW.Differenace_Amount
               WHERE t.receipt_line_id = LINES_ROW.LINE_ID;

              P_MESSAGE := 'SUCCESS';

              --更新接口表intf_ar_soa_receipt_lines状态为0：成功
              UPDATE intf_ar_soa_receipt_lines
                 SET STATUS = '0', ERROR_INFO = P_MESSAGE, FLAG = '1'
               WHERE LINE_ID = LINES_ROW.LINE_ID AND FLAG = '0';

            EXCEPTION
              WHEN OTHERS THEN

                P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_CCS.P_ACCOUNT_CCS',
                                                    SQLCODE,
                                                    '对账单' || P_HEADER_ID || '客户确认失败, 数据插入确认式往来对账单到款结算行失败：' ||
                                                    substr(dbms_utility.format_error_backtrace,1,100) || SQLERRM);

                UPDATE intf_ar_soa_receipt_lines
                   SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
                 WHERE LINE_ID = LINES_ROW.LINE_ID AND FLAG = '0';

            END;

          END LOOP;

          BEGIN
            UPDATE T_AR_SOA_ORDER_HEADS
               SET CONFIRM_USER_NAME = HEADS_ROW.CONFIRM_USER_NAME,
                   CONFIRM_FLAG = HEADS_ROW.Confirm_Flag,
                   CONFIRM_DATE = HEADS_ROW.Confirm_Date,
                   DIFF_CHECK_FLAG = HEADS_ROW.Diff_Check_Flag,
                   DIFF_CHECK_DATE = HEADS_ROW.Diff_Check_Date,
                   DIFF_CHECK_BY = HEADS_ROW.Diff_Check_By
             WHERE HEADER_ID = P_HEADER_ID;

            P_MESSAGE := 'SUCCESS';

            --更新接口表INTF_AR_SOA_ORDER_HEADS状态为0：成功
            UPDATE INTF_AR_SOA_ORDER_HEADS
               SET STATUS = '0', ERROR_INFO = P_MESSAGE, FLAG = '1'
             WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

          EXCEPTION
            WHEN OTHERS THEN
              P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_CCS.P_ACCOUNT_CCS',
                                                  SQLCODE,
                                                  '对账单' || P_HEADER_ID || '客户确认失败, 数据插入确认式往来对账单头表失败：' ||
                                                  substr(dbms_utility.format_error_backtrace,1,100) || SQLERRM);

              UPDATE INTF_AR_SOA_ORDER_HEADS
                 SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
               WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

          END;

        end if;

        end if;
      else

        P_MESSAGE := 'HEADER_ID：' || P_HEADER_ID ||
                     '在对账单头表T_AR_SOA_ORDER_HEADS中不存在';

        UPDATE INTF_AR_SOA_ORDER_DIFFERENCES
           SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
         WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

        UPDATE INTF_AR_SOA_ORDER_FILES
           SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
         WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

        UPDATE intf_ar_soa_receipt_lines
           SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
         WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

        UPDATE intf_ar_soa_order_heads
           SET STATUS = '1', ERROR_INFO = P_MESSAGE, FLAG = '1'
         WHERE HEADER_ID = P_HEADER_ID AND FLAG = '0';

      end if;

    END LOOP;

  EXCEPTION

    WHEN OTHERS THEN

      --dbms_output.put_line(SQLERRM);
      --记录出错信息
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_INTF_CCS.P_ACCOUNT_CCS',
                                          SQLCODE,
                                          '对账单' || P_HEADER_ID || '客户确认失败: ' || substr(dbms_utility.format_error_backtrace,1,100) || SQLERRM);

      COMMIT;

  END;

END PKG_AR_INTF_CCS;
/

