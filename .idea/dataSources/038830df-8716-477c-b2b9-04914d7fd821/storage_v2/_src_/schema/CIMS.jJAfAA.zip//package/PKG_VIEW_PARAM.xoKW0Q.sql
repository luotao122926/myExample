create package pkg_view_param is

  -- Author  : HEJY3
  -- Created : 2017-2-14 11:35:35
  -- Purpose : 
  -- Public function and procedure declarations
  function set_Entity_Id(p_Entity_Id number) return number; 
  function get_Entity_id return number;
  
  function set_Customer_Code(p_Customer_Code varchar2) return varchar2; 
  function get_Customer_Code return varchar2;
  
  function set_Sales_Center_Code(p_Sales_Center_Code varchar2) return varchar2; 
  function get_Sales_Center_Code return varchar2;
  
  function set_Item_Code(p_Item_Code varchar2) return varchar2; 
  function get_Item_Code return varchar2;

end pkg_view_param;
/

