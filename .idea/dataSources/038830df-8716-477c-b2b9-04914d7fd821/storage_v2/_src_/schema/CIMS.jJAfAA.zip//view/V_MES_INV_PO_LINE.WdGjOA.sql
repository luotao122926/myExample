create view V_MES_INV_PO_LINE as
select tl.BILLED_QTY AS QTY, --数量
       tl.ITEM_BAR_CODE AS MITEMBARCODE, --物料条码
       tl.ITEM_CODE AS MITEMNAME, --物料编码
       tl.ITEM_NAME AS MITEMDESC, --物料名称
       tl.ITEM_ID AS ITEMID, --物料ID
       tl.PO_LINE_ID AS LINEID, --行ID
       tl.UOM_CODE AS  MITEMUOM, --物料单位
       tl.PO_ID AS HEADID,  -- 头ID
       tl.LAST_UPDATE_DATE --最后修改时间(liaolz添加)
from t_inv_po_lines tl, t_inv_po_headers h
where  tl.po_id = h.po_id
       --and h.PO_TYPE in ('1001','1003','1005')
       and h.print_count > 0
/

