create package body      PKG_CREDIT_DIS is

  --------------------------------------------------------------------------------
  /*
  *   创建日期：2017-04-10
  *     创建者：梁颜明
  *   功能说明：信用管理折扣类型处理
  *
  */
  -------------------------------------------------------------------------------  /**

  /**
  * 折扣类型余款更新历史
  **/
  PROCEDURE P_ADD_DIS_AMOUNT_HIS(IN_ACTION_TYPE     IN NUMBER, --操作类型 非信用控制(销售)写负1，其他（订单、返利）与信用控制动作标识一致 PKG_CREDIT_ACCOUNT_CONTROL PRC_CREDIT_VERIFICATION
                                 IS_ACTION_DESC     IN VARCHAR2, --操作描述 比如销售单新增 销售单更新
                                 IN_ENTITY_ID       IN NUMBER, --主体ID
                                 IN_ACCOUNT_ID      IN NUMBER, --客户账户ID
                                 IN_CREDIT_GROUP_ID IN NUMBER, --额度组ID
                                 IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                 IS_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 订单、销售单头上的折扣金额
                                 IN_RECEIPT_AMOUNT  IN NUMBER, --上账金额 只有销售折让、折让证明取结算金额，其他传入0
                                 IN_SALES_AMOUNT    IN NUMBER, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                                 IN_LOCK_AMOUNT     IN NUMBER, --金额 只有锁款、解锁传入结算金额，其他传入0
                                 IN_CASH_AMOUNT     IN NUMBER,--
                                 IS_SOURCE_TYPE     IN VARCHAR2, --来源类型 取码表SO_SRC_TYPE
                                 IN_SOURCE_BILL_ID  IN VARCHAR2, --来源单据ID
                                 IS_USER_NAME       IN VARCHAR2 --操作人
                                 ) IS
  BEGIN
    --T_CREDIT_DIS_AMOUNT_HIS
    INSERT INTO T_CREDIT_DIS_AMOUNT_HIS
      (DIS_AMOUNT_HIS_ID,
       ACCOUNT_ID,
       ENTITY_ID,
       ACTION_TYPE,
       SOURCE_TYPE,
       SOURCE_BILL_ID,
       SALES_MAIN_TYPE,
       CREDIT_GROUP_ID,
       DISCOUNT_TYPE,
       RECEIPT_AMOUNT,
       SALES_AMOUNT,
       LOCK_AMOUNT,
       RECEIVED_AMOUNT,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE,
       ACTION_DESC)
    VALUES
      (S_CREDIT_DIS_AMOUNT_HIS.NEXTVAL,
       IN_ACCOUNT_ID,
       IN_ENTITY_ID,
       IN_ACTION_TYPE,
       IS_SOURCE_TYPE,
       IN_SOURCE_BILL_ID,
       IS_SALES_MAIN_TYPE,
       IN_CREDIT_GROUP_ID,
       IS_DISCOUNT_TYPE,
       IN_RECEIPT_AMOUNT,
       IN_SALES_AMOUNT,
       IN_LOCK_AMOUNT,
       IN_CASH_AMOUNT,
       IS_USER_NAME,
       SYSDATE,
       IS_USER_NAME,
       SYSDATE,
       IS_ACTION_DESC);
  END P_ADD_DIS_AMOUNT_HIS;

  /**
  * 折扣类型余款检查 调用私有过程
  */
  PROCEDURE P_CHECK_DISOUNT_AMOUNT(IN_ENTITY_ID       IN NUMBER, --主体ID
                                   IN_ACCOUNT_ID      IN NUMBER, --客户账户ID
                                   IN_CREDIT_GROUP_ID IN NUMBER, --额度组ID
                                   --IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                   --IS_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 取行上的折扣类型
                                   IN_AMOUNT     IN NUMBER, --金额
                                   IN_CHECK_TYPE IN NUMBER, --检查类型 
                                   --1锁款减少
                                   --2锁款增加
                                   --3销售金额减少（手工开退货单、红冲单、结算销售金额减少）
                                   --4销售金额增加锁款减少（锁款自动开单）
                                   --5销售金额增加锁款不变（手工开单、退货红冲单、结算销售金额增加、或无锁款自动开单）
                                   --6上账金额减少（销售折让红冲单、折让证明红冲单、结算上账金额减少）
                                   --7释放全款锁定、增加订金锁定 IN_AMOUNT IN_DOWN_PAY_AMOUNT 都不能为空
                                   --8释放订金、增加全款锁定 IN_AMOUNT IN_DOWN_PAY_AMOUNT 都不能为空
                                   ON_RESULT          OUT NUMBER, --成功则返回0，否则返回对应的出错代码
                                   OS_MESSAGE         OUT VARCHAR2, --成功返回“SUCCESS”；失败返回出错信息
                                   IN_DOWN_PAY_AMOUNT IN NUMBER DEFAULT NULL, --订金金额
                                   IN_DOWN_PAY_SCALE  IN NUMBER DEFAULT NULL --订金比例
                                   ,IN_ORDER_DP_AMOUNT IN NUMBER DEFAULT NULL --订单订金
                                   --,IN_ORDER_DIS_DP_AMOUNT IN NUMBER DEFAULT NULL --订单折扣订金
                                   ) IS
    VN_RECEIPT_AMOUNT NUMBER; --非“常规到款”上账金额
    VN_SALES_AMOUNT   NUMBER; --销售金额
    VN_LOCK_AMOUNT    NUMBER; --金额
    VN_RECEIVED_AMOUNT        NUMBER; --折让到款到款金额
    VT_AMOUNT_CRTL_FLAG       T_SALES_ACCOUNT_AMOUNT.AMOUNT_CRTL_FLAG%TYPE;
  BEGIN
    --ADD BY LIANGYM2 2017-7-28 根据客户款项金额控制标识确定是否检查 若AMOUNT_CRTL_FLAG等于-1（关闭），不做控制
    BEGIN
      SELECT A.AMOUNT_CRTL_FLAG INTO VT_AMOUNT_CRTL_FLAG FROM T_SALES_ACCOUNT_AMOUNT A
      WHERE A.ENTITY_ID = IN_ENTITY_ID AND A.ACCOUNT_ID = IN_ACCOUNT_ID
      AND A.CREDIT_GROUP_ID = IN_CREDIT_GROUP_ID;
      IF -1 = VT_AMOUNT_CRTL_FLAG THEN
        --金额控制关闭
        ON_RESULT  := 0;
        OS_MESSAGE := V_SUCCESS_MSG;
        RETURN;
      END IF;
    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;
    VN_RECEIPT_AMOUNT := 0;
    VN_SALES_AMOUNT   := 0;
    VN_LOCK_AMOUNT    := 0;
    VN_RECEIVED_AMOUNT   := 0;
    FOR LI IN (SELECT A.RECEIVED_AMOUNT,A.RECEIPT_AMOUNT, A.SALES_AMOUNT, A.LOCK_AMOUNT
                 FROM T_CREDIT_DISCOUNT_AMOUNT A
                WHERE A.ENTITY_ID = IN_ENTITY_ID
                  AND A.ACCOUNT_ID = IN_ACCOUNT_ID
                  AND IN_CREDIT_GROUP_ID =
                      PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(A.ENTITY_ID,
                                                             A.CUSTOMER_ID,
                                                             A.SALES_MAIN_TYPE,
                                                             A.ACCOUNT_ID)
                  FOR UPDATE WAIT 10) LOOP
      VN_RECEIPT_AMOUNT := VN_RECEIPT_AMOUNT + NVL(LI.RECEIPT_AMOUNT, 0);
      VN_RECEIVED_AMOUNT := VN_RECEIVED_AMOUNT + NVL(LI.RECEIVED_AMOUNT, 0);
      VN_SALES_AMOUNT   := VN_SALES_AMOUNT + NVL(LI.SALES_AMOUNT, 0);
      VN_LOCK_AMOUNT    := VN_LOCK_AMOUNT + NVL(LI.LOCK_AMOUNT, 0);
    END LOOP;
    VN_RECEIPT_AMOUNT := (VN_RECEIPT_AMOUNT + VN_RECEIVED_AMOUNT);
    
    IF 0 >= IN_DOWN_PAY_AMOUNT AND IN_CHECK_TYPE IN (1,2) THEN
      --如果订金金额不为空并且小于等于0，不用校验，直接返回成功，针对IN_CHECK_TYPE=1或2
      ON_RESULT  := 0;
      OS_MESSAGE := V_SUCCESS_MSG;
    ELSIF 1 = IN_CHECK_TYPE OR 4 = IN_CHECK_TYPE THEN
      --1锁款减少 4销售金额增加锁款减少（锁款自动开单）
      IF IN_DOWN_PAY_AMOUNT > VN_LOCK_AMOUNT AND IN_DOWN_PAY_SCALE IS NOT NULL THEN
        ON_RESULT  := 1;
        OS_MESSAGE := '折让款项锁定金额不足：当前需释放的锁定到款金额：' || IN_DOWN_PAY_AMOUNT
        || '（订金比例：' || IN_DOWN_PAY_SCALE || '%）大于折让款项锁定到款金额（' || VN_LOCK_AMOUNT || '）';
      ELSIF IN_AMOUNT > VN_LOCK_AMOUNT THEN
        ON_RESULT  := 1;
        OS_MESSAGE := '折让款项锁定金额不足：当前需释放的锁定到款金额（' || IN_AMOUNT || '）大于折让款项锁定到款金额（' ||
                      VN_LOCK_AMOUNT || '）';
      ELSE
        ON_RESULT  := 0;
        OS_MESSAGE := V_SUCCESS_MSG;
      END IF;
    ELSIF 2 = IN_CHECK_TYPE OR 5 = IN_CHECK_TYPE THEN
      --2锁款增加 5销售金额增加锁款不变（手工开单、结算销售金额增加、或无锁款自动开单）
      --IN_DOWN_PAY_SCALE
      IF IN_DOWN_PAY_SCALE IS NOT NULL AND IN_DOWN_PAY_AMOUNT > (VN_RECEIPT_AMOUNT - VN_SALES_AMOUNT - VN_LOCK_AMOUNT) THEN
        ON_RESULT  := 1;
        OS_MESSAGE := '折让款项可用到款金额不足：当前需增加的折让款项锁定金额' || IN_DOWN_PAY_AMOUNT || '（'
         || '订金比例：' || IN_DOWN_PAY_SCALE || '%）大于【非“常规到款”到款金额（' ||
                        VN_RECEIPT_AMOUNT || '）－销售金额（' || VN_SALES_AMOUNT ||
                        '）－锁定金额（' || VN_LOCK_AMOUNT || '）】=' ||
                        (VN_RECEIPT_AMOUNT - VN_SALES_AMOUNT - VN_LOCK_AMOUNT);
      ELSIF IN_AMOUNT > (VN_RECEIPT_AMOUNT - VN_SALES_AMOUNT - VN_LOCK_AMOUNT) THEN
        ON_RESULT  := 1;
        IF 2 = IN_CHECK_TYPE THEN
          OS_MESSAGE := '折让款项可用到款金额不足：当前需增加的折让款项锁定金额（' || IN_AMOUNT || '）大于折让款项：【非“常规到款”到款金额（' ||
                        VN_RECEIPT_AMOUNT || '）－销售金额（' || VN_SALES_AMOUNT ||
                        '）－锁定金额（' || VN_LOCK_AMOUNT || '）】=' ||
                        (VN_RECEIPT_AMOUNT - VN_SALES_AMOUNT - VN_LOCK_AMOUNT);
        ELSE
          OS_MESSAGE := '折让款项可用到款金额不足：当前需增加的折让款项销售金额（' || IN_AMOUNT || '）大于折让款项：【非“常规到款”到款金额（' ||
                        VN_RECEIPT_AMOUNT || '）－销售金额（' || VN_SALES_AMOUNT ||
                        '）－锁定金额（' || VN_LOCK_AMOUNT || '）】=' ||
                        (VN_RECEIPT_AMOUNT - VN_SALES_AMOUNT - VN_LOCK_AMOUNT);
        END IF;
      ELSE
        ON_RESULT  := 0;
        OS_MESSAGE := V_SUCCESS_MSG;
      END IF;
    ELSIF 3 = IN_CHECK_TYPE THEN
      --3销售金额减少（手工开退货单、红冲单、结算销售金额减少）
      IF IN_AMOUNT > VN_SALES_AMOUNT THEN
        ON_RESULT  := 1;
        OS_MESSAGE := '折让款项销售金额不足：当前金额（' || IN_AMOUNT || '）大于折让款项销售金额（' || VN_SALES_AMOUNT || '）';
      ELSE
        ON_RESULT  := 0;
        OS_MESSAGE := V_SUCCESS_MSG;
      END IF;
    ELSIF 6 = IN_CHECK_TYPE THEN
      --6上账金额减少（销售折让红冲单、折让证明红冲单、结算上账金额减少）
      IF IN_AMOUNT > VN_RECEIPT_AMOUNT THEN
        ON_RESULT  := 1;
        OS_MESSAGE := '非“常规到款”到款金额不足：当前调整金额绝对值（' || IN_AMOUNT || '）大于折让款项：非“常规到款”到款金额（' ||
                      VN_RECEIPT_AMOUNT || '）';
      ELSIF IN_AMOUNT >
            (VN_RECEIPT_AMOUNT - VN_SALES_AMOUNT - VN_LOCK_AMOUNT) THEN
        ON_RESULT  := 1;
        OS_MESSAGE := '折让款项可用金额不足：当前调整金额绝对值（' || IN_AMOUNT || '）大于折让款项：【非“常规到款”到款金额（' ||
                      VN_RECEIPT_AMOUNT || '）－销售金额（' || VN_SALES_AMOUNT ||
                      '）－锁定金额（' || VN_LOCK_AMOUNT || '）】=' ||
                      (VN_RECEIPT_AMOUNT - VN_SALES_AMOUNT - VN_LOCK_AMOUNT);
      ELSE
        ON_RESULT  := 0;
        OS_MESSAGE := V_SUCCESS_MSG;
      END IF;
    ELSIF 7 = IN_CHECK_TYPE THEN
      --7释放全款锁定、增加订金锁定 IN_AMOUNT IN_DOWN_PAY_AMOUNT 都不能为空
      ON_RESULT  := 0;
      OS_MESSAGE := V_SUCCESS_MSG;
    ELSIF 8 = IN_CHECK_TYPE THEN
      --8释放订金、增加全款锁定 IN_AMOUNT IN_DOWN_PAY_AMOUNT 都不能为空
      IF IN_AMOUNT > (VN_RECEIPT_AMOUNT - VN_SALES_AMOUNT - VN_LOCK_AMOUNT + IN_DOWN_PAY_AMOUNT) THEN
        ON_RESULT  := 1;
        
        OS_MESSAGE := '折让到款解锁订金锁款-校验不通过!';
        OS_MESSAGE := OS_MESSAGE || V_NL || '校验公式：(' || IN_AMOUNT || '-' || IN_DOWN_PAY_AMOUNT || ')>' || (VN_RECEIPT_AMOUNT - VN_SALES_AMOUNT - VN_LOCK_AMOUNT);
        OS_MESSAGE := OS_MESSAGE || V_NL || '本次所选择折让方式为“折让到款”的评审行以及对应的款项：【评审发货按100%比例锁定的总金额】-【按订金比例已锁定的订金】”不能大于【客户款项可用到款金额】';
          
        OS_MESSAGE := OS_MESSAGE || V_NL || '问题详解（若校验公式已理解且无疑惑请忽略方括号内容）：【目前订单的订金比例是' || IN_DOWN_PAY_SCALE || '%，送审时订单的锁定到款金额为' ||
                        IN_ORDER_DP_AMOUNT || '（订金）'
                        --|| (CASE WHEN 0 < IN_ORDER_DIS_DP_AMOUNT THEN '、锁定折扣金额为' || IN_ORDER_DIS_DP_AMOUNT || '（折扣订金）' ELSE NULL END)
                        || '，不含本次所选择评审行的订金：' || IN_DOWN_PAY_AMOUNT
                        || '，剩余未评审的订金应该是：' || (IN_ORDER_DP_AMOUNT - IN_DOWN_PAY_AMOUNT)
                        || '。此次评审发货，须按100%比例进行锁定的总金额：' || IN_AMOUNT || '（即评审发货所选择订单行的总金额'
                        --|| (CASE WHEN 0 < IN_DISCOUNT_AMOUNT THEN '，不含折扣部分：' || IN_DISCOUNT_AMOUNT ELSE NULL END) || '）'
                        || '但此金额减去相应比例的订金：（' || IN_AMOUNT || '-' || IN_DOWN_PAY_AMOUNT || '=' || (IN_AMOUNT - IN_DOWN_PAY_AMOUNT)
                        || '），大于客户款项可用到款金额：' || (VN_RECEIPT_AMOUNT - VN_SALES_AMOUNT - VN_LOCK_AMOUNT)
                        || '，不足以抵消此金额，不允许发货！！';
                        
        OS_MESSAGE := OS_MESSAGE || V_NL || '以上详解所说的评审行、订金、客户款项对应的折让方式均为“折让到款”，并非是“常规到款”哦' || V_NL;
        
        /*OS_MESSAGE := '可用金额不足：当前需增加的折让款项锁定金额：' || IN_AMOUNT || '（全款）大于折让款项：【非“常规到款”到款金额（' ||
                        VN_RECEIPT_AMOUNT || '）－销售金额（' || VN_SALES_AMOUNT ||
                        '）－锁定金额（' || VN_LOCK_AMOUNT || '）+ 待释放订金（'
                        || IN_DOWN_PAY_AMOUNT || '、订金比例：' || IN_DOWN_PAY_SCALE || '%）】=' ||
                        (VN_RECEIPT_AMOUNT - VN_SALES_AMOUNT - VN_LOCK_AMOUNT + IN_DOWN_PAY_AMOUNT);*/
        
      ELSE
        ON_RESULT  := 0;
        OS_MESSAGE := V_SUCCESS_MSG;
      END IF;
    END IF;
  END;

  /**
  * 折扣类型余款检查 入口
  *   1：订单评审
      2：订单取消
      3：开单（销售单，自动开单）
      36 开单（销售单，手工开单）
      4：开单（销售红冲单）
      5：开单（退货单）
      6：开单（退货红冲单）
      7：开单（折让证明单）
      8：开单（折让证明红冲单）
      9：开单（销售折让单）
      10：开单（销售折让红冲单）
      11：开单、结算（扣率折让单）
      12：开单、结算（扣率折让红冲单）
      13 结算[折让证明单,折让证明红冲单,销售折让单,销售折让红冲单]（非“常规到款”到款金额，增加IN_AMOUNT传正数，减少IN_AMOUNT传负数）
      14 结算[销售单,销售红冲单,退货单,退货红冲单]（销售金额，增加IN_AMOUNT传正数，减少IN_AMOUNT传负数）
      15：收款确认（不包括三方承兑）（不使用，直接返回成功 ）
      16：收款冲销（不使用，直接返回成功 ）
      17：三方承兑到款（不使用，直接返回成功 ）
      18：三方承兑冲销（不使用，直接返回成功 ）
      19：三方承兑解付（不使用，直接返回成功 ）
      20：三方承兑解付冲销（不使用，直接返回成功 ）
      21：退款（不使用，直接返回成功 ）
      22：铺底审批（铺底）（不使用，直接返回成功 ）
      23：铺底审批（临时铺底）（不使用，直接返回成功 ）
      24：铺底审批（冻结折让）（不使用，直接返回成功 ）
      25：铺底到期（铺底）（不使用，直接返回成功 ）
      26：铺底到期（临时铺底）（不使用，直接返回成功 ）
      27：铺底到期（冻结折让）（不使用，直接返回成功 ）
      28: 解锁订金（不使用，直接返回成功 ）
      29: 锁订金（不使用，直接返回成功 ）
  *             按资源提货（不使用，直接返回成功 ）
                30：资源返利单（不使用，直接返回成功 ）
                31：资源返利红冲单（不使用，直接返回成功 ）
                32：资源提货订单（不使用，直接返回成功 ）
                33：资源提货订单取消（不使用，直接返回成功 ）
                34：资源发放单（不使用，直接返回成功 ）
                40：领用（不使用，直接返回成功 ）
                35:返利调整单
  **/
  PROCEDURE P_CHECK_DIS_AMOUNT(IN_ACTION_TYPE IN NUMBER, --操作类型
                               --与信用控制动作标识一致 PKG_CREDIT_ACCOUNT_CONTROL PRC_CREDIT_VERIFICATION
                               IN_ENTITY_ID       IN NUMBER, --主体ID
                               IN_ACCOUNT_ID      IN NUMBER, --客户账户ID
                               IS_SOURCE_TYPE     IN VARCHAR2, --来源类型 取码表SO_SRC_TYPE
                               IN_SOURCE_BILL_ID  IN NUMBER, --来源单据ID 取相应的单据头ID
                               IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                               IS_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 取行上的折扣类型
                               IN_AMOUNT          IN NUMBER, --金额
                               IS_USER_NAME       IN VARCHAR2, --操作人
                               IS_ATTRIB01        IN VARCHAR2, --预留输入参数01
                               IS_ATTRIB02        IN VARCHAR2, --预留输入参数02
                               ON_RESULT          OUT NUMBER, --成功则返回0，否则返回对应的出错代码
                               OS_MESSAGE         OUT VARCHAR2, --成功返回“SUCCESS”；失败返回出错信息
                               OS_ATTRIB01        OUT VARCHAR2, --预留输出参数01
                               OS_ATTRIB02        OUT VARCHAR2 --预留输出参数02
                               ) IS
    VN_CREDIT_GROUP_ID NUMBER;
    V_PLN_LG_ORDER_HEAD   T_PLN_LG_ORDER_HEAD%ROWTYPE;
    VN_DOWN_PAY_AMOUNT    NUMBER;
  BEGIN
    IF IN_ACTION_TYPE IS NULL THEN
      ON_RESULT  := -1;
      OS_MESSAGE := '动作标识不能为空';
      RETURN;
    END IF;
    IF IS_SOURCE_TYPE IS NULL THEN
      ON_RESULT  := -1;
      OS_MESSAGE := '来源类型不能为空';
      RETURN;
    END IF;
    IF IN_SOURCE_BILL_ID IS NULL THEN
      ON_RESULT  := -1;
      OS_MESSAGE := '来源单据ID不能为空';
      RETURN;
    END IF;
    IF NOT (IN_ACTION_TYPE BETWEEN 1 AND 36 OR IN_ACTION_TYPE = 40) THEN
      ON_RESULT  := -1;
      OS_MESSAGE := '动作标识有误，必须是1到36之间的数字或者是40';
      RETURN;
    END IF;
    ON_RESULT  := 0;
    OS_MESSAGE := V_SUCCESS_MSG;
    IF (IN_ACTION_TYPE = 40 OR IN_ACTION_TYPE = 11 OR IN_ACTION_TYPE = 12
       OR (IN_ACTION_TYPE NOT IN (28,29) AND IN_ACTION_TYPE NOT BETWEEN 15 AND 21
       AND IN_ACTION_TYPE BETWEEN 22 AND 34) ) THEN
      RETURN;
    END IF;
  
    --
    IF IS_DISCOUNT_TYPE IS NULL OR 'COMMON' = IS_DISCOUNT_TYPE THEN
      RETURN;
    END IF;
  
    SELECT PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(A.ENTITY_ID,
                                                  A.CUSTOMER_ID,
                                                  IS_SALES_MAIN_TYPE,
                                                  A.ACCOUNT_ID)
      INTO VN_CREDIT_GROUP_ID
      FROM T_CUSTOMER_ACCOUNT A
     WHERE A.ENTITY_ID = IN_ENTITY_ID
       AND A.ACCOUNT_ID = IN_ACCOUNT_ID;
    IF 0 >= VN_CREDIT_GROUP_ID THEN
      ON_RESULT  := -1;
      OS_MESSAGE := '不存在客户账户与大类的额度组配置关系[主体ID:' || IN_ENTITY_ID || '营销大类' ||
                    IS_SALES_MAIN_TYPE || '账户ID' || IN_ACCOUNT_ID;
      RETURN;
    END IF;
    IF IN_ACTION_TYPE IN (1,2,28,29) THEN
      BEGIN
        SELECT * INTO V_PLN_LG_ORDER_HEAD FROM T_PLN_LG_ORDER_HEAD
        WHERE ORDER_HEAD_ID = IN_SOURCE_BILL_ID;
      EXCEPTION WHEN OTHERS THEN
        --为了避免增加订金对原来程序的影响，保持稳定，捕获异常
        NULL;
      END;
      --如果动作标识是28，送审锁款，并且订金比例为空或小于0，不做任何处理，直接返回成功
      IF IN_ACTION_TYPE IN (28,29) AND (V_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID IS NULL 
        OR (V_PLN_LG_ORDER_HEAD.LOCK_AMOUNT_FLAG IN ('S','RS','HQ')
         AND 0 > NVL(V_PLN_LG_ORDER_HEAD.DOWN_PAY_SCALE,-1))) THEN
          RETURN;
      ELSIF V_PLN_LG_ORDER_HEAD.ORDER_HEAD_ID IS NOT NULL
        AND V_PLN_LG_ORDER_HEAD.DOWN_PAY_SCALE >= 0 AND V_PLN_LG_ORDER_HEAD.LOCK_AMOUNT_FLAG IN ('S','HQ') THEN
        VN_DOWN_PAY_AMOUNT := (IN_AMOUNT * V_PLN_LG_ORDER_HEAD.DOWN_PAY_SCALE / 100);
      END IF;
    END IF;
    
    IF 1 = IN_ACTION_TYPE THEN
    
      P_CHECK_DISOUNT_AMOUNT(IN_ENTITY_ID,
                             IN_ACCOUNT_ID,
                             VN_CREDIT_GROUP_ID,
                             --IN_AMOUNT,
                             (CASE WHEN VN_DOWN_PAY_AMOUNT IS NULL THEN IN_AMOUNT ELSE NULL END),
                             2, --2锁款增加
                             ON_RESULT,
                             OS_MESSAGE,
                             VN_DOWN_PAY_AMOUNT,
                             V_PLN_LG_ORDER_HEAD.DOWN_PAY_SCALE
                             ,V_PLN_LG_ORDER_HEAD.DOWN_PAY_AMOUNT
                             --,V_PLN_LG_ORDER_HEAD.DOWN_PAY_DIS_AMOUNT
                             );
      IF 0 = ON_RESULT THEN
        P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                            NULL,
                            IN_ENTITY_ID, --主体ID
                            IN_ACCOUNT_ID, --客户账户ID
                            IS_SALES_MAIN_TYPE, --营销大类
                            IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                            0, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                            0, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                            --IN_AMOUNT, --金额 只有锁款、解锁传入结算金额，其他传入0
                            NVL(VN_DOWN_PAY_AMOUNT,IN_AMOUNT),--金额 只有锁款、解锁传入结算金额，其他传入0
                            0,
                            IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                            IN_SOURCE_BILL_ID, --来源单据ID
                            IS_USER_NAME, --操作人,
                            ON_RESULT,
                            OS_MESSAGE);
      END IF;
    ELSIF 2 = IN_ACTION_TYPE THEN
    
      P_CHECK_DISOUNT_AMOUNT(IN_ENTITY_ID,
                             IN_ACCOUNT_ID,
                             VN_CREDIT_GROUP_ID,
                             --IN_AMOUNT,
                             (CASE WHEN VN_DOWN_PAY_AMOUNT IS NULL THEN IN_AMOUNT ELSE NULL END),
                             1, --1锁款减少
                             ON_RESULT,
                             OS_MESSAGE,
                             VN_DOWN_PAY_AMOUNT,
                             V_PLN_LG_ORDER_HEAD.DOWN_PAY_SCALE
                             ,V_PLN_LG_ORDER_HEAD.DOWN_PAY_AMOUNT
                             --,V_PLN_LG_ORDER_HEAD.DOWN_PAY_DIS_AMOUNT
                             );
      IF 0 = ON_RESULT THEN
        P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                            NULL,
                            IN_ENTITY_ID, --主体ID
                            IN_ACCOUNT_ID, --客户账户ID
                            IS_SALES_MAIN_TYPE, --营销大类
                            IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                            0, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                            0, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                            ---IN_AMOUNT, --金额 只有锁款、解锁传入结算金额，其他传入0
                            -NVL(VN_DOWN_PAY_AMOUNT,IN_AMOUNT),--金额 只有锁款、解锁传入结算金额，其他传入0
                            0,
                            IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                            IN_SOURCE_BILL_ID, --来源单据ID
                            IS_USER_NAME, --操作人,
                            ON_RESULT,
                            OS_MESSAGE);
      END IF;
    ELSIF 29 = IN_ACTION_TYPE THEN--动作标识等于29 取消发货通知单，需要释放全款锁定、增加订金锁定
    
      P_CHECK_DISOUNT_AMOUNT(IN_ENTITY_ID,
                             IN_ACCOUNT_ID,
                             VN_CREDIT_GROUP_ID,
                             IN_AMOUNT,
                             7, --7释放全款锁定、增加订金锁定
                             ON_RESULT,
                             OS_MESSAGE,
                             VN_DOWN_PAY_AMOUNT,
                             V_PLN_LG_ORDER_HEAD.DOWN_PAY_SCALE
                             ,V_PLN_LG_ORDER_HEAD.DOWN_PAY_AMOUNT
                             --,V_PLN_LG_ORDER_HEAD.DOWN_PAY_DIS_AMOUNT
                             );
      IF 0 = ON_RESULT THEN
        P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                            '释放全款锁定',
                            IN_ENTITY_ID, --主体ID
                            IN_ACCOUNT_ID, --客户账户ID
                            IS_SALES_MAIN_TYPE, --营销大类
                            IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                            0, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                            0, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                            -IN_AMOUNT,--金额 只有锁款、解锁传入结算金额，其他传入0
                            0,
                            IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                            IN_SOURCE_BILL_ID, --来源单据ID
                            IS_USER_NAME, --操作人,
                            ON_RESULT,
                            OS_MESSAGE);
        IF 0 = ON_RESULT THEN
          P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                              '增加订金锁定',
                              IN_ENTITY_ID, --主体ID
                              IN_ACCOUNT_ID, --客户账户ID
                              IS_SALES_MAIN_TYPE, --营销大类
                              IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                              0, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                              0, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                              VN_DOWN_PAY_AMOUNT,--金额 只有锁款、解锁传入结算金额，其他传入0
                              0,
                              IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                              IN_SOURCE_BILL_ID, --来源单据ID
                              IS_USER_NAME, --操作人,
                              ON_RESULT,
                              OS_MESSAGE);
        END IF;
      END IF;
    ELSIF 28 = IN_ACTION_TYPE THEN--动作标识：28 评审生成发货计划，需要释放订金、增加全款锁定
    
      P_CHECK_DISOUNT_AMOUNT(IN_ENTITY_ID,
                             IN_ACCOUNT_ID,
                             VN_CREDIT_GROUP_ID,
                             IN_AMOUNT,
                             8, --8释放订金、增加全款锁定
                             ON_RESULT,
                             OS_MESSAGE,
                             VN_DOWN_PAY_AMOUNT,
                             V_PLN_LG_ORDER_HEAD.DOWN_PAY_SCALE
                             ,V_PLN_LG_ORDER_HEAD.DOWN_PAY_AMOUNT
                             --,V_PLN_LG_ORDER_HEAD.DOWN_PAY_DIS_AMOUNT
                             );
      IF 0 = ON_RESULT THEN
        P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                            '释放订金',
                            IN_ENTITY_ID, --主体ID
                            IN_ACCOUNT_ID, --客户账户ID
                            IS_SALES_MAIN_TYPE, --营销大类
                            IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                            0, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                            0, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                            ---IN_AMOUNT, --金额 只有锁款、解锁传入结算金额，其他传入0
                            -VN_DOWN_PAY_AMOUNT,--金额 只有锁款、解锁传入结算金额，其他传入0
                            0,
                            IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                            IN_SOURCE_BILL_ID, --来源单据ID
                            IS_USER_NAME, --操作人,
                            ON_RESULT,
                            OS_MESSAGE);
        IF 0 = ON_RESULT THEN
          P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                              '增加全款锁定',
                              IN_ENTITY_ID, --主体ID
                              IN_ACCOUNT_ID, --客户账户ID
                              IS_SALES_MAIN_TYPE, --营销大类
                              IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                              0, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                              0, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                              ---IN_AMOUNT, --金额 只有锁款、解锁传入结算金额，其他传入0
                              IN_AMOUNT,--金额 只有锁款、解锁传入结算金额，其他传入0
                              0,
                              IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                              IN_SOURCE_BILL_ID, --来源单据ID
                              IS_USER_NAME, --操作人,
                              ON_RESULT,
                              OS_MESSAGE);
        END IF;
      END IF;
    ELSIF 3 = IN_ACTION_TYPE THEN
    
      P_CHECK_DISOUNT_AMOUNT(IN_ENTITY_ID,
                             IN_ACCOUNT_ID,
                             VN_CREDIT_GROUP_ID,
                             IN_AMOUNT,
                             4, --4销售金额增加锁款减少（锁款自动开单）
                             ON_RESULT,
                             OS_MESSAGE);
      IF 0 = ON_RESULT THEN
        P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                            NULL,
                            IN_ENTITY_ID, --主体ID
                            IN_ACCOUNT_ID, --客户账户ID
                            IS_SALES_MAIN_TYPE, --营销大类
                            IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                            0, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                            IN_AMOUNT, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                            -IN_AMOUNT, --金额 只有锁款、解锁传入结算金额，其他传入0
                            0,
                            IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                            IN_SOURCE_BILL_ID, --来源单据ID
                            IS_USER_NAME, --操作人,
                            ON_RESULT,
                            OS_MESSAGE);
      END IF;
    ELSIF 36 = IN_ACTION_TYPE OR 6 = IN_ACTION_TYPE OR
          (14 = IN_ACTION_TYPE AND 0 < IN_AMOUNT) THEN
    
      P_CHECK_DISOUNT_AMOUNT(IN_ENTITY_ID,
                             IN_ACCOUNT_ID,
                             VN_CREDIT_GROUP_ID,
                             IN_AMOUNT,
                             5, --5销售金额增加锁款不变（手工开单、退货红冲单、结算销售金额增加、或无锁款自动开单）
                             ON_RESULT,
                             OS_MESSAGE);
      IF 0 = ON_RESULT THEN
        P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                            NULL,
                            IN_ENTITY_ID, --主体ID
                            IN_ACCOUNT_ID, --客户账户ID
                            IS_SALES_MAIN_TYPE, --营销大类
                            IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                            0, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                            IN_AMOUNT, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                            0, --金额 只有锁款、解锁传入结算金额，其他传入0
                            0,
                            IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                            IN_SOURCE_BILL_ID, --来源单据ID
                            IS_USER_NAME, --操作人,
                            ON_RESULT,
                            OS_MESSAGE);
      END IF;
    ELSIF (14 = IN_ACTION_TYPE AND 0 > IN_AMOUNT) THEN
      ON_RESULT := 0;
      --2017-8-5 liangym2 销售金额减少不做校验
      /*P_CHECK_DISOUNT_AMOUNT(IN_ENTITY_ID,
                             IN_ACCOUNT_ID,
                             VN_CREDIT_GROUP_ID,
                             -IN_AMOUNT,
                             3, --3销售金额减少（手工开退货单、红冲单、结算销售金额减少）
                             ON_RESULT,
                             OS_MESSAGE);*/
      IF 0 = ON_RESULT THEN
        P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                            NULL,
                            IN_ENTITY_ID, --主体ID
                            IN_ACCOUNT_ID, --客户账户ID
                            IS_SALES_MAIN_TYPE, --营销大类
                            IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                            0, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                            IN_AMOUNT, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                            0, --金额 只有锁款、解锁传入结算金额，其他传入0
                            0,
                            IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                            IN_SOURCE_BILL_ID, --来源单据ID
                            IS_USER_NAME, --操作人,
                            ON_RESULT,
                            OS_MESSAGE);
      END IF;
    ELSIF (13 = IN_ACTION_TYPE) THEN
    
      IF 0 > IN_AMOUNT THEN
        P_CHECK_DISOUNT_AMOUNT(IN_ENTITY_ID,
                               IN_ACCOUNT_ID,
                               VN_CREDIT_GROUP_ID,
                               -IN_AMOUNT,
                               6, --6上账金额减少（销售折让红冲单、折让证明红冲单、结算上账金额减少）
                               ON_RESULT,
                               OS_MESSAGE);
        --ELSE
        --  ON_RESULT := 0;
      END IF;
      IF 0 = ON_RESULT THEN
        P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                            NULL,
                            IN_ENTITY_ID, --主体ID
                            IN_ACCOUNT_ID, --客户账户ID
                            IS_SALES_MAIN_TYPE, --营销大类
                            IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                            IN_AMOUNT, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                            0, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                            0, --金额 只有锁款、解锁传入结算金额，其他传入0
                            0,
                            IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                            IN_SOURCE_BILL_ID, --来源单据ID
                            IS_USER_NAME, --操作人,
                            ON_RESULT,
                            OS_MESSAGE);
      END IF;
    ELSIF (7 = IN_ACTION_TYPE OR 9 = IN_ACTION_TYPE) THEN
      --7：开单（折让证明单） 9：开单（销售折让单）
      P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                          NULL,
                          IN_ENTITY_ID, --主体ID
                          IN_ACCOUNT_ID, --客户账户ID
                          IS_SALES_MAIN_TYPE, --营销大类
                          IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                          IN_AMOUNT, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                          0, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                          0, --金额 只有锁款、解锁传入结算金额，其他传入0
                          0,
                          IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                          IN_SOURCE_BILL_ID, --来源单据ID
                          IS_USER_NAME, --操作人,
                          ON_RESULT,
                          OS_MESSAGE);
    ELSIF (8 = IN_ACTION_TYPE OR 10 = IN_ACTION_TYPE) THEN
      --8：开单（折让证明红冲单） 10：开单（销售折让红冲单）
      P_CHECK_DISOUNT_AMOUNT(IN_ENTITY_ID,
                             IN_ACCOUNT_ID,
                             VN_CREDIT_GROUP_ID,
                             IN_AMOUNT,
                             6, --6上账金额减少（销售折让红冲单、折让证明红冲单、结算上账金额减少）
                             ON_RESULT,
                             OS_MESSAGE);
      IF 0 = ON_RESULT THEN
        P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                            NULL,
                            IN_ENTITY_ID, --主体ID
                            IN_ACCOUNT_ID, --客户账户ID
                            IS_SALES_MAIN_TYPE, --营销大类
                            IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                            -IN_AMOUNT, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                            0, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                            0, --金额 只有锁款、解锁传入结算金额，其他传入0
                            0,
                            IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                            IN_SOURCE_BILL_ID, --来源单据ID
                            IS_USER_NAME, --操作人,
                            ON_RESULT,
                            OS_MESSAGE);
      END IF;
    ELSIF 4 = IN_ACTION_TYPE OR 5 = IN_ACTION_TYPE THEN
    
      ON_RESULT := 0;
      --2017-8-5 liangym2 销售金额减少不做校验
      /*P_CHECK_DISOUNT_AMOUNT(IN_ENTITY_ID,
                             IN_ACCOUNT_ID,
                             VN_CREDIT_GROUP_ID,
                             IN_AMOUNT,
                             3, --3销售金额减少（手工开退货单、红冲单、结算销售金额减少）
                             ON_RESULT,
                             OS_MESSAGE);*/
      IF 0 = ON_RESULT THEN
        P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                            NULL,
                            IN_ENTITY_ID, --主体ID
                            IN_ACCOUNT_ID, --客户账户ID
                            IS_SALES_MAIN_TYPE, --营销大类
                            IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                            0, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                            -IN_AMOUNT, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                            0, --金额 只有锁款、解锁传入结算金额，其他传入0
                            0,
                            IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                            IN_SOURCE_BILL_ID, --来源单据ID
                            IS_USER_NAME, --操作人,
                            ON_RESULT,
                            OS_MESSAGE);
      END IF;
    ELSIF 15 = IN_ACTION_TYPE THEN
      --收款确认（不包括三方承兑）
      P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                          NULL,
                          IN_ENTITY_ID, --主体ID
                          IN_ACCOUNT_ID, --客户账户ID
                          IS_SALES_MAIN_TYPE, --营销大类
                          IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                          0, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                          0, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                          0, --金额 只有锁款、解锁传入结算金额，其他传入0
                          IN_AMOUNT,
                          IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                          IN_SOURCE_BILL_ID, --来源单据ID
                          IS_USER_NAME, --操作人,
                          ON_RESULT,
                          OS_MESSAGE);
    ELSIF IN_ACTION_TYPE = 16 OR IN_ACTION_TYPE = 21 THEN
      --16 收款冲销 21 退款
      P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                          NULL,
                          IN_ENTITY_ID, --主体ID
                          IN_ACCOUNT_ID, --客户账户ID
                          IS_SALES_MAIN_TYPE, --营销大类
                          IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                          0, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                          0, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                          0, --金额 只有锁款、解锁传入结算金额，其他传入0
                          -IN_AMOUNT,
                          IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                          IN_SOURCE_BILL_ID, --来源单据ID
                          IS_USER_NAME, --操作人,
                          ON_RESULT,
                          OS_MESSAGE);
    ELSIF 17 = IN_ACTION_TYPE THEN
      --三方承兑到款
      P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                          NULL,
                          IN_ENTITY_ID, --主体ID
                          IN_ACCOUNT_ID, --客户账户ID
                          IS_SALES_MAIN_TYPE, --营销大类
                          IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                          0, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                          0, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                          IN_AMOUNT, --金额 只有锁款、解锁传入结算金额，其他传入0
                          IN_AMOUNT,
                          IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                          IN_SOURCE_BILL_ID, --来源单据ID
                          IS_USER_NAME, --操作人,
                          ON_RESULT,
                          OS_MESSAGE);
    ELSIF 18 = IN_ACTION_TYPE THEN
      --三方承兑冲销
      P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                          NULL,
                          IN_ENTITY_ID, --主体ID
                          IN_ACCOUNT_ID, --客户账户ID
                          IS_SALES_MAIN_TYPE, --营销大类
                          IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                          0, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                          0, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                          -IN_AMOUNT, --金额 只有锁款、解锁传入结算金额，其他传入0
                          -IN_AMOUNT,
                          IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                          IN_SOURCE_BILL_ID, --来源单据ID
                          IS_USER_NAME, --操作人,
                          ON_RESULT,
                          OS_MESSAGE);
    ELSIF 19 = IN_ACTION_TYPE THEN
      --三方承兑解付
      P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                          NULL,
                          IN_ENTITY_ID, --主体ID
                          IN_ACCOUNT_ID, --客户账户ID
                          IS_SALES_MAIN_TYPE, --营销大类
                          IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                          0, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                          0, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                          -IN_AMOUNT, --金额 只有锁款、解锁传入结算金额，其他传入0
                          0,
                          IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                          IN_SOURCE_BILL_ID, --来源单据ID
                          IS_USER_NAME, --操作人,
                          ON_RESULT,
                          OS_MESSAGE);
    ELSIF 20 = IN_ACTION_TYPE THEN
      --三方承兑解付冲销 THREE_NOT_PAY
      P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE,
                          NULL,
                          IN_ENTITY_ID, --主体ID
                          IN_ACCOUNT_ID, --客户账户ID
                          IS_SALES_MAIN_TYPE, --营销大类
                          IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                          0, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                          0, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                          IN_AMOUNT, --金额 只有锁款、解锁传入结算金额，其他传入0
                          0,
                          IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                          IN_SOURCE_BILL_ID, --来源单据ID
                          IS_USER_NAME, --操作人,
                          ON_RESULT,
                          OS_MESSAGE);
    ELSIF 35 = IN_ACTION_TYPE AND 0 > IN_AMOUNT THEN
      --返利调整 上账金额减少
      P_CHECK_DISOUNT_AMOUNT(IN_ENTITY_ID,
                             IN_ACCOUNT_ID,
                             VN_CREDIT_GROUP_ID,
                             -IN_AMOUNT,
                             6, --6上账金额减少（销售折让红冲单、折让证明红冲单、结算上账金额减少）
                             ON_RESULT,
                             OS_MESSAGE);
    END IF;
    IF 0 <> ON_RESULT THEN
      RAISE V_BIZ_EXCEPTION;
    END IF;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      ON_RESULT  := -1;
      OS_MESSAGE := '折扣类型款项更新不成功[' || IN_ACTION_TYPE || ',' || IN_ENTITY_ID || ',' ||
                    IN_ACCOUNT_ID || ',' || IS_SOURCE_TYPE || ',' ||
                    IN_SOURCE_BILL_ID || ',' || IS_SALES_MAIN_TYPE || ',' ||
                    IS_DISCOUNT_TYPE || ',' || IN_AMOUNT || ',' ||
                    IS_USER_NAME || ',' || IS_ATTRIB01 || ',' ||
                    IS_ATTRIB02 || ']' || OS_MESSAGE;
    WHEN OTHERS THEN
      ON_RESULT  := -1;
      OS_MESSAGE := '折扣类型款项更新出错[' || IN_ACTION_TYPE || ',' || IN_ENTITY_ID || ',' ||
                    IN_ACCOUNT_ID || ',' || IS_SOURCE_TYPE || ',' ||
                    IN_SOURCE_BILL_ID || ',' || IS_SALES_MAIN_TYPE || ',' ||
                    IS_DISCOUNT_TYPE || ',' || IN_AMOUNT || ',' ||
                    IS_USER_NAME || ',' || IS_ATTRIB01 || ',' ||
                    IS_ATTRIB02 || ']' || CHR(10) || SQLERRM;
  END;

  /**
  * 折扣类型余款更新 调用私有过程
  **/
  PROCEDURE P_UPDATE_DISCOUNT_AMOUNT(IN_ENTITY_ID       IN NUMBER, --主体ID
                                     IN_ACCOUNT_ID      IN NUMBER, --客户账户ID
                                     IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                     IS_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 订单、销售单头上的折扣金额
                                     IN_RECEIPT_AMOUNT  IN NUMBER, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                                     IN_SALES_AMOUNT    IN NUMBER, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                                     IN_LOCK_AMOUNT     IN NUMBER, --金额 只有锁款、解锁传入结算金额，其他传入0
                                     IN_CASH_AMOUNT     IN NUMBER,--收款单据到款金额
                                     IS_USER_NAME       IN VARCHAR2, --操作人
                                     ON_RESULT          OUT NUMBER, --成功则返回0，否则返回对应的出错代码
                                     OS_MESSAGE         OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息
                                     ) IS
    VC_CRE_DIS_AMOUNT T_CREDIT_DISCOUNT_AMOUNT%ROWTYPE;
    VN_COUNT          NUMBER;
  BEGIN
    ON_RESULT  := 0;
    OS_MESSAGE := V_SUCCESS_MSG;
  
    --
    IF IS_DISCOUNT_TYPE IS NULL OR 'COMMON' = IS_DISCOUNT_TYPE THEN
      RETURN;
    END IF;
    IF (IN_RECEIPT_AMOUNT IS NULL OR IN_RECEIPT_AMOUNT = 0) AND
       (IN_SALES_AMOUNT IS NULL OR IN_SALES_AMOUNT = 0) AND
       (IN_LOCK_AMOUNT IS NULL OR IN_LOCK_AMOUNT = 0) AND
       (IN_CASH_AMOUNT IS NULL OR IN_CASH_AMOUNT = 0) THEN
      RETURN;
    END IF;
    <<MAIN_START>>
  --查询相同主体、账户ID、营销大类、折扣类型的折扣款项记录个数，最大ID
    SELECT COUNT(0), MAX(DA.DISCOUNT_AMOUNT_ID)
      INTO VN_COUNT, VC_CRE_DIS_AMOUNT.DISCOUNT_AMOUNT_ID
      FROM T_CREDIT_DISCOUNT_AMOUNT DA
     WHERE (DA.ENTITY_ID = IN_ENTITY_ID AND DA.ACCOUNT_ID = IN_ACCOUNT_ID AND
           DA.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE AND
           DA.DISCOUNT_TYPE = IS_DISCOUNT_TYPE);
    --关联客户账户中心关系查到最新的中心ID、中心编码、名称 客户名称
    SELECT CO.SALES_CENTER_ID,
           CO.SALES_CENTER_CODE,
           CO.SALES_CENTER_NAME,
           A.CUSTOMER_ID,
           A.CUSTOMER_CODE,
           H.CUSTOMER_NAME
      INTO VC_CRE_DIS_AMOUNT.SALES_CENTER_ID,
           VC_CRE_DIS_AMOUNT.SALES_CENTER_CODE,
           VC_CRE_DIS_AMOUNT.SALES_CENTER_NAME,
           VC_CRE_DIS_AMOUNT.CUSTOMER_ID,
           VC_CRE_DIS_AMOUNT.CUSTOMER_CODE,
           VC_CRE_DIS_AMOUNT.CUSTOMER_NAME
      FROM T_CUSTOMER_ACCOUNT A
     INNER JOIN T_CUSTOMER_HEADER H
        ON (H.CUSTOMER_ID = A.CUSTOMER_ID)
     INNER JOIN T_CUSTOMER_ACC_ORG_RELATION AR
        ON (AR.ACCOUNT_ID = A.ACCOUNT_ID)
     INNER JOIN T_CUSTOMER_ORG CO
        ON (CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID)
     WHERE A.ACCOUNT_ID = IN_ACCOUNT_ID
       AND A.ENTITY_ID = IN_ENTITY_ID;
  
    IF VC_CRE_DIS_AMOUNT.DISCOUNT_AMOUNT_ID IS NULL THEN
      --无折扣款项记录，插入
      SELECT S_CREDIT_DISCOUNT_AMOUNT.NEXTVAL
        INTO VC_CRE_DIS_AMOUNT.DISCOUNT_AMOUNT_ID
        FROM DUAL;
      BEGIN
        INSERT INTO T_CREDIT_DISCOUNT_AMOUNT
          (DISCOUNT_AMOUNT_ID,
           SALES_CENTER_ID,
           SALES_CENTER_CODE,
           SALES_CENTER_NAME,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           CUSTOMER_NAME,
           ACCOUNT_ID,
           SALES_MAIN_TYPE,
           DISCOUNT_TYPE,
           RECEIPT_AMOUNT,
           SALES_AMOUNT,
           LOCK_AMOUNT,
           RECEIVED_AMOUNT,
           ENTITY_ID,
           CREATION_DATE,
           CREATED_BY)
        VALUES
          (VC_CRE_DIS_AMOUNT.DISCOUNT_AMOUNT_ID,
           VC_CRE_DIS_AMOUNT.SALES_CENTER_ID,
           VC_CRE_DIS_AMOUNT.SALES_CENTER_CODE,
           VC_CRE_DIS_AMOUNT.SALES_CENTER_NAME,
           VC_CRE_DIS_AMOUNT.CUSTOMER_ID,
           VC_CRE_DIS_AMOUNT.CUSTOMER_CODE,
           VC_CRE_DIS_AMOUNT.CUSTOMER_NAME,
           IN_ACCOUNT_ID,
           IS_SALES_MAIN_TYPE,
           IS_DISCOUNT_TYPE,
           NVL(IN_RECEIPT_AMOUNT, 0),
           NVL(IN_SALES_AMOUNT, 0),
           NVL(IN_LOCK_AMOUNT, 0),
           NVL(IN_CASH_AMOUNT,0),
           IN_ENTITY_ID,
           SYSDATE,
           NVL(IS_USER_NAME,'SYS'));
      
        --防止物理索引不存在，或者失效
        SELECT COUNT(0)
          INTO VN_COUNT
          FROM T_CREDIT_DISCOUNT_AMOUNT DA
         WHERE (DA.ENTITY_ID = IN_ENTITY_ID AND
               DA.ACCOUNT_ID = IN_ACCOUNT_ID AND
               DA.SALES_MAIN_TYPE = IS_SALES_MAIN_TYPE AND
               DA.DISCOUNT_TYPE = IS_DISCOUNT_TYPE);
        IF 1 < VN_COUNT THEN
          ON_RESULT  := -1;
          OS_MESSAGE := 'DUP_VAL_ON_INDEX';
          RETURN;
        END IF;
      
      EXCEPTION
        --DUP_VAL_ON_INDEX  ORA-00001 如果插入一列被唯一索引约束的重复值的时候，就会引发该异常（该值被INDEX认定为冲突的）
        WHEN DUP_VAL_ON_INDEX THEN
          ON_RESULT  := -1;
          OS_MESSAGE := 'DUP_VAL_ON_INDEX';
          RETURN;
      END;
    ELSIF 1 < VN_COUNT THEN
      ON_RESULT  := 1;
      OS_MESSAGE := '相同主体、账户ID、营销大类、折扣类型存在重复的折扣款项记录[' || IN_ENTITY_ID || '、' ||
                    IN_ACCOUNT_ID || '、' || IS_SALES_MAIN_TYPE || '、' ||
                    IS_DISCOUNT_TYPE || ']';
      RETURN;
    ELSE
      SELECT *
        INTO VC_CRE_DIS_AMOUNT
        FROM T_CREDIT_DISCOUNT_AMOUNT
       WHERE DISCOUNT_AMOUNT_ID = VC_CRE_DIS_AMOUNT.DISCOUNT_AMOUNT_ID
      --不能使用nowait 或者 wait 或者并发频繁容易导致报错、销售单等无法正常生成
         FOR UPDATE --WAIT 3
           ;
      UPDATE T_CREDIT_DISCOUNT_AMOUNT
         SET SALES_CENTER_ID   = VC_CRE_DIS_AMOUNT.SALES_CENTER_ID,
             SALES_CENTER_CODE = VC_CRE_DIS_AMOUNT.SALES_CENTER_CODE,
             SALES_CENTER_NAME = VC_CRE_DIS_AMOUNT.SALES_CENTER_NAME,
             --CUSTOMER_ID, CUSTOMER_CODE,
             CUSTOMER_NAME    = VC_CRE_DIS_AMOUNT.CUSTOMER_NAME,
             LAST_UPDATE_DATE = SYSDATE,
             LAST_UPDATED_BY  = NVL(IS_USER_NAME,'SYS'),
             RECEIPT_AMOUNT   = RECEIPT_AMOUNT + NVL(IN_RECEIPT_AMOUNT, 0),
             SALES_AMOUNT     = SALES_AMOUNT + NVL(IN_SALES_AMOUNT, 0),
             LOCK_AMOUNT      = LOCK_AMOUNT + NVL(IN_LOCK_AMOUNT, 0),
             RECEIVED_AMOUNT  = RECEIVED_AMOUNT + NVL(IN_CASH_AMOUNT,0)
       WHERE DISCOUNT_AMOUNT_ID = VC_CRE_DIS_AMOUNT.DISCOUNT_AMOUNT_ID;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      ON_RESULT := 1;
      --记录出错信息
      OS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_DIS.P_UPDATE_DISCOUNT_AMOUNT',
                                           SQLCODE,
                                           '折扣类型款项更新处理出错！：' || SQLERRM);
  END P_UPDATE_DISCOUNT_AMOUNT;

  /**
  * 折扣类型余款更新 入口
  **/
  PROCEDURE P_UPDATE_DIS_AMOUNT(IN_ACTION_TYPE     IN NUMBER, --操作类型 非信用控制(销售)写负1，其他（订单、返利）与信用控制动作标识一致 PKG_CREDIT_ACCOUNT_CONTROL PRC_CREDIT_VERIFICATION
                                IS_ACTION_DESC     IN VARCHAR2, --操作描述 比如销售单新增 销售单更新
                                IN_ENTITY_ID       IN NUMBER, --主体ID
                                IN_ACCOUNT_ID      IN NUMBER, --客户账户ID
                                IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                IS_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 订单、销售单头上的折扣金额
                                IN_RECEIPT_AMOUNT  IN NUMBER, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                                IN_SALES_AMOUNT    IN NUMBER, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                                IN_LOCK_AMOUNT     IN NUMBER, --金额 只有锁款、解锁传入结算金额，其他传入0
                                IN_CASH_AMOUNT     IN NUMBER,--收款单据到款金额
                                IS_SOURCE_TYPE     IN VARCHAR2, --来源类型 取码表SO_SRC_TYPE
                                IN_SOURCE_BILL_ID  IN VARCHAR2, --来源单据ID
                                IS_USER_NAME       IN VARCHAR2, --操作人
                                ON_RESULT          OUT NUMBER, --成功则返回0，否则返回对应的出错代码
                                OS_MESSAGE         OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息
                                ) IS
    VN_CREDIT_GROUP_ID NUMBER;
  BEGIN
    --控制事务保存点
    SAVEPOINT SAVEPOINT_CREDIT_DIS;
    P_UPDATE_DISCOUNT_AMOUNT(IN_ENTITY_ID,
                             IN_ACCOUNT_ID,
                             IS_SALES_MAIN_TYPE,
                             IS_DISCOUNT_TYPE,
                             IN_RECEIPT_AMOUNT,
                             IN_SALES_AMOUNT,
                             IN_LOCK_AMOUNT,
                             IN_CASH_AMOUNT,
                             IS_USER_NAME,
                             ON_RESULT,
                             OS_MESSAGE);
    IF 0 <> ON_RESULT AND 'DUP_VAL_ON_INDEX' = OS_MESSAGE THEN
      --捕获违反唯一约束重新调用
      --回滚
      ROLLBACK TO SAVEPOINT_CREDIT_DIS;
      P_UPDATE_DISCOUNT_AMOUNT(IN_ENTITY_ID,
                               IN_ACCOUNT_ID,
                               IS_SALES_MAIN_TYPE,
                               IS_DISCOUNT_TYPE,
                               IN_RECEIPT_AMOUNT,
                               IN_SALES_AMOUNT,
                               IN_LOCK_AMOUNT,
                               IN_CASH_AMOUNT,
                               IS_USER_NAME,
                               ON_RESULT,
                               OS_MESSAGE);
    END IF;
    IF 0 = ON_RESULT AND
       NOT (IS_DISCOUNT_TYPE IS NULL OR 'COMMON' = IS_DISCOUNT_TYPE) THEN
      BEGIN
        SELECT PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(A.ENTITY_ID,
                                                      A.CUSTOMER_ID,
                                                      IS_SALES_MAIN_TYPE,
                                                      A.ACCOUNT_ID)
          INTO VN_CREDIT_GROUP_ID
          FROM T_CUSTOMER_ACCOUNT A
         WHERE A.ENTITY_ID = IN_ENTITY_ID
           AND A.ACCOUNT_ID = IN_ACCOUNT_ID;
        P_ADD_DIS_AMOUNT_HIS(IN_ACTION_TYPE,
                             IS_ACTION_DESC, --操作描述 比如销售单新增 销售单更新
                             IN_ENTITY_ID, --主体ID
                             IN_ACCOUNT_ID, --客户账户ID
                             VN_CREDIT_GROUP_ID, --额度组ID
                             IS_SALES_MAIN_TYPE, --营销大类
                             IS_DISCOUNT_TYPE, --折扣类型 订单、销售单头上的折扣金额
                             IN_RECEIPT_AMOUNT, --非“常规到款”到款金额 只有销售折让、折让证明取结算金额，其他传入0
                             
                             IN_SALES_AMOUNT, --销售金额 只有非销售折让、非折让证明取结算金额，其他传入0
                             IN_LOCK_AMOUNT, --金额 只有锁款、解锁传入结算金额，其他传入0
                             IN_CASH_AMOUNT,--
                             IS_SOURCE_TYPE, --来源类型 取码表SO_SRC_TYPE
                             IN_SOURCE_BILL_ID, --来源单据ID
                             IS_USER_NAME --操作人
                             );
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK TO SAVEPOINT_CREDIT_DIS;
          ON_RESULT := 1;
          --记录出错信息
          OS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_DIS.P_UPDATE_DIS_AMOUNT',
                                               SQLCODE,
                                               '折扣类型款项更新历史添加出错！：' || SQLERRM);
      END;
    ELSIF 0 <> ON_RESULT THEN
      ROLLBACK TO SAVEPOINT_CREDIT_DIS;
      RAISE V_BIZ_EXCEPTION;
    END IF;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      ON_RESULT  := -1;
      OS_MESSAGE := 'PKG_CREDIT_DIS.P_UPDATE_DIS_AMOUNT更新不成功[' || IN_ACTION_TYPE || ',' || IS_ACTION_DESC
                     || ',' || IN_ENTITY_ID || ',' ||  IN_ACCOUNT_ID || ',' || IS_SALES_MAIN_TYPE
                      || ',' || IN_RECEIPT_AMOUNT || ',' || IN_SALES_AMOUNT || ',' || IN_LOCK_AMOUNT || ',' || IN_CASH_AMOUNT
                      || ',' || IS_DISCOUNT_TYPE || ',' || IS_SOURCE_TYPE || ',' || IN_SOURCE_BILL_ID || ',' || IS_USER_NAME || ']' || OS_MESSAGE;
    WHEN OTHERS THEN
      ON_RESULT := 1;
      --记录出错信息
      OS_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_CREDIT_DIS.P_UPDATE_DIS_AMOUNT',
                                           SQLCODE,
                                           '折扣类型款项更新异常！：' || SQLERRM);
  END P_UPDATE_DIS_AMOUNT;

  /*
  *折扣类型款项冻结
  */
  PROCEDURE P_DIS_AMOUNT_FREEZE(IN_ENTITY_ID       IN NUMBER,
                                IS_CRE_DIS_TYPE_EN IN VARCHAR2 DEFAULT NULL,
    IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
    IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
    IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
    IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
    IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
    IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
                                --,OS_MESSAGE         OUT VARCHAR2 --成功返回“SUCCESS”；失败返回出错信息
                                ) IS
    VD_FREEZE_DATE               DATE;
    VN_RESULT                    NUMBER;
    VV_MSG                       VARCHAR2(4000);
    VV_ERR_MSG                   VARCHAR2(4000);
    VT_CRE_DIS_AMOUNT            T_CREDIT_DISCOUNT_AMOUNT%ROWTYPE; --折让款项记录
    VN_SHIP_LOCK_AMOUNT_TRANSFER NUMBER; --直发代理商发货计划锁款
    VN_DOC_LOCK_AMOUNT_TRANSFER  NUMBER; --直发代理商发货通知单锁款
    VN_SHIP_LOCK_AMOUNT          NUMBER; --常规发货计划锁款
    VN_DOC_LOCK_AMOUNT           NUMBER; --常规发货通知单锁款
    VN_PLN_LOCK_AMOUNT           NUMBER; --送审锁款方式已经送审未生成发货计划的锁款，全款部分
    VN_PLN_DP_LOCK_AMOUNT        NUMBER; --送审锁款方式已经送审未生成发货计划的锁款，订金部分
    VN_PLN_PS_LOCK_AMOUNT           NUMBER; --针对已结转总部主体且发货锁款的提货订单，全款部分
    VN_PLN_PS_DP_LOCK_AMOUNT        NUMBER; --针对已结转总部主体且发货锁款的提货订单，订金部分
    
    VN_PLN_LOCK_AMOUNT_HQ        NUMBER; --送总部评审锁款，全款
    VN_PLN_DP_LOCK_AMOUNT_HQ     NUMBER; --送总部评审锁款，订金
    
    VN_LOCK_AMOUNT               NUMBER;
    VN_REC_LOCK_AMOUNT           NUMBER;
    CURSOR CUR_SO_DIS(P_ENTITY_ID   NUMBER,
                      P_CUSTOMER_ID NUMBER,
                      P_ACCOUNT_ID  NUMBER,
                      P_SALES_MAIN_TYPE VARCHAR2,
                      P_DISCOUNT_TYPE VARCHAR2) IS
      SELECT t.entity_id,
             t.customer_id,
             t.account_id,
             t.sales_main_type,
             2 as amount_type,
             T.discount_type,
             sum(NVL(t.settle_amount,0)) as settle_amount
             ,0 AS LOCK_RECEIVED_AMOUNT
             /*,SUM((CASE WHEN T.FUND_CTRL_MODE = 'Y' AND T.writeoff_receipt_flag = 'Y' THEN
             NVL(T.SETTLE_AMOUNT,0) WHEN T.FUND_CTRL_MODE = 'Y' AND T.writeoff_receipt_flag = 'N' THEN
             NVL(T.SETTLE_AMOUNT,0)-NVL(T.SOLUTION_PAY_AMOUNT,0) ELSE 0 END)) AS LOCK_RECEIVED_AMOUNT*/
      FROM V_CREDIT_CONTACT_AMOUNT_AR T
      WHERE t.entity_id = P_ENTITY_ID
         and t.customer_id = P_CUSTOMER_ID
         and t.account_id = P_ACCOUNT_ID
         and t.sales_main_type = P_SALES_MAIN_TYPE
         and t.discount_type <> 'COMMON'
         AND T.discount_type = P_DISCOUNT_TYPE
         and 'Y' = t.settle_flag
       group by t.entity_id,
                t.customer_id,
                t.account_id,
                t.sales_main_type,
                t.discount_type
      UNION ALL
      select t.entity_id,
             t.customer_id,
             t.account_id,
             t.sales_main_type,
             (case
               when t.src_type_code in ('1005', '1006', '1007', '1008') then
                0
               when t.src_type_code not in ('1009', '1010') then
                1
               else
                null
             end) as amount_type,
             T.discount_type,
             sum(t.settle_amount) as settle_amount
             ,0 AS LOCK_RECEIVED_AMOUNT
        from V_CREDIT_CONTACT_AMOUNT_SO t
       where t.entity_id = P_ENTITY_ID
         and t.customer_id = P_CUSTOMER_ID
         and t.account_id = P_ACCOUNT_ID
         and t.sales_main_type = P_SALES_MAIN_TYPE
         and t.discount_type <> 'COMMON'
         AND T.discount_type = P_DISCOUNT_TYPE
         and 'Y' = t.settle_flag
         and t.SRC_TYPE_CODE not in ('1009', '1010')
       group by t.entity_id,
                t.customer_id,
                t.account_id,
                t.sales_main_type,
                (case
                  when t.src_type_code in ('1005', '1006', '1007', '1008') then
                   0
                  when t.src_type_code not in ('1009', '1010') then
                   1
                  else
                   null
                end),
                t.discount_type;
    V_CUR_SO_DIS CUR_SO_DIS%ROWTYPE;
    --VCT_DIS_LOCK_RECEIVED_AMOUNT V_CUR_SO_DIS.settle_amount%TYPE;
    VCT_DIS_RECEIPT_AMOUNT V_CUR_SO_DIS.settle_amount%TYPE;--折让到款 上账金额
    VCT_DIS_SALES_AMOUNT V_CUR_SO_DIS.settle_amount%TYPE;--折让到款 销售金额
    VCT_DIS_RECEIVED_AMOUNT V_CUR_SO_DIS.settle_amount%TYPE;--折让到款  到款金额
    
    V_CRUENT_TIME NUMBER;
    V_PARAM_EXIT_TIME NUMBER;
  BEGIN
    
    V_PARAM_EXIT_TIME := PKG_BD.F_GET_PARAMETER_VALUE('CREDIT_PARAM_EXIT_TIME', IN_ENTITY_ID, NULL, NULL);
    --
   -- SAVEPOINT SP_CRE_DIS_AMOUNT_F;
    FOR EL IN (SELECT T.ENTITY_ID,T.CUSTOMER_ID,T.ACCOUNT_ID,T.ACCOUNT_CODE
      ,S.SALES_MAIN_TYPE_CODE,UC.CODE_VALUE AS DISCOUNT_TYPE
                 FROM T_CUSTOMER_ACCOUNT T
                 INNER JOIN T_CUSTOMER_SALES_MAIN_TYPE S
                 ON (S.ENTITY_ID = T.ENTITY_ID AND S.CUSTOM_ID = T.CUSTOMER_ID)
                 INNER JOIN UP_CODELIST UC
                 ON (UC.CODETYPE = 'DISCOUNT_TYPE' AND UC.CODE_VALUE <> 'COMMON')
                 INNER JOIN T_CUSTOMER_ACC_ORG_RELATION AR
                 ON (AR.ACCOUNT_ID = T.ACCOUNT_ID)
                 INNER JOIN T_CUSTOMER_ORG CO
                 ON (CO.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID AND CO.ENTITY_ID = T.ENTITY_ID)
                WHERE T.ENTITY_ID = IN_ENTITY_ID
                AND (IN_CUSTOMER_ID IS NULL OR IN_CUSTOMER_ID = T.CUSTOMER_ID)
                AND (IN_ACCOUNT_ID IS NULL OR IN_ACCOUNT_ID = T.ACCOUNT_ID)
                  AND 'Y' =
                      PKG_BD.F_GET_PARAM_VALUE_ENTITY_PRIOR('CRE_DIS_TYPE_ENABLE',
                                                            T.ENTITY_ID,
                                                            T.CUSTOMER_ID,
                                                            CO.SALES_CENTER_ID)) LOOP
      
            VT_CRE_DIS_AMOUNT.DISCOUNT_AMOUNT_ID := 0;
            VT_CRE_DIS_AMOUNT.RECEIPT_AMOUNT := 0;
            VT_CRE_DIS_AMOUNT.SALES_AMOUNT := 0;
            VT_CRE_DIS_AMOUNT.RECEIVED_AMOUNT := 0;
            VT_CRE_DIS_AMOUNT.LOCK_AMOUNT := 0;
      BEGIN   
          SELECT TO_NUMBER(TO_CHAR(SYSDATE, 'HH24')) INTO V_CRUENT_TIME FROM DUAL;
          IF IN_ACCOUNT_ID IS NULL AND IN_CUSTOMER_ID IS NULL AND V_CRUENT_TIME>=V_PARAM_EXIT_TIME THEN
             EXIT;
          END IF;
      
         
          BEGIN
              SELECT *
                into VT_CRE_DIS_AMOUNT
                FROM T_CREDIT_DISCOUNT_AMOUNT DA
               WHERE DA.entity_id = el.entity_id
                 and DA.customer_id = el.customer_id
                 and DA.account_id = el.account_id
                 and da.sales_main_type = EL.SALES_MAIN_TYPE_CODE
                 and da.discount_type = EL.discount_type
                 FOR UPDATE;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                NULL;/*VT_CRE_DIS_AMOUNT.DISCOUNT_AMOUNT_ID := 0;
                VT_CRE_DIS_AMOUNT.RECEIPT_AMOUNT := 0;
                VT_CRE_DIS_AMOUNT.SALES_AMOUNT := 0;
                VT_CRE_DIS_AMOUNT.RECEIVED_AMOUNT := 0;
                VT_CRE_DIS_AMOUNT.LOCK_AMOUNT := 0;*/
              WHEN TOO_MANY_ROWS THEN
                /*VT_CRE_DIS_AMOUNT.RECEIPT_AMOUNT := 0;
                VT_CRE_DIS_AMOUNT.SALES_AMOUNT := 0;
                VT_CRE_DIS_AMOUNT.RECEIVED_AMOUNT := 0;
                VT_CRE_DIS_AMOUNT.LOCK_AMOUNT := 0;*/
                VV_ERR_MSG := '折扣类型款项冻结重算异常：[' || EL.ENTITY_ID || ',' ||
                              EL.CUSTOMER_ID || ',' || EL.account_id || ',' ||
                              EL.SALES_MAIN_TYPE_CODE || ',' || EL.discount_type || ']';
                VV_ERR_MSG := VV_ERR_MSG || SQLERRM;
                VV_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('P_DIS_AMOUNT_FREEZE',
                                                     SQLCODE,
                                                     SUBSTR(VV_ERR_MSG, 1, 240));
              WHEN OTHERS THEN
                NULL;/*VT_CRE_DIS_AMOUNT.RECEIPT_AMOUNT := 0;
                VT_CRE_DIS_AMOUNT.SALES_AMOUNT := 0;
                VT_CRE_DIS_AMOUNT.RECEIVED_AMOUNT := 0;
                VT_CRE_DIS_AMOUNT.LOCK_AMOUNT := 0;*/
            END;
            
          
          VCT_DIS_RECEIPT_AMOUNT := 0;
          VCT_DIS_SALES_AMOUNT := 0;
          VCT_DIS_RECEIVED_AMOUNT := 0;
          FOR CL IN CUR_SO_DIS(EL.ENTITY_ID, EL.CUSTOMER_ID, EL.ACCOUNT_ID
            ,EL.SALES_MAIN_TYPE_CODE,EL.DISCOUNT_TYPE) LOOP
            IF 0 = CL.AMOUNT_TYPE THEN
              VCT_DIS_RECEIPT_AMOUNT := (-CL.SETTLE_AMOUNT + VCT_DIS_RECEIPT_AMOUNT);
            ELSIF 1 = CL.AMOUNT_TYPE THEN
              VCT_DIS_SALES_AMOUNT := (CL.SETTLE_AMOUNT + VCT_DIS_SALES_AMOUNT);
            ELSIF 2 = CL.AMOUNT_TYPE THEN
              VCT_DIS_RECEIVED_AMOUNT := (CL.SETTLE_AMOUNT + VCT_DIS_RECEIVED_AMOUNT);
            END IF;
          END LOOP;
          
          --IF VT_CRE_DIS_AMOUNT.DISCOUNT_AMOUNT_ID IS NOT NULL THEN
              IF VCT_DIS_RECEIPT_AMOUNT <> NVL(VT_CRE_DIS_AMOUNT.RECEIPT_AMOUNT, 0) THEN
                P_UPDATE_DIS_AMOUNT(0,
                                    '重算',
                                    EL.ENTITY_ID,
                                    EL.ACCOUNT_ID,
                                    EL.SALES_MAIN_TYPE_CODE,
                                    EL.DISCOUNT_TYPE,
                                    VCT_DIS_RECEIPT_AMOUNT -
                                    NVL(VT_CRE_DIS_AMOUNT.RECEIPT_AMOUNT, 0),
                                    0,
                                    0,
                                    0,
                                    '0',
                                    '0',
                                    NVL(IS_USER_CODE,'上账金额'),
                                    VN_RESULT,
                                    VV_MSG);
              END IF;
            
              IF VCT_DIS_SALES_AMOUNT <> NVL(VT_CRE_DIS_AMOUNT.SALES_AMOUNT, 0) THEN
                P_UPDATE_DIS_AMOUNT(0,
                                    '重算',
                                    EL.ENTITY_ID,
                                    EL.ACCOUNT_ID,
                                    EL.SALES_MAIN_TYPE_CODE,
                                    EL.DISCOUNT_TYPE,
                                    0,
                                    VCT_DIS_SALES_AMOUNT -
                                    NVL(VT_CRE_DIS_AMOUNT.SALES_AMOUNT, 0),
                                    0,
                                    0,
                                    '0',
                                    '0',
                                    NVL(IS_USER_CODE,'销售金额'),
                                    VN_RESULT,
                                    VV_MSG);
              END IF;
            
              IF VCT_DIS_RECEIVED_AMOUNT <> NVL(VT_CRE_DIS_AMOUNT.RECEIVED_AMOUNT, 0) THEN
                P_UPDATE_DIS_AMOUNT(0,
                                    '重算',
                                    EL.ENTITY_ID,
                                    EL.ACCOUNT_ID,
                                    EL.SALES_MAIN_TYPE_CODE,
                                    EL.DISCOUNT_TYPE,
                                    0,
                                    0,
                                    0,
                                    VCT_DIS_RECEIVED_AMOUNT -
                                    NVL(VT_CRE_DIS_AMOUNT.RECEIVED_AMOUNT, 0),
                                    '0',
                                    '0',
                                    NVL(IS_USER_CODE,'到款金额'),
                                    VN_RESULT,
                                    VV_MSG);
              END IF;
            --END IF;
            
          FOR DL IN (SELECT DA.* FROM T_CREDIT_DISCOUNT_AMOUNT DA
                      WHERE/* DA.ENTITY_ID = EL.ENTITY_ID
                        AND DA.CUSTOMER_ID = EL.CUSTOMER_ID AND*/
                        DA.ACCOUNT_ID = EL.ACCOUNT_ID
                        AND DA.SALES_MAIN_TYPE = EL.SALES_MAIN_TYPE_CODE
                        AND DA.DISCOUNT_TYPE = EL.DISCOUNT_TYPE) LOOP
            --三方承兑未解付金额
            SELECT SUM(NVL((CASE WHEN T.FUND_CTRL_MODE = 'Y' AND T.writeoff_receipt_flag = 'Y' THEN
                 NVL(T.SETTLE_AMOUNT,0) WHEN T.FUND_CTRL_MODE = 'Y' AND T.writeoff_receipt_flag = 'N' THEN
                 NVL(T.SETTLE_AMOUNT,0)-NVL(T.SOLUTION_PAY_AMOUNT,0) ELSE 0 END),0))
              INTO VN_LOCK_AMOUNT
              FROM V_CREDIT_CONTACT_AMOUNT_AR T
             WHERE T.ENTITY_ID = DL.ENTITY_ID
               AND T.CUSTOMER_ID = DL.CUSTOMER_ID
               AND T.ACCOUNT_ID = DL.ACCOUNT_ID
               AND T.SALES_MAIN_TYPE = DL.SALES_MAIN_TYPE
               AND T.DISCOUNT_TYPE = DL.DISCOUNT_TYPE
               AND 'Y' = T.SETTLE_FLAG
               AND T.FUND_CTRL_MODE = 'Y'
               ;
            
            --制定发货需求计划下达（直发客户）未生成发货通知单
            SELECT SUM(NVL(ROUND(
                                 --锁定代理商到款(未确认数量*直发列表价*(100-直发扣率-直发月返)/100)
                                 NVL(TP.UNAFFIRM_QTY, 0) *
                                 NVL(TP.TRANSFER_LIST_PRICE, 0) *
                                 (100 - NVL(TP.TRANSFER_DISCOUNT_RATE, 0) -
                                  NVL(TP.TRANSFER_MONTH_DISCOUNT_RATE, 0)) / 100,
                                 2),
                           0))
              INTO VN_SHIP_LOCK_AMOUNT_TRANSFER
              FROM T_LG_SHIP_PLAN TP
             WHERE TP.TRANSFER_ENTITY_ID = DL.ENTITY_ID
               AND TP.TRANSFER_CUSTOMER_ID = DL.CUSTOMER_ID
               AND TP.TRANSFER_ACCOUNT_ID = DL.ACCOUNT_ID
               AND TP.TRANSFER_ITEM_MAIN_TYPE = DL.SALES_MAIN_TYPE
               AND TP.TRANSFER_DISCOUNT_TYPE = DL.DISCOUNT_TYPE
               AND TP.STATUS <> '03' --撤销单据没有锁款
               AND TP.STATUS <> '02'
                  --已确认，确认则生成发货通知单。部分确认的话，则拆单，生成两个发运计划
               AND TP.TRANSFER_LOCK_AMOUNT_FLAG = 'Y';
          
            --制定发货需求计划下达（直发客户） 发货通知单未生成销售单
            SELECT SUM(NVL(ROUND( --锁定代理商到款((产品数量-已取消数量-已转采购数量)*直发列表价*(100-直发扣率-直发月返)/100)
                                 (NVL(B.ITEM_QTY, 0) - NVL(B.CANCEL_QTY, 0) -
                                 NVL(B.TRANSFER_TO_POX_QTY, 0)) *
                                 NVL(b.TRANSFER_LIST_PRICE, 0) *
                                 (100 - NVL(b.TRANSFER_DISCOUNT_RATE, 0) -
                                 NVL(b.TRANSFER_MONTH_DISCOUNT_RATE, 0)) / 100,
                                 2),
                           0))
              INTO VN_DOC_LOCK_AMOUNT_TRANSFER
              FROM t_lg_ship_doc      a, --发货通知单头
                   t_lg_ship_doc_line b --发货通知单行
            --单据源类型
             WHERE a.ship_doc_id = b.ship_doc_id
               AND A.TRANSFER_ENTITY_ID = DL.ENTITY_ID
               AND A.TRANSFER_CUSTOMER_ID = DL.CUSTOMER_ID
               AND A.TRANSFER_ACCOUNT_ID = DL.ACCOUNT_ID
               AND B.TRANSFER_ITEM_MAIN_TYPE = DL.SALES_MAIN_TYPE
               AND B.TRANSFER_DISCOUNT_TYPE = DL.DISCOUNT_TYPE
               AND A.DOC_STATUS <> '01' --单据状态 00正常 01红冲
               AND B.TRANSFER_LOCK_AMOUNT_FLAG = 'Y';
          
            --优化后 ： 2、已下达发运计划但未生成发货通知锁款
            SELECT SUM(NVL(ROUND(CASE
                                   --20200314 家用直发锁款调整
                                   when tp.origin_type = '01' and nvl(tp.direct_transport_falg, 'N') = 'Y' and 
                                     (select nvl(h.amount_lock_flag, 'N')
                                        from t_pln_order_head h
                                       where h.order_head_id = tp.origin_order_id) = 'NT'
                                     then
                                       0
                                   WHEN tP.lock_amount_flag IN ('S', 'Y', 'HQ') THEN
                                   --未确认数量*单价*(100-折扣-月返)/100
                                    NVL(tP.unaffirm_qty, 0) * NVL(tP.item_price, 0) *
                                    (100 - NVL(tP.discount_rate, 0) -
                                     NVL(tP.month_discount_rate, 0)) / 100
                                   ELSE
                                    0
                                 END,
                                 2),
                           0))
              INTO VN_SHIP_LOCK_AMOUNT
              FROM t_lg_ship_plan tp
             WHERE TP.ENTITY_ID = DL.ENTITY_ID
               AND TP.CUSTOMER_ID = DL.CUSTOMER_ID
               AND TP.ACCOUNT_CODE = EL.ACCOUNT_CODE
               AND TP.SALES_MAIN_TYPE = DL.SALES_MAIN_TYPE
               AND TP.DISCOUNT_TYPE = DL.DISCOUNT_TYPE
               AND tp.status <> '03' --撤销单据没有锁款
               AND tp.status <> '02'
                  --已确认，确认则生成发货通知单。部分确认的话，则拆单，生成两个发运计划
               AND tp.lock_amount_flag IN ('S', 'Y', 'RS', 'RT', 'HQ');
          
            --3、已生成发货通知未生成销售单锁款
            SELECT SUM(NVL(ROUND(CASE
                                   --20200314 家用直发锁款调整
                                   when b.origin_type = '01' and nvl(a.direct_transport_falg, 'N') = 'Y' and 
                                     (select nvl(h.amount_lock_flag, 'N')
                                        from t_pln_order_head h
                                       where h.order_head_id = b.origin_order_id) = 'NT'
                                     then
                                       0
                                   WHEN b.lock_amount_flag IN ('S', 'Y', 'HQ') THEN
                                   --(ITEM_QTY产品数量 - FACT_SHIP_QTY实际发货数量 - CANCEL_QTY累积取消数量)*单价*(100-折扣-月返)/100
                                    (NVL(b.item_qty, 0) - NVL(b.fact_ship_qty, 0) -
                                    NVL(b.cancel_qty, 0)) * NVL(b.item_price, 0) *
                                    (100 - NVL(b.discount_rate, 0) -
                                    NVL(b.month_discount_rate, 0)) / 100
                                   ELSE
                                    0
                                 END,
                                 2),
                           0))
              INTO VN_DOC_LOCK_AMOUNT
              FROM t_lg_ship_doc      a, --发货通知单头
                   t_lg_ship_doc_line b --发货通知单行
            --,t_inv_bill_types   bill_type, --业务单据类型
            --t_inv_source_types source_type
            --单据源类型
             WHERE a.ship_doc_id = b.ship_doc_id
               AND A.ENTITY_ID = DL.ENTITY_ID
               AND A.CUSTOMER_ID = DL.CUSTOMER_ID
               AND A.ACCOUNT_CODE = EL.ACCOUNT_CODE
               AND B.SALES_MAIN_TYPE = DL.SALES_MAIN_TYPE
               AND B.DISCOUNT_TYPE = DL.DISCOUNT_TYPE
               AND a.doc_status <> '01' --单据状态 00正常 01红冲
                  --AND b.sales_order_type_id = bill_type.bill_type_id(+)
                  --AND bill_type.source_type_id = source_type.source_type_id
               AND b.lock_amount_flag IN ('S', 'Y', 'RS', 'RT', 'HQ');
          
            --1、送审锁款：已经送审未下达发运计划的锁款
            --1.1、提货订单
            --1.1、提货订单--新2
            SELECT SUM(NVL(ROUND(CASE
                                   WHEN nvl(l.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED 
                                     and nvl(l.is_lock_amount, 'N') <> 'NT' THEN
                                     0
                                   --20200314 家用直发锁款调整
                                   WHEN (H.lock_amount_flag = 'S' AND
                                        NOT (NVL(H.DOWN_PAY_SCALE, -1) >= 0)) or NVL(L.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                    (CASE
                                      when nvl(l.is_lock_amount, 'N') = 'NT' then
                                        NVL(L.center_affirm_quantity, 0) - NVL(L.cancel_qty, 0)
                                    --2016-09-13 tianmzh修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                      WHEN H.order_head_state IN ('20', '1455', '2225') and nvl(l.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                      --ADD YBY LIANGYM2 2017-6-18 已送审状态下销司主体结转到总部主体 Center_Affirm_Quantity可能发生变化
                                       NVL(decode(h.hq_lg_order_head_id,null,l.quantity,NVL(L.center_affirm_quantity, L.quantity)), 0) -
                                       NVL(L.affirmed_quantity, 0) - NVL(L.cancel_qty, 0)
                                       -(nvl(l.transfer_hq_affirmed_qty,0)-nvl(l.sended_qty,0))
                                       -(nvl(l.direct_transport_qty,0)-nvl(l.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                      WHEN H.order_head_state IN ('381', '679') and nvl(l.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                       NVL(L.center_affirm_quantity, 0) - NVL(L.affirmed_quantity, 0) - NVL(L.cancel_qty, 0)
                                       -(nvl(l.transfer_hq_affirmed_qty,0)-nvl(l.sended_qty,0))
                                       -(nvl(l.direct_transport_qty,0)-nvl(l.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                      ELSE
                                       0
                                    END)
                                   ELSE
                                    0
                                 END
                                 * DECODE(L.project_order_type,
                                                  NULL,
                                                  NVL(L.list_price, 0),
                                                  NVL(L.apply_list_price, 0))
                                   --add by lizhen 2015-11-30 增加月返计算
                                    * (100 - DECODE(L.project_order_type,
                                                    NULL,
                                                    NVL(L.discount_rate, 0),
                                                    NVL(L.apply_discount_rate, 0)) -
                                    NVL(L.ordered_discount_rate, 0)) / 100,
                                 2),
                           0)),
                   SUM((H.DOWN_PAY_SCALE / 100) *
                       NVL(ROUND(CASE
                                   --20200314 家用直发锁款调整
                                   WHEN (nvl(l.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED and nvl(l.is_lock_amount, 'N') <> 'NT')
                                     or NVL(L.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                     0
                                   WHEN H.lock_amount_flag = 'S' AND H.DOWN_PAY_SCALE > 0 THEN
                                    (CASE
                                      WHEN NVL(L.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                        NVL(L.center_affirm_quantity, 0) - NVL(L.cancel_qty, 0)
                                    --2016-09-13 tianmzh修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                      WHEN H.order_head_state IN ('20', '1455', '2225') and nvl(l.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                      --ADD YBY LIANGYM2 2017-6-18 已送审状态下销司主体结转到总部主体 Center_Affirm_Quantity可能发生变化
                                       NVL(decode(h.hq_lg_order_head_id,null,l.quantity,NVL(L.center_affirm_quantity, L.quantity)), 0) -
                                       NVL(L.affirmed_quantity, 0) - NVL(L.cancel_qty, 0) - (NVL(l.transfer_hq_affirmed_qty,0)-NVL(l.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                       -(nvl(l.transfer_hq_affirmed_qty,0)-nvl(l.sended_qty,0))
                                       -(nvl(l.direct_transport_qty,0)-nvl(l.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                      WHEN H.order_head_state IN ('381', '679') and nvl(l.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                       NVL(L.center_affirm_quantity, 0) - NVL(L.affirmed_quantity, 0) - NVL(L.cancel_qty, 0)
                                       -(nvl(l.transfer_hq_affirmed_qty,0)-nvl(l.sended_qty,0))
                                       -(nvl(l.direct_transport_qty,0)-nvl(l.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                      ELSE
                                       0
                                    END) * DECODE(L.project_order_type,
                                                  NULL,
                                                  NVL(L.list_price, 0),
                                                  NVL(L.apply_list_price, 0))
                                   --add by lizhen 2015-11-30 增加月返计算
                                    * (100 - DECODE(L.project_order_type,
                                                    NULL,
                                                    NVL(L.discount_rate, 0),
                                                    NVL(L.apply_discount_rate, 0)) -
                                    NVL(L.ordered_discount_rate, 0)) / 100
                                   ELSE
                                    0
                                 END,
                                 2),
                           0))
              INTO VN_PLN_LOCK_AMOUNT, VN_PLN_DP_LOCK_AMOUNT
              FROM t_pln_lg_order_head h --物流订单头表
             INNER JOIN t_pln_lg_order_line l --物流订单行表
                ON (H.ORDER_HEAD_ID = L.ORDER_HEAD_ID AND
                   --NVL(l.order_line_state, 'NORMAL') <> 'CLOSED' AND
                   L.DISCOUNT_TYPE = DL.DISCOUNT_TYPE)
             WHERE H.ENTITY_ID = DL.ENTITY_ID
               AND H.CUSTOMER_ID = DL.CUSTOMER_ID
               AND H.ACCOUNT_ID = DL.ACCOUNT_ID
               AND h.order_head_state IN
                  --2016-09-13 tianmzh修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                   ('20', '23', '381', '679', '1455', '2225', '304')
               AND h.lock_amount_flag IN ('S', 'RS')
               and L.sales_main_type = dl.sales_main_type
            --and h.order_head_state IS NOT NULL
            --AND H.lock_amount_flag IS NOT NULL
            ;
            
            --hejy3 送总部锁款方式
            SELECT SUM(NVL(ROUND(CASE
                                   WHEN nvl(l.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED 
                                     AND NVL(L.IS_LOCK_AMOUNT, 'N') <> 'NT' THEN
                                     0
                                   --20200314 家用直发锁款调整
                                   WHEN NVL(H.DOWN_PAY_SCALE, -1) < 0 OR NVL(L.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                    (CASE
                                      when nvl(l.is_lock_amount, 'N') = 'NT' then
                                        NVL(L.center_affirm_quantity, 0) - NVL(L.cancel_qty, 0)
                                    --2016-09-13 tianmzh修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                      WHEN (H.order_head_state IN ('20', '1455', '2225') and ha.Submit_To_Hq_Flag = 'Y')
                                        or h.Submit_To_Hq_Flag = 'Y' THEN
                                        greatest(NVL(l.CENTER_AFFIRM_QUANTITY,0)-nvl(l.AFFIRMED_QUANTITY,0)-Nvl(l.Cancel_Qty,0)
                                           -(nvl(l.transfer_hq_affirmed_qty,0)-nvl(l.sended_qty,0))
                                           -(nvl(l.direct_transport_qty,0)-nvl(l.already_direct_transport_qty,0)),0)
                                      ELSE
                                       0
                                    END)
                                   ELSE
                                    0
                                 END
                                 * DECODE(L.project_order_type,
                                                  NULL,
                                                  NVL(L.list_price, 0),
                                                  NVL(L.apply_list_price, 0))
                                   --add by lizhen 2015-11-30 增加月返计算
                                    * (100 - DECODE(L.project_order_type,
                                                    NULL,
                                                    NVL(L.discount_rate, 0),
                                                    NVL(L.apply_discount_rate, 0)) -
                                    NVL(L.ordered_discount_rate, 0)) / 100,
                                 2),
                           0)),
                   SUM((H.DOWN_PAY_SCALE / 100) *
                       NVL(ROUND(Case
                                   --20200314 家用直发锁款调整
                                   WHEN (nvl(l.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED AND NVL(L.IS_LOCK_AMOUNT, 'N') <> 'NT')
                                     or nvl(l.is_lock_amount, 'N') = 'Y' THEN
                                     0
                                   When h.DOWN_PAY_SCALE > 0 Then
                                   --
                                    Case
                                      WHEN NVL(L.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                        NVL(L.center_affirm_quantity, 0) - NVL(L.cancel_qty, 0)
                                       When (h.order_head_state In ('20', '2225', '1455') and ha.Submit_To_Hq_Flag = 'Y')
                                         or h.Submit_To_Hq_Flag = 'Y' Then
                                         greatest(NVL(l.CENTER_AFFIRM_QUANTITY, 0)-nvl(l.AFFIRMED_QUANTITY, 0)-Nvl(l.Cancel_Qty, 0)
                                           -(NVL(l.transfer_hq_affirmed_qty,0)-NVL(l.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                           -(nvl(l.direct_transport_qty,0)-nvl(l.already_direct_transport_qty,0)),0) --20180328 hejy3 已预约直发数量在发货通知单重算
                                       Else 0
                                     End
                                     * DECODE(l.PROJECT_ORDER_TYPE,
                                              NULL,
                                              NVL(l.List_Price, 0),
                                              NVL(l.APPLY_LIST_PRICE, 0))
                                     --add by lizhen 2015-11-30 增加月返计算
                                     * (100 - DECODE(l.PROJECT_ORDER_TYPE,
                                                     NULL,
                                                     Nvl(l.Discount_Rate, 0),
                                                     NVL(l.APPLY_DISCOUNT_RATE, 0)) -
                                     Nvl(l.ordered_discount_rate, 0)) / 100
                                   Else 0
                                 End,
                                 2),
                           0))
              INTO VN_PLN_LOCK_AMOUNT_HQ, VN_PLN_DP_LOCK_AMOUNT_HQ
              FROM t_pln_lg_order_head h --物流订单头表
             INNER JOIN t_pln_lg_order_line l --物流订单行表
                ON (H.ORDER_HEAD_ID = L.ORDER_HEAD_ID AND
                   L.DISCOUNT_TYPE = DL.DISCOUNT_TYPE)
              left join t_pln_lg_order_head ha
                on h.hq_lg_order_head_id = ha.order_head_id
             WHERE H.ENTITY_ID = DL.ENTITY_ID
               AND H.CUSTOMER_ID = DL.CUSTOMER_ID
               AND H.ACCOUNT_ID = DL.ACCOUNT_ID
               AND h.order_head_state IN
                  --2016-09-13 tianmzh修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                   ('20', '23', '381', '679', '1455', '2225', '304')
               AND h.lock_amount_flag IN ('HQ')
               and L.sales_main_type = dl.sales_main_type
            ;
            
            SELECT --锁定客户到款((跨主体总部评审数量-已评审数量+申请数量-送总部评审数量-已取消数量)*价格*(100-扣率-月返)/100)
                   SUM(NVL(ROUND(CASE WHEN NVL(L.IS_LOCK_AMOUNT, 'N') <> 'NT' THEN
                                     (NVL(L.transfer_hq_affirmed_qty,0)-NVL(L.SENDED_QTY,0))
                                  * DECODE(L.project_order_type,
                                                  NULL,
                                                  NVL(L.list_price, 0),
                                                  NVL(L.apply_list_price, 0))
                                   --add by lizhen 2015-11-30 增加月返计算
                                    * (100 - DECODE(L.project_order_type,
                                                    NULL,
                                                    NVL(L.discount_rate, 0),
                                                    NVL(L.apply_discount_rate, 0)) -
                                    NVL(L.ordered_discount_rate, 0)) / 100
                                   ELSE 0 END
                                 ,2),
                           0)),
                   0
              INTO VN_PLN_PS_LOCK_AMOUNT, VN_PLN_PS_DP_LOCK_AMOUNT
              FROM t_pln_lg_order_head h --物流订单头表
             INNER JOIN t_pln_lg_order_line l --物流订单行表
                ON (H.ORDER_HEAD_ID = L.ORDER_HEAD_ID AND
                   --NVL(l.order_line_state, 'NORMAL') <> 'CLOSED' AND
                   L.DISCOUNT_TYPE = DL.DISCOUNT_TYPE)
             WHERE H.ENTITY_ID = DL.ENTITY_ID
               AND H.CUSTOMER_ID = DL.CUSTOMER_ID
               AND H.ACCOUNT_ID = DL.ACCOUNT_ID
               AND h.order_head_state IN
                   ('20', '23', '381', '679', '1455', '2225', '304')
               AND L.TRANSFER_HQ_AFFIRMED_QTY > 0
               --AND H.HQ_LG_ORDER_HEAD_ID IS NOT NULL
               --AND h.lock_amount_flag = 'Y'
               and L.sales_main_type = dl.sales_main_type
            ;
            VN_LOCK_AMOUNT := (NVL(VN_LOCK_AMOUNT,0) + NVL(VN_PLN_LOCK_AMOUNT, 0) +
                              NVL(VN_SHIP_LOCK_AMOUNT, 0) +
                              NVL(VN_DOC_LOCK_AMOUNT, 0) +
                              NVL(VN_SHIP_LOCK_AMOUNT_TRANSFER, 0) +
                              NVL(VN_DOC_LOCK_AMOUNT_TRANSFER, 0) +
                              NVL(VN_PLN_DP_LOCK_AMOUNT, 0))
                              + NVL(VN_PLN_PS_LOCK_AMOUNT,0) + NVL(VN_PLN_PS_DP_LOCK_AMOUNT,0)
                              + NVL(VN_PLN_LOCK_AMOUNT_HQ,0) + NVL(VN_PLN_DP_LOCK_AMOUNT_HQ, 0)
                              ;
            /*SELECT DL.LOCK_AMOUNT INTO VN_REC_LOCK_AMOUNT FROM DUAL;*/
            SELECT DL.LOCK_AMOUNT
              INTO VN_REC_LOCK_AMOUNT
              FROM T_CREDIT_DISCOUNT_AMOUNT
             WHERE DL.DISCOUNT_AMOUNT_ID = DISCOUNT_AMOUNT_ID;
            IF VN_LOCK_AMOUNT <> NVL(VN_REC_LOCK_AMOUNT, 0) THEN
              P_UPDATE_DIS_AMOUNT(0,
                                  '重算',
                                  EL.ENTITY_ID,
                                  EL.ACCOUNT_ID,
                                  DL.SALES_MAIN_TYPE,
                                  DL.DISCOUNT_TYPE,
                                  0,
                                  0,
                                  VN_LOCK_AMOUNT - NVL(VN_REC_LOCK_AMOUNT, 0),
                                  0,
                                  '0',
                                  '0',
                                  NVL(IS_USER_CODE,'锁定金额'),
                                  VN_RESULT,
                                  VV_MSG);
              END IF;
          END LOOP;
          COMMIT;
        EXCEPTION
          WHEN OTHERS THEN
              ROLLBACK;
              VV_ERR_MSG := '折扣类型款项冻结异常！' || SQLERRM;
              VV_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('P_DIS_AMOUNT_FREEZE_RE',
                                                   '异常，主体：' || IN_ENTITY_ID || '，客户ID=' ||el.customer_id
              || '，账户ID=' ||el.account_id||EL.SALES_MAIN_TYPE_CODE||EL.discount_type|| '，IS_USER_CODE=' ||IS_USER_CODE,
                                                    SUBSTR(VV_ERR_MSG, 1, 240));  
        END;     
    END LOOP;
  
    IF (IS_CRE_DIS_TYPE_EN IS NULL OR 'Y' = IS_CRE_DIS_TYPE_EN) AND (IS_PRE_ARG IS NULL OR IS_PRE_ARG = 'FREEZE') THEN
      VV_ERR_MSG     := PKG_BD.F_ADD_ERROR_LOG('P_DIS_AMOUNT_FREEZE',
                                               'SUCCESS',
                                               SUBSTR('折扣类型款项冻结开始，ENTITY_ID=' ||
                                                      IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
     || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE,
                                                      1,
                                                      240));
      VD_FREEZE_DATE := TRUNC(SYSDATE) - 1;
      --删除当天冻结数据 暂无冻结历史
      DELETE FROM T_CREDIT_DIS_AMOUNT_FREEZE T
       WHERE FREEZE_DATE = VD_FREEZE_DATE
         AND IN_ENTITY_ID = ENTITY_ID
                AND (IN_CUSTOMER_ID IS NULL OR IN_CUSTOMER_ID = T.CUSTOMER_ID)
                AND (IN_ACCOUNT_ID IS NULL OR IN_ACCOUNT_ID = T.ACCOUNT_ID);
      --插入当天冻结
      INSERT INTO T_CREDIT_DIS_AMOUNT_FREEZE
        (DIS_AMOUNT_FREEZE_ID,
         DISCOUNT_AMOUNT_ID,
         FREEZE_TIME,
         SALES_CENTER_ID,
         SALES_CENTER_NAME,
         SALES_CENTER_CODE,
         CUSTOMER_ID,
         CUSTOMER_NAME,
         CUSTOMER_CODE,
         ACCOUNT_ID,
         SALES_MAIN_TYPE,
         DISCOUNT_TYPE,
         RECEIPT_AMOUNT,
         SALES_AMOUNT,
         LOCK_AMOUNT,
         RECEIVED_AMOUNT,
         FREEZE_DATE,
         ENTITY_ID,
         CREDIT_GROUP_ID)
        SELECT S_CREDIT_DIS_AMOUNT_FREEZE.NEXTVAL,
               DISCOUNT_AMOUNT_ID,
               SYSDATE,
               SALES_CENTER_ID,
               SALES_CENTER_NAME,
               SALES_CENTER_CODE,
               CUSTOMER_ID,
               CUSTOMER_NAME,
               CUSTOMER_CODE,
               ACCOUNT_ID,
               SALES_MAIN_TYPE,
               DISCOUNT_TYPE,
               RECEIPT_AMOUNT,
               SALES_AMOUNT,
               LOCK_AMOUNT,
               RECEIVED_AMOUNT,
               VD_FREEZE_DATE,
               ENTITY_ID,
               PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(ENTITY_ID,
                                                      CUSTOMER_ID,
                                                      SALES_MAIN_TYPE,
                                                      ACCOUNT_ID)
          FROM T_CREDIT_DISCOUNT_AMOUNT T
         WHERE IN_ENTITY_ID = ENTITY_ID
                AND (IN_CUSTOMER_ID IS NULL OR IN_CUSTOMER_ID = T.CUSTOMER_ID)
                AND (IN_ACCOUNT_ID IS NULL OR IN_ACCOUNT_ID = T.ACCOUNT_ID)
         AND (RECEIPT_AMOUNT <> 0 OR SALES_AMOUNT <> 0 OR LOCK_AMOUNT <> 0 OR RECEIVED_AMOUNT <> 0);
    
      VV_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('P_DIS_AMOUNT_FREEZE',
                                           'SUCCESS',
                                           SUBSTR('折扣类型款项冻结结束，ENTITY_ID=' ||
                                                  IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
     || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE,
                                                  1,
                                                  240));
                                                  
    COMMIT;                                              
    END IF; 
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      VV_ERR_MSG := '记录折扣类型款项冻结异常！' || SQLERRM;
      VV_ERR_MSG := PKG_BD.F_ADD_ERROR_LOG('P_DIS_AMOUNT_FREEZE',
                                           '异常，主体：' || IN_ENTITY_ID || '，客户ID=' ||IN_CUSTOMER_ID
     || '，账户ID=' ||IN_ACCOUNT_ID|| '，IS_USER_CODE=' ||IS_USER_CODE,
                                           SUBSTR(VV_ERR_MSG, 1, 240));
  END P_DIS_AMOUNT_FREEZE;
  
  /*
  select * from Table(PKG_CREDIT_DIS.F_GET_LOCK_AMOUNT(28,12882,50675,'C0000433-010',569,null,'COMMON','liangxr'));
  */
  
  ---需要一起修改的存储过程函数：PKG_CREDIT_LAMOUNT_CCS.P_GET_LOCK_AMOUNT/PKG_CREDIT_LOCK_AMOUNT.F_GET_LOCK_AMOUNT/PKG_CREDIT_DIS.F_GET_LOCK_AMOUNT
  FUNCTION F_GET_LOCK_AMOUNT(IN_ENTITY_ID       NUMBER, --主体ID 不能为空
                             IN_CUSTOMER_ID     NUMBER, --客户ID 可以为空
                             IN_ACCOUNT_ID      NUMBER, --账户ID 可以为空
                             IN_ACCOUNT_CODE    VARCHAR2, --账户编码 可以为空
                             IN_CREDIT_GROUP_ID NUMBER, --额度组ID 可以为空
                             IN_SALES_CENTER_ID VARCHAR2, --营销中心ID 可以为空
                             IN_DISCOUNT_TYPE   VARCHAR2, --折让方式 可以为空
                             IN_USER_ACC        VARCHAR2 --用户账号 不能为空
                             ) RETURN TAB_CREDIT_LOCK_AMOUNT
    PIPELINED AS
  
    V_CENTER_ID      NUMBER;
    VN_CREDIT_GROUP_ID       NUMBER;
    VN_CUSTOMER_ID       NUMBER;
    VN_ACCOUNT_ID       NUMBER;
    V_LOCK_AMOUT_ROW OBJ_CREDIT_LOCK_AMOUNT;
    --不带中心
    CURSOR C_LOCK_AMOUT_NOCENTER IS
      SELECT CG.CREDIT_GROUP_NAME     AS CREDIT_GROUP_NAME,
             V.ENTITY_ID,
             V.CUSTOMER_ID,
             V.SALES_CENTER_ID,
             V.CUSTOMER_CODE,
             V.CUSTOMER_NAME,
             V.ACCOUNT_ID,
             V.ACCOUNT_CODE,
             V.ACCOUNT_NAME,
             V.SALES_MAIN_TYPE,
             V.CREDIT_GROUP_ID,
             V.DISCOUNT_TYPE,
             V.ORIGIN_ORDER_NUM,V.ORDER_NUM,
             V.DOWN_PAY_SCALE,--锁定订金比例  update 2018/5/31 by 梁颜明
             V.LOCK_METHOD,
             V.LOCKED_AMOUNT,
             V.LOCKED_DISCOUNT_AMOUNT,
             V.LOCKED_DOWNPAY_AMOUNT,
             V.LOCKED_DIS_DP_AMOUNT,
             V.SALES_CENTER_CODE      SALES_CENTER_CODE,
             V.SALES_CENTER_NAME      SALES_CENTER_NAME
        FROM (SELECT BI.ENTITY_ID,
                     BI.CUSTOMER_ID,
                     A.SALES_CENTER_ID,
                     A.SALES_CENTER_CODE,
                     A.SALES_CENTER_NAME,
                     BI.CUSTOMER_CODE,
                     BI.CUSTOMER_NAME,
                     A.ACCOUNT_ID,
                     BI.ACCOUNT_CODE,
                     BI.ACCOUNT_NAME,
                     BI.SALES_MAIN_TYPE,
                     PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(BI.ENTITY_ID,
                                                            BI.CUSTOMER_ID,
                                                            BI.SALES_MAIN_TYPE,
                                                            A.ACCOUNT_ID) AS CREDIT_GROUP_ID,
                     BI.DISCOUNT_TYPE,
                     BI.ORIGIN_ORDER_NUM,BI.ORDER_NUM,
                     LO.DOWN_PAY_SCALE,--锁定订金比例  update 2018/5/31 by 梁颜明
                     BI.LOCK_METHOD,
                     SUM(BI.LOCKED_AMOUNT) LOCKED_AMOUNT,
                     SUM(BI.LOCKED_DOWNPAY_AMOUNT) LOCKED_DOWNPAY_AMOUNT,
                     SUM(BI.LOCKED_DISCOUNT_AMOUNT) LOCKED_DISCOUNT_AMOUNT,
                     SUM(BI.LOCKED_DIS_DP_AMOUNT) LOCKED_DIS_DP_AMOUNT
                FROM (
                      --v_credit_contact_amount_ar
                      SELECT T.ENTITY_ID ENTITY_ID,
                              T.CUSTOMER_ID CUSTOMER_ID,
                              T.CUSTOMER_CODE CUSTOMER_CODE,
                              T.CUSTOMER_NAME CUSTOMER_NAME,
                              T.ACCOUNT_ID,
                              T.ACCOUNT_CODE ACCOUNT_CODE,
                              T.ACCOUNT_NAME ACCOUNT_NAME,
                              T.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                              NVL(T.DISCOUNT_TYPE,'COMMON') AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              CAST(NULL AS NUMERIC) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              T.BILL_NUM ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                              '三方承兑锁款' LOCK_METHOD,
                              NVL(ROUND(CASE T.BUSINESS_ID
                                        WHEN 'ar' Then
                                        --(CASE WHEN T.FUND_CTRL_MODE = 'Y' THEN --是否为承兑
                                        --mod by sudy 2015-12-26 到款模块三方承兑冲销改变了方式，由之前不生成冲销单改成生成产冲销单据
                                        --重算需要调整，将冲销单据剔除掉
                                        /*(CASE WHEN T.FUND_CTRL_MODE = 'Y' And t.SETTLE_AMOUNT >= 0 THEN --是否为承兑
                                        NVL(T.SETTLE_AMOUNT,0)-NVL(T.SOLUTION_PAY_AMOUNT,0) ELSE 0 END)*/
                                        
                                        --mod by 龙鸿文 2016-1-11 区分三方承兑单据是否被冲销(T.writeoff_receipt_flag = 'Y')
                                         (CASE
                                           WHEN T.FUND_CTRL_MODE = 'Y' AND
                                                T.writeoff_receipt_flag = 'Y' THEN
                                            NVL(T.SETTLE_AMOUNT, 0)
                                           WHEN T.FUND_CTRL_MODE = 'Y' AND
                                                T.writeoff_receipt_flag = 'N' THEN
                                            NVL(T.SETTLE_AMOUNT, 0) -
                                            NVL(T.SOLUTION_PAY_AMOUNT, 0)
                                           ELSE
                                            0
                                         END)
                                        ELSE
                                         0
                                      END, 2),
                                  0) LOCKED_AMOUNT,
                              0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                              0 LOCKED_DISCOUNT_AMOUNT,
                              0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                        FROM V_CREDIT_CONTACT_AMOUNT_AR T
                       WHERE T.ENTITY_ID = IN_ENTITY_ID
                         AND T.CUSTOMER_ID =
                             NVL(VN_CUSTOMER_ID, T.CUSTOMER_ID)
                         AND T.ACCOUNT_ID = NVL(VN_ACCOUNT_ID, T.ACCOUNT_ID)
                         AND (IN_DISCOUNT_TYPE IS NULL OR
                         T.DISCOUNT_TYPE = IN_DISCOUNT_TYPE OR
                         (T.DISCOUNT_TYPE IS NULL AND IN_DISCOUNT_TYPE = 'COMMON'))
                         AND T.SETTLE_FLAG = 'Y'
                         AND 'Y' = T.FUND_CTRL_MODE
                      UNION ALL
                      --1、已下达发运计划但未生成发货通知锁款
                        SELECT T.ENTITY_ID ENTITY_ID,
                               T.CUSTOMER_ID CUSTOMER_ID,
                               T.CUSTOMER_CODE CUSTOMER_CODE,
                               T.CUSTOMER_NAME CUSTOMER_NAME,
                               0 AS ACCOUNT_ID,
                               T.ACCOUNT_CODE ACCOUNT_CODE,
                               T.ACCOUNT_CODE ACCOUNT_NAME,
                               T.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               NVL(T.DISCOUNT_TYPE, 'COMMON') AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               DECODE(T.ORIGIN_ORIGIN_TYPE,'02',T.ORIGIN_ORIGIN_HEAD_ID,T.ORIGIN_ORDER_ID) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               DECODE(T.ORIGIN_ORIGIN_TYPE,'02',T.ORIGIN_ORIGIN_ORDER_CODE,T.ORIGIN_ORDER_NUM) AS ORIGIN_ORDER_NUM,T.ORIGIN_ORDER_NUM AS ORDER_NUM,
                               /*DECODE(T.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'Y',
                                      '发货锁定到款',
                                      'RS',
                                      '资源送审锁定到款',
                                      'RT',
                                      '资源提货锁定到款')*/C.CODE_NAME LOCK_METHOD,
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           when t.origin_type = '01' and nvl(t.direct_transport_falg, 'N') = 'Y' and 
                                             (select nvl(h.amount_lock_flag, 'N')
                                                from t_pln_order_head h
                                               where h.order_head_id = t.origin_order_id) = 'NT'
                                             then
                                               0
                                           WHEN T.LOCK_AMOUNT_FLAG IN ('S', 'Y', 'HQ') THEN
                                           --未确认数量*单价*(100-折扣-月返)/100
                                            NVL(T.UNAFFIRM_QTY, 0) *
                                            NVL(T.ITEM_PRICE, 0) *
                                            (100 - NVL(T.DISCOUNT_RATE, 0) -
                                             NVL(T.MONTH_DISCOUNT_RATE, 0)) / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           when t.origin_type = '01' and nvl(t.direct_transport_falg, 'N') = 'Y' and 
                                             (select nvl(h.amount_lock_flag, 'N')
                                                from t_pln_order_head h
                                               where h.order_head_id = t.origin_order_id) = 'NT'
                                             then
                                               0
                                           WHEN T.LOCK_AMOUNT_FLAG IN ('S', 'Y', 'HQ') THEN
                                            NVL(T.UNAFFIRM_QTY, 0) *
                                            NVL(T.ITEM_PRICE, 0) *
                                            NVL(T.DISCOUNT_RATE, 0) / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_LG_SHIP_PLAN T
                                LEFT JOIN UP_CODELIST C
                                  ON (T.LOCK_AMOUNT_FLAG = C.CODE_VALUE AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE T.ENTITY_ID = IN_ENTITY_ID
                                 AND T.CUSTOMER_ID =
                                     NVL(VN_CUSTOMER_ID, T.CUSTOMER_ID)
                                 AND T.ACCOUNT_CODE =
                                     NVL(IN_ACCOUNT_CODE, T.ACCOUNT_CODE)
                                 AND (IN_DISCOUNT_TYPE IS NULL OR
                                     T.DISCOUNT_TYPE = IN_DISCOUNT_TYPE OR
                                     (T.DISCOUNT_TYPE IS NULL AND
                                     IN_DISCOUNT_TYPE = 'COMMON'))
                                 AND T.STATUS IN ('00', '01') --撤销单据没有锁款
                                    --TP.STATUS <> '03'       
                                    --AND TP.STATUS <> '02'
                                    --已确认，确认则生成发货通知单。部分确认的话，则拆单，生成两个发运计划
                                 AND T.LOCK_AMOUNT_FLAG IN
                                     ('S', 'Y', 'RS', 'RT', 'HQ')
                                 --AND T.SALES_CENTER_ID = V_CENTER_ID
                              UNION ALL
                              --3、已生成发货通知未生成销售单锁款
                              SELECT A.ENTITY_ID ENTITY_ID,
                               A.CUSTOMER_ID CUSTOMER_ID,
                               A.CUSTOMER_CODE CUSTOMER_CODE,
                               A.CUSTOMER_NAME CUSTOMER_NAME,
                               0 AS ACCOUNT_ID,
                               A.ACCOUNT_CODE ACCOUNT_CODE,
                               A.ACCOUNT_CODE ACCOUNT_NAME,
                               B.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               NVL(B.DISCOUNT_TYPE, 'COMMON') AS DISCOUNT_TYPE,
                               0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                               DECODE(B.ORIGIN_ORIGIN_TYPE,'02',B.ORIGIN_ORIGIN_HEAD_ID,B.ORIGIN_ORDER_ID) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                               DECODE(B.ORIGIN_ORIGIN_TYPE,'02',B.ORIGIN_ORIGIN_DOC_CODE,B.ORIGIN_ORDER_NUM) AS ORIGIN_ORDER_NUM,B.ORIGIN_ORDER_NUM AS ORDER_NUM,
                               /*DECODE(B.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'Y',
                                      '发货锁定到款',
                                      'RS',
                                      '资源送审锁定到款',
                                      'RT',
                                      '资源提货锁定到款')*/C.CODE_NAME LOCK_METHOD,
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           when b.origin_type = '01' and nvl(a.direct_transport_falg, 'N') = 'Y' and 
                                             (select nvl(h.amount_lock_flag, 'N')
                                                from t_pln_order_head h
                                               where h.order_head_id = b.origin_order_id) = 'NT'
                                             then
                                               0
                                           WHEN B.LOCK_AMOUNT_FLAG IN ('S', 'Y', 'HQ') THEN
                                           --(ITEM_QTY产品数量 - FACT_SHIP_QTY实际发货数量 - CANCEL_QTY累积取消数量)*单价*(100-折扣-月返)/100
                                            (NVL(B.ITEM_QTY, 0) -
                                            NVL(B.FACT_SHIP_QTY, 0) -
                                            NVL(B.CANCEL_QTY, 0)) *
                                            NVL(B.ITEM_PRICE, 0) *
                                            (100 - NVL(B.DISCOUNT_RATE, 0) -
                                            NVL(B.MONTH_DISCOUNT_RATE, 0)) / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           when b.origin_type = '01' and nvl(a.direct_transport_falg, 'N') = 'Y' and 
                                             (select nvl(h.amount_lock_flag, 'N')
                                                from t_pln_order_head h
                                               where h.order_head_id = b.origin_order_id) = 'NT'
                                             then
                                               0
                                           WHEN B.LOCK_AMOUNT_FLAG IN ('S', 'Y', 'HQ') THEN
                                            (NVL(B.ITEM_QTY, 0) -
                                            NVL(B.FACT_SHIP_QTY, 0) -
                                            NVL(B.CANCEL_QTY, 0)) *
                                            NVL(B.ITEM_PRICE, 0) *
                                            NVL(B.DISCOUNT_RATE, 0) / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_LG_SHIP_DOC A --发货通知单头
                               INNER JOIN T_LG_SHIP_DOC_LINE B --发货通知单行
                                  ON (A.SHIP_DOC_ID = B.SHIP_DOC_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (B.LOCK_AMOUNT_FLAG = C.CODE_VALUE AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE A.ENTITY_ID = IN_ENTITY_ID
                                 AND A.CUSTOMER_ID =
                                     NVL(VN_CUSTOMER_ID, A.CUSTOMER_ID)
                                 AND A.ACCOUNT_CODE =
                                     NVL(IN_ACCOUNT_CODE, A.ACCOUNT_CODE)
                                 AND (IN_DISCOUNT_TYPE IS NULL OR
                                     B.DISCOUNT_TYPE = IN_DISCOUNT_TYPE OR
                                     (B.DISCOUNT_TYPE IS NULL AND
                                     IN_DISCOUNT_TYPE = 'COMMON'))
                                 AND A.DOC_STATUS <> '01' --单据状态 00正常 01红冲
                                 AND B.LOCK_AMOUNT_FLAG IN
                                     ('S', 'Y', 'RS', 'RT', 'HQ')
                                 --AND A.SALES_CENTER_ID = V_CENTER_ID
                              UNION ALL
                              --制定发货需求计划下达（直发客户） 发货计划未确认（未生成发货通知单）
                              SELECT T.TRANSFER_ENTITY_ID ENTITY_ID,
                               T.TRANSFER_CUSTOMER_ID CUSTOMER_ID,
                               T.TRANSFER_CUSTOMER_CODE CUSTOMER_CODE,
                               T.TRANSFER_CUSTOMER_NAME CUSTOMER_NAME,
                               T.TRANSFER_ACCOUNT_ID ACCOUNT_ID,
                               T.TRANSFER_ACCOUNT_CODE ACCOUNT_CODE,
                               T.TRANSFER_ACCOUNT_CODE ACCOUNT_NAME,
                               T.TRANSFER_ITEM_MAIN_TYPE SALES_MAIN_TYPE,
                               NVL(T.TRANSFER_DISCOUNT_TYPE, 'COMMON') AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              DECODE(T.ORIGIN_ORIGIN_TYPE,'02',T.ORIGIN_ORIGIN_HEAD_ID,T.ORIGIN_ORDER_ID) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              DECODE(T.ORIGIN_ORIGIN_TYPE,'02',T.ORIGIN_ORIGIN_ORDER_CODE,T.ORIGIN_ORDER_NUM) AS ORIGIN_ORDER_NUM,T.ORIGIN_ORDER_NUM AS ORDER_NUM,
                               '发货锁定到款（直发）' LOCK_METHOD,
                               NVL(ROUND(
                                         --锁定代理商到款(未确认数量*直发列表价*(100-直发扣率-直发月返)/100)
                                         NVL(T.UNAFFIRM_QTY, 0) *
                                         NVL(T.TRANSFER_LIST_PRICE, 0) *
                                         (100 -
                                          NVL(T.TRANSFER_DISCOUNT_RATE, 0) -
                                          NVL(T.TRANSFER_MONTH_DISCOUNT_RATE,
                                              0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(NVL(T.UNAFFIRM_QTY, 0) *
                                         NVL(T.TRANSFER_LIST_PRICE, 0) *
                                         NVL(T.TRANSFER_DISCOUNT_RATE, 0) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT, --锁定代理商折让(未确认数量*直发列表价*直发扣率/100),
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_LG_SHIP_PLAN T
                               /*LEFT JOIN T_PLN_LG_ORDER_HEAD LH1 ON (LH1.ENTITY_ID = IN_ENTITY_ID
                               AND LH1.ACCOUNT_CODE = T.ACCOUNT_CODE AND ( (LH1.ORDER_HEAD_ID = T.ORIGIN_ORDER_ID
                               AND LH1.ORDER_NUMBER = T.ORIGIN_ORDER_NUM AND T.ORIGIN_TYPE = '02' AND T.ORIGIN_ORIGIN_TYPE IS NULL
                               ) OR (LH1.ORDER_HEAD_ID = T.ORIGIN_ORIGIN_HEAD_ID
                               AND LH1.ORDER_NUMBER = T.ORIGIN_ORIGIN_ORDER_CODE AND T.ORIGIN_ORIGIN_TYPE = '02'-- AND T.ORIGIN_TYPE IS NOT NULL
                               ) )
                               )*/
                               WHERE T.TRANSFER_ENTITY_ID = IN_ENTITY_ID
                                 AND T.TRANSFER_ACCOUNT_ID =
                                     NVL(VN_ACCOUNT_ID, T.TRANSFER_ACCOUNT_ID)
                                 AND T.TRANSFER_CUSTOMER_ID =
                                     NVL(VN_CUSTOMER_ID,
                                         T.TRANSFER_CUSTOMER_ID)
                                 AND (IN_DISCOUNT_TYPE IS NULL OR
                                     T.TRANSFER_DISCOUNT_TYPE =
                                     IN_DISCOUNT_TYPE OR
                                     (T.TRANSFER_DISCOUNT_TYPE IS NULL AND
                                     IN_DISCOUNT_TYPE = 'COMMON'))
                                 AND T.STATUS IN ('00', '01') --撤销单据没有锁款
                                 AND T.TRANSFER_LOCK_AMOUNT_FLAG = 'Y'
                                 AND T.TRANSFER_ITEM_MAIN_TYPE IS NOT NULL
                              UNION ALL
                              --制定发货需求计划下达（直发客户） 发货通知单未生成销售单
                              SELECT A.TRANSFER_ENTITY_ID ENTITY_ID,
                               A.TRANSFER_CUSTOMER_ID CUSTOMER_ID,
                               A.TRANSFER_CUSTOMER_CODE CUSTOMER_CODE,
                               A.TRANSFER_CUSTOMER_NAME AS CUSTOMER_NAME,
                               A.TRANSFER_ACCOUNT_ID ACCOUNT_ID,
                               A.TRANSFER_ACCOUNT_CODE ACCOUNT_CODE,
                               A.TRANSFER_ACCOUNT_CODE ACCOUNT_NAME,
                               B.TRANSFER_ITEM_MAIN_TYPE SALES_MAIN_TYPE,
                               NVL(B.TRANSFER_DISCOUNT_TYPE, 'COMMON') AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              DECODE(B.ORIGIN_ORIGIN_TYPE,'02',B.ORIGIN_ORIGIN_HEAD_ID,B.ORIGIN_ORDER_ID) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              DECODE(B.ORIGIN_ORIGIN_TYPE,'02',B.ORIGIN_ORIGIN_DOC_CODE,B.ORIGIN_ORDER_NUM) AS ORIGIN_ORDER_NUM,B.ORIGIN_ORDER_NUM AS ORDER_NUM,
                               '发货锁定到款（直发）' LOCK_METHOD,
                               NVL(ROUND( --锁定代理商到款((产品数量-已取消数量-已转采购数量)*直发列表价*(100-直发扣率-直发月返)/100)
                                         (NVL(B.ITEM_QTY, 0) -
                                         NVL(B.CANCEL_QTY, 0) -
                                         NVL(B.TRANSFER_TO_POX_QTY, 0)) *
                                         NVL(B.TRANSFER_LIST_PRICE, 0) *
                                         (100 -
                                         NVL(B.TRANSFER_DISCOUNT_RATE, 0) -
                                         NVL(B.TRANSFER_MONTH_DISCOUNT_RATE,
                                              0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND((NVL(B.ITEM_QTY, 0) -
                                         NVL(B.FACT_SHIP_QTY, 0) -
                                         NVL(B.CANCEL_QTY, 0) -
                                         NVL(B.TRANSFER_TO_POX_QTY, 0)) *
                                         NVL(B.TRANSFER_LIST_PRICE, 0) *
                                         NVL(B.TRANSFER_DISCOUNT_RATE, 0) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT, --锁定代理商折让((产品数量-已取消数量-已转采购数量)*直发列表价*直发扣率/100)
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_LG_SHIP_DOC A --发货通知单头
                               INNER JOIN T_LG_SHIP_DOC_LINE B
                                  ON (A.SHIP_DOC_ID = B.SHIP_DOC_ID) --发货通知单行
                               WHERE A.TRANSFER_ENTITY_ID = IN_ENTITY_ID
                                 AND A.TRANSFER_ACCOUNT_ID =
                                     NVL(VN_ACCOUNT_ID, A.TRANSFER_ACCOUNT_ID)
                                 AND A.TRANSFER_CUSTOMER_ID =
                                     NVL(VN_CUSTOMER_ID,
                                         A.TRANSFER_CUSTOMER_ID)
                                 AND (IN_DISCOUNT_TYPE IS NULL OR
                                     B.TRANSFER_DISCOUNT_TYPE =
                                     IN_DISCOUNT_TYPE OR
                                     (B.TRANSFER_DISCOUNT_TYPE IS NULL AND
                                     IN_DISCOUNT_TYPE = 'COMMON'))
                                 AND A.DOC_STATUS <> '01' --单据状态 00正常 01红冲
                                 AND B.TRANSFER_LOCK_AMOUNT_FLAG = 'Y'
                                 AND B.TRANSFER_ITEM_MAIN_TYPE IS NOT NULL
                              UNION ALL
                              --送审锁款：已经送审未下达发运计划的锁款 提货订单 常规部分
                              SELECT A.ENTITY_ID ENTITY_ID,
                               A.CUSTOMER_ID CUSTOMER_ID,
                               A.CUSTOMER_CODE CUSTOMER_CODE,
                               A.CUSTOMER_NAME CUSTOMER_NAME,
                               A.ACCOUNT_ID ACCOUNT_ID,
                               A.ACCOUNT_CODE ACCOUNT_CODE,
                               A.ACCOUNT_NAME ACCOUNT_NAME,
                               B.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               --'COMMON' AS DISCOUNT_TYPE,--常规部分
                               NVL(B.DISCOUNT_TYPE,'COMMON') AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              A.ORDER_HEAD_ID AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              A.ORDER_NUMBER ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                               /*DECODE(A.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'RS',
                                      '资源送审锁款')*/c.code_name LOCK_METHOD,
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           WHEN (A.LOCK_AMOUNT_FLAG = 'S'
                                               --2016-09-23 TIANMZH修改，订金比例为空或小于0时，计算锁定到款，否则，锁定到款为0.
                                                AND (A.DOWN_PAY_SCALE IS NULL OR A.DOWN_PAY_SCALE < 0))
                                                OR NVL(b.is_lock_amount, 'N') = 'Y' THEN
                                            (CASE
                                              when nvl(b.is_lock_amount, 'N') = 'NT' then
                                                NVL(b.center_affirm_quantity, 0) - NVL(b.cancel_qty, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              WHEN A.ORDER_HEAD_STATE IN ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END)
                                           ELSE
                                            0
                                         END 
                                         * DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               
                               --ADD TIANMZH 2016-09-13 ，增加锁定订金（锁款方式 = "送审锁款"，订金比例 > 0，锁定订金=锁定到款*订金比例）
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           WHEN NVL(b.is_lock_amount, 'N') = 'Y' THEN
                                             0
                                           WHEN (A.LOCK_AMOUNT_FLAG = 'S' AND NVL(A.DOWN_PAY_SCALE, 0) > 0) THEN
                                            (CASE
                                              WHEN NVL(b.is_lock_amount, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) -
                                               NVL(B.CANCEL_QTY, 0) - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              WHEN A.ORDER_HEAD_STATE IN ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100 *
                                            A.DOWN_PAY_SCALE / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           --20200314 家用直发锁款调整
                                           WHEN (A.LOCK_AMOUNT_FLAG = 'S' AND (A.DOWN_PAY_SCALE IS NULL OR A.DOWN_PAY_SCALE < 0)) 
                                             OR NVL(b.is_lock_amount, 'N') = 'Y' THEN
                                           --ADD BY LIZHEN 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                                            (CASE
                                              when nvl(b.is_lock_amount, 'N') = 'NT' then
                                                NVL(b.center_affirm_quantity, 0) - NVL(b.cancel_qty, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) -
                                               NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              WHEN A.ORDER_HEAD_STATE IN ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END)
                                           ELSE
                                            0
                                         END
                                         * DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               NVL(ROUND(CASE
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           --20200314 家用直发锁款调整
                                           WHEN NVL(b.is_lock_amount, 'N') = 'Y' THEN
                                             0
                                           WHEN A.LOCK_AMOUNT_FLAG = 'S' AND NVL(A.DOWN_PAY_SCALE, 0) > 0 THEN
                                           --ADD BY LIZHEN 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                                            (CASE
                                              WHEN NVL(b.is_lock_amount, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) -
                                               NVL(B.CANCEL_QTY, 0) - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              WHEN A.ORDER_HEAD_STATE IN ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100 *
                                            A.DOWN_PAY_SCALE / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_PLN_LG_ORDER_HEAD A --物流订单头表
                               INNER JOIN T_PLN_LG_ORDER_LINE B --物流订单行表
                                  ON (A.ORDER_HEAD_ID = B.ORDER_HEAD_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = A.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE A.ENTITY_ID = IN_ENTITY_ID
                                 AND A.ACCOUNT_ID =
                                     NVL(VN_ACCOUNT_ID, A.ACCOUNT_ID)
                                 AND A.CUSTOMER_ID =
                                     NVL(VN_CUSTOMER_ID, A.CUSTOMER_ID)
                                 AND (IN_DISCOUNT_TYPE IS NULL OR
                                     B.DISCOUNT_TYPE =
                                     IN_DISCOUNT_TYPE OR
                                     (B.DISCOUNT_TYPE IS NULL AND
                                     IN_DISCOUNT_TYPE = 'COMMON'))
                                 --AND NVL(B.ORDER_LINE_STATE, 'NORMAL') <> 'CLOSED'
                                 AND A.ORDER_HEAD_STATE IN
                                    --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                     ('20', '23', '381', '679', '1455', '2225')
                                 AND A.LOCK_AMOUNT_FLAG IN ('S', 'RS')
                              UNION ALL
                              --hejy3 送总部锁款
                              SELECT A.ENTITY_ID ENTITY_ID,
                               A.CUSTOMER_ID CUSTOMER_ID,
                               A.CUSTOMER_CODE CUSTOMER_CODE,
                               A.CUSTOMER_NAME CUSTOMER_NAME,
                               A.ACCOUNT_ID ACCOUNT_ID,
                               A.ACCOUNT_CODE ACCOUNT_CODE,
                               A.ACCOUNT_NAME ACCOUNT_NAME,
                               B.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               --'COMMON' AS DISCOUNT_TYPE,--常规部分
                               NVL(B.DISCOUNT_TYPE,'COMMON') AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              A.ORDER_HEAD_ID AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              A.ORDER_NUMBER ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                               /*DECODE(A.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'RS',
                                      '资源送审锁款')*/c.code_name LOCK_METHOD,
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           WHEN (A.DOWN_PAY_SCALE IS NULL OR A.DOWN_PAY_SCALE < 0) 
                                             OR NVL(b.is_lock_amount, 'N') = 'Y' THEN
                                            (CASE
                                              when nvl(b.is_lock_amount, 'N') = 'NT' then
                                                NVL(b.center_affirm_quantity, 0) - NVL(b.cancel_qty, 0)
                                              WHEN ((A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and ha.Submit_To_Hq_Flag = 'Y')
                                                or a.Submit_To_Hq_Flag = 'Y') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END)
                                           ELSE 0
                                         END 
                                         * DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               
                               --ADD TIANMZH 2016-09-13 ，增加锁定订金（锁款方式 = "送审锁款"，订金比例 > 0，锁定订金=锁定到款*订金比例）
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           WHEN NVL(b.is_lock_amount, 'N') = 'Y' THEN
                                             0
                                           WHEN NVL(A.DOWN_PAY_SCALE, 0) > 0 THEN
                                            (CASE
                                              WHEN NVL(b.is_lock_amount, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                              WHEN ((A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and ha.Submit_To_Hq_Flag = 'Y')
                                                or a.Submit_To_Hq_Flag = 'Y') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE 0
                                            END) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100 *
                                            A.DOWN_PAY_SCALE / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           --20200314 家用直发锁款调整
                                           WHEN (A.DOWN_PAY_SCALE IS NULL OR A.DOWN_PAY_SCALE < 0) 
                                             OR NVL(b.is_lock_amount, 'N') = 'Y' THEN
                                            (CASE
                                              when nvl(b.is_lock_amount, 'N') = 'NT' then
                                                NVL(b.center_affirm_quantity, 0) - NVL(b.cancel_qty, 0)
                                              WHEN ((A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and ha.Submit_To_Hq_Flag = 'Y')
                                                or a.Submit_To_Hq_Flag = 'Y') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE 0
                                            END)
                                           ELSE 0
                                         END
                                         * DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               NVL(ROUND(CASE
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           --20200314 家用直发锁款调整
                                           WHEN NVL(b.is_lock_amount, 'N') = 'Y' THEN
                                             0
                                           WHEN NVL(A.DOWN_PAY_SCALE, 0) > 0 THEN
                                            (CASE
                                              WHEN NVL(b.is_lock_amount, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                              WHEN ((A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and ha.Submit_To_Hq_Flag = 'Y')
                                                or a.Submit_To_Hq_Flag = 'Y') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE 0
                                            END) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100 *
                                            A.DOWN_PAY_SCALE / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_PLN_LG_ORDER_HEAD A --物流订单头表
                               INNER JOIN T_PLN_LG_ORDER_LINE B --物流订单行表
                                  ON (A.ORDER_HEAD_ID = B.ORDER_HEAD_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = A.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                                LEFT JOIN T_PLN_LG_ORDER_HEAD HA
                                  ON (HA.ORDER_HEAD_ID = A.HQ_LG_ORDER_HEAD_ID)
                               WHERE A.ENTITY_ID = IN_ENTITY_ID
                                 AND A.ACCOUNT_ID =
                                     NVL(VN_ACCOUNT_ID, A.ACCOUNT_ID)
                                 AND A.CUSTOMER_ID =
                                     NVL(VN_CUSTOMER_ID, A.CUSTOMER_ID)
                                 AND (IN_DISCOUNT_TYPE IS NULL OR
                                     B.DISCOUNT_TYPE =
                                     IN_DISCOUNT_TYPE OR
                                     (B.DISCOUNT_TYPE IS NULL AND
                                     IN_DISCOUNT_TYPE = 'COMMON'))
                                 --AND NVL(B.ORDER_LINE_STATE, 'NORMAL') <> 'CLOSED'
                                 AND A.ORDER_HEAD_STATE IN
                                    --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                     ('20', '23', '381', '679', '1455', '2225')
                                 AND A.LOCK_AMOUNT_FLAG IN ('HQ')
                              UNION ALL
                              --针对已结转总部主体且发货锁款的提货订单 常规部分
                              SELECT A.ENTITY_ID ENTITY_ID,
                               A.CUSTOMER_ID CUSTOMER_ID,
                               A.CUSTOMER_CODE CUSTOMER_CODE,
                               A.CUSTOMER_NAME CUSTOMER_NAME,
                               A.ACCOUNT_ID ACCOUNT_ID,
                               A.ACCOUNT_CODE ACCOUNT_CODE,
                               A.ACCOUNT_NAME ACCOUNT_NAME,
                               B.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               --'COMMON' AS DISCOUNT_TYPE,--常规部分
                               NVL(B.DISCOUNT_TYPE,'COMMON') AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              A.ORDER_HEAD_ID AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              A.ORDER_NUMBER ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                               /*DECODE(A.LOCK_AMOUNT_FLAG,
                                      'Y',
                                      '发货锁款')*/c.code_name LOCK_METHOD,
                               NVL(ROUND(CASE WHEN NVL(b.is_lock_amount, 'N') <> 'NT' THEN
                                            (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100
                                           ELSE 0 END
                                         ,2),
                                   0) LOCKED_AMOUNT,
                               
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           WHEN NVL(b.is_lock_amount, 'N') <> 'NT' THEN
                                            (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100
                                           ELSE 0
                                         END,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_PLN_LG_ORDER_HEAD A --物流订单头表
                               INNER JOIN T_PLN_LG_ORDER_LINE B --物流订单行表
                                  ON (A.ORDER_HEAD_ID = B.ORDER_HEAD_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = A.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE A.ENTITY_ID = IN_ENTITY_ID
                                 AND A.ACCOUNT_ID =
                                     NVL(VN_ACCOUNT_ID, A.ACCOUNT_ID)
                                 AND A.CUSTOMER_ID =
                                     NVL(VN_CUSTOMER_ID, A.CUSTOMER_ID)
                                 AND (IN_DISCOUNT_TYPE IS NULL OR
                                     B.DISCOUNT_TYPE =
                                     IN_DISCOUNT_TYPE OR
                                     (B.DISCOUNT_TYPE IS NULL AND
                                     IN_DISCOUNT_TYPE = 'COMMON'))
                                 AND A.ORDER_HEAD_STATE IN
                                     ('20', '23', '381', '679', '1455', '2225', '304')
                                 AND B.TRANSFER_HQ_AFFIRMED_QTY > 0
                              UNION ALL
                              --1.2、计划订单
                              SELECT POH.ENTITY_ID ENTITY_ID,
                               POH.CUSTOMER_ID CUSTOMER_ID,
                               POH.CUSTOMER_CODE CUSTOMER_CODE,
                               POH.CUSTOMER_NAME CUSTOMER_NAME,
                               POH.ACCOUNT_ID ACCOUNT_ID,
                               POH.ACCOUNT_CODE ACCOUNT_CODE,
                               POH.ACCOUNT_NAME ACCOUNT_NAME,
                               NVL(POL.SALES_MAIN_TYPE,
                                   BI.SALES_MAIN_TYPE) SALES_MAIN_TYPE,
                               'COMMON' AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              CAST(NULL AS NUMERIC) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              POH.ORDER_NUMBER ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                               --POH.LOCK_AMOUNT_FLAG 送审锁款,(这一行写错了别名)
                               /*DECODE(POH.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'Y',
                                      '发货锁定到款')*/c.code_name LOCK_METHOD,
                               NVL(ROUND((CASE
                                            WHEN NVL(POH.DOWN_PAY_SCALE, -1) < 0 THEN --计划订单锁订金处理
                                              CASE
                                               WHEN POH.FORM_STATE NOT IN
                                                    ('23',
                                                     '32',
                                                     '248',
                                                     '303',
                                                     '304',
                                                     '306') THEN
                                                NVL(POL.APPLY_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_IN_QTY, 0)
                                               WHEN POH.FORM_STATE IN ('23', '32') THEN
                                                NVL(POL.CAN_PRODUCE_QTY, 0) +
                                                NVL(POL.INV_AFFIRM_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_IN_QTY, 0)
                                               ELSE
                                                0
                                              END
                                            ELSE
                                              0
                                          END
                                          ) * POL.ITEM_PRICE *
                                         (100 -
                                         NVL(POL.DISCOUNT_RATE, 0) -
                                         NVL(POL.ORDERED_DISCOUNT_RATE,
                                              0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               NVL(ROUND((CASE
                                            WHEN POH.DOWN_PAY_SCALE > 0 THEN --计划订单锁订金处理
                                              POH.DOWN_PAY_SCALE / 100 *
                                              CASE
                                               WHEN POH.FORM_STATE NOT IN
                                                    ('23',
                                                     '32',
                                                     '248',
                                                     '303',
                                                     '304',
                                                     '306') THEN
                                                NVL(POL.APPLY_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_IN_QTY, 0)
                                               WHEN POH.FORM_STATE IN ('23', '32') THEN
                                                NVL(POL.CAN_PRODUCE_QTY, 0) +
                                                NVL(POL.INV_AFFIRM_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_IN_QTY, 0)
                                               ELSE
                                                0
                                              END
                                            ELSE
                                              0
                                          END
                                          ) * POL.ITEM_PRICE *
                                         (100 -
                                         NVL(POL.DISCOUNT_RATE, 0) -
                                         NVL(POL.ORDERED_DISCOUNT_RATE,
                                              0)) / 100,
                                         2),
                                   0) LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND((CASE
                                            WHEN NVL(POH.DOWN_PAY_SCALE, -1) < 0 THEN
                                              CASE
                                               WHEN POH.FORM_STATE NOT IN
                                                    ('23', '32', '248', '303', '304', '306') THEN
                                                NVL(POL.APPLY_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0)
                                               WHEN POH.FORM_STATE IN
                                                    ('23', '32') THEN--, '306'
                                                NVL(POL.CAN_PRODUCE_QTY, 0) +
                                                NVL(POL.INV_AFFIRM_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0)
                                               ELSE
                                                0
                                              END
                                            ELSE
                                              0
                                          END
                                         ) * POL.ITEM_PRICE *
                                         NVL(POL.DISCOUNT_RATE, 0) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               NVL(ROUND((CASE
                                            WHEN POH.DOWN_PAY_SCALE > 0 THEN
                                              POH.DOWN_PAY_SCALE / 100 *
                                              CASE
                                               WHEN POH.FORM_STATE NOT IN
                                                    ('23', '32', '248', '303', '304', '306') THEN
                                                NVL(POL.APPLY_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0)
                                               WHEN POH.FORM_STATE IN
                                                    ('23', '32') THEN--, '306'
                                                NVL(POL.CAN_PRODUCE_QTY, 0) +
                                                NVL(POL.INV_AFFIRM_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0)
                                               ELSE
                                                0
                                              END
                                            ELSE
                                              0
                                          END
                                         ) * POL.ITEM_PRICE *
                                         NVL(POL.DISCOUNT_RATE, 0) / 100,
                                         2),
                                   0) AS LOCKED_DIS_DP_AMOUNT
                                FROM T_PLN_ORDER_HEAD POH --计划订单头表
                               INNER JOIN T_PLN_ORDER_LINE POL
                                  ON (POH.ORDER_HEAD_ID = POL.ORDER_HEAD_ID) --计划订单行表
                               INNER JOIN T_PLN_ORDER_TYPE POT
                                  ON (POT.ORDER_TYPE_ID = POH.ORDER_TYPE_ID) --订单类型表
                               INNER JOIN t_Bd_Item BI
                                  ON (Bi.Item_Id = Pol.Item_Id And
                                     Bi.Entity_Id = Pol.Entity_Id)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = poh.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE POH.ENTITY_ID = IN_ENTITY_ID
                                 AND POH.ACCOUNT_ID =
                                     NVL(VN_ACCOUNT_ID, POH.ACCOUNT_ID)
                                 AND POH.CUSTOMER_ID =
                                     NVL(VN_CUSTOMER_ID, POH.CUSTOMER_ID)
                                 AND (IN_DISCOUNT_TYPE IS NULL OR
                                     IN_DISCOUNT_TYPE = 'COMMON')
                                 AND NVL(POH.LOCK_AMOUNT_FLAG, 'N') = 'S'
                                 AND POH.FORM_STATE NOT IN
                                     ('19', '248', '303', '304', '305')
                      ) BI
                                INNER JOIN T_CUSTOMER_ACCOUNT A
                                ON ((A.ACCOUNT_ID = BI.ACCOUNT_ID OR A.ACCOUNT_CODE = BI.ACCOUNT_CODE)
                                AND A.ENTITY_ID = BI.ENTITY_ID AND A.ENTITY_ID = IN_ENTITY_ID)
                                LEFT JOIN T_PLN_LG_ORDER_HEAD LO
                                ON (LO.ORDER_HEAD_ID = BI.SRC_LG_ORDER_ID AND LO.ENTITY_ID = IN_ENTITY_ID
                                AND (VN_CUSTOMER_ID IS NULL OR 0 >= VN_CUSTOMER_ID OR LO.CUSTOMER_ID = VN_CUSTOMER_ID)
                                AND (VN_ACCOUNT_ID IS NULL OR 0 >= VN_ACCOUNT_ID OR LO.ACCOUNT_ID = VN_ACCOUNT_ID)
                                )
               GROUP BY BI.ENTITY_ID,
                        BI.CUSTOMER_ID,
                        A.SALES_CENTER_ID,
                        A.SALES_CENTER_CODE,
                        A.SALES_CENTER_NAME,
                        BI.CUSTOMER_CODE,
                        BI.CUSTOMER_NAME,
                        A.ACCOUNT_ID,
                        BI.ACCOUNT_CODE,
                        BI.ACCOUNT_NAME,
                        BI.SALES_MAIN_TYPE,
                        PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(BI.ENTITY_ID,
                                                               BI.CUSTOMER_ID,
                                                               BI.SALES_MAIN_TYPE,
                                                               A.ACCOUNT_ID),
                        BI.DISCOUNT_TYPE,
                        BI.ORIGIN_ORDER_NUM,BI.ORDER_NUM,
                        LO.DOWN_PAY_SCALE,--锁定订金比例  update 2018/5/31 by 梁颜明
                        BI.LOCK_METHOD
              --梁颜明 2016-09-24修改 锁定到款拆分为普通的锁款和订金 计算锁定到款时两值要相加
              HAVING 0 <> SUM(BI.LOCKED_DISCOUNT_AMOUNT + BI.LOCKED_DIS_DP_AMOUNT)
              --
              OR 0 <> SUM(BI.LOCKED_AMOUNT + BI.LOCKED_DOWNPAY_AMOUNT)
              --
              ) V
       INNER JOIN T_CREDIT_GROUP CG
          ON (CG.ENTITY_ID = V.ENTITY_ID AND
             CG.CREDIT_GROUP_ID = V.CREDIT_GROUP_ID)
       WHERE (VN_CREDIT_GROUP_ID IS NULL OR 0 >= VN_CREDIT_GROUP_ID
             --
             OR VN_CREDIT_GROUP_ID = V.CREDIT_GROUP_ID)
         AND EXISTS (SELECT VA.ACCOUNT_ID
                FROM CIMS.V_BD_USER_ACC_PRIV VA
               WHERE VA.USER_CODE = IN_USER_ACC
                 AND VA.ENTITY_ID = IN_ENTITY_ID
                 AND VA.ACCOUNT_ID = V.ACCOUNT_ID)
                 ;
  
    CURSOR C_LOCK_AMOUT IS
      SELECT CG.CREDIT_GROUP_NAME     AS CREDIT_GROUP_NAME,
             V.ENTITY_ID,
             V.CUSTOMER_ID,
             V.SALES_CENTER_ID,
             V.CUSTOMER_CODE,
             V.CUSTOMER_NAME,
             V.ACCOUNT_ID,
             V.ACCOUNT_CODE,
             V.ACCOUNT_NAME,
             V.SALES_MAIN_TYPE,
             V.CREDIT_GROUP_ID,
             V.DISCOUNT_TYPE,
             V.ORIGIN_ORDER_NUM,V.ORDER_NUM,
             V.DOWN_PAY_SCALE,--锁定订金比例  update 2018/5/31 by 梁颜明
             V.LOCK_METHOD,
             V.LOCKED_AMOUNT,
             V.LOCKED_DISCOUNT_AMOUNT,
             V.LOCKED_DOWNPAY_AMOUNT,
             V.LOCKED_DIS_DP_AMOUNT,
             V.SALES_CENTER_CODE      SALES_CENTER_CODE,
             V.SALES_CENTER_NAME      SALES_CENTER_NAME
        FROM (SELECT BI.ENTITY_ID,
                     BI.CUSTOMER_ID,
                     BI.SALES_CENTER_ID,
                     BI.SALES_CENTER_CODE,
                     BI.SALES_CENTER_NAME,
                     BI.CUSTOMER_CODE,
                     BI.CUSTOMER_NAME,
                     BI.ACCOUNT_ID,
                     BI.ACCOUNT_CODE,
                     BI.ACCOUNT_NAME,
                     BI.SALES_MAIN_TYPE,
                     PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(BI.ENTITY_ID,
                                                            BI.CUSTOMER_ID,
                                                            BI.SALES_MAIN_TYPE,
                                                            BI.ACCOUNT_ID) AS CREDIT_GROUP_ID,
                     BI.DISCOUNT_TYPE,
                     BI.ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                     LO.DOWN_PAY_SCALE,--锁定订金比例  update 2018/5/31 by 梁颜明
                     BI.LOCK_METHOD,
                     SUM(BI.LOCKED_AMOUNT) LOCKED_AMOUNT,
                     SUM(BI.LOCKED_DOWNPAY_AMOUNT) LOCKED_DOWNPAY_AMOUNT,
                     SUM(BI.LOCKED_DISCOUNT_AMOUNT) LOCKED_DISCOUNT_AMOUNT,
                     SUM(BI.LOCKED_DIS_DP_AMOUNT) LOCKED_DIS_DP_AMOUNT
                FROM (
                      --v_credit_contact_amount_ar
                      SELECT T.ENTITY_ID ENTITY_ID,
                              T.CUSTOMER_ID CUSTOMER_ID,
                              T.CUSTOMER_CODE CUSTOMER_CODE,
                              T.CUSTOMER_NAME CUSTOMER_NAME,
                              T.ACCOUNT_ID,
                              T.ACCOUNT_CODE ACCOUNT_CODE,
                              T.ACCOUNT_NAME ACCOUNT_NAME,
                     AC.SALES_CENTER_ID,
                     AC.SALES_CENTER_CODE,
                     AC.SALES_CENTER_NAME,
                              T.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                              NVL(T.DISCOUNT_TYPE,'COMMON') AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              CAST(NULL AS NUMERIC) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              T.BILL_NUM ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                              '三方承兑锁款' LOCK_METHOD,
                              NVL(ROUND(CASE T.BUSINESS_ID
                                        WHEN 'ar' Then
                                        --mod by 龙鸿文 2016-1-11 区分三方承兑单据是否被冲销(T.writeoff_receipt_flag = 'Y')
                                         (CASE
                                           WHEN T.FUND_CTRL_MODE = 'Y' AND
                                                T.writeoff_receipt_flag = 'Y' THEN
                                            NVL(T.SETTLE_AMOUNT, 0)
                                           WHEN T.FUND_CTRL_MODE = 'Y' AND
                                                T.writeoff_receipt_flag = 'N' THEN
                                            NVL(T.SETTLE_AMOUNT, 0) -
                                            NVL(T.SOLUTION_PAY_AMOUNT, 0)
                                           ELSE
                                            0
                                         END)
                                        ELSE
                                         0
                                      END, 2),
                                  0) LOCKED_AMOUNT,
                              0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                              0 LOCKED_DISCOUNT_AMOUNT,
                              0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                        FROM V_CREDIT_CONTACT_AMOUNT_AR T
                        INNER JOIN T_CUSTOMER_ACCOUNT AC ON (AC.ACCOUNT_ID = T.ACCOUNT_ID
                        AND AC.SALES_CENTER_ID = V_CENTER_ID AND AC.ENTITY_ID = IN_ENTITY_ID)
                       WHERE T.ENTITY_ID = IN_ENTITY_ID
                         AND T.CUSTOMER_ID =
                             NVL(VN_CUSTOMER_ID, T.CUSTOMER_ID)
                         AND T.ACCOUNT_ID = NVL(VN_ACCOUNT_ID, T.ACCOUNT_ID)
                         AND (IN_DISCOUNT_TYPE IS NULL OR
                         T.DISCOUNT_TYPE = IN_DISCOUNT_TYPE OR
                         (T.DISCOUNT_TYPE IS NULL AND IN_DISCOUNT_TYPE = 'COMMON'))
                         AND T.SETTLE_FLAG = 'Y'
                         AND 'Y' = T.FUND_CTRL_MODE
                         --AND T.SALES_CENTER_ID = V_CENTER_ID
                      UNION ALL
                      --1、已下达发运计划但未生成发货通知锁款
                        SELECT T.ENTITY_ID ENTITY_ID,
                               T.CUSTOMER_ID CUSTOMER_ID,
                               T.CUSTOMER_CODE CUSTOMER_CODE,
                               T.CUSTOMER_NAME CUSTOMER_NAME,
                               A.ACCOUNT_ID AS ACCOUNT_ID,
                               T.ACCOUNT_CODE ACCOUNT_CODE,
                               T.ACCOUNT_CODE ACCOUNT_NAME,
                     A.SALES_CENTER_ID,
                     A.SALES_CENTER_CODE,
                     A.SALES_CENTER_NAME,
                               T.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               NVL(T.DISCOUNT_TYPE, 'COMMON') AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              DECODE(T.ORIGIN_ORIGIN_TYPE,'02',T.ORIGIN_ORIGIN_HEAD_ID,T.ORIGIN_ORDER_ID) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              DECODE(T.ORIGIN_ORIGIN_TYPE,'02',T.ORIGIN_ORIGIN_ORDER_CODE,T.ORIGIN_ORDER_NUM) AS ORIGIN_ORDER_NUM,T.ORIGIN_ORDER_NUM AS ORDER_NUM,
                               /*DECODE(T.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'Y',
                                      '发货锁定到款',
                                      'RS',
                                      '资源送审锁定到款',
                                      'RT',
                                      '资源提货锁定到款')*/C.CODE_NAME LOCK_METHOD,
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           when t.origin_type = '01' and nvl(t.direct_transport_falg, 'N') = 'Y' and 
                                             (select nvl(h.amount_lock_flag, 'N')
                                                from t_pln_order_head h
                                               where h.order_head_id = t.origin_order_id) = 'NT'
                                             then
                                               0
                                           WHEN T.LOCK_AMOUNT_FLAG IN ('S', 'Y','HQ') THEN
                                           --未确认数量*单价*(100-折扣-月返)/100
                                            NVL(T.UNAFFIRM_QTY, 0) *
                                            NVL(T.ITEM_PRICE, 0) *
                                            (100 - NVL(T.DISCOUNT_RATE, 0) -
                                             NVL(T.MONTH_DISCOUNT_RATE, 0)) / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           when t.origin_type = '01' and nvl(t.direct_transport_falg, 'N') = 'Y' and 
                                             (select nvl(h.amount_lock_flag, 'N')
                                                from t_pln_order_head h
                                               where h.order_head_id = t.origin_order_id) = 'NT'
                                             then
                                               0
                                           WHEN T.LOCK_AMOUNT_FLAG IN ('S', 'Y','HQ') THEN
                                            NVL(T.UNAFFIRM_QTY, 0) *
                                            NVL(T.ITEM_PRICE, 0) *
                                            NVL(T.DISCOUNT_RATE, 0) / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_LG_SHIP_PLAN T
                                INNER JOIN T_CUSTOMER_ACCOUNT A
                                ON (A.ACCOUNT_CODE = T.ACCOUNT_CODE AND A.ENTITY_ID = IN_ENTITY_ID
                                AND A.SALES_CENTER_ID = V_CENTER_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = T.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE T.ENTITY_ID = IN_ENTITY_ID
                                 AND T.CUSTOMER_ID =
                                     NVL(VN_CUSTOMER_ID, T.CUSTOMER_ID)
                                 AND T.ACCOUNT_CODE =
                                     NVL(IN_ACCOUNT_CODE, T.ACCOUNT_CODE)
                                 AND (IN_DISCOUNT_TYPE IS NULL OR
                                     T.DISCOUNT_TYPE = IN_DISCOUNT_TYPE OR
                                     (T.DISCOUNT_TYPE IS NULL AND
                                     IN_DISCOUNT_TYPE = 'COMMON'))
                                 AND T.STATUS IN ('00', '01') --撤销单据没有锁款
                                    --TP.STATUS <> '03'       
                                    --AND TP.STATUS <> '02'
                                    --已确认，确认则生成发货通知单。部分确认的话，则拆单，生成两个发运计划
                                 AND T.LOCK_AMOUNT_FLAG IN
                                     ('S', 'Y', 'RS', 'RT', 'HQ')
                                 --AND T.SALES_CENTER_ID = V_CENTER_ID
                              UNION ALL
                              --3、已生成发货通知未生成销售单锁款
                              SELECT A.ENTITY_ID ENTITY_ID,
                               A.CUSTOMER_ID CUSTOMER_ID,
                               A.CUSTOMER_CODE CUSTOMER_CODE,
                               A.CUSTOMER_NAME CUSTOMER_NAME,
                               ACC.ACCOUNT_ID AS ACCOUNT_ID,
                               A.ACCOUNT_CODE ACCOUNT_CODE,
                               A.ACCOUNT_CODE ACCOUNT_NAME,
                     ACC.SALES_CENTER_ID,
                     ACC.SALES_CENTER_CODE,
                     ACC.SALES_CENTER_NAME,
                               B.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               NVL(B.DISCOUNT_TYPE, 'COMMON') AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              DECODE(B.ORIGIN_ORIGIN_TYPE,'02',B.ORIGIN_ORIGIN_HEAD_ID,B.ORIGIN_ORDER_ID) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              DECODE(B.ORIGIN_ORIGIN_TYPE,'02',B.ORIGIN_ORIGIN_DOC_CODE,B.ORIGIN_ORDER_NUM) AS ORIGIN_ORDER_NUM,B.ORIGIN_ORDER_NUM AS ORDER_NUM,
                               /*DECODE(B.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'Y',
                                      '发货锁定到款',
                                      'RS',
                                      '资源送审锁定到款',
                                      'RT',
                                      '资源提货锁定到款')*/C.CODE_NAME LOCK_METHOD,
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           when b.origin_type = '01' and nvl(a.direct_transport_falg, 'N') = 'Y' and 
                                             (select nvl(h.amount_lock_flag, 'N')
                                                from t_pln_order_head h
                                               where h.order_head_id = b.origin_order_id) = 'NT'
                                             then
                                               0
                                           WHEN B.LOCK_AMOUNT_FLAG IN ('S', 'Y','HQ') THEN
                                           --(ITEM_QTY产品数量 - FACT_SHIP_QTY实际发货数量 - CANCEL_QTY累积取消数量)*单价*(100-折扣-月返)/100
                                            (NVL(B.ITEM_QTY, 0) -
                                            NVL(B.FACT_SHIP_QTY, 0) -
                                            NVL(B.CANCEL_QTY, 0)) *
                                            NVL(B.ITEM_PRICE, 0) *
                                            (100 - NVL(B.DISCOUNT_RATE, 0) -
                                            NVL(B.MONTH_DISCOUNT_RATE, 0)) / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           when b.origin_type = '01' and nvl(a.direct_transport_falg, 'N') = 'Y' and 
                                             (select nvl(h.amount_lock_flag, 'N')
                                                from t_pln_order_head h
                                               where h.order_head_id = b.origin_order_id) = 'NT'
                                             then
                                               0
                                           WHEN B.LOCK_AMOUNT_FLAG IN ('S', 'Y','HQ') THEN
                                            (NVL(B.ITEM_QTY, 0) -
                                            NVL(B.FACT_SHIP_QTY, 0) -
                                            NVL(B.CANCEL_QTY, 0)) *
                                            NVL(B.ITEM_PRICE, 0) *
                                            NVL(B.DISCOUNT_RATE, 0) / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_LG_SHIP_DOC A --发货通知单头
                               INNER JOIN T_LG_SHIP_DOC_LINE B --发货通知单行
                                  ON (A.SHIP_DOC_ID = B.SHIP_DOC_ID)
                                INNER JOIN T_CUSTOMER_ACCOUNT ACC
                                ON (ACC.ACCOUNT_CODE = A.ACCOUNT_CODE AND ACC.ENTITY_ID = IN_ENTITY_ID
                                AND ACC.SALES_CENTER_ID = V_CENTER_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = B.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE A.ENTITY_ID = IN_ENTITY_ID
                                 AND A.CUSTOMER_ID =
                                     NVL(VN_CUSTOMER_ID, A.CUSTOMER_ID)
                                 AND A.ACCOUNT_CODE =
                                     NVL(IN_ACCOUNT_CODE, A.ACCOUNT_CODE)
                                 AND (IN_DISCOUNT_TYPE IS NULL OR
                                     B.DISCOUNT_TYPE = IN_DISCOUNT_TYPE OR
                                     (B.DISCOUNT_TYPE IS NULL AND
                                     IN_DISCOUNT_TYPE = 'COMMON'))
                                 AND A.DOC_STATUS <> '01' --单据状态 00正常 01红冲
                                 AND B.LOCK_AMOUNT_FLAG IN
                                     ('S', 'Y', 'RS', 'RT','HQ')
                                 --AND A.SALES_CENTER_ID = V_CENTER_ID
                              UNION ALL
                              --制定发货需求计划下达（直发客户） 发货计划未确认（未生成发货通知单）
                              SELECT T.TRANSFER_ENTITY_ID ENTITY_ID,
                               T.TRANSFER_CUSTOMER_ID CUSTOMER_ID,
                               T.TRANSFER_CUSTOMER_CODE CUSTOMER_CODE,
                               T.TRANSFER_CUSTOMER_NAME CUSTOMER_NAME,
                               T.TRANSFER_ACCOUNT_ID ACCOUNT_ID,
                               T.TRANSFER_ACCOUNT_CODE ACCOUNT_CODE,
                               T.TRANSFER_ACCOUNT_CODE ACCOUNT_NAME,
                     A.SALES_CENTER_ID,
                     A.SALES_CENTER_CODE,
                     A.SALES_CENTER_NAME,
                               T.TRANSFER_ITEM_MAIN_TYPE SALES_MAIN_TYPE,
                               NVL(T.TRANSFER_DISCOUNT_TYPE, 'COMMON') AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              DECODE(T.ORIGIN_ORIGIN_TYPE,'02',T.ORIGIN_ORIGIN_HEAD_ID,T.ORIGIN_ORDER_ID) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              DECODE(T.ORIGIN_ORIGIN_TYPE,'02',T.ORIGIN_ORIGIN_ORDER_CODE,T.ORIGIN_ORDER_NUM) AS ORIGIN_ORDER_NUM,T.ORIGIN_ORDER_NUM AS ORDER_NUM,
                               '发货锁定到款（直发）' LOCK_METHOD,
                               NVL(ROUND(
                                         --锁定代理商到款(未确认数量*直发列表价*(100-直发扣率-直发月返)/100)
                                         NVL(T.UNAFFIRM_QTY, 0) *
                                         NVL(T.TRANSFER_LIST_PRICE, 0) *
                                         (100 -
                                          NVL(T.TRANSFER_DISCOUNT_RATE, 0) -
                                          NVL(T.TRANSFER_MONTH_DISCOUNT_RATE,
                                              0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(NVL(T.UNAFFIRM_QTY, 0) *
                                         NVL(T.TRANSFER_LIST_PRICE, 0) *
                                         NVL(T.TRANSFER_DISCOUNT_RATE, 0) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT, --锁定代理商折让(未确认数量*直发列表价*直发扣率/100),
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_LG_SHIP_PLAN T
                                INNER JOIN T_CUSTOMER_ACCOUNT A
                                ON (A.ACCOUNT_ID = T.TRANSFER_ACCOUNT_ID AND A.ENTITY_ID = IN_ENTITY_ID
                                AND A.SALES_CENTER_ID = V_CENTER_ID)
                               WHERE T.TRANSFER_ENTITY_ID = IN_ENTITY_ID
                                 AND T.TRANSFER_ACCOUNT_ID =
                                     NVL(VN_ACCOUNT_ID, T.TRANSFER_ACCOUNT_ID)
                                 AND T.TRANSFER_CUSTOMER_ID =
                                     NVL(VN_CUSTOMER_ID,
                                         T.TRANSFER_CUSTOMER_ID)
                                 AND (IN_DISCOUNT_TYPE IS NULL OR
                                     T.TRANSFER_DISCOUNT_TYPE =
                                     IN_DISCOUNT_TYPE OR
                                     (T.TRANSFER_DISCOUNT_TYPE IS NULL AND
                                     IN_DISCOUNT_TYPE = 'COMMON'))
                                 AND T.STATUS IN ('00', '01') --撤销单据没有锁款
                                 AND T.TRANSFER_LOCK_AMOUNT_FLAG = 'Y'
                                 AND T.TRANSFER_ITEM_MAIN_TYPE IS NOT NULL
                              UNION ALL
                              --制定发货需求计划下达（直发客户） 发货通知单未生成销售单
                              SELECT A.TRANSFER_ENTITY_ID ENTITY_ID,
                               A.TRANSFER_CUSTOMER_ID CUSTOMER_ID,
                               A.TRANSFER_CUSTOMER_CODE CUSTOMER_CODE,
                               A.TRANSFER_CUSTOMER_NAME AS CUSTOMER_NAME,
                               A.TRANSFER_ACCOUNT_ID ACCOUNT_ID,
                               A.TRANSFER_ACCOUNT_CODE ACCOUNT_CODE,
                               A.TRANSFER_ACCOUNT_CODE ACCOUNT_NAME,
                     ACC.SALES_CENTER_ID,
                     ACC.SALES_CENTER_CODE,
                     ACC.SALES_CENTER_NAME,
                               B.TRANSFER_ITEM_MAIN_TYPE SALES_MAIN_TYPE,
                               NVL(B.TRANSFER_DISCOUNT_TYPE, 'COMMON') AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              DECODE(B.ORIGIN_ORIGIN_TYPE,'02',B.ORIGIN_ORIGIN_HEAD_ID,B.ORIGIN_ORDER_ID) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              DECODE(B.ORIGIN_ORIGIN_TYPE,'02',B.ORIGIN_ORIGIN_DOC_CODE,B.ORIGIN_ORDER_NUM) AS ORIGIN_ORDER_NUM,B.ORIGIN_ORDER_NUM AS ORDER_NUM,
                               '发货锁定到款（直发）' LOCK_METHOD,
                               NVL(ROUND( --锁定代理商到款((产品数量-已取消数量-已转采购数量)*直发列表价*(100-直发扣率-直发月返)/100)
                                         (NVL(B.ITEM_QTY, 0) -
                                         NVL(B.CANCEL_QTY, 0) -
                                         NVL(B.TRANSFER_TO_POX_QTY, 0)) *
                                         NVL(B.TRANSFER_LIST_PRICE, 0) *
                                         (100 -
                                         NVL(B.TRANSFER_DISCOUNT_RATE, 0) -
                                         NVL(B.TRANSFER_MONTH_DISCOUNT_RATE,
                                              0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND((NVL(B.ITEM_QTY, 0) -
                                         NVL(B.FACT_SHIP_QTY, 0) -
                                         NVL(B.CANCEL_QTY, 0) -
                                         NVL(B.TRANSFER_TO_POX_QTY, 0)) *
                                         NVL(B.TRANSFER_LIST_PRICE, 0) *
                                         NVL(B.TRANSFER_DISCOUNT_RATE, 0) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT, --锁定代理商折让((产品数量-已取消数量-已转采购数量)*直发列表价*直发扣率/100)
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_LG_SHIP_DOC A --发货通知单头
                               INNER JOIN T_LG_SHIP_DOC_LINE B
                                  ON (A.SHIP_DOC_ID = B.SHIP_DOC_ID) --发货通知单行
                                INNER JOIN T_CUSTOMER_ACCOUNT ACC
                                ON (ACC.ACCOUNT_ID = A.TRANSFER_ACCOUNT_ID AND ACC.ENTITY_ID = IN_ENTITY_ID
                                AND ACC.SALES_CENTER_ID = V_CENTER_ID)
                               WHERE A.TRANSFER_ENTITY_ID = IN_ENTITY_ID
                                 AND A.TRANSFER_ACCOUNT_ID =
                                     NVL(VN_ACCOUNT_ID, A.TRANSFER_ACCOUNT_ID)
                                 AND A.TRANSFER_CUSTOMER_ID =
                                     NVL(VN_CUSTOMER_ID,
                                         A.TRANSFER_CUSTOMER_ID)
                                 AND (IN_DISCOUNT_TYPE IS NULL OR
                                     B.TRANSFER_DISCOUNT_TYPE =
                                     IN_DISCOUNT_TYPE OR
                                     (B.TRANSFER_DISCOUNT_TYPE IS NULL AND
                                     IN_DISCOUNT_TYPE = 'COMMON'))
                                 AND A.DOC_STATUS <> '01' --单据状态 00正常 01红冲
                                 AND B.TRANSFER_LOCK_AMOUNT_FLAG = 'Y'
                                 AND B.TRANSFER_ITEM_MAIN_TYPE IS NOT NULL
                              UNION ALL
                              --送审锁款：已经送审未下达发运计划的锁款 提货订单 常规部分
                              SELECT A.ENTITY_ID ENTITY_ID,
                               A.CUSTOMER_ID CUSTOMER_ID,
                               A.CUSTOMER_CODE CUSTOMER_CODE,
                               A.CUSTOMER_NAME CUSTOMER_NAME,
                               A.ACCOUNT_ID ACCOUNT_ID,
                               A.ACCOUNT_CODE ACCOUNT_CODE,
                               A.ACCOUNT_NAME ACCOUNT_NAME,
                     ACC.SALES_CENTER_ID,
                     ACC.SALES_CENTER_CODE,
                     ACC.SALES_CENTER_NAME,
                               B.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               --'COMMON' AS DISCOUNT_TYPE,--常规部分
                               NVL(B.DISCOUNT_TYPE,'COMMON') AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              A.ORDER_HEAD_ID AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              A.ORDER_NUMBER ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                               /*DECODE(A.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'RS',
                                      '资源送审锁款')*/C.CODE_NAME LOCK_METHOD,
                               NVL(ROUND(CASE
                                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED 
                                             and NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT' THEN
                                             0
                                           --20200314 家用直发锁款调整
                                           WHEN (A.LOCK_AMOUNT_FLAG = 'S'
                                               --2016-09-23 TIANMZH修改，订金比例为空或小于0时，计算锁定到款，否则，锁定到款为0.
                                                AND (A.DOWN_PAY_SCALE IS NULL OR A.DOWN_PAY_SCALE < 0)) 
                                               OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                            (CASE
                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              WHEN A.ORDER_HEAD_STATE IN ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END)
                                           ELSE
                                            0
                                         END
                                         * DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               
                               --ADD TIANMZH 2016-09-13 ，增加锁定订金（锁款方式 = "送审锁款"，订金比例 > 0，锁定订金=锁定到款*订金比例）
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           WHEN (nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED AND NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT')
                                             or NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                             0
                                           WHEN A.LOCK_AMOUNT_FLAG = 'S' AND NVL(A.DOWN_PAY_SCALE, 0) > 0 THEN
                                            (CASE
                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) -
                                               NVL(B.CANCEL_QTY, 0) - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              WHEN A.ORDER_HEAD_STATE IN ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100 *
                                            A.DOWN_PAY_SCALE / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED 
                                             AND NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT' THEN
                                             0
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           --20200314 家用直发锁款调整
                                           WHEN (A.LOCK_AMOUNT_FLAG = 'S' AND (A.DOWN_PAY_SCALE IS NULL OR A.DOWN_PAY_SCALE < 0)) 
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                           --ADD BY LIZHEN 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                                            (CASE
                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              WHEN A.ORDER_HEAD_STATE IN ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END)
                                           ELSE
                                            0
                                         END
                                         * DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           WHEN (nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED and NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT')
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                             0
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           WHEN A.LOCK_AMOUNT_FLAG = 'S' AND NVL(A.DOWN_PAY_SCALE, 0) > 0 THEN
                                           --ADD BY LIZHEN 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                                            (CASE
                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                            --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                              WHEN A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) -
                                               NVL(B.CANCEL_QTY, 0) - (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) --20180105 hejy3 增加订金发货锁全款处理
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              WHEN A.ORDER_HEAD_STATE IN ('381', '679') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE
                                               0
                                            END) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100 *
                                            A.DOWN_PAY_SCALE / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_PLN_LG_ORDER_HEAD A --物流订单头表
                               INNER JOIN T_PLN_LG_ORDER_LINE B --物流订单行表
                                  ON (A.ORDER_HEAD_ID = B.ORDER_HEAD_ID)
                               INNER JOIN T_CUSTOMER_ACCOUNT ACC
                                ON (ACC.ACCOUNT_ID = A.ACCOUNT_ID AND ACC.ENTITY_ID = IN_ENTITY_ID
                                AND ACC.SALES_CENTER_ID = V_CENTER_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = A.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE A.ENTITY_ID = IN_ENTITY_ID
                                 AND A.ACCOUNT_ID =
                                     NVL(VN_ACCOUNT_ID, A.ACCOUNT_ID)
                                 AND A.CUSTOMER_ID =
                                     NVL(VN_CUSTOMER_ID, A.CUSTOMER_ID)
                                 AND (IN_DISCOUNT_TYPE IS NULL OR
                                     B.DISCOUNT_TYPE =
                                     IN_DISCOUNT_TYPE OR
                                     (B.DISCOUNT_TYPE IS NULL AND
                                     IN_DISCOUNT_TYPE = 'COMMON'))
                                 AND A.ORDER_HEAD_STATE IN
                                    --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                     ('20', '23', '381', '679', '1455', '2225', '304')
                                 AND A.LOCK_AMOUNT_FLAG IN ('S', 'RS')
                                 --AND A.SALES_CENTER_ID = V_CENTER_ID
                              UNION ALL
                              --HEJY3 送总部锁款
                              SELECT A.ENTITY_ID ENTITY_ID,
                               A.CUSTOMER_ID CUSTOMER_ID,
                               A.CUSTOMER_CODE CUSTOMER_CODE,
                               A.CUSTOMER_NAME CUSTOMER_NAME,
                               A.ACCOUNT_ID ACCOUNT_ID,
                               A.ACCOUNT_CODE ACCOUNT_CODE,
                               A.ACCOUNT_NAME ACCOUNT_NAME,
                               ACC.SALES_CENTER_ID,
                               ACC.SALES_CENTER_CODE,
                               ACC.SALES_CENTER_NAME,
                               B.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               --'COMMON' AS DISCOUNT_TYPE,--常规部分
                               NVL(B.DISCOUNT_TYPE,'COMMON') AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              A.ORDER_HEAD_ID AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              A.ORDER_NUMBER ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                               /*DECODE(A.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'RS',
                                      '资源送审锁款')*/C.CODE_NAME LOCK_METHOD,
                               NVL(ROUND(CASE
                                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED 
                                             AND NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT' THEN
                                             0
                                           --20200314 家用直发锁款调整
                                           WHEN (A.DOWN_PAY_SCALE IS NULL OR A.DOWN_PAY_SCALE < 0) 
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                            (CASE
                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                              WHEN ((A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and ha.Submit_To_Hq_Flag = 'Y')
                                                or a.Submit_To_Hq_Flag = 'Y') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE 0
                                            END)
                                           ELSE
                                            0
                                         END
                                         * DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               
                               --ADD TIANMZH 2016-09-13 ，增加锁定订金（锁款方式 = "送审锁款"，订金比例 > 0，锁定订金=锁定到款*订金比例）
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           WHEN (nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED and NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT')
                                             or NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                             0
                                           WHEN NVL(A.DOWN_PAY_SCALE, 0) > 0 THEN
                                            (CASE
                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                              WHEN ((A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and ha.Submit_To_Hq_Flag = 'Y')
                                                or a.Submit_To_Hq_Flag = 'Y') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE 0
                                            END) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100 *
                                            A.DOWN_PAY_SCALE / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           WHEN nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED
                                             AND NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT' THEN
                                             0
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           --20200314 家用直发锁款调整
                                           WHEN (A.DOWN_PAY_SCALE IS NULL OR A.DOWN_PAY_SCALE < 0) OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                           --ADD BY LIZHEN 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                                            (CASE
                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                              WHEN ((A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and ha.Submit_To_Hq_Flag = 'Y')
                                                or a.Submit_To_Hq_Flag = 'Y') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE 0
                                            END)
                                           ELSE
                                            0
                                         END
                                         * DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               NVL(ROUND(CASE
                                           --20200314 家用直发锁款调整
                                           WHEN (nvl(b.order_line_state,LG_LINE_STATE_NORMAL)=LG_LINE_STATE_CLOSED and NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT')
                                             OR NVL(B.IS_LOCK_AMOUNT, 'N') = 'Y' THEN
                                             0
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           WHEN NVL(A.DOWN_PAY_SCALE, 0) > 0 THEN
                                           --ADD BY LIZHEN 2015-11-30 T+3订单回写取消数量，并会释放款项，所以取消数量重算时不计入锁款
                                            (CASE
                                              WHEN NVL(B.IS_LOCK_AMOUNT, 'N') = 'NT' THEN
                                                NVL(B.CENTER_AFFIRM_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                              WHEN ((A.ORDER_HEAD_STATE IN ('20', '1455', '2225') and ha.Submit_To_Hq_Flag = 'Y')
                                                or a.Submit_To_Hq_Flag = 'Y') and nvl(b.order_line_state,LG_LINE_STATE_NORMAL)<>LG_LINE_STATE_CLOSED THEN
                                               NVL(DECODE(A.HQ_LG_ORDER_HEAD_ID,NULL,B.QUANTITY,0,B.QUANTITY,B.CENTER_AFFIRM_QUANTITY), 0) -
                                               NVL(B.AFFIRMED_QUANTITY, 0) - NVL(B.CANCEL_QTY, 0)
                                               -(NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0))
                                               -(nvl(b.direct_transport_qty,0)-nvl(b.already_direct_transport_qty,0)) --20180328 hejy3 已预约直发数量在发货通知单重算
                                              ELSE 0
                                            END) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100 *
                                            A.DOWN_PAY_SCALE / 100
                                           ELSE
                                            0
                                         END,
                                         2),
                                   0) LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_PLN_LG_ORDER_HEAD A --物流订单头表
                               INNER JOIN T_PLN_LG_ORDER_LINE B --物流订单行表
                                  ON (A.ORDER_HEAD_ID = B.ORDER_HEAD_ID)
                               INNER JOIN T_CUSTOMER_ACCOUNT ACC
                                ON (ACC.ACCOUNT_ID = A.ACCOUNT_ID AND ACC.ENTITY_ID = IN_ENTITY_ID
                                AND ACC.SALES_CENTER_ID = V_CENTER_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = A.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                                LEFT JOIN T_PLN_LG_ORDER_HEAD HA
                                  ON (HA.ORDER_HEAD_ID = A.HQ_LG_ORDER_HEAD_ID)
                               WHERE A.ENTITY_ID = IN_ENTITY_ID
                                 AND A.ACCOUNT_ID =
                                     NVL(VN_ACCOUNT_ID, A.ACCOUNT_ID)
                                 AND A.CUSTOMER_ID =
                                     NVL(VN_CUSTOMER_ID, A.CUSTOMER_ID)
                                 AND (IN_DISCOUNT_TYPE IS NULL OR
                                     B.DISCOUNT_TYPE =
                                     IN_DISCOUNT_TYPE OR
                                     (B.DISCOUNT_TYPE IS NULL AND
                                     IN_DISCOUNT_TYPE = 'COMMON'))
                                 AND A.ORDER_HEAD_STATE IN
                                    --2016-09-13 TIANMZH修改，增加'2225'，显示产能可视状态('2225'提货订单金额。
                                     ('20', '23', '381', '679', '1455', '2225', '304')
                                 AND A.LOCK_AMOUNT_FLAG IN ('HQ')
                              UNION ALL
                              --针对已结转总部主体且发货锁款的提货订单 常规部分
                              SELECT A.ENTITY_ID ENTITY_ID,
                               A.CUSTOMER_ID CUSTOMER_ID,
                               A.CUSTOMER_CODE CUSTOMER_CODE,
                               A.CUSTOMER_NAME CUSTOMER_NAME,
                               A.ACCOUNT_ID ACCOUNT_ID,
                               A.ACCOUNT_CODE ACCOUNT_CODE,
                               A.ACCOUNT_NAME ACCOUNT_NAME,
                     ACC.SALES_CENTER_ID,
                     ACC.SALES_CENTER_CODE,
                     ACC.SALES_CENTER_NAME,
                               B.SALES_MAIN_TYPE SALES_MAIN_TYPE,
                               --'COMMON' AS DISCOUNT_TYPE,--常规部分
                               NVL(B.DISCOUNT_TYPE,'COMMON') AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              A.ORDER_HEAD_ID AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              A.ORDER_NUMBER ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                               /*DECODE(A.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '发货锁款')*/C.CODE_NAME LOCK_METHOD,
                               NVL(ROUND(CASE
                                           WHEN NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT' THEN
                                            (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0))
                                           --ADD BY LIZHEN 2015-11-30 增加月返计算
                                            * (100 -
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                      NULL,
                                                      NVL(B.DISCOUNT_RATE, 0),
                                                      NVL(B.APPLY_DISCOUNT_RATE, 0)) -
                                            NVL(B.ORDERED_DISCOUNT_RATE, 0)) / 100
                                           ELSE 0
                                         END,
                                         2),
                                   0) LOCKED_AMOUNT,
                               0 LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND(CASE
                                           WHEN B.DISCOUNT_TYPE <> 'COMMON' THEN
                                             0
                                           WHEN NVL(B.IS_LOCK_AMOUNT, 'N') <> 'NT' THEN
                                            (NVL(B.transfer_hq_affirmed_qty,0)-NVL(B.SENDED_QTY,0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.LIST_PRICE, 0),
                                                   NVL(B.APPLY_LIST_PRICE, 0)) *
                                            DECODE(B.PROJECT_ORDER_TYPE,
                                                   NULL,
                                                   NVL(B.DISCOUNT_RATE, 0),
                                                   NVL(B.APPLY_DISCOUNT_RATE, 0)) / 100
                                           ELSE 0
                                         END
                                         ,2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               0 LOCKED_DIS_DP_AMOUNT --锁定折扣订金
                                FROM T_PLN_LG_ORDER_HEAD A --物流订单头表
                               INNER JOIN T_PLN_LG_ORDER_LINE B --物流订单行表
                                  ON (A.ORDER_HEAD_ID = B.ORDER_HEAD_ID)
                               INNER JOIN T_CUSTOMER_ACCOUNT ACC
                                ON (ACC.ACCOUNT_ID = A.ACCOUNT_ID AND ACC.ENTITY_ID = IN_ENTITY_ID
                                AND ACC.SALES_CENTER_ID = V_CENTER_ID)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = A.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE A.ENTITY_ID = IN_ENTITY_ID
                                 AND A.ACCOUNT_ID =
                                     NVL(VN_ACCOUNT_ID, A.ACCOUNT_ID)
                                 AND A.CUSTOMER_ID =
                                     NVL(VN_CUSTOMER_ID, A.CUSTOMER_ID)
                                 AND (IN_DISCOUNT_TYPE IS NULL OR
                                     B.DISCOUNT_TYPE =
                                     IN_DISCOUNT_TYPE OR
                                     (B.DISCOUNT_TYPE IS NULL AND
                                     IN_DISCOUNT_TYPE = 'COMMON'))
                                 AND A.ORDER_HEAD_STATE IN
                                     ('20', '23', '381', '679', '1455', '2225', '304')
                                 AND B.TRANSFER_HQ_AFFIRMED_QTY > 0
                                 
                              UNION ALL
                              --1.2、计划订单
                              SELECT POH.ENTITY_ID ENTITY_ID,
                               POH.CUSTOMER_ID CUSTOMER_ID,
                               POH.CUSTOMER_CODE CUSTOMER_CODE,
                               POH.CUSTOMER_NAME CUSTOMER_NAME,
                               POH.ACCOUNT_ID ACCOUNT_ID,
                               POH.ACCOUNT_CODE ACCOUNT_CODE,
                               POH.ACCOUNT_NAME ACCOUNT_NAME,
                     ACC.SALES_CENTER_ID,
                     ACC.SALES_CENTER_CODE,
                     ACC.SALES_CENTER_NAME,
                               NVL(POL.SALES_MAIN_TYPE,
                                   BI.SALES_MAIN_TYPE) SALES_MAIN_TYPE,
                               'COMMON' AS DISCOUNT_TYPE,
                              0 AS IS_DOWN_PAY,CAST(NULL AS NUMERIC) AS DOWN_PAY_SCALE,-- ADD YB LIANGYM2 2018-5-31 订金比例 暂时不用而是外面关联取订金比例
                              CAST(NULL AS NUMERIC) AS SRC_LG_ORDER_ID,-- ADD YB LIANGYM2 2018-5-31 来源提货订单ID
                              POH.ORDER_NUMBER ORIGIN_ORDER_NUM,NULL AS ORDER_NUM,
                               --POH.LOCK_AMOUNT_FLAG 送审锁款,(这一行写错了别名)
                               /*DECODE(POH.LOCK_AMOUNT_FLAG,
                                      'S',
                                      '送审锁款',
                                      'Y',
                                      '发货锁定到款')*/C.CODE_NAME LOCK_METHOD,
                               NVL(ROUND((CASE
                                            WHEN NVL(POH.DOWN_PAY_SCALE, -1) < 0 THEN
                                              CASE
                                               WHEN POH.FORM_STATE NOT IN
                                                    ('23',
                                                     '32',
                                                     '248',
                                                     '303',
                                                     '304',
                                                     '306') THEN
                                                NVL(POL.APPLY_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_IN_QTY, 0)
                                               WHEN POH.FORM_STATE IN ('23', '32') THEN
                                                NVL(POL.CAN_PRODUCE_QTY, 0) +
                                                NVL(POL.INV_AFFIRM_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_IN_QTY, 0)
                                               ELSE
                                                0
                                              END
                                            ELSE
                                              0
                                          END
                                         ) * POL.ITEM_PRICE *
                                         (100 -
                                         NVL(POL.DISCOUNT_RATE, 0) -
                                         NVL(POL.ORDERED_DISCOUNT_RATE,
                                              0)) / 100,
                                         2),
                                   0) LOCKED_AMOUNT,
                               NVL(ROUND((CASE
                                            WHEN POH.DOWN_PAY_SCALE > 0 THEN
                                              POH.DOWN_PAY_SCALE / 100 *
                                              CASE
                                               WHEN POH.FORM_STATE NOT IN
                                                    ('23',
                                                     '32',
                                                     '248',
                                                     '303',
                                                     '304',
                                                     '306') THEN
                                                NVL(POL.APPLY_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_IN_QTY, 0)
                                               WHEN POH.FORM_STATE IN ('23', '32') THEN
                                                NVL(POL.CAN_PRODUCE_QTY, 0) +
                                                NVL(POL.INV_AFFIRM_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_IN_QTY, 0)
                                               ELSE
                                                0
                                              END
                                            ELSE
                                              0
                                          END
                                         ) * POL.ITEM_PRICE *
                                         (100 -
                                         NVL(POL.DISCOUNT_RATE, 0) -
                                         NVL(POL.ORDERED_DISCOUNT_RATE,
                                              0)) / 100,
                                         2),
                                   0) LOCKED_DOWNPAY_AMOUNT, --锁定订金
                               NVL(ROUND((CASE
                                            WHEN NVL(POH.DOWN_PAY_SCALE, -1) < 0 THEN
                                              CASE
                                               WHEN POH.FORM_STATE NOT IN
                                                    ('23', '32', '248', '303', '304', '306') THEN
                                                NVL(POL.APPLY_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0)
                                               WHEN POH.FORM_STATE IN
                                                    ('23', '32') THEN--, '306'
                                                NVL(POL.CAN_PRODUCE_QTY, 0) +
                                                NVL(POL.INV_AFFIRM_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0)
                                               ELSE
                                                0
                                              END
                                            ELSE
                                              0
                                          END
                                         ) * POL.ITEM_PRICE *
                                         NVL(POL.DISCOUNT_RATE, 0) / 100,
                                         2),
                                   0) LOCKED_DISCOUNT_AMOUNT,
                               NVL(ROUND((CASE
                                            WHEN POH.DOWN_PAY_SCALE > 0 THEN
                                              POH.DOWN_PAY_SCALE / 100 *
                                              CASE
                                               WHEN POH.FORM_STATE NOT IN
                                                    ('23', '32', '248', '303', '304', '306') THEN
                                                NVL(POL.APPLY_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0)
                                               WHEN POH.FORM_STATE IN
                                                    ('23', '32') THEN--, '306'
                                                NVL(POL.CAN_PRODUCE_QTY, 0) +
                                                NVL(POL.INV_AFFIRM_QTY, 0) -
                                                NVL(POL.CARRY_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0) -
                                                NVL(POL.CANCEL_INV_CHECK_QTY, 0)
                                               ELSE
                                                0
                                              END
                                            ELSE
                                              0
                                          END
                                         ) * POL.ITEM_PRICE *
                                         NVL(POL.DISCOUNT_RATE, 0) / 100,
                                         2),
                                   0) AS LOCKED_DIS_DP_AMOUNT
                                FROM T_PLN_ORDER_HEAD POH --计划订单头表
                               INNER JOIN T_PLN_ORDER_LINE POL
                                  ON (POH.ORDER_HEAD_ID = POL.ORDER_HEAD_ID) --计划订单行表
                               INNER JOIN T_CUSTOMER_ACCOUNT ACC
                                ON (ACC.ACCOUNT_ID = POH.ACCOUNT_ID AND ACC.ENTITY_ID = IN_ENTITY_ID
                                AND ACC.SALES_CENTER_ID = V_CENTER_ID)
                                
                               INNER JOIN T_PLN_ORDER_TYPE POT
                                  ON (POT.ORDER_TYPE_ID = POH.ORDER_TYPE_ID) --订单类型表
                               INNER JOIN t_Bd_Item BI
                                  ON (Bi.Item_Id = Pol.Item_Id And
                                     Bi.Entity_Id = Pol.Entity_Id)
                                LEFT JOIN UP_CODELIST C
                                  ON (C.CODE_VALUE = POH.LOCK_AMOUNT_FLAG AND C.CODETYPE = 'plnlockMoneyFlag')
                               WHERE POH.ENTITY_ID = IN_ENTITY_ID
                                 AND POH.ACCOUNT_ID =
                                     NVL(VN_ACCOUNT_ID, POH.ACCOUNT_ID)
                                 AND POH.CUSTOMER_ID =
                                     NVL(VN_CUSTOMER_ID, POH.CUSTOMER_ID)
                                 AND (IN_DISCOUNT_TYPE IS NULL OR
                                     IN_DISCOUNT_TYPE = 'COMMON')
                                 AND NVL(POH.LOCK_AMOUNT_FLAG, 'N') = 'S'
                                 AND POH.FORM_STATE NOT IN
                                     ('19', '248', '303', '304', '305')
                                 --AND POH.SALES_CENTER_ID = V_CENTER_ID
                      ) BI
                                LEFT JOIN T_PLN_LG_ORDER_HEAD LO
                                ON (LO.ORDER_HEAD_ID = BI.SRC_LG_ORDER_ID
                                AND LO.ENTITY_ID = IN_ENTITY_ID
                                AND (VN_CUSTOMER_ID IS NULL OR 0 >= VN_CUSTOMER_ID OR LO.CUSTOMER_ID = VN_CUSTOMER_ID)
                                AND (VN_ACCOUNT_ID IS NULL OR 0 >= VN_ACCOUNT_ID OR LO.ACCOUNT_ID = VN_ACCOUNT_ID)
                                )
              --WHERE CO.SALES_CENTER_ID = V_CENTER_ID
               GROUP BY BI.ENTITY_ID,
                        BI.CUSTOMER_ID,
                        BI.SALES_CENTER_ID,
                        BI.SALES_CENTER_CODE,
                        BI.SALES_CENTER_NAME,
                        BI.CUSTOMER_CODE,
                        BI.CUSTOMER_NAME,
                        BI.ACCOUNT_ID,
                        BI.ACCOUNT_CODE,
                        BI.ACCOUNT_NAME,
                        BI.SALES_MAIN_TYPE,
                        PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(BI.ENTITY_ID,
                                                               BI.CUSTOMER_ID,
                                                               BI.SALES_MAIN_TYPE,
                                                               BI.ACCOUNT_ID),
                        BI.DISCOUNT_TYPE,
                        BI.ORIGIN_ORDER_NUM,BI.ORDER_NUM,
                        LO.DOWN_PAY_SCALE,--锁定订金比例  update 2018/5/31 by 梁颜明
                        BI.LOCK_METHOD
              --梁颜明 2016-09-24修改 锁定到款拆分为普通的锁款和订金 计算锁定到款时两值要相加
              HAVING 0 <> SUM(BI.LOCKED_DISCOUNT_AMOUNT + BI.LOCKED_DIS_DP_AMOUNT)
              --
              OR 0 <> SUM(BI.LOCKED_AMOUNT + BI.LOCKED_DOWNPAY_AMOUNT)
              --
              ) V
       INNER JOIN T_CREDIT_GROUP CG
          ON (CG.ENTITY_ID = V.ENTITY_ID AND
             CG.CREDIT_GROUP_ID = V.CREDIT_GROUP_ID)
       WHERE (VN_CREDIT_GROUP_ID IS NULL OR 0 >= VN_CREDIT_GROUP_ID
             --
             OR VN_CREDIT_GROUP_ID = V.CREDIT_GROUP_ID)
         AND EXISTS (SELECT VA.ACCOUNT_ID
                FROM CIMS.V_BD_USER_ACC_PRIV VA
               WHERE VA.USER_CODE = IN_USER_ACC
                 AND VA.ENTITY_ID = IN_ENTITY_ID
                 AND VA.ACCOUNT_ID = V.ACCOUNT_ID)
                 ;
    R_LOCK_AMOUT C_LOCK_AMOUT%ROWTYPE;
  
  BEGIN
    VN_CUSTOMER_ID := IN_CUSTOMER_ID;
    VN_ACCOUNT_ID := IN_ACCOUNT_ID;
    VN_CREDIT_GROUP_ID := IN_CREDIT_GROUP_ID;
    V_CENTER_ID := IN_SALES_CENTER_ID;
    IF 0 >= VN_CUSTOMER_ID THEN
      VN_CUSTOMER_ID := NULL;
    END IF;
    IF 0 >= VN_ACCOUNT_ID THEN
      VN_ACCOUNT_ID := NULL;
    END IF;
    IF 0 >= VN_CREDIT_GROUP_ID THEN
      VN_CREDIT_GROUP_ID := NULL;
    END IF;
    IF 0 >= V_CENTER_ID THEN
      V_CENTER_ID := NULL;
    END IF;
    --入参没有中心，有客户、账户、主体，根据客户账户获取中心ID
    IF V_CENTER_ID IS NULL AND VN_ACCOUNT_ID IS NOT NULL THEN
      SELECT V.SALES_CENTER_ID
        INTO V_CENTER_ID
        FROM V_CUSTOMER_ACCOUNT_SALECENTER V
       WHERE V.CUSTOMER_ID = NVL(VN_CUSTOMER_ID,V.CUSTOMER_ID)
         AND V.ACCOUNT_ID = VN_ACCOUNT_ID
         AND V.ENTITY_ID = IN_ENTITY_ID;
    END IF;
    
    IF V_CENTER_ID IS NOT NULL THEN
      OPEN C_LOCK_AMOUT;
    ELSE
      OPEN C_LOCK_AMOUT_NOCENTER;
    END IF;
  
    --FOR R_LOCK_AMOUT IN C_LOCK_AMOUT
    LOOP
      IF V_CENTER_ID IS NOT NULL THEN
        FETCH C_LOCK_AMOUT INTO R_LOCK_AMOUT;
        EXIT WHEN C_LOCK_AMOUT%NOTFOUND;
      ELSE
        FETCH C_LOCK_AMOUT_NOCENTER INTO R_LOCK_AMOUT;
        EXIT WHEN C_LOCK_AMOUT_NOCENTER%NOTFOUND;
      END IF;
      V_LOCK_AMOUT_ROW := OBJ_CREDIT_LOCK_AMOUNT(R_LOCK_AMOUT.ENTITY_ID,
                                                 R_LOCK_AMOUT.CUSTOMER_ID,
                                                 R_LOCK_AMOUT.CUSTOMER_CODE,
                                                 R_LOCK_AMOUT.CUSTOMER_NAME,
                                                 R_LOCK_AMOUT.ACCOUNT_ID,
                                                 R_LOCK_AMOUT.ACCOUNT_CODE,
                                                 R_LOCK_AMOUT.ACCOUNT_NAME,
                                                 R_LOCK_AMOUT.SALES_MAIN_TYPE,
                                                 R_LOCK_AMOUT.ORIGIN_ORDER_NUM,R_LOCK_AMOUT.ORDER_NUM,
                                                 R_LOCK_AMOUT.DOWN_PAY_SCALE,--锁定订金比例  update 2018/5/31 by 梁颜明
                                                 R_LOCK_AMOUT.LOCK_METHOD,
                                                 R_LOCK_AMOUT.LOCKED_AMOUNT,
                                                 R_LOCK_AMOUT.LOCKED_DISCOUNT_AMOUNT,
                                                 R_LOCK_AMOUT.LOCKED_DOWNPAY_AMOUNT,
                                                 R_LOCK_AMOUT.LOCKED_DIS_DP_AMOUNT,
                                                 R_LOCK_AMOUT.SALES_CENTER_ID,
                                                 R_LOCK_AMOUT.SALES_CENTER_CODE,
                                                 R_LOCK_AMOUT.SALES_CENTER_NAME,
                                                 R_LOCK_AMOUT.CREDIT_GROUP_ID,
                                                 R_LOCK_AMOUT.CREDIT_GROUP_NAME,
                                                 R_LOCK_AMOUT.DISCOUNT_TYPE);
      PIPE ROW(V_LOCK_AMOUT_ROW);
    
    END LOOP;
    
    IF V_CENTER_ID IS NOT NULL THEN
      CLOSE C_LOCK_AMOUT;
    ELSE
      CLOSE C_LOCK_AMOUT_NOCENTER;
    END IF;
    
    RETURN;
  END F_GET_LOCK_AMOUNT;

  FUNCTION F_GET_CUSTOMER_AMOUNT(IN_ENTITY_ID         NUMBER, --主体ID 不能为空
                                 IS_CUSTOMER_CODE     VARCHAR2, --客户ID 可以为空
                                 IS_SALES_CENTER_CODE VARCHAR2, --营销中心 可以为空
                                 IS_ACCOUNT_STATUS    VARCHAR2, --
                                 IS_DISCOUNT_TYPE     VARCHAR2, --折让方式 可以为空
                                 IS_FREEZE_DATE       VARCHAR2, --不能为空
                                 IS_USER_ACC          VARCHAR2, --用户账号 不能为空
                                 IS_ACCOUNT_CODE      VARCHAR2 DEFAULT NULL
                                 ) RETURN TAB_SALES_DIS_AMOUNT_FREEZE
    PIPELINED AS
    V_CUSTOMER_AMOUNT_ROW OBJ_SALES_DIS_AMOUNT_FREEZE;
    VD_FREEZE_DATE        DATE;
  
    CURSOR C_CUSTOMER_AMOUNT IS
    SELECT DO.*,1 AS AMOUNT_ZERO/*,(CASE WHEN (DO.RECEIVED_AMOUNT <> 0 OR DO.SALES_AMOUNT <> 0 OR DO.LOCK_RECEIVED_AMOUNT <> 0 OR DO.DELAYPAY_AMOUNT <> 0 OR DO.TEMP_DELAYPAY_AMOUNT <> 0
   OR DO.DISCOUNT_AMOUNT <> 0 OR DO.APPLIED_DISCOUNT_AMOUNT <> 0 OR DO.FREEZE_DISCOUNT_AMOUNT <> 0 OR DO.FREEZE_DELAY_AMOUNT <> 0 OR DO.LOCK_DISCOUNT_AMOUNT <> 0
   OR DO.DISPAY_AMOUNT <> 0 OR DO.THREE_NOT_PAY <> 0 OR DO.RESOURCE_AMOUNT <> 0 OR DO.LOCK_RESOURCE_AMOUNT <> 0 OR DO.TRANSACTION_AMOUNT <> 0 OR DO.MPAY_STREAM_AMOUNT <> 0 OR DO.MPAY_CASH_AMOUNT <> 0)
   THEN 1 ELSE 0 END) AS AMOUNT_ZERO*/ FROM (SELECT 'B' || F.ACCOUNT_AMOUNT_ID AS ACCOUNT_AMOUNT_ID,
       F.ENTITY_ID,
       F.CREDIT_GROUP_ID,
       F.PROJ_NUMBER,
       F.CUSTOMER_ID,
       F.CUSTOMER_CODE,
       F.CUSTOMER_NAME,
       F.ACCOUNT_ID,
       F.ACCOUNT_CODE,
       F.ACCOUNT_NAME,
       T.ACCOUNT_STATUS,
       CAST('COMMON' AS VARCHAR2(100)) AS DISCOUNT_TYPE,
       F.SALES_YEAR_ID,
       (F.RECEIVED_AMOUNT - NVL(T1.RECEIVED_AMOUNT,0)) AS RECEIVED_AMOUNT,
       (F.SALES_AMOUNT + NVL(T1.RECEIPT_AMOUNT, 0) -
       NVL(T1.SALES_AMOUNT, 0)) AS SALES_AMOUNT,
       (F.LOCK_RECEIVED_AMOUNT - NVL(T1.LOCK_AMOUNT, 0)) AS LOCK_RECEIVED_AMOUNT,
       F.DELAYPAY_AMOUNT,
       F.TEMP_DELAYPAY_AMOUNT,
       F.DISCOUNT_AMOUNT,
       F.APPLIED_DISCOUNT_AMOUNT,
       F.FREEZE_DISCOUNT_AMOUNT,
       F.FREEZE_DELAY_AMOUNT,
       F.LOCK_DISCOUNT_AMOUNT,
       F.DISPAY_AMOUNT,
       F.THREE_NOT_PAY,
       F.RESOURCE_AMOUNT,
       F.LOCK_RESOURCE_AMOUNT,
       F.TRANSACTION_AMOUNT,
       (F.RESOURCE_AMOUNT - F.TRANSACTION_AMOUNT) AS RESOURCE_LEFT_AMOUNT,
       /*0 AS MPAY_STREAM_AMOUNT,
       0 AS MPAY_CASH_AMOUNT,*/
       F.MPAY_STREAM_AMOUNT AS MPAY_STREAM_AMOUNT,
       F.MPAY_CASH_AMOUNT AS MPAY_CASH_AMOUNT,
       F.AMOUNT_CRTL_FLAG,
       F.DISCONT_CRTL_FLAG,
       F.CREATION_DATE,
       F.CREATED_BY,
       F.LAST_UPDATE_DATE,
       F.LAST_UPDATED_BY,
       F.PRE_FIELD_01,
       F.PRE_FIELD_02,
       F.PRE_FIELD_03,
       F.PRE_FIELD_04,
       F.PRE_FIELD_05,
       F.PRE_FIELD_06,
       TRUNC(SYSDATE) AS FREEZE_DATE,
       O.SALES_CENTER_ID,
       O.SALES_CENTER_CODE,
       O.SALES_CENTER_NAME
  FROM T_SALES_ACCOUNT_AMOUNT F
 INNER JOIN T_CUSTOMER_ACCOUNT T
    ON (F.ACCOUNT_ID = T.ACCOUNT_ID AND F.ENTITY_ID = IN_ENTITY_ID)
  LEFT JOIN (SELECT A.ENTITY_ID,
                    PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(A.ENTITY_ID,
                                                           A.CUSTOMER_ID,
                                                           A.SALES_MAIN_TYPE,
                                                           A.ACCOUNT_ID) AS CREDIT_GROUP_ID,
                    A.CUSTOMER_ID,
                    A.CUSTOMER_CODE,
                    A.CUSTOMER_NAME,
                    A.ACCOUNT_ID,
                    O1.SALES_CENTER_ID,
                    O1.SALES_CENTER_CODE,
                    O1.SALES_CENTER_NAME,
                    SUM(A.RECEIPT_AMOUNT) AS RECEIPT_AMOUNT,
                    SUM(A.SALES_AMOUNT) AS SALES_AMOUNT,
                    SUM(A.LOCK_AMOUNT) AS LOCK_AMOUNT,
                    SUM(A.RECEIVED_AMOUNT) AS RECEIVED_AMOUNT
               FROM T_CREDIT_DISCOUNT_AMOUNT A
                      
                     INNER JOIN T_CUSTOMER_ACCOUNT T1
                        ON (A.ACCOUNT_ID = T1.ACCOUNT_ID AND A.ENTITY_ID = IN_ENTITY_ID)
                     LEFT JOIN T_CUSTOMER_ACC_ORG_RELATION AR1
                        ON (AR1.ACCOUNT_ID = A.ACCOUNT_ID)
                      LEFT JOIN T_CUSTOMER_ORG O1
                        ON (O1.CUSTOMER_ORG_ID = AR1.CUSTOMER_ORG_ID AND
                           O1.ENTITY_ID = A.ENTITY_ID AND O1.CUSTOMER_ID = A.CUSTOMER_ID)
                     
               WHERE A.ENTITY_ID = IN_ENTITY_ID AND EXISTS (SELECT 1 FROM V_BD_USER_ACC_PRIV V WHERE V.ACCOUNT_ID = A.ACCOUNT_ID AND V.USER_CODE = IS_USER_ACC AND V.ENTITY_ID = IN_ENTITY_ID)
               AND (IS_CUSTOMER_CODE IS NULL OR IS_CUSTOMER_CODE = A.CUSTOMER_CODE)
               AND (IS_SALES_CENTER_CODE IS NULL OR IS_SALES_CENTER_CODE = O1.SALES_CENTER_CODE)
               AND (IS_ACCOUNT_STATUS IS NULL OR IS_ACCOUNT_STATUS = T1.ACCOUNT_STATUS)
               AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON' OR IS_DISCOUNT_TYPE = A.DISCOUNT_TYPE)
               AND (A.RECEIPT_AMOUNT <> 0 OR A.LOCK_AMOUNT <> 0 OR A.SALES_AMOUNT <> 0 OR A.RECEIVED_AMOUNT <> 0)
              GROUP BY A.ENTITY_ID,
                       PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(A.ENTITY_ID,
                                                              A.CUSTOMER_ID,
                                                              A.SALES_MAIN_TYPE,
                                                              A.ACCOUNT_ID),
                       A.CUSTOMER_ID,
                       A.CUSTOMER_CODE,
                       A.CUSTOMER_NAME,
                       A.ACCOUNT_ID,
                       O1.SALES_CENTER_ID,
                       O1.SALES_CENTER_CODE,
                       O1.SALES_CENTER_NAME) T1
    ON (F.ENTITY_ID = T1.ENTITY_ID AND F.CUSTOMER_ID = T1.CUSTOMER_ID AND
       F.ACCOUNT_ID = T1.ACCOUNT_ID AND
       F.CREDIT_GROUP_ID = T1.CREDIT_GROUP_ID)
  LEFT JOIN T_CUSTOMER_ACC_ORG_RELATION AR
    ON (AR.ACCOUNT_ID = F.ACCOUNT_ID)
  LEFT JOIN T_CUSTOMER_ORG O
    ON (O.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID AND
       O.ENTITY_ID = F.ENTITY_ID AND O.CUSTOMER_ID = F.CUSTOMER_ID)
    WHERE F.ENTITY_ID = IN_ENTITY_ID AND EXISTS (SELECT 1 FROM V_BD_USER_ACC_PRIV V WHERE V.ACCOUNT_ID = F.ACCOUNT_ID AND V.USER_CODE = IS_USER_ACC AND V.ENTITY_ID = IN_ENTITY_ID)
    AND (IS_CUSTOMER_CODE IS NULL OR IS_CUSTOMER_CODE = F.CUSTOMER_CODE)
    AND (IS_SALES_CENTER_CODE IS NULL OR IS_SALES_CENTER_CODE = O.SALES_CENTER_CODE)--
    AND (IS_ACCOUNT_STATUS IS NULL OR IS_ACCOUNT_STATUS = T.ACCOUNT_STATUS)
    AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON')
    /*AND (F.RECEIVED_AMOUNT <> 0 OR F.SALES_AMOUNT <> 0 OR F.LOCK_RECEIVED_AMOUNT <> 0 OR F.DELAYPAY_AMOUNT <> 0 OR F.TEMP_DELAYPAY_AMOUNT <> 0
   OR F.DISCOUNT_AMOUNT <> 0 OR F.APPLIED_DISCOUNT_AMOUNT <> 0 OR F.FREEZE_DISCOUNT_AMOUNT <> 0 OR F.LOCK_DISCOUNT_AMOUNT <> 0
   OR F.DISPAY_AMOUNT <> 0 OR F.THREE_NOT_PAY <> 0 OR F.RESOURCE_AMOUNT <> 0 OR F.LOCK_RESOURCE_AMOUNT <> 0 OR F.TRANSACTION_AMOUNT <> 0 OR F.MPAY_STREAM_AMOUNT <> 0 OR F.MPAY_CASH_AMOUNT <> 0)*/
UNION ALL
SELECT 'A' || MAX(DA.DISCOUNT_AMOUNT_ID) AS ACCOUNT_AMOUNT_ID,
       DA.ENTITY_ID,
       PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(DA.ENTITY_ID,
                                              DA.CUSTOMER_ID,
                                              DA.SALES_MAIN_TYPE,
                                              DA.ACCOUNT_ID) AS CREDIT_GROUP_ID,
       NULL AS PROJ_NUMBER,
       DA.CUSTOMER_ID,
       DA.CUSTOMER_CODE,
       DA.CUSTOMER_NAME,
       DA.ACCOUNT_ID,
       T.ACCOUNT_CODE,
       T.ACCOUNT_NAME,
       T.ACCOUNT_STATUS,
       DA.DISCOUNT_TYPE,
       NULL AS SALES_YEAR_ID,
       SUM(DA.RECEIPT_AMOUNT+DA.RECEIVED_AMOUNT) AS RECEIVED_AMOUNT,
       SUM(DA.SALES_AMOUNT) AS SALES_AMOUNT,
       SUM(DA.LOCK_AMOUNT) AS LOCK_RECEIVED_AMOUNT,
       0 AS DELAYPAY_AMOUNT,
       0 AS TEMP_DELAYPAY_AMOUNT,
       0 AS DISCOUNT_AMOUNT,
       0 AS APPLIED_DISCOUNT_AMOUNT,
       0 AS FREEZE_DISCOUNT_AMOUNT,
       0 AS FREEZE_DELAY_AMOUNT,
       0 AS LOCK_DISCOUNT_AMOUNT,
       0 AS DISPAY_AMOUNT,
       0 AS THREE_NOT_PAY,
       0 AS RESOURCE_AMOUNT,
       0 AS LOCK_RESOURCE_AMOUNT,
       0 AS TRANSACTION_AMOUNT,
       0 AS RESOURCE_LEFT_AMOUNT,
       0 AS MPAY_STREAM_AMOUNT,
       0 AS MPAY_CASH_AMOUNT,
       NULL AS AMOUNT_CRTL_FLAG,
       NULL AS DISCONT_CRTL_FLAG,
       NULL AS CREATION_DATE,
       NULL AS CREATED_BY,
       NULL AS LAST_UPDATE_DATE,
       NULL AS LAST_UPDATED_BY,
       NULL AS PRE_FIELD_01,
       NULL AS PRE_FIELD_02,
       NULL AS PRE_FIELD_03,
       NULL AS PRE_FIELD_04,
       NULL AS PRE_FIELD_05,
       NULL AS PRE_FIELD_06,
       TRUNC(SYSDATE) AS FREEZE_DATE,
       DA.SALES_CENTER_ID,
       DA.SALES_CENTER_CODE,
       DA.SALES_CENTER_NAME
  FROM T_CREDIT_DISCOUNT_AMOUNT DA
 INNER JOIN T_CUSTOMER_ACCOUNT T ON (DA.ACCOUNT_ID = T.ACCOUNT_ID)
 LEFT JOIN T_CUSTOMER_ACC_ORG_RELATION AR ON (AR.ACCOUNT_ID = DA.ACCOUNT_ID)
 LEFT JOIN T_CUSTOMER_ORG O
 ON (O.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID AND O.ENTITY_ID = DA.ENTITY_ID AND O.CUSTOMER_ID = DA.CUSTOMER_ID)
         
 WHERE DA.ENTITY_ID = IN_ENTITY_ID AND EXISTS (SELECT 1 FROM V_BD_USER_ACC_PRIV V WHERE V.ACCOUNT_ID = DA.ACCOUNT_ID AND V.USER_CODE = IS_USER_ACC AND V.ENTITY_ID = IN_ENTITY_ID)
 AND (IS_CUSTOMER_CODE IS NULL OR IS_CUSTOMER_CODE = DA.CUSTOMER_CODE)
 AND (IS_SALES_CENTER_CODE IS NULL OR IS_SALES_CENTER_CODE = O.SALES_CENTER_CODE)--
 AND (IS_ACCOUNT_STATUS IS NULL OR IS_ACCOUNT_STATUS = T.ACCOUNT_STATUS)
 AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = DA.DISCOUNT_TYPE)
 AND (DA.RECEIPT_AMOUNT <> 0 OR DA.LOCK_AMOUNT <> 0 OR DA.SALES_AMOUNT <> 0 OR DA.RECEIVED_AMOUNT <> 0)
 GROUP BY DA.ENTITY_ID,
          PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(DA.ENTITY_ID,
                                                 DA.CUSTOMER_ID,
                                                 DA.SALES_MAIN_TYPE,
                                                 DA.ACCOUNT_ID),
          DA.CUSTOMER_ID,
          DA.CUSTOMER_CODE,
          DA.CUSTOMER_NAME,
          DA.ACCOUNT_ID,
          T.ACCOUNT_CODE,
          T.ACCOUNT_NAME,
          T.ACCOUNT_STATUS,
          DA.DISCOUNT_TYPE,
          DA.SALES_CENTER_ID,
          DA.SALES_CENTER_CODE,
          DA.SALES_CENTER_NAME
          --ORDER BY DA.ENTITY_ID,DA.CUSTOMER_ID,DA.ACCOUNT_ID,DA.DISCOUNT_TYPE--,CREDIT_GROUP_ID
          ) DO-- ORDER BY ENTITY_ID,CUSTOMER_ID,ACCOUNT_ID,CREDIT_GROUP_ID,DISCOUNT_TYPE
          ORDER BY ENTITY_ID,CUSTOMER_ID,ACCOUNT_ID,DISCOUNT_TYPE
    ;
    CURSOR C_CUSTOMER_AMOUNT_CM IS
    SELECT 'B' || F.ACCOUNT_AMOUNT_ID AS ACCOUNT_AMOUNT_ID,
       F.ENTITY_ID,
       F.CREDIT_GROUP_ID,
       F.PROJ_NUMBER,
       F.CUSTOMER_ID,
       F.CUSTOMER_CODE,
       F.CUSTOMER_NAME,
       F.ACCOUNT_ID,
       F.ACCOUNT_CODE,
       F.ACCOUNT_NAME,
       T.ACCOUNT_STATUS,
       CAST('COMMON' AS VARCHAR2(100)) AS DISCOUNT_TYPE,
       F.SALES_YEAR_ID,
       (F.RECEIVED_AMOUNT - NVL(T1.RECEIVED_AMOUNT,0)) AS RECEIVED_AMOUNT,
       (F.SALES_AMOUNT + NVL(T1.RECEIPT_AMOUNT, 0) -
       NVL(T1.SALES_AMOUNT, 0)) AS SALES_AMOUNT,
       (F.LOCK_RECEIVED_AMOUNT - NVL(T1.LOCK_AMOUNT, 0)) AS LOCK_RECEIVED_AMOUNT,
       F.DELAYPAY_AMOUNT,
       F.TEMP_DELAYPAY_AMOUNT,
       F.DISCOUNT_AMOUNT,
       F.APPLIED_DISCOUNT_AMOUNT,
       F.FREEZE_DISCOUNT_AMOUNT,
       F.FREEZE_DELAY_AMOUNT,
       F.LOCK_DISCOUNT_AMOUNT,
       F.DISPAY_AMOUNT,
       F.THREE_NOT_PAY,
       F.RESOURCE_AMOUNT,
       F.LOCK_RESOURCE_AMOUNT,
       F.TRANSACTION_AMOUNT,
       (F.RESOURCE_AMOUNT - F.TRANSACTION_AMOUNT) AS RESOURCE_LEFT_AMOUNT,
       /*0 AS MPAY_STREAM_AMOUNT,
       0 AS MPAY_CASH_AMOUNT,*/
       F.MPAY_STREAM_AMOUNT AS MPAY_STREAM_AMOUNT,
       F.MPAY_CASH_AMOUNT AS MPAY_CASH_AMOUNT,
       F.AMOUNT_CRTL_FLAG,
       F.DISCONT_CRTL_FLAG,
       F.CREATION_DATE,
       F.CREATED_BY,
       F.LAST_UPDATE_DATE,
       F.LAST_UPDATED_BY,
       F.PRE_FIELD_01,
       F.PRE_FIELD_02,
       F.PRE_FIELD_03,
       F.PRE_FIELD_04,
       F.PRE_FIELD_05,
       F.PRE_FIELD_06,
       TRUNC(SYSDATE) AS FREEZE_DATE,
       O.SALES_CENTER_ID,
       O.SALES_CENTER_CODE,
       O.SALES_CENTER_NAME,
       1 AS AMOUNT_ZERO/*,
       (CASE WHEN (F.RECEIVED_AMOUNT <> 0 OR (F.SALES_AMOUNT + NVL(T1.RECEIPT_AMOUNT, 0) -
       NVL(T1.SALES_AMOUNT, 0)) <> 0 OR (F.LOCK_RECEIVED_AMOUNT - NVL(T1.LOCK_AMOUNT, 0)) <> 0 OR F.DELAYPAY_AMOUNT <> 0 OR F.TEMP_DELAYPAY_AMOUNT <> 0
   OR F.DISCOUNT_AMOUNT <> 0 OR F.APPLIED_DISCOUNT_AMOUNT <> 0 OR F.FREEZE_DISCOUNT_AMOUNT <> 0 OR F.LOCK_DISCOUNT_AMOUNT <> 0
   OR F.DISPAY_AMOUNT <> 0 OR F.THREE_NOT_PAY <> 0 OR F.RESOURCE_AMOUNT <> 0 OR F.LOCK_RESOURCE_AMOUNT <> 0 OR F.TRANSACTION_AMOUNT <> 0 OR F.MPAY_STREAM_AMOUNT <> 0 OR F.MPAY_CASH_AMOUNT <> 0)
      THEN 1 ELSE 0 END) AS AMOUNT_ZERO*/
  FROM T_SALES_ACCOUNT_AMOUNT F
 INNER JOIN T_CUSTOMER_ACCOUNT T
    ON (F.ACCOUNT_ID = T.ACCOUNT_ID AND F.ENTITY_ID = IN_ENTITY_ID)
  LEFT JOIN (SELECT A.ENTITY_ID,
                    PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(A.ENTITY_ID,
                                                           A.CUSTOMER_ID,
                                                           A.SALES_MAIN_TYPE,
                                                           A.ACCOUNT_ID) AS CREDIT_GROUP_ID,
                    A.CUSTOMER_ID,
                    A.CUSTOMER_CODE,
                    A.CUSTOMER_NAME,
                    A.ACCOUNT_ID,
                    O1.SALES_CENTER_ID,
                    O1.SALES_CENTER_CODE,
                    O1.SALES_CENTER_NAME,
                    SUM(A.RECEIPT_AMOUNT) AS RECEIPT_AMOUNT,
                    SUM(A.SALES_AMOUNT) AS SALES_AMOUNT,
                    SUM(A.LOCK_AMOUNT) AS LOCK_AMOUNT,
                    SUM(A.RECEIVED_AMOUNT) AS RECEIVED_AMOUNT
               FROM T_CREDIT_DISCOUNT_AMOUNT A
                      
                     INNER JOIN T_CUSTOMER_ACCOUNT T1
                        ON (A.ACCOUNT_ID = T1.ACCOUNT_ID AND A.ENTITY_ID = IN_ENTITY_ID)
                     LEFT JOIN T_CUSTOMER_ACC_ORG_RELATION AR1
                        ON (AR1.ACCOUNT_ID = A.ACCOUNT_ID)
                      LEFT JOIN T_CUSTOMER_ORG O1
                        ON (O1.CUSTOMER_ORG_ID = AR1.CUSTOMER_ORG_ID AND
                           O1.ENTITY_ID = A.ENTITY_ID AND O1.CUSTOMER_ID = A.CUSTOMER_ID)
               
               WHERE A.ENTITY_ID = IN_ENTITY_ID AND EXISTS (SELECT 1 FROM V_BD_USER_ACC_PRIV V WHERE V.ACCOUNT_ID = A.ACCOUNT_ID AND V.USER_CODE = IS_USER_ACC AND V.ENTITY_ID = IN_ENTITY_ID)
               AND (IS_CUSTOMER_CODE IS NULL OR IS_CUSTOMER_CODE = A.CUSTOMER_CODE)
               AND (IS_SALES_CENTER_CODE IS NULL OR IS_SALES_CENTER_CODE = O1.SALES_CENTER_CODE)
               AND (IS_ACCOUNT_STATUS IS NULL OR IS_ACCOUNT_STATUS = T1.ACCOUNT_STATUS)
               AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON' OR IS_DISCOUNT_TYPE = A.DISCOUNT_TYPE)
               AND (A.RECEIPT_AMOUNT <> 0 OR A.LOCK_AMOUNT <> 0 OR A.SALES_AMOUNT <> 0 OR A.RECEIVED_AMOUNT <> 0)
              GROUP BY A.ENTITY_ID,
                       PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(A.ENTITY_ID,
                                                              A.CUSTOMER_ID,
                                                              A.SALES_MAIN_TYPE,
                                                              A.ACCOUNT_ID),
                       A.CUSTOMER_ID,
                       A.CUSTOMER_CODE,
                       A.CUSTOMER_NAME,
                       A.ACCOUNT_ID,
                       O1.SALES_CENTER_ID,
                       O1.SALES_CENTER_CODE,
                       O1.SALES_CENTER_NAME) T1
    ON (F.ENTITY_ID = T1.ENTITY_ID AND F.CUSTOMER_ID = T1.CUSTOMER_ID AND
       F.ACCOUNT_ID = T1.ACCOUNT_ID AND
       F.CREDIT_GROUP_ID = T1.CREDIT_GROUP_ID)
  LEFT JOIN T_CUSTOMER_ACC_ORG_RELATION AR
    ON (AR.ACCOUNT_ID = F.ACCOUNT_ID)
  LEFT JOIN T_CUSTOMER_ORG O
    ON (O.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID AND
       O.ENTITY_ID = F.ENTITY_ID AND O.CUSTOMER_ID = F.CUSTOMER_ID)
    WHERE EXISTS (SELECT 1 FROM V_BD_USER_ACC_PRIV V WHERE V.ACCOUNT_ID = F.ACCOUNT_ID AND V.USER_CODE = IS_USER_ACC AND V.ENTITY_ID = IN_ENTITY_ID)
    AND (IS_CUSTOMER_CODE IS NULL OR IS_CUSTOMER_CODE = F.CUSTOMER_CODE)
    AND (IS_SALES_CENTER_CODE IS NULL OR IS_SALES_CENTER_CODE = O.SALES_CENTER_CODE)--
    AND (IS_ACCOUNT_STATUS IS NULL OR IS_ACCOUNT_STATUS = T.ACCOUNT_STATUS)
    AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON')
    /*AND (F.RECEIVED_AMOUNT <> 0 OR F.SALES_AMOUNT <> 0 OR F.LOCK_RECEIVED_AMOUNT <> 0 OR F.DELAYPAY_AMOUNT <> 0 OR F.TEMP_DELAYPAY_AMOUNT <> 0
   OR F.DISCOUNT_AMOUNT <> 0 OR F.APPLIED_DISCOUNT_AMOUNT <> 0 OR F.FREEZE_DISCOUNT_AMOUNT <> 0 OR F.LOCK_DISCOUNT_AMOUNT <> 0
   OR F.DISPAY_AMOUNT <> 0 OR F.THREE_NOT_PAY <> 0 OR F.RESOURCE_AMOUNT <> 0 OR F.LOCK_RESOURCE_AMOUNT <> 0 OR F.TRANSACTION_AMOUNT <> 0 OR F.MPAY_STREAM_AMOUNT <> 0 OR F.MPAY_CASH_AMOUNT <> 0)*/
    ;
    CURSOR C_CUSTOMER_AMOUNT_DIS IS
    SELECT 'A' || MAX(DA.DISCOUNT_AMOUNT_ID) AS ACCOUNT_AMOUNT_ID,
       DA.ENTITY_ID,
       PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(DA.ENTITY_ID,
                                              DA.CUSTOMER_ID,
                                              DA.SALES_MAIN_TYPE,
                                              DA.ACCOUNT_ID) AS CREDIT_GROUP_ID,
       NULL AS PROJ_NUMBER,
       DA.CUSTOMER_ID,
       DA.CUSTOMER_CODE,
       DA.CUSTOMER_NAME,
       DA.ACCOUNT_ID,
       T.ACCOUNT_CODE,
       T.ACCOUNT_NAME,
       T.ACCOUNT_STATUS,
       DA.DISCOUNT_TYPE,
       NULL AS SALES_YEAR_ID,
       SUM(DA.RECEIPT_AMOUNT + DA.RECEIVED_AMOUNT) AS RECEIVED_AMOUNT,
       SUM(DA.SALES_AMOUNT) AS SALES_AMOUNT,
       SUM(DA.LOCK_AMOUNT) AS LOCK_RECEIVED_AMOUNT,
       0 AS DELAYPAY_AMOUNT,
       0 AS TEMP_DELAYPAY_AMOUNT,
       0 AS DISCOUNT_AMOUNT,
       0 AS APPLIED_DISCOUNT_AMOUNT,
       0 AS FREEZE_DISCOUNT_AMOUNT,
       0 AS FREEZE_DELAY_AMOUNT,
       0 AS LOCK_DISCOUNT_AMOUNT,
       0 AS DISPAY_AMOUNT,
       0 AS THREE_NOT_PAY,
       0 AS RESOURCE_AMOUNT,
       0 AS LOCK_RESOURCE_AMOUNT,
       0 AS TRANSACTION_AMOUNT,
       0 AS RESOURCE_LEFT_AMOUNT,
       0 AS MPAY_STREAM_AMOUNT,
       0 AS MPAY_CASH_AMOUNT,
       NULL AS AMOUNT_CRTL_FLAG,
       NULL AS DISCONT_CRTL_FLAG,
       NULL AS CREATION_DATE,
       NULL AS CREATED_BY,
       NULL AS LAST_UPDATE_DATE,
       NULL AS LAST_UPDATED_BY,
       NULL AS PRE_FIELD_01,
       NULL AS PRE_FIELD_02,
       NULL AS PRE_FIELD_03,
       NULL AS PRE_FIELD_04,
       NULL AS PRE_FIELD_05,
       NULL AS PRE_FIELD_06,
       TRUNC(SYSDATE) AS FREEZE_DATE,
       DA.SALES_CENTER_ID,
       DA.SALES_CENTER_CODE,
       DA.SALES_CENTER_NAME,
       1 AS AMOUNT_ZERO
  FROM T_CREDIT_DISCOUNT_AMOUNT DA
 INNER JOIN T_CUSTOMER_ACCOUNT T ON (DA.ACCOUNT_ID = T.ACCOUNT_ID)
 LEFT JOIN T_CUSTOMER_ACC_ORG_RELATION AR ON (AR.ACCOUNT_ID = DA.ACCOUNT_ID)
 LEFT JOIN T_CUSTOMER_ORG O
 ON (O.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID AND O.ENTITY_ID = DA.ENTITY_ID AND O.CUSTOMER_ID = DA.CUSTOMER_ID)
 WHERE DA.ENTITY_ID = IN_ENTITY_ID AND EXISTS (SELECT 1 FROM V_BD_USER_ACC_PRIV V WHERE V.ACCOUNT_ID = DA.ACCOUNT_ID AND V.USER_CODE = IS_USER_ACC AND V.ENTITY_ID = IN_ENTITY_ID)
 AND (IS_CUSTOMER_CODE IS NULL OR IS_CUSTOMER_CODE = DA.CUSTOMER_CODE)
 AND (IS_SALES_CENTER_CODE IS NULL OR IS_SALES_CENTER_CODE = O.SALES_CENTER_CODE)--
 AND (IS_ACCOUNT_STATUS IS NULL OR IS_ACCOUNT_STATUS = T.ACCOUNT_STATUS)
 AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = DA.DISCOUNT_TYPE)
 AND (DA.RECEIPT_AMOUNT <> 0 OR DA.LOCK_AMOUNT <> 0 OR DA.SALES_AMOUNT <> 0 OR DA.RECEIVED_AMOUNT <> 0)
 GROUP BY DA.ENTITY_ID,
          PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(DA.ENTITY_ID,
                                                 DA.CUSTOMER_ID,
                                                 DA.SALES_MAIN_TYPE,
                                                 DA.ACCOUNT_ID),
          DA.CUSTOMER_ID,
          DA.CUSTOMER_CODE,
          DA.CUSTOMER_NAME,
          DA.ACCOUNT_ID,
          T.ACCOUNT_CODE,
          T.ACCOUNT_NAME,
          T.ACCOUNT_STATUS,
          DA.DISCOUNT_TYPE,
          DA.SALES_CENTER_ID,
          DA.SALES_CENTER_CODE,
          DA.SALES_CENTER_NAME
    ;
    CURSOR C_CUSTOMER_AMOUNT_F IS
    SELECT DO.*,
1 AS AMOUNT_ZERO
  FROM (SELECT T2.ACCOUNT_AMOUNT_ID
,T2.ENTITY_ID
,T2.CREDIT_GROUP_ID
,T2.PROJ_NUMBER
,T2.CUSTOMER_ID
,T2.CUSTOMER_CODE
,T2.CUSTOMER_NAME
,T2.ACCOUNT_ID
,T2.ACCOUNT_CODE
,T2.ACCOUNT_NAME
,T2.ACCOUNT_STATUS
,T2.DISCOUNT_TYPE
,T2.SALES_YEAR_ID
,(T2.RECEIVED_AMOUNT - NVL(T1.RECEIVED_AMOUNT,0)) AS RECEIVED_AMOUNT
,(T2.SALES_AMOUNT + NVL(T1.RECEIPT_AMOUNT,0) - NVL(T1.SALES_AMOUNT,0)) AS SALES_AMOUNT
,(T2.LOCK_RECEIVED_AMOUNT - NVL(T1.LOCK_AMOUNT,0)) AS LOCK_RECEIVED_AMOUNT
,T2.DELAYPAY_AMOUNT
,T2.TEMP_DELAYPAY_AMOUNT
,T2.DISCOUNT_AMOUNT
,T2.APPLIED_DISCOUNT_AMOUNT
,T2.FREEZE_DISCOUNT_AMOUNT
,T2.FREEZE_DELAY_AMOUNT
,T2.LOCK_DISCOUNT_AMOUNT
,T2.DISPAY_AMOUNT
,T2.THREE_NOT_PAY
,T2.RESOURCE_AMOUNT
,T2.LOCK_RESOURCE_AMOUNT
,T2.TRANSACTION_AMOUNT
,T2.RESOURCE_LEFT_AMOUNT
,T2.MPAY_STREAM_AMOUNT
,T2.MPAY_CASH_AMOUNT
,T2.AMOUNT_CRTL_FLAG
,T2.DISCONT_CRTL_FLAG
,T2.CREATION_DATE
,T2.CREATED_BY
,T2.LAST_UPDATE_DATE
,T2.LAST_UPDATED_BY
,T2.PRE_FIELD_01
,T2.PRE_FIELD_02
,T2.PRE_FIELD_03
,T2.PRE_FIELD_04
,T2.PRE_FIELD_05
,T2.PRE_FIELD_06
,T2.FREEZE_DATE
,T2.SALES_CENTER_ID
,T2.SALES_CENTER_CODE
,T2.SALES_CENTER_NAME FROM (
SELECT 'B' || MAX(F.CUST_AMOUNT_ID) AS ACCOUNT_AMOUNT_ID,
               F.ENTITY_ID,
               (CASE WHEN AA.ACCOUNT_AMOUNT_ID IS NOT NULL THEN AA.CREDIT_GROUP_ID WHEN DL.ACCOUNT_AMOUNT_ID IS NOT NULL THEN DL.CREDIT_GROUP_ID ELSE NULL END) AS CREDIT_GROUP_ID,
               NULL AS PROJ_NUMBER,
               F.CUSTOMER_ID,
               F.CUSTOMER_CODE,
               F.CUSTOMER_NAME,
               F.ACCOUNT_ID,
               F.ACCOUNT_CODE,
               F.ACCOUNT_NAME,
               T.ACCOUNT_STATUS,
               CAST('COMMON' AS VARCHAR2(100)) AS DISCOUNT_TYPE,
               NULL AS SALES_YEAR_ID,
               SUM(F.RECEIVED_AMOUNT) AS RECEIVED_AMOUNT,
               SUM(F.SALES_AMOUNT) AS SALES_AMOUNT,
               SUM(F.LOCK_RECEIVED_AMOUNT) AS LOCK_RECEIVED_AMOUNT,
               SUM(F.DELAYPAY_AMOUNT) AS DELAYPAY_AMOUNT,
               SUM(F.TEMP_DELAYPAY_AMOUNT) AS TEMP_DELAYPAY_AMOUNT,
               SUM(F.DISCOUNT_AMOUNT) AS DISCOUNT_AMOUNT,
               SUM(F.APPLIED_DISCOUNT_AMOUNT) AS APPLIED_DISCOUNT_AMOUNT,
               SUM(F.FREEZE_DISCOUNT_AMOUNT) AS FREEZE_DISCOUNT_AMOUNT,
               SUM(F.FREEZE_DELAY_AMOUNT) AS FREEZE_DELAY_AMOUNT,
               SUM(F.LOCK_DISCOUNT_AMOUNT) AS LOCK_DISCOUNT_AMOUNT,
               SUM(F.DISPAY_AMOUNT) AS DISPAY_AMOUNT,
               SUM(F.THREE_NOT_PAY) AS THREE_NOT_PAY,
               SUM(F.RESOURCE_AMOUNT) AS RESOURCE_AMOUNT,
               SUM(F.LOCK_RESOURCE_AMOUNT) AS LOCK_RESOURCE_AMOUNT,
               SUM(F.TRANSACTION_AMOUNT) AS TRANSACTION_AMOUNT,
               SUM(F.RESOURCE_AMOUNT - F.TRANSACTION_AMOUNT) AS RESOURCE_LEFT_AMOUNT,
               SUM(F.MPAY_STREAM_AMOUNT) AS MPAY_STREAM_AMOUNT,
               SUM(F.MPAY_CASH_AMOUNT) AS MPAY_CASH_AMOUNT,
               (CASE WHEN AA.ACCOUNT_AMOUNT_ID IS NOT NULL THEN AA.AMOUNT_CRTL_FLAG WHEN DL.ACCOUNT_AMOUNT_ID IS NOT NULL THEN DL.AMOUNT_CRTL_FLAG ELSE NULL END) AS AMOUNT_CRTL_FLAG,
               (CASE WHEN AA.ACCOUNT_AMOUNT_ID IS NOT NULL THEN AA.DISCONT_CRTL_FLAG WHEN DL.ACCOUNT_AMOUNT_ID IS NOT NULL THEN DL.DISCONT_CRTL_FLAG ELSE NULL END) AS DISCONT_CRTL_FLAG,
               NULL AS CREATION_DATE,
               NULL AS CREATED_BY,
               NULL AS LAST_UPDATE_DATE,
               NULL AS LAST_UPDATED_BY,
               NULL AS PRE_FIELD_01,
               NULL AS PRE_FIELD_02,
               NULL AS PRE_FIELD_03,
               NULL AS PRE_FIELD_04,
               NULL AS PRE_FIELD_05,
               NULL AS PRE_FIELD_06,
               F.FREEZE_DATE,
               O.SALES_CENTER_ID,
               O.SALES_CENTER_CODE,
               O.SALES_CENTER_NAME
          FROM T_SALES_AMOUNT_FREEZE F
         INNER JOIN T_CUSTOMER_ACCOUNT T
            ON (F.ACCOUNT_ID = T.ACCOUNT_ID AND F.ENTITY_ID = IN_ENTITY_ID)
          LEFT JOIN T_SALES_ACCOUNT_AMOUNT AA
            ON (AA.ACCOUNT_AMOUNT_ID = F.ACCOUNT_AMOUNT_ID)
          LEFT JOIN T_SALES_ACCOUNT_AMOUNT_DEL_LOG DL
            ON (DL.ACCOUNT_AMOUNT_ID = F.ACCOUNT_AMOUNT_ID)
          LEFT JOIN T_CUSTOMER_ACC_ORG_RELATION AR
            ON (AR.ACCOUNT_ID = F.ACCOUNT_ID)
          LEFT JOIN T_CUSTOMER_ORG O
            ON (O.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID AND
               O.ENTITY_ID = F.ENTITY_ID AND O.CUSTOMER_ID = F.CUSTOMER_ID)
         WHERE EXISTS (SELECT 1
                  FROM V_BD_USER_ACC_PRIV V
                 WHERE V.ACCOUNT_ID = F.ACCOUNT_ID
                   AND V.USER_CODE = IS_USER_ACC
                   AND V.ENTITY_ID = IN_ENTITY_ID)
    AND (IS_CUSTOMER_CODE IS NULL OR IS_CUSTOMER_CODE = F.CUSTOMER_CODE)
    AND (IS_SALES_CENTER_CODE IS NULL OR IS_SALES_CENTER_CODE = O.SALES_CENTER_CODE)--
    AND (IS_ACCOUNT_STATUS IS NULL OR IS_ACCOUNT_STATUS = T.ACCOUNT_STATUS)
    AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON')
    AND VD_FREEZE_DATE = F.FREEZE_DATE
         GROUP BY F.ENTITY_ID,
                  (CASE WHEN AA.ACCOUNT_AMOUNT_ID IS NOT NULL THEN AA.CREDIT_GROUP_ID WHEN DL.ACCOUNT_AMOUNT_ID IS NOT NULL THEN DL.CREDIT_GROUP_ID ELSE NULL END),
                  F.CUSTOMER_ID,
                  F.CUSTOMER_CODE,
                  F.CUSTOMER_NAME,
                  F.ACCOUNT_ID,
                  F.ACCOUNT_CODE,
                  F.ACCOUNT_NAME,
                  T.ACCOUNT_STATUS,
                  (CASE WHEN AA.ACCOUNT_AMOUNT_ID IS NOT NULL THEN AA.AMOUNT_CRTL_FLAG WHEN DL.ACCOUNT_AMOUNT_ID IS NOT NULL THEN DL.AMOUNT_CRTL_FLAG ELSE NULL END),
                  (CASE WHEN AA.ACCOUNT_AMOUNT_ID IS NOT NULL THEN AA.DISCONT_CRTL_FLAG WHEN DL.ACCOUNT_AMOUNT_ID IS NOT NULL THEN DL.DISCONT_CRTL_FLAG ELSE NULL END),
                  F.FREEZE_DATE,
                  O.SALES_CENTER_ID,
                  O.SALES_CENTER_CODE,
                  O.SALES_CENTER_NAME
) T2 
          LEFT JOIN (SELECT A.ENTITY_ID,
                           A.CREDIT_GROUP_ID,
                           A.CUSTOMER_ID,
                           A.CUSTOMER_CODE,
                           A.CUSTOMER_NAME,
                           A.ACCOUNT_ID,
                           O1.SALES_CENTER_ID,
                           O1.SALES_CENTER_CODE,
                           O1.SALES_CENTER_NAME,
                           SUM(A.RECEIPT_AMOUNT) AS RECEIPT_AMOUNT,
                           SUM(A.SALES_AMOUNT) AS SALES_AMOUNT,
                           SUM(A.LOCK_AMOUNT) AS LOCK_AMOUNT,
                           SUM(A.RECEIVED_AMOUNT) AS RECEIVED_AMOUNT
                      FROM T_CREDIT_DIS_AMOUNT_FREEZE A
                      
                     INNER JOIN T_CUSTOMER_ACCOUNT T1
                        ON (A.ACCOUNT_ID = T1.ACCOUNT_ID AND A.ENTITY_ID = IN_ENTITY_ID)
                     LEFT JOIN T_CUSTOMER_ACC_ORG_RELATION AR1
                        ON (AR1.ACCOUNT_ID = A.ACCOUNT_ID)
                      LEFT JOIN T_CUSTOMER_ORG O1
                        ON (O1.CUSTOMER_ORG_ID = AR1.CUSTOMER_ORG_ID AND
                           O1.ENTITY_ID = A.ENTITY_ID AND O1.CUSTOMER_ID = A.CUSTOMER_ID)
                     
                     WHERE A.ENTITY_ID = IN_ENTITY_ID
                       AND EXISTS (SELECT 1
                              FROM V_BD_USER_ACC_PRIV V
                             WHERE V.ACCOUNT_ID = A.ACCOUNT_ID
                               AND V.USER_CODE = IS_USER_ACC
                               AND V.ENTITY_ID = IN_ENTITY_ID)
               AND (IS_CUSTOMER_CODE IS NULL OR IS_CUSTOMER_CODE = A.CUSTOMER_CODE)
               AND (IS_SALES_CENTER_CODE IS NULL OR IS_SALES_CENTER_CODE = O1.SALES_CENTER_CODE)
               AND (IS_ACCOUNT_STATUS IS NULL OR IS_ACCOUNT_STATUS = T1.ACCOUNT_STATUS)
               AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON' OR IS_DISCOUNT_TYPE = A.DISCOUNT_TYPE)
               AND VD_FREEZE_DATE = A.FREEZE_DATE
                     GROUP BY A.ENTITY_ID,
                              A.CREDIT_GROUP_ID,
                              A.CUSTOMER_ID,
                              A.CUSTOMER_CODE,
                              A.CUSTOMER_NAME,
                              A.ACCOUNT_ID,
                              O1.SALES_CENTER_ID,
                              O1.SALES_CENTER_CODE,
                              O1.SALES_CENTER_NAME) T1
            ON (T2.ENTITY_ID = T1.ENTITY_ID AND
               T2.CUSTOMER_ID = T1.CUSTOMER_ID AND
               T2.ACCOUNT_ID = T1.ACCOUNT_ID AND T1.CREDIT_GROUP_ID = T2.CREDIT_GROUP_ID)
        UNION ALL
        SELECT 'A' || MAX(DA.DISCOUNT_AMOUNT_ID) AS ACCOUNT_AMOUNT_ID,
               DA.ENTITY_ID,
               DA.CREDIT_GROUP_ID,
               NULL AS PROJ_NUMBER,
               DA.CUSTOMER_ID,
               DA.CUSTOMER_CODE,
               DA.CUSTOMER_NAME,
               DA.ACCOUNT_ID,
               T.ACCOUNT_CODE,
               T.ACCOUNT_NAME,
               T.ACCOUNT_STATUS,
               DA.DISCOUNT_TYPE,
               NULL AS SALES_YEAR_ID,
               SUM(DA.RECEIPT_AMOUNT + DA.RECEIVED_AMOUNT) AS RECEIVED_AMOUNT,
               SUM(DA.SALES_AMOUNT) AS SALES_AMOUNT,
               SUM(DA.LOCK_AMOUNT) AS LOCK_RECEIVED_AMOUNT,
               0 AS DELAYPAY_AMOUNT,
               0 AS TEMP_DELAYPAY_AMOUNT,
               0 AS DISCOUNT_AMOUNT,
               0 AS APPLIED_DISCOUNT_AMOUNT,
               0 AS FREEZE_DISCOUNT_AMOUNT,
               0 AS FREEZE_DELAY_AMOUNT,
               0 AS LOCK_DISCOUNT_AMOUNT,
               0 AS DISPAY_AMOUNT,
               0 AS THREE_NOT_PAY,
               0 AS RESOURCE_AMOUNT,
               0 AS LOCK_RESOURCE_AMOUNT,
               0 AS TRANSACTION_AMOUNT,
               0 AS RESOURCE_LEFT_AMOUNT,
               0 AS MPAY_STREAM_AMOUNT,
               0 AS MPAY_CASH_AMOUNT,
               NULL AS AMOUNT_CRTL_FLAG,
               NULL AS DISCONT_CRTL_FLAG,
               NULL AS CREATION_DATE,
               NULL AS CREATED_BY,
               NULL AS LAST_UPDATE_DATE,
               NULL AS LAST_UPDATED_BY,
               NULL AS PRE_FIELD_01,
               NULL AS PRE_FIELD_02,
               NULL AS PRE_FIELD_03,
               NULL AS PRE_FIELD_04,
               NULL AS PRE_FIELD_05,
               NULL AS PRE_FIELD_06,
               DA.FREEZE_DATE AS FREEZE_DATE,
               DA.SALES_CENTER_ID,
               DA.SALES_CENTER_CODE,
               DA.SALES_CENTER_NAME
          FROM T_CREDIT_DIS_AMOUNT_FREEZE DA
         INNER JOIN T_CUSTOMER_ACCOUNT T
            ON (DA.ACCOUNT_ID = T.ACCOUNT_ID)
         LEFT JOIN T_CUSTOMER_ACC_ORG_RELATION AR ON (AR.ACCOUNT_ID = DA.ACCOUNT_ID)
         LEFT JOIN T_CUSTOMER_ORG O
         ON (O.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID AND O.ENTITY_ID = DA.ENTITY_ID AND O.CUSTOMER_ID = DA.CUSTOMER_ID)
         
         WHERE DA.ENTITY_ID = IN_ENTITY_ID
           AND EXISTS (SELECT 1
                  FROM V_BD_USER_ACC_PRIV V
                 WHERE V.ACCOUNT_ID = DA.ACCOUNT_ID
                   AND V.USER_CODE = IS_USER_ACC
                     AND V.ENTITY_ID = IN_ENTITY_ID)
 AND (IS_CUSTOMER_CODE IS NULL OR IS_CUSTOMER_CODE = DA.CUSTOMER_CODE)
 AND (IS_SALES_CENTER_CODE IS NULL OR IS_SALES_CENTER_CODE = O.SALES_CENTER_CODE)--
 AND (IS_ACCOUNT_STATUS IS NULL OR IS_ACCOUNT_STATUS = T.ACCOUNT_STATUS)
 AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = DA.DISCOUNT_TYPE)
 AND VD_FREEZE_DATE = DA.FREEZE_DATE
         GROUP BY DA.ENTITY_ID,
                  DA.CREDIT_GROUP_ID,
                  DA.CUSTOMER_ID,
                  DA.CUSTOMER_CODE,
                  DA.CUSTOMER_NAME,
                  DA.ACCOUNT_ID,
                  T.ACCOUNT_CODE,
                  T.ACCOUNT_NAME,
                  T.ACCOUNT_STATUS,
                  DA.DISCOUNT_TYPE,
                  DA.FREEZE_DATE,
                  DA.SALES_CENTER_ID,
                  DA.SALES_CENTER_CODE,
                  DA.SALES_CENTER_NAME) DO
 --ORDER BY ENTITY_ID,CUSTOMER_ID,ACCOUNT_ID,CREDIT_GROUP_ID,DISCOUNT_TYPE
    ;
    CURSOR C_CUSTOMER_AMOUNT_F_CM IS
    SELECT T2.ACCOUNT_AMOUNT_ID
,T2.ENTITY_ID
,T2.CREDIT_GROUP_ID
,T2.PROJ_NUMBER
,T2.CUSTOMER_ID
,T2.CUSTOMER_CODE
,T2.CUSTOMER_NAME
,T2.ACCOUNT_ID
,T2.ACCOUNT_CODE
,T2.ACCOUNT_NAME
,T2.ACCOUNT_STATUS
,T2.DISCOUNT_TYPE
,T2.SALES_YEAR_ID
,(T2.RECEIVED_AMOUNT - NVL(T1.RECEIVED_AMOUNT,0)) AS RECEIVED_AMOUNT
,(T2.SALES_AMOUNT + NVL(T1.RECEIPT_AMOUNT,0) - NVL(T1.SALES_AMOUNT,0)) AS SALES_AMOUNT
,(T2.LOCK_RECEIVED_AMOUNT - NVL(T1.LOCK_AMOUNT,0)) AS LOCK_RECEIVED_AMOUNT
,T2.DELAYPAY_AMOUNT
,T2.TEMP_DELAYPAY_AMOUNT
,T2.DISCOUNT_AMOUNT
,T2.APPLIED_DISCOUNT_AMOUNT
,T2.FREEZE_DISCOUNT_AMOUNT
,T2.FREEZE_DELAY_AMOUNT
,T2.LOCK_DISCOUNT_AMOUNT
,T2.DISPAY_AMOUNT
,T2.THREE_NOT_PAY
,T2.RESOURCE_AMOUNT
,T2.LOCK_RESOURCE_AMOUNT
,T2.TRANSACTION_AMOUNT
,T2.RESOURCE_LEFT_AMOUNT
,T2.MPAY_STREAM_AMOUNT
,T2.MPAY_CASH_AMOUNT
,T2.AMOUNT_CRTL_FLAG
,T2.DISCONT_CRTL_FLAG
,T2.CREATION_DATE
,T2.CREATED_BY
,T2.LAST_UPDATE_DATE
,T2.LAST_UPDATED_BY
,T2.PRE_FIELD_01
,T2.PRE_FIELD_02
,T2.PRE_FIELD_03
,T2.PRE_FIELD_04
,T2.PRE_FIELD_05
,T2.PRE_FIELD_06
,T2.FREEZE_DATE
,T2.SALES_CENTER_ID
,T2.SALES_CENTER_CODE
,T2.SALES_CENTER_NAME,
1 AS AMOUNT_ZERO FROM (
SELECT 'B' || MAX(F.CUST_AMOUNT_ID) AS ACCOUNT_AMOUNT_ID,
               F.ENTITY_ID,
               (CASE WHEN AA.ACCOUNT_AMOUNT_ID IS NOT NULL THEN AA.CREDIT_GROUP_ID WHEN DL.ACCOUNT_AMOUNT_ID IS NOT NULL THEN DL.CREDIT_GROUP_ID ELSE NULL END) AS CREDIT_GROUP_ID,
               NULL AS PROJ_NUMBER,
               F.CUSTOMER_ID,
               F.CUSTOMER_CODE,
               F.CUSTOMER_NAME,
               F.ACCOUNT_ID,
               F.ACCOUNT_CODE,
               F.ACCOUNT_NAME,
               T.ACCOUNT_STATUS,
               CAST('COMMON' AS VARCHAR2(100)) AS DISCOUNT_TYPE,
               NULL AS SALES_YEAR_ID,
               SUM(F.RECEIVED_AMOUNT) AS RECEIVED_AMOUNT,
               SUM(F.SALES_AMOUNT) AS SALES_AMOUNT,
               SUM(F.LOCK_RECEIVED_AMOUNT) AS LOCK_RECEIVED_AMOUNT,
               SUM(F.DELAYPAY_AMOUNT) AS DELAYPAY_AMOUNT,
               SUM(F.TEMP_DELAYPAY_AMOUNT) AS TEMP_DELAYPAY_AMOUNT,
               SUM(F.DISCOUNT_AMOUNT) AS DISCOUNT_AMOUNT,
               SUM(F.APPLIED_DISCOUNT_AMOUNT) AS APPLIED_DISCOUNT_AMOUNT,
               SUM(F.FREEZE_DISCOUNT_AMOUNT) AS FREEZE_DISCOUNT_AMOUNT,
               SUM(F.FREEZE_DELAY_AMOUNT) AS FREEZE_DELAY_AMOUNT,
               SUM(F.LOCK_DISCOUNT_AMOUNT) AS LOCK_DISCOUNT_AMOUNT,
               SUM(F.DISPAY_AMOUNT) AS DISPAY_AMOUNT,
               SUM(F.THREE_NOT_PAY) AS THREE_NOT_PAY,
               SUM(F.RESOURCE_AMOUNT) AS RESOURCE_AMOUNT,
               SUM(F.LOCK_RESOURCE_AMOUNT) AS LOCK_RESOURCE_AMOUNT,
               SUM(F.TRANSACTION_AMOUNT) AS TRANSACTION_AMOUNT,
               SUM(F.RESOURCE_AMOUNT - F.TRANSACTION_AMOUNT) AS RESOURCE_LEFT_AMOUNT,
               /*SUM(0) AS MPAY_STREAM_AMOUNT,
               SUM(0) AS MPAY_CASH_AMOUNT,*/
               SUM(F.MPAY_STREAM_AMOUNT) AS MPAY_STREAM_AMOUNT,
               SUM(F.MPAY_CASH_AMOUNT) AS MPAY_CASH_AMOUNT,
               (CASE WHEN AA.ACCOUNT_AMOUNT_ID IS NOT NULL THEN AA.AMOUNT_CRTL_FLAG WHEN DL.ACCOUNT_AMOUNT_ID IS NOT NULL THEN DL.AMOUNT_CRTL_FLAG ELSE NULL END) AS AMOUNT_CRTL_FLAG,
               (CASE WHEN AA.ACCOUNT_AMOUNT_ID IS NOT NULL THEN AA.DISCONT_CRTL_FLAG WHEN DL.ACCOUNT_AMOUNT_ID IS NOT NULL THEN DL.DISCONT_CRTL_FLAG ELSE NULL END) AS DISCONT_CRTL_FLAG,
               NULL AS CREATION_DATE,
               NULL AS CREATED_BY,
               NULL AS LAST_UPDATE_DATE,
               NULL AS LAST_UPDATED_BY,
               NULL AS PRE_FIELD_01,
               NULL AS PRE_FIELD_02,
               NULL AS PRE_FIELD_03,
               NULL AS PRE_FIELD_04,
               NULL AS PRE_FIELD_05,
               NULL AS PRE_FIELD_06,
               F.FREEZE_DATE,
               O.SALES_CENTER_ID,
               O.SALES_CENTER_CODE,
               O.SALES_CENTER_NAME
          FROM T_SALES_AMOUNT_FREEZE F
         INNER JOIN T_CUSTOMER_ACCOUNT T
            ON (F.ACCOUNT_ID = T.ACCOUNT_ID AND F.ENTITY_ID = IN_ENTITY_ID)
          LEFT JOIN T_SALES_ACCOUNT_AMOUNT AA
            ON (AA.ACCOUNT_AMOUNT_ID = F.ACCOUNT_AMOUNT_ID)
          LEFT JOIN T_SALES_ACCOUNT_AMOUNT_DEL_LOG DL
            ON (DL.ACCOUNT_AMOUNT_ID = F.ACCOUNT_AMOUNT_ID)
          LEFT JOIN T_CUSTOMER_ACC_ORG_RELATION AR
            ON (AR.ACCOUNT_ID = F.ACCOUNT_ID)
          LEFT JOIN T_CUSTOMER_ORG O
            ON (O.CUSTOMER_ORG_ID = AR.CUSTOMER_ORG_ID AND
               O.ENTITY_ID = F.ENTITY_ID AND O.CUSTOMER_ID = F.CUSTOMER_ID)
         WHERE EXISTS (SELECT 1
                  FROM V_BD_USER_ACC_PRIV V
                 WHERE V.ACCOUNT_ID = F.ACCOUNT_ID
                   AND V.USER_CODE = IS_USER_ACC
                   AND V.ENTITY_ID = IN_ENTITY_ID)
    AND (IS_CUSTOMER_CODE IS NULL OR IS_CUSTOMER_CODE = F.CUSTOMER_CODE)
    AND (IS_SALES_CENTER_CODE IS NULL OR IS_SALES_CENTER_CODE = O.SALES_CENTER_CODE)--
    AND (IS_ACCOUNT_STATUS IS NULL OR IS_ACCOUNT_STATUS = T.ACCOUNT_STATUS)
    AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON')
    AND VD_FREEZE_DATE = F.FREEZE_DATE
         GROUP BY F.ENTITY_ID,
                  (CASE WHEN AA.ACCOUNT_AMOUNT_ID IS NOT NULL THEN AA.CREDIT_GROUP_ID WHEN DL.ACCOUNT_AMOUNT_ID IS NOT NULL THEN DL.CREDIT_GROUP_ID ELSE NULL END),
                  F.CUSTOMER_ID,
                  F.CUSTOMER_CODE,
                  F.CUSTOMER_NAME,
                  F.ACCOUNT_ID,
                  F.ACCOUNT_CODE,
                  F.ACCOUNT_NAME,
                  T.ACCOUNT_STATUS,
                  (CASE WHEN AA.ACCOUNT_AMOUNT_ID IS NOT NULL THEN AA.AMOUNT_CRTL_FLAG WHEN DL.ACCOUNT_AMOUNT_ID IS NOT NULL THEN DL.AMOUNT_CRTL_FLAG ELSE NULL END),
                  (CASE WHEN AA.ACCOUNT_AMOUNT_ID IS NOT NULL THEN AA.DISCONT_CRTL_FLAG WHEN DL.ACCOUNT_AMOUNT_ID IS NOT NULL THEN DL.DISCONT_CRTL_FLAG ELSE NULL END),
                  F.FREEZE_DATE,
                  O.SALES_CENTER_ID,
                  O.SALES_CENTER_CODE,
                  O.SALES_CENTER_NAME
) T2 
          LEFT JOIN (SELECT A.ENTITY_ID,
                           A.CREDIT_GROUP_ID,
                           A.CUSTOMER_ID,
                           A.CUSTOMER_CODE,
                           A.CUSTOMER_NAME,
                           A.ACCOUNT_ID,
                           O1.SALES_CENTER_ID,
                           O1.SALES_CENTER_CODE,
                           O1.SALES_CENTER_NAME,
                           SUM(A.RECEIPT_AMOUNT) AS RECEIPT_AMOUNT,
                           SUM(A.SALES_AMOUNT) AS SALES_AMOUNT,
                           SUM(A.LOCK_AMOUNT) AS LOCK_AMOUNT,
                           SUM(A.RECEIVED_AMOUNT) AS RECEIVED_AMOUNT
                      FROM T_CREDIT_DIS_AMOUNT_FREEZE A
                      
                     INNER JOIN T_CUSTOMER_ACCOUNT T1
                        ON (A.ACCOUNT_ID = T1.ACCOUNT_ID AND A.ENTITY_ID = IN_ENTITY_ID)
                     LEFT JOIN T_CUSTOMER_ACC_ORG_RELATION AR1
                        ON (AR1.ACCOUNT_ID = A.ACCOUNT_ID)
                      LEFT JOIN T_CUSTOMER_ORG O1
                        ON (O1.CUSTOMER_ORG_ID = AR1.CUSTOMER_ORG_ID AND
                           O1.ENTITY_ID = A.ENTITY_ID AND O1.CUSTOMER_ID = A.CUSTOMER_ID)
               
                     WHERE A.ENTITY_ID = IN_ENTITY_ID
                       AND EXISTS (SELECT 1
                              FROM V_BD_USER_ACC_PRIV V
                             WHERE V.ACCOUNT_ID = A.ACCOUNT_ID
                               AND V.USER_CODE = IS_USER_ACC
                               AND V.ENTITY_ID = IN_ENTITY_ID)
               AND (IS_CUSTOMER_CODE IS NULL OR IS_CUSTOMER_CODE = A.CUSTOMER_CODE)
               AND (IS_SALES_CENTER_CODE IS NULL OR IS_SALES_CENTER_CODE = O1.SALES_CENTER_CODE)
               AND (IS_ACCOUNT_STATUS IS NULL OR IS_ACCOUNT_STATUS = T1.ACCOUNT_STATUS)
               AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = 'COMMON' OR IS_DISCOUNT_TYPE = A.DISCOUNT_TYPE)
               AND VD_FREEZE_DATE = A.FREEZE_DATE
                     GROUP BY A.ENTITY_ID,
                              A.CREDIT_GROUP_ID,
                              A.CUSTOMER_ID,
                              A.CUSTOMER_CODE,
                              A.CUSTOMER_NAME,
                              A.ACCOUNT_ID,
                              O1.SALES_CENTER_ID,
                              O1.SALES_CENTER_CODE,
                              O1.SALES_CENTER_NAME) T1
            ON (T2.ENTITY_ID = T1.ENTITY_ID AND
               T2.CUSTOMER_ID = T1.CUSTOMER_ID AND
               T2.ACCOUNT_ID = T1.ACCOUNT_ID AND T1.CREDIT_GROUP_ID = T2.CREDIT_GROUP_ID)
    ;
    CURSOR C_CUSTOMER_AMOUNT_F_DIS IS
    SELECT 'A' || MAX(DA.DISCOUNT_AMOUNT_ID) AS ACCOUNT_AMOUNT_ID,
               DA.ENTITY_ID,
               DA.CREDIT_GROUP_ID,
               NULL AS PROJ_NUMBER,
               DA.CUSTOMER_ID,
               DA.CUSTOMER_CODE,
               DA.CUSTOMER_NAME,
               DA.ACCOUNT_ID,
               T.ACCOUNT_CODE,
               T.ACCOUNT_NAME,
               T.ACCOUNT_STATUS,
               DA.DISCOUNT_TYPE,
               NULL AS SALES_YEAR_ID,
               SUM(DA.RECEIPT_AMOUNT + DA.RECEIVED_AMOUNT) AS RECEIVED_AMOUNT,
               SUM(DA.SALES_AMOUNT) AS SALES_AMOUNT,
               SUM(DA.LOCK_AMOUNT) AS LOCK_RECEIVED_AMOUNT,
               0 AS DELAYPAY_AMOUNT,
               0 AS TEMP_DELAYPAY_AMOUNT,
               0 AS DISCOUNT_AMOUNT,
               0 AS APPLIED_DISCOUNT_AMOUNT,
               0 AS FREEZE_DISCOUNT_AMOUNT,
               0 AS FREEZE_DELAY_AMOUNT,
               0 AS LOCK_DISCOUNT_AMOUNT,
               0 AS DISPAY_AMOUNT,
               0 AS THREE_NOT_PAY,
               0 AS RESOURCE_AMOUNT,
               0 AS LOCK_RESOURCE_AMOUNT,
               0 AS TRANSACTION_AMOUNT,
               0 AS RESOURCE_LEFT_AMOUNT,
               0 AS MPAY_STREAM_AMOUNT,
               0 AS MPAY_CASH_AMOUNT,
               NULL AS AMOUNT_CRTL_FLAG,
               NULL AS DISCONT_CRTL_FLAG,
               NULL AS CREATION_DATE,
               NULL AS CREATED_BY,
               NULL AS LAST_UPDATE_DATE,
               NULL AS LAST_UPDATED_BY,
               NULL AS PRE_FIELD_01,
               NULL AS PRE_FIELD_02,
               NULL AS PRE_FIELD_03,
               NULL AS PRE_FIELD_04,
               NULL AS PRE_FIELD_05,
               NULL AS PRE_FIELD_06,
               DA.FREEZE_DATE AS FREEZE_DATE,
               DA.SALES_CENTER_ID,
               DA.SALES_CENTER_CODE,
               DA.SALES_CENTER_NAME,
               1 AS AMOUNT_ZERO
          FROM T_CREDIT_DIS_AMOUNT_FREEZE DA
         INNER JOIN T_CUSTOMER_ACCOUNT T
            ON (DA.ACCOUNT_ID = T.ACCOUNT_ID)
         WHERE DA.ENTITY_ID = IN_ENTITY_ID
           AND EXISTS (SELECT 1
                  FROM V_BD_USER_ACC_PRIV V
                 WHERE V.ACCOUNT_ID = DA.ACCOUNT_ID
                   AND V.USER_CODE = IS_USER_ACC
                     AND V.ENTITY_ID = IN_ENTITY_ID)
 AND (IS_CUSTOMER_CODE IS NULL OR IS_CUSTOMER_CODE = DA.CUSTOMER_CODE)
 AND (IS_SALES_CENTER_CODE IS NULL OR IS_SALES_CENTER_CODE = DA.SALES_CENTER_CODE)--
 AND (IS_ACCOUNT_STATUS IS NULL OR IS_ACCOUNT_STATUS = T.ACCOUNT_STATUS)
 AND (IS_DISCOUNT_TYPE IS NULL OR IS_DISCOUNT_TYPE = DA.DISCOUNT_TYPE)
 AND VD_FREEZE_DATE = DA.FREEZE_DATE
         GROUP BY DA.ENTITY_ID,
                  DA.CREDIT_GROUP_ID,
                  DA.CUSTOMER_ID,
                  DA.CUSTOMER_CODE,
                  DA.CUSTOMER_NAME,
                  DA.ACCOUNT_ID,
                  T.ACCOUNT_CODE,
                  T.ACCOUNT_NAME,
                  T.ACCOUNT_STATUS,
                  DA.DISCOUNT_TYPE,
                  DA.FREEZE_DATE,
                  DA.SALES_CENTER_ID,
                  DA.SALES_CENTER_CODE,
                  DA.SALES_CENTER_NAME
    ;
    R_CUSTOMER_AMOUNT C_CUSTOMER_AMOUNT%ROWTYPE;
  BEGIN
    IF IS_FREEZE_DATE IS NOT NULL THEN
       VD_FREEZE_DATE := TO_DATE(IS_FREEZE_DATE,'YYYYMMDD');
    END IF;
    /*IF VD_FREEZE_DATE IS NULL OR VD_FREEZE_DATE >= TRUNC(SYSDATE) THEN
      IF IS_DISCOUNT_TYPE IS NULL THEN
        NULL;
      ELSIF 'COMMON' = IS_DISCOUNT_TYPE THEN
        NULL;
      ELSE
        NULL;
      END IF;
    ELSIF IS_DISCOUNT_TYPE IS NULL THEN
        NULL;
    ELSIF 'COMMON' = IS_DISCOUNT_TYPE THEN
        NULL;
    ELSE
        NULL;
    END IF;*/
    IF VD_FREEZE_DATE IS NULL OR VD_FREEZE_DATE >= TRUNC(SYSDATE) THEN
      IF IS_DISCOUNT_TYPE IS NULL THEN
        OPEN C_CUSTOMER_AMOUNT;
      ELSIF 'COMMON' = IS_DISCOUNT_TYPE THEN
         OPEN C_CUSTOMER_AMOUNT_CM;
      ELSE
         OPEN C_CUSTOMER_AMOUNT_DIS;
      END IF;
    ELSIF IS_DISCOUNT_TYPE IS NULL THEN
         OPEN C_CUSTOMER_AMOUNT_F;
    ELSIF 'COMMON' = IS_DISCOUNT_TYPE THEN
        OPEN C_CUSTOMER_AMOUNT_F_CM;
    ELSE
        OPEN C_CUSTOMER_AMOUNT_F_DIS;
    END IF;
    LOOP
      IF VD_FREEZE_DATE IS NULL OR VD_FREEZE_DATE >= TRUNC(SYSDATE) THEN
        IF IS_DISCOUNT_TYPE IS NULL THEN
          FETCH C_CUSTOMER_AMOUNT INTO R_CUSTOMER_AMOUNT;
          EXIT WHEN C_CUSTOMER_AMOUNT%NOTFOUND;
        ELSIF 'COMMON' = IS_DISCOUNT_TYPE THEN
           FETCH C_CUSTOMER_AMOUNT_CM INTO R_CUSTOMER_AMOUNT;
           EXIT WHEN C_CUSTOMER_AMOUNT_CM%NOTFOUND;
        ELSE
           FETCH C_CUSTOMER_AMOUNT_DIS INTO R_CUSTOMER_AMOUNT;
           EXIT WHEN C_CUSTOMER_AMOUNT_DIS%NOTFOUND;
        END IF;
      ELSIF IS_DISCOUNT_TYPE IS NULL THEN
        FETCH C_CUSTOMER_AMOUNT_F INTO R_CUSTOMER_AMOUNT;
        EXIT WHEN C_CUSTOMER_AMOUNT_F%NOTFOUND;
      ELSIF 'COMMON' = IS_DISCOUNT_TYPE THEN
        FETCH C_CUSTOMER_AMOUNT_F_CM INTO R_CUSTOMER_AMOUNT;
        EXIT WHEN C_CUSTOMER_AMOUNT_F_CM%NOTFOUND;
      ELSE
        FETCH C_CUSTOMER_AMOUNT_F_DIS INTO R_CUSTOMER_AMOUNT;
        EXIT WHEN C_CUSTOMER_AMOUNT_F_DIS%NOTFOUND;
      END IF;
      
      V_CUSTOMER_AMOUNT_ROW := OBJ_SALES_DIS_AMOUNT_FREEZE(R_CUSTOMER_AMOUNT.ACCOUNT_AMOUNT_ID
,R_CUSTOMER_AMOUNT.ENTITY_ID
,R_CUSTOMER_AMOUNT.CREDIT_GROUP_ID
,R_CUSTOMER_AMOUNT.PROJ_NUMBER
,R_CUSTOMER_AMOUNT.CUSTOMER_ID
,R_CUSTOMER_AMOUNT.CUSTOMER_CODE
,R_CUSTOMER_AMOUNT.CUSTOMER_NAME
,R_CUSTOMER_AMOUNT.ACCOUNT_ID
,R_CUSTOMER_AMOUNT.ACCOUNT_CODE
,R_CUSTOMER_AMOUNT.ACCOUNT_NAME
,R_CUSTOMER_AMOUNT.ACCOUNT_STATUS
,R_CUSTOMER_AMOUNT.DISCOUNT_TYPE
,R_CUSTOMER_AMOUNT.SALES_YEAR_ID
,R_CUSTOMER_AMOUNT.RECEIVED_AMOUNT
,R_CUSTOMER_AMOUNT.SALES_AMOUNT
,R_CUSTOMER_AMOUNT.LOCK_RECEIVED_AMOUNT
,R_CUSTOMER_AMOUNT.DELAYPAY_AMOUNT
,R_CUSTOMER_AMOUNT.TEMP_DELAYPAY_AMOUNT
,R_CUSTOMER_AMOUNT.DISCOUNT_AMOUNT
,R_CUSTOMER_AMOUNT.APPLIED_DISCOUNT_AMOUNT
,R_CUSTOMER_AMOUNT.FREEZE_DISCOUNT_AMOUNT
,R_CUSTOMER_AMOUNT.FREEZE_DELAY_AMOUNT
,R_CUSTOMER_AMOUNT.LOCK_DISCOUNT_AMOUNT
,R_CUSTOMER_AMOUNT.DISPAY_AMOUNT
,R_CUSTOMER_AMOUNT.THREE_NOT_PAY
,R_CUSTOMER_AMOUNT.RESOURCE_AMOUNT
,R_CUSTOMER_AMOUNT.LOCK_RESOURCE_AMOUNT
,R_CUSTOMER_AMOUNT.TRANSACTION_AMOUNT
,R_CUSTOMER_AMOUNT.RESOURCE_LEFT_AMOUNT
,R_CUSTOMER_AMOUNT.MPAY_STREAM_AMOUNT
,R_CUSTOMER_AMOUNT.MPAY_CASH_AMOUNT
,R_CUSTOMER_AMOUNT.AMOUNT_CRTL_FLAG
,R_CUSTOMER_AMOUNT.DISCONT_CRTL_FLAG
,R_CUSTOMER_AMOUNT.CREATION_DATE
,R_CUSTOMER_AMOUNT.CREATED_BY
,R_CUSTOMER_AMOUNT.LAST_UPDATE_DATE
,R_CUSTOMER_AMOUNT.LAST_UPDATED_BY
,R_CUSTOMER_AMOUNT.PRE_FIELD_01
,R_CUSTOMER_AMOUNT.PRE_FIELD_02
,R_CUSTOMER_AMOUNT.PRE_FIELD_03
,R_CUSTOMER_AMOUNT.PRE_FIELD_04
,R_CUSTOMER_AMOUNT.PRE_FIELD_05
,R_CUSTOMER_AMOUNT.PRE_FIELD_06
,R_CUSTOMER_AMOUNT.FREEZE_DATE
,R_CUSTOMER_AMOUNT.SALES_CENTER_ID
,R_CUSTOMER_AMOUNT.SALES_CENTER_CODE
,R_CUSTOMER_AMOUNT.SALES_CENTER_NAME
,R_CUSTOMER_AMOUNT.AMOUNT_ZERO
,NULL,NULL,NULL,NULL,NULL);

      PIPE ROW(V_CUSTOMER_AMOUNT_ROW);
    END LOOP;
    IF VD_FREEZE_DATE IS NULL OR VD_FREEZE_DATE >= TRUNC(SYSDATE) THEN
      IF IS_DISCOUNT_TYPE IS NULL THEN
        CLOSE C_CUSTOMER_AMOUNT;
      ELSIF 'COMMON' = IS_DISCOUNT_TYPE THEN
         CLOSE C_CUSTOMER_AMOUNT_CM;
      ELSE
         CLOSE C_CUSTOMER_AMOUNT_DIS;
      END IF;
    ELSIF IS_DISCOUNT_TYPE IS NULL THEN
         CLOSE C_CUSTOMER_AMOUNT_F;
    ELSIF 'COMMON' = IS_DISCOUNT_TYPE THEN
        CLOSE C_CUSTOMER_AMOUNT_F_CM;
    ELSE
        CLOSE C_CUSTOMER_AMOUNT_F_DIS;
    END IF;
  END F_GET_CUSTOMER_AMOUNT;

end PKG_CREDIT_DIS;
/

