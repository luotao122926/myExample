create PACKAGE      PKG_SO_RT IS
  -------------------------------------------------------------------------------
  --来源单据类型VARCHAR2(100)01中转单/02财务单  '02'; --01中转单/02财务单
  V_SOURCE_ORDERS_TYPE INTF_CUX_ICP_ORDER_REQ_HEADERS.SOURCE_ORDERS_TYPE%TYPE := '02';
  --来源单据类型VARCHAR2(100) 03事业部关联交易单边模式
  V_SOURCE_ORDERS_TYPE_G INTF_CUX_ICP_ORDER_REQ_HEADERS.SOURCE_ORDERS_TYPE%TYPE := '03';
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-21
  *     创建者：陈武杰
  *   功能说明：related transaction销售拉式关联交易核心存储过程包，
      拉式销售单引ERP，拉式关联订单，拉式关联物流
  */
  -------------------------------------------------------------------------------
  -------------------------------------------------------------------------------

  PROCEDURE P_TABLE_ACTION_LOG(P_TABLE_NAME     VARCHAR2, --操作表名称
                               P_ACTION_REMARKS VARCHAR2, --操作说明
                               P_PK             VARCHAR2, --关键主键
                               P_ISERR          NUMBER, --是否出错，1出错，0未出错
                               P_MSG            VARCHAR2 --错误信息
                               );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-22
  *     创建者：陈武杰
  *   功能说明：关联订单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_TO_RT_ORDER(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                             P_RESULT       IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-07-22
  *     创建者：xiongpl
  *   功能说明：跨事业部关联订单，如中央内销销售给热水内销，两内销间关联订单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_TO_RT_ORDER_ENTITY(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                             P_RESULT       IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             );                             
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-01-22
  *     创建者：陈武杰
  *   功能说明：物流订单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_TO_LG_ORDER(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                             P_STATUS       IN VARCHAR2, --状态：N待发送；P已发送；S成功，如果前面有关联订单，需要将状态传空值，这样才可以实现串行
                             P_RESULT       IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-07-22
  *     创建者：陈武杰
  *   功能说明：跨事业部关联物流订单，如中央内销销售给热水内销，两内销间关联物流
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_TO_LG_ORDER_ENTITY(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                             P_STATUS       IN VARCHAR2, --状态：N待发送；P已发送；S成功，如果前面有关联订单，需要将状态传空值，这样才可以实现串行
                             P_RESULT       IN OUT NUMBER, --返回错误ID
                             P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             );   
                             
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2016-03-07
  *     创建者：xiongpl
  *   功能说明：根据库存组织与客户ID获取关联交易仓
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_GET_ICP_INV( P_SO_HEADER  IN T_SO_HEADER%ROWTYPE,            --销售单记录
                             P_INV_CODE   OUT T_SO_ICP_INVENTORY.INVENTORY_CODE%TYPE,  --仓库编码
                             P_RESULT     OUT NUMBER, --返回错误ID
                             P_ERR_MSG    OUT VARCHAR2 --返回错误信息
                             );                                                          
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-02-05
  *     创建者：陈武杰
  *   功能说明：关联订单回调，关联订单交易成功回调
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ORDER_WRITE_BACK(P_SO_NUM T_SO_HEADER.SO_NUM%TYPE
                               --P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE --销售单头ID
                               --P_RESULT       IN OUT NUMBER, --返回错误ID
                               --P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                               );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-02-05
  *     创建者：陈武杰
  *   功能说明：关联物流回调
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_LOGIST_WRITE_BACK(P_SO_NUM T_SO_HEADER.SO_NUM%TYPE
                                --P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE --销售单头ID
                                --P_RESULT       IN OUT NUMBER, --返回错误ID
                                --P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                                );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-02-05
  *     创建者：陈武杰
  *   功能说明：RMA接收回调
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_RMA_WRITE_BACK(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE --销售单头ID
                             --P_RESULT       IN OUT NUMBER, --返回错误ID
                             --P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-02-05
  *     创建者：陈武杰
  *   功能说明：SO变更回调
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SOCHANGE_WRITE_BACK(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE --销售单头ID
                                  --P_RESULT       IN OUT NUMBER, --返回错误ID
                                  --P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                                  );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-20
  *     创建者：陈武杰
  *   功能说明：生成SO变更标记记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_JOB_MAKE_SO_CHANGE(P_SUCCESS_COUNT OUT NUMBER, --成功记录条数
                                 P_FAIL_COUNT    OUT NUMBER --失败记录条数
                                 );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-03-20
  *     创建者：陈武杰
  *   功能说明：生成关联交易物流订单记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_JOB_MAKE_RT_LOGIST(P_SUCCESS_COUNT OUT NUMBER, --成功记录条数
                                 P_FAIL_COUNT    OUT NUMBER --失败记录条数
                                 );

  /*
     普通客户关联关易入口
  */
  PROCEDURE P_MAIN(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                   P_RESULT       IN OUT NUMBER, --返回错误ID
                   P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                   );
                   
  /*
     事业部客户关联关易入口
  */
  PROCEDURE P_MAIN_ENTITY(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                   P_RESULT       IN OUT NUMBER, --返回错误ID
                   P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                   );       
  -------------------------------------------------------------------------------            
  PROCEDURE P_TEST(P_SQL VARCHAR2);
  -------------------------------------------------------------------------------  
  /*
  *   创建日期：2016-11-17
  *     创建者：周建刚
  *   功能说明：内部关联交易客户，需方主体在CIMS实施，则根据供方的销售单生成需方对应的PO单
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_TO_PO(P_SO_HEADER_ID IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
                       P_RESULT       IN OUT NUMBER, --返回错误ID
                       P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                             );
  
  -----------------------------------------------------------------------------
  --处理需要校验价格的单边订单
  -----------------------------------------------------------------------------
  PROCEDURE P_JOB_CHECK_PRICE
  (
    P_ENTITY_ID      IN T_SO_HEADER.ENTITY_ID%TYPE, --主体id
    P_SO_HEADER_ID   IN T_SO_HEADER.SO_HEADER_ID%TYPE, --销售单头id
    P_RESULT         IN OUT NUMBER, --返回错误ID
    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
  );                           
  -------------------------------------------------------------------------------
  
  
END;
/

