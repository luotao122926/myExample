create Package Body      Pkg_Trx_Oi Is


  --打印后回写数据
  Procedure Create_So_Trx_Callback(p_Trx_Id   In t_So_Trx_Headers.idTrx_Id%Type --打印队列ID
                                  ,
                                   p_Trx_Code In t_So_Trx_Headers.Trx_Code%Type
                                   --发票号码
                                  ,
                                   p_Trx_Date In t_So_Trx_Headers.Trx_Date%Type
                                   --发票日期
                                  ,
                                   p_Result Out Varchar2
                                   --返回值
                                   ) Is
  Begin
       p_Result := Err_Ok;
       Create_So_Trx_Callback(p_Trx_Id,p_Trx_Code,p_Trx_Date,null,null,null,null,null,p_Result);
  END;


Procedure Create_So_Trx_Callback(p_Trx_Id In t_So_Trx_Headers.idTrx_Id%Type --打印队列ID
                                  , p_Trx_Code In t_So_Trx_Headers.Trx_Code%Type
                                   --发票号码
                                  , p_Trx_Date In t_So_Trx_Headers.Trx_Date%Type
                                  
                                  , p_Material_Trx_Amount In number
                                  
                                  , p_Material_Amount In number
                                  
                                  , p_Tax_Amount In number
                                  
                                  , p_Original_TRX_CODE In Varchar2
                                  
                                  , p_Created_By In Varchar2
                                   --发票日期
                                  , p_Result Out Varchar2
                                   --返回值
                                   )Is
    Vcolumnlen Number;
    Vcount     Number;
    Vstate     t_So_Trx_Headers.State%Type;
  Begin
    p_Result := Err_Ok;
   
    begin
            insert into 
               INTF_SO_TAX_INVOICE(
                  TAX_INVOICE_ID
                  ,TRX_ID
                  ,TRX_CODE
                  ,TRX_DATE
                  ,MATERIAL_TRX_AMOUNT
                  ,MATERIAL_AMOUNT
                  ,TAX_AMOUNT
                  ,ORIGINAL_TRX_CODE
                  ,CREATED_BY
                  ,CREATION_DATE
                  ,LAST_UPDATED_BY
                  ,LAST_UPDATE_DATE
            )values(
                  S_SO_TAX_INVOICE.NEXTVAL
                 ,p_Trx_Id
                 ,p_Trx_Code
                 ,p_Trx_Date
                 ,p_Material_Trx_Amount
                 ,p_Material_Amount
                 ,p_Tax_Amount
                 ,p_Original_TRX_CODE
                 ,p_Created_By
                 ,SYSDATE
                 ,p_Created_By
                 ,SYSDATE
            ); 
            Commit;
          Exception
              When Others Then   
              P_RESULT := PKG_BD.F_ADD_ERROR_LOG('Pkg_Trx_Oi.Create_So_Trx_Callback', SQLCODE,
                '回写发票错误：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM || p_Trx_Code);
     end;
    
     Savepoint Procstart;

    --MDCSS.检测售后接口表是否存在，是则表明为售后的发票单据，更新掉即可
    /*    Begin
      Select Count(*) Into Vcount From t_Css_Oi_So_Trx Sth Where Sth.Trx_Id = p_Trx_Id;
      If Vcount > 0 Then
        --2013年4月25日 增加反写CSS系统写过的配件发票，打印回写。更新售后发票头接口表
        Select Sth.State Into Vstate From t_Css_Oi_So_Trx Sth Where Sth.Trx_Id = p_Trx_Id For Update;
        If Vstate Not In (Pkg_Trx.Ts_In_Queue, Pkg_Trx.Ts_Locked) Then
          p_Result := Err_Trx_State_Err;
        End If;
        If p_Result = Err_Ok Then
          Update t_Css_Oi_So_Trx Sth
          Set Sth.Invoice_Number = p_Trx_Code, Sth.Invoice_Date = p_Trx_Date, Sth.State = Pkg_Trx.Ts_Printed,
              Sth.Last_Updated_By = 0, Sth.Last_Update_Date = Sysdate
          Where Sth.Trx_Id = p_Trx_Id;
          Commit;
          Return;
        Else
          Rollback To Savepoint Procstart;
          Return;
        End If;
      End If;
    End;*/

    --检测输入参数长度是否与数据库要求长度匹配
    If Nvl(Length(p_Trx_Code), 0) > 60 Then
      p_Result := Err_Param_Err; --参数不在允许的范围内
    End If;

    If p_Result = Err_Ok Then
      Begin
        Select Sth.State
          Into Vstate
          From t_So_Trx_Headers Sth
         Where Sth.idTrx_Id = p_Trx_Id
           For Update;
        --判断发票的状态是否可以锁定
        If Vstate Not In (Pkg_Trx.Ts_In_Queue, Pkg_Trx.Ts_Locked) Then
          p_Result := Err_Trx_State_Err;
        End If;
      Exception
        When No_Data_Found Then
          p_Result := Err_Trx_Not_Found;
      End;
    End If;

    --更新发票池对应数据
    If p_Result = Err_Ok Then
      --发票头
      Update t_So_Trx_Headers Sth
         Set Sth.Trx_Code         = p_Trx_Code,
             Sth.Trx_Date         = p_Trx_Date,
             Sth.State            = Pkg_Trx.Ts_Printed,
             Sth.Last_Updated_By  = 0,
             Sth.Last_Update_Date = Sysdate,
             Sth.INTF_TAX_FLAG = 'N',
             Sth.TAX_CONTROL_FLAG = 'Y',
             STH.Tax_Amount = nvl(p_Tax_Amount,STH.Tax_Amount),
             STH.SOURCE_SYSTEM = 'kpy'
       Where Sth.idTrx_Id = p_Trx_Id;

      --得到 T_SO_ORDER_HEADERS.TAX_NUMBER字段的长度
      /*
            select C.data_length into vColumnLen
             from cols c
            where c.table_name = 'T_SO_ORDER_HEADERS'
              AND c.column_name = 'TAX_NUMBER';
      */
      Vcolumnlen := 500;
      --更新销售表的发票号
      Update t_So_Header Soh
         Set Soh.INVOICE_NUM_LIST = Decode(Instr(Soh.INVOICE_NUM_LIST,
                                                 p_Trx_Code) --查找发票号是否在销售单头
                                          ,
                                           0
                                           --检查是否超长，如果没有超长则追加在后尾
                                          ,
                                           Decode(Sign(Nvl(Length(Soh.INVOICE_NUM_LIST ||
                                                                  Decode(Soh.INVOICE_NUM_LIST,
                                                                         Null,
                                                                         Null,
                                                                         ',') ||
                                                                  p_Trx_Code),
                                                           0) - Vcolumnlen),
                                                  -1,
                                                  Soh.INVOICE_NUM_LIST ||
                                                  Decode(Soh.INVOICE_NUM_LIST,
                                                         Null,
                                                         Null,
                                                         ',') || p_Trx_Code,
                                                  Soh.INVOICE_NUM_LIST)
                                           --销售单发票号码是空的则直接回写
                                          ,
                                           Null,
                                           p_Trx_Code
                                           --发票号已存在，不需要更新
                                          ,
                                           Soh.INVOICE_NUM_LIST),
             Soh.INVOICE_DATE     = Decode(Instr(Soh.INVOICE_NUM_LIST,
                                                 p_Trx_Code),
                                           0,
                                           p_Trx_Date,
                                           Null,
                                           p_Trx_Date,
                                           Soh.INVOICE_DATE),
             Soh.Last_Update_Date = Sysdate,
             Soh.Last_Updated_By  = 1
       Where Soh.SO_HEADER_ID In
             (Select Sthr.SO_HEAD_ID
                From t_So_Trx_Header_Relation Sthr
               Where Sthr.IDTRX_ID = p_Trx_Id);

      --如果update之后发现没update成功，回滚并报错。
      Select Count(*)
        Into Vcount
        From t_So_Header Soh, t_So_Trx_Header_Relation Sthr
       Where Soh.So_Header_Id = Sthr.So_Head_Id
         And Sthr.Idtrx_Id = p_Trx_Id
         And Nvl(Instr(Soh.INVOICE_NUM_LIST, p_Trx_Code), 0) <= 0
         And Sign(Nvl(Length(Soh.INVOICE_NUM_LIST ||
                             Decode(Soh.INVOICE_NUM_LIST, Null, Null, ',') ||
                             p_Trx_Code),
                      0) - Vcolumnlen) < 0;

      If Vcount > 0 Then
        Rollback To Savepoint Procstart;
        p_Result := '发现不明错误，发票号不能完全回写到销售单上';
      End If;
    End If;

    If p_Result = Err_Ok Then
      Commit;
    Else
      Rollback To Savepoint Procstart;
    End If;
  Exception
    When Dup_Val_On_Index Then
      Rollback To Savepoint Procstart;
      p_Result := Err_Trx_Dup;
    When Others Then
      Rollback To Savepoint Procstart;
      p_Result := Err_Unknow || Sqlerrm;
  End;
  
  --开具电子发票回写接口 add by huanghb12
  Procedure Create_So_Trx_Callback_Ecm(
                                    p_Trx_Id In t_So_Trx_Headers.idTrx_Id%Type --打印队列ID
                                    
                                  , p_Trx_Code In t_So_Trx_Headers.Trx_Code%Type
                                   --发票号码
                                   
                                   , p_Pdf_Url In t_So_Trx_Headers.pdf_url%Type
                                   --电子发票开票结果
                                   
                                  , p_Trx_Date In t_So_Trx_Headers.Trx_Date%Type
                                  
                                  , p_Material_Trx_Amount In number
                                  
                                  , p_Material_Amount In number
                                  
                                  , p_Tax_Amount In number
                                  
                                  , p_Original_TRX_CODE In Varchar2
                                  
                                  , p_SOURCE_SYSTEM In Varchar2
                                  
                                  , p_Created_By In Varchar2
                                   --发票日期
                                  , p_Result Out Varchar2
                                   --返回值
                                   )Is
    Vcolumnlen Number;
    Vcount     Number;
    Vstate     t_So_Trx_Headers.State%Type;
    V_Material_Trx_Amount          Number;
    V_Material_Amount              Number;
    V_Tax_Amount                   Number;
    V_TRX_ACCOUNT_DEVIATION        Number; --结算差异金额
    V_SOURCE_SYSTEM                t_So_Trx_Headers.Source_System%Type; 
    
  Begin
    p_Result := Err_Ok;
    
    V_Material_Trx_Amount := p_Material_Trx_Amount;
    V_Material_Amount := p_Material_Amount;
    V_Tax_Amount := p_Tax_Amount;
    
    
    --add by huanghb12  待优化
    if (0 = V_Material_Trx_Amount) or (V_Material_Trx_Amount is null) then
     select nvl(th.TRX_ACCOUNT_DEVIATION,0)
       into V_TRX_ACCOUNT_DEVIATION
       from cims.t_so_trx_headers th
       where th.idtrx_id =  p_Trx_Id;
    
      select sum(nvl(TL.material_trx_amount,0)),sum(nvl(TL.MATERIAL_AMOUNT,0))
        into V_Material_Trx_Amount,V_Material_Amount
        from cims.V_SO_TRX_LINES TL
       WHERE TL.IDTRX_ID = p_Trx_Id;
       
      V_Material_Trx_Amount := V_Material_Trx_Amount + V_TRX_ACCOUNT_DEVIATION;
      V_Material_Amount     := V_Material_Amount + V_TRX_ACCOUNT_DEVIATION;
      
    end if;
    
    if (p_SOURCE_SYSTEM is null) then
      V_SOURCE_SYSTEM := 'pky';
    end if;
   
    begin
            insert into 
               INTF_SO_TAX_INVOICE(
                  TAX_INVOICE_ID
                  ,TRX_ID
                  ,TRX_CODE
                  ,TRX_DATE
                  ,MATERIAL_TRX_AMOUNT
                  ,MATERIAL_AMOUNT
                  ,TAX_AMOUNT
                  ,ORIGINAL_TRX_CODE
                  ,CREATED_BY
                  ,CREATION_DATE
                  ,LAST_UPDATED_BY
                  ,LAST_UPDATE_DATE
            )values(
                  S_SO_TAX_INVOICE.NEXTVAL
                 ,p_Trx_Id
                 ,p_Trx_Code
                 ,p_Trx_Date
                 ,V_Material_Trx_Amount
                 ,V_Material_Amount
                 ,nvl(p_Tax_Amount,V_Material_Trx_Amount - V_Material_Amount)
                 ,p_Original_TRX_CODE
                 ,p_Created_By
                 ,SYSDATE
                 ,p_Created_By
                 ,SYSDATE
            ); 
            Commit;
          Exception
              When Others Then   
              P_RESULT := PKG_BD.F_ADD_ERROR_LOG('Pkg_Trx_Oi.Create_So_Trx_Callback', SQLCODE,
                '回写发票错误：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM || p_Trx_Code);
     end;
    
     Savepoint Procstart;

    --MDCSS.检测售后接口表是否存在，是则表明为售后的发票单据，更新掉即可
    /*    Begin
      Select Count(*) Into Vcount From t_Css_Oi_So_Trx Sth Where Sth.Trx_Id = p_Trx_Id;
      If Vcount > 0 Then
        --2013年4月25日 增加反写CSS系统写过的配件发票，打印回写。更新售后发票头接口表
        Select Sth.State Into Vstate From t_Css_Oi_So_Trx Sth Where Sth.Trx_Id = p_Trx_Id For Update;
        If Vstate Not In (Pkg_Trx.Ts_In_Queue, Pkg_Trx.Ts_Locked) Then
          p_Result := Err_Trx_State_Err;
        End If;
        If p_Result = Err_Ok Then
          Update t_Css_Oi_So_Trx Sth
          Set Sth.Invoice_Number = p_Trx_Code, Sth.Invoice_Date = p_Trx_Date, Sth.State = Pkg_Trx.Ts_Printed,
              Sth.Last_Updated_By = 0, Sth.Last_Update_Date = Sysdate
          Where Sth.Trx_Id = p_Trx_Id;
          Commit;
          Return;
        Else
          Rollback To Savepoint Procstart;
          Return;
        End If;
      End If;
    End;*/

    --检测输入参数长度是否与数据库要求长度匹配
    If Nvl(Length(p_Trx_Code), 0) > 60 Then
      p_Result := Err_Param_Err; --参数不在允许的范围内
    End If;

    If p_Result = Err_Ok Then
      Begin
        Select Sth.State
          Into Vstate
          From t_So_Trx_Headers Sth
         Where Sth.idTrx_Id = p_Trx_Id
           For Update;
        --判断发票的状态是否可以锁定
        If Vstate Not In (Pkg_Trx.Ts_In_Queue, Pkg_Trx.Ts_Locked) Then
          p_Result := Err_Trx_State_Err;
        End If;
      Exception
        When No_Data_Found Then
          p_Result := Err_Trx_Not_Found;
      End;
    End If;

    --更新发票池对应数据
    If p_Result = Err_Ok Then
      --发票头
      Update t_So_Trx_Headers Sth
         Set Sth.Trx_Code         = p_Trx_Code,
             Sth.Pdf_Url          = p_Pdf_Url,--增加电子发票结果传输
             Sth.Trx_Date         = p_Trx_Date,
             Sth.State            = Pkg_Trx.Ts_Printed,
             Sth.Last_Updated_By  = 0,
             Sth.Last_Update_Date = Sysdate,
             Sth.INTF_TAX_FLAG = 'N',
             Sth.TAX_CONTROL_FLAG = 'Y',
             Sth.Intf_Error_Msg = '',
             STH.Tax_Amount = nvl(p_Tax_Amount,V_Material_Trx_Amount - V_Material_Amount), -- nvl(p_Tax_Amount,STH.Tax_Amount),
             STH.SOURCE_SYSTEM = V_SOURCE_SYSTEM
       Where Sth.idTrx_Id = p_Trx_Id;

      --得到 T_SO_ORDER_HEADERS.TAX_NUMBER字段的长度
      /*
            select C.data_length into vColumnLen
             from cols c
            where c.table_name = 'T_SO_ORDER_HEADERS'
              AND c.column_name = 'TAX_NUMBER';
      */
      Vcolumnlen := 500;
      --更新销售表的发票号
      Update t_So_Header Soh
         Set Soh.INVOICE_NUM_LIST = Decode(Instr(Soh.INVOICE_NUM_LIST,
                                                 p_Trx_Code) --查找发票号是否在销售单头
                                          ,
                                           0
                                           --检查是否超长，如果没有超长则追加在后尾
                                          ,
                                           Decode(Sign(Nvl(Length(Soh.INVOICE_NUM_LIST ||
                                                                  Decode(Soh.INVOICE_NUM_LIST,
                                                                         Null,
                                                                         Null,
                                                                         ',') ||
                                                                  p_Trx_Code),
                                                           0) - Vcolumnlen),
                                                  -1,
                                                  Soh.INVOICE_NUM_LIST ||
                                                  Decode(Soh.INVOICE_NUM_LIST,
                                                         Null,
                                                         Null,
                                                         ',') || p_Trx_Code,
                                                  Soh.INVOICE_NUM_LIST)
                                           --销售单发票号码是空的则直接回写
                                          ,
                                           Null,
                                           p_Trx_Code
                                           --发票号已存在，不需要更新
                                          ,
                                           Soh.INVOICE_NUM_LIST),
             Soh.INVOICE_DATE     = Decode(Instr(Soh.INVOICE_NUM_LIST,
                                                 p_Trx_Code),
                                           0,
                                           p_Trx_Date,
                                           Null,
                                           p_Trx_Date,
                                           Soh.INVOICE_DATE),
             Soh.Last_Update_Date = Sysdate,
             Soh.Last_Updated_By  = 1
       Where Soh.SO_HEADER_ID In
             (Select Sthr.SO_HEAD_ID
                From t_So_Trx_Header_Relation Sthr
               Where Sthr.IDTRX_ID = p_Trx_Id);

      --如果update之后发现没update成功，回滚并报错。
      Select Count(*)
        Into Vcount
        From t_So_Header Soh, t_So_Trx_Header_Relation Sthr
       Where Soh.So_Header_Id = Sthr.So_Head_Id
         And Sthr.Idtrx_Id = p_Trx_Id
         And Nvl(Instr(Soh.INVOICE_NUM_LIST, p_Trx_Code), 0) <= 0
         And Sign(Nvl(Length(Soh.INVOICE_NUM_LIST ||
                             Decode(Soh.INVOICE_NUM_LIST, Null, Null, ',') ||
                             p_Trx_Code),
                      0) - Vcolumnlen) < 0;

      If Vcount > 0 Then
        Rollback To Savepoint Procstart;
        p_Result := '发现不明错误，发票号不能完全回写到销售单上';
      End If;
    End If;

    If p_Result = Err_Ok Then
      Commit;
    Else
      Rollback To Savepoint Procstart;
    End If;
  Exception
    When Dup_Val_On_Index Then
      Rollback To Savepoint Procstart;
      p_Result := Err_Trx_Dup;
    When Others Then
      Rollback To Savepoint Procstart;
      p_Result := Err_Unknow || Sqlerrm;
  End;

  --作废发票回写数据
  Procedure Cancel_So_Trx_Callback(p_Trx_Code In t_So_Trx_Headers.Trx_Code%Type --作废的发票号码
                                  ,
                                   p_Result   Out Varchar2
                                   --返回值
                                   ) Is
    Vtrx_Id t_So_Trx_Headers.idTrx_Id%Type;
    v_State t_So_Trx_Headers.State%Type; --add by huanghb12
    V_Trx_Type t_So_Trx_Headers.Trx_Type%Type; --add by huanghb12
    
    
    S_RESULT_MESSAGE      VARCHAR(10000); 
  Begin
    p_Result := Err_Ok;
    Savepoint Procstart;

    --检测输入参数长度是否与数据库要求长度匹配
    If Nvl(Length(p_Trx_Code), 0) Not Between 0 And 60 Then
      p_Result := Err_Param_Err;
    End If;

    --MDCSS.检测售后接口表是否存在，是则表明为售后的发票单据，更新掉即可
    /*    If p_Result = Err_Ok Then
      Declare
        v_Count  Number;
        v_Trx_Id Number;
        v_State  Varchar2(1000);
      Begin
        Select Count(*)
          Into v_Count
          From t_Css_Oi_So_Trx Sth
         Where Sth.Invoice_Number = p_Trx_Code;
        If v_Count > 0 Then
          --2013年4月25日 增加反写CSS系统写过的配件发票，打印回写。更新售后发票头接口表
          Begin
            Select Trx_Id, Sth.State
              Into v_Trx_Id, v_State
              From t_Css_Oi_So_Trx Sth
             Where Sth.Invoice_Number = p_Trx_Code
               For Update;
          Exception
            When Too_Many_Rows Then
              p_Result := Err_Dup_Trx_Code || ':' || p_Trx_Code; --发票号码发现有重复，无法处理
              Rollback To Savepoint Procstart;
              Return;
          End;

          If v_State Not In (Pkg_Trx.Ts_Printed) Then
            p_Result := Err_Trx_Not_Cancelable;
          End If;
          If p_Result = Err_Ok Then
            --2013年4月25日，作废回写。更新售后发票池接口表
            Update t_Css_Oi_So_Trx Sth
               Set Sth.Invoice_Number   = Null,
                   Sth.Invoice_Date     = Null,
                   Sth.Have_Cancel_Flag = 'Y'
                   --作废发票时将重置巳建回执标志
                  ,
                   Sth.State            = Pkg_Trx.Ts_In_Queue,
                   Sth.Last_Updated_By  = 0,
                   Sth.Last_Update_Date = Sysdate
             Where Sth.Trx_Id = v_Trx_Id;
            Commit;
            Return;
          Else
            Rollback To Savepoint Procstart;
            Return;
          End If;
        End If;
      End;
    End If;*/

    If p_Result = Err_Ok Then
      Begin
        Select Sth.Idtrx_Id,Sth.State,Sth.Trx_Type
          Into Vtrx_Id,v_State,V_Trx_Type
          From t_So_Trx_Headers Sth
         Where Sth.Trx_Code = p_Trx_Code;
      Exception
        When No_Data_Found Then
          p_Result := Err_Trx_Not_Found; --发票号码不存在
        When Too_Many_Rows Then
          p_Result := Err_Dup_Trx_Code || ':' || p_Trx_Code; --发票号码发现有重复，无法处理
      End;
    End If;

    --add by huanghb12 电子发票处理
    If p_Result = Err_Ok Then
      --如果是电子发票，调用红冲的时候，需要解锁
      if v_State = Pkg_Trx.Ts_Locked and v_Trx_Type = 'ELECTRONIC_TRX_MATCH' then
        Update t_So_Trx_Headers Sth
         Set Sth.State            = Pkg_Trx.Ts_Printed,
             Sth.Last_Updated_By  = 'ecm',
             Sth.Last_Update_Date = Sysdate
        Where Sth.idTrx_Id = Vtrx_Id;                            
      end if;
    End If;
    --end by huanghb12
    --更新发票池对应数据
    If p_Result = Err_Ok Then
      
      PKG_AR_INVOICE.P_SO_TAX_CANCEL(Vtrx_Id,'kpy',S_RESULT_MESSAGE); --取消ERP税控信息
    
      Pkg_Trx.Cancel_So_Trx(p_Trx_Id  => Vtrx_Id,
                            p_User_Id => 1,
                            p_Result  => p_Result);
    End If;
    
    --add by huanghb12 电子发票处理
    If p_Result = Err_Ok Then
      --如果是电子发票，红冲成功之后，将电子发票的状态改为未开票状态  Ts_Not_Printed
      if v_Trx_Type = 'ELECTRONIC_TRX_MATCH' then
        Update t_So_Trx_Headers Sth
         Set Sth.State            = Pkg_Trx.Ts_Not_Printed,
             Sth.Intf_Error_Msg   = null,
             Sth.Pdf_Url          = null,
             Sth.Last_Updated_By  = 'ecm',
             Sth.Last_Update_Date = Sysdate
        Where Sth.idTrx_Id = Vtrx_Id;  
        
        --存在美云销改票信息的更新发票头
        UPDATE CIMS.T_SO_TRX_HEADERS H
           SET (H.TRX_TYPE,
                H.CUSTOMER_REGISTRATION_CODE,
                H.INVOICE_ADDRESS,
                H.INVOICE_TEL,
                H.INVOICE_BANK,
                H.INVOICE_BANK_ACCOUNT,
                H.INVOICE_CONTACT,
                H.INVOICE_CONTACT_TEL,
                H.INVOICE_CONTACT_ADDR) =
               (SELECT I.INVOICE_TYPE,
                       I.IDENTIFICATION_NUMBER,
                       I.INVOICE_ADDRESS,
                       I.INVOICE_TEL,
                       I.INVOICE_BANK,
                       I.INVOICE_BANK_ACCOUNT,
                       I.INVOICE_CONTACT,
                       I.INVOICE_CONTACT_TEL,
                       I.INVOICE_CONTACT_ADDR
                  FROM T_SO_INVOICE_INFO I
                 WHERE I.INVOICE_OPT_TYPE = 'MODIFY' --改票
                   AND I.ENTITY_ID = H.ENTITY_ID
                   AND I.INVOICE_NUMBER = H.TRX_HEADER_CODE
                   AND ROWNUM = 1)
                ,H.STATE = Pkg_Trx.Ts_In_Queue
                ,H.LAST_UPDATED_BY = 'hessianIntf'
                ,H.LAST_UPDATE_DATE = SYSDATE
         WHERE H.IDTRX_ID = Vtrx_Id
           AND EXISTS (SELECT 1 FROM T_SO_INVOICE_INFO II
                        WHERE II.ENTITY_ID = H.ENTITY_ID
                          AND II.INVOICE_NUMBER = H.TRX_HEADER_CODE);
      end if;
    End If;
    --end by huanghb12

    If p_Result = Err_Ok Then
      Commit;
    Else
      Rollback To Savepoint Procstart;
    End If;
  Exception
    When Others Then
      Rollback To Savepoint Procstart;
      p_Result := Err_Unknow || Sqlerrm;
  End;

  --锁定发票
  Procedure Lock_Trx(p_Trx_Id In t_So_Trx_Headers.idTrx_Id%Type --打印队列ID
                    ,
                     p_Result Out Varchar2
                     --返回值
                     ) Is
    Vstate t_So_Trx_Headers.State%Type;

    Vcount Number;
  Begin
    p_Result := Err_Ok;
    Savepoint Procstart;

    --MDCSS.检测售后接口表是否存在，是则表明为售后的发票单据，更新掉即可
    /*Begin
      Select Count(*)
        Into Vcount
        From t_Css_Oi_So_Trx Sth
       Where Sth.Trx_Id = p_Trx_Id;
      If Vcount > 0 Then
        --2013年4月25日 增加反写CSS系统写过的配件发票，打印回写。更新售后发票头接口表
        Select Sth.State
          Into Vstate
          From t_Css_Oi_So_Trx Sth
         Where Sth.Trx_Id = p_Trx_Id
           For Update;
        --判断发票的状态是否可以锁定
        If Vstate Not In (Pkg_Trx.Ts_In_Queue) Then
          p_Result := Err_Trx_State_Err;
        End If;
        If p_Result = Err_Ok Then
          Update t_Css_Oi_So_Trx Sth
             Set Sth.State            = Pkg_Trx.Ts_Locked,
                 Sth.Last_Updated_By  = 0,
                 Sth.Last_Update_Date = Sysdate
           Where Sth.Trx_Id = p_Trx_Id;
          Commit;
          Return;
        Else
          Rollback To Savepoint Procstart;
          Return;
        End If;
      End If;
    End;*/

    Begin
      Select Sth.State
        Into Vstate
        From t_So_Trx_Headers Sth
       Where Sth.idTrx_Id = p_Trx_Id
         For Update;
      --判断发票的状态是否可以锁定
      If Vstate Not In (Pkg_Trx.Ts_In_Queue) Then
        p_Result := Err_Trx_State_Err;
      End If;
    Exception
      When No_Data_Found Then
        p_Result := Err_No_Queue;
    End;

    If p_Result = Err_Ok Then
      Update t_So_Trx_Headers Sth
         Set Sth.State            = Pkg_Trx.Ts_Locked,
             Sth.Last_Updated_By  = 1,
             Sth.Last_Update_Date = Sysdate
       Where Sth.idTrx_Id = p_Trx_Id;
    End If;

    If p_Result = Err_Ok Then
      Commit;
    Else
      Rollback To Savepoint Procstart;
    End If;
  Exception
    When Others Then
      Rollback To Savepoint Procstart;
      p_Result := Err_Unknow || Sqlerrm;
  End;

  --解锁发票
  Procedure Unlock_Trx(p_Trx_Id In t_So_Trx_Headers.idTrx_Id%Type --打印队列ID
                      ,
                       p_Result Out Varchar2
                       --返回值
                       ) Is
    Vstate t_So_Trx_Headers.State%Type;

    Vcount Number;
  Begin
    p_Result := Err_Ok;
    Savepoint Procstart;

    --MDCSS.检测售后接口表是否存在，是则表明为售后的发票单据，更新掉即可
    /*Begin
      Select Count(*)
        Into Vcount
        From t_Css_Oi_So_Trx Sth
       Where Sth.Trx_Id = p_Trx_Id;
      If Vcount > 0 Then
        --2013年4月25日 增加反写CSS系统写过的配件发票，打印回写。更新售后发票头接口表
        Select Sth.State
          Into Vstate
          From t_Css_Oi_So_Trx Sth
         Where Sth.Trx_Id = p_Trx_Id
           For Update;
        --判断发票的状态是否可以锁定
        If Vstate Not In (Pkg_Trx.Ts_Locked) Then
          p_Result := Err_Trx_State_Err;
        End If;
        If p_Result = Err_Ok Then
          Update t_Css_Oi_So_Trx Sth
             Set Sth.State            = Pkg_Trx.Ts_In_Queue,
                 Sth.Last_Updated_By  = 0,
                 Sth.Last_Update_Date = Sysdate
           Where Sth.Trx_Id = p_Trx_Id;
          Commit;
          Return;
        Else
          Rollback To Savepoint Procstart;
          Return;
        End If;
      End If;
    End;*/

    Begin
      Select Sth.State
        Into Vstate
        From t_So_Trx_Headers Sth
       Where Sth.idTrx_Id = p_Trx_Id
         For Update;
      --判断发票的状态是否可以解锁
      If Vstate Not In (Pkg_Trx.Ts_Locked) Then
        p_Result := Err_Trx_State_Err;
      End If;
    Exception
      When No_Data_Found Then
        p_Result := Err_No_Queue;
    End;

    If p_Result = Err_Ok Then
      Update t_So_Trx_Headers Sth
         Set Sth.State            = Pkg_Trx.Ts_In_Queue,
             Sth.Last_Updated_By  = 1,
             Sth.Last_Update_Date = Sysdate
       Where Sth.idTrx_Id = p_Trx_Id;
    End If;

    If p_Result = Err_Ok Then
      Commit;
    Else
      Rollback To Savepoint Procstart;
    End If;
  Exception
    When Others Then
      Rollback To Savepoint Procstart;
      p_Result := Err_Unknow || Sqlerrm;
  End;

End Pkg_Trx_Oi;
/

