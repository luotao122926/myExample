create Package      Pkg_Pln_Lg_Order Is
  -- Author  : NICRO.LI
  -- Created : 2014-09-09 15:49:26
  -- Purpose : 提货订单处理包
  
  ------------------------------------------------------------------------------------------
  ---- AUTHOR  : Nicro.Li
  -- CREATED : 2016-06-20
  -- PURPOSE : 提货订单产能可视检查、产能不足时方法默认返回成功，但会同时返回产可视异常信息
  ------------------------------------------------------------------------------------------
  Procedure p_Chk_Item_Capacity(p_Entity_Id        In Number, --主体ID
                                p_Order_Head_Id    In Number, ----订单头ID
                                p_User_Code        In Varchar2, ----用户ID
                                p_Result           In Out Varchar2, --成功则反回 SUCCESS 失败则返回失败原因
                                p_Chk_Msg          In Out Varchar2  --产能检查不通过时返回错误信息
                                );
                                
  -----------------------------------------------------------------
  --AUTHOR :吴林
  --CREATED : 2016-6-3
  --PURPOSE :提货订单从CCS过来时 自动评审到总部评审 允许修改扣率 并且调整扣款金额
  -----------------------------------------------------------------
  Procedure p_Adjust_Credit_Deductions(p_Order_Head_Id In Number,
                                       p_User_Code     In Varchar2,
                                       p_Result        Out Varchar2);
                                     
  -----------------------------------------------------------------------------
  ---- AUTHOR  : 李振
  -- CREATED : 2014-07-16 11:05:52
  -- PURPOSE : 执行提货订单或调拨申请操作
  -----------------------------------------------------------------------------
  Procedure p_Execute_Lgorder_Operate(p_Order_Head_Id    In Number, ----订单ID
                                      p_Operation_Action In Varchar2, --当前单据动作
                                      p_Next_State       In Varchar2, --下一状态值
                                      p_User_Code        In Varchar2, ----用户ID
                                      p_Result           In Out VARCHAR2 --返回结果：成功返回SUCCESS，失败返回原因
                                      );
  -----------------------------------------------------------------------------
  ---- AUTHOR  : 李振
  -- CREATED : 2014-09-09
  -- PURPOSE : 订单退回、审核驳回
  -----------------------------------------------------------------------------
  Procedure p_Back_Or_Close_Order(p_Order_Head_Id    In Number, ----订单头ID(如果没有则需传入-1)
                                  p_Operation_Action In Varchar2, --订单当前操作类型
                                  p_User_Code        In Varchar2, ----用户ID
                                  p_Result           In Out Varchar2, ----退回原因,/返回结果
                                  p_Close_Line_Flag  In Varchar2 Default 'N' --是否关闭订单行 --add by lizhen 2016-06-07
                                  );
  -----------------------------------------------------------------------------
  -- AUTHOR  : 李振
  -- CREATED : 2015-02-10
  -- PURPOSE : 提货订单自动评审计划订单发货计划
  -----------------------------------------------------------------------------
  Procedure p_Lgorder_Shareship_Review(p_Order_Head_Id In Number, ----订单ID
                                       p_User_Code     In Varchar2, ----用户ID
                                       p_Result        In Out Varchar2, --返回结果：成功返回SUCCESS，失败返回原因
                                       p_Ship_Match_Batch_Id in number default -1
                                       );
   -----------------------------------------------------------------------------
  -- AUTHOR  : 徐鸿就
  -- CREATED : 2015-07-09
  -- PURPOSE : 检查提交的产品总体积
  -----------------------------------------------------------------------------
  Procedure p_Lgorder_Check_Ship_Batch(p_Order_Head_Id In Number, ----订单ID
                                       p_Result        In Out Varchar2, --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                       p_Message       Out Varchar2     --返回信息：如果是SUCCESS，但p_Message不为空时，则说明是小于系统设置的参数
                                                                        --          如果是FAILURE,则是过程运行的时候抛出的错误,记录在p_Message中。
                                       );


  -----------------------------------------------------------------------------
  -- AUTHOR  : 李振
  -- CREATED : 2014-09-09
  -- PURPOSE : 提货订单、调拨申请 总部评审
  -----------------------------------------------------------------------------
  Procedure p_Hq_Review_Order(p_Order_Head_Id    In Number, ----订单ID
                              p_Operation_Action In Varchar2, --当前单据动作
                              p_User_Code        In Varchar2, ----用户ID
                              p_Result           Out VARCHAR2 --返回结果：成功返回SUCCESS，失败返回原因
                              );

  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2015-08-14
  -- PURPOSE : 提货订单T+3模式汇总
  -----------------------------------------------------------------------------
  Procedure p_T3_Lgorder_Collect(p_Entity_Id        In Number, --订单ID
                                 p_Check_Begin_Date In Date, --送审开始日期
                                 p_Check_End_Date   In Date, --送审结束日期
                                 p_User_Code        In Varchar2, --用户编码
                                 p_Result           In Out Varchar2 --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                 );

  -----------------------------------------------------------------------------
  -- AUTHOR  : ZhangCC
  -- CREATED : 2015-08-14
  -- PURPOSE : 提货订单汇总数据转T+3订单
  -----------------------------------------------------------------------------
  Procedure p_T3_LgMake_PlnOrder(p_Entity_Id         In Number , --主体ID
                                 P_Period_id         In Number,--周期ID
                                 p_order_type_ID     In Number,--订单类型ID
                                 p_COLLECT_HEAD_ID In Number , --提货提货订单头ID
                                 p_User_Code          In Varchar2, --用户编码
                                 p_Result             IN Out VarChar2  --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                 );

  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2015-08-19
  -- PURPOSE : 提货订单汇总数据保存
  -----------------------------------------------------------------------------
  Procedure p_T3_Save_Change(p_Entity_Id       In Number, --主体ID
                             p_Collect_Head_Id In Number, --提货提货订单头ID
                             p_User_Code       In Varchar2, --用户编码
                             p_Result          In Out Varchar2 --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                             );
  -----------------------------------------------------------------------------
  -- AUTHOR  : 徐鸿就
  -- CREATED : 2015-08-17
  -- PURPOSE : 批量发货
  -----------------------------------------------------------------------------
  Procedure p_Lgorder_Bulk_Shipment(p_Order_Head_Id    In Number, ----订单ID
                                    p_Operation_Action In Varchar2, --当前单据动作
                                    p_User_Code        In Varchar2, ----用户ID
                                    p_Result           Out Varchar2 --返回结果：成功返回SUCCESS，失败返回原因
                                    );
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2015-10-19
  -- PURPOSE : 提货订单T+3模式汇总01
  -----------------------------------------------------------------------------
  Procedure p_T3_Lgorder_Collect01(p_Entity_Id        In Number, --订单ID
                                 p_Check_Begin_Date In Date, --送审开始日期
                                 p_Check_End_Date   In Date, --送审结束日期
                                 p_User_Code        In Varchar2, --用户编码
                                 p_Result           In Out Varchar2 --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                 );
   -----------------------------------------------------------------------------
  -- AUTHOR  : ZhangCC
  -- CREATED : 2015-10-20
  -- PURPOSE : 提货订单汇总数据转T+3订单01
  -----------------------------------------------------------------------------
  Procedure p_T3_LgMake_PlnOrder01( p_COLLECT_HEAD_ID In Number , --提货提货订单头ID
                                    p_User_Code          In Varchar2, --用户编码
                                    p_Result             IN Out VarChar2,  --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                    p_period_id      IN NUMBER default Null, --结转周期
                                    p_Order_Type_Id   In Number default Null --订单类型ID
                                 );
 -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2015-10-21
  -- PURPOSE : 提货订单汇总数据保存01
  -----------------------------------------------------------------------------
  Procedure p_T3_Save_Change01( p_Collect_Head_Id In Number, --提货提货订单头ID
                              p_User_Code       In Varchar2, --用户编码
                              p_Result          In Out Varchar2 --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                             );
   -----------------------------------------------------------------------------
  -- AUTHOR  : ex_zhangcc
  -- CREATED : 2015-11-11
  -- PURPOSE : 提货订单T+3模式汇总02
  -----------------------------------------------------------------------------
  Procedure p_T3_Lgorder_Collect02(p_Entity_Id        In Number, --订单ID
                                 p_Check_Begin_Date In Date, --送审开始日期
                                 p_Check_End_Date   In Date, --送审结束日期
                                 p_User_Code        In Varchar2, --用户编码
                                 p_Result           In Out Varchar2 --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                 );

  -----------------------------------------------------------------------------
  -- AUTHOR  : 何加源
  -- CREATED : 2015-12-08
  -- PURPOSE : 提货订单转T+3时部分结转时回写取消数量
  -----------------------------------------------------------------------------
  PROCEDURE p_T3_Lg_To_Pln_Upd_Lg_Qty(p_Entity_Id     In Number, --订单ID
                                      p_Order_Head_Id In Number, --提货汇总订单头ID
                                      p_Collect_Flag  IN VARCHAR2, --是否汇总订单
                                      p_User_Code     In Varchar2, --用户编码
                                      p_Result        In Out Varchar2 --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                     );
  -----------------------------------------------------------------------------
  -- AUTHOR  : ex_zhangcc
  -- CREATED : 2015-12-21
  -- PURPOSE : 计算T+3订单排产优先级
  -----------------------------------------------------------------------------
  PROCEDURE P_CALCUL_T3_PRIORITY( P_collect_lg_head_id IN NUMBER,--T3汇总头ID
                                  P_USER_code          In VARCHAR2,--用户编码
                                  P_result             IN OUT VARCHAR2, --返回结果
                                  IN_COLLECT_TYPE      IN VARCHAR2 DEFAULT 'N+1'
                                 )  ;    
 ------------------------------------------------------------------------------
  Procedure p_LockOrRelease_Money(p_Entity_Id     In Number, --订单ID
                                  p_Order_Head_Id In Number, --提货汇总订单头ID
                                  p_Action_Type   In Number,  --动作类型：1锁款，2解款
                                  p_User_Code     In Varchar2, --用户编码
                                  p_Result        In Out Varchar2 --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                  );
                                  
  -----------------------------------------------------------------------------
  -- AUTHOR  : lizhen
  -- CREATED : 2016-3-21
  -- PURPOSE : 预排管理删除提货订单行功能处理
  -----------------------------------------------------------------------------
  Procedure p_Deletet3relation(p_Lg_Order_Line_Id In Number,   --提货订单行ID
                               p_User_Code        In Varchar2,
                               p_Result           Out Varchar2);

  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2016-4-8
  -- PURPOSE : 提货订单预排汇总功能
  -----------------------------------------------------------------------------
  Procedure p_Collect_WorkThrough_Lgorder(p_Entity_id In Number,   --主体ID
                                          p_Period_Code IN VARCHAR2, --周期编码
                                          p_Begin_Date IN DATE, --起始单据日期
                                          p_End_Date IN DATE, --终止单据日期
                                          p_User_Code In Varchar2,
                                          p_Result    Out Varchar2);
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2016-4-8
  -- PURPOSE : 按产品获取库存可用量
  -----------------------------------------------------------------------------
  PROCEDURE p_Get_Inv_Onhand_By_Item(p_Entity_id IN NUMBER, --主体ID
                                     p_Item_id   IN NUMBER, --产品ID
                                     p_Usable_Qty OUT NUMBER, --可用量
                                     p_Result    OUT VARCHAR2);
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2016-7-22
  -- PURPOSE : 提货订单预占用库存
  -----------------------------------------------------------------------------
  PROCEDURE P_LG_ORDER_PRE_OCCUPY(P_ORDER_HEAD_ID IN NUMBER, --提货订单头ID
                                  P_USER_CODE     IN VARCHAR2, --操作用户
                                  P_RESULT        OUT VARCHAR2);
                                  
  -----------------------------------------------------------------------------
  -- AUTHOR  : lilh6
  -- CREATED : 2019-5-30
  -- PURPOSE : 代销单预占用库存
  -----------------------------------------------------------------------------
  PROCEDURE P_DX_ORDER_PRE_OCCUPY(P_ORDER_HEAD_ID IN NUMBER, --代销单头ID
                                  P_USER_CODE     IN VARCHAR2, --操作用户
                                  p_pre_lock_flag In Varchar2,  --预占用处理标识，Y 执行占用，N 执行释放
                                  P_RESULT        OUT Varchar2);
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-08-04
  -- PURPOSE : T+3提货订单汇总，可做N+1预排处理，支持不同周期预排
  -----------------------------------------------------------------------------   
  Procedure p_T3_Lgorder_Collect03(p_Entity_Id        In Number, --订单ID
                                   p_Check_Begin_Date In Date, --送审开始日期
                                   p_Check_End_Date   In Date, --送审结束日期
                                   p_Period_Code      In Varchar2, --周期编码
                                   p_User_Code        In Varchar2, --用户编码
                                   p_Result           In Out Varchar2 --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                   );
                                   
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2018-08-17
  -- PURPOSE : 提货订单汇总数据转T+3订单,多主体处理
  -----------------------------------------------------------------------------
  Procedure p_Lgcollect_To_Plnorder_All(p_Collect_Head_Id In Number, --提货汇总订单头ID
                                        p_Order_Type_Id   In Number, --计划订单类型ID                  
                                        p_User_Code       In Varchar2, --用户编码
                                        p_Result          In Out Varchar2, --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                        IN_PERIOD_ID      IN NUMBER default null --结转周期
                                        );
                                   
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2016-08-17
  -- PURPOSE : 提货订单汇总预排数据转T+3订单，单一主体数据处理
  -----------------------------------------------------------------------------
  Procedure p_Lgcollect_To_PlnOrder_Single(p_Entity_Id       In Number, --主体ID
                                           p_Order_Type_Id   In Number, --订单类型ID
                                           p_Collect_Head_Id In Number, --提货提货订单头ID
                                           p_User_Code       In Varchar2, --用户编码
                                           p_Result          In Out Varchar2, --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                           IN_PERIOD_ID      IN Number default null --结转周期
                                           );
  
  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2016-09-21
  -- PURPOSE : 齐套补货检查
  -----------------------------------------------------------------------------
  Procedure P_CAR_LOAD_REPL_CHK(p_Entity_Id       In Number, --主体ID
                                P_ORDER_HEAD_ID   In Number, --订单ID
                                P_CARLOAD_MEET_NUM In VARCHAR2, --齐套号
                                p_User_Code       In Varchar2, --用户编码
                                p_Result          In Out Varchar2 --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                );

  ------------------------------------------------------------------------------------------
  ---- AUTHOR  : ex_dengjh
  -- CREATED : 2017-04-05
  -- PURPOSE : 获取产品严控标识及分配量
  ------------------------------------------------------------------------------------------
  Procedure p_Chk_Item_Capacity_and_assign(IN_ENTITY_ID        in NUMBER, --主体ID
                                           IN_ORDER_HEAD_ID    in NUMBER, --订单ID
                                           IN_USER_CODE        in VARCHAR2, --用户
                                           OUT_RESULT          out VARCHAR2, --返回结果，成功返回SUCCESS，否则返回错误信息
                                           OUT_CAP_STRICT_FLAG out VARCHAR2, --产能严控标志
                                           OUT_CHK_MSG         out VARCHAR2 --产能检查不通过时返回提示信息
                                           );
  ------------------------------------------------------------------------------------------
  ---- AUTHOR  : ex_dengjh
  -- CREATED : 2017-04-07
  -- PURPOSE : 根据订单行ID，占用分配量
  ------------------------------------------------------------------------------------------
  Procedure p_pln_assign_occupy(IN_ENTITY_ID     in NUMBER, --主体ID
                                IN_ORDER_HEAD_ID in NUMBER, --提货订单ID
                                IN_ORDER_LINE_ID in NUMBER, --提货订单行ID
                                IN_ASSIGN_QTY    in NUMBER, --处理数量
                                IN_ASSIGN_SIGN   in NUMBER, --占用标志，1：占用，-1：释放
                                IN_USER_CODE     in VARCHAR2, --用户
                                OUT_RESULT       out VARCHAR2 --返回结果，成功返回SUCCESS，否则返回错误信息
                                );
------------------------------------------------------------------------------------------
  ---- AUTHOR  : lizhen
  -- CREATED : 2017-04-07
  -- PURPOSE : 销司提货订单结账致总部
  ------------------------------------------------------------------------------------------
  Procedure p_Scorder_To_Hqorder(In_Lg_Order_Head_Id In Number, --提货订单头ID
                                 In_Carload_Meet_Num In Varchar2, --提货订单齐套号
                                 In_User_Code        In Varchar2, --用户
                                 Out_Result          Out Varchar2 --返回结果，成功返回SUCCESS，否则返回错误信息
                                 );
                                 
  ------------------------------------------------------------------------------------------
  -- AUTHOR  : lizhen
  -- CREATED : 2017-09-25
  -- PURPOSE : 提货订单评审发货时订单金额不足时写入评审错误信息
  ------------------------------------------------------------------------------------------
  Procedure p_Insert_Review_Error(In_Lg_Order_Head   Number,
                                  In_Sales_Main_Type Varchar2,
                                  In_Discount_Type   Varchar2,
                                  In_Amount          Number,
                                  In_Discount_Amount Number,
                                  In_Error_Msg       Varchar2,
                                  In_User_Code       Varchar2,
                                  Out_Result         Varchar2);
  
  ------------------------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2017-10-30
  -- PURPOSE : 回写提货订单总部直发下达数量
  ------------------------------------------------------------------------------------------
  procedure p_Update_Lg_Order_Direct_Qty(In_Lg_Order_Id in number, --单据ID
                                         In_Lg_Order_Line_Id in number, --单据行ID
                                         In_Qty in number, --数量
                                         In_Qty_Sign in number, --方向 增加1，减少-1
                                         In_User_Code in Varchar2, --用户
                                         Out_Result out Varchar2 --结果
                                         );
  ------------------------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2018-3-13
  -- PURPOSE : 预约直发确认
  ------------------------------------------------------------------------------------------
  PROCEDURE P_PLN_DIRECT_TRANSPORT(IN_ENTITY_ID    IN NUMBER, --事业部ID
                                   IN_PERIOD_CODE  IN VARCHAR2, --订单周期
                                   IN_USER_CODE    IN VARCHAR2, --操作用户
                                   IS_IGNORE       IN VARCHAR2, --是否跳过款项异常
                                   OUT_LG_BATCH_DEAL_NUM OUT NUMBER, --物流处理批次
                                   OUT_RESULT      OUT VARCHAR2 --返回结果
    );
  ------------------------------------------------------------------------------------------
  -- AUTHOR  : lilh6
  -- CREATED : 2019-4-3
  -- PURPOSE : 预约直发确认(工单匹配模式）
  ------------------------------------------------------------------------------------------
  Procedure p_Pln_Direct_Transport_Wip(In_Entity_Id          In Number, --事业部ID
                                       In_Batch_Num          In Varchar2, --评审批次
                                       In_User_Code          In Varchar2, --操作用户
                                       IS_IGNORE       IN VARCHAR2, --是否跳过款项异常
                                       Out_Lg_Batch_Deal_Num Out Number, --物流处理批次
                                       Out_Result            Out Varchar2 --返回结果
                                       );
  
  ------------------------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2018-2-28
  -- PURPOSE : 定制提货订单结转T+3
  ------------------------------------------------------------------------------------------
  PROCEDURE P_LGORDER_TO_PLNORDER_SINGLE(IN_LG_ORDER_ID IN NUMBER, --提货订单ID
                                         IN_USER_CODE   IN VARCHAR2, --操作用户
                                         OUT_RESULT     OUT VARCHAR2 --处理结果
    );
  
  ------------------------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2018-8-21
  -- PURPOSE : 提货订单自动评审
  ------------------------------------------------------------------------------------------
  PROCEDURE P_LGORDER_AUTO_SHIP(IN_LG_ORDER_ID IN NUMBER, --提货订单ID
                                OUT_RESULT     OUT VARCHAR2 --处理结果
    );
  ------------------------------------------------------------------------------------------
  -- AUTHOR  : zhouly2
  -- CREATED : 2018-10-25
  -- PURPOSE : 提货订单评审前检查是否维护年度任务，任务比
  ------------------------------------------------------------------------------------------
  PROCEDURE P_LGORDER_CHECK_TASK_PROP(IN_LG_ORDER_ID IN NUMBER, --提货订单ID
                                OUT_RESULT     OUT VARCHAR2 --处理结果
    );
  -----------------------------------------------------------------------------
  -- AUTHOR  : lilh6
  -- CREATED : 2019-04-13
  -- PURPOSE : 提货订单提交自动匹配计划订单发货
  -----------------------------------------------------------------------------
  Procedure p_Lgorder_Match_Plnorder(p_Order_Head_Id In Number, ----提货订单订单ID
                                     p_User_Code     In Varchar2, ----用户编码
                                     p_Result        In Out Varchar2 --返回结果：成功返回SUCCESS，失败返回原因
                                     );
------------------------------------------------------------------------------------------
 ---- AUTHOR  : lilh6
  -- CREATED : 2019-03-05
  -- PURPOSE : 代销订单评审结转
  ------------------------------------------------------------------------------------------
  Procedure p_dxorder_To_lgorder(In_dx_Order_Head_Id In Number, --提货订单头ID
                                 in_Operation_Action In Varchar2, --当前单据动作
                                 In_User_Code        In Varchar2, --用户
                                 Out_Result          Out Varchar2 --返回结果，成功返回SUCCESS，否则返回错误信息
                                 );
                                 
  -----------------------------------------------------------------------------
  -- 订单评审检查冻结数
  -----------------------------------------------------------------------------
  Procedure p_review_check_freeze(
                                  p_Entity_Id           In Number, --主体ID
                                  p_Inventory_Id        In Number, --指定仓库
                                  p_Item_Id             In Number, --指定产品
                                  p_affirm_quantity     In Number, --订单评审数
                                  p_Result              In Out VARCHAR2 --返回结果：成功返回SUCCESS，失败返回原因
                                  );
                                  
End Pkg_Pln_Lg_Order;
/

