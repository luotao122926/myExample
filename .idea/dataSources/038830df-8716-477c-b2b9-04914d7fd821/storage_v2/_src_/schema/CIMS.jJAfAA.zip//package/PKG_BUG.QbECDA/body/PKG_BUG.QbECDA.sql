create PACKAGE BODY      PKG_BUG IS

  PROCEDURE P_SO_GEN(  P_RESULT       IN OUT NUMBER, --返回错误ID
                        P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                        )  IS
    --销售单据头
    CURSOR C_SO_HEADER IS
      select sh.*
        from cims.t_so_header sh
       where sh.so_num in
             ('140072974');

    R_SO_HEADER C_SO_HEADER%ROWTYPE;
  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;

    FOR R_SO_HEADER IN C_SO_HEADER LOOP
      P_SO_TO_ERP(R_SO_HEADER.SO_HEADER_ID,
                  'GEN','F',P_RESULT,P_ERR_MSG  ) ;
      P_SO_TO_ERP(R_SO_HEADER.SO_HEADER_ID,
                  'CHANGE','F',P_RESULT,P_ERR_MSG  ) ;
    END LOOP;

  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28018;
      P_ERR_MSG := '添加到与ERP系统对接的接口表出错：' ||
                   P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28018;
      P_ERR_MSG := '添加到与ERP系统对接的接口表发生异常：' || SQLERRM;
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-21
  *   功能说明：把销售单据添加到与ERP系统对接的接口表，并配置调用的接口。
  *   参数说明：P_ERP_TRX_CODE 调用ERP接口代码：GEN(生成)
  *                                             INV(挑库)
  *                                             SHIP(发运)
  *                                             CHANGE(变更)
  *                                             RMA_RECV(RMA接收)
  *                                             BOOK(登记)
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_TO_ERP(P_SO_HEADER_ID IN VARCHAR2, --销售单据头ID
                        P_ERP_TRX_CODE IN VARCHAR2, --调用ERP接口代码
                        P_STATUS    IN VARCHAR2,    --接口状态
                        P_RESULT       IN OUT NUMBER, --返回错误ID
                        P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                        ) IS
    --销售单据头
    CURSOR C_SO_HEADER IS
      SELECT * FROM T_SO_HEADER WHERE SO_HEADER_ID = P_SO_HEADER_ID;
    R_SO_HEADER C_SO_HEADER%ROWTYPE;

    --ERP系统对接销售订单头接口表
    R_OE_HEADERS INTF_OE_HEADERS_IFACE_ALL%ROWTYPE;

    --接口头ID
    V_OE_HEADERS_ID NUMBER;
    --接口交易ID
    V_TRX_ID NUMBER;
    --状态
    V_STATUS CHAR(1) := 'N';

    --订单来源，统一写“CIMS”
    V_ORDER_SOURCE CHAR(4) := 'CIMS';
    --ERP订单类型ID
    V_ORDER_TYPE_ID NUMBER;
    --ERP订单类型编码
    V_ORDER_TYPE VARCHAR2(40);
    --价格列表
    V_PRICE_LIST VARCHAR2(240) := 'CIMS价格表';
    --币种，内销固定填“CNY”
    V_CURR_CODE VARCHAR2(15) := 'CNY';
    --区域代码：销售单上的区域代码，客户收货地址上的区域代码
    V_SALESREP    VARCHAR2(240);
    V_SALESREP_ID NUMBER;
    --付款条件，固定填1000，表示立即付款
    V_PAYMENT_TERM_ID NUMBER := 1000;
    --固定填“N”
    V_PARTIAL_SHIPMENTS_ALLOWED CHAR(1) := 'N';
    --填客户信息里的收货方地点代码，固定值“缺省”
    V_SHIP_TO_ORG VARCHAR2(240) := '缺省';
    --填固定值“缺省”，客户信息里的收单方地点代码
    V_INVOICE_TO_ORG VARCHAR2(240) := '缺省';

    --登记标识，折让和折让证明以及他们的红冲，填“N“，否则填”Y“
    V_BOOKED_FLAG CHAR(1);

    --操作代码：新建：INSERT；修改：UPDATE
    V_OPERATION_CODE        VARCHAR2(20);
    V_OPERATION_CODE_INSERT VARCHAR2(20) := 'INSERT';
    --OPERATION_CODE_UPDATE VARCHAR2(20) := 'UPDATE';

    --应收发票配置信息
    V_AR_CONFIG PKG_SO_PUB.AR_CONFIG;
    --账龄起始日期
    V_AR_AGE_BEGIN_DATE DATE;

    --结算日期
    V_SETTLE_DATE DATE;

    --账户、客户、销售中心信息记录集
    V_ACCOUNT_INFO ACCOUNT_INFO;

    --接口表中销售单据的数量（防重复）
    V_SO_CNT NUMBER;

    --是否库存验证：Y/N (Y为需要验证库存可用量，N为不用验证)
    V_VALIDATE_FLAG CHAR(1) := PKG_SO_PUB.V_NO;

    --发运组织ID、编码
    V_SHIP_FROM_ORG_ID NUMBER;
    V_SHIP_FROM_ORG    VARCHAR2(100);

    --账龄开始日期参数
    V_BILLAGE_BEGIN_DATE VARCHAR2(20);

    -- chenzh 加 推式或拉式
    V_PUSH_OR_PULL VARCHAR2(32);
    --关联交易模式 chen.wj
    V_SO_TRX_MODE VARCHAR2(10);

    V_ATTRIBUTE7 INTF_OE_HEADERS_IFACE_ALL.ATTRIBUTE7%TYPE;

    V_PULL_MODE       NUMBER;
    V_AR_CONF_INITIAL T_AR_CONF.AR_CONF_INITIAL%TYPE;

    --销售单据类型的数量（如果存在，取单据类型，否则取销售单据源类型）
    V_SO_COUNT NUMBER;
    PP_SO_HEADER_ID VARCHAR2(32);

  BEGIN
    --初始返回值
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;
    V_STATUS  :=  P_STATUS ;
    PP_SO_HEADER_ID := to_char(to_number(P_SO_HEADER_ID)*10);

    --获取sequence值作为接口交易ID
    SELECT S_OE_HEADERS_IFACE_ALL.NEXTVAL INTO V_TRX_ID FROM DUAL;

    --获取销售单据头数据
    OPEN C_SO_HEADER;
    FETCH C_SO_HEADER
      INTO R_SO_HEADER;
    CLOSE C_SO_HEADER;

    --若是GEN(生成)，则在接口头和行表生成新的记录；否则更新原记录。
    IF (P_ERP_TRX_CODE = 'GEN') THEN
      --操作代码
      V_OPERATION_CODE := V_OPERATION_CODE_INSERT;

      --防重复检查
      SELECT COUNT(*)
        INTO V_SO_CNT
        FROM INTF_OE_HEADERS_IFACE_ALL
       WHERE ORIG_SYS_DOCUMENT_REF = PP_SO_HEADER_ID
         AND OPERATION_CODE = V_OPERATION_CODE;

      IF V_SO_CNT > 0 THEN
        P_ERR_MSG := '销售单据[单据号：' || R_SO_HEADER.SO_NUM ||
                     ']已经引入到与ERP对接的接口表[INTF_OE_HEADERS_IFACE_ALL]' || TO_CHAR(P_SO_HEADER_ID) || ':' || V_OPERATION_CODE;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;

      --接口头表ID
      SELECT S_OE_HEADERS_IFACE_ALL.NEXTVAL INTO V_OE_HEADERS_ID FROM DUAL;

      --优先取销售单据类型，销售单据类型为空时再取单源类型(龙鸿文)
      SELECT COUNT(1)
        INTO V_SO_COUNT
        FROM V_SO_TYPE_EXTEND_RELATION
       WHERE BILL_TYPE_ID = R_SO_HEADER.BILL_TYPE_ID
         AND ORG_ID = R_SO_HEADER.ERP_OU_ID
         AND ENTITY_ID = R_SO_HEADER.ENTITY_ID
         AND ROWNUM = 1;
       IF V_SO_COUNT > 0 THEN
          --获取对应的ERP订单类型
          SELECT TRANSACTION_TYPE_ID, NAME
            INTO V_ORDER_TYPE_ID, V_ORDER_TYPE
            FROM V_SO_TYPE_EXTEND_RELATION
           WHERE BILL_TYPE_ID = R_SO_HEADER.BILL_TYPE_ID
             AND ORG_ID = R_SO_HEADER.ERP_OU_ID
             AND ENTITY_ID = R_SO_HEADER.ENTITY_ID
             AND ROWNUM = 1;
       ELSE
          --获取对应的ERP订单类型(源类型)
          BEGIN
            SELECT TRANSACTION_TYPE_ID, NAME
              INTO V_ORDER_TYPE_ID, V_ORDER_TYPE
              FROM V_SO_ERP_TYPE_RELATION
             WHERE SRC_TYPE_ID = R_SO_HEADER.BIZ_SRC_BILL_TYPE_ID
               AND ORG_ID = R_SO_HEADER.ERP_OU_ID
               AND ENTITY_ID = R_SO_HEADER.ENTITY_ID
               AND ROWNUM = 1;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              P_ERR_MSG := '销售单据类型[源类型ID：' || R_SO_HEADER.BIZ_SRC_BILL_TYPE_ID || ',编码：' || R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE
                         || ',名称：' || R_SO_HEADER.BIZ_SRC_BILL_TYPE_NAME ||
                           ']没有配置对应的ERP订单类型或ERP订单类型不属于当前OU[OU ID：' ||
                           R_SO_HEADER.ERP_OU_ID || ',名称：' || R_SO_HEADER.ERP_OU_NAME || ']';
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
            WHEN OTHERS THEN
              P_ERR_MSG := '获取对应的ERP订单类型发生异常：' || SQLERRM;
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          END;
         END IF;

      --SALESREP销售代表：收货地址上的区域段，根据收货地址所在行政区域：省市的区域段编码
      --获取区域代码：省市行政区域编码(T_BD_DISTRICT)
      --V_SALESREP := R_SO_HEADER.CONSIGNEE_PROVINCE_CODE||R_SO_HEADER.CONSIGNEE_CITY_CODE;
      V_SALESREP := R_SO_HEADER.CONSIGNEE_CITY_CODE;
      IF (V_SALESREP IS NULL) OR (V_SALESREP = '') THEN
          BEGIN
              --获取账户、客户、销售中心信息
              V_ACCOUNT_INFO := F_GET_ACCOUNT_INFO(R_SO_HEADER.ACCOUNT_ID,
                       R_SO_HEADER.ENTITY_ID);
          EXCEPTION
            WHEN OTHERS THEN
              P_ERR_MSG := '根据账户ID：' || R_SO_HEADER.ACCOUNT_ID || ',主体ID：' ||
                           R_SO_HEADER.ENTITY_ID || '获取账户信息异常，请检查。' || SQLERRM;
              RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          END;
          V_SALESREP     := V_ACCOUNT_INFO.CITY;
      END IF;
      --销售代表ID

      IF V_SALESREP IS NULL THEN
        V_SALESREP_ID := -3;
      END IF;

      --登记标识
      V_BOOKED_FLAG := 'N';

      --增加推拉判断 add by chen.wj 20150305
      BEGIN
        V_PUSH_OR_PULL :=R_SO_HEADER.TRX_MODE;
        IF V_PUSH_OR_PULL IS NULL THEN
          PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_ARG_SO_AR_PUSH_OR_PULL,
                                       R_SO_HEADER.ENTITY_ID,
                                       NULL,
                                       NULL,
                                       V_PUSH_OR_PULL);
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := 'SO_AR_PUSH_OR_PULL主体参数,主体id:' ||
                       R_SO_HEADER.ENTITY_ID || '的参数设置异常，请检查。' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
      /*
             单据类型     来源子库    目标子库
             销售单       发货仓      中间仓
             销售红冲单   中间仓      发货仓
             退货单       中间仓      收货仓
             退货红冲单   收货仓      中间仓
      */
      --根据业务单据源类型，指定来源子库和目标子库
      IF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO) THEN
        --销售单：发货仓库 -〉中间仓库（发货仓对应的未结算仓）
        R_OE_HEADERS.ORIGINAL_SUBINVENTORY := R_SO_HEADER.SHIP_INV_CODE; --来源
        R_OE_HEADERS.SUBINVENTORY          := R_SO_HEADER.MIDDLE_INV_CODE; --目标
      ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED) THEN
        --销售红冲单：中间仓库（退未结算仓） -〉发货仓库
        R_OE_HEADERS.ORIGINAL_SUBINVENTORY := R_SO_HEADER.MIDDLE_INV_CODE;
        R_OE_HEADERS.SUBINVENTORY          := R_SO_HEADER.SHIP_INV_CODE;
      ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN
        --退货单：中间仓库（退货未结算仓） -〉收货仓库（退货仓）
        R_OE_HEADERS.ORIGINAL_SUBINVENTORY := R_SO_HEADER.MIDDLE_INV_CODE;
        R_OE_HEADERS.SUBINVENTORY          := R_SO_HEADER.CONSIGNEE_INV_CODE;
      ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
        --退货红冲单：收货仓库（退货仓） -〉中间仓库（未结算仓）
        R_OE_HEADERS.ORIGINAL_SUBINVENTORY := R_SO_HEADER.CONSIGNEE_INV_CODE;
        R_OE_HEADERS.SUBINVENTORY          := R_SO_HEADER.MIDDLE_INV_CODE;
      END IF;

      --根据调用接口代码，设置操作代码值。
      R_OE_HEADERS.GEN_TRX_ID     := V_TRX_ID;
      R_OE_HEADERS.GEN_TRX_STATUS := V_STATUS;
      R_OE_HEADERS.GEN_TRX_DATE   := SYSDATE;

      --退货单、销售红冲单，在ERP系统生成退货订单RMA，销售单、退货红冲单在ERP系统生成销售订单
      --单据源类型编码：1002销售红冲单，1003退货单
      IF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
         PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED OR
         R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
         PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) THEN
        R_OE_HEADERS.RETURN_REASON_CODE := 'RETURN';
      ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN
            (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT,
              PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT)) THEN
        --销售折让单、折让证明单在ERP系统也是作为退货处理
        R_OE_HEADERS.RETURN_REASON_CODE := 'RETURN';
      ELSE
        R_OE_HEADERS.RETURN_REASON_CODE := '';
      END IF;

      --折让单及其红冲单，发运组织取OU下对应的库存组织
      IF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN
         (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT,
           PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT_RED,
           PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT,
           PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT_RED,
           PKG_SO_PUB.V_BIZ_SRC_BILL_RATE,
           PKG_SO_PUB.V_BIZ_SRC_BILL_RATE_RED)) THEN
        BEGIN
          SELECT ORGANIZATION_ID, ORGANIZATION_CODE
            INTO V_SHIP_FROM_ORG_ID, V_SHIP_FROM_ORG
            FROM T_INV_ORGANIZATION
           WHERE ENTITY_ID = R_SO_HEADER.ENTITY_ID
             AND OPERATING_UNIT = R_SO_HEADER.ERP_OU_ID
             AND (TRUNC(SYSDATE) BETWEEN USER_DEFINITION_ENABLE_DATE AND
                 NVL(DISABLE_DATE, SYSDATE))
             AND ROWNUM = 1;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            P_ERR_MSG := '根据OU ID[' || R_SO_HEADER.ERP_OU_ID ||
                         ']获取库存组织出错：' ||
                         '库存组织表（T_INV_ORGANIZATION）不存在该OU ID或已超出有效期或不属于主体[ID：' ||
                         R_SO_HEADER.ENTITY_ID || ']。';
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
          WHEN OTHERS THEN
            P_ERR_MSG := '根据OU ID[' || R_SO_HEADER.ERP_OU_ID ||
                         ']获取库存组织发生异常：' || SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
      ELSE
        --拉式时为工厂库存组织
        V_SHIP_FROM_ORG_ID := R_SO_HEADER.ERP_SUBINV_ID;
        V_SHIP_FROM_ORG    := R_SO_HEADER.ERP_SUBINV_CODE;
      END IF;


      R_OE_HEADERS.ORG_ID := R_SO_HEADER.ERP_OU_ID;
      /*引ERP头表都填写内销*/
      IF (V_PUSH_OR_PULL = 'PULL') AND
         R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN
         (PKG_SO_PUB.V_BIZ_SRC_BILL_SO,
          PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED,
          PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN,
          PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) AND
         NVL(R_SO_HEADER.IS_MATERIAL, 'N') = 'N' THEN
        BEGIN
          --add by chen.wj 20150206
          -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
          V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE(R_SO_HEADER.SO_NUM);
          SELECT DECODE(V_PULL_MODE,
                        1,
                        PKG_SO_PUB.V_SO_TRX_MODE_003,
                        2,
                        PKG_SO_PUB.V_SO_TRX_MODE_004,
                        3,
                        PKG_SO_PUB.V_SO_TRX_MODE_004,
                        4,
                        PKG_SO_PUB.V_SO_TRX_MODE_005,
                        5,
                        PKG_SO_PUB.V_SO_TRX_MODE_003,
                        V_PULL_MODE)
            INTO V_SO_TRX_MODE
            FROM DUAL;
          --edit by chen.wj 20150304
          IF V_SO_TRX_MODE = PKG_SO_PUB.V_SO_TRX_MODE_005 THEN


            SELECT A.SUPPLIER_OU_ID,
                   A.SUPPLIER_SUBINV_ID,
                   A.SUPPLIER_SUBINV_CODE,
                   A.SUPPLIER_SUBINVENTORY_CODE,
                   A.SUPPLIER_SUBINVENTORY_CODE AS SUBINVENTORY_CODE1
              INTO R_OE_HEADERS.ORG_ID,
                   V_SHIP_FROM_ORG_ID,
                   V_SHIP_FROM_ORG,
                   R_OE_HEADERS.ORIGINAL_SUBINVENTORY,
                   R_OE_HEADERS.SUBINVENTORY
              FROM T_SO_SUPPLIER_REQUIREMENT A
             WHERE A.TRADE_MODE_CODE = V_SO_TRX_MODE
               AND A.ENTITY_ID = R_SO_HEADER.ENTITY_ID
               AND A.REQUIREMENT_OU_ID = R_SO_HEADER.FACTORY_OU_ID
               AND A.SUPPLIER_OU_ID = R_SO_HEADER.ERP_OU_ID;
          ELSE
            SELECT A.REQUIREMENT_OU_ID,
                   A.ERP_SUBINV_ID,
                   A.ERP_SUBINV_CODE,
                   A.SUBINVENTORY_CODE,
                   A.SUBINVENTORY_CODE AS SUBINVENTORY_CODE1
              INTO R_OE_HEADERS.ORG_ID,
                   V_SHIP_FROM_ORG_ID,
                   V_SHIP_FROM_ORG,
                   R_OE_HEADERS.ORIGINAL_SUBINVENTORY,
                   R_OE_HEADERS.SUBINVENTORY
              FROM T_SO_SUPPLIER_REQUIREMENT A
             WHERE A.TRADE_MODE_CODE = V_SO_TRX_MODE
               AND A.ENTITY_ID = R_SO_HEADER.ENTITY_ID
               AND A.REQUIREMENT_OU_ID = R_SO_HEADER.ERP_OU_ID
               AND A.SUPPLIER_OU_ID = R_SO_HEADER.FACTORY_OU_ID;

          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_MSG := '主体id[' || R_SO_HEADER.ENTITY_ID || '],供方OU ID[' ||
                         R_SO_HEADER.FACTORY_OU_ID || '],关联交易模式编码[' ||
                         V_SO_TRX_MODE ||
                         ']，在T_SO_SUPPLIER_REQUIREMENT表参数设置异常，请检查。' ||
                         SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;
      END IF;

      R_OE_HEADERS.OE_HEADERS_ID         := V_OE_HEADERS_ID;
      R_OE_HEADERS.ORDER_SOURCE          := V_ORDER_SOURCE;
      R_OE_HEADERS.ORIG_SYS_DOCUMENT_REF := TO_CHAR(PP_SO_HEADER_ID);
      --R_OE_HEADERS.ORG_ID                    := R_SO_HEADER.ERP_OU_ID;/**/
      R_OE_HEADERS.ORDER_NUMBER              := '88'||R_SO_HEADER.SO_NUM;
      R_OE_HEADERS.ORDERED_DATE              := R_SO_HEADER.SO_DATE;
      R_OE_HEADERS.ORDER_TYPE_ID             := V_ORDER_TYPE_ID;
      R_OE_HEADERS.ORDER_TYPE                := V_ORDER_TYPE;
      R_OE_HEADERS.PRICE_LIST                := V_PRICE_LIST;
      R_OE_HEADERS.TRANSACTIONAL_CURR_CODE   := V_CURR_CODE;
      R_OE_HEADERS.SALESREP                  := V_SALESREP;
      R_OE_HEADERS.SALESREP_ID               := V_SALESREP_ID;
      R_OE_HEADERS.PAYMENT_TERM_ID           := V_PAYMENT_TERM_ID;
      R_OE_HEADERS.PARTIAL_SHIPMENTS_ALLOWED := V_PARTIAL_SHIPMENTS_ALLOWED;
      R_OE_HEADERS.SHIP_TO_ORG               := V_SHIP_TO_ORG;
      R_OE_HEADERS.INVOICE_TO_ORG            := V_INVOICE_TO_ORG;
      --R_OE_HEADERS.SOLD_TO_ORG               := R_SO_HEADER.CUSTOMER_NAME;
      R_OE_HEADERS.SOLD_TO_ORG    := R_SO_HEADER.CUSTOMER_CODE;
      R_OE_HEADERS.SHIP_FROM_ORG_ID := V_SHIP_FROM_ORG_ID; /**/
      R_OE_HEADERS.SHIP_FROM_ORG    := V_SHIP_FROM_ORG; /**/
      --R_OE_HEADERS.SHIP_FROM_ORG_ID := R_SO_HEADER.ERP_SUBINV_ID;
      --R_OE_HEADERS.SHIP_FROM_ORG    := R_SO_HEADER.ERP_SUBINV_CODE;
      R_OE_HEADERS.BOOKED_FLAG      := V_BOOKED_FLAG;
      R_OE_HEADERS.OPERATION_CODE   := V_OPERATION_CODE;
      R_OE_HEADERS.CREATED_BY       := R_SO_HEADER.CREATED_BY;
      R_OE_HEADERS.CREATION_DATE    := R_SO_HEADER.CREATION_DATE;
      R_OE_HEADERS.LAST_UPDATED_BY  := R_SO_HEADER.LAST_UPDATED_BY;
      R_OE_HEADERS.LAST_UPDATE_DATE := R_SO_HEADER.LAST_UPDATE_DATE;
      R_OE_HEADERS.ATTRIBUTE2       := R_SO_HEADER.ORIG_SO_NUM; --头弹性域（红冲单原单单号）
      R_OE_HEADERS.ATTRIBUTE3       := R_SO_HEADER.SALES_CENTER_CODE; --头弹性域（中心编码：销售公司，小电指中心）
      IF R_OE_HEADERS.ORDERED_DATE IS NOT NULL THEN
        --yyyy-mm-dd hh24:mi:ss
        R_OE_HEADERS.ATTRIBUTE6 := TO_CHAR(R_OE_HEADERS.ORDERED_DATE,
                                           'yyyy-mm-dd'); --头弹性域（账龄起始日期）
      END IF;

      --往接口表添加销售单据数据
      PKG_BUG.P_SO_TO_ERP_CREATE(R_SO_HEADER,
                                    R_OE_HEADERS,
                                    V_STATUS,
                                    P_RESULT,
                                    P_ERR_MSG);

    ELSIF P_ERP_TRX_CODE = 'INV' THEN
      --INV(挑库)
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET INV_TRX_ID     = V_TRX_ID,
             INV_TRX_STATUS = V_STATUS,
             INV_TRX_DATE   = SYSDATE
       WHERE ORIG_SYS_DOCUMENT_REF = R_SO_HEADER.SO_HEADER_ID
         AND ORDER_NUMBER = R_SO_HEADER.SO_NUM
         AND OPERATION_CODE = V_OPERATION_CODE_INSERT
         AND ROWNUM = 1;

    ELSIF P_ERP_TRX_CODE = 'CHANGE' THEN
      --CHANGE(SO变更)
      --销售折让及红冲单据、让证明及红冲结算后触发销售订单变更接口，变更状态为登记
      --销售单结算后触发销售订单变更接口

      --获取ERP接口头ID
      BEGIN
        SELECT OE_HEADERS_ID
          INTO V_OE_HEADERS_ID
          FROM INTF_OE_HEADERS_IFACE_ALL
         WHERE ORIG_SYS_DOCUMENT_REF = PP_SO_HEADER_ID
           AND ORDER_NUMBER = '88'||R_SO_HEADER.SO_NUM
           AND OPERATION_CODE = V_OPERATION_CODE_INSERT
           AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          /*P_ERR_MSG := '获取ERP接口头ID出错：没有符合条件[ORIG_SYS_DOCUMENT_REF=' ||
                       R_SO_HEADER.SO_HEADER_ID || ' AND OPERATION_CODE=''' ||
                       V_OPERATION_CODE_INSERT || ''' AND ROWNUM=1]的数据。';*/
          P_ERR_MSG:='请检查SO生成记录是否生成！销售单号['|| R_SO_HEADER.SO_NUM||']';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        WHEN OTHERS THEN
          P_ERR_MSG := '获取ERP接口头ID发生异常。' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;

      --获取账龄起始日期
      IF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
         PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED) OR
         (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
         PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT) OR
         (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
         PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT_RED) THEN
        --销售红冲单、销售折让单及其红冲单，账龄起始日期写为单据日期；
        V_AR_AGE_BEGIN_DATE := R_SO_HEADER.SO_DATE;
      ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN) OR
            (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) OR
            (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT) OR
            (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT_RED) THEN
        --退货单、退货红冲单、折让证明单及其红冲单，账龄起始日期写为结算日期；
        V_AR_AGE_BEGIN_DATE := R_SO_HEADER.SETTLE_DATE;
      ELSIF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
            PKG_SO_PUB.V_BIZ_SRC_BILL_SO) THEN
        --销售单：账龄起始日期根据业务应收确认始点配置写入单据日期或是收货确认日期
        --获取应收发票配置信息
        /*
        注释 by chen.wj 20150317 统一从财务那边取值
        */
        /*V_AR_CONFIG := PKG_SO_PUB.F_GET_AR_CONFIG(R_SO_HEADER.CUSTOMER_ID,
        R_SO_HEADER.SALES_CENTER_ID,
        R_SO_HEADER.ENTITY_ID,
        R_SO_HEADER.ERP_OU_ID);*/
        /*IF (V_AR_CONFIG.AR_CONF_INITIAL = 'SHIP_FLAG') THEN
          --应收账龄取发货确认时间
          V_AR_AGE_BEGIN_DATE := R_SO_HEADER.SHIP_DATE;
        ELSIF (V_AR_CONFIG.AR_CONF_INITIAL = 'RECEIVE_FLAG') THEN
          --应收账龄取收货确认
          V_AR_AGE_BEGIN_DATE := R_SO_HEADER.RECEIVE_DATE;
        ELSIF (V_AR_CONFIG.AR_CONF_INITIAL = 'CHECKED_ACCOUNT_FLAG') THEN
          --应收账龄取客户对账
          V_AR_AGE_BEGIN_DATE := R_SO_HEADER.CHECKED_ACCOUNT_DATE;
        END IF;*/
        SELECT AR_CONF_INITIAL
          INTO V_AR_CONF_INITIAL
          FROM TABLE(PKG_AR_INVOICE.F_GET_AR_CONFIG(R_SO_HEADER.ENTITY_ID,
                                                    R_SO_HEADER.SALES_CENTER_ID,
                                                    R_SO_HEADER.CUSTOMER_ID,
                                                    R_SO_HEADER.ERP_OU_ID));
        IF (V_AR_CONF_INITIAL = 'SHIP_FLAG') THEN
          --应收账龄取发货确认时间
          V_AR_AGE_BEGIN_DATE := R_SO_HEADER.SHIP_DATE;
        ELSIF (V_AR_CONF_INITIAL = 'RECEIVE_FLAG') THEN
          --应收账龄取收货确认
          V_AR_AGE_BEGIN_DATE := R_SO_HEADER.RECEIVE_DATE;
        ELSIF (V_AR_CONF_INITIAL = 'CHECKED_ACCOUNT_FLAG') THEN
          --应收账龄取客户对账
          V_AR_AGE_BEGIN_DATE := R_SO_HEADER.CHECKED_ACCOUNT_DATE;
        ELSE
          P_RESULT  := -28018;
          P_ERR_MSG := 'T_AR_CONF表查询不到应收配置实点信息，请维护！实体ID[' ||
                       R_SO_HEADER.ENTITY_ID || ']，营销中心ID[' ||
                       R_SO_HEADER.SALES_CENTER_ID || ']，客户ID[' ||
                       R_SO_HEADER.CUSTOMER_ID || ']，OU_ID[' ||
                       R_SO_HEADER.ERP_OU_ID || ']';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END IF;
      ELSE
        /* add by shengy 20150120 */
        BEGIN
          PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_ARG_SO_AR_PUSH_OR_PULL,
                                       R_SO_HEADER.ENTITY_ID,
                                       NULL,
                                       NULL,
                                       V_BILLAGE_BEGIN_DATE);
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_MSG := 'SO_BILLAGE_BEGIN_DATE主体参数,主体id:' ||
                         R_SO_HEADER.ENTITY_ID || '的参数设置异常，请检查。' || SQLERRM;
            RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END;

        IF V_BILLAGE_BEGIN_DATE = 'SHIP_DATE' THEN
          --家用空调：发货确认时间（即单据日期）为账龄起始日期
          V_AR_AGE_BEGIN_DATE := R_SO_HEADER.SO_DATE;
        ELSIF V_BILLAGE_BEGIN_DATE = 'RECEIVE_DATE' THEN
          --厨房电器：签收时间为账龄起始日期
          V_AR_AGE_BEGIN_DATE := R_SO_HEADER.RECEIVE_DATE;
        END IF;

        /*mark by shengy 20150120
        --其他单据类型
        IF R_SO_HEADER.ENTITY_ID = PKG_SO_PUB.V_ENTITY_ID_MDK THEN
          --家用空调：发货确认时间（即单据日期）为账龄起始日期
          V_AR_AGE_BEGIN_DATE := R_SO_HEADER.SO_DATE;
        ELSIF R_SO_HEADER.ENTITY_ID = PKG_SO_PUB.V_ENTITY_ID_MDC THEN
          --厨房电器：签收时间为账龄起始日期
          V_AR_AGE_BEGIN_DATE := R_SO_HEADER.RECEIVE_DATE;
        END IF;*/

      END IF;

      --add by shengy 20150128 结算日期是否为空判断
      V_SETTLE_DATE := R_SO_HEADER.SETTLE_DATE;
      IF V_SETTLE_DATE IS NULL THEN
        P_ERR_MSG := '结算日期为空，请检查！';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;

      --更新ERP接口头信息
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET UPDATE_TRX_ID     = V_TRX_ID,
             UPDATE_TRX_STATUS = V_STATUS,
             UPDATE_TRX_DATE   = SYSDATE,
             BOOKED_FLAG       = PKG_SO_PUB.V_YES,
             ATTRIBUTE6        = TO_CHAR(V_AR_AGE_BEGIN_DATE, 'yyyy-MM-dd'), --账龄起始日期
             ATTRIBUTE7        = TO_CHAR(V_SETTLE_DATE, 'yyyy-MM-dd') --结算日期 20150127 chen.wj 增加
       WHERE OE_HEADERS_ID = V_OE_HEADERS_ID;

      --更新ERP接口行上套机行的价格
      UPDATE INTF_OE_LINES_IFACE_ALL OL
         SET OL.UNIT_SELLING_PRICE =
             (SELECT SL.ITEM_SETTLE_PRICE
                FROM T_SO_LINE SL
               WHERE SL.SO_HEADER_ID = P_SO_HEADER_ID
                 AND SL.SO_LINE_ID = OL.ORIG_SYS_LINE_REF)
       WHERE OL.OE_HEADERS_ID = V_OE_HEADERS_ID
         AND OL.ITEM_TYPE_CODE = 'MODEL'
         AND EXISTS (SELECT 1
                FROM T_SO_LINE
               WHERE SO_HEADER_ID = P_SO_HEADER_ID
                 AND SO_LINE_ID = OL.ORIG_SYS_LINE_REF);

      --更新ERP接口行上套件的散件产品价格为0
      UPDATE INTF_OE_LINES_IFACE_ALL OL
         SET OL.UNIT_SELLING_PRICE =
             (SELECT 0
                FROM T_SO_LINE_DETAIL LD
               WHERE LD.SO_HEADER_ID = P_SO_HEADER_ID
                 AND LD.SO_LINE_DETAIL_ID = OL.ORIG_SYS_SHIPMENT_REF)
       WHERE OL.OE_HEADERS_ID = V_OE_HEADERS_ID
         AND OL.ITEM_TYPE_CODE = 'OPTION'
         AND EXISTS
       (SELECT 1
                FROM T_SO_LINE_DETAIL
               WHERE SO_HEADER_ID = P_SO_HEADER_ID
                 AND SO_LINE_DETAIL_ID = OL.ORIG_SYS_SHIPMENT_REF);

      --更新ERP接口行上的散件产品价格
      UPDATE INTF_OE_LINES_IFACE_ALL OL
         SET OL.UNIT_SELLING_PRICE =
             (SELECT LD.COMPONENT_SETTLE_PRICE
                FROM T_SO_LINE_DETAIL LD
               WHERE LD.SO_HEADER_ID = P_SO_HEADER_ID
                 AND LD.SO_LINE_DETAIL_ID = OL.ORIG_SYS_SHIPMENT_REF)
       WHERE OL.OE_HEADERS_ID = V_OE_HEADERS_ID
         AND (OL.ITEM_TYPE_CODE IS NULL OR OL.ITEM_TYPE_CODE = '')
         AND EXISTS
       (SELECT 1
                FROM T_SO_LINE_DETAIL
               WHERE SO_HEADER_ID = P_SO_HEADER_ID
                 AND SO_LINE_DETAIL_ID = OL.ORIG_SYS_SHIPMENT_REF);

      --是否库存验证：需出库（即销售单与退货红冲单）时才设置为Y
      IF (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_SO_PUB.V_BIZ_SRC_BILL_SO) OR
         (R_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE =
         PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) THEN
        V_VALIDATE_FLAG := PKG_SO_PUB.V_YES;
      END IF;

      --更新是否库存验证标识：VALIDATE_FLAG，套件行不需要验证
      UPDATE INTF_OE_LINES_IFACE_ALL
         SET VALIDATE_FLAG = V_VALIDATE_FLAG
       WHERE OE_HEADERS_ID = V_OE_HEADERS_ID
         AND (ITEM_TYPE_CODE IS NULL OR ITEM_TYPE_CODE != 'MODEL');

      --套件行不需要验证
      UPDATE INTF_OE_LINES_IFACE_ALL
         SET VALIDATE_FLAG = 'N'
       WHERE OE_HEADERS_ID = V_OE_HEADERS_ID
         AND ITEM_TYPE_CODE = 'MODEL';

    ELSIF P_ERP_TRX_CODE = 'SHIP' THEN
      --SHIP(发运)
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET SHIP_TRX_ID     = V_TRX_ID,
             SHIP_TRX_STATUS = V_STATUS,
             SHIP_TRX_DATE   = SYSDATE
       WHERE ORIG_SYS_DOCUMENT_REF = R_SO_HEADER.SO_HEADER_ID
         AND ORDER_NUMBER = R_SO_HEADER.SO_NUM
         AND OPERATION_CODE = V_OPERATION_CODE_INSERT
         AND ROWNUM = 1;
    ELSIF P_ERP_TRX_CODE = 'RMA_RECV' THEN
      /*↓↓↓↓↓↓↓↓↓↓↓↓↓ add by chen.wj 20150209 增加开始 ↓↓↓↓↓↓↓↓↓↓↓↓↓*/
      BEGIN
        SELECT ATTRIBUTE7
          INTO V_ATTRIBUTE7
          FROM INTF_OE_HEADERS_IFACE_ALL
         WHERE ORIG_SYS_DOCUMENT_REF = R_SO_HEADER.SO_HEADER_ID
           AND ORDER_NUMBER = R_SO_HEADER.SO_NUM
           AND OPERATION_CODE = V_OPERATION_CODE_INSERT
           AND ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
      --判断ERP接口表ATTRIBUTE7结算日期是否为空，如果为空则重新取结算日期赋值。
      IF V_ATTRIBUTE7 IS NULL OR V_ATTRIBUTE7 = '' THEN
        --add by chen.wj 20150206 结算日期是否为空判断
        V_SETTLE_DATE := R_SO_HEADER.SETTLE_DATE;
        IF V_SETTLE_DATE IS NULL THEN
          P_ERR_MSG := '结算日期为空，请检查！';
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
        END IF;

        UPDATE INTF_OE_HEADERS_IFACE_ALL
           SET RMA_RECEIVE_TRX_ID     = V_TRX_ID,
               RMA_RECEIVE_TRX_STATUS = V_STATUS,
               RMA_RECEIVE_TRX_DATE   = SYSDATE,
               ATTRIBUTE7             = TO_CHAR(V_SETTLE_DATE, 'yyyy-MM-dd') --结算日期 20150206 chen.wj 增加
         WHERE ORIG_SYS_DOCUMENT_REF = R_SO_HEADER.SO_HEADER_ID
           AND ORDER_NUMBER = R_SO_HEADER.SO_NUM
           AND OPERATION_CODE = V_OPERATION_CODE_INSERT
           AND ROWNUM = 1;
      ELSE
        UPDATE INTF_OE_HEADERS_IFACE_ALL
           SET RMA_RECEIVE_TRX_ID     = V_TRX_ID,
               RMA_RECEIVE_TRX_STATUS = V_STATUS,
               RMA_RECEIVE_TRX_DATE   = SYSDATE
        --ATTRIBUTE7        = TO_CHAR(V_SETTLE_DATE, 'yyyy-MM-dd') --结算日期 20150206 chen.wj 增加
         WHERE ORIG_SYS_DOCUMENT_REF = R_SO_HEADER.SO_HEADER_ID
           AND ORDER_NUMBER = R_SO_HEADER.SO_NUM
           AND OPERATION_CODE = V_OPERATION_CODE_INSERT
           AND ROWNUM = 1;
      END IF;
      /*↑↑↑↑↑↑↑↑↑↑↑↑↑ add by chen.wj 20150209 增加结束 ↑↑↑↑↑↑↑↑↑↑↑↑↑ */
      --add by chen.wj 20150206 结算日期是否为空判断

      --RMA_RECV(RMA接收)
      /*UPDATE INTF_OE_HEADERS_IFACE_ALL
        SET RMA_RECEIVE_TRX_ID     = V_TRX_ID,
            RMA_RECEIVE_TRX_STATUS = V_STATUS,
            RMA_RECEIVE_TRX_DATE   = SYSDATE
      WHERE ORIG_SYS_DOCUMENT_REF = R_SO_HEADER.SO_HEADER_ID
        AND ORDER_NUMBER = R_SO_HEADER.SO_NUM
        AND OPERATION_CODE = V_OPERATION_CODE_INSERT
        AND ROWNUM = 1;*/

    ELSIF P_ERP_TRX_CODE = 'BOOK' THEN
      --BOOK(登记)
      UPDATE INTF_OE_HEADERS_IFACE_ALL
         SET BOOK_TRX_ID     = V_TRX_ID,
             BOOK_TRX_STATUS = V_STATUS,
             BOOK_TRX_DATE   = SYSDATE,
             BOOKED_FLAG     = PKG_SO_PUB.V_YES
       WHERE ORIG_SYS_DOCUMENT_REF = R_SO_HEADER.SO_HEADER_ID
         AND ORDER_NUMBER = R_SO_HEADER.SO_NUM
         AND OPERATION_CODE = V_OPERATION_CODE_INSERT
         AND ROWNUM = 1;
    END IF;

  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28018;
      P_ERR_MSG := '销售单据[单据ID：' || P_SO_HEADER_ID || ']添加到与ERP系统对接的接口表出错：' ||
                   P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28018;
      P_ERR_MSG := '销售单据[单据ID：' || P_SO_HEADER_ID ||
                   ']添加到与ERP系统对接的接口表发生异常：' || SQLERRM;
  END;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-23
  *   功能说明：在与ERP系统对接接口头表和行表添加记录
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_SO_TO_ERP_CREATE(P_SO_HEADER  IN T_SO_HEADER%ROWTYPE, --销售单头
                               R_OE_HEADERS IN OUT INTF_OE_HEADERS_IFACE_ALL%ROWTYPE, --接口头
                               P_TRX_STATUS IN VARCHAR2, --交易状态
                               P_RESULT     IN OUT NUMBER, --返回错误ID
                               P_ERR_MSG    IN OUT VARCHAR2 --返回错误信息
                               ) IS
    --销售单据头ID
    V_SO_HEADER_ID T_SO_HEADER.SO_HEADER_ID%TYPE;

    CURSOR C_SO_LINE IS
      SELECT * FROM T_SO_LINE WHERE SO_HEADER_ID = V_SO_HEADER_ID;
    --销售单据行
    R_SO_LINE C_SO_LINE%ROWTYPE;

    --ERP系统对接销售订单行接口表
    R_OE_LINES INTF_OE_LINES_IFACE_ALL%ROWTYPE;

    --物料类型：套机-MODEL，内机-OPTION，室外机-OPTION
    V_ITEM_TYPE_CODE VARCHAR2(30);

    --散件价格（套件的散件价格为0）
    V_COMPONENT_PRICE NUMBER := 0;

    --是否对应ERP退货订单
    V_IS_RETURN_ORDER CHAR(1) := PKG_SO_PUB.V_NO;

    --退货原因（行）：RETURN-退货，PTO_RETURN-套件退货，PARTS_RETURN-散件退货，PTO_PARTS_RETURN-套件中的散件退货
    V_RETURN_REASON_CODE VARCHAR2(30);
    --行弹性域（退货原因）
    V_ATTRIBUTE3 VARCHAR2(30);
    --行弹性域（退货的时候从IMS传散件对应的套机码）
    V_ATTRIBUTE4 VARCHAR2(30);
    --行弹性域(上下文值)：（退货时必填，固定值:CIMS）
    V_CONTEXT VARCHAR2(30);

    --退货类型（退货要关联原订单时必填，固定值，ORDER)
    --V_RETURN_CONTEXT VARCHAR2(30) := 'ORDER';

    --税码（从快码表取，销售取VAT17_OUT）
    V_TAX_CODE UP_CODELIST.CODE_NAME%TYPE;

    --正负号：销售单、退货红冲单为正号，销售红冲单、退货单未负号
    V_SIGN NUMBER := 1;

    --chenzh 子库
    V_SUBINVENTORY VARCHAR2(10);
    V_PUSH_OR_PULL VARCHAR2(32);

    --关联交易模式 chen.wj
    V_SO_TRX_MODE VARCHAR2(10);

    V_PULL_MODE NUMBER;

    --税率
    V_TRX_RATE NUMBER;
    V_ORIG_SYS_LINE_REF	 VARCHAR2(100);
    V_ORIG_SYS_SHIPMENT_REF VARCHAR2(100);

  BEGIN
    P_RESULT  := PKG_SO_PUB.V_RESULT;
    P_ERR_MSG := PKG_SO_PUB.V_SUCCESS;

    V_SO_HEADER_ID := P_SO_HEADER.SO_HEADER_ID;

    --单据类型和单据源类型
    R_OE_HEADERS.BILL_TYPE_CODE         := P_SO_HEADER.BILL_TYPE_CODE;
    R_OE_HEADERS.BIZ_SRC_BILL_TYPE_CODE := P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE;
    R_OE_HEADERS.BILL_TYPE_NAME         := P_SO_HEADER.BILL_TYPE_NAME;
    R_OE_HEADERS.BIZ_SRC_BILL_TYPE_NAME := P_SO_HEADER.BIZ_SRC_BILL_TYPE_NAME;

    --退货单、销售红冲单，在ERP系统生成退货订单RMA，销售单、退货红冲单在ERP系统生成销售订单
    IF (P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN
       (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED, PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN)) THEN
      V_IS_RETURN_ORDER := PKG_SO_PUB.V_YES;
      --退货原因
      V_RETURN_REASON_CODE := 'RETURN';
      --正负号：销售单、退货红冲单为正号，销售红冲单、退货单为负号
      V_SIGN    := -1;
      V_CONTEXT := 'CIMS';
    ELSIF (P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN
          (PKG_SO_PUB.V_BIZ_SRC_BILL_SO_DISCOUNT,
            PKG_SO_PUB.V_BIZ_SRC_BILL_DISCOUNT)) THEN
      --销售折让单、折让证明单在ERP系统也是作为退货处理
      V_IS_RETURN_ORDER := PKG_SO_PUB.V_YES;
      --退货原因
      V_RETURN_REASON_CODE := 'RETURN';
      --正负号：销售折让单、折让证明单为负号，销售折让红冲单、折让证明红冲单为负号
      V_SIGN    := -1;
      V_CONTEXT := 'CIMS';
    ELSE
      V_IS_RETURN_ORDER := PKG_SO_PUB.V_NO;
      --正负号：销售单、退货红冲单为正号，销售红冲单、退货单未负号
      V_SIGN := 1;
    END IF;

    --从快码表取税码
  /*↓↓↓↓↓↓↓↓↓↓↓↓↓ add by chen.wj 20150418 增加开始 ↓↓↓↓↓↓↓↓↓↓↓↓↓*/
    BEGIN
      SELECT TRX_RATE
        INTO V_TRX_RATE
        FROM TABLE(PKG_AR_INVOICE.F_GET_AR_CONFIG(P_SO_HEADER.ENTITY_ID,
                                                  P_SO_HEADER.SALES_CENTER_ID,
                                                  P_SO_HEADER.CUSTOMER_ID,
                                                  P_SO_HEADER.ERP_OU_ID));
      IF V_TRX_RATE IS NULL THEN
        P_RESULT  := -28018;
        P_ERR_MSG := 'T_AR_CONF表查询不到税率，请维护！实体ID[' || P_SO_HEADER.ENTITY_ID ||
                     ']，营销中心ID[' || P_SO_HEADER.SALES_CENTER_ID ||
                     ']，客户ID[' || P_SO_HEADER.CUSTOMER_ID || ']，OU_ID[' ||
                     P_SO_HEADER.ERP_OU_ID || ']';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END IF;

    END;

    BEGIN
      SELECT CODE_NAME
        INTO V_TAX_CODE
        FROM UP_CODELIST
       WHERE CODETYPE = 'SO_TAX_RATE_CODE'
         AND CODE_VALUE = TO_CHAR(V_TRX_RATE);
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT  := -28018;
        P_ERR_MSG := 'UP_CODELIST表查询不到税码，请维护！代码类型[SO_TAX_RATE_CODE]，代码值[' ||
                     V_TRX_RATE || ']';
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
   /*↑↑↑↑↑↑↑↑↑↑↑↑↑ add by chen.wj 20150418 增加结束 ↑↑↑↑↑↑↑↑↑↑↑↑↑ */
    --往接口头表添加销售单据数据
    INSERT INTO INTF_OE_HEADERS_IFACE_ALL
      (OE_HEADERS_ID,
       GEN_TRX_ID,
       GEN_TRX_STATUS,
       GEN_TRX_DATE,
       INV_TRX_ID,
       INV_TRX_STATUS,
       INV_TRX_DATE,
       SHIP_TRX_ID,
       SHIP_TRX_STATUS,
       SHIP_TRX_DATE,
       UPDATE_TRX_ID,
       UPDATE_TRX_STATUS,
       UPDATE_TRX_DATE,
       BOOK_TRX_ID,
       BOOK_TRX_STATUS,
       BOOK_TRX_DATE,
       RMA_RECEIVE_TRX_ID,
       RMA_RECEIVE_TRX_STATUS,
       RMA_RECEIVE_TRX_DATE,
       ERROR_FLAG,
       ORDER_SOURCE,
       ORIG_SYS_DOCUMENT_REF,
       ORG_ID,
       ORDER_NUMBER,
       ORDERED_DATE,
       ORDER_TYPE_ID,
       ORDER_TYPE,
       PRICE_LIST,
       CONVERSION_RATE,
       CONVERSION_RATE_DATE,
       CONVERSION_TYPE_CODE,
       CONVERSION_TYPE,
       TRANSACTIONAL_CURR_CODE,
       SALESREP,
       SALESREP_ID,
       PAYMENT_TERM_ID,
       PARTIAL_SHIPMENTS_ALLOWED,
       SHIPPING_INSTRUCTIONS,
       PACKING_INSTRUCTIONS,
       CUSTOMER_PO_NUMBER,
       SHIP_TO_ORG_ID,
       SHIP_TO_ORG,
       INVOICE_TO_ORG_ID,
       INVOICE_TO_ORG,
       SOLD_TO_ORG_ID,
       SOLD_TO_ORG,
       SHIP_FROM_ORG_ID,
       SHIP_FROM_ORG,
       BOOKED_FLAG,
       OPERATION_CODE,
       RETURN_REASON_CODE,
       ORIGINAL_SUBINVENTORY,
       SUBINVENTORY,
       BILL_TYPE_CODE,
       BIZ_SRC_BILL_TYPE_CODE,
       BILL_TYPE_NAME,
       BIZ_SRC_BILL_TYPE_NAME,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE,
       ATTRIBUTE2, --头弹性域（红冲单原单单号）
       ATTRIBUTE3, --头弹性域（中心编码：销售公司，小电指中心）
       ATTRIBUTE6 --头弹性域（账龄起始日期）
       )
    VALUES
      (R_OE_HEADERS.OE_HEADERS_ID,
       R_OE_HEADERS.GEN_TRX_ID, --销售订单生成交易ID
       R_OE_HEADERS.GEN_TRX_STATUS, --销售订单生成交易状态（新建：N；提交：P；返回成功标志：S）
       R_OE_HEADERS.GEN_TRX_DATE, --销售订单生成交易日期
       R_OE_HEADERS.INV_TRX_ID, --挑库交易ID
       R_OE_HEADERS.INV_TRX_STATUS, --挑库交易状态
       R_OE_HEADERS.INV_TRX_DATE, --挑库交易日期
       R_OE_HEADERS.SHIP_TRX_ID, --发运交易ID
       R_OE_HEADERS.SHIP_TRX_STATUS, --发运交易状态
       R_OE_HEADERS.SHIP_TRX_DATE, --发运交易日期
       R_OE_HEADERS.UPDATE_TRX_ID, --SO变更（结算日期、价格调整等）交易ID
       R_OE_HEADERS.UPDATE_TRX_STATUS, --SO变更交易状态
       R_OE_HEADERS.UPDATE_TRX_DATE, --SO变更交易日期
       R_OE_HEADERS.BOOK_TRX_ID, --折让单登记交易ID
       R_OE_HEADERS.BOOK_TRX_STATUS, --折让单登记交易状态
       R_OE_HEADERS.BOOK_TRX_DATE, --折让单登记交易日期
       R_OE_HEADERS.RMA_RECEIVE_TRX_ID, --RMA接收交易ID
       R_OE_HEADERS.RMA_RECEIVE_TRX_STATUS, --RMA接收交易状态
       R_OE_HEADERS.RMA_RECEIVE_TRX_DATE, --RMA结算交易日期
       R_OE_HEADERS.ERROR_FLAG, --出错标记
       R_OE_HEADERS.ORDER_SOURCE, --订单来源，统一写“CIMS”
       R_OE_HEADERS.ORIG_SYS_DOCUMENT_REF, --销售单据头ID
       R_OE_HEADERS.ORG_ID, --ERP的OU ID
       R_OE_HEADERS.ORDER_NUMBER, --销售单据号
       R_OE_HEADERS.ORDERED_DATE, --订购日期（销售单据日期）
       R_OE_HEADERS.ORDER_TYPE_ID, --订单类型ID，数据来自销售单据类型和ERP订单类型的对照表
       R_OE_HEADERS.ORDER_TYPE, --订单类型编号
       R_OE_HEADERS.PRICE_LIST, --价格列表，固定写“CIMS价格表”
       R_OE_HEADERS.CONVERSION_RATE, --汇率相关，本位币订单，留空
       R_OE_HEADERS.CONVERSION_RATE_DATE, --汇率相关，本位币订单，留空
       R_OE_HEADERS.CONVERSION_TYPE_CODE, --汇率相关，本位币订单，留空
       R_OE_HEADERS.CONVERSION_TYPE, --汇率相关，本位币订单，留空
       R_OE_HEADERS.TRANSACTIONAL_CURR_CODE, --币种，内销固定填“CNY”
       R_OE_HEADERS.SALESREP, --销售代表，取销售单上的区域代码：客户收货地址上的区域代码
       R_OE_HEADERS.SALESREP_ID, --销售代表ID
       R_OE_HEADERS.PAYMENT_TERM_ID, --付款条件，固定填5，表示立即付款
       R_OE_HEADERS.PARTIAL_SHIPMENTS_ALLOWED, --固定填“N”
       R_OE_HEADERS.SHIPPING_INSTRUCTIONS, --留空，备用，可以写出货备注
       R_OE_HEADERS.PACKING_INSTRUCTIONS, --留空，备用，可以写出货备注
       R_OE_HEADERS.CUSTOMER_PO_NUMBER, --客户PO号码
       R_OE_HEADERS.SHIP_TO_ORG_ID, --与SHIP_TO_ORG，填一个就行了
       R_OE_HEADERS.SHIP_TO_ORG, --填客户信息里的收货方地点代码，固定值“默认”
       R_OE_HEADERS.INVOICE_TO_ORG_ID, --与INVOICE_TO_ORG，填一个就行了
       R_OE_HEADERS.INVOICE_TO_ORG, --填客户信息里的收单方地点代码，固定值“默认”
       R_OE_HEADERS.SOLD_TO_ORG_ID, --与SOLD_TO_ORG，填一个就行了。
       R_OE_HEADERS.SOLD_TO_ORG, --客户名称
       R_OE_HEADERS.SHIP_FROM_ORG_ID, --与SHIP_FROM_ORG，填一个就行了
       R_OE_HEADERS.SHIP_FROM_ORG, --出货库存组织编码
       R_OE_HEADERS.BOOKED_FLAG, --折让和折让证明以及他们的红冲，填“N“，否则填”Y“
       R_OE_HEADERS.OPERATION_CODE, --操作代码（新建：INSERT；修改：UPDATE）
       R_OE_HEADERS.RETURN_REASON_CODE, --退货必须，固定填“RETURN”
       R_OE_HEADERS.ORIGINAL_SUBINVENTORY, --来源子库（销售单发货仓库编码）
       R_OE_HEADERS.SUBINVENTORY, --目标子库（销售单发货仓库对应的未结算仓库编码）
       R_OE_HEADERS.BILL_TYPE_CODE, --业务单据类型编码
       R_OE_HEADERS.BIZ_SRC_BILL_TYPE_CODE, --业务单据源类型编码
       R_OE_HEADERS.BILL_TYPE_NAME, --业务单据类型名称
       R_OE_HEADERS.BIZ_SRC_BILL_TYPE_NAME, --业务单据源类型名称
       R_OE_HEADERS.CREATED_BY, --创建人ID。不写到ERP
       R_OE_HEADERS.CREATION_DATE, --创建时间。不写到ERP
       R_OE_HEADERS.LAST_UPDATED_BY, --修改人ID。不写到ERP
       R_OE_HEADERS.LAST_UPDATE_DATE, --修改时间。不写到ERP
       R_OE_HEADERS.ATTRIBUTE2, --头弹性域（红冲单原单单号）
       R_OE_HEADERS.ATTRIBUTE3, --头弹性域（中心编码：销售公司，小电指中心）
       R_OE_HEADERS.ATTRIBUTE6 --头弹性域（账龄起始日期）
       );
    /*chenzh 2015-02-05 变更子库*/
    V_SUBINVENTORY := R_OE_HEADERS.SUBINVENTORY;
    BEGIN
      V_PUSH_OR_PULL := P_SO_HEADER.TRX_MODE;
      IF V_PUSH_OR_PULL IS NULL THEN
        PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_PUB.V_ARG_SO_AR_PUSH_OR_PULL,
                                     P_SO_HEADER.ENTITY_ID,
                                     NULL,
                                     NULL,
                                     V_PUSH_OR_PULL);
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_MSG := 'SO_AR_PUSH_OR_PULL主体参数,主体id:' ||
                     P_SO_HEADER.ENTITY_ID || '的参数设置异常，请检查。' || SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;

    IF (V_PUSH_OR_PULL = 'PULL') AND
       P_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN
       (PKG_SO_PUB.V_BIZ_SRC_BILL_SO,
        PKG_SO_PUB.V_BIZ_SRC_BILL_SO_RED,
        PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN,
        PKG_SO_PUB.V_BIZ_SRC_BILL_RETURN_RED) AND
         NVL(P_SO_HEADER.IS_MATERIAL, 'N') = 'N' THEN
      BEGIN
        --add by chen.wj 20150206
        -- -1错误,0非拉式,1销售,2红冲,3源单退回,4反向销售,5源单退货红冲，6拉式其他单据类型
        V_PULL_MODE := PKG_SO_PUB.F_PULL_MODE(P_SO_HEADER.SO_NUM);
        SELECT DECODE(V_PULL_MODE,
                      1,
                      PKG_SO_PUB.V_SO_TRX_MODE_003,
                      2,
                      PKG_SO_PUB.V_SO_TRX_MODE_004,
                      3,
                      PKG_SO_PUB.V_SO_TRX_MODE_004,
                      4,
                      PKG_SO_PUB.V_SO_TRX_MODE_005,
                      5,
                      PKG_SO_PUB.V_SO_TRX_MODE_003,
                      V_PULL_MODE)
          INTO V_SO_TRX_MODE
          FROM DUAL;
        --edit by chen.wj 20150304
        IF V_SO_TRX_MODE = PKG_SO_PUB.V_SO_TRX_MODE_005 THEN
          SELECT T.SUPPLIER_SUBINVENTORY_CODE
            INTO V_SUBINVENTORY
            FROM T_SO_SUPPLIER_REQUIREMENT T
           WHERE T.ENTITY_ID = P_SO_HEADER.ENTITY_ID
             AND T.REQUIREMENT_OU_ID = P_SO_HEADER.FACTORY_OU_ID --反向销售供需需方找内销供方
             AND T.SUPPLIER_OU_ID = P_SO_HEADER.ERP_OU_ID
             AND T.TRADE_MODE_CODE = V_SO_TRX_MODE;
        ELSE
          SELECT T.SUBINVENTORY_CODE
            INTO V_SUBINVENTORY
            FROM T_SO_SUPPLIER_REQUIREMENT T
           WHERE T.ENTITY_ID = P_SO_HEADER.ENTITY_ID
             AND T.REQUIREMENT_OU_ID = P_SO_HEADER.ERP_OU_ID
             AND T.SUPPLIER_OU_ID = P_SO_HEADER.FACTORY_OU_ID
             AND T.TRADE_MODE_CODE = V_SO_TRX_MODE;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := '主体id[' || P_SO_HEADER.ENTITY_ID || '],供方OU ID[' ||
                       P_SO_HEADER.FACTORY_OU_ID || '],关联交易模式编码[' ||
                       V_SO_TRX_MODE ||
                       ']，在T_SO_SUPPLIER_REQUIREMENT表参数设置异常，请检查。' ||
                       SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    END IF;
    --PTO模式传三行或多行给ERP系统：套件独立一行，套件对应的每个散件独立一行
    --获取销售单行
    OPEN C_SO_LINE;
    LOOP
      FETCH C_SO_LINE
        INTO R_SO_LINE;
      EXIT WHEN C_SO_LINE%NOTFOUND;

      IF (R_SO_LINE.ITEM_IS_SET = PKG_SO_PUB.V_YES) THEN
        --套机
        V_ITEM_TYPE_CODE := 'MODEL';

        IF (V_IS_RETURN_ORDER = PKG_SO_PUB.V_YES) THEN
          --套件退货
          V_ATTRIBUTE3 := 'PTO_RETURN';
        ELSE
          V_ATTRIBUTE3 := '';
        END IF;

          V_ORIG_SYS_LINE_REF	 := null;
          V_ORIG_SYS_SHIPMENT_REF :=null;
          if R_SO_LINE.SO_LINE_ID is not null then
             V_ORIG_SYS_LINE_REF	 := to_char(to_number(R_SO_LINE.SO_LINE_ID)*10);
          end if;
        --套件作为接口行表的独立一行
        INSERT INTO INTF_OE_LINES_IFACE_ALL
          (OE_LINES_ID,
           OE_HEADERS_ID,
           TRX_ID,
           OPERATION_CODE,
           ERROR_FLAG,
           STATUS,
           ORIG_SYS_DOCUMENT_REF,
           ORIG_SYS_LINE_REF,
           LINE_NUMBER,
           ORG_ID,
           ORDERED_ITEM,
           ORDER_QUANTITY_UOM,
           ORDERED_QUANTITY,
           UNIT_SELLING_PRICE,
           RETURN_REASON_CODE,
           RETURN_CONTEXT,
           RETURN_ATTRIBUTE1,
           RETURN_ATTRIBUTE2,
           ITEM_TYPE_CODE,
           OPTION_FLAG,
           TAX_CODE,
           ATTRIBUTE1,
           ATTRIBUTE3,
           SUBINVENTORY,
           CONTEXT,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
        VALUES
          (S_OE_LINES_IFACE_ALL.NEXTVAL,
           R_OE_HEADERS.OE_HEADERS_ID,
           S_OE_HEADERS_IFACE_ALL.NEXTVAL, --WebService交易ID
           R_OE_HEADERS.OPERATION_CODE, --操作代码（新建：INSERT；修改：UPDATE）
           R_OE_HEADERS.ERROR_FLAG, --出错标记
           P_TRX_STATUS, --状态：新建：N；提交：P；返回成功标志：S；返回出错标志：E
           R_OE_HEADERS.ORIG_SYS_DOCUMENT_REF, --销售单据头ID
           V_ORIG_SYS_LINE_REF,--R_SO_LINE.SO_LINE_ID, --销售单据行ID
           R_SO_LINE.SO_LINE_NUM, --行号
           R_OE_HEADERS.ORG_ID, --ERP的OU ID
           R_SO_LINE.ITEM_CODE, --物料编码，即产品编码
           R_SO_LINE.ITEM_UOM, --物料编码单位，即产品/散件单位
           R_SO_LINE.ITEM_QTY * V_SIGN, --订单数据，即产品/散件的数量
           R_SO_LINE.ITEM_SETTLE_PRICE, --价格，即结算价格
           V_RETURN_REASON_CODE, --退货原因：PTO_RETURN 套件退货
           NULL, --RETURN_CONTEXT, --退货类型（退货要关联原订单时必填，固定值，ORDER)
           NULL, --RETURN_ATTRIBUTE1, --退货原订单头ID（退货要关联原订单时必填，退货原订单头ID）
           NULL, --RETURN_ATTRIBUTE2, --退货原订单行ID（退货要关联原订单时必填，退货原订单行ID）
           V_ITEM_TYPE_CODE, --物料类型（套机：MODEL、室内机：OPTION、室外机：OPTION）
           NULL, --OPTION_FLAG, --是否装置（为启用替代备用，暂填空）
           V_TAX_CODE, --TAX_CODE, --税码
           V_ORIG_SYS_SHIPMENT_REF,--R_SO_LINE.SO_LINE_ID, --ATTRIBUTE1 销售单据行ID
           V_ATTRIBUTE3, --ATTRIBUTE3 行弹性域（退货原因）：PTO_RETURN 套件退货
           V_SUBINVENTORY, --目标子库（销售单发货仓库对应的未结算仓库编码）
           V_CONTEXT, --行弹性域(上下文值)：（退货时必填，固定值:CIMS）
           R_OE_HEADERS.CREATED_BY,
           R_OE_HEADERS.CREATION_DATE,
           R_OE_HEADERS.LAST_UPDATED_BY,
           R_OE_HEADERS.LAST_UPDATE_DATE);
      END IF;

      --处理行明细
      DECLARE
        --销售单据行明细
        CURSOR C_SO_LINE_DETAIL IS
          SELECT *
            FROM T_SO_LINE_DETAIL
           WHERE SO_LINE_ID = R_SO_LINE.SO_LINE_ID;
        R_SO_LINE_DETAIL C_SO_LINE_DETAIL%ROWTYPE;

        --明细行号（主要是给ERP系统做配套时使用）
        V_ROW_NUM NUMBER;

      BEGIN
        --初始明细行号
        V_ROW_NUM := 0;

        --获取销售单据行明细数据
        OPEN C_SO_LINE_DETAIL;
        LOOP
          FETCH C_SO_LINE_DETAIL
            INTO R_SO_LINE_DETAIL;
          EXIT WHEN C_SO_LINE_DETAIL%NOTFOUND;

          --明细行号加1（即从1开始）
          V_ROW_NUM := V_ROW_NUM + 1;

          IF (V_IS_RETURN_ORDER = PKG_SO_PUB.V_YES AND
             R_SO_LINE.ITEM_IS_SET = PKG_SO_PUB.V_YES) THEN
            --PTO_PARTS_RETURN 套件中的散件退货
            V_ATTRIBUTE3 := 'PTO_PARTS_RETURN';
            --退货的时候从IMS传散件对应的套机码
            V_ATTRIBUTE4 := R_SO_LINE_DETAIL.ITEM_CODE;
          ELSIF (V_IS_RETURN_ORDER = PKG_SO_PUB.V_YES AND
                R_SO_LINE.ITEM_IS_SET != PKG_SO_PUB.V_YES) THEN
            --PARTS_RETURN 散件退货
            V_ATTRIBUTE3 := 'PARTS_RETURN';
            V_ATTRIBUTE4 := '';
          ELSE
            V_ATTRIBUTE3 := '';
            V_ATTRIBUTE4 := '';
          END IF;

          IF (R_SO_LINE.ITEM_IS_SET = PKG_SO_PUB.V_YES) THEN
            --套件中的散件
            V_ITEM_TYPE_CODE  := 'OPTION';
            V_COMPONENT_PRICE := 0;
          ELSE
            --散件（行是散件）
            V_ITEM_TYPE_CODE  := '';
            V_COMPONENT_PRICE := R_SO_LINE_DETAIL.COMPONENT_SETTLE_PRICE;
          END IF;

       --bb.ORIG_SYS_DOCUMENT_REF,  --t_so_header.so_head_id
       --bb.ORIG_SYS_LINE_REF,   --t_so_line.so_line_id
       --bb.ORIG_SYS_SHIPMENT_REF,  --t_so_line_detail.so_line_detail_id
       --bb.ATTRIBUTE1,   --t_so_line_detail.so_line_detail_id

          V_ORIG_SYS_LINE_REF	 := null;
          V_ORIG_SYS_SHIPMENT_REF :=null;
          if R_SO_LINE_DETAIL.SO_LINE_ID is not null then
             V_ORIG_SYS_LINE_REF	 := to_char(to_number(R_SO_LINE_DETAIL.SO_LINE_ID)*10);
          end if;
          if R_SO_LINE_DETAIL.SO_LINE_DETAIL_ID is not null then
             V_ORIG_SYS_SHIPMENT_REF := to_char(to_number(R_SO_LINE_DETAIL.SO_LINE_DETAIL_ID)*10);
          end if;
          --往接口行表插入记录
          INSERT INTO INTF_OE_LINES_IFACE_ALL
            (OE_LINES_ID,
             OE_HEADERS_ID,
             TRX_ID,
             OPERATION_CODE,
             ERROR_FLAG,
             STATUS,
             ORIG_SYS_DOCUMENT_REF,
             ORIG_SYS_LINE_REF,
             ORIG_SYS_SHIPMENT_REF,
             LINE_NUMBER,
             SHIPMENT_NUMBER,
             ORG_ID,
             ORDERED_ITEM,
             ORDER_QUANTITY_UOM,
             ORDERED_QUANTITY,
             UNIT_SELLING_PRICE,
             RETURN_REASON_CODE,
             RETURN_CONTEXT,
             RETURN_ATTRIBUTE1,
             RETURN_ATTRIBUTE2,
             ITEM_TYPE_CODE,
             OPTION_FLAG,
             TAX_CODE,
             ATTRIBUTE1,
             ATTRIBUTE3,
             ATTRIBUTE4,
             SUBINVENTORY,
             CONTEXT,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE)
          VALUES
            (S_OE_LINES_IFACE_ALL.NEXTVAL,
             R_OE_HEADERS.OE_HEADERS_ID,
             S_OE_HEADERS_IFACE_ALL.NEXTVAL, --WebService交易ID
             R_OE_HEADERS.OPERATION_CODE, --操作代码（新建：INSERT；修改：UPDATE）
             R_OE_HEADERS.ERROR_FLAG, --出错标记
             P_TRX_STATUS, --状态：新建：N；提交：P；返回成功标志：S
             R_OE_HEADERS.ORIG_SYS_DOCUMENT_REF, --销售单据头ID
             V_ORIG_SYS_LINE_REF,--R_SO_LINE_DETAIL.SO_LINE_ID, --销售单据行ID
             V_ORIG_SYS_SHIPMENT_REF,--R_SO_LINE_DETAIL.SO_LINE_DETAIL_ID, --销售单据行明细ID
             R_SO_LINE.SO_LINE_NUM, --行号
             V_ROW_NUM, --R_SO_LINE_DETAIL.SO_LINE_DETAIL_NUM, --行明细的行号
             R_OE_HEADERS.ORG_ID, --ERP的OU ID
             R_SO_LINE_DETAIL.COMPONENT_CODE, --物料编码，即产品/散件编码
             R_SO_LINE_DETAIL.COMPONENT_UOM, --物料编码单位，即产品/散件单位
             R_SO_LINE_DETAIL.COMPONENT_QTY * V_SIGN, --订单数据，即产品/散件的数量
             V_COMPONENT_PRICE, --价格，即结算价格
             V_RETURN_REASON_CODE, --退货原因：固定值-退货
             NULL, --RETURN_CONTEXT, --退货类型（退货要关联原订单时必填，固定值，ORDER)
             NULL, --RETURN_ATTRIBUTE1, --退货原订单头ID（退货要关联原订单时必填，退货原订单头ID）
             NULL, --RETURN_ATTRIBUTE2, --退货原订单行ID（退货要关联原订单时必填，退货原订单行ID）
             V_ITEM_TYPE_CODE, --物料类型（套机：MODEL、室内机：OPTION、室外机：OPTION）
             NULL, --OPTION_FLAG, --是否装置（为启用替代备用，暂填空）
             V_TAX_CODE, --TAX_CODE, --税码
             V_ORIG_SYS_SHIPMENT_REF,--R_SO_LINE_DETAIL.SO_LINE_DETAIL_ID, --ATTRIBUTE1 销售单据行明细ID
             V_ATTRIBUTE3, --行弹性域（退货原因）：RETURN-退货、PTO_RETURN-套件退货、PARTS_RETURN、散件退货、PTO_PARTS_RETURN、套件中的散件退货
             V_ATTRIBUTE4, --行弹性域（退货的时候从IMS传散件对应的套机码）
             V_SUBINVENTORY, --目标子库（销售单发货仓库对应的未结算仓库编码）
             V_CONTEXT, --行弹性域(上下文值)：（退货时必填，固定值:CIMS）
             R_OE_HEADERS.CREATED_BY,
             R_OE_HEADERS.CREATION_DATE,
             R_OE_HEADERS.LAST_UPDATED_BY,
             R_OE_HEADERS.LAST_UPDATE_DATE);
        END LOOP;
        CLOSE C_SO_LINE_DETAIL; --关闭游标
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_MSG := '把行明细插入ERP接口行表出错：' || SQLERRM;
          RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      END;
    END LOOP;
    CLOSE C_SO_LINE;
  EXCEPTION
    WHEN PKG_SO_PUB.V_BIZ_EXCEPTION THEN
      P_RESULT  := -28019;
      P_ERR_MSG := '销售单据[单据号：' || R_OE_HEADERS.ORDER_NUMBER ||
                   ']添加到与ERP系统对接的接口表发生异常。' || P_ERR_MSG;
    WHEN OTHERS THEN
      P_RESULT  := -28019;
      P_ERR_MSG := '销售单据[单据号：' || R_OE_HEADERS.ORDER_NUMBER ||
                   ']添加到与ERP系统对接的接口表发生异常：' || SQLERRM;
  END;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-07-25
  *   功能说明：根据账户ID获取客户、账户信息
  */
  -------------------------------------------------------------------------------
  FUNCTION F_GET_ACCOUNT_INFO(P_ACCOUNT_ID IN VARCHAR2, --业务单据类型编码
                              P_ENTITY_ID  IN NUMBER --主体ID
                              ) RETURN ACCOUNT_INFO IS
    --账户、客户、销售中心信息游标
    CURSOR C_CUST_ACCOUNT IS
      SELECT *
        FROM V_CUST_ACCOUNT
       WHERE ACCOUNT_ID = P_ACCOUNT_ID
         AND ENTITY_ID = P_ENTITY_ID
         AND ROWNUM = 1;
    /*
    SELECT CA.ACCOUNT_ID, CA.ACCOUNT_CODE, CA.ACCOUNT_NAME, CH.CUSTOMER_ID, CH.CUSTOMER_CODE, CH.CUSTOMER_NAME
    FROM T_CUSTOMER_ACCOUNT CA, T_CUSTOMER_HEADER CH
    WHERE CA.CUSTOMER_ID = CH.CUSTOMER_ID
      AND CA.ACCOUNT_ID = P_ACCOUNT_ID
      AND CA.ENTITY_ID = P_ENTITY_ID;
    */
    R_CUST_ACCOUNT C_CUST_ACCOUNT%ROWTYPE;

    --账户默认的地址
    CURSOR C_ADDR_DEFAULT IS
      SELECT CAD.PROVINCE, CAD.CITY, CAD.AREA, CAD.ADDRESS_ID, CAD.ADDRESS
        FROM T_CUSTOMER_ACCOUNT_ADDRESS CAA, T_CUSTOMER_ADDRESS CAD
       WHERE CAA.ADDRESS_ID = CAD.ADDRESS_ID
         AND CAA.ENTITY_ID = CAD.ENTITY_ID
         AND CAA.ACCOUNT_ID = P_ACCOUNT_ID
         AND CAA.ENTITY_ID = P_ENTITY_ID
            --AND CAA.IS_DEFAULT = '1' --默认的收货地址
         AND CAA.IS_DEFAULT = 'Y' --默认的收货地址  edit by chen.wj 20150301
         AND CAD.ADDRESS_TYPE = 'ShipTo' --收到地址
         AND ROWNUM = 1;
    R_ADDR_DEFAULT C_ADDR_DEFAULT%ROWTYPE;

    --账户的其他地址
    CURSOR C_ADDR_OTHER IS
      SELECT CAD.PROVINCE, CAD.CITY, CAD.AREA, CAD.ADDRESS_ID, CAD.ADDRESS
        FROM T_CUSTOMER_ACCOUNT_ADDRESS CAA, T_CUSTOMER_ADDRESS CAD
       WHERE CAA.ADDRESS_ID = CAD.ADDRESS_ID
         AND CAA.ENTITY_ID = CAD.ENTITY_ID
         AND CAA.ACCOUNT_ID = P_ACCOUNT_ID
         AND CAA.ENTITY_ID = P_ENTITY_ID
            --AND CAA.IS_DEFAULT = '0' --默认的收货地址
         AND CAA.IS_DEFAULT = 'N' --默认的收货地址 edit by chen.wj 20150301
         AND CAD.ADDRESS_TYPE = 'ShipTo' --收到地址
         AND ROWNUM = 1;
    R_ADDR_OTHER C_ADDR_OTHER%ROWTYPE;

    --账户、客户、销售中心信息
    V_ACCOUNT_INFO ACCOUNT_INFO;

  BEGIN
    OPEN C_CUST_ACCOUNT;
    FETCH C_CUST_ACCOUNT
      INTO R_CUST_ACCOUNT;
    CLOSE C_CUST_ACCOUNT;

    IF R_CUST_ACCOUNT.ACCOUNT_ID IS NULL THEN
      RETURN V_ACCOUNT_INFO;
    END IF;

    V_ACCOUNT_INFO.ACCOUNT_ID        := R_CUST_ACCOUNT.ACCOUNT_ID;
    V_ACCOUNT_INFO.ACCOUNT_CODE      := R_CUST_ACCOUNT.ACCOUNT_CODE;
    V_ACCOUNT_INFO.ACCOUNT_NAME      := R_CUST_ACCOUNT.ACCOUNT_NAME;
    V_ACCOUNT_INFO.CUSTOMER_ID       := R_CUST_ACCOUNT.CUSTOMER_ID;
    V_ACCOUNT_INFO.CUSTOMER_CODE     := R_CUST_ACCOUNT.CUSTOMER_CODE;
    V_ACCOUNT_INFO.CUSTOMER_NAME     := R_CUST_ACCOUNT.CUSTOMER_NAME;
    V_ACCOUNT_INFO.SALES_CENTER_ID   := R_CUST_ACCOUNT.SALES_CENTER_ID;
    V_ACCOUNT_INFO.SALES_CENTER_CODE := R_CUST_ACCOUNT.SALES_CENTER_CODE;
    V_ACCOUNT_INFO.SALES_CENTER_NAME := R_CUST_ACCOUNT.SALES_CENTER_NAME;

    OPEN C_ADDR_DEFAULT;
    FETCH C_ADDR_DEFAULT
      INTO R_ADDR_DEFAULT;
    CLOSE C_ADDR_DEFAULT;

    IF R_ADDR_DEFAULT.ADDRESS_ID IS NOT NULL THEN
      V_ACCOUNT_INFO.ADDRESS_ID := R_ADDR_DEFAULT.ADDRESS_ID;
      V_ACCOUNT_INFO.ADDRESS    := R_ADDR_DEFAULT.ADDRESS;
      V_ACCOUNT_INFO.PROVINCE   := R_ADDR_DEFAULT.PROVINCE;
      V_ACCOUNT_INFO.CITY       := R_ADDR_DEFAULT.CITY;
      V_ACCOUNT_INFO.AREA       := R_ADDR_DEFAULT.AREA;
    ELSE
      OPEN C_ADDR_OTHER;
      FETCH C_ADDR_OTHER
        INTO R_ADDR_OTHER;
      CLOSE C_ADDR_OTHER;

      IF R_ADDR_OTHER.ADDRESS_ID IS NOT NULL THEN
        V_ACCOUNT_INFO.ADDRESS_ID := R_ADDR_OTHER.ADDRESS_ID;
        V_ACCOUNT_INFO.ADDRESS    := R_ADDR_OTHER.ADDRESS;
        V_ACCOUNT_INFO.PROVINCE   := R_ADDR_OTHER.PROVINCE;
        V_ACCOUNT_INFO.CITY       := R_ADDR_OTHER.CITY;
        V_ACCOUNT_INFO.AREA       := R_ADDR_OTHER.AREA;
      END IF;
    END IF;

    RETURN V_ACCOUNT_INFO;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
  END;


END PKG_BUG;
/

