create package      PKG_PUB is

  -- Author  : HUTAO
  -- Created : 2014/8/27 10:09:16

  -------------------------------------------------------------------------------
  --锁定数据（动态）
  --返回：锁定成功1，失败0
  -------------------------------------------------------------------------------
  FUNCTION F_PUB_LOCK_RECORD
  (
     P_TABLE_NAME VARCHAR2                       --表名
     ,P_SQL_WHERE VARCHAR2 DEFAULT NULL          --条件
     ,P_FIELDS VARCHAR2 DEFAULT NULL             --列名
   )
   RETURN NUMBER;                                --锁定成功1，失败0
  --------------------------------------------------------------------------------------------
  -- Author  : huanghb12
  -- Created : 2019-03-14
  -- Purpose : 写入平台统一下载的附件表，job会每隔几分钟下载一次
  --------------------------------------------------------------------------------------------
  PROCEDURE P_DOWNLOAD_FILE(P_BUSINESS_ID   IN VARCHAR2, --附件ID
                            P_BUSINESS_TYPE IN VARCHAR2, --附件业务类型
                            P_FILE_PATH     IN VARCHAR2, --文件路径
                            P_FILE_NAME     IN VARCHAR2, --文件名称
                            P_RESULT        OUT VARCHAR2 --返回信息
                            );

end PKG_PUB;
/

