create package body PKG_CROSSOUTURNFEE_BASE is--包体声明

 FUNCTION F_T_AR_CONF_INITIAL
  --------------------   根据主体ID、营销中心ID、客户ID查询应收配置  -----------------
  --------------------   SHIP_FLAG：发货确认；RECEIVE_FLAG：收货确认；CHECKED_ACCOUNT_FLAG：客户对账   -----------------------
 (
    P_ENTITY_ID                                      IN T_AR_CONF.ENTITY_ID%TYPE, --主体ID
    P_SALES_CENTER_ID                           IN T_AR_CONF.SALES_CENTER_ID%TYPE, --营销中心ID
    P_CUSTOMER_ID                                IN T_AR_CONF.CUSTOMER_ID%TYPE, --客户ID
    P_ERP_OU_ID                                     IN T_AR_CONF.ERP_OU%TYPE --ERP_OU_ID
 ) RETURN T_AR_CONF.AR_CONF_INITIAL%TYPE AS

 P_AR_CONF_INITIAL                              T_AR_CONF.AR_CONF_INITIAL%TYPE;
 P_COUNT1                                           INT;                                   --判断应收配置表是否有数据(按客户)
 P_COUNT2                                           INT;                                   --判断应收配置表是否有数据(按营销中心)
 P_COUNT3                                           INT;                                   --判断应收配置表是否有数据(按主体)
 P_RESULT                                             varchar2(2000);
 P_MESSAGE                                          varchar2(2000);
 BEGIN
   --应收配置优先级 客户->中心->主体
    SELECT COUNT(*) INTO P_COUNT1 FROM T_AR_CONF TC1 WHERE TC1.CUSTOMER_ID = P_CUSTOMER_ID AND TC1.ENTITY_ID = P_ENTITY_ID;
    --按客户
    IF P_COUNT1>0 THEN
      SELECT TC2.AR_CONF_INITIAL INTO P_AR_CONF_INITIAL FROM T_AR_CONF TC2  WHERE TC2.CUSTOMER_ID = P_CUSTOMER_ID AND TC2.ENTITY_ID = P_ENTITY_ID AND rownum=1;
    ELSE
      --按中心
      SELECT COUNT(*) INTO P_COUNT2 FROM T_AR_CONF TC3 WHERE TC3.SALES_CENTER_ID = P_SALES_CENTER_ID AND TC3.ENTITY_ID = P_ENTITY_ID AND TC3.CUSTOMER_ID IS NULL;
      IF P_COUNT2>0 THEN
        SELECT TC4.AR_CONF_INITIAL INTO P_AR_CONF_INITIAL FROM T_AR_CONF TC4 WHERE TC4.SALES_CENTER_ID = P_SALES_CENTER_ID AND TC4.ENTITY_ID = P_ENTITY_ID AND TC4.CUSTOMER_ID IS NULL AND rownum=1;
      ELSE
        --按主体
        SELECT COUNT(*) INTO P_COUNT3 FROM T_AR_CONF TC5 WHERE TC5.ENTITY_ID=P_ENTITY_ID AND TC5.ERP_OU = P_ERP_OU_ID AND TC5.SALES_CENTER_ID IS NULL AND TC5.CUSTOMER_ID IS NULL;
        IF P_COUNT3>0 THEN
          SELECT TC6.AR_CONF_INITIAL INTO P_AR_CONF_INITIAL FROM T_AR_CONF TC6 WHERE TC6.ENTITY_ID=P_ENTITY_ID AND TC6.ERP_OU = P_ERP_OU_ID AND TC6.SALES_CENTER_ID IS NULL AND TC6.CUSTOMER_ID IS NULL AND rownum=1;
        END IF;
      END IF;
    END IF;
    RETURN P_AR_CONF_INITIAL;
EXCEPTION
    WHEN OTHERS THEN
        --记录出错信息
        P_MESSAGE := PKG_CROSSOUTURNFEE.V_ERROR;
        P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_CROSSOUTURNFEE_BASE.F_T_AR_CONF_INITIAL',
                  SQLCODE,
                  '查询应收配置失败！主体ID：'||P_ENTITY_ID||'。营销中心ID：'||P_SALES_CENTER_ID||'。客户ID：'||P_CUSTOMER_ID||'。ERP_OU_ID：'||P_ERP_OU_ID||'。错误消息：' || SQLERRM);
    RETURN P_AR_CONF_INITIAL;
 END;
end PKG_CROSSOUTURNFEE_BASE;
/

