create view V_BD_ITEM_A3 as
select bi.ITEM_CODE,
       bi.ITEM_NAME,
       bi.PRODUCTMODEL,
       bi.marketModel,
       bi.productDesc,
       (select aa.CODE_NAME from cims.v_up_codelist aa where aa.CODETYPE ='BD_UOM' and aa.CODE_VALUE=bi.defaultunit and rownum = 1) defaultunit ,
       bi.productForm,
       decode(bi.productForm,'SET_PRODUCT','Y','N') is_assembled,
       bi.sales_main_type,
       msc.sales_main_type_name,
       bi.sales_sub_type,
       msc.sales_sub_type_name,
       bi.grossWeight,
       bi.netWeight,
       bi.packingLength,
       bi.packingWidth,
       bi.packingHeight,
       bi.packingSize,
       bi.commodityBarCode,
       bi.barcode,
       bi.stackLayers,
       bi.loadingCapacity,
       bi.old_item_code,
       bi.entity_id,
       bi.is_rounding，--2015-3-30 增加是否凑整
       bi.rounding_cnt,  --2015-3-30 增加凑整数
       bi.brand,--2015-7-10 增加凑整数
       bi.PRODUCT_CLASS_CODE,
       bi.last_update_date
  from T_BD_ITEM bi,
       (select mc.entity_id, mc.class_code sales_main_type, mc.class_name sales_main_type_name,
               sc.class_code sales_sub_type, sc.class_name sales_sub_type_name
          from t_bd_item_class mc, t_bd_item_class sc
         where mc.class_type = 'M'
           and sc.class_type = 'S'
           and mc.item_class_id = sc.parentc_lass_id) msc
 where bi.entity_id = msc.entity_id(+)
   and bi.sales_main_type = msc.sales_main_type(+)
   and bi.sales_sub_type = msc.sales_sub_type(+)
/

