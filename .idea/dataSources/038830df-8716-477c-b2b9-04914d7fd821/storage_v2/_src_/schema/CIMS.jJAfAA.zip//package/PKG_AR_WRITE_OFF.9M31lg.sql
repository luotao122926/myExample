create package      PKG_AR_WRITE_OFF AS
  --包头声明

  V_SUCCESS       CONSTANT VARCHAR2(10) := 'SUCCESS';
  V_ERROR         CONSTANT VARCHAR2(10) := 'ERROR';
  V_YES           CONSTANT CHAR(1) := 'Y';
  V_NO            CONSTANT CHAR(1) := 'N';
  V_OK            CONSTANT CHAR(2) := 'OK';
  V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常

  -- 核销关系引ERP状态
  V_WRITE_OFF_ERP_FLAG_Y         CONSTANT CHAR(1) := 'Y'; -- 已引ERP
  V_WRITE_OFF_ERP_FLAG_N         CONSTANT CHAR(1) := 'N'; -- 未引ERP
  V_WRITE_OFF_ERP_FLAG_C         CONSTANT CHAR(1) := 'C'; -- 不引ERP
  V_WRITE_OFF_ERP_FLAG_D         CONSTANT CHAR(1) := 'D'; -- 取消ERP
  
  --销售单状态
  V_SO_STATUS_11         CONSTANT CHAR(2) := '11'; -- 已审核
  V_SO_STATUS_12         CONSTANT CHAR(2) := '12'; -- 已结算

  -- 核销状态
  V_WRITE_OFF_STATUS_ALL         CONSTANT CHAR(1) := '0'; -- 全部核销
  V_WRITE_OFF_STATUS_PART        CONSTANT CHAR(1) := '1'; -- 部分核销
  V_WRITE_OFF_STATUS_NONE        CONSTANT CHAR(1) := '2'; -- 未核销

  -- 红冲标记
  V_REVERSAL_FLAG_ALL            CONSTANT CHAR(2) := '11'; -- 11-全部红冲
  V_REVERSAL_FLAG_PART           CONSTANT CHAR(2) := '12'; -- 12-部分红冲
  V_REVERSAL_FLAG_NONE           CONSTANT CHAR(2) := '10'; -- 10-未红冲

  -- 应收配置时点
  V_AR_CONF_INITIAL_SHIP         CONSTANT VARCHAR2(20) := 'SHIP_FLAG'; -- SHIP_FLAG 发货确认
  V_AR_CONF_INITIAL_RECEIVE      CONSTANT VARCHAR2(20) := 'RECEIVE_FLAG'; -- RECEIVE_FLAG 收货确认
  V_AR_CONF_INITIAL_CHECKED      CONSTANT VARCHAR2(20) := 'CHECKED_ACCOUNT_FLAG'; -- CHECKED_ACCOUNT_FLAG 客户对账

  --销售单据源类型编码
  V_BIZ_SRC_BILL_SO              CONSTANT CHAR(4) := '1001'; --销售单
  V_BIZ_SRC_BILL_SO_RED          CONSTANT CHAR(4) := '1002'; --销售红冲单
  V_BIZ_SRC_BILL_RETURN          CONSTANT CHAR(4) := '1003'; --退货单
  V_BIZ_SRC_BILL_RETURN_RED      CONSTANT CHAR(4) := '1004'; --退货红冲单
  V_BIZ_SRC_BILL_SO_DISCOUNT     CONSTANT CHAR(4) := '1005'; --销售折让单
  V_BIZ_SRC_BILL_SO_DISCOUNT_RED CONSTANT CHAR(4) := '1006'; --销售折让红冲单
  V_BIZ_SRC_BILL_DISCOUNT        CONSTANT CHAR(4) := '1007'; --折让证明单
  V_BIZ_SRC_BILL_DISCOUNT_RED    CONSTANT CHAR(4) := '1008'; --折让证明红冲单
  V_BIZ_SRC_BILL_RATE            CONSTANT CHAR(4) := '1009'; --扣率折让单
  V_BIZ_SRC_BILL_RATE_RED        CONSTANT CHAR(4) := '1010'; --扣率折让红冲单


  V_AR_SALE_MAIN_TYPE_WRITE_OFF     CONSTANT VARCHAR2(30) := 'ar_sale_main_type_write_off'; --系统参数中定义是否区分营销大类
  V_AR_SALE_MAIN_DEF_WRITE_OFF      CONSTANT VARCHAR2(30) := 'ar_default_sale_main_write_off';-- 系统参数中定义主体的默认营销大类

  V_CROSS_OU_METHOD_NAME            CONSTANT VARCHAR2(30) := '跨主体转款';

  MV_AR_WRITE_OFF_CHECK_REP_NEW     CONSTANT VARCHAR2(50) := 'MV_AR_WRITE_OFF_CHECK_REP_NEW';

  TYPE AR_SALE_MAIN_TYPE IS RECORD(
  --默认营销大类配置
    IS_SALE_MAIN_WRITEOFF      T_BD_PARAM_ENTITY.ENTITY_VALUE%TYPE, --是否区分营销大类。Y：区分；N：不区分
    SALE_MAIN_TYPE_ID          T_BD_ITEM_CLASS.ITEM_CLASS_ID%TYPE, --营销大类ID
    DEFAULT_SALE_MAIN_TYPE_ID  T_BD_ITEM_CLASS.ITEM_CLASS_ID%TYPE, --默认营销大类ID
    SALE_MAIN_TYPE_CODE        T_BD_ITEM_CLASS.CLASS_CODE%TYPE, --默认营销大类编码
    SALE_MAIN_TYPE_NAME        T_BD_ITEM_CLASS.CLASS_NAME%TYPE, --默认营销大类名称
    P_RESULT                   VARCHAR2(400),--执行消息
    P_MESSAGE                  VARCHAR2(10) --成功则返回“OK”，否则返回出错信息
  );

  -- 核销(按照流程执行核销)
  PROCEDURE P_AR_WRITE_OFFS
  (
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  );

  --客户自动核销处理
  PROCEDURE P_AR_WRITE_OFFS_TRAN
  ( IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  );

  --T_SO_HEADER 优先核销
  PROCEDURE P_AR_PRIOR_WRITE_OFFS
  (
   IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  );
  
        -- 大额到款单提前核销
  PROCEDURE P_AR_AMOUNT_WRITE_OFFS
  (
    IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  );
  
      -- 网批按单据对照关系 单单核销
  PROCEDURE P_AR_NET_WRITE_OFFS
  (
    IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  );

  -- 核销主过程
  PROCEDURE P_AR_WRITE_OFFS_MAIN
  ( IN_ENTITY_ID IN  NUMBER,  --主体 
      IN_MOD      IN  NUMBER,  --mod参数
      IN_MOD_REN  IN  NUMBER,  --mod余数
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  );

  -- 收款冲销后，收款冲销单跟原收款单进行核销
  PROCEDURE P_AR_RECEIPT_INVOICE_WRITE_OFF
  (
     IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  );

  -- 退款申请进行撤回修改、撤回作废、GTMS已驳回
  PROCEDURE P_AR_CASH_STATUS
  (
       IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT      OUT VARCHAR2,
      P_MESSAGE     OUT VARCHAR2
  );

  -- 结算更改（修改折扣率）过程
  PROCEDURE P_AR_SETTLED_WRITE_OFF
  (
       IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT      OUT VARCHAR2,
      P_MESSAGE     OUT VARCHAR2
  );
  
  --解除未结算销售单 同账户存在已结算未核销的销售单 的核销关系   未发送ERP
  PROCEDURE P_CANCEL_NO_SETTLE_SO
  (
      IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  );

  -- 解除核销关系
  PROCEDURE P_CANCEL_ORDER_RECEIPT
  (
      P_ORDER_NUMBER IN VARCHAR2,--单据号
      P_ORDER_TYPE IN VARCHAR2,-- 单据类型。ORDER_TYPE = 1，收款单；ORDER_TYPE in (1001,1002,1003,1004,1005,1006,1007,1008)销售单
      P_WRITE_FLAG IN VARCHAR2,  --部分冲销  根据标志 冲销指定类型数据  ALL 全部 | ORDER 单单核销
      P_REMARK     IN VARCHAR2, -- 备注
      P_CANCEL_ERP_YES_OR_NO IN VARCHAR2, --是否取消ERP核销关系
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  );

  -- 生成原单和冲销单的核销关系
  PROCEDURE P_CREATE_ORDER_RECEIPT
  (
      P_ORDER_NUMBER IN VARCHAR2,--单据号
      P_ORDER_TYPE IN VARCHAR2,-- 单据类型。ORDER_TYPE = 1，收款单；ORDER_TYPE in (1001,1002,1003,1004,1005,1006,1007,1008)销售单
      P_ORDER_NUMBER_RED IN VARCHAR2, --冲销单单据号
      P_MATCH_DATE       IN DATE, -- 核销日期。为空默认为sysdate-1
      P_TO_ERP_FLAG      IN VARCHAR2, --新生成核销关系引ERP方式。Y已引入，N未引入，C不引入。为空默认为N未引入
      P_REMARK     IN VARCHAR2, -- 备注
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  );

  -- 生成跨主体单据（制单状态）
  PROCEDURE P_AR_CASH_TURNFEE_NEW(
     IN_ENTITY_ID IN  NUMBER,  --主体 
       P_RESULT OUT VARCHAR2,
       P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  /**
  ** 1、确认跨主体单据，
  ** 2、引关联交易
  ** 3、生成正负数收款
  ** 4、正数收款引ERP收款、负数收款引ERP发票
  ** 5、正负数收款分别参与同OU核销
  **/
  PROCEDURE P_AR_CASH_TURNFEE_COMMIT(
    IN_ENTITY_ID IN  NUMBER,  --主体 
       P_RESULT OUT VARCHAR2,
       P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息息
  );

  --核销接口表插入【erp】
  PROCEDURE P_SO_ORDER_RECEIPT_TO_ERP
  (
   IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -- 核销关系推送ERP校验。一张收款单和一张财务单只能核销一次
  PROCEDURE P_SO_ORDER_RECEIPT_ERP_CHECK
  (
     IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -- 取消核销关系推送ER
  PROCEDURE P_SO_ORDER_RECEIPT_ERP_CANCEL
  (
   IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  --核销对账检查
  PROCEDURE P_AR_WRITE_OFF_CHECK
  (
      P_CHECK_YES_OR_NO                    IN VARCHAR2,
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2
  );

  --自动坏账准备计提
  PROCEDURE P_SO_BAD_BILL_PROVISION_REPROT
  (
   IN_ENTITY_ID IN  NUMBER,  --主体 
      P_DATE    IN  DATE,
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  --坏账准备计提沉淀报表
  PROCEDURE P_SO_BAD_BILL_PROVISION_PREC_R
    (
    IN_ENTITY_ID IN  NUMBER,  --主体 
       P_DATE    IN DATE,
       P_RESULT  OUT VARCHAR2,
       P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
   );

  -- 重置核销状态
  PROCEDURE P_RESET_WRITE_OFF_STATUS
  (
   IN_ENTITY_ID IN NUMBER,  --主体
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -- 刷新物化视图
  PROCEDURE P_REFRESH_MATERIALIZED_VIEW
  (
      P_MATERIALIZED_VIEW_NAME IN VARCHAR2, -- 物化视图名称
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );
  
    -- 比较更新核销校正表
  PROCEDURE P_ALL_FREEZE_WRITE_OFF(
        P_RESULT  OUT VARCHAR2,
        P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );
    
  -- 增量更新核销校正表
  PROCEDURE P_INCREMENTAL_FREEZE_WRITE_OFF
  (
      ID_CURRENT_DATE   IN   DATE,      --当前日期
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -- 核销金额>单据金额数据自动修复
  PROCEDURE P_AUTO_REPAIR_ORDER_RECEIPT
  (    IN_ENTITY_ID IN NUMBER,  --主体
      P_AUTO_REPAIR_YES_OR_NO                    IN VARCHAR2,
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -- 修复为空的核销状态
  PROCEDURE P_AUTO_REPAIR_MATCH_STATUS
  (IN_ENTITY_ID IN NUMBER,  --主体
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );
  
    --冻结账龄日报表
  PROCEDURE P_AR_AGE_FREEZE
  (
      P_MATCH_DATE IN VARCHAR2, --核销日期。默认取TRUNC(SYSDATE - 1,'DD')
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );
  
      --处理核销接口数据
  PROCEDURE P_AR_WRITEOFF_RESET
  (
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  FUNCTION F_AR_DEFAULT_SALE_MAIN_TYPE
  --------------------   根据主体判断是否区分营销大类核销  -----------------
  ---------------------------   获取默认的营销大类  -----------------------
  (
    ENTITY_ID                        IN NUMBER --主体ID
  ) RETURN PKG_AR_WRITE_OFF.AR_SALE_MAIN_TYPE;

  FUNCTION F_AR_IS_CROSS_OU_BILL
  --------------------   根据单据号判断是否为跨主体单据  -----------------
  (
    P_ORDER_NUMBER                        IN VARCHAR2 --单据号
  ) RETURN VARCHAR2;

  FUNCTION F_AR_HAS_ORDER_RECIPET
  --------------------   根据单据ID判断核销关系状态  -----------------
  (
    P_ORDER_ID                        IN NUMBER, --单据ID
    P_ORDER_TYPE                      IN VARCHAR2 --单据类型。P_ORDER_TYPE IN (1, -1)收款单；P_ORDER_TYPE IN (1001,1002,1003,1004,1005,1006,1007,1008)销售单
  ) RETURN VARCHAR2;

  FUNCTION F_GET_MATCH_AMOUNT
  --------------------   查询核销金额  -----------------
  (
    P_ORDER_ID                        IN NUMBER, --单据ID
    P_SO_OR_RECEIPT                   IN NUMBER, -- 应收或回款。1：应收；-1：回款
    P_ORDER_TYPE                      IN VARCHAR2 --单据类型。P_ORDER_TYPE IN (1, -1)收款单；P_ORDER_TYPE IN (1001,1002,1003,1004,1005,1006,1007,1008)销售单
  ) RETURN NUMBER;
  
            --清空核销应收、回款临时表
  PROCEDURE P_AR_WRITEOFF_DELETE
  (
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  FUNCTION F_GET_AGE_AMOUNT
  --------------------   查询账龄金额  -----------------
  (
    P_ORDER_ID                        IN NUMBER, --单据ID
    P_ORDER_MAIN_TYPE                 IN VARCHAR2, --单据主类型（收款单/财务单）1代表收款单、2代表财务单
    P_AR_TYPE                         IN VARCHAR2, --应收类型（应收款/回款）1代表应收款，2代表回款
    P_MATCH_DATE                      IN DATE --核销日期。默认取TRUNC(SYSDATE - 1,'DD')
  ) RETURN NUMBER;
  
  
    --处理核销对账接口
  PROCEDURE P_AR_WRITEOFF_ACCOUNT
  (
      P_ENTITY_ID IN NUMBER, --主体
      P_MAX_NUM IN NUMBER, --主体
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );
  
    --处理ERP发票金额核对
  PROCEDURE P_AR_SO_HEADER_ACCOUNT
  (
      P_ENTITY_ID IN NUMBER, --主体
      P_MAX_NUM IN NUMBER, --主体
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );
  
  
      --核销对账冻结
  PROCEDURE P_AR_ACCOUNT_FREEZE
  (
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );
  --解冻逾期的账户
  PROCEDURE P_AR_UNLOCK_OVERDUE_ACCOUNT
  (
      P_MATCH_DATE IN VARCHAR2, --核销日期。默认取TRUNC(SYSDATE - 1,'DD')
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );
 --冻结逾期的账户
  PROCEDURE P_AR_LOCK_OVERDUE_ACCOUNT
  (
      P_MATCH_DATE IN VARCHAR2, --核销日期。默认取TRUNC(SYSDATE - 1,'DD')
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );
end PKG_AR_WRITE_OFF;
/

