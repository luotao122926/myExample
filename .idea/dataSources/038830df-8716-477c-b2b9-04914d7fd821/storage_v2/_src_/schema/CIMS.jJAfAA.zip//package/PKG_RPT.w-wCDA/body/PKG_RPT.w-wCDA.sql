create PACKAGE BODY      PKG_RPT AS

  -----------------------------------------------------------------------------
  --      初始报表周期(年)                                            --
  --处理逻辑：按指定日期范围，循环生成对应的年度周期数据
  -----------------------------------------------------------------------------
  PROCEDURE P_INIT_PERIOD_YEAR(
    IN_ENTITY_ID              IN  NUMBER   --主体ID
    ,ID_BEGIN_DATE            IN  DATE     --起始日期
    ,ID_END_DATE              IN  DATE     --终止日期
    ,IN_PARENT_PERIOD_ID      IN  NUMBER   --上级周期ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --操作用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    D_PERIOD_BEGIN_DATE DATE;  --周期开始日期
    D_PERIOD_END_DATE DATE;  --周期结束日期
    S_PARENT_PEROD_NAME VARCHAR2(240);
  BEGIN
    OS_MESSAGE := 'OK';
    
    --取起始日期
    D_PERIOD_BEGIN_DATE := TRUNC(ID_BEGIN_DATE,'YYYY');
    IF D_PERIOD_BEGIN_DATE <> ID_BEGIN_DATE THEN
      --对于起始日期不是年度第一天，则取下一年度
      D_PERIOD_BEGIN_DATE := ADD_MONTHS(D_PERIOD_BEGIN_DATE,12);
    END IF;
    --取终止日期
    D_PERIOD_END_DATE := ADD_MONTHS(D_PERIOD_BEGIN_DATE,12)-1;
    IF D_PERIOD_END_DATE > ID_END_DATE THEN
      OS_MESSAGE := '该日期范围内没有可生成的周期，请重新选择日期范围！';
    ELSE
      --存在上级周期ID则取出对应的名称
      IF IN_PARENT_PERIOD_ID <> -1 THEN
        SELECT
          PERIOD_NAME
        INTO
          S_PARENT_PEROD_NAME
        FROM
          T_BD_RPT_PERIOD
        WHERE
          RPT_PERIOD_ID = IN_PARENT_PERIOD_ID;
      END IF;
      WHILE D_PERIOD_END_DATE <= ID_END_DATE
      LOOP
        --写周期表
        INSERT INTO T_BD_RPT_PERIOD
        (
          RPT_PERIOD_ID
          ,PERIOD_TYPE
          ,PERIOD_NAME
          ,BEGIN_DATE
          ,END_DATE
          ,ENTITY_ID
          ,PARENT_PERIOD_ID
          ,PARENT_PERIOD_NAME
          ,CREATED_BY
          ,CREATION_DATE
          ,LAST_UPDATED_BY
          ,LAST_UPDATE_DATE
          ,VERSION
        )
        VALUES
        (
          S_BD_RPT_PERIOD.NEXTVAL --RPT_PERIOD_ID
          ,'YEAR' --PERIOD_TYPE
          ,TO_CHAR(D_PERIOD_BEGIN_DATE,'YYYY') || '年' --PERIOD_NAME
          ,D_PERIOD_BEGIN_DATE --BEGIN_DATE
          ,D_PERIOD_END_DATE --END_DATE
          ,IN_ENTITY_ID --ENTITY_ID
          ,IN_PARENT_PERIOD_ID --PARENT_PERIOD_ID
          ,S_PARENT_PEROD_NAME --PARENT_PERIOD_NAME
          ,IS_USER_ACCOUNT --CREATED_BY
          ,SYSDATE --CREATION_DATE
          ,IS_USER_ACCOUNT --LAST_UPDATED_BY
          ,SYSDATE --LAST_UPDATE_DATE
          ,0 --VERSION
        );
          
        --取下一个周期对应日期范围
        D_PERIOD_BEGIN_DATE := D_PERIOD_END_DATE+1;
        D_PERIOD_END_DATE := ADD_MONTHS(D_PERIOD_BEGIN_DATE,12)-1;
      END LOOP;
    END IF;
  END P_INIT_PERIOD_YEAR;

  -----------------------------------------------------------------------------
  --      初始报表周期(月)                                            --
  --处理逻辑：按指定日期范围，循环生成对应的月度周期数据
  --注意：系统按指定的上级周期ID记录到月度周期中，不判断是否在同一自然年份
  -----------------------------------------------------------------------------
  PROCEDURE P_INIT_PERIOD_MONTH(
    IN_ENTITY_ID              IN  NUMBER   --主体ID
    ,ID_BEGIN_DATE            IN  DATE     --起始日期
    ,ID_END_DATE              IN  DATE     --终止日期
    ,IN_PARENT_PERIOD_ID      IN  NUMBER   --上级周期ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --操作用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    D_PERIOD_BEGIN_DATE DATE;  --周期开始日期
    D_PERIOD_END_DATE DATE;  --周期结束日期
    S_PARENT_PEROD_NAME VARCHAR2(240);
  BEGIN
    OS_MESSAGE := 'OK';
    
    --取起始日期
    D_PERIOD_BEGIN_DATE := TRUNC(ID_BEGIN_DATE,'MM');
    IF D_PERIOD_BEGIN_DATE <> ID_BEGIN_DATE THEN
      --对于起始日期不是月度第一天，则取下一月
      D_PERIOD_BEGIN_DATE := ADD_MONTHS(D_PERIOD_BEGIN_DATE,1);
    END IF;
    --取终止日期
    D_PERIOD_END_DATE := ADD_MONTHS(D_PERIOD_BEGIN_DATE,1)-1;
    IF D_PERIOD_END_DATE > ID_END_DATE THEN
      OS_MESSAGE := '该日期范围内没有可生成的周期，请重新选择日期范围！';
    ELSE
      --存在上级周期ID则取出对应的名称，冗余到月份周期信息中
      IF IN_PARENT_PERIOD_ID <> -1 THEN
        SELECT
          PERIOD_NAME
        INTO
          S_PARENT_PEROD_NAME
        FROM
          T_BD_RPT_PERIOD
        WHERE
          RPT_PERIOD_ID = IN_PARENT_PERIOD_ID;
      END IF;

      WHILE D_PERIOD_END_DATE <= ID_END_DATE
      LOOP
        --写周期表
        INSERT INTO T_BD_RPT_PERIOD
        (
          RPT_PERIOD_ID
          ,PERIOD_TYPE
          ,PERIOD_NAME
          ,BEGIN_DATE
          ,END_DATE
          ,ENTITY_ID
          ,PARENT_PERIOD_ID
          ,PARENT_PERIOD_NAME
          ,CREATED_BY
          ,CREATION_DATE
          ,LAST_UPDATED_BY
          ,LAST_UPDATE_DATE
          ,VERSION
        )
        VALUES
        (
          S_BD_RPT_PERIOD.NEXTVAL --RPT_PERIOD_ID
          ,'MONTH' --PERIOD_TYPE
          ,TO_CHAR(D_PERIOD_BEGIN_DATE,'YYYY') || '年' || TO_CHAR(D_PERIOD_BEGIN_DATE,'MM') || '月' --PERIOD_NAME
          ,D_PERIOD_BEGIN_DATE --BEGIN_DATE
          ,D_PERIOD_END_DATE --END_DATE
          ,IN_ENTITY_ID --ENTITY_ID
          ,IN_PARENT_PERIOD_ID --PARENT_PERIOD_ID
          ,S_PARENT_PEROD_NAME --PARENT_PERIOD_NAME
          ,IS_USER_ACCOUNT --CREATED_BY
          ,SYSDATE --CREATION_DATE
          ,IS_USER_ACCOUNT --LAST_UPDATED_BY
          ,SYSDATE --LAST_UPDATE_DATE
          ,0 --VERSION
        );
          
        --取下一个周期对应日期范围
        D_PERIOD_BEGIN_DATE := D_PERIOD_END_DATE+1;
        D_PERIOD_END_DATE := ADD_MONTHS(D_PERIOD_BEGIN_DATE,1)-1;
      END LOOP;
    END IF;
  END P_INIT_PERIOD_MONTH;

  -----------------------------------------------------------------------------
  --      初始报表周期(日)                                            --
  --注意：系统按指定的上级周期ID记录到日周期中，不判断是否在同一自然月份
  -----------------------------------------------------------------------------
  PROCEDURE P_INIT_PERIOD_DAY(
    IN_ENTITY_ID              IN  NUMBER   --主体ID
    ,ID_BEGIN_DATE            IN  DATE     --起始日期
    ,ID_END_DATE              IN  DATE     --终止日期
    ,IN_PARENT_PERIOD_ID      IN  NUMBER   --上级周期ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --操作用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    D_PERIOD_BEGIN_DATE DATE;  --周期开始日期
    D_PERIOD_END_DATE DATE;  --周期结束日期
    S_PARENT_PEROD_NAME VARCHAR2(240);
  BEGIN
    OS_MESSAGE := 'OK';
    
    --取起始日期
    D_PERIOD_BEGIN_DATE := ID_BEGIN_DATE;
    --取终止日期
    D_PERIOD_END_DATE := D_PERIOD_BEGIN_DATE;
    IF D_PERIOD_END_DATE > ID_END_DATE THEN
      OS_MESSAGE := '该日期范围内没有可生成的周期，请重新选择日期范围！';
    ELSE
      --存在上级周期ID则取出对应的名称
      IF IN_PARENT_PERIOD_ID <> -1 THEN
        SELECT
          PERIOD_NAME
        INTO
          S_PARENT_PEROD_NAME
        FROM
          T_BD_RPT_PERIOD
        WHERE
          RPT_PERIOD_ID = IN_PARENT_PERIOD_ID;
      END IF;

      WHILE D_PERIOD_END_DATE <= ID_END_DATE
      LOOP
        --写周期表
        INSERT INTO T_BD_RPT_PERIOD
        (
          RPT_PERIOD_ID
          ,PERIOD_TYPE
          ,PERIOD_NAME
          ,BEGIN_DATE
          ,END_DATE
          ,ENTITY_ID
          ,PARENT_PERIOD_ID
          ,PARENT_PERIOD_NAME
          ,CREATED_BY
          ,CREATION_DATE
          ,LAST_UPDATED_BY
          ,LAST_UPDATE_DATE
          ,VERSION
        )
        VALUES
        (
          S_BD_RPT_PERIOD.NEXTVAL --RPT_PERIOD_ID
          ,'DAY' --PERIOD_TYPE
          ,TO_CHAR(D_PERIOD_BEGIN_DATE,'YYYY') || '年' || TO_CHAR(D_PERIOD_BEGIN_DATE,'MM') || '月' || TO_CHAR(D_PERIOD_BEGIN_DATE,'DD') || '日' --PERIOD_NAME
          ,D_PERIOD_BEGIN_DATE --BEGIN_DATE
          ,D_PERIOD_END_DATE --END_DATE
          ,IN_ENTITY_ID --ENTITY_ID
          ,IN_PARENT_PERIOD_ID --PARENT_PERIOD_ID
          ,S_PARENT_PEROD_NAME --PARENT_PERIOD_NAME
          ,IS_USER_ACCOUNT --CREATED_BY
          ,SYSDATE --CREATION_DATE
          ,IS_USER_ACCOUNT --LAST_UPDATED_BY
          ,SYSDATE --LAST_UPDATE_DATE
          ,0 --VERSION
        );
          
        --取下一个周期对应日期范围
        D_PERIOD_BEGIN_DATE := D_PERIOD_END_DATE+1;
        D_PERIOD_END_DATE := D_PERIOD_BEGIN_DATE;
      END LOOP;
    END IF;
  END P_INIT_PERIOD_DAY;

  -----------------------------------------------------------------------------
  --      初始报表周期                                             --
  --处理逻辑：根据周期类型分别处理年、月、日的周期初始
  -----------------------------------------------------------------------------
  PROCEDURE P_INIT_PERIOD(
    IS_PERIOD_TYPE            IN  VARCHAR2 --周期类型
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,ID_BEGIN_DATE            IN  DATE     --起始日期
    ,ID_END_DATE              IN  DATE     --终止日期
    ,IN_PARENT_PERIOD_ID      IN  NUMBER   --上级周期ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --操作用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    S_STEP VARCHAR2(40);
    N_CNT NUMBER;
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP_INIT_PERIOD;
    
    --检查是否已存在日期范围内的周期信息
    S_STEP := '检查周期';
    SELECT
      COUNT(*)
    INTO
      N_CNT
    FROM
      T_BD_RPT_PERIOD
    WHERE
      PERIOD_TYPE = IS_PERIOD_TYPE
      AND ENTITY_ID = IN_ENTITY_ID
      AND BEGIN_DATE BETWEEN ID_BEGIN_DATE AND ID_END_DATE
      AND ROWNUM = 1;
    IF N_CNT > 0 THEN
      OS_MESSAGE := '已存在对应日期范围的周期信息，不能重复生成！';
    END IF;
    
    IF OS_MESSAGE = 'OK' THEN
      --按分类生成周期
      IF IS_PERIOD_TYPE = 'YEAR' THEN
        --按年生成周期
        S_STEP := '按年生成周期';
        P_INIT_PERIOD_YEAR(IN_ENTITY_ID,ID_BEGIN_DATE,ID_END_DATE,IN_PARENT_PERIOD_ID,IS_USER_ACCOUNT,OS_MESSAGE);
      ELSIF IS_PERIOD_TYPE = 'MONTH' THEN
        --按月生成周期
        S_STEP := '按月生成周期';
        P_INIT_PERIOD_MONTH(IN_ENTITY_ID,ID_BEGIN_DATE,ID_END_DATE,IN_PARENT_PERIOD_ID,IS_USER_ACCOUNT,OS_MESSAGE);
      ELSE
        --按日生成周期
        S_STEP := '按日生成周期';
        P_INIT_PERIOD_DAY(IN_ENTITY_ID,ID_BEGIN_DATE,ID_END_DATE,IN_PARENT_PERIOD_ID,IS_USER_ACCOUNT,OS_MESSAGE);
      END IF;
    END IF;
    
    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP_INIT_PERIOD;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_INIT_PERIOD;
      OS_MESSAGE := '初始报表周期-'|| S_STEP || ':' || SQLERRM;
  END P_INIT_PERIOD;

  -----------------------------------------------------------------------------
  --      初始报表结果，内部调用，不处理出错                                 --
  --处理逻辑：
  --1、对于不存在报表头，则生成报表头。
  --2、记录报表行中的调整信息，重新生成报表行（按账户、报表定义项目生成相关数据为0的行）。
  --3、按已记录报表行的调整信息更新到最新的报表行中。
  --4、更新上期值、上期累计。
  -----------------------------------------------------------------------------
  PROCEDURE P_INIT_RPT_RESULT(
    IN_RPT_DEFINE_ID          IN  NUMBER   --报表定义ID
    ,IN_RPT_PERIOD_ID         IN  NUMBER   --报表周期ID
    ,IS_RPT_NAME              IN  VARCHAR2 --报表名称
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,ID_RESULT_DATE           IN  DATE     --计算结果日期
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --操作用户账号
    ,ON_RPT_RESULT_ID         OUT NUMBER   --报表结果ID
    ,OS_MESSAGE               OUT VARCHAR2 --检查信息
  )
  IS
    S_RPT_STATUS VARCHAR2(32); --报表状态
    N_PRIOR_PERIOD_ID NUMBER; --上一周期ID
    S_STEP VARCHAR2(40);
    N_CNT NUMBER;
    N_PRIOR_RESULT_ID NUMBER;
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP_INIT_RPT_RESULT;
    
    --根据报表定义ID、主体ID、计算报表结果日期,获取对应的报表结果ID
    S_STEP := '获取报表信息';
    BEGIN
      SELECT
        RPT_RESULT_ID
        ,RPT_STATUS
      INTO
        ON_RPT_RESULT_ID
        ,S_RPT_STATUS
      FROM
        T_BD_RPT_RESULT
      WHERE
        RPT_DEFINE_ID = IN_RPT_DEFINE_ID
        AND RPT_PERIOD_ID = IN_RPT_PERIOD_ID
        AND ENTITY_ID = IN_ENTITY_ID
      FOR UPDATE NOWAIT;
      
      IF S_RPT_STATUS = 'CHECKED' THEN
        OS_MESSAGE := '当前报表已审核，不能重算！报表ID：' || TO_CHAR(ON_RPT_RESULT_ID);
      END IF;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        --没有对应的数据则设置为0
        ON_RPT_RESULT_ID := 0;
    END;    
    
    IF OS_MESSAGE = 'OK' THEN
      IF ON_RPT_RESULT_ID = 0 THEN
        --没有报表结果信息，则生成报表结果头信息
        --获取报表结果ID
        SELECT
          S_BD_RPT_RESULT.NEXTVAL
        INTO
          ON_RPT_RESULT_ID
        FROM
          DUAL;
        
        --写结果表
        S_STEP := '写结果表';
        INSERT INTO T_BD_RPT_RESULT
        (
          RPT_RESULT_ID
          ,RPT_DEFINE_ID
          ,RPT_PERIOD_ID
          ,RPT_NAME
          ,RESULT_DATE
          ,ENTITY_ID
          ,RPT_STATUS
          ,CREATED_BY
          ,CREATION_DATE
          ,LAST_UPDATED_BY
          ,LAST_UPDATE_DATE
        )
        VALUES
        (
          ON_RPT_RESULT_ID --RPT_RESULT_ID
          ,IN_RPT_DEFINE_ID --RPT_DEFINE_ID
          ,IN_RPT_PERIOD_ID --RPT_PERIOD_ID
          ,IS_RPT_NAME --RPT_NAME
          ,ID_RESULT_DATE --RESULT_DATE
          ,IN_ENTITY_ID --ENTITY_ID
          ,'ENTER' --RPT_STATUS
          ,IS_USER_ACCOUNT --CREATED_BY
          ,SYSDATE --CREATION_DATE
          ,IS_USER_ACCOUNT --LAST_UPDATED_BY
          ,SYSDATE --LAST_UPDATE_DATE
        );
        
      ELSE
        --存在则删除报表调整中间表对应内容(临时表)
        S_STEP := '删除报表调整中间表内容';
        DELETE FROM T_BD_RPT_ADJUST_TMP;
        
        --将当前报表中的调整内容记录到中间表
        S_STEP := '记录中间表内容';
        INSERT INTO T_BD_RPT_ADJUST_TMP
        (
          ACCOUNT_ID
          ,RPT_DEFINE_ITEM_ID
          ,ADJUST_VAL
        )
        SELECT
          ACCOUNT_ID
          ,RPT_DEFINE_ITEM_ID
          ,ADJUST_VAL
        FROM
          T_BD_RPT_RESULT_DETAIL
        WHERE
          RPT_RESULT_ID = ON_RPT_RESULT_ID
          AND ADJUST_VAL <> 0;
          
        --删除对应的报表结果（明细）
        S_STEP := '删除报表结果（明细）';
        DELETE FROM
          T_BD_RPT_RESULT_DETAIL
        WHERE
          RPT_RESULT_ID = ON_RPT_RESULT_ID;
        
        --删除对应的报表结果（横放明细）
        S_STEP := '删除报表结果（横放明细）';
        DELETE FROM
          T_BD_RPT_DETAIL_TRAVERSE
        WHERE
          RPT_RESULT_ID = ON_RPT_RESULT_ID;
      END IF;
      
      --重新生成报表结果明细空表，每个账户生成对应的报表内容，失效的客户仍要生成报表数据
      S_STEP := '生成报表结果明细空表';
      INSERT INTO T_BD_RPT_RESULT_DETAIL
      (
        RPT_DETAIL_ID
        ,RPT_DEFINE_ITEM_ID
        ,RPT_RESULT_ID
        ,SALES_CENTER_ID
        ,SALES_CENTER_CODE
        ,SALES_CENTER_NAME
        ,CUSTOMER_ID
        ,CUSTOMER_CODE
        ,CUSTOMER_NAME
        ,ACCOUNT_ID
        ,INDUSTRY_TYPE
        ,RPT_ITEM_CODE
        ,RPT_ITEM_NAME
        ,RPT_ITEM_TYPE
        ,RPT_ITEM_CURR_SUM
        ,RPT_ITEM_CURR_VAL
        ,RPT_ITEM_PRIOR_SUM
        ,RPT_ITEM_PRIOR_VAL
        ,ADJUST_VAL
        ,CREATED_BY
        ,CREATION_DATE
        ,LAST_UPDATED_BY
        ,LAST_UPDATE_DATE
      )
      SELECT
        S_BD_RPT_RESULT_DETAIL.NEXTVAL RPT_DETAIL_ID
        ,I.RPT_DEFINE_ITEM_ID RPT_DEFINE_ITEM_ID
        ,ON_RPT_RESULT_ID RPT_RESULT_ID
        ,O.SALES_CENTER_ID
        ,O.SALES_CENTER_CODE
        ,O.SALES_CENTER_NAME
        ,C.CUSTOMER_ID
        ,C.CUSTOMER_CODE
        ,C.CUSTOMER_NAME
        ,A.ACCOUNT_ID
        ,(
          SELECT
            CL.CODE_NAME
          FROM
            T_CUSTOMER_CHANNEL_TYPE CT
            ,UP_CODELIST CL
          WHERE
            CT.INDUSTRY_TYPE = CL.CODE_VALUE
            AND CL.CODETYPE = 'MIDEA_ACCNT_CHANNEL_TYPE'
            AND CT.CUSTOMER_ID = C.CUSTOMER_ID
            AND CT.ACTIVE_FLAG = 'Active'
            AND CT.ENTITY_ID = IN_ENTITY_ID
            AND ROWNUM = 1
        ) INDUSTRY_TYPE  --对于存在多个业态类型，则只取第一个
        ,I.RPT_ITEM_CODE
        ,I.RPT_ITEM_NAME
        ,I.RPT_ITEM_TYPE
        ,0 PRT_ITEM_CURR_SUM
        ,0 RPT_ITEM_CURR_VAL
        ,0 RPT_ITEM_PRIOR_SUM
        ,0 RPT_ITEM_PRIOR_VAL
        ,0 ADJUST_VAL
        ,IS_USER_ACCOUNT CREATED_BY
        ,SYSDATE CREATION_DATE
        ,IS_USER_ACCOUNT LAST_UPDATED_BY
        ,SYSDATE LAST_UPDATE_DATE
      FROM
        T_CUSTOMER_HEADER C
        ,T_CUSTOMER_ACCOUNT A
        ,T_CUSTOMER_ORG O
        ,T_CUSTOMER_ACC_ORG_RELATION R
        ,T_BD_RPT_DEFINE_ITEM I
      WHERE
        C.CUSTOMER_ID = A.CUSTOMER_ID
        AND C.CUSTOMER_ID = O.CUSTOMER_ID
        AND R.ACCOUNT_ID = A.ACCOUNT_ID
        AND R.CUSTOMER_ORG_ID = O.CUSTOMER_ORG_ID
        AND A.ENTITY_ID = IN_ENTITY_ID
        --AND C.ACTIVE_FLAG = 'Active'
        --AND A.ACTIVE_FLAG = 'Y'
        AND I.RPT_DEFINE_ID = IN_RPT_DEFINE_ID;
      
      --检查是否存在调整值
      SELECT
        COUNT(*)
      INTO
        N_CNT
      FROM
        T_BD_RPT_ADJUST_TMP;
      
      --存在之前录入的调整值，则更新调整值
      IF N_CNT > 0 THEN
        S_STEP := '更新调整值';
        UPDATE
          T_BD_RPT_RESULT_DETAIL D
        SET
          ADJUST_VAL =
          (
            SELECT
              ADJUST_VAL
            FROM
              T_BD_RPT_ADJUST_TMP T
            WHERE
              T.ACCOUNT_ID = D.ACCOUNT_ID
              AND T.RPT_DEFINE_ITEM_ID = D.RPT_DEFINE_ITEM_ID
          )
        WHERE
          EXISTS(
            SELECT
              1
            FROM
              T_BD_RPT_ADJUST_TMP T
            WHERE
              T.ACCOUNT_ID = D.ACCOUNT_ID
              AND T.RPT_DEFINE_ITEM_ID = D.RPT_DEFINE_ITEM_ID
          );
          
      END IF;
      
      --记录上期累计、上期值
      S_STEP := '记录上期值';
      BEGIN
        --取上一周期ID
        SELECT
          PP.RPT_PERIOD_ID
        INTO
          N_PRIOR_PERIOD_ID
        FROM
          T_BD_RPT_PERIOD PC
          ,T_BD_RPT_PERIOD PP
        WHERE
          PC.PARENT_PERIOD_ID = PP.PARENT_PERIOD_ID
          AND PC.RPT_PERIOD_ID = IN_RPT_PERIOD_ID
          AND PC.BEGIN_DATE-1 = PP.END_DATE;
        
        --取上一周期的报表ID
        SELECT
          RPT_RESULT_ID
        INTO
          N_PRIOR_RESULT_ID
        FROM
          T_BD_RPT_RESULT
        WHERE
          RPT_DEFINE_ID = IN_RPT_DEFINE_ID
          AND RPT_PERIOD_ID = N_PRIOR_PERIOD_ID
          AND ENTITY_ID = IN_ENTITY_ID;
        
        --存在上一周期，则记录上期累计、上期值
        UPDATE
          T_BD_RPT_RESULT_DETAIL DC
        SET
          (RPT_ITEM_PRIOR_SUM,RPT_ITEM_PRIOR_VAL) =
          (
            SELECT
              RPT_ITEM_CURR_SUM
              ,RPT_ITEM_CURR_VAL
            FROM
              T_BD_RPT_RESULT_DETAIL DP
            WHERE
              DP.ACCOUNT_ID = DC.ACCOUNT_ID
              AND DP.RPT_DEFINE_ITEM_ID =DC.RPT_DEFINE_ITEM_ID
              AND DP.RPT_RESULT_ID = N_PRIOR_RESULT_ID
          )
        WHERE
          RPT_RESULT_ID = ON_RPT_RESULT_ID
          AND EXISTS(
            SELECT
              1
            FROM
              T_BD_RPT_RESULT_DETAIL DP
            WHERE
              DP.ACCOUNT_ID = DC.ACCOUNT_ID
              AND DP.RPT_DEFINE_ITEM_ID =DC.RPT_DEFINE_ITEM_ID
              AND DP.RPT_RESULT_ID = N_PRIOR_RESULT_ID
          );
        
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
        
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_INIT_RPT_RESULT;
      OS_MESSAGE := '初始报表结果-'|| S_STEP || ':' || SQLERRM;
  END P_INIT_RPT_RESULT;

  -----------------------------------------------------------------------------
  --      执行动态SQL，对于存在相关参数则处理绑定参数                                 --
  -----------------------------------------------------------------------------
  PROCEDURE P_EXECUTE_SQL(
    IS_SQL                    IN  VARCHAR2 --要执行的SQL
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,IN_BILL_ID               IN  NUMBER   --单据ID
    ,IN_BILL_LINE_ID          IN  NUMBER   --单据行ID
    ,ID_BEGIN_DATE            IN  DATE     --起始统计日期
    ,ID_END_DATE              IN  DATE     --终止统计日期
  )
  IS
    N_CUR NUMBER;
    N_ROW NUMBER;
  BEGIN
    --打开光标
    N_CUR := DBMS_SQL.OPEN_CURSOR;
    --解析动态SQL语句
    DBMS_SQL.PARSE(N_CUR, IS_SQL, DBMS_SQL.NATIVE);
    --绑定输入参数
    IF INSTR(IS_SQL, ':P_BEGIN_DATE', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_BEGIN_DATE', ID_BEGIN_DATE);
    END IF;
    IF INSTR(IS_SQL, ':P_END_DATE', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_END_DATE', ID_END_DATE);
    END IF;
    IF INSTR(IS_SQL, ':P_ENTITY_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_ENTITY_ID', IN_ENTITY_ID);
    END IF;
    IF INSTR(IS_SQL, ':P_BILL_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_BILL_ID', IN_BILL_ID);
    END IF;
    IF INSTR(IS_SQL, ':P_BILL_LINE_ID', 1, 1) > 0 THEN
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_BILL_LINE_ID', IN_BILL_LINE_ID);
    END IF;
    --执行语句
    N_ROW := DBMS_SQL.EXECUTE(N_CUR);
    --关闭光标
    DBMS_SQL.CLOSE_CURSOR(N_CUR);
  END P_EXECUTE_SQL;
  
  -----------------------------------------------------------------------------
  --      根据语义写报表结果，内部调用                                 --
  --处理逻辑：
  --1、按语义ID取出对应的SQL，拼接成写中间表的SQL（按账户汇总）。
  --2、根据账户合并关系更新中间表的账户信息
  --3、按账户汇总中间表的结果，更新到报表行中
  -----------------------------------------------------------------------------
  PROCEDURE P_SET_RPT_SEMANTIC_VAL(
    IN_RPT_RESULT_ID          IN  NUMBER   --报表结果ID
    ,IN_RPT_DEFINE_ITEM_ID    IN  NUMBER   --报表定义行ID
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,IN_SEMANTIC_ID           IN  NUMBER   --语义编码
    ,IS_SEMANTIC_FIELD        IN  VARCHAR2 --语义取值字段
    ,ID_BEGIN_DATE            IN  DATE     --起始统计日期
    ,ID_END_DATE              IN  DATE     --终止统计日期
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --操作用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --检查信息
  )
  IS
    S_GET_VAL_SQL VARCHAR2(4000);
    S_PRE_PROC_SQL VARCHAR2(4000);
    --S_UPDATE_SQL VARCHAR2(4000);
    S_INSERT_SQL VARCHAR2(4000);
    N_CUR NUMBER;
    S_STEP VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP_SET_RPT_SEMANTIC_VAL;
    
    --根据语义获取对应的SQL
    S_STEP := '获取SQL';
    SELECT
      GET_VAL_SQL
      ,PRE_PROC_SQL
    INTO
      S_GET_VAL_SQL
      ,S_PRE_PROC_SQL
    FROM
      T_POL_SEMANTIC
    WHERE
      SEMANTIC_ID = IN_SEMANTIC_ID
      AND ENTITY_ID = IN_ENTITY_ID;
    
    --拼接成写中间表T_BD_RPT_ADJUST_TMP的SQL
    S_INSERT_SQL := 'INSERT INTO T_BD_RPT_ADJUST_TMP(RPT_DEFINE_ITEM_ID,ACCOUNT_ID,ADJUST_VAL) SELECT ACCOUNT_ID,ACCOUNT_ID,SUM('
      || IS_SEMANTIC_FIELD || ') FROM ('
      || S_GET_VAL_SQL || ') WHERE ACCOUNT_ID IS NOT NULL GROUP BY ACCOUNT_ID';
    
    --拼接成更新结果表的SQL
    --S_UPDATE_SQL := 'UPDATE T_BD_RPT_RESULT_DETAIL D SET RPT_ITEM_CURR_SUM=(SELECT SUM('
    --  || IS_SEMANTIC_FIELD || ') FROM ('
    --  || S_GET_VAL_SQL || ') R WHERE R.ACCOUNT_ID=D.ACCOUNT_ID)'
    --  || ' WHERE RPT_RESULT_ID=' || TO_CHAR(IN_RPT_RESULT_ID)
    --  || ' AND RPT_DEFINE_ITEM_ID=' || TO_CHAR(IN_RPT_DEFINE_ITEM_ID);
    
    --存在预处理SQL，则先执行预处理
    IF S_PRE_PROC_SQL IS NOT NULL THEN
      S_STEP := '执行预处理语句';
      P_EXECUTE_SQL(S_PRE_PROC_SQL,IN_ENTITY_ID,IN_RPT_RESULT_ID,IN_RPT_DEFINE_ITEM_ID,ID_BEGIN_DATE,ID_END_DATE);
    END IF;
    
    --删除中间表内容
    DELETE FROM T_BD_RPT_ADJUST_TMP;
    
    --执行SQL，写中间表
    S_STEP := '执行语义取值';
    P_EXECUTE_SQL(S_INSERT_SQL,IN_ENTITY_ID,IN_RPT_RESULT_ID,IN_RPT_DEFINE_ITEM_ID,ID_BEGIN_DATE,ID_END_DATE);
    
    --根据客户合并关系更新对应的账户ID
    UPDATE
      T_BD_RPT_ADJUST_TMP T
    SET
      RPT_DEFINE_ITEM_ID=
      (
        SELECT
          M.TAR_ACCOUNT_ID
        FROM
          T_BD_RPT_CUS_MERGE M
        WHERE
          M.ACCOUNT_ID = T.ACCOUNT_ID
      )
    WHERE
      EXISTS(
        SELECT
          1
        FROM
          T_BD_RPT_CUS_MERGE M
        WHERE
          M.ACCOUNT_ID = T.ACCOUNT_ID
      );
    
    --更新到报表中
    UPDATE
      T_BD_RPT_RESULT_DETAIL D
    SET
      RPT_ITEM_CURR_SUM=
      (
        SELECT
          SUM(ADJUST_VAL)
        FROM
          T_BD_RPT_ADJUST_TMP T
        WHERE
          T.RPT_DEFINE_ITEM_ID = D.ACCOUNT_ID
      )
    WHERE
      RPT_RESULT_ID = IN_RPT_RESULT_ID
      AND RPT_DEFINE_ITEM_ID = IN_RPT_DEFINE_ITEM_ID;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_SET_RPT_SEMANTIC_VAL;
      OS_MESSAGE := '设置语义[' || IN_SEMANTIC_ID || ']值-'|| S_STEP || ':' || SQLERRM;
  END P_SET_RPT_SEMANTIC_VAL;

  -----------------------------------------------------------------------------
  --      根据公式写报表结果，内部调用                                 --
  --处理逻辑：
  --1、循环取出报表中涉及的账户ID，取报表中的其它项作为参数带入公式中，执行公式，更新到报表行中。
  -----------------------------------------------------------------------------
  PROCEDURE P_SET_RPT_EXPRESSION_VAL(
    IN_RPT_RESULT_ID          IN  NUMBER   --报表结果ID
    ,IN_RPT_DEFINE_ITEM_ID    IN  NUMBER   --报表定义行ID
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,IS_EXPRESSION            IN  VARCHAR2 --取数公式
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --操作用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --检查信息
  )
  IS
    S_UPDATE_SQL VARCHAR2(4000);
    N_CUR NUMBER;
    N_ROW NUMBER;
    S_PARAM_NAME VARCHAR2(40);
    S_STEP VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP_SET_RPT_EXPRESSION_VAL;
    
    S_UPDATE_SQL := 'UPDATE T_BD_RPT_RESULT_DETAIL SET RPT_ITEM_CURR_SUM=' || IS_EXPRESSION
      || ' WHERE RPT_RESULT_ID=:P_RPT_RESULT_ID'
      || ' AND RPT_DEFINE_ITEM_ID=:P_RPT_DEFINE_ITEM_ID'
      || ' AND ACCOUNT_ID=:P_ACCOUNT_ID';
    
    --打开光标
    N_CUR := DBMS_SQL.OPEN_CURSOR;
    --解析动态SQL语句
    DBMS_SQL.PARSE(N_CUR, S_UPDATE_SQL, DBMS_SQL.NATIVE);
    --按账户ID循环，分别取出对应的报表数据
    FOR R_ACCOUNT IN
    (
      SELECT DISTINCT
        ACCOUNT_ID
      FROM
        T_BD_RPT_RESULT_DETAIL
      WHERE
        RPT_RESULT_ID = IN_RPT_RESULT_ID
        AND RPT_DEFINE_ITEM_ID = IN_RPT_DEFINE_ITEM_ID
    )
    LOOP
      S_STEP := '账户ID:' || TO_CHAR(R_ACCOUNT.ACCOUNT_ID);
      --循环获取公式中使用的编码，作为参数绑定到SQL
      FOR R_DETAIL IN
      (
        SELECT
          RPT_ITEM_CODE
          ,NVL(RPT_ITEM_CURR_SUM,0) RPT_ITEM_CURR_SUM
        FROM
          T_BD_RPT_RESULT_DETAIL
        WHERE
          RPT_RESULT_ID = IN_RPT_RESULT_ID
          AND ACCOUNT_ID = R_ACCOUNT.ACCOUNT_ID
      )
      LOOP
        S_PARAM_NAME := ':' || R_DETAIL.RPT_ITEM_CODE; 
        --公式存在对应的编码则作为参数
        --绑定输入参数
        IF INSTR(S_UPDATE_SQL, S_PARAM_NAME, 1, 1) > 0 THEN
          DBMS_SQL.BIND_VARIABLE(N_CUR, S_PARAM_NAME, R_DETAIL.RPT_ITEM_CURR_SUM);
        END IF;
      END LOOP;
      --绑定指定参数
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_RPT_RESULT_ID', IN_RPT_RESULT_ID);
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_RPT_DEFINE_ITEM_ID', IN_RPT_DEFINE_ITEM_ID);
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_ACCOUNT_ID', R_ACCOUNT.ACCOUNT_ID);

      --执行SQL
      N_ROW := DBMS_SQL.EXECUTE(N_CUR);
    END LOOP;
    
    --关闭光标
    DBMS_SQL.CLOSE_CURSOR(N_CUR);

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_SET_RPT_EXPRESSION_VAL;
      OS_MESSAGE := '设置公式值-公式(' || IS_EXPRESSION || ')' || S_STEP || ':' || SQLERRM;
  END P_SET_RPT_EXPRESSION_VAL;

  -----------------------------------------------------------------------------
  --      写报表结果明细，内部调用，不处理出错                                 --
  --处理逻辑：
  --1、循环取出报表项目，按项目定义，分别处理语义、外部数据、计算公式的报表数据更新。
  --2、按取值方式（当月/累计）更新报表当前值。
  -----------------------------------------------------------------------------
  PROCEDURE P_SET_RPT_RESULT_DETAIL(
    IN_RPT_RESULT_ID          IN  NUMBER   --报表结果ID
    ,IN_RPT_DEFINE_ID         IN  NUMBER   --报表定义ID
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,IN_RPT_PERIOD_ID         IN  NUMBER   --周期ID
    ,IS_CAL_METHOD            IN  VARCHAR2 --计算方式
    ,ID_BEGIN_DATE            IN  DATE     --起始统计日期
    ,ID_END_DATE              IN  DATE     --终止统计日期
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --操作用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --检查信息
  )
  IS
    S_RPT_STATUS VARCHAR2(32); --报表状态
    S_STEP VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP_SET_RPT_RESULT_DETAIL;
    
    --按优先级顺序循环取出对应的报表项目
    FOR R_DEFINE_ITEM IN
    (
      SELECT
        PRIORITY_LEVEL
        ,RPT_DEFINE_ITEM_ID
        ,RPT_ITEM_TYPE
        ,SEMANTIC_ID
        ,SEMANTIC_FIELD
        ,GET_VAL_EXPRESSION
        ,OUT_DATA_CODE
      FROM
        T_BD_RPT_DEFINE_ITEM
      WHERE
        RPT_DEFINE_ID = IN_RPT_DEFINE_ID
      ORDER BY
        PRIORITY_LEVEL
        ,RPT_ITEM_CODE
    )
    LOOP
      --RPT_ITEM_TYPE: SEMANTIC:语义；EXPRESSION：公式；OUT_DATA：外部数据
      IF R_DEFINE_ITEM.RPT_ITEM_TYPE = 'SEMANTIC' THEN
        S_STEP := '语义取值RPT_DEFINE_ITEM_ID=' || TO_CHAR(R_DEFINE_ITEM.RPT_DEFINE_ITEM_ID);
        --对于语义则对应SQL统计值，记录报表值
        P_SET_RPT_SEMANTIC_VAL(
          IN_RPT_RESULT_ID
          ,R_DEFINE_ITEM.RPT_DEFINE_ITEM_ID
          ,IN_ENTITY_ID
          ,R_DEFINE_ITEM.SEMANTIC_ID
          ,R_DEFINE_ITEM.SEMANTIC_FIELD
          ,ID_BEGIN_DATE
          ,ID_END_DATE
          ,IS_USER_ACCOUNT
          ,OS_MESSAGE
        );

      ELSIF R_DEFINE_ITEM.RPT_ITEM_TYPE = 'OUT_DATA' THEN
        S_STEP := '外部数据取值RPT_DEFINE_ITEM_ID=' || TO_CHAR(R_DEFINE_ITEM.RPT_DEFINE_ITEM_ID);
        --从外部数据获取对应值
        --T_POL_POLICY_OUT_DATA增加周期ID
        --从外部数据获取对应值,更新数据
        /* 查询子句，拆分为两条以利用索引
        UPDATE
          T_BD_RPT_RESULT_DETAIL D
        SET
          RPT_ITEM_CURR_SUM =
          (
            SELECT
              SUM(OD.DATA_VALUE)
            FROM
              T_POL_POLICY_OUT_DATA OD
              ,T_BD_RPT_CUS_MERGE CM
            WHERE
              OD.ACCOUNT_ID = CM.ACCOUNT_ID(+)
              AND NVL(CM.TAR_ACCOUNT_ID,OD.ACCOUNT_ID) = D.ACCOUNT_ID
              AND OD.OUT_DATA_TYPE = R_DEFINE_ITEM.OUT_DATA_CODE
              AND OD.RPT_PERIOD_ID = IN_RPT_PERIOD_ID
              AND OD.ENTITY_ID = IN_ENTITY_ID
          )
        WHERE
          RPT_RESULT_ID = IN_RPT_RESULT_ID
          AND RPT_DEFINE_ITEM_ID = R_DEFINE_ITEM.RPT_DEFINE_ITEM_ID;
        */  
        UPDATE T_BD_RPT_RESULT_DETAIL D
           SET RPT_ITEM_CURR_SUM =
               (SELECT NVL(SUM(NVL(OD.DATA_VALUE, 0)), 0)
                  FROM T_POL_POLICY_OUT_DATA OD, T_BD_RPT_CUS_MERGE CM
                 WHERE CM.TAR_ACCOUNT_ID = D.ACCOUNT_ID
                   AND OD.ACCOUNT_ID = CM.ACCOUNT_ID
                   AND OD.OUT_DATA_TYPE = R_DEFINE_ITEM.OUT_DATA_CODE
                   AND OD.RPT_PERIOD_ID = IN_RPT_PERIOD_ID
                   AND OD.ENTITY_ID = IN_ENTITY_ID) +
               (SELECT NVL(SUM(NVL(OD.DATA_VALUE, 0)), 0)
                  FROM CIMS.T_POL_POLICY_OUT_DATA OD
                 WHERE OD.ACCOUNT_ID = D.ACCOUNT_ID
                   AND OD.OUT_DATA_TYPE = R_DEFINE_ITEM.OUT_DATA_CODE
                   AND OD.RPT_PERIOD_ID = IN_RPT_PERIOD_ID
                   AND OD.ENTITY_ID = IN_ENTITY_ID
                   AND NOT EXISTS
                 (SELECT 1
                          FROM CIMS.T_BD_RPT_CUS_MERGE CM
                         WHERE CM.ACCOUNT_ID = OD.ACCOUNT_ID))
         WHERE RPT_RESULT_ID = IN_RPT_RESULT_ID
           AND RPT_DEFINE_ITEM_ID = R_DEFINE_ITEM.RPT_DEFINE_ITEM_ID;

      ELSE --R_DEFINE_ITEM.RPT_ITEM_TYPE = 'EXPRESSION'
        S_STEP := '公式取值RPT_DEFINE_ITEM_ID=' || TO_CHAR(R_DEFINE_ITEM.RPT_DEFINE_ITEM_ID);
        --对于公式则循环报表值，按报表编码更新到公式中,再通过动态SQL获取公式对应的值，并记录报表值
        P_SET_RPT_EXPRESSION_VAL(
          IN_RPT_RESULT_ID          --报表结果ID
          ,R_DEFINE_ITEM.RPT_DEFINE_ITEM_ID    --报表定义行ID
          ,IN_ENTITY_ID             --主体ID
          ,R_DEFINE_ITEM.GET_VAL_EXPRESSION            --取数公式
          ,IS_USER_ACCOUNT          --操作用户账号
          ,OS_MESSAGE               --检查信息
        );
      END IF;
      
      EXIT WHEN OS_MESSAGE <> 'OK';
      
    END LOOP;
    
    IF OS_MESSAGE = 'OK' THEN
      --更新本期当前值
      S_STEP := '更新本期当前值RPT_RESULT_ID=' || TO_CHAR(IN_RPT_RESULT_ID);
      IF IS_CAL_METHOD = 'SUM_CUR' THEN
        UPDATE
          T_BD_RPT_RESULT_DETAIL
        SET
          RPT_ITEM_CURR_VAL = NVL(RPT_ITEM_CURR_SUM,0) - NVL(RPT_ITEM_PRIOR_SUM,0)
        WHERE
          RPT_RESULT_ID = IN_RPT_RESULT_ID;
      ELSE
        UPDATE
          T_BD_RPT_RESULT_DETAIL
        SET
          RPT_ITEM_CURR_VAL = RPT_ITEM_CURR_SUM
        WHERE
          RPT_RESULT_ID = IN_RPT_RESULT_ID;
      END IF;
    END IF;
    
    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP_SET_RPT_RESULT_DETAIL;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_SET_RPT_RESULT_DETAIL;
      OS_MESSAGE := '计算报表结果明细-'|| S_STEP || '(报表结果ID:' || TO_CHAR(IN_RPT_RESULT_ID) || '):' || SQLERRM;
  END P_SET_RPT_RESULT_DETAIL;

  -----------------------------------------------------------------------------
  --      根据报表结果明细写报表结果明细横放表，内部调用，不处理出错         --
  --处理逻辑：
  --1、按报表行中涉及的账户，以及统计方式生成横放表空表。
  --2、按报表定义中的编码顺序，将竖放表的内容更新到横放表中。
  -----------------------------------------------------------------------------
  PROCEDURE P_SET_RPT_RESULT_TRAVERSE(
    IN_RPT_RESULT_ID          IN  NUMBER   --报表结果ID
    ,IN_RPT_DEFINE_ID         IN  NUMBER   --报表定义ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --操作用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --检查信息
  )
  IS
    S_UPDATE_SQL VARCHAR2(4000); --数据更新SQL
    S_FIELD VARCHAR2(30);
    N_INDEX NUMBER;
    N_CUR NUMBER;
    N_ROW NUMBER;
    S_STEP VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP_SET_RPT_RESULT_TRAVERSE;
    --T_BD_RPT_DETAIL_TRAVERSE
    
    --插入空表,统计口径（SUM:累计；CUR:当期）
    S_STEP := '生成空表';
    INSERT INTO T_BD_RPT_DETAIL_TRAVERSE
    (
      RPT_DETAIL_TRAVERSE_ID
      ,RPT_RESULT_ID
      ,SALES_CENTER_ID
      ,SALES_CENTER_CODE
      ,SALES_CENTER_NAME
      ,CUSTOMER_ID
      ,CUSTOMER_CODE
      ,CUSTOMER_NAME
      ,INDUSTRY_TYPE
      ,ACCOUNT_ID
      ,STAT_WAY
      ,CREATED_BY
      ,CREATION_DATE
      ,LAST_UPDATED_BY
      ,LAST_UPDATE_DATE
    )
    SELECT
      S_BD_RPT_DETAIL_TRAVERSE.NEXTVAL RPT_DETAIL_TRAVERSE_ID
      ,IN_RPT_RESULT_ID RPT_RESULT_ID
      ,D.SALES_CENTER_ID
      ,D.SALES_CENTER_CODE
      ,D.SALES_CENTER_NAME
      ,D.CUSTOMER_ID
      ,D.CUSTOMER_CODE
      ,D.CUSTOMER_NAME
      ,D.INDUSTRY_TYPE
      ,D.ACCOUNT_ID
      ,C.STAT_WAY
      ,IS_USER_ACCOUNT CREATED_BY
      ,SYSDATE CREATION_DATE
      ,IS_USER_ACCOUNT LAST_UPDATED_BY
      ,SYSDATE LAST_UPDATE_DATE
    FROM
      (
        SELECT DISTINCT
          SALES_CENTER_ID
          ,SALES_CENTER_CODE
          ,SALES_CENTER_NAME
          ,CUSTOMER_ID
          ,CUSTOMER_CODE
          ,CUSTOMER_NAME
          ,INDUSTRY_TYPE
          ,ACCOUNT_ID
        FROM
          T_BD_RPT_RESULT_DETAIL
        WHERE
          RPT_RESULT_ID = IN_RPT_RESULT_ID
      ) D
      ,(
        SELECT
          CODE_VALUE STAT_WAY
        FROM
          UP_CODELIST
        WHERE
          CODETYPE = 'BD_RPT_STAT_WAY'
      ) C;
    
    --循环报表项目，拼接更新SQL
    N_INDEX := 1;
    FOR R_DEFINE_ITEM IN
    (
      SELECT
        RPT_ITEM_CODE
      FROM
        T_BD_RPT_DEFINE_ITEM
      WHERE
        RPT_DEFINE_ID = IN_RPT_DEFINE_ID
      ORDER BY
        RPT_ITEM_CODE
    )
    LOOP
      S_FIELD := 'VALUE' || LPAD(N_INDEX,2,'0');
      S_STEP := '写字段' || S_FIELD || ',RPT_RESULT_ID=' || TO_CHAR(IN_RPT_RESULT_ID);
      --处理累计值更新
      S_UPDATE_SQL := 'UPDATE T_BD_RPT_DETAIL_TRAVERSE T SET '
        || S_FIELD || '=(SELECT RPT_ITEM_CURR_SUM FROM T_BD_RPT_RESULT_DETAIL D '
        || 'WHERE D.ACCOUNT_ID=T.ACCOUNT_ID AND D.RPT_RESULT_ID=' || TO_CHAR(IN_RPT_RESULT_ID) || ' AND D.RPT_ITEM_CODE='''
        || R_DEFINE_ITEM.RPT_ITEM_CODE || ''')'
        || ' WHERE T.RPT_RESULT_ID=' || TO_CHAR(IN_RPT_RESULT_ID) || ' AND STAT_WAY=''SUM''';
      --打开光标
      N_CUR := DBMS_SQL.OPEN_CURSOR;
      --解析动态SQL语句
      DBMS_SQL.PARSE(N_CUR, S_UPDATE_SQL, DBMS_SQL.NATIVE);
      --执行语句
      N_ROW := DBMS_SQL.EXECUTE(N_CUR);
      --关闭光标
      DBMS_SQL.CLOSE_CURSOR(N_CUR);
      
      --处理当期值更新
      S_UPDATE_SQL := 'UPDATE T_BD_RPT_DETAIL_TRAVERSE T SET '
        || S_FIELD || '=(SELECT RPT_ITEM_CURR_VAL FROM T_BD_RPT_RESULT_DETAIL D '
        || 'WHERE D.ACCOUNT_ID=T.ACCOUNT_ID AND D.RPT_RESULT_ID=' || TO_CHAR(IN_RPT_RESULT_ID) || ' AND D.RPT_ITEM_CODE='''
        || R_DEFINE_ITEM.RPT_ITEM_CODE || ''')'
        || ' WHERE T.RPT_RESULT_ID=' || TO_CHAR(IN_RPT_RESULT_ID) || ' AND STAT_WAY=''CUR''';
      --打开光标
      N_CUR := DBMS_SQL.OPEN_CURSOR;
      --解析动态SQL语句
      DBMS_SQL.PARSE(N_CUR, S_UPDATE_SQL, DBMS_SQL.NATIVE);
      --执行语句
      N_ROW := DBMS_SQL.EXECUTE(N_CUR);
      --关闭光标
      DBMS_SQL.CLOSE_CURSOR(N_CUR);

      N_INDEX := N_INDEX+1;
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_SET_RPT_RESULT_TRAVERSE;
      OS_MESSAGE := '写报表横放结果-'|| S_STEP || '(报表结果ID:' || TO_CHAR(IN_RPT_RESULT_ID) || '):' || SQLERRM;
  END P_SET_RPT_RESULT_TRAVERSE;

  -----------------------------------------------------------------------------
  --  按主体计算报表                                                     --
  --处理逻辑：
  --1、根据报表定义ID获取相关信息。
  --2、初始报表（空表）。
  --3、更新报表相关值。
  --4、删除无数据的账户。
  --5、将报表内容生成横放表。
  --6、更新报表生成日期。
  -----------------------------------------------------------------------------
  PROCEDURE P_BUILD_ENTITY_REPORT(
    IN_RPT_DEFINE_ID          IN  NUMBER   --报表定义ID
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,ID_RESULT_DATE           IN  DATE     --计算报表结果日期
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    S_STEP VARCHAR2(40);
    N_RPT_RESULT_ID NUMBER;
    N_RPT_PERIOD_ID NUMBER;
    S_RPT_NAME VARCHAR2(240);
    D_BEGIN_DATE DATE;
    D_END_DATE DATE;
    S_CAL_METHOD VARCHAR2(32);
    N_PARENT_PERIOD_ID NUMBER;
    N_ITEM_CNT NUMBER;
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP_BUILD_ENTITY_REPORT;
    
    --根据日期获取对应的周期信息
    S_STEP := '获取周期信息';
    SELECT
      P.RPT_PERIOD_ID
      ,D.RPT_DEFINE_NAME || '-' || P.PERIOD_NAME
      ,P.BEGIN_DATE
      ,P.END_DATE
      ,D.CAL_METHOD
      ,P.PARENT_PERIOD_ID
    INTO
      N_RPT_PERIOD_ID
      ,S_RPT_NAME
      ,D_BEGIN_DATE
      ,D_END_DATE
      ,S_CAL_METHOD
      ,N_PARENT_PERIOD_ID
    FROM
      T_BD_RPT_PERIOD P
      ,T_BD_RPT_DEFINE D
    WHERE
      P.PERIOD_TYPE = D.PERIOD_TYPE
      AND D.RPT_DEFINE_ID = IN_RPT_DEFINE_ID
      AND P.ENTITY_ID = IN_ENTITY_ID
      AND ID_RESULT_DATE BETWEEN P.BEGIN_DATE AND P.END_DATE
      AND ID_RESULT_DATE BETWEEN D.BEGIN_DATE AND NVL(D.END_DATE,ID_RESULT_DATE);
    
    IF S_CAL_METHOD = 'SUM_CUR' THEN
      --对于通过累计值推算当前值，则需将起始日期取上级周期的起始日期
      S_STEP := '获取累计起始日期';
      BEGIN
        SELECT
          BEGIN_DATE
        INTO
          D_BEGIN_DATE
        FROM
          T_BD_RPT_PERIOD
        WHERE
          RPT_PERIOD_ID = N_PARENT_PERIOD_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          --没找到上级周期则不处理
          NULL;
      END;
    END IF;
    
    --初始报表结果头
      --对于已存在则：删除报表调整中间表对应内容(临时表)、将当前报表中的调整内容记录到中间表、删除对应的报表结果（明细\横放明细）
      --对于不存在则：生成报表结果头信息
    S_STEP := '初始报表结果头';
    P_INIT_RPT_RESULT(IN_RPT_DEFINE_ID,N_RPT_PERIOD_ID,S_RPT_NAME,IN_ENTITY_ID,ID_RESULT_DATE,IS_USER_ACCOUNT,N_RPT_RESULT_ID,OS_MESSAGE);
    
    --按优先级顺序循环取出对应的报表项目
    --对于语义则对应SQL统计值，记录报表值
    --对于公式则循环报表值，按报表编码更新到公式中
    --再通过动态SQL获取公式对应的值，并记录报表值
    --对于出错则回滚到进入点，并返回出错信息
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '更新报表结果明细';
      P_SET_RPT_RESULT_DETAIL(
        N_RPT_RESULT_ID   --报表结果ID
        ,IN_RPT_DEFINE_ID  --报表定义ID
        ,IN_ENTITY_ID      --主体ID
        ,N_RPT_PERIOD_ID   --周期ID
        ,S_CAL_METHOD      --计算方法
        ,D_BEGIN_DATE     --起始统计日期
        ,D_END_DATE       --终止统计日期
        ,IS_USER_ACCOUNT   --操作用户账号
        ,OS_MESSAGE        --检查信息
      );
    END IF;

    --删除没有数据的账户信息
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '删除无数据的账户信息';
      --取报表定义总项目数
      SELECT
        COUNT(*)
      INTO
        N_ITEM_CNT
      FROM
        T_BD_RPT_DEFINE_ITEM
      WHERE
        RPT_DEFINE_ID = IN_RPT_DEFINE_ID;
        
      --对于全部项目为0的账户，则删除
      DELETE FROM
        T_BD_RPT_RESULT_DETAIL D1
      WHERE
        D1.RPT_RESULT_ID = N_RPT_RESULT_ID
        AND D1.ACCOUNT_ID IN
        (
          SELECT
            D2.ACCOUNT_ID
          FROM
            T_BD_RPT_RESULT_DETAIL D2
          WHERE
            D2.RPT_RESULT_ID = N_RPT_RESULT_ID
            AND NVL(RPT_ITEM_CURR_SUM,0) = 0
            AND NVL(RPT_ITEM_PRIOR_SUM,0) = 0
          GROUP BY
            D2.ACCOUNT_ID
          HAVING
            COUNT(*) = N_ITEM_CNT
        );
    END IF;
    
    --写横放表
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '写横放表';
      P_SET_RPT_RESULT_TRAVERSE(
        N_RPT_RESULT_ID    --报表结果ID
        ,IN_RPT_DEFINE_ID   --报表定义ID
        ,IS_USER_ACCOUNT    --操作用户账号
        ,OS_MESSAGE         --检查信息
      );
    END IF;
    
    --更新报表结果表的统计日期
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '更新报表日期';
      UPDATE
        T_BD_RPT_RESULT
      SET
        RESULT_DATE = ID_RESULT_DATE
        ,LAST_UPDATED_BY = IS_USER_ACCOUNT
        ,LAST_UPDATE_DATE = SYSDATE
      WHERE
        RPT_RESULT_ID = N_RPT_RESULT_ID;
    END IF;
    
    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP_BUILD_ENTITY_REPORT;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_BUILD_ENTITY_REPORT;
      OS_MESSAGE := '计算报表结果-'|| S_STEP || '(主体:' || TO_CHAR(IN_ENTITY_ID) || '):' || SQLERRM;
  END P_BUILD_ENTITY_REPORT;

  -----------------------------------------------------------------------------
  --  自动计算报表，通过JOB调用                                              --
  --处理逻辑：
  --1、循环取出要统计的报表，执行报表自动计算，记录报表执行信息。
  -----------------------------------------------------------------------------
  PROCEDURE P_BUILD_REPORT
  IS
    S_STEP VARCHAR2(50);
    D_RESULT_DATE DATE;
    S_MSG VARCHAR2(4000);
    S_EXECUTE_STATUS VARCHAR2(2);
    D_EXECUTE_DATE DATE;
  BEGIN
    --使用昨天的日期处理计算
    D_RESULT_DATE := TRUNC(SYSDATE)-1;
    
    --循环要统计的报表
    FOR R_RPT IN
    (
      SELECT
        D.RPT_DEFINE_ID
        ,E.ENTITY_ID
      FROM
        T_BD_RPT_DEFINE D
        ,T_BD_RPT_PERIOD P
        ,T_BD_RPT_ENTITY E
      WHERE
        P.PERIOD_TYPE = D.PERIOD_TYPE
        AND D.RPT_DEFINE_ID = E.RPT_DEFINE_ID
        AND P.ENTITY_ID = E.ENTITY_ID
        AND D_RESULT_DATE BETWEEN P.BEGIN_DATE AND P.END_DATE
        AND D_RESULT_DATE BETWEEN D.BEGIN_DATE AND NVL(D.END_DATE,D_RESULT_DATE)
        AND D_RESULT_DATE BETWEEN E.BEGIN_DATE AND NVL(E.END_DATE,D_RESULT_DATE)
    )
    LOOP
      S_STEP := '报表定义ID=' || TO_CHAR(R_RPT.RPT_DEFINE_ID) || ',主体ID=' || TO_CHAR(R_RPT.ENTITY_ID);
      S_MSG := 'OK';
      D_EXECUTE_DATE := SYSDATE;
      --执行报表自动计算
      P_BUILD_ENTITY_REPORT(
        R_RPT.RPT_DEFINE_ID   --报表定义ID
        ,R_RPT.ENTITY_ID      --主体ID
        ,D_RESULT_DATE     --计算报表结果日期
        ,'program'   --用户账号
        ,S_MSG             --成功则返回“OK”，否则返回出错信息
      );
      --出错则记录出错信息，继续处理下一个报表
      IF S_MSG = 'OK' THEN
        S_EXECUTE_STATUS := 'S';
      ELSE
        S_EXECUTE_STATUS := 'E';
        ROLLBACK;
      END IF;
      --记录执行信息
      UPDATE
        T_BD_RPT_ENTITY
      SET
        EXECUTE_DATE = D_EXECUTE_DATE
        ,EXECUTE_FINISH_DATE = SYSDATE
        ,EXECUTE_STATUS = S_EXECUTE_STATUS
        ,ERROR_MESSAGE = SUBSTRB(S_MSG,1,300)
        ,LAST_UPDATE_DATE = SYSDATE
        ,LAST_UPDATED_BY = 'program'
      WHERE
        RPT_DEFINE_ID = R_RPT.RPT_DEFINE_ID
        AND ENTITY_ID = R_RPT.ENTITY_ID;
      COMMIT;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      S_MSG := '自动计算报表-'|| S_STEP || ':' || SQLERRM;
      ROLLBACK;
      --记录出错信息
      S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_RPT.P_BUILD_REPORT',0,S_MSG);
  END P_BUILD_REPORT;

  -----------------------------------------------------------------------------
  --  重算报表，通过JOB调用                                                  --
  --处理逻辑：
  --1、循环取出状态为要重算的报表，执行报表自动计算，记录报表执行信息。
  -----------------------------------------------------------------------------
  PROCEDURE P_RECAL_RPT
  IS
    D_RESULT_DATE DATE;
    S_STEP VARCHAR2(40);
    S_MSG VARCHAR2(4000);
    D_EXECUTE_DATE DATE;
    S_EXECUTE_STATUS VARCHAR2(2);
  BEGIN
    --循环要统计的报表
    S_STEP := '获取要重算的报表';
    FOR R_RPT IN
    (
      SELECT
        R.RPT_RESULT_ID
        ,R.RPT_DEFINE_ID
        ,R.ENTITY_ID
        ,R.RESULT_DATE
      FROM
        T_BD_RPT_RESULT R
      WHERE
        R.RPT_STATUS = 'RECAL'
      FOR UPDATE NOWAIT
    )
    LOOP
      S_MSG := 'OK';
      D_EXECUTE_DATE := SYSDATE;
      
      --执行报表自动计算
      S_STEP := '报表计算,结果ID=' || TO_CHAR(R_RPT.RPT_RESULT_ID);
      P_BUILD_ENTITY_REPORT(
        R_RPT.RPT_DEFINE_ID   --报表定义ID
        ,R_RPT.ENTITY_ID      --主体ID
        ,R_RPT.RESULT_DATE     --计算报表结果日期
        ,'program'   --用户账号
        ,S_MSG             --成功则返回“OK”，否则返回出错信息
      );
      
      --出错则记录出错信息，继续处理下一个报表
      IF S_MSG = 'OK' THEN
        --更新报表状态,由于审核要求ENTER状态，故不需锁定
        S_STEP := '更新报表状态';
        UPDATE
          T_BD_RPT_RESULT
        SET
          RPT_STATUS = 'ENTER'
          ,LAST_UPDATED_BY = 'program'
          ,LAST_UPDATE_DATE = SYSDATE
        WHERE
          RPT_RESULT_ID = R_RPT.RPT_RESULT_ID;
        
        COMMIT;
        S_EXECUTE_STATUS := 'S';
      ELSE
        ROLLBACK;
        S_EXECUTE_STATUS := 'E';
        --记录出错信息
        S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_RPT.P_RECAL_RPT',TO_CHAR(R_RPT.RPT_DEFINE_ID),S_MSG);
      END IF;
      
      --出错则记录出错信息，继续处理下一个报表
      UPDATE
        T_BD_RPT_ENTITY
      SET
        EXECUTE_DATE = D_EXECUTE_DATE
        ,EXECUTE_FINISH_DATE = SYSDATE
        ,EXECUTE_STATUS = S_EXECUTE_STATUS
        ,ERROR_MESSAGE = SUBSTRB(S_MSG,1,300)
        ,LAST_UPDATE_DATE = SYSDATE
        ,LAST_UPDATED_BY = 'program'
      WHERE
        RPT_DEFINE_ID = R_RPT.RPT_DEFINE_ID
        AND ENTITY_ID = R_RPT.ENTITY_ID;
      COMMIT;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      S_MSG := '重算报表-'|| S_STEP || ':' || SQLERRM;
      ROLLBACK;
      --记录出错信息
      S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_RPT.P_RECAL_RPT',0,S_MSG);
  END P_RECAL_RPT;

  -----------------------------------------------------------------------------
  --  重算报表调整项                                      --
  --处理逻辑：
  --1、按优先级取出报表对应的公式项，重新计算公式值。
  --2、更新报表当期值。
  -----------------------------------------------------------------------------
  PROCEDURE P_RECAL_ADJUST(
    IN_RPT_RESULT_ID          IN  NUMBER   --报表结果ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )
  IS
    S_RPT_STATUS VARCHAR2(32); --报表状态
    S_STEP VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP_RECAL_ADJUST;
    
    --按优先级顺序循环取出对应的报表项目
    FOR R_DEFINE_ITEM IN
    (
      SELECT
        PRIORITY_LEVEL
        ,RPT_DEFINE_ITEM_ID
        ,GET_VAL_EXPRESSION
        ,ENTITY_ID
      FROM
        T_BD_RPT_RESULT R
        ,T_BD_RPT_DEFINE_ITEM I
      WHERE
        R.RPT_DEFINE_ID = I.RPT_DEFINE_ID
        AND R.RPT_RESULT_ID = IN_RPT_RESULT_ID
        AND I.RPT_ITEM_TYPE = 'EXPRESSION'
      ORDER BY
        PRIORITY_LEVEL
    )
    LOOP
      S_STEP := '公式取值RPT_DEFINE_ITEM_ID=' || TO_CHAR(R_DEFINE_ITEM.RPT_DEFINE_ITEM_ID);
      --对于公式则循环报表值，按报表编码更新到公式中,再通过动态SQL获取公式对应的值，并记录报表值
      P_SET_RPT_EXPRESSION_VAL(
        IN_RPT_RESULT_ID          --报表结果ID
        ,R_DEFINE_ITEM.RPT_DEFINE_ITEM_ID    --报表定义行ID
        ,R_DEFINE_ITEM.ENTITY_ID             --主体ID
        ,R_DEFINE_ITEM.GET_VAL_EXPRESSION            --取数公式
        ,IS_USER_ACCOUNT          --操作用户账号
        ,OS_MESSAGE               --检查信息
      );
      
      EXIT WHEN OS_MESSAGE <> 'OK';
      
    END LOOP;
    
    IF OS_MESSAGE = 'OK' THEN
      --更新本期当前值
       S_STEP := '更新本期当前值RPT_RESULT_ID=' || TO_CHAR(IN_RPT_RESULT_ID);
      UPDATE
        T_BD_RPT_RESULT_DETAIL
      SET
        RPT_ITEM_CURR_VAL = RPT_ITEM_CURR_SUM - NVL(RPT_ITEM_PRIOR_SUM,0)
      WHERE
        RPT_RESULT_ID = IN_RPT_RESULT_ID;
    END IF;
    
    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP_RECAL_ADJUST;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_RECAL_ADJUST;
      OS_MESSAGE := '计算调整结果明细-'|| S_STEP || '(报表结果ID:' || TO_CHAR(IN_RPT_RESULT_ID) || '):' || SQLERRM;
  END P_RECAL_ADJUST;
  
  -----------------------------------------------------------------------------
  --  报表审核                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_CHECK_RPT(
    IN_RPT_RESULT_ID          IN  NUMBER   --报表结果ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )
  IS
    S_RPT_STATUS VARCHAR2(32);
  BEGIN
    OS_MESSAGE := 'OK';
    
    --检查状态并锁定
    BEGIN
      SELECT
        RPT_STATUS
      INTO
        S_RPT_STATUS
      FROM
        T_BD_RPT_RESULT
      WHERE
        RPT_RESULT_ID = IN_RPT_RESULT_ID
      FOR UPDATE NOWAIT;
      IF S_RPT_STATUS = 'CHECKED' THEN
        OS_MESSAGE := '当前报表已审核，不能重复审核。';
      ELSIF S_RPT_STATUS = 'RECAL' THEN
        OS_MESSAGE := '当前报表需重算完成后才能审核。';
      END IF;
    EXCEPTION
      WHEN TIMEOUT_ON_RESOURCE THEN
        OS_MESSAGE := '锁定报表不成功！请稍后再试。';
    END;
    
    --更新审核信息
    IF OS_MESSAGE = 'OK' THEN
      UPDATE
        T_BD_RPT_RESULT
      SET
        RPT_STATUS = 'CHECKED'
        ,CHECK_BY = IS_USER_ACCOUNT
        ,CHECK_DATE = TRUNC(SYSDATE)
        ,LAST_UPDATED_BY = IS_USER_ACCOUNT
        ,LAST_UPDATE_DATE = SYSDATE
      WHERE
        RPT_RESULT_ID = IN_RPT_RESULT_ID;
    END IF;
    
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '报表审核:' || SQLERRM;
  END P_CHECK_RPT;

  -----------------------------------------------------------------------------
  --  取消报表审核                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_UNCHECK_RPT(
    IN_RPT_RESULT_ID          IN  NUMBER   --报表结果ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )
  IS
    S_RPT_STATUS VARCHAR2(32);
  BEGIN
    OS_MESSAGE := 'OK';
    
    --检查状态并锁定
    BEGIN
      SELECT
        RPT_STATUS
      INTO
        S_RPT_STATUS
      FROM
        T_BD_RPT_RESULT
      WHERE
        RPT_RESULT_ID = IN_RPT_RESULT_ID
      FOR UPDATE NOWAIT;
      IF S_RPT_STATUS <> 'CHECKED' THEN
        OS_MESSAGE := '当前报表未审核，不能取消审核。';
      END IF;
    EXCEPTION
      WHEN TIMEOUT_ON_RESOURCE THEN
        OS_MESSAGE := '锁定报表不成功！请稍后再试。';
    END;
    
    --更新审核信息
    IF OS_MESSAGE = 'OK' THEN
      UPDATE
        T_BD_RPT_RESULT
      SET
        RPT_STATUS = 'ENTER'
        ,CHECK_BY = NULL
        ,CHECK_DATE = NULL
        ,LAST_UPDATED_BY = IS_USER_ACCOUNT
        ,LAST_UPDATE_DATE = SYSDATE
      WHERE
        RPT_RESULT_ID = IN_RPT_RESULT_ID;
    END IF;
    
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '报表取消审核:' || SQLERRM;
  END P_UNCHECK_RPT;

  -----------------------------------------------------------------------------
  --      根据公式写报表结果，内部调用                                 --
  --处理逻辑：
  --1、循环取出报表中的营销中心、客户业态类型
  --1.1、循环取出营销中心、客户业态类型的报表内容，作为参数传入公式中，按公式处理数据更新
  -----------------------------------------------------------------------------
  PROCEDURE P_SET_SUM_RPT_EXP_VAL(
    IN_RPT_SUM_ID             IN  NUMBER   --汇总报表结果ID
    ,IN_RPT_DEFINE_ITEM_ID    IN  NUMBER   --报表定义行ID
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,IS_EXPRESSION            IN  VARCHAR2 --取数公式
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --操作用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --检查信息
  )
  IS
    S_UPDATE_SQL VARCHAR2(4000);
    N_CUR NUMBER;
    N_ROW NUMBER;
    S_PARAM_NAME VARCHAR2(40);
    S_STEP VARCHAR2(100);
    S_EXP_CURR_SUM VARCHAR2(1000); --对应RPT_ITEM_CURR_SUM的公式
    S_EXP_CURR_VAL VARCHAR2(1000); --对应RPT_ITEM_CURR_VAL的公式
    S_EXP_PRIOR_SUM VARCHAR2(1000); --对应RPT_ITEM_PRIOR_SUM的公式
    S_EXP_PRIOR_VAL VARCHAR2(1000); --对应RPT_ITEM_PRIOR_VAL的公式
    S_EXP_ADJUST_VAL VARCHAR2(1000); --对应ADJUST_VAL的公式
    S_EXP_SUM_ADJUST VARCHAR2(1000); --对应CURR_SUM_ADJUST的公式
    S_EXP_VAL_ADJUST VARCHAR2(1000); --对应CURR_VAL_ADJUST的公式
    S_PARAM_CURR_SUM VARCHAR2(40); --对应RPT_ITEM_CURR_SUM的参数
    S_PARAM_CURR_VAL VARCHAR2(40); --对应RPT_ITEM_CURR_VAL的参数
    S_PARAM_PRIOR_SUM VARCHAR2(40); --对应RPT_ITEM_PRIOR_SUM的参数
    S_PARAM_PRIOR_VAL VARCHAR2(40); --对应RPT_ITEM_PRIOR_VAL的参数
    S_PARAM_ADJUST_VAL VARCHAR2(40); --对应ADJUST_VAL的参数
    S_PARAM_SUM_ADJUST VARCHAR2(40); --对应CURR_SUM_ADJUST的参数
    S_PARAM_VAL_ADJUST VARCHAR2(40); --对应CURR_VAL_ADJUST的参数
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP_SET_RPT_EXPRESSION_VAL;
    --分别对不同的字段对应不同的公式
    S_EXP_CURR_SUM := REPLACE(IS_EXPRESSION,':',':CS');
    S_EXP_CURR_VAL := REPLACE(IS_EXPRESSION,':',':CV');
    S_EXP_PRIOR_SUM := REPLACE(IS_EXPRESSION,':',':PS');
    S_EXP_PRIOR_VAL := REPLACE(IS_EXPRESSION,':',':PV');
    S_EXP_ADJUST_VAL := REPLACE(IS_EXPRESSION,':',':AV');
    S_EXP_SUM_ADJUST := REPLACE(IS_EXPRESSION,':',':SA');
    S_EXP_VAL_ADJUST := REPLACE(IS_EXPRESSION,':',':VA');
    
    --拼接更新数据的SQL
    S_UPDATE_SQL := 'UPDATE T_BD_RPT_SUM_DETAIL SET RPT_ITEM_CURR_SUM=' || S_EXP_CURR_SUM
      || ',RPT_ITEM_CURR_VAL=' || S_EXP_CURR_VAL
      || ',RPT_ITEM_PRIOR_SUM=' || S_EXP_PRIOR_SUM
      || ',RPT_ITEM_PRIOR_VAL=' || S_EXP_PRIOR_VAL
      || ',ADJUST_VAL=' || S_EXP_ADJUST_VAL
      || ',CURR_SUM_ADJUST=' || S_EXP_SUM_ADJUST
      || ',CURR_VAL_ADJUST=' || S_EXP_VAL_ADJUST
      || ' WHERE RPT_SUM_ID=:P_RPT_SUM_ID'
      || ' AND RPT_DEFINE_ITEM_ID=:P_RPT_DEFINE_ITEM_ID'
      || ' AND (SALES_CENTER_CODE IS NULL OR SALES_CENTER_CODE=:P_SALES_CENTER_CODE)'
      || ' AND (INDUSTRY_TYPE IS NULL OR INDUSTRY_TYPE=:P_INDUSTRY_TYPE)';
    
    --打开光标
    N_CUR := DBMS_SQL.OPEN_CURSOR;
    --解析动态SQL语句
    DBMS_SQL.PARSE(N_CUR, S_UPDATE_SQL, DBMS_SQL.NATIVE);
    --按分组字段循环，分别取出对应的报表数据
    FOR R_GROUP IN
    (
      SELECT DISTINCT
        SALES_CENTER_CODE
        ,INDUSTRY_TYPE
      FROM
        T_BD_RPT_SUM_DETAIL
      WHERE
        RPT_SUM_ID = IN_RPT_SUM_ID
        AND RPT_DEFINE_ITEM_ID = IN_RPT_DEFINE_ITEM_ID
    )
    LOOP
      S_STEP := '中心编码:' || R_GROUP.SALES_CENTER_CODE || ';业态类型:' || R_GROUP.INDUSTRY_TYPE;
      --循环获取公式中使用的编码，作为参数绑定到SQL
      FOR R_DETAIL IN
      (
        SELECT
          RPT_ITEM_CODE
          ,NVL(RPT_ITEM_CURR_SUM,0) RPT_ITEM_CURR_SUM
          ,NVL(RPT_ITEM_CURR_VAL,0) RPT_ITEM_CURR_VAL
          ,NVL(RPT_ITEM_PRIOR_SUM,0) RPT_ITEM_PRIOR_SUM
          ,NVL(RPT_ITEM_PRIOR_VAL,0) RPT_ITEM_PRIOR_VAL
          ,NVL(ADJUST_VAL,0) ADJUST_VAL
          ,NVL(CURR_SUM_ADJUST,0) CURR_SUM_ADJUST
          ,NVL(CURR_VAL_ADJUST,0) CURR_VAL_ADJUST
        FROM
          T_BD_RPT_SUM_DETAIL
        WHERE
          RPT_SUM_ID = IN_RPT_SUM_ID
          AND
          (
            SALES_CENTER_CODE IS NULL
            OR SALES_CENTER_CODE = R_GROUP.SALES_CENTER_CODE
          )
          AND
          (
            INDUSTRY_TYPE IS NULL
            OR INDUSTRY_TYPE = R_GROUP.INDUSTRY_TYPE
          )
      )
      LOOP
        S_PARAM_NAME := ':' || R_DETAIL.RPT_ITEM_CODE; 
        IF INSTR(IS_EXPRESSION, S_PARAM_NAME, 1, 1) > 0 THEN
          --公式存在对应的编码则作为参数
          S_PARAM_CURR_SUM := ':CS' || R_DETAIL.RPT_ITEM_CODE;
          S_PARAM_CURR_VAL := ':CV' || R_DETAIL.RPT_ITEM_CODE;
          S_PARAM_PRIOR_SUM := ':PS' || R_DETAIL.RPT_ITEM_CODE;
          S_PARAM_PRIOR_VAL := ':PV' || R_DETAIL.RPT_ITEM_CODE;
          S_PARAM_ADJUST_VAL := ':AV' || R_DETAIL.RPT_ITEM_CODE;
          S_PARAM_SUM_ADJUST := ':SA' || R_DETAIL.RPT_ITEM_CODE;
          S_PARAM_VAL_ADJUST := ':VA' || R_DETAIL.RPT_ITEM_CODE;
          
          --绑定输入参数
          DBMS_SQL.BIND_VARIABLE(N_CUR, S_PARAM_CURR_SUM, R_DETAIL.RPT_ITEM_CURR_SUM);
          DBMS_SQL.BIND_VARIABLE(N_CUR, S_PARAM_CURR_VAL, R_DETAIL.RPT_ITEM_CURR_VAL);
          DBMS_SQL.BIND_VARIABLE(N_CUR, S_PARAM_PRIOR_SUM, R_DETAIL.RPT_ITEM_PRIOR_SUM);
          DBMS_SQL.BIND_VARIABLE(N_CUR, S_PARAM_PRIOR_VAL, R_DETAIL.RPT_ITEM_PRIOR_VAL);
          DBMS_SQL.BIND_VARIABLE(N_CUR, S_PARAM_ADJUST_VAL, R_DETAIL.ADJUST_VAL);
          DBMS_SQL.BIND_VARIABLE(N_CUR, S_PARAM_SUM_ADJUST, R_DETAIL.CURR_SUM_ADJUST);
          DBMS_SQL.BIND_VARIABLE(N_CUR, S_PARAM_VAL_ADJUST, R_DETAIL.CURR_VAL_ADJUST);
        END IF;
      END LOOP;
      --绑定指定参数
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_RPT_SUM_ID', IN_RPT_SUM_ID);
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_RPT_DEFINE_ITEM_ID', IN_RPT_DEFINE_ITEM_ID);
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_SALES_CENTER_CODE', R_GROUP.SALES_CENTER_CODE);
      DBMS_SQL.BIND_VARIABLE(N_CUR, ':P_INDUSTRY_TYPE', R_GROUP.INDUSTRY_TYPE);

      --执行SQL
      N_ROW := DBMS_SQL.EXECUTE(N_CUR);
    END LOOP;
    
    --关闭光标
    DBMS_SQL.CLOSE_CURSOR(N_CUR);

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_SET_RPT_EXPRESSION_VAL;
      OS_MESSAGE := '设置汇总公式值-公式(' || IS_EXPRESSION || ')' || S_STEP || ':' || SQLERRM;
  END P_SET_SUM_RPT_EXP_VAL;

  -----------------------------------------------------------------------------
  --  汇总竖放报表，写到中间表中，返回报表ID，从T_BD_RPT_SUM_DETAIL获取对应的报表结果 --
  --处理逻辑：
  --1、按参数指定的分组方法汇总明细报表计算结果的内容，写入汇总报表中。
  --2、更新调整后字段值。
  --3、按优先级循环取出公式，重算公式值。
  --注意：由于公式可能存在乘、除法等，故不能直接汇总明细表的数据，需重新使用公式计算对应的公式值。
  -----------------------------------------------------------------------------
  PROCEDURE P_SUM_RPT_DETAIL(
    IN_RPT_DEFINE_ID          IN  NUMBER   --报表定义ID
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,IN_RPT_PERIOD_ID         IN  NUMBER   --报表周期ID
    ,IN_SALES_CENTER_ID       IN  NUMBER   --营销中心ID
    ,IS_GROUP_BY              IN  VARCHAR2 --分组汇总字段（不需写别名）              
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,ON_SUM_RPT_ID            OUT NUMBER   --成功则返回汇总报表ID，否则返回-1
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )
  IS
    N_RPT_RESULT_ID NUMBER;
    S_SQL VARCHAR2(4000);
    N_CUR NUMBER;
    N_ROW NUMBER;
    S_STEP VARCHAR2(100);
  BEGIN
    OS_MESSAGE := 'OK';
    --根据报表定义ID、周期获取报表ID
    BEGIN
      SELECT
        RPT_RESULT_ID
      INTO
        N_RPT_RESULT_ID
      FROM
        T_BD_RPT_RESULT
      WHERE
        RPT_DEFINE_ID = IN_RPT_DEFINE_ID
        AND RPT_PERIOD_ID = IN_RPT_PERIOD_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        ON_SUM_RPT_ID := -1;
        OS_MESSAGE := '根据报表定义、周期没有找到对应的报表统计结果（报表定义ID：' || TO_CHAR(IN_RPT_DEFINE_ID) || '；周期ID：' || TO_CHAR(IN_RPT_PERIOD_ID) || '）';
    END;
    
    --获取汇总报表ID
    S_STEP := '获取汇总报表ID';
    IF OS_MESSAGE = 'OK' THEN
      SELECT
        S_BD_RPT_SUM.NEXTVAL
      INTO
        ON_SUM_RPT_ID
      FROM
        DUAL;
    END IF;
    
    --删除100个以前生成的报表
    S_STEP := '删除历史报表';
    DELETE FROM
      T_BD_RPT_SUM_DETAIL
    WHERE
      RPT_SUM_ID <= ON_SUM_RPT_ID-100;

    --拼接汇总SQL
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '插入汇总数据';
      S_SQL := 'INSERT INTO T_BD_RPT_SUM_DETAIL(RPT_DEFINE_ITEM_ID,RPT_SUM_ID,' || IS_GROUP_BY
        || ',RPT_ITEM_CODE,RPT_ITEM_NAME,RPT_ITEM_TYPE,RPT_ITEM_CURR_SUM'
        || ',RPT_ITEM_CURR_VAL,RPT_ITEM_PRIOR_SUM,RPT_ITEM_PRIOR_VAL,ADJUST_VAL)'
        || ' SELECT RPT_DEFINE_ITEM_ID,' || TO_CHAR(ON_SUM_RPT_ID) || ',' || IS_GROUP_BY
        || ',RPT_ITEM_CODE,RPT_ITEM_NAME,RPT_ITEM_TYPE,SUM(RPT_ITEM_CURR_SUM)'
        || ',SUM(RPT_ITEM_CURR_VAL),SUM(RPT_ITEM_PRIOR_SUM),SUM(RPT_ITEM_PRIOR_VAL),SUM(ADJUST_VAL)'
        || ' FROM CIMS.T_BD_RPT_RESULT_DETAIL D'
        || ' WHERE RPT_RESULT_ID=' || TO_CHAR(N_RPT_RESULT_ID)
        || ' AND D.SALES_CENTER_ID = NVL(''' || TO_CHAR(IN_SALES_CENTER_ID) || ''',D.SALES_CENTER_ID)'
        || ' AND EXISTS (SELECT 1 FROM V_BD_USER_CUST_PRIV CP'
        || '   WHERE CP.ENTITY_ID = ' || TO_CHAR(IN_ENTITY_ID)
        || '   AND CP.SALES_CENTER_ID = D.SALES_CENTER_ID'
        || '   AND CP.CUSTOMER_ID = D.CUSTOMER_ID'
        || '   AND CP.USER_CODE = ''' || IS_USER_ACCOUNT || ''')'
        || ' GROUP BY RPT_DEFINE_ITEM_ID,' || IS_GROUP_BY
        || ',RPT_ITEM_CODE,RPT_ITEM_NAME,RPT_ITEM_TYPE';

      --执行汇总SQL
      --打开光标
      N_CUR := DBMS_SQL.OPEN_CURSOR;
      --解析动态SQL语句
      DBMS_SQL.PARSE(N_CUR, S_SQL, DBMS_SQL.NATIVE);
      --执行语句
      N_ROW := DBMS_SQL.EXECUTE(N_CUR);
      --关闭光标
      DBMS_SQL.CLOSE_CURSOR(N_CUR);
    END IF;
    
    --更新调整后字段
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '更新调整后字段';
      UPDATE
        T_BD_RPT_SUM_DETAIL
      SET
        CURR_SUM_ADJUST = NVL(RPT_ITEM_CURR_SUM,0)+NVL(ADJUST_VAL,0)
        ,CURR_VAL_ADJUST = NVL(RPT_ITEM_CURR_VAL,0)+NVL(ADJUST_VAL,0)
      WHERE
        RPT_SUM_ID = ON_SUM_RPT_ID;
    END IF;
      
    --对于公式项，则重新按公式计算
    IF OS_MESSAGE = 'OK' THEN
      --循环取出公式
      FOR R_DEFINE_ITEM IN
      (
        SELECT
          PRIORITY_LEVEL
          ,RPT_DEFINE_ITEM_ID
          ,GET_VAL_EXPRESSION
        FROM
          T_BD_RPT_DEFINE_ITEM
        WHERE
          RPT_DEFINE_ID = IN_RPT_DEFINE_ID
          AND RPT_ITEM_TYPE = 'EXPRESSION'
        ORDER BY
          PRIORITY_LEVEL
          ,RPT_ITEM_CODE
      )
      LOOP
        S_STEP := '公式取值(' || R_DEFINE_ITEM.GET_VAL_EXPRESSION || ')';
        --对于公式则循环报表值，按报表编码更新到公式中,再通过动态SQL获取公式对应的值，并记录报表值
        P_SET_SUM_RPT_EXP_VAL(
          ON_SUM_RPT_ID          --报表汇总结果ID
          ,R_DEFINE_ITEM.RPT_DEFINE_ITEM_ID    --报表定义行ID
          ,IN_ENTITY_ID             --主体ID
          ,R_DEFINE_ITEM.GET_VAL_EXPRESSION            --取数公式
          ,IS_USER_ACCOUNT          --操作用户账号
          ,OS_MESSAGE               --检查信息
        );
        
        --更新不成功则退出
        EXIT WHEN OS_MESSAGE <> 'OK';
        
      END LOOP;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      ON_SUM_RPT_ID := -1;
      OS_MESSAGE := '汇总报表-' || S_STEP || ':' || SQLERRM;
  END P_SUM_RPT_DETAIL;

  -----------------------------------------------------------------------------
  --      将公式转换成横放表字段的SQL公式                                 --
  -----------------------------------------------------------------------------
  FUNCTION P_GET_TRAVERSE_EXP(
    IN_RPT_DEFINE_ID          IN  NUMBER   --报表定义ID
    ,IS_EXPRESSION            IN  VARCHAR2 --取数公式
    ,IS_NOT_NVL_FILED         IN  VARCHAR2 --不使用NVL的字段名
  )
  RETURN VARCHAR2  --返回SQL格式的处理更新公式
  IS
    N_INDEX NUMBER;
    S_FIELD VARCHAR2(30);
    S_RESULT VARCHAR2(1000);
  BEGIN
    S_RESULT := IS_EXPRESSION;
    --循环报表项目，更新公式字段
    N_INDEX := 1;
    FOR R_DEFINE_ITEM IN
    (
      SELECT
        RPT_ITEM_CODE
      FROM
        T_BD_RPT_DEFINE_ITEM
      WHERE
        RPT_DEFINE_ID = IN_RPT_DEFINE_ID
      ORDER BY
        RPT_ITEM_CODE
    )
    LOOP
       --转换成横放表字段
       IF R_DEFINE_ITEM.RPT_ITEM_CODE = IS_NOT_NVL_FILED THEN
         S_FIELD := 'VALUE' || LPAD(N_INDEX,2,'0'); 
       ELSE
         S_FIELD := 'NVL(VALUE' || LPAD(N_INDEX,2,'0') || ',0)';
       END IF;
       S_RESULT := REPLACE(S_RESULT,':'||R_DEFINE_ITEM.RPT_ITEM_CODE,S_FIELD);
       N_INDEX := N_INDEX+1;
    END LOOP;
    RETURN S_RESULT;
  END P_GET_TRAVERSE_EXP;
  -----------------------------------------------------------------------------
  --  汇总横放报表，写到中间表中，返回报表ID，从T_BD_RPT_SUM_TRAVERSE获取对应的报表结果 --
  --处理逻辑：
  --1、按参数指定的分组方法汇总明细报表计算结果的内容，写入横放汇总报表中。
  --2、按优先级循环取出公式，重算公式值。
  --注意：由于公式可能存在乘、除法等，故不能直接汇总明细表的数据，需重新使用公式计算对应的公式值。
  -----------------------------------------------------------------------------
  PROCEDURE P_SUM_RPT_TRAVERSE(
    IN_RPT_DEFINE_ID          IN  NUMBER   --报表定义ID
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,IN_RPT_PERIOD_ID         IN  NUMBER   --报表周期ID
    ,IN_SALES_CENTER_ID       IN  NUMBER   --营销中心ID
    ,IS_GROUP_BY              IN  VARCHAR2 --分组汇总字段（不需写别名）              
    ,IS_STAT_WAY              IN  VARCHAR2 --统计方式，SUM:累计；CUR:当前，空值则两个都取            
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,ON_SUM_RPT_ID            OUT NUMBER   --成功则返回汇总报表ID，否则返回-1
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )
  IS
    N_RPT_RESULT_ID NUMBER;
    S_SQL VARCHAR2(4000);
    S_EXPRESSION VARCHAR2(1000);
    N_CUR NUMBER;
    N_ROW NUMBER;
    S_STEP VARCHAR2(100);
  BEGIN
    OS_MESSAGE := 'OK';
    --根据报表定义ID、周期获取报表ID
    BEGIN
      SELECT
        RPT_RESULT_ID
      INTO
        N_RPT_RESULT_ID
      FROM
        T_BD_RPT_RESULT
      WHERE
        RPT_DEFINE_ID = IN_RPT_DEFINE_ID
        AND RPT_PERIOD_ID = IN_RPT_PERIOD_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        ON_SUM_RPT_ID := -1;
        OS_MESSAGE := '根据报表定义、周期没有找到对应的报表统计结果（报表定义ID：' || TO_CHAR(IN_RPT_DEFINE_ID) || '；周期ID：' || TO_CHAR(IN_RPT_PERIOD_ID) || '）';
    END;
    
    --获取汇总报表ID
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '获取汇总报表ID';
      SELECT
        S_BD_RPT_SUM.NEXTVAL
      INTO
        ON_SUM_RPT_ID
      FROM
        DUAL;
    END IF;
    
    --删除100个以前生成的报表
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '删除历史报表';
      DELETE FROM
        T_BD_RPT_SUM_TRAVERSE
      WHERE
        RPT_SUM_ID <= ON_SUM_RPT_ID-100;
    END IF;

    --插入汇总报表
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '插入汇总报表';
      --拼接汇总SQL
      S_SQL := 'INSERT INTO T_BD_RPT_SUM_TRAVERSE(RPT_SUM_ID,STAT_WAY,' || IS_GROUP_BY
        || ',VALUE01,VALUE02,VALUE03,VALUE04,VALUE05,VALUE06,VALUE07,VALUE08,VALUE09,VALUE10'
        || ',VALUE11,VALUE12,VALUE13,VALUE14,VALUE15,VALUE16,VALUE17,VALUE18,VALUE19,VALUE20'
        || ',VALUE21,VALUE22,VALUE23,VALUE24,VALUE25,VALUE26,VALUE27,VALUE28,VALUE29,VALUE30'
        || ',VALUE31,VALUE32,VALUE33,VALUE34,VALUE35,VALUE36,VALUE37,VALUE38,VALUE39,VALUE40'
        || ',VALUE41,VALUE42,VALUE43,VALUE44,VALUE45,VALUE46,VALUE47,VALUE48,VALUE49,VALUE50'
        || ',VALUE51,VALUE52,VALUE53,VALUE54,VALUE55,VALUE56,VALUE57,VALUE58,VALUE59,VALUE60)'
        || ' SELECT ' || TO_CHAR(ON_SUM_RPT_ID) || ',STAT_WAY,' || IS_GROUP_BY
        || ',SUM(VALUE01),SUM(VALUE02),SUM(VALUE03),SUM(VALUE04),SUM(VALUE05),SUM(VALUE06),SUM(VALUE07),SUM(VALUE08),SUM(VALUE09),SUM(VALUE10)'
        || ',SUM(VALUE11),SUM(VALUE12),SUM(VALUE13),SUM(VALUE14),SUM(VALUE15),SUM(VALUE16),SUM(VALUE17),SUM(VALUE18),SUM(VALUE19),SUM(VALUE20)'
        || ',SUM(VALUE21),SUM(VALUE22),SUM(VALUE23),SUM(VALUE24),SUM(VALUE25),SUM(VALUE26),SUM(VALUE27),SUM(VALUE28),SUM(VALUE29),SUM(VALUE30)'
        || ',SUM(VALUE31),SUM(VALUE32),SUM(VALUE33),SUM(VALUE34),SUM(VALUE35),SUM(VALUE36),SUM(VALUE37),SUM(VALUE38),SUM(VALUE39),SUM(VALUE40)'
        || ',SUM(VALUE41),SUM(VALUE42),SUM(VALUE43),SUM(VALUE44),SUM(VALUE45),SUM(VALUE46),SUM(VALUE47),SUM(VALUE48),SUM(VALUE49),SUM(VALUE50)'
        || ',SUM(VALUE51),SUM(VALUE52),SUM(VALUE53),SUM(VALUE54),SUM(VALUE55),SUM(VALUE56),SUM(VALUE57),SUM(VALUE58),SUM(VALUE59),SUM(VALUE60)'
        || ' FROM CIMS.T_BD_RPT_DETAIL_TRAVERSE T'
        || ' WHERE RPT_RESULT_ID=' || TO_CHAR(N_RPT_RESULT_ID)
        || ' AND T.SALES_CENTER_ID = NVL(''' || TO_CHAR(IN_SALES_CENTER_ID) || ''',T.SALES_CENTER_ID)'
        || ' AND T.STAT_WAY=NVL(''' || IS_STAT_WAY || ''',T.STAT_WAY)'
        || ' AND EXISTS (SELECT 1 FROM V_BD_USER_CUST_PRIV CP'
        || '   WHERE CP.ENTITY_ID = ' || TO_CHAR(IN_ENTITY_ID)
        || '   AND CP.SALES_CENTER_ID = T.SALES_CENTER_ID'
        || '   AND CP.CUSTOMER_ID = T.CUSTOMER_ID'
        || '   AND CP.USER_CODE = ''' || IS_USER_ACCOUNT || ''')'
        || ' GROUP BY STAT_WAY,' || IS_GROUP_BY;

      --执行汇总SQL
      --打开光标
      N_CUR := DBMS_SQL.OPEN_CURSOR;
      --解析动态SQL语句
      DBMS_SQL.PARSE(N_CUR, S_SQL, DBMS_SQL.NATIVE);
      --执行语句
      N_ROW := DBMS_SQL.EXECUTE(N_CUR);
      --关闭光标
      DBMS_SQL.CLOSE_CURSOR(N_CUR);
    END IF;
    
    --对于公式项，则重新按公式计算
    --循环取出公式，由于公式存在嵌套，需逐个执行
    IF OS_MESSAGE = 'OK' THEN
      FOR R_DEFINE_ITEM IN
      (
        SELECT
          PRIORITY_LEVEL
          ,RPT_ITEM_CODE
          ,RPT_DEFINE_ITEM_ID
          ,GET_VAL_EXPRESSION
        FROM
          T_BD_RPT_DEFINE_ITEM
        WHERE
          RPT_DEFINE_ID = IN_RPT_DEFINE_ID
          AND RPT_ITEM_TYPE = 'EXPRESSION'
        ORDER BY
          PRIORITY_LEVEL
          ,RPT_ITEM_CODE
      )
      LOOP
        S_STEP := '公式取值(' || R_DEFINE_ITEM.GET_VAL_EXPRESSION || ')';
        
        --拼接更新SQL
        S_EXPRESSION := ':' || R_DEFINE_ITEM.RPT_ITEM_CODE || '=' || R_DEFINE_ITEM.GET_VAL_EXPRESSION;
        S_SQL := 'UPDATE T_BD_RPT_SUM_TRAVERSE SET ' || P_GET_TRAVERSE_EXP(IN_RPT_DEFINE_ID,S_EXPRESSION,R_DEFINE_ITEM.RPT_ITEM_CODE)
          || ' WHERE RPT_SUM_ID=' || TO_CHAR(ON_SUM_RPT_ID);
        
        --执行更新SQL
        --打开光标
        N_CUR := DBMS_SQL.OPEN_CURSOR;
        --解析动态SQL语句
        DBMS_SQL.PARSE(N_CUR, S_SQL, DBMS_SQL.NATIVE);
        --执行语句
        N_ROW := DBMS_SQL.EXECUTE(N_CUR);
        --关闭光标
        DBMS_SQL.CLOSE_CURSOR(N_CUR);
        
      END LOOP;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      IF N_CUR <> 0 THEN
        DBMS_SQL.CLOSE_CURSOR(N_CUR);
      END IF;
      ON_SUM_RPT_ID := -1;
      OS_MESSAGE := '汇总报表-' || S_STEP || ':' || SQLERRM;
  END P_SUM_RPT_TRAVERSE;

END PKG_RPT;
/

