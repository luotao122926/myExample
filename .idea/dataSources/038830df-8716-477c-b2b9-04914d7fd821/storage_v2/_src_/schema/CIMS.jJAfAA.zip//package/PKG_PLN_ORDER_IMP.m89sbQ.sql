create PACKAGE PKG_PLN_ORDER_IMP AS
  ------------------------------------------------------------------------------------------------
  --                                                                                            --
  --  计划订单导入后台包                                                                        --
  --                                                                                            --
  --                                                                 --
  ------------------------------------------------------------------------------------------------
  /*
  2015-1-12 梁学荣
  创建计划订单导入后台包后台包。
  导入表：T_PLN_ORDER_SHIP_IMPORT
  发货计划匹配表：T_PLN_ORDER_SHIP_MATCH
  发货计划表：T_PLN_ORDER_SHARE_SHIPMENT
  批次表：T_PLN_ORDER_SHIP_IMP_BAT STATUS(CREATED:创建  MATCHED:已匹配  AFFIRMED:已确认)
  2015-3-23 梁学荣
  修改P_AFFIRM_ORDER_SHIP
  增加参数OI_BATCH_ID（OUTPUT），用于计划模块的JAVA程序调用
  */

  -----------------------------------------------------------------------------
  --      匹配订单                                             --
  -----------------------------------------------------------------------------
  PROCEDURE P_MATCH_ORDER_SHIP(
    IN_BATCH_ID               IN  NUMBER   --批次ID
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -----------------------------------------------------------------------------
  --  确认发货计划                                                     --
  --  更新发货计划内容，并通过调用发货计划下达过程，生成T_LG_SHIP_PLAN对应内容
  -----------------------------------------------------------------------------
  PROCEDURE P_AFFIRM_ORDER_SHIP(
    IN_BATCH_ID               IN  NUMBER   --批次ID
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OI_BATCH_ID              OUT NUMBER   --输出批次ID
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -----------------------------------------------------------------------------
  --  清理导入批次信息，每天调用，删除7天前的批次信息                        --
  -----------------------------------------------------------------------------
  PROCEDURE P_CLEAR_PLN_SHIP_BATCH;

END PKG_PLN_ORDER_IMP;
/

