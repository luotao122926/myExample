create Package      PKG_INV_INVENTORY AS

       TYPE c_cursor IS REF CURSOR;

      Procedure INVENTORY_QTY(p_entityId            in number,
                              invertory_id          in  number,
                              info_date             in  Date,
                               v_exception          out varchar2
                        --v_get out  c_cursor
                        --v_qty_lm        out number
                       );
       Procedure INVENTORY_QTY_CHECK(inv_code        in varchar2,
                                     info_date       in Date,
                                     v_exception     out varchar2,
                                     p_entity_id       in number,
                                     p_user_code       in varchar2
                        );
       Procedure INVENTORY_REPORT_SPLIT(p_user         in varchar2,
                                        p_report_num   in varchar2,
                                        p_entity_id  in number,
                                        p_exception  out varchar
                                        );
       Procedure INVENTORY_SPLIT_INSERT_TEMP(p_entityId     in number,
                                             p_report_num   in varchar2,
                                             P_INVENTORY_ID IN NUMBER,
                                             P_INFO_DATE    IN DATE,
                                             P_exception    OUT VARCHAR2
                                             );
       Procedure INVENTORY_CHANGE_DIFF(S_CHECK_INFO_NUM_SUM IN VARCHAR2);

End PKG_INV_INVENTORY;
/

