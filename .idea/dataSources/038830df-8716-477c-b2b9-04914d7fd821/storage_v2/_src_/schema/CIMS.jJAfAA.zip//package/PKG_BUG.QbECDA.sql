create PACKAGE      PKG_BUG IS
  /*----------------------------------------------------------------
  *         包：PKG_SO_BIZ
  *   创建日期：2014-07-05
  *     创建者：廖丽章
  *   功能说明：1、根据发货确认、差异签收、备货转销售等生成销售单据数据到接口表；
  *             2、根据销售单据头接口表与销售单据行接口表数据，生成各种类型销售单据（财务单）。
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  */ ----------------------------------------------------------------

  --定义REF CURSOR类型
  --TYPE REFCURSOR_SO_DATA IS REF CURSOR;

  --定义销售单据类型记录集
  TYPE SO_BILL_TYPE IS RECORD(
    BILL_TYPE_ID     V_SO_BILL_TYPE.BILL_TYPE_ID%TYPE, --单据类型ID
    BILL_TYPE_CODE   V_SO_BILL_TYPE.BILL_TYPE_CODE%TYPE, --单据类型编码
    BILL_TYPE_NAME   V_SO_BILL_TYPE.BILL_TYPE_NAME%TYPE, --单据类型名称
    SRC_TYPE_ID      V_SO_BILL_TYPE.SRC_TYPE_ID%TYPE, --业务单据源类型ID
    SRC_TYPE_CODE    V_SO_BILL_TYPE.SRC_TYPE_CODE%TYPE, --业务单据源类型编码
    SRC_TYPE_NAME    V_SO_BILL_TYPE.SRC_TYPE_NAME%TYPE, --业务单据源类型名称
    SETTLE_TYPE_CODE V_SO_BILL_TYPE.SETTLE_TYPE_CODE%TYPE, --结算类型编码
    SETTLE_TYPE_NAME V_SO_BILL_TYPE.SETTLE_TYPE_NAME%TYPE --结算类型名称
    );

  --定义客户、账户信息记录集
  TYPE ACCOUNT_INFO IS RECORD(
    ACCOUNT_ID        T_CUSTOMER_ACCOUNT.ACCOUNT_ID%TYPE, --账户ID
    ACCOUNT_CODE      T_CUSTOMER_ACCOUNT.ACCOUNT_CODE%TYPE, --账户编码
    ACCOUNT_NAME      T_CUSTOMER_ACCOUNT.ACCOUNT_NAME%TYPE, --账户名称
    CUSTOMER_ID       T_CUSTOMER_HEADER.CUSTOMER_ID%TYPE, --客户ID
    CUSTOMER_CODE     T_CUSTOMER_HEADER.CUSTOMER_CODE%TYPE, --客户代码
    CUSTOMER_NAME     T_CUSTOMER_HEADER.CUSTOMER_NAME%TYPE, --客户名称
    SALES_CENTER_ID   T_CUSTOMER_ORG.SALES_CENTER_ID%TYPE, --销售中心ID
    SALES_CENTER_CODE T_CUSTOMER_ORG.SALES_CENTER_CODE%TYPE, --销售中心编码
    SALES_CENTER_NAME T_CUSTOMER_ORG.SALES_CENTER_NAME%TYPE, --销售中心名称
    ADDRESS_ID        T_CUSTOMER_ADDRESS.ADDRESS_ID%TYPE, --客户账户地址ID
    ADDRESS           T_CUSTOMER_ADDRESS.ADDRESS%TYPE, --客户账户地址
    PROVINCE          T_CUSTOMER_ADDRESS.PROVINCE%TYPE, --行政区域省份(省份代码)
    CITY              T_CUSTOMER_ADDRESS.CITY%TYPE, --行政区域地级市(地级市代码)
    AREA              T_CUSTOMER_ADDRESS.AREA%TYPE --行政区域县区(县级市代码)
    );

  --库存处理（库存校验、库存解锁等）所需参数记录集
  TYPE INV_PROC_PARAMS IS RECORD(
    ENTITY_ID          NUMBER, --销售单据头
    INV_ID             NUMBER, --销售单据行
    SRC_TYPE           VARCHAR2(6), --来源类型：01计划订单 02提货订单 03调拨订单 04促销品 09采购单据 10调拨单据 11备货单据
    SRC_BILL_TYPE_ID   NUMBER, --来源单据类型ID（计划订单、提货订单等单据类型）
    SRC_BILL_TYPE_NAME VARCHAR2(200), --来源单据类型名称
    SRC_BILL_ID        NUMBER, --来源单据ID
    SRC_BILL_LINE_ID   NUMBER, --来源行ID（计划订单、提货订单等单据行ID）
    ITEM_ID            T_BD_ITEM.ITEM_ID%TYPE, --产品ID
    ITEM_CODE          T_BD_ITEM.ITEM_CODE%TYPE, --产品编码
    ITEM_NAME          T_BD_ITEM.ITEM_NAME%TYPE, --产品名称
    ITEM_QTY           T_SO_LINE.ITEM_QTY%TYPE --产品数量
    );

  --定义给库存事务的单据数据记录集
  TYPE BILL_DATA_INV IS RECORD(
    BILL_ID        NUMBER, --业务单据头ID
    BILL_NUM       VARCHAR2(100), --业务单据号
    LINE_ID        NUMBER, --业务单据行ID
    LINE_DETAIL_ID NUMBER, --业务单据行明细ID
    ITEM_ID        T_BD_ITEM.ITEM_ID%TYPE, --产品ID
    ITEM_CODE      T_BD_ITEM.ITEM_CODE%TYPE, --产品编码
    ITEM_NAME      T_BD_ITEM.ITEM_NAME%TYPE, --产品名称
    ITEM_UOM       T_BD_ITEM.DEFAULTUNIT%TYPE, --产品单位
    SRC_INV_ID     T_INV_INVENTORIES.INVENTORY_ID%TYPE, --仓库ID（来源仓库）
    ITEM_QTY       NUMBER, --数量
    CREATED_BY     VARCHAR2(32), --操作人
    TARGET_INV_ID  T_INV_INVENTORIES.INVENTORY_ID%TYPE, --目的仓库ID

    SRC_TERMINAL_ENTITY_ID  T_PRO_TERMINAL_ENTITY.TERMINAL_ENTITY_ID%TYPE, --来源门店主体ID add by  GUIBR20150723 样机
    SRC_TERMINAL_CODE       T_PRO_TERMINAL.TERMINAL_CODE%TYPE, --来源门店编码 add by  GUIBR20150723 样机
    SRC_TERMINAL_NAME       T_PRO_TERMINAL.TERMINAL_NAME%TYPE, --来源门店名称 add by  GUIBR20150723 样机
    TARGET_TERMINAL_ENTITY_ID  T_PRO_TERMINAL_ENTITY.TERMINAL_ENTITY_ID%TYPE, --目的门店主体ID add by  GUIBR20150723 样机
    TARGET_TERMINAL_CODE       T_PRO_TERMINAL.TERMINAL_CODE%TYPE, --目的门店编码GUIBR20150723 add by  GUIBR20150723 样机
    TARGET_TERMINAL_NAME       T_PRO_TERMINAL.TERMINAL_NAME%TYPE --目的门店名称GUIBR20150723 add by  GUIBR20150723 样机

    );

  --定义保存给库存事务的单据数据记录集的数组
  TYPE BILL_DATA_INV_ARRAY IS TABLE OF BILL_DATA_INV INDEX BY BINARY_INTEGER;

  PROCEDURE P_SO_GEN(  P_RESULT       IN OUT NUMBER, --返回错误ID
                        P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                        );

  PROCEDURE P_SO_TO_ERP(P_SO_HEADER_ID IN VARCHAR2, --销售单据头ID
                        P_ERP_TRX_CODE IN VARCHAR2, --调用ERP接口代码
                        P_STATUS    IN VARCHAR2,    --接口状态
                        P_RESULT       IN OUT NUMBER, --返回错误ID
                        P_ERR_MSG      IN OUT VARCHAR2 --返回错误信息
                        );

  PROCEDURE P_SO_TO_ERP_CREATE(P_SO_HEADER  IN T_SO_HEADER%ROWTYPE, --销售单头
                               R_OE_HEADERS IN OUT INTF_OE_HEADERS_IFACE_ALL%ROWTYPE,
                               P_TRX_STATUS IN VARCHAR2, --交易状态
                               P_RESULT     IN OUT NUMBER, --返回错误ID
                               P_ERR_MSG    IN OUT VARCHAR2 --返回错误信息
                               );

  FUNCTION F_GET_ACCOUNT_INFO(P_ACCOUNT_ID IN VARCHAR2, --业务单据类型编码
                              P_ENTITY_ID  IN NUMBER --主体ID
                              ) RETURN ACCOUNT_INFO;

END PKG_BUG;
/

