create PACKAGE PKG_INV_ITEM_ONHAND IS
 --包头声明

  v_Nl      Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Null    Constant Varchar2(4) := 'NULL'; --空值
  v_True    Constant Varchar2(2) := 'Y';
  v_False   Constant Varchar2(2) := 'N';
  v_Result  Constant Number := 0; --成功返回
  v_Success Constant Varchar2(10) := 'SUCCESS';
  v_Failure Constant Varchar2(10) := 'FAILURE';
  v_Base_Exception Exception; --自定义异常
  
  ------------------------------------------------------------------------------------------------
  -- Author  : 黄洪彬 2019-12-3
  -- Purpose : 增量冻结仓库产品库存  for ccs。 
  ------------------------------------------------------------------------------------------------
  PROCEDURE P_INCREMENTAL_FREEZE_INV_ITEM(P_ENTITY_ID IN NUMBER,
                                                 P_RESULT    OUT VARCHAR2);
                                     

                                           
END PKG_INV_ITEM_ONHAND;
/

