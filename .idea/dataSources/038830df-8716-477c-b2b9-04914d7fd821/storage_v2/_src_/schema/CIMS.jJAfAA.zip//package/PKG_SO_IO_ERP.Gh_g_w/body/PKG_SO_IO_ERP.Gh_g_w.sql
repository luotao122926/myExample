create Package Body      PKG_SO_IO_ERP Is

  -----------------------------------------------------------------------------
  --  销售跟ERP有 DBLINK 交互方式 的程序包                                                   --
  -----------------------------------------------------------------------------
  
  
  
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-10-19
  --处理内部客户关联交易号更新事物接口
  --------------------------------------------------------------------------
  Procedure P_ENTITY_CUST_TRANSACTION_INTF(
                            IN_ENTITY_ID IN NUMBER,
                              OS_MESSAGE OUT VARCHAR2) --返回值     
    IS     
    S_ERR_MESSAGE VARCHAR2(500);
    N_TRANSACTION_ID NUMBER;
    S_ICP_SEQ_ID VARCHAR2(100);
    N_LOGIST_LINE_ID NUMBER;
    N_REQ_HEADE_ID NUMBER;
  BEGIN
       OS_MESSAGE :='OK';
       FOR 
         TRX_HEADER_ROW 
         IN(
            SELECT 
              SO.SO_NUM
             ,TH.ID TRANSACTION_HEAD_ID
             ,SO.ENTITY_ID
             ,SO.ERP_OU_ID
            FROM 
              T_SO_HEADER SO
            LEFT JOIN INTF_INV_TRANSACTION_HEAD TH ON SO.SO_NUM = TH.ORDER_NUM
            WHERE SO.ENTITY_CUST_FLAG = 'Y' 
            AND TH.ORDER_STEP = 2
            AND TH.OPERSTATUS='N'
            AND TH.STATUS='S'
            AND SO.ERP_LOGIST_RECEIVE_FLAG = 'Y'
            AND SO.ENTITY_ID = IN_ENTITY_ID
        )LOOP
           BEGIN 
               SAVEPOINT SP;
               
               FOR 
                 TRX_LINE_ROW 
                 IN(
                     SELECT 
                         INV.ITEM_NUMBER
                        ,INV.ID LINE_ID
                        ,INV.SOURCE_LINE_ID
                        ,INV_ERP.TRANSACTION_ID
                        ,INV.SOURCE_LINE_DETAIL_ID
                      FROM 
                         INTF_INV_TRANSACTION INV
                      LEFT JOIN APPS.MTL_MATERIAL_TRANSACTIONS@MDIMS2MDERP INV_ERP
                            ON  INV_ERP.TRANSACTION_REFERENCE = TRX_HEADER_ROW.SO_NUM
                           AND  INV_ERP.SOURCE_CODE = 'CIMS' 
                           AND  INV_ERP.SOURCE_LINE_ID = INV.ID
                      WHERE   
                         HEADER_ID = TRX_HEADER_ROW.TRANSACTION_HEAD_ID
                )LOOP 
                      N_TRANSACTION_ID := TRX_LINE_ROW.TRANSACTION_ID; 
                                           
                      IF N_TRANSACTION_ID IS NULL THEN
                          RAISE_APPLICATION_ERROR(-20001,'ERP库存事物ID为空'); 
                      END IF;  
                      
                      SELECT 
                         CH.X_ICP_SEQ_ID
                        ,CL.LOGIST_LINE_ID 
                      INTO 
                         S_ICP_SEQ_ID
                        ,N_LOGIST_LINE_ID
                      FROM 
                         INTF_CUX_ICP_LOGIST_REQ_HEADER CH
                      LEFT JOIN 
                         INTF_CUX_ICP_LOGIST_REQ_LINES CL ON CH.ID = CL.HEADERS_ID
                      WHERE
                         CH.REQUIREMENT_ORDER_NUM = 'G'||TRX_HEADER_ROW.SO_NUM 
                       AND CL.SOURCE_LINE =  TRX_LINE_ROW.SOURCE_LINE_DETAIL_ID;
                       
                     IF S_ICP_SEQ_ID IS NULL THEN
                          RAISE_APPLICATION_ERROR(-20001,'未回写关联交易号'); 
                     END IF; 
                     
                     IF N_LOGIST_LINE_ID IS NULL THEN
                          RAISE_APPLICATION_ERROR(-20001,'未回写关联交易行号'); 
                     END IF; 
                     
                       N_REQ_HEADE_ID := S_INVOICE_TRAN_NUM.NEXTVAL;
                       
                       INSERT 
                          INTO
                         INTF_INV_TRANSACTION_TRAN_NUM
                          (SOURCE_CODE
                          ,SOURCE_NUM
                          ,SOURCE_LINE_NUM
                          ,ESB_SERIAL_NUM
                          ,ESB_DATA_SOURCE
                          ,REQ_HEADER_ID
                          ,REQ_LINE_ID
                          ,TRANSACTION_ID
                          ,ATTRIBUTE1
                          ,ATTRIBUTE2
                          ,ATTRIBUTE3
                          ,ATTRIBUTE4
                          ,ATTRIBUTE5
                          ,TRX_ID
                          ,CREATED_BY
                          ,LAST_UPDATED_BY
                          ,CREATION_DATE
                          ,LAST_UPDATE_DATE
                          ,INTF_STATUS
                          ,ERROR_FLAG
                          ,ERROR_MSG
                          ,POST_DATE
                          ,RETURN_DATE
                          ,RESPONSE_TYPE
                          ,RESPONSE_CODE
                          ,RESPONSE_MESSAGE
                          ,OPERSTATUS
                          ,ENTITY_ID
                          ,ORG_ID
                          ,SO_NUM
                          )
                        VALUES(
                          'CIMS'
                          ,N_REQ_HEADE_ID
                          ,TRX_LINE_ROW.SOURCE_LINE_ID
                          ,null
                          ,'ERP-IMS-080'
                          ,TO_NUMBER(S_ICP_SEQ_ID)
                          ,N_LOGIST_LINE_ID
                          ,N_TRANSACTION_ID
                          ,null
                          ,null
                          ,null
                          ,null
                          ,null
                          ,N_REQ_HEADE_ID
                          ,'admin'
                          ,'admin'
                          ,sysdate
                          ,sysdate
                          ,'N'
                          ,null
                          ,null
                          ,null
                          ,null
                          ,null
                          ,null
                          ,null
                          ,'N'
                          ,TRX_HEADER_ROW.ENTITY_ID
                          ,TRX_HEADER_ROW.ERP_OU_ID
                          ,TRX_HEADER_ROW.SO_NUM
                        );
                END LOOP;    
                
                 UPDATE 
                        INTF_INV_TRANSACTION_HEAD 
                 SET 
                       OPERSTATUS = 'S'
                      ,ERROR_MSG = NULL
                 WHERE ID = TRX_HEADER_ROW.TRANSACTION_HEAD_ID; 
                 COMMIT;
           EXCEPTION
                WHEN OTHERS THEN
                     ROLLBACK TO SAVEPOINT SP;
                     --设置ESB异步回调处理错误
                     S_ERR_MESSAGE := substr(sqlerrm,1,80);
                     UPDATE 
                        INTF_INV_TRANSACTION_HEAD 
                     SET 
                        OPERSTATUS = 'E'
                       ,ERROR_MSG = S_ERR_MESSAGE
                    WHERE ID = TRX_HEADER_ROW.TRANSACTION_HEAD_ID; 
          END;
        END LOOP;        
  END; 
  
  
    
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-12
  --处理ERP接口错误自动修复   SO生成
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_OE_HEADERS(
                            IN_SPACE_TIME IN NUMBER
                            ,IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2) --返回值     
    IS     
    S_ERR_MESSAGE VARCHAR2(500);
    V_SO_HEADER_ID NUMBER;
    V_ERP_LINE_ID NUMBER;
    V_ERP_HEADER_ID NUMBER;
  BEGIN
        OS_MESSAGE :='OK';
       FOR 
         HEADERS_BATCH_ROW 
          IN(
              select * from cims.intf_oe_headers_iface_all oe where oe.gen_trx_status='E' and error_msg like '%订单参考标识已存在%'
              union all
              select * from cims.intf_oe_headers_iface_all oe where oe.gen_trx_status='N' and oe.gen_request_id is not null AND oe.post_date<=sysdate-1/IN_SPACE_TIME
          )LOOP
              BEGIN 
                  select SO_HEADER_ID into V_SO_HEADER_ID from cims.t_so_header where SO_NUM=to_char(HEADERS_BATCH_ROW.ORDER_NUMBER);
                 
              
                  for LINES_BATCH_ROW in (
                      select ORIG_SYS_LINE_REF,ORDERED_ITEM,ITEM_TYPE_CODE,ORIG_SYS_SHIPMENT_REF from CIMS.INTF_OE_LINES_IFACE_ALL where OE_HEADERS_Id = HEADERS_BATCH_ROW.OE_HEADERS_ID
                  )loop
                  
                   IF LINES_BATCH_ROW.ITEM_TYPE_CODE is null OR  LINES_BATCH_ROW.ITEM_TYPE_CODE = 'MODEL' THEN    
                         SELECT  
                                  OEL.LINE_ID 
                              INTO 
                                  V_ERP_LINE_ID    
                            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
                           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
                             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
                             AND LV.LANGUAGE = 'US'
                             AND LV.VIEW_APPLICATION_ID = 660
                             AND OEH.HEADER_ID = OEL.HEADER_ID
                             AND OEH.ORDER_NUMBER = HEADERS_BATCH_ROW.ORDER_NUMBER
                             AND OEH.ORG_ID =  HEADERS_BATCH_ROW.ORG_ID
                             AND OEL.ORDERED_ITEM = LINES_BATCH_ROW.ORDERED_ITEM
                             AND OEL.ORIG_SYS_LINE_REF = LINES_BATCH_ROW.ORIG_SYS_LINE_REF;       
                   elsif    LINES_BATCH_ROW.ITEM_TYPE_CODE = 'OPTION' then
                       begin
                          SELECT  
                              OEL.LINE_ID 
                          INTO 
                              V_ERP_LINE_ID    
                        FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                             APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                             APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
                       WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
                         AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
                         AND LV.LANGUAGE = 'US'
                         AND LV.VIEW_APPLICATION_ID = 660
                         AND OEH.HEADER_ID = OEL.HEADER_ID
                         AND OEH.ORDER_NUMBER = HEADERS_BATCH_ROW.ORDER_NUMBER
                         AND OEH.ORG_ID =  HEADERS_BATCH_ROW.ORG_ID
                         AND OEL.ORDERED_ITEM = LINES_BATCH_ROW.ORDERED_ITEM
                         AND OEL.ORIG_SYS_LINE_REF = LINES_BATCH_ROW.ORIG_SYS_LINE_REF;
                       exception
                         when others then    
                             SELECT  
                                  OEL.LINE_ID 
                              INTO 
                                  V_ERP_LINE_ID    
                            FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                                 APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                                 APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
                           WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
                             AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
                             AND LV.LANGUAGE = 'US'
                             AND LV.VIEW_APPLICATION_ID = 660
                             AND OEH.HEADER_ID = OEL.HEADER_ID
                             AND OEH.ORDER_NUMBER = HEADERS_BATCH_ROW.ORDER_NUMBER
                             AND OEH.ORG_ID =  HEADERS_BATCH_ROW.ORG_ID
                             AND OEL.ORDERED_ITEM = LINES_BATCH_ROW.ORDERED_ITEM
                             AND OEL.ORIG_SYS_LINE_REF = LINES_BATCH_ROW.ORIG_SYS_SHIPMENT_REF;
                       end;  
                     
                     else
                         RAISE_APPLICATION_ERROR(-20000, '没找到对应关系'||HEADERS_BATCH_ROW.ORDER_NUMBER);
                     end if;
                    
                         UPDATE CIMS.T_SO_LINE
                            SET ERP_SO_LINE_ID = V_ERP_LINE_ID,
                                LAST_UPDATED_BY  = 'ERP',
                                LAST_UPDATE_DATE = sysdate
                         WHERE SO_LINE_ID = LINES_BATCH_ROW.ORIG_SYS_LINE_REF
                           AND SO_HEADER_ID = V_SO_HEADER_ID
                           AND ITEM_CODE = LINES_BATCH_ROW.ORDERED_ITEM;
                           
                        UPDATE  CIMS.T_SO_LINE_DETAIL
                           SET ERP_SO_LINE_ID = V_ERP_LINE_ID,
                               LAST_UPDATED_BY = 'ERP',
                               LAST_UPDATE_DATE = sysdate
                         WHERE  SO_HEADER_ID = V_SO_HEADER_ID
                           AND  SO_LINE_ID = LINES_BATCH_ROW.ORIG_SYS_LINE_REF
                           and  COMPONENT_CODE = LINES_BATCH_ROW.ORDERED_ITEM;
                      
                        UPDATE INTF_OE_LINES_IFACE_ALL
                            SET STATUS     = 'S',
                                ERROR_FLAG = 'N',
                                LINE_ID    = V_ERP_LINE_ID
                         WHERE ORIG_SYS_LINE_REF = LINES_BATCH_ROW.ORIG_SYS_LINE_REF
                           AND ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
                           AND OPERATION_CODE = 'INSERT'
                           AND ORDERED_ITEM  = LINES_BATCH_ROW.ORDERED_ITEM;
                    end loop; 
                    
                        SELECT  
                              OEH.HEADER_ID 
                          INTO 
                              V_ERP_HEADER_ID    
                        FROM APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP   OEL,
                             APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP OEH,
                             APPS.FND_LOOKUP_VALUES@MDIMS2MDERP    LV
                       WHERE LV.LOOKUP_TYPE = 'LINE_FLOW_STATUS'
                         AND LV.LOOKUP_CODE = OEL.FLOW_STATUS_CODE
                         AND LV.LANGUAGE = 'US'
                         AND LV.VIEW_APPLICATION_ID = 660
                         AND OEH.HEADER_ID = OEL.HEADER_ID
                         AND OEH.ORDER_NUMBER = HEADERS_BATCH_ROW.ORDER_NUMBER
                         AND OEH.ORG_ID =  HEADERS_BATCH_ROW.ORG_ID
                         AND ROWNUM=1;
                         
                    
                    UPDATE cims.T_SO_HEADER SH
                       SET SH.ERP_SO_ID   = V_ERP_HEADER_ID,
                           SH.ERP_SO_CODE = HEADERS_BATCH_ROW.Order_Number,
                           sh.LAST_UPDATE_DATE = sysdate
                    WHERE SH.SO_HEADER_ID = V_SO_HEADER_ID
                        and sh.so_num=HEADERS_BATCH_ROW.ORDER_NUMBER;

                    --ERP返回结果为成功
                    UPDATE INTF_OE_HEADERS_IFACE_ALL
                       SET STATUS = 'S', --成功
                           ERROR_FLAG  = 'N', --设置错误标识为N
                           ERROR_MSG   = '',
                           HEADER_ID   = V_ERP_HEADER_ID, --销售订单头ID
                           RETURN_DATE = sysdate,
                           GEN_TRX_STATUS = 'S',
                           GEN_TRX_DATE = sysdate
                    WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
                      AND ORDER_NUMBER = HEADERS_BATCH_ROW.ORDER_NUMBER
                      AND OPERATION_CODE = 'INSERT'; 
                 COMMIT;
              EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                     ROLLBACK;
                     
                     IF IN_RE_SEND='Y' THEN 
                             --ERP返回结果为成功
                             UPDATE INTF_OE_HEADERS_IFACE_ALL
                               SET ERROR_FLAG  = 'N', --设置错误标识为N
                                   ERROR_MSG   = '',
                                   RETURN_DATE = sysdate,
                                   GEN_TRX_STATUS = 'N',
                                   GEN_TRX_DATE = sysdate,
                                   GEN_REQUEST_ID = null,
                                   GEN_TRX_SEND_TIMES = 0
                             WHERE ORIG_SYS_DOCUMENT_REF = V_SO_HEADER_ID
                              AND ORDER_NUMBER = HEADERS_BATCH_ROW.ORDER_NUMBER
                              AND OPERATION_CODE = 'INSERT'; 
                            COMMIT;
                      END IF;          
                     
                  WHEN OTHERS THEN
                     ROLLBACK;
              END;
           END LOOP;        
  END; 
  
  
  
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-12
  --处理ERP接口错误自动修复   --SO变更
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_OE_CHANGE(
                            IN_SPACE_TIME IN NUMBER
                            , IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2) --返回值     
    IS     
    S_ERR_MESSAGE    VARCHAR2(500);
    V_SO_HEADER_ID   NUMBER;
    V_ERP_LINE_ID    NUMBER;
    V_ERP_HEADER_ID  NUMBER;
    V_ERP_TRX_NUMBER VARCHAR2(500);
    V_ERP_WORK_STATE VARCHAR2(500);
  BEGIN
        OS_MESSAGE :='OK';
       FOR 
         HEADERS_BATCH_ROW 
          IN(
              select * from cims.intf_oe_headers_iface_all oe where oe.update_trx_status='E' and error_msg like '%库存可用量不足%'
              union all
              select * from cims.intf_oe_headers_iface_all oe where oe.update_trx_status='N' and oe.update_request_id is not null AND oe.post_date<=sysdate-1/IN_SPACE_TIME
          )LOOP
              BEGIN 
                 BEGIN
                      SELECT 
                          INC.TRX_NUMBER
                      INTO
                          V_ERP_TRX_NUMBER 
                      FROM APPS.CUX_IMS_AR_INVOICE_V@MDIMS2MDERP INC
                      WHERE INC.REFERENCE = HEADERS_BATCH_ROW.ORDER_NUMBER||''
                      AND INC.ORG_ID = HEADERS_BATCH_ROW.ORG_ID
                      AND ROWNUM=1;    -- ERP  AR发票存在 说明SO变更成功
                  EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                         V_ERP_TRX_NUMBER := NULL;
                  END; 
                  
                  BEGIN
                       SELECT 
                           A.FLOW_STATUS_CODE
                         INTO 
                           V_ERP_WORK_STATE
                      FROM  APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP A 
                           ,APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP L 
                       WHERE A.HEADER_ID = L.HEADER_ID 
                        AND A.ORDER_NUMBER = HEADERS_BATCH_ROW.ORDER_NUMBER
                        AND A.ORG_ID= HEADERS_BATCH_ROW.ORG_ID and rownum=1;
                  EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                          V_ERP_WORK_STATE := NULL;
                  END; 
                  
                  /*
                   select *  
                   from apps.cux_oe_headers_iface_all  
                   where operation_code = 'UPDATE' 
                   and source_code='CIMS' 
                   and process_status = 'COMPLETED' 
                   and header_id = 40510171  /*变量:销售订单头ID*/ 
                 /*  AND esb_serial_num = 'CimsSo20190163309080'; */
                
                  IF V_ERP_TRX_NUMBER IS NOT NULL  OR V_ERP_WORK_STATE IN('BOOKED','CLOSED') THEN 
                          UPDATE INTF_OE_HEADERS_IFACE_ALL
                           SET STATUS = 'S', --成功
                               ERROR_FLAG = 'N', --设置错误标识为N
                               ERROR_MSG = null,
                               RETURN_DATE = sysdate,
                               UPDATE_TRX_STATUS = 'S',
                               UPDATE_TRX_DATE = sysdate
                        WHERE ORIG_SYS_DOCUMENT_REF = HEADERS_BATCH_ROW.ORIG_SYS_DOCUMENT_REF
                          AND OPERATION_CODE = 'INSERT';

                          --SO变更成功回调，如果是拉式销售，销售红冲、源单退回、反向销售时需要继续调用RMA接收
                          pkg_so_rt.P_SOCHANGE_WRITE_BACK( HEADERS_BATCH_ROW.ORIG_SYS_DOCUMENT_REF);

                        --更新销售单头表的ERP登记标记：Y-是，N-否
                        UPDATE T_SO_HEADER SET ERP_BOOKED_FLAG = 'Y',LAST_UPDATE_DATE = SYSDATE
                         WHERE SO_HEADER_ID =  HEADERS_BATCH_ROW.ORIG_SYS_DOCUMENT_REF;
                  ELSE   
                    
                     IF IN_RE_SEND='Y' THEN 
                           UPDATE INTF_OE_HEADERS_IFACE_ALL
                               SET ERROR_FLAG = 'N', --设置错误标识为N
                                   ERROR_MSG = null,
                                   RETURN_DATE = sysdate,
                                   UPDATE_TRX_STATUS = 'N',
                                   UPDATE_TRX_DATE = sysdate,
                                   UPDATE_REQUEST_ID=null,
                                   UPDATE_TRX_SEND_TIMES = 0
                            WHERE ORIG_SYS_DOCUMENT_REF = HEADERS_BATCH_ROW.ORIG_SYS_DOCUMENT_REF
                              AND OPERATION_CODE = 'INSERT';   
                     END IF;          
                                        
                  END IF; 
              END;
           END LOOP;        
  END; 
  
  
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-29
  --处理ERP接口错误自动修复   --关联订单
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_REQ_HEADERS(
                            IN_SPACE_TIME IN NUMBER
                            ,IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2) --返回值     
    IS     
    S_ERR_MESSAGE    VARCHAR2(500);
    V_ERP_HEADER_ID  NUMBER;
  BEGIN
    FOR 
         HEADERS_BATCH_ROW 
          IN(
              select * from cims.INTF_CUX_ICP_ORDER_REQ_HEADERS rh where rh.status='P' and rh.post_date<=sysdate-1/IN_SPACE_TIME and rh.post_date>=sysdate-30                    
            )LOOP
              BEGIN 
                  IF HEADERS_BATCH_ROW.X_ICP_SEQ_ID IS NOT NULl THEN
                     update cims.INTF_CUX_ICP_ORDER_REQ_HEADERS rh  set rh.status='S' where rh.id=  HEADERS_BATCH_ROW.id;
                  ELSE
                      BEGIN
                         select REQ_HEADER_ID INTO V_ERP_HEADER_ID from CUX_ICP_ORDER_REQ_HEADERS_V where SOURCE_CODE = 'CIMS' and SOURCE_ORDERS = HEADERS_BATCH_ROW.SOURCE_ORDERS;
                      EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                           V_ERP_HEADER_ID := NULL;
                      END; 
                      IF V_ERP_HEADER_ID IS NOT NULL THEN 
                             UPDATE INTF_CUX_ICP_ORDER_REQ_HEADERS IM
                             SET IM.STATUS = 'S',
                                  IM.RETURN_DATE = SYSDATE,
                                  IM.X_ICP_SEQ_ID = V_ERP_HEADER_ID
                            WHERE IM.SOURCE_ORDERS = HEADERS_BATCH_ROW.SOURCE_ORDERS; 
                      
                      
                            UPDATE INTF_CUX_ICP_LOGIST_REQ_LINES RL SET RL.ORDER_HEADER_ID= V_ERP_HEADER_ID,RL.X_ICP_SEQ_ID = V_ERP_HEADER_ID WHERE RL.SOURCE_HEADER=HEADERS_BATCH_ROW.SOURCE_ORDERS;       
                            IF HEADERS_BATCH_ROW.SOURCE_ORDERS_TYPE = '01' THEN
                                 UPDATE T_INV_PO_HEADERS PH SET PH.ERP_ORDER_HEADER_ID = V_ERP_HEADER_ID,PH.LAST_UPDATE_DATE=SYSDATE  WHERE PH.PO_ID = HEADERS_BATCH_ROW.SOURCE_HEADER_ID;
                                 UPDATE INTF_CUX_ICP_LOGIST_REQ_HEADER RH SET RH.STATUS='P',RH.STATUS_SUPPLIER='N' WHERE RH.REQUIREMENT_ORDER_NUM=HEADERS_BATCH_ROW.SOURCE_ORDERS AND (RH.STATUS_SUPPLIER IS NULL OR RH.STATUS_SUPPLIER<>'S'); 
                            ELSIF  HEADERS_BATCH_ROW.SOURCE_ORDERS_TYPE = '02' THEN
                                 UPDATE T_SO_HEADER SH SET SH.ERP_ORDER_HEADER_ID = V_ERP_HEADER_ID,SH.LAST_UPDATE_DATE=SYSDATE WHERE SH.SO_HEADER_ID = HEADERS_BATCH_ROW.SOURCE_HEADER_ID;
                                 UPDATE INTF_CUX_ICP_LOGIST_REQ_HEADER RH SET RH.STATUS_SOURCE='N' WHERE RH.REQUIREMENT_ORDER_NUM=HEADERS_BATCH_ROW.SOURCE_ORDERS AND (RH.STATUS_SOURCE IS NULL OR RH.STATUS_SOURCE<>'S'); 
                            ELSIF  HEADERS_BATCH_ROW.SOURCE_ORDERS_TYPE = '03' THEN 
                                 UPDATE T_SO_HEADER SH SET SH.ERP_ORDER_HEADER_ID2 = V_ERP_HEADER_ID,SH.LAST_UPDATE_DATE=SYSDATE WHERE SH.SO_HEADER_ID = HEADERS_BATCH_ROW.SOURCE_HEADER_ID;
                                 UPDATE INTF_CUX_ICP_LOGIST_REQ_HEADER RH SET RH.STATUS='P',RH.STATUS_SUPPLIER='N' WHERE RH.REQUIREMENT_ORDER_NUM=HEADERS_BATCH_ROW.SOURCE_ORDERS AND (RH.STATUS_SUPPLIER IS NULL OR RH.STATUS_SUPPLIER<>'S' ); 
                            ELSE
                                NULL;   
                            END IF;
                       ELSE
                           IF IN_RE_SEND='Y' THEN 
                                 UPDATE INTF_CUX_ICP_ORDER_REQ_HEADERS IM
                                 SET IM.STATUS = 'N',
                                      IM.RETURN_DATE = SYSDATE
                                 WHERE IM.SOURCE_ORDERS = HEADERS_BATCH_ROW.SOURCE_ORDERS; 
                           END IF;          
                      END IF;
                  END IF;
              END;
          END LOOP;
  END; 
  
  
  
    --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-29
  --处理ERP接口错误自动修复   --关联订单
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_REQ_SEND(
                            IN_SPACE_TIME IN NUMBER
                            ,IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2) --返回值     
    IS     
    S_ERR_MESSAGE    VARCHAR2(500);
    V_ERP_HEADER_ID  NUMBER;
    V_SEND_TYPE VARCHAR2(500);
  BEGIN
      V_SEND_TYPE := 'CIMS-SEND';
      FOR 
         HEADERS_BATCH_ROW 
          IN( 
              select * from cims.intf_cux_icp_logist_req_header kh where  kh.status_supplier='P' and kh.post_date_send<=sysdate-1/IN_SPACE_TIME and kh.post_date_send>=sysdate-30
              union all
              select * from cims.intf_cux_icp_logist_req_header kh where  kh.status_source='P' and kh.post_date_send<=sysdate-1/IN_SPACE_TIME and kh.post_date_send>=sysdate-30                     
            )LOOP
              BEGIN 
                 BEGIN
                    select REQ_HEADER_ID INTO V_ERP_HEADER_ID from CUX_ICP_LOGIST_REQ_HEADERS_V 
                    where REQUIREMENT_ORDER_NUM = HEADERS_BATCH_ROW.REQUIREMENT_ORDER_NUM
                    and esb_data_source='CIMS' 
                    and REQUIREMENT_ORDER_TYPE = V_SEND_TYPE
                    AND ROWNUM=1; 
                 EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      V_ERP_HEADER_ID := NULL;
                 END; 
                 IF V_ERP_HEADER_ID IS NOT NULl THEN 
                       IF HEADERS_BATCH_ROW.REQUIREMENT_ORDER_TYPE = '02' THEN
                          UPDATE INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_SOURCE='S',RESPONSETYPE_1='N',X_ICP_SEQ_ID=V_ERP_HEADER_ID,RETURN_DATE_SEND= sysdate where REQUIREMENT_ORDER_NUM = HEADERS_BATCH_ROW.REQUIREMENT_ORDER_NUM;    
                          UPDATE T_SO_HEADER SH SET SH.ERP_LOGIST_HEADER_ID = V_ERP_HEADER_ID,SH.LAST_UPDATE_DATE=SYSDATE WHERE SH.SO_HEADER_ID =  HEADERS_BATCH_ROW.SOURCE_HEADER_ID;
                       ELSIF HEADERS_BATCH_ROW.REQUIREMENT_ORDER_TYPE = '01' THEN
                             update INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_SUPPLIER = 'S',RESPONSETYPE_1='N', REQ_HEADER_ID = V_ERP_HEADER_ID, X_ICP_SEQ_ID = V_ERP_HEADER_ID, RETURN_DATE_SEND= sysdate where REQUIREMENT_ORDER_NUM = HEADERS_BATCH_ROW.REQUIREMENT_ORDER_NUM; 
                             update INTF_CUX_ICP_LOGIST_REQ_LINES set LOGIST_HEADER_ID = V_ERP_HEADER_ID where HEADERS_ID = HEADERS_BATCH_ROW.id;
                             UPDATE T_INV_PO_HEADERS PH SET PH.ERP_LOGIST_HEADER_ID = V_ERP_HEADER_ID,PH.LAST_UPDATE_DATE=SYSDATE  WHERE PH.PO_ID = HEADERS_BATCH_ROW.SOURCE_HEADER_ID;
                       ELSIF HEADERS_BATCH_ROW.REQUIREMENT_ORDER_TYPE = '03' THEN
                             update INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_SUPPLIER = 'S',RESPONSETYPE_1='N',REQ_HEADER_ID = V_ERP_HEADER_ID, X_ICP_SEQ_ID = V_ERP_HEADER_ID, RETURN_DATE_SEND= sysdate where REQUIREMENT_ORDER_NUM = HEADERS_BATCH_ROW.REQUIREMENT_ORDER_NUM; 
                             update INTF_CUX_ICP_LOGIST_REQ_LINES set LOGIST_HEADER_ID = V_ERP_HEADER_ID where HEADERS_ID =  HEADERS_BATCH_ROW.id;
                             UPDATE T_SO_HEADER SH SET SH.ERP_LOGIST_HEADER_ID2 = V_ERP_HEADER_ID,SH.LAST_UPDATE_DATE=SYSDATE WHERE SH.SO_HEADER_ID = HEADERS_BATCH_ROW.SOURCE_HEADER_ID;
                      END IF; 
                  ELSE
                     IF IN_RE_SEND='Y' THEN 
                        IF HEADERS_BATCH_ROW.REQUIREMENT_ORDER_TYPE = '02' THEN
                            UPDATE INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_SOURCE='N',RETURN_DATE_SEND= sysdate where REQUIREMENT_ORDER_NUM = HEADERS_BATCH_ROW.REQUIREMENT_ORDER_NUM;   
                        ELSIF HEADERS_BATCH_ROW.REQUIREMENT_ORDER_TYPE = '01' THEN 
                            update INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_SUPPLIER = 'N', RETURN_DATE_SEND= sysdate where REQUIREMENT_ORDER_NUM = HEADERS_BATCH_ROW.REQUIREMENT_ORDER_NUM; 
                        ELSIF HEADERS_BATCH_ROW.REQUIREMENT_ORDER_TYPE = '03' THEN
                            update INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_SUPPLIER = 'N', RETURN_DATE_SEND= sysdate where REQUIREMENT_ORDER_NUM = HEADERS_BATCH_ROW.REQUIREMENT_ORDER_NUM; 
                        END IF;        
                     END IF;       
                 END IF;
              END;
         END LOOP;
  
  END; 
  
  
  
    --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-29
  --处理ERP接口错误自动修复   --关联订单
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_REQ_RECEIVE(
                            IN_SPACE_TIME IN NUMBER
                            ,IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2) --返回值     
    IS     
    S_ERR_MESSAGE    VARCHAR2(500);
    V_ERP_HEADER_ID  NUMBER;
    V_SEND_TYPE VARCHAR2(500);
  BEGIN
      V_SEND_TYPE := 'CIMS-RECEIVE';
      FOR 
         HEADERS_BATCH_ROW 
          IN( 
              select * from cims.intf_cux_icp_logist_req_header kh where  kh.status_receive='P' and kh.post_date_send<=sysdate-1/IN_SPACE_TIME  and kh.post_date_send>=sysdate-30                     
            )LOOP
               BEGIN 
                   BEGIN
                      select REQ_HEADER_ID INTO V_ERP_HEADER_ID from CUX_ICP_LOGIST_REQ_HEADERS_V 
                      where REQUIREMENT_ORDER_NUM = HEADERS_BATCH_ROW.REQUIREMENT_ORDER_NUM 
                      and esb_data_source='CIMS'
                      and REQUIREMENT_ORDER_TYPE = V_SEND_TYPE
                      AND ROWNUM=1;
                   EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        V_ERP_HEADER_ID := NULL;
                   END; 
                   
                   IF V_ERP_HEADER_ID IS NOT NULl THEN 
                         IF HEADERS_BATCH_ROW.REQUIREMENT_ORDER_TYPE = '01' THEN
                             update INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_RECEIVE = 'S',RESPONSETYPE_2='N' ,RETURN_DATE_REV= sysdate where REQUIREMENT_ORDER_NUM = HEADERS_BATCH_ROW.REQUIREMENT_ORDER_NUM; 
                         ELSIF HEADERS_BATCH_ROW.REQUIREMENT_ORDER_TYPE = '03' THEN
                             update INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_RECEIVE = 'S',RESPONSETYPE_2='N', RETURN_DATE_REV= sysdate where REQUIREMENT_ORDER_NUM = HEADERS_BATCH_ROW.REQUIREMENT_ORDER_NUM; 
                         END IF; 
                   ELSE     
                       IF IN_RE_SEND='Y' THEN 
                           update INTF_CUX_ICP_LOGIST_REQ_HEADER set STATUS_RECEIVE = 'N',RETURN_DATE_REV= sysdate where REQUIREMENT_ORDER_NUM = HEADERS_BATCH_ROW.REQUIREMENT_ORDER_NUM; 
                       END IF;
                   END IF;
               END;
         END LOOP;
  END;         
  
  
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-29
  --处理ERP接口错误自动修复   --财务发票
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_REQ_INVOICE(
                            IN_SPACE_TIME IN NUMBER
                            ,IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2) --返回值   
       IS     
  P_RESULT varchar2(1000);
  P_MESSAGE varchar2(1000);
  P_INVOICE_HEADER_ID number;
  P_ERP_INVOICE_HEADER_ID number;
  P_ERP_INVOICE_LINE_ID number;
  BEGIN
      FOR 
         HEADERS_BATCH_ROW 
          IN( 
               select * from cims.intf_ar_invoice where  INTF_STATUS='E' and error_msg like '%标准接口:发票号重复%' 
                union all
                select * from cims.intf_ar_invoice where INTF_STATUS='N' and RESPONSETYPE is not null and  POST_DATE <=sysdate-1                
            )LOOP
               BEGIN                          
                    select 
                         INVOICE_HEADER_ID
                       into
                         P_INVOICE_HEADER_ID
                     from 
                       cims.t_ar_cash_receipt_headers rh
                     where
                       rh.cash_receipt_code = HEADERS_BATCH_ROW.TRX_NUMBER;
                 
                   BEGIN      
                         select   distinct
                               trx_erp_cust.CUSTOMER_TRX_ID,
                               trx_erp_line.CUSTOMER_TRX_LINE_ID
                              INTO 
                                 P_ERP_INVOICE_HEADER_ID,
                                 P_ERP_INVOICE_LINE_ID
                          from apps.ra_customer_trx_lines_all@mdims2mderp    trx_erp_line,
                               apps.ra_customer_trx_all@mdims2mderp          trx_erp_cust,
                               apps.ra_cust_trx_line_gl_dist_all@mdims2mderp trx_erp_gl
                         where trx_erp_cust.customer_trx_id = trx_erp_line.customer_trx_id
                           and trx_erp_cust.customer_trx_id = trx_erp_gl.customer_trx_id
                           and trx_erp_gl.account_class = 'REC'
                           and  trx_erp_cust.trx_number= HEADERS_BATCH_ROW.TRX_NUMBER
                           and trx_erp_line.line_type ='LINE';
                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                         P_ERP_INVOICE_HEADER_ID := NULL;
                         P_ERP_INVOICE_LINE_ID := NULL;
                     END;    
                     
                       
                     IF  P_INVOICE_HEADER_ID IS null AND  P_ERP_INVOICE_HEADER_ID IS NOT NULL THEN 
                          UPDATE  CIMS.T_AR_CASH_RECEIPT_HEADERS SET INVOICE_HEADER_ID=P_ERP_INVOICE_HEADER_ID,INVOICE_LINE_ID=P_ERP_INVOICE_LINE_ID,UPDATED_DATE=sysdate WHERE CASH_RECEIPT_CODE= HEADERS_BATCH_ROW.TRX_NUMBER;
                     END IF; 
                     IF P_ERP_INVOICE_HEADER_ID IS NOT NULL THEN
                   
                         UPDATE CIMS.intf_ar_invoice SET INTF_STATUS='S',RESPONSETYPE='N'
                         ,RESPNOSECODE='000000',RESPONSEMESSAGE=NULL
                         ,ERROR_MSG=NULL,ERROR_FLAG=NULL WHERE TRX_NUMBER= HEADERS_BATCH_ROW.TRX_NUMBER;
                         
                         UPDATE  CIMS.T_AR_CASH_RECEIPT_HEADERS SET INTO_ERP_ERROR=NULL,UPDATED_DATE=sysdate  WHERE CASH_RECEIPT_CODE= HEADERS_BATCH_ROW.TRX_NUMBER;
                     ELSE
                         IF IN_RE_SEND='Y' THEN 
                              UPDATE CIMS.intf_ar_invoice SET INTF_STATUS='N',RESPONSETYPE=null
                              ,RESPNOSECODE=null,RESPONSEMESSAGE=NULL
                             ,ERROR_MSG=NULL,ERROR_FLAG=NULL WHERE TRX_NUMBER= HEADERS_BATCH_ROW.TRX_NUMBER;
                         END IF;
                     END IF; 
                   
               END;
         END LOOP;
    END;     
    
    
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-29
  --处理ERP接口错误自动修复   --财务收款
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_REQ_RECEIPT(
                            IN_SPACE_TIME IN NUMBER
                            ,IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2) --返回值                              
          IS     
  P_RESULT varchar2(1000);
  P_MESSAGE varchar2(1000);
  P_RECEIPT_CODE varchar2(200);
  P_ERP_RECEIPT_CODE varchar2(200);
  BEGIN
      FOR 
         HEADERS_BATCH_ROW 
          IN( 
                 select * from cims.intf_ar_cash_receipt where  INTF_STATUS='E' and error_msg like '%SOURCE_NUM已存在%' 
                 union all
                 select * from cims.intf_ar_cash_receipt where  INTF_STATUS='N' and RESPONSETYPE is not null  and POST_DATE <=sysdate-1              
          )LOOP
               BEGIN       
                   select 
                         AR_RECEIPT_CODE
                       into
                         P_RECEIPT_CODE
                     from 
                       cims.t_ar_cash_receipt_headers rh
                     where
                       rh.cash_receipt_code = HEADERS_BATCH_ROW.Receipt_Number;
                       
                    BEGIN      
                       select  
                             ar_erp.cash_receipt_id||''
                         into 
                             P_ERP_RECEIPT_CODE
                          from apps.ar_cash_receipts_all@mdims2mderp ar_erp
                         where ar_erp.attribute2 = 'IMS' 
                        and ar_erp.receipt_number=HEADERS_BATCH_ROW.Receipt_Number;
                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                         P_ERP_RECEIPT_CODE := NULL;
                    END;        
                         
                     IF  P_RECEIPT_CODE IS null AND  P_ERP_RECEIPT_CODE IS NOT NULL THEN 
                          UPDATE  CIMS.T_AR_CASH_RECEIPT_HEADERS SET AR_RECEIPT_CODE=P_ERP_RECEIPT_CODE,UPDATED_DATE=sysdate WHERE CASH_RECEIPT_CODE= HEADERS_BATCH_ROW.RECEIPT_NUMBER;
                     END IF; 
                     
                     IF P_ERP_RECEIPT_CODE IS NOT NULL THEN
                   
                         UPDATE CIMS.INTF_AR_CASH_RECEIPT SET INTF_STATUS='S',RESPONSETYPE='N'
                         ,RESPNOSECODE='000000',RESPONSEMESSAGE=NULL
                         ,ERROR_MSG=NULL,ERROR_FLAG=NULL WHERE RECEIPT_NUMBER= HEADERS_BATCH_ROW.RECEIPT_NUMBER;
                         
                         UPDATE  CIMS.T_AR_CASH_RECEIPT_HEADERS SET INTO_ERP_ERROR=NULL,UPDATED_DATE=sysdate  WHERE CASH_RECEIPT_CODE= HEADERS_BATCH_ROW.RECEIPT_NUMBER;
                     ELSE
                         IF IN_RE_SEND='Y' THEN
                              UPDATE CIMS.INTF_AR_CASH_RECEIPT SET INTF_STATUS='N',RESPONSETYPE=null
                               ,RESPNOSECODE=null,RESPONSEMESSAGE=NULL
                               ,ERROR_MSG=NULL,ERROR_FLAG=NULL WHERE RECEIPT_NUMBER= HEADERS_BATCH_ROW.RECEIPT_NUMBER;
                         END IF;
                     END IF;
               END;
         END LOOP;
    END;   
    
    
    --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-29
  --处理ERP接口错误自动修复   --RMA 
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_OE_RMA(
                            IN_SPACE_TIME IN NUMBER
                            ,IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2) --返回值                              
          IS     
    S_ERR_MESSAGE    VARCHAR2(500);
    V_SO_HEADER_ID   NUMBER;
    V_ERP_LINE_ID    NUMBER;
    V_ERP_HEADER_ID  NUMBER;
    V_ERP_TRX_NUMBER VARCHAR2(500);
    V_ERP_WORK_STATE VARCHAR2(500);
  BEGIN  
        OS_MESSAGE :='OK';
       FOR 
         HEADERS_BATCH_ROW 
          IN(
              select * from cims.intf_oe_headers_iface_all oe where oe.rma_receive_trx_status='E' and error_msg like '%库存可用量不足%'
              union all
              select * from cims.intf_oe_headers_iface_all oe where oe.rma_receive_trx_status='N' and oe.rma_receive_request_id is not null AND oe.post_date<=sysdate-1/IN_SPACE_TIME
          )LOOP
              BEGIN 
                 BEGIN
                      SELECT 
                          INC.TRX_NUMBER
                      INTO
                          V_ERP_TRX_NUMBER 
                      FROM APPS.CUX_IMS_AR_INVOICE_V@MDIMS2MDERP INC
                      WHERE INC.REFERENCE = HEADERS_BATCH_ROW.ORDER_NUMBER||''
                      AND INC.ORG_ID = HEADERS_BATCH_ROW.ORG_ID
                      AND ROWNUM=1;    -- ERP  AR发票存在 说明SO变更成功
                  EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                         V_ERP_TRX_NUMBER := NULL;
                  END; 
                  
                  BEGIN
                       SELECT 
                           A.FLOW_STATUS_CODE
                         INTO 
                           V_ERP_WORK_STATE
                      FROM  APPS.OE_ORDER_HEADERS_ALL@MDIMS2MDERP A 
                           ,APPS.OE_ORDER_LINES_ALL@MDIMS2MDERP L 
                       WHERE A.HEADER_ID = L.HEADER_ID 
                        AND A.ORDER_NUMBER = HEADERS_BATCH_ROW.ORDER_NUMBER
                        AND A.ORG_ID= HEADERS_BATCH_ROW.ORG_ID and rownum=1;
                  EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                          V_ERP_WORK_STATE := NULL;
                  END; 
                  
                  V_SO_HEADER_ID := HEADERS_BATCH_ROW.ORIG_SYS_DOCUMENT_REF;
                
                  IF V_ERP_TRX_NUMBER IS NOT NULL  OR V_ERP_WORK_STATE IN('CLOSED') THEN 
                         --ERP返回结果为成功
                          UPDATE INTF_OE_HEADERS_IFACE_ALL
                             SET STATUS      = 'S', --成功
                                 ERROR_FLAG  = 'N', --设置错误标识为N
                                 ERROR_MSG   = '',
                                 RETURN_DATE = sysdate,
                                 RMA_RECEIVE_TRX_STATUS = 'S',
                                 RMA_RECEIVE_TRX_DATE   = sysdate
                          WHERE ORIG_SYS_DOCUMENT_REF = HEADERS_BATCH_ROW.ORIG_SYS_DOCUMENT_REF
                            AND OPERATION_CODE = 'INSERT';
                          --add by chen.wj 20150205 RMA接收成功，回调
                          pkg_so_rt.P_RMA_WRITE_BACK(V_SO_HEADER_ID);
                  ELSE   
                    
                     IF IN_RE_SEND='Y' THEN 
                           UPDATE INTF_OE_HEADERS_IFACE_ALL
                               SET ERROR_FLAG = 'N', --设置错误标识为N
                                   ERROR_MSG = null,
                                   RETURN_DATE = sysdate,
                                   RMA_RECEIVE_TRX_STATUS = 'N',
                                   RMA_RECEIVE_TRX_DATE = sysdate,
                                   RMA_RECEIVE_REQUEST_ID=null,
                                   RMA_RECEIVE_TRX_SEND_TIMES = 0
                            WHERE ORIG_SYS_DOCUMENT_REF = HEADERS_BATCH_ROW.ORIG_SYS_DOCUMENT_REF
                              AND OPERATION_CODE = 'INSERT';   
                     END IF;          
                                        
                  END IF; 
              END;
           END LOOP;    
  END;    
  
      --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-29
  --处理ERP接口错误自动修复   --库存事物
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_INV_TRANSACTION(
                            IN_SPACE_TIME IN NUMBER
                            ,IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2) --返回值                              
          IS     
   V_ERP_COUNT NUMBER;
   N_SO_EXIST NUMBER;
   N_SO_HEADER_ID  NUMBER;
   P_RETURN_MSG varchar(1000);
  BEGIN  
              OS_MESSAGE :='OK';
       FOR 
         HEADERS_BATCH_ROW 
          IN(
                 select * from cims.intf_inv_transaction_head where status='P' AND post_date<=sysdate-1/IN_SPACE_TIME and  post_date>=sysdate-30    
            )LOOP
              BEGIN 
                 BEGIN
                     select 
                        count(1) 
                      into 
                        V_ERP_COUNT
                     from apps.mtl_material_transactions@mdims2mderp inv_erp
                     where inv_erp.transaction_reference=HEADERS_BATCH_ROW.ORDER_NUM
                     and inv_erp.source_code='CIMS'
                     and inv_erp.source_line_id in(select h.id from cims.intf_inv_transaction h where h.header_id = HEADERS_BATCH_ROW.ID);
                  EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                          V_ERP_COUNT := 0;
                  END; 
                  
                  IF V_ERP_COUNT>0 THEN
                        update INTF_INV_TRANSACTION_HEAD th
                        set th.STATUS = 'S',
                            th.RETURN_DATE = sysdate
                       where  th.id = HEADERS_BATCH_ROW.ID;
                       BEGIN
                           select
                             SO_HEADER_ID
                           into
                              N_SO_HEADER_ID
                          from cims.t_so_header
                          where so_num = HEADERS_BATCH_ROW.ORDER_NUM;
                        EXCEPTION
                           WHEN NO_DATA_FOUND THEN
                            N_SO_HEADER_ID := null;
                       END; 
                       
                        IF HEADERS_BATCH_ROW.INTERFACE_NUM='ERP-IMS-022' THEN                             
                            update T_INV_CHECK_ORDERS tico
                              set tico.EBS_DEAL_FLAG = 'Y',
                                  tico.EBS_DEAL_TIME = sysdate
                             where tico.CHECK_ORDER_NUM =HEADERS_BATCH_ROW.ORDER_NUM;
                        ELSE    
                             if N_SO_HEADER_ID IS NOT NULL then
                                begin
                                  pkg_so_intf.P_SO_INV_TRANSFER_WIRTE_BACK(N_SO_HEADER_ID);
                                exception
                                     when others then
                                        P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('pkg_so_intf.P_SO_INV_TRANSFER_WIRTE_BACK',
                                                                   sqlcode,
                                                                   '销售子库回调失败：'||sqlerrm);
                                 end;
                            else
                                --更新业务表
                                update T_INV_TRSF_ORDER tito
                                  set tito.EBS_DEAL_FLAG = 'Y',
                                      tito.EBS_DEAL_TIME = sysdate
                                 where tito.TRSF_ORDER_NUM = HEADERS_BATCH_ROW.ORDER_NUM;
                            end if;
                      END IF;
                  ELSE  
                      IF IN_RE_SEND='Y' THEN  
                        /* update INTF_INV_TRANSACTION_HEAD th
                          set th.STATUS = 'N',
                              th.RETURN_DATE = sysdate
                         where  th.id = HEADERS_BATCH_ROW.ID;*/
                         null;
                      END IF;   
                       
                  END IF;
              
              END;
         END LOOP;       
  END;  
         
END PKG_SO_IO_ERP;
/

