create function get_Area_Org_By_Code(in_district_code in varchar2,
                                                in_entity_id     in NUMBER)
  return varchar2 is
  tmp_id       NUMBER;
  tmp_unit_id       NUMBER;
  tmp_org_code      varchar(32);
  tmp_par_row_id    NUMBER;
  tmp_level_seq     NUMBER;
  tmp_district_code varchar2(32);
begin
  select a.id,a.unit_id,a.org_code, b.level_seq, b.district_code, b.par_row_id
    into tmp_id, tmp_unit_id, tmp_org_code, tmp_level_seq, tmp_district_code, tmp_par_row_id
    from t_pg_area_org a
   right join (select *
                 from t_bd_district
                where district_code = in_district_code
                  and active_flag = 'Y') b
      on a.district_id = b.row_id
     and a.entity_id = in_entity_id;
  if tmp_id is null or tmp_unit_id is null or tmp_org_code is null then
    if tmp_level_seq > 0 then
      select district_code
        into tmp_district_code
        from t_bd_district
       where row_id = tmp_par_row_id
         and active_flag = 'Y';
      tmp_id := get_Area_Org_By_Code(tmp_district_code, in_entity_id);
      return tmp_id;
    else
      return 0;
    end if;
  else
    return tmp_id;
  end if;
end get_Area_Org_By_Code;
/

