create view V_PLN_FLOW_STATUS as
Select Distinct Flow."FLOW_ID",Flow."FLOW_CODE",Flow."STATUS_ID",Flow."STATUS_CODE",
                Pot.Order_Type_Id,
                Pot.Order_Type_Code,
                Pot.Order_Type_Name,
                Pot.Entity_Id,
                pot.source_order_type_id
  From (Select Tpf.Flow_Id,
               Tpf.Flow_Code,
               Pfs.Curr_Status_Id Status_Id,
               Pfs.Curr_Status    Status_Code
          From t_Pln_Flow Tpf, t_Pln_Flow_Status Pfs
         Where Tpf.Flow_Id = Pfs.Flow_Id
        Union All
        Select Tpf.Flow_Id,
               Tpf.Flow_Code,
               Pfs.Next_Status_Id Status_Id,
               Pfs.Next_Status    Status_Code
          From t_Pln_Flow Tpf, t_Pln_Flow_Status Pfs
         Where Tpf.Flow_Id = Pfs.Flow_Id) Flow,
       t_Pln_Order_Type Pot
 Where Flow.Flow_Id = Pot.Flow_Id
   And flow.status_code <> '新增'
 Order By Flow.Flow_Id, Flow.Status_Id
/

