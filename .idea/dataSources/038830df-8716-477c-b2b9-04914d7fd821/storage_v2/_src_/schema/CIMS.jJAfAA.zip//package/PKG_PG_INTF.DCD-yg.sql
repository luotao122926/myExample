create package PKG_PG_INTF is

 V_CCS_EXCEPTION exception;
 V_SC_BUSINESS_EXCEPTION exception;
  -- Author  : LZH
  -- Created : 2014/12/30 9:10:40
  -- Purpose : 工程机接口

  ----------------------------------------------------------------------
  -- Author  : LZH
  -- Created : 2014/12/30 9:34:40
  -- Purpose : 商机录入
  ----------------------------------------------------------------------
  Procedure P_BUSINESS_ENTRY(p_Intf_Id In Number, p_Result Out Varchar2);

  ----------------------------------------------------------------------
  -- Author  : LZH
  -- Created : 2015/01/06 9:25:40
  -- Purpose : 产品定制
  ----------------------------------------------------------------------
  Procedure P_PRODUCT_CUSTOMIZE(p_Intf_Id In Number, p_Result Out Varchar2);

  ----------------------------------------------------------------------
  -- Author  : LZH
  -- Created : 2015/01/16 14:11:40
  -- Purpose : 价格申请
  ----------------------------------------------------------------------
  Procedure P_PRICE_APPLY(p_Intf_Id In Number, p_Result Out Varchar2);

  ----------------------------------------------------------------------
  -- Author  : LZH
  -- Created : 2015/01/20 17:34:40
  -- Purpose : 授权申请
  ----------------------------------------------------------------------
  Procedure P_AUTHORIZATION_APPLY(p_intf_authorization_id In Number, p_Result Out Varchar2);

  ----------------------------------------------------------------------
  -- Author  : ZWL
  -- Created : 2015/7/22 10:48:52
  -- Purpose : 中标信息回传
  ----------------------------------------------------------------------
  Procedure P_BID_MESSAGE_PASSBACK(p_business_bid_id In Number, p_Result Out Varchar2);

  ----------------------------------------------------------------------
  -- Author  : ZWL
  -- Created : 2015/7/27 10:48:52
  -- Purpose : 价格申报接口
  -----------------------------------------------------------------------
  Procedure P_PG_PRICE_APPLY(P_PRICE_APPLY_ID IN NUMBER, P_RESULT OUT VARCHAR2) ;

  ----------------------------------------------------------------------
  -- Author  : WYF
  -- Created : 2015/08/03 11:08:40
  -- Purpose : 商机同步
  ----------------------------------------------------------------------
  Procedure P_PG_BUSINESS_SYNC(p_Business_Id In Number, p_Entity_Id In Number, p_Result Out Varchar2);

  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2015/10/12
  -- Purpose : 价格申报调整
  ----------------------------------------------------------------------
  Procedure P_PG_PRICE_APPLY_ADJUST(P_PRICE_APPLY_ID IN NUMBER,P_RESULT OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : WYF
  -- Created : 2015/10/19
  -- Purpose : CCS发起价格申报调整校验
  ----------------------------------------------------------------------
  Procedure P_PG_PRICE_APPLY_ADJUST_VERIFY(P_INTF_APPLY_ID IN NUMBER, P_ENTITY_ID IN NUMBER, P_APPLY_CODE OUT VARCHAR2, P_RESULT OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2015/10/19
  -- Purpose : 锁定/解锁批文
  ----------------------------------------------------------------------
  Procedure P_PG_LOCK_UNLOCK_PRICE_APPLY(P_BD_APPLY_CODE IN VARCHAR2,P_ENTITY_ID IN NUMBER,IS_LOCK IN VARCHAR2,P_RESULT OUT VARCHAR2);
  
  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2016/06/07
  -- Purpose : ccs商机引入从接口表同步数据到正式表
  ----------------------------------------------------------------------
  Procedure P_PG_BUSINESS_CCS_SALES(P_INTF_HEAD_ID IN NUMBER,P_MESSAGE OUT VARCHAR2);
  
  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2017/04/17
  -- Purpose : 商机登陆CCS撤回校验
  ----------------------------------------------------------------------
  Procedure P_PG_BUSINESS_REVOKE_VERIFY(P_BUSINESS_CODE IN VARCHAR2,P_ENTITY_ID IN NUMBER,P_MESSAGE OUT VARCHAR2);
  
  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2017/04/12
  -- Purpose : 独资主体商机从CCS引入CIMS
  ----------------------------------------------------------------------
  Procedure P_PG_BUSINESS_CCS(P_INTF_HEAD_ID IN NUMBER,P_MESSAGE OUT VARCHAR2);
  
    
  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2017/04/24
  -- Purpose : 价格申报CCS撤回校验
  ----------------------------------------------------------------------
  Procedure P_PG_PRICE_APPLY_REVOKE_VERIFY(P_APPLY_CODE IN VARCHAR2,P_ENTITY_ID IN NUMBER,P_MESSAGE OUT VARCHAR2);
  
      
  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2017/04/28
  -- Purpose : 商机登陆CCS驳回
  ----------------------------------------------------------------------
  Procedure P_PG_PROJECT_REJECT_VERIFY(P_PROJECT_ID IN NUMBER,P_REJECT_REASON IN VARCHAR2,P_MESSAGE OUT VARCHAR2);
  
  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2017/04/28
  -- Purpose : 价格申报CCS驳回
  ----------------------------------------------------------------------
  Procedure P_PG_PRICE_APPLY_REJECT_VERIFY(P_INTF_ID IN NUMBER,P_REJECT_REASON IN VARCHAR2,P_MESSAGE OUT VARCHAR2);
  
  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2017/05/17
  -- Purpose : 团购项目CCS驳回
  ----------------------------------------------------------------------
  Procedure P_PG_GROUP_BUSINESS_REJECT(P_PROJECT_ID IN NUMBER,P_REJECT_REASON IN VARCHAR2,P_MESSAGE OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2017/05/17
  -- Purpose : 团购申报CCS驳回
  ----------------------------------------------------------------------
  Procedure P_PG_GROUP_PRICE_REJECT(P_PRICE_ID IN NUMBER,P_REJECT_REASON IN VARCHAR2,P_MESSAGE OUT VARCHAR2);
  
  ----------------------------------------------------------------------
  -- Author  : WANGCONG
  -- Created : 2017/11/01
  -- Purpose : 销司商机引入总部
  ----------------------------------------------------------------------
  Procedure P_PG_SC_BUSINESS_SYNC(P_BUSINESS_ID IN NUMBER,P_ENTITY_ID IN NUMBER,P_MESSAGE OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- author  : huanghb12
  -- created : 2018/02/28 16:34:40
  -- purpose : 工程机核销单录入
  ----------------------------------------------------------------------
  --输入项：p_header_id 核销头接口表id
  --输出项：p_Result 记录错误信息  
  Procedure P_PG_VERIFICATION(p_header_id in number, p_Result Out Varchar2);
  
  ----------------------------------------------------------------------  
  -- Author  : huanghb12
  -- Created : 2018/03/21
  -- Purpose : 工程机核销CCS驳回
  ----------------------------------------------------------------------
  Procedure P_PG_VERIFICATION_REJECT(CSS_ID IN NUMBER,P_REJECT_REASON IN VARCHAR2,P_MESSAGE OUT VARCHAR2);
  
  ----------------------------------------------------------------------
  
  ----------------------------------------------------------------------  
  -- Author  : xiaoxu
  -- Created : 2018/03/21
  -- Purpose : 工程机核销CCS撤回（CCS调用）
  ----------------------------------------------------------------------
  PROCEDURE P_PG_VERIFICATION_REVOKE(IN_VERI_HEADER_ID IN NUMBER    --核销单ID
                                    ,IS_REVOKE_REASON  IN VARCHAR2  --撤回原因
                                    ,OS_MESSAGE        OUT VARCHAR2 --返回信息：OK表示成功，其它表示出错信息
                                     );
  ----------------------------------------------------------------------
 
 
  ----------------------------------------------------------------------
  -- Author  : zhouly2
  -- Created : 2018/08/01
  -- Purpose : 工程机附件
  ----------------------------------------------------------------------

  PROCEDURE P_PG_BUSINESS_FILE_TRANSFER(P_INTF_HEAD_ID IN NUMBER,
                                        V_SUCCESS      IN VARCHAR2,
                                        P_MESSAGE      IN OUT VARCHAR2,
                                        V_APPENDIX_ID  OUT VARCHAR2);
                                        
  -- Author  : tangjz2
  -- Created : 2018/09/10
  -- Purpose : CCS发起的商机调整     P_INTF_HEAD_ID为接口表新单据对应的ID
  ----------------------------------------------------------------------
  Procedure P_PG_BUSINESS_CCS_ADJUST(P_INTF_HEAD_ID IN NUMBER,P_MESSAGE OUT VARCHAR2);
  
  -- Author  : tangjz2
  -- Created : 2018/09/10
  -- Purpose : CCS发起的商机调整校验   P_INTF_HEAD_ID为接口表旧单据对应的ID
  ----------------------------------------------------------------------
  Procedure P_PG_BUSINESS_CCS_ADJ_VERIFY(P_INTF_HEAD_ID IN NUMBER, P_RESULT OUT VARCHAR2);
END PKG_PG_INTF;
/

