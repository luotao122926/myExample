create view V_ACCOUNT_AGE_DAY as
select '' as area_name,
       t1.code as center_code,
       t1.name as center_name,
       t.customer_code,
       t.customer_name,
       t.age_date,
       1.1 as is_close_account,
       1.1 as accounts_a_month,
       1.1 as accounts_two_months,
       1.1 as accounts_two_point_five_months,
       1.1 as accounts_three_months,
       1.1 as accounts_four_months,
       1.1 as accounts_five_months,
       1.1 as accounts_six_months,
       1.1 as accounts_seven_months,
       1.1 as accounts_eight_months,
       1.1 as accounts_nine_months,
       1.1 as accounts_ten_months,
       1.1 as accounts_eleven_months,
       1.1 as accounts_twelve_months,
       1.1 as accounts_more_months,
       1.1 as not_settled_amount,
       1.1 as customer_overdue_amount,
       '' as entity_name
  from T_SO_ACCOUNT_AGE t, UP_ORG_UNIT t1
 where t1.unit_id = t.entity_id
/

