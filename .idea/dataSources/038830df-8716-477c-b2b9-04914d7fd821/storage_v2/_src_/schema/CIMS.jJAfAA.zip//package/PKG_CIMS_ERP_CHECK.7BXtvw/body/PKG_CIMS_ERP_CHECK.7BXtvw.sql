create package body      PKG_CIMS_ERP_Check
 is
 --01  组织间转移   02 子库转移  07  正常采购-关联交易  08 退货-关联交易  09 反向销售-关联交易  05 外部采购  06 外部采购退货

/*
create sequence S_Ims_ERP_Check_N;
create table T_IMS_ERP_Check
(
    Check_id number,
    order_type varchar2(50),
    transaction_type varchar2(50),
    entity_id number,
    business_num varchar2(50),
    transaction_date date,
    inv_code varchar2(50),
    cims_qty number,
    gerp_qty number,
    error_mess varchar2(1000),
    ERP_Error varchar2(4000),
    error_flag varchar2(1),
    constraint IDX_IMS_ERP_Check_PK primary key(Check_id)
);

comment on column T_IMS_ERP_Check.Check_id is 'ID、唯一索引';
comment on column T_IMS_ERP_Check.order_type is '单据类型（采购单、销售单）';
comment on column T_IMS_ERP_Check.transaction_type is '事务类型（ICP关联交易、PO采购、PO子库转移、SO子库转移、SO结算、推广发放、调拨发出、调拨接收、盘点）';
comment on column T_IMS_ERP_Check.entity_id is '主体ID';
comment on column T_IMS_ERP_Check.business_num is '单据号';
comment on column T_IMS_ERP_Check.transaction_date is '单据事务日期（发生库存事务的日期，采购单执行日期；销售单审核、结算日期；调拨单审核、接收日期，推广发放发放日期、盘点执行日期）';
comment on column T_IMS_ERP_Check.inv_code is '仓库编码';
comment on column T_IMS_ERP_Check.cims_qty is 'CIMS数量';
comment on column T_IMS_ERP_Check.gerp_qty is 'GERP数量';
comment on column T_IMS_ERP_Check.error_mess is '错误类型';
comment on column T_IMS_ERP_Check.ERP_Error is 'ERP-ESB返回的错误信息';
comment on column T_IMS_ERP_Check.error_flag is '错误标志，Y为错误，N为正确';

Create Index IDX_IMS_ERP_Check_N01 On T_IMS_ERP_Check(order_type)  Tablespace CIMSX;
Create Index IDX_IMS_ERP_Check_N02 On T_IMS_ERP_Check(business_num,entity_id)  Tablespace CIMSX;
Create Index IDX_IMS_ERP_Check_N03 On T_IMS_ERP_Check(transaction_date,entity_id)  Tablespace CIMSX;
Create Index IDX_IMS_ERP_Check_N04 On T_IMS_ERP_Check(inv_code,entity_id)  Tablespace CIMSX;
Create Index IDX_IMS_ERP_Check_N04 On T_IMS_ERP_Check(error_flag,entity_id)  Tablespace CIMSX;
*/

  procedure p_inv_check(p_begin_date date,p_end_date date)
        is
                   v_Begin_Date varchar2(20);
                   v_End_Date varchar2(20);
        begin

             if to_char(sysdate,'hh24') >= '06' then
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '超过6点，停止运行' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                    from dual;
               commit;
               return;
             end if;
             
               v_Begin_Date := to_char(p_begin_date,'yyyy-mm-dd');
               v_End_Date := to_char(p_end_date,'yyyy-mm-dd');

               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    'PO关联交易开始' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;

                commit;

               --中转单-- 关联交易触发库存事务(所有）
               insert into cims.T_IMS_ERP_Check
                      (check_id,
                       order_type,
                       transaction_type,
                       entity_id,
                       business_num,
                       transaction_date,
                       inv_code,
                       error_flag,
                       gerp_qty)
                       select S_Ims_ERP_Check_N.nextval,
                             order_type,
                             transaction_type,
                             entity_id,
                             business_num,
                             transaction_date,
                             inv_code,
                             error_flag,
                             gerp_qty
                        from (
                              select /*+leading(ph) use_nl(ph,inv_erp)*/
                                     '采购单' order_type,
                                     'ICP关联交易' transaction_type,
                                     ph.entity_id,
                                     ph.po_num business_num,
                                     ph.exec_date transaction_date,
                                     ph.inv_finance_code inv_code,
                                     'Z' error_flag,
                                     sum(inv_erp.transaction_quantity) gerp_qty
                                from cims.t_inv_po_headers                      ph,
                                     cims.t_inv_inventories ii,
                                     apps.mtl_material_transactions@mdims2mderp inv_erp
                               where ph.exec_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                                 and ph.exec_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                                 and ii.inventory_code = ph.inv_finance_code
                                 and ii.entity_id = ph.entity_id
                                 and ph.entity_id not in(28,29,32)
                                 and inv_erp.organization_id = ii.organization_id
                                 and inv_erp.attribute11 = 'CIMS'
                                 and inv_erp.attribute13 = decode(ph.source_type,'销售单',ph.sched_order_num,'销售转采购',ph.sched_order_num,ph.po_num) --如果source_type为销售单，证明该单据是由销售单生成的，需要使用sched_order_num来查询库存事务
                                 and inv_erp.subinventory_code = ph.inv_finance_code
                                 and inv_erp.attribute_category = 'ICP'
                                 --and inv_erp.transaction_date = to_date(V_End_Date, 'yyyy-mm-dd')
                                 and not exists(select 1 from T_IMS_ERP_Check iec
                                                         where iec.business_num = ph.po_num
                                                               and iec.order_type = '采购单')
                               group by '采购单',
                                        'ICP关联交易',
                                        ph.entity_id,
                                        ph.po_num,
                                        ph.exec_date,
                                        ph.inv_finance_code,
                                        'Z');

               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    'PO关联交易结束' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;

                   commit;

            if to_char(sysdate,'hh24') >= '06' then
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '超过6点，停止运行' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                    from dual;
               commit;
               return;
             end if;
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    'PO采购开始' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;
                   commit;

                   --中转单--po（采购-非关联交易）
                   insert into cims.T_IMS_ERP_Check
                      (check_id,
                       order_type,
                       transaction_type,
                       entity_id,
                       business_num,
                       transaction_date,
                       inv_code,
                       error_flag,
                       gerp_qty)
                       select S_Ims_ERP_Check_N.nextval,
                              order_type,
                              transaction_type,
                              entity_id,
                              business_num,
                              transaction_date,
                              inv_code,
                              error_flag,
                              gerp_qty
                       from (
                            select  /*+leading(ph) use_nl(ph,po_rcv)*/
                                    '采购单' order_type,
                                   'PO采购' transaction_type,
                                   ph.entity_id,
                                   ph.po_num business_num,
                                   ph.exec_date transaction_date,
                                   ph.inv_finance_code inv_code,
                                   'Z' error_flag,
                                   sum(po_rcv.quantity*decode(po_rcv.transaction_type,'DELIVER',1,-1)) gerp_qty
                              from cims.t_inv_po_headers             ph,
                                   cims.t_inv_bill_types bt,
                                   --apps.po_headers_all@mdims2mderp   po_erp,
                                   apps.rcv_transactions@mdims2mderp po_rcv
                             where ph.exec_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                               and ph.exec_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                               and ph.erp_trancation in('05','06')
                               and ph.po_type_id = bt.bill_type_id
                               and ph.entity_id not in(28,29,32)
                               --and po_erp.segment1 = decode(bt.cancel_flag, 'Y', ph.OLD_PO_NUM, ph.po_num)
                               --and po_erp.po_header_id = po_rcv.po_header_id
                               and po_rcv.INTERFACE_SOURCE_CODE = 'CIMS'
                               --and decode(bt.cancel_flag, 'Y',po_rcv.from_subinventory,po_rcv.subinventory)= ph.inv_finance_code
                               and po_rcv.transaction_type in ('DELIVER', 'RETURN TO RECEIVING')
                               and po_rcv.transaction_date = to_date(V_End_Date, 'yyyy-mm-dd')
                               and po_rcv.attribute5 = ph.po_num
                               and po_rcv.attribute12 = 'C-IMS'
                               and not exists(select 1 from T_IMS_ERP_Check iec
                                                       where iec.business_num = ph.po_num
                                                             and iec.order_type = '采购单')
                             group by '采购单',
                                      'PO采购',
                                      ph.entity_id,
                                      ph.po_num,
                                      ph.exec_date,
                                      ph.inv_finance_code,
                                      'Z');

                     commit;

                     insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    'PO采购结束' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;
               commit;

            if to_char(sysdate,'hh24') >= '06' then
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '超过6点，停止运行' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                    from dual;
               commit;
               return;
             end if;

               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    'PO中转子库转移开始' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;
                 commit;
                 -- 中转单--组织间子库存转移、子库转移
                 insert into cims.T_IMS_ERP_Check
                      (check_id,
                       order_type,
                       transaction_type,
                       entity_id,
                       business_num,
                       transaction_date,
                       inv_code,
                       error_flag,
                       gerp_qty)
                     select S_Ims_ERP_Check_N.nextval,
                              order_type,
                              transaction_type,
                              entity_id,
                              business_num,
                              transaction_date,
                              inv_code,
                              error_flag,
                              gerp_qty
                       from (
                            select /*+leading(ph) use_nl(ph,inv_erp)*/ 
                                    '采购单' order_type,
                                   'PO子库转移' transaction_type,
                                   ph.entity_id,
                                   ph.po_num business_num,
                                   ph.exec_date transaction_date,
                                   ph.inv_finance_code inv_code,
                                   'Z' error_flag,
                                   sum(inv_erp.transaction_quantity) gerp_qty
                              from cims.t_inv_po_headers                      ph,
                                   cims.t_inv_inventories ii,
                                   apps.mtl_material_transactions@mdims2mderp inv_erp
                             where ph.exec_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                               and ph.exec_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                               and ii.inventory_code = ph.inv_finance_code
                               and ii.entity_id = ph.entity_id
                               and ph.entity_id not in(28,29,32)
                               and inv_erp.organization_id = ii.organization_id
                               and inv_erp.subinventory_code = ph.inv_finance_code
                               and inv_erp.transaction_reference = ph.po_num
                               and inv_erp.source_code = 'CIMS'
                               --and inv_erp.transaction_date = to_date(V_End_Date, 'yyyy-mm-dd')
                               and not exists(select 1 from T_IMS_ERP_Check iec
                                                       where iec.business_num = ph.po_num
                                                             and iec.order_type = '采购单')
                             group by '采购单',
                                      'PO子库转移',
                                      ph.entity_id,
                                      ph.po_num,
                                      ph.exec_date,
                                      ph.inv_finance_code,
                                      'Z');

               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    'PO中转子库转移结束' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;
                 commit;

                    --cims_qty
                    update cims.T_IMS_ERP_Check iec
                       set cims_qty =
                           (select sum(pl.billed_qty *decode(t.action_type, '01', 1, '02', -1, 1))
                              from cims.t_inv_po_headers ph
                                   ,cims.t_inv_po_lines pl
                                   ,cims.t_inv_bill_types b
                                   ,cims.t_inv_transaction_types t
                             where ph.po_id = pl.po_id
                               and iec.business_num = ph.po_num
                               and ph.entity_id = b.entity_id
                               and ph.po_type_id = b.bill_type_id
                               and b.transaction_type_id = t.transaction_type_id
                               )
                     where order_type = '采购单'
                       and iec.transaction_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                       and iec.transaction_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                       and iec.error_flag = 'Z';

                 commit;

            if to_char(sysdate,'hh24') >= '06' then
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '超过6点，停止运行' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                    from dual;
               commit;
               return;
             end if;

                 -- 01  组织间转移   02 子库转移  07  正常采购-关联交易  08 退货-关联交易  09 反向销售-关联交易  05 外部采购  06 外部采购退货



               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    'SO子库转移开始' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;
                 commit;

              --销售单子库转移，按照审核日期处理，biz_src_bill_type_code('1001'销售, '1002'销售红冲, '1003'退货, '1004'退货红冲)
               insert into cims.T_IMS_ERP_Check
                        (check_id,
                         order_type,
                         transaction_type,
                         entity_id,
                         business_num,
                         transaction_date,
                         inv_code,
                         error_flag,
                         gerp_qty)
                        select S_Ims_ERP_Check_N.nextval,
                                order_type,
                                transaction_type,
                                entity_id,
                                business_num,
                                transaction_date,
                                inv_code,
                                error_flag,
                                gerp_qty
                            from
                            (
                              select /*+leading(sh) use_nl(sh,inv_erp)*/
                                     '销售单' order_type,
                                     'SO子库转移' transaction_type,
                                     sh.entity_id,
                                     sh.so_num business_num,
                                     sh.so_date transaction_date,
                                     nvl(sh.ship_inv_code, sh.CONSIGNEE_INV_CODE) inv_code,
                                     'Z' error_flag,
                                     sum(inv_erp.transaction_quantity) gerp_qty
                                from cims.t_so_header                           sh,
                                     cims.t_inv_inventories ii,
                                     apps.mtl_material_transactions@mdims2mderp inv_erp
                               where sh.so_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                                 and sh.so_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                                 and sh.audit_flag = 'Y'
                                 and sh.biz_src_bill_type_code in
                                   ('1001', '1002', '1003', '1004')
                                 and ii.entity_id = sh.entity_id
                                 and sh.entity_id not in(28,29,32)
                                 and ii.inventory_code = nvl(sh.ship_inv_code, sh.CONSIGNEE_INV_CODE)
                                 and inv_erp.organization_id = ii.organization_id
                                 and inv_erp.transaction_reference = sh.so_num
                                 and inv_erp.subinventory_code = nvl(sh.ship_inv_code, sh.CONSIGNEE_INV_CODE)
                                 and inv_erp.transfer_subinventory = sh.middle_inv_code
                                 and inv_erp.source_code = 'CIMS'
                                 --and inv_erp.transaction_date = to_date(V_End_Date, 'yyyy-mm-dd')
                                 and not exists(select 1 from cims.T_IMS_ERP_Check iec
                                                       where iec.business_num = sh.so_num
                                                             and iec.order_type = '销售单'
                                                             and iec.transaction_type = 'SO子库转移')
                               group by '销售单',
                                        'SO子库转移',
                                        sh.entity_id,
                                        sh.so_num,
                                        sh.so_date,
                                        nvl(sh.ship_inv_code, sh.CONSIGNEE_INV_CODE),
                                        'Z');

                   insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    'SO子库转移结束' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;
                  commit;

            if to_char(sysdate,'hh24') >= '06' then
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '超过6点，停止运行' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                    from dual;
               commit;
               return;
             end if;

              --销售单关联交易PO接收，按照关联交易接收日期处理，biz_src_bill_type_code('1001'销售, '1002'销售红冲, '1003'退货, '1004'退货红冲)
              insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    'SO关联交易-供方开始' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;
                  commit;
                  
            insert into cims.T_IMS_ERP_Check
                        (check_id,
                         order_type,
                         transaction_type,
                         entity_id,
                         business_num,
                         transaction_date,
                         inv_code,
                         error_flag,
                         gerp_qty)
                        select S_Ims_ERP_Check_N.nextval,
                                order_type,
                                transaction_type,
                                entity_id,
                                business_num,
                                transaction_date,
                                inv_code,
                                error_flag,
                                gerp_qty
                            from
                            (
                              select /*+leading(sh) use_nl(sh,inv_erp)*/
                                     '销售单' order_type,
                                     'SO事业部间关联交易-供方' transaction_type,
                                     sh.entity_id,
                                     sh.so_num business_num,
                                     sh.ERP_LOGIST_RECEIVE_DATE transaction_date,
                                     sh.nosettled_inventory_code inv_code,
                                     'Z' error_flag,
                                     sum(inv_erp.transaction_quantity) gerp_qty
                                from cims.t_so_header                           sh,
                                     cims.t_inv_inventories ii,
                                     apps.mtl_material_transactions@mdims2mderp inv_erp
                               where sh.ERP_LOGIST_RECEIVE_DATE >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                                 and sh.ERP_LOGIST_RECEIVE_DATE < to_date(V_End_Date, 'yyyy-mm-dd')+1
                                 and sh.ERP_LOGIST_RECEIVE_FLAG = 'Y'
                                 and sh.middle_inv_code <> sh.nosettled_inventory_code
                                 and sh.biz_src_bill_type_code in   ('1001', '1002', '1003', '1004')
                                 and sh.entity_id not in(28,29,32)
                                 and ii.entity_id = sh.entity_id
                                 and ii.inventory_code = sh.middle_inv_code
                                 and inv_erp.organization_id = ii.organization_id
                                 and inv_erp.transaction_reference = sh.so_num
                                 and inv_erp.subinventory_code = sh.middle_inv_code
                                 and inv_erp.transfer_subinventory = sh.nosettled_inventory_code
                                 and inv_erp.source_code = 'CIMS'
                                 --and inv_erp.transaction_date = to_date(V_End_Date, 'yyyy-mm-dd')
                                 and not exists(select 1 from cims.T_IMS_ERP_Check iec
                                                       where iec.business_num = sh.so_num
                                                             and iec.order_type = '销售单'
                                                             and iec.transaction_type = 'SO事业部间关联交易-供方')
                               group by '销售单',
                                        'SO事业部间关联交易-供方',
                                        sh.entity_id,
                                        sh.so_num,
                                        sh.ERP_LOGIST_RECEIVE_DATE,
                                        sh.nosettled_inventory_code,
                                        'Z');

                   insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    'SO事业部间关联交易-供方结束' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;
                  commit;

            if to_char(sysdate,'hh24') >= '06' then
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '超过6点，停止运行' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                    from dual;
               commit;
               return;
             end if;

  --2017.1.9需方关联交易
  --销售单关联交易PO接收，按照关联交易接收日期处理，biz_src_bill_type_code('1001'销售, '1002'销售红冲, '1003'退货, '1004'退货红冲)
              insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    'SO事业部间关联交易-需方开始' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;
                  commit;
                  
            insert into cims.T_IMS_ERP_Check
                        (check_id,
                         order_type,
                         transaction_type,
                         entity_id,
                         business_num,
                         transaction_date,
                         inv_code,
                         error_flag,
                         gerp_qty)
                        select S_Ims_ERP_Check_N.nextval,
                                order_type,
                                transaction_type,
                                entity_id,
                                business_num,
                                transaction_date,
                                inv_code,
                                error_flag,
                                gerp_qty
                            from
                            (
                              select /*+leading(sh) use_nl(sh,inv_erp)*/
                                     '销售单' order_type,
                                     'SO事业部间关联交易-需方子库转移' transaction_type,
                                     sh.entity_id,
                                     sh.so_num business_num,
                                     sh.ERP_LOGIST_RECEIVE_DATE transaction_date,
                                     sh.nosettled_inventory_code inv_code,
                                     'Z' error_flag,
                                     sum(inv_erp.transaction_quantity) gerp_qty
                                from cims.t_so_header                           sh,
                                     apps.mtl_material_transactions@mdims2mderp inv_erp
                               where sh.ERP_LOGIST_RECEIVE_DATE >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                                 and sh.ERP_LOGIST_RECEIVE_DATE < to_date(V_End_Date, 'yyyy-mm-dd')+1
                                 and sh.ERP_LOGIST_RECEIVE_FLAG = 'Y'
                                 and sh.entity_id not in(28,29,32)
                                 and sh.middle_inv_code <> sh.nosettled_inventory_code
                                 and sh.biz_src_bill_type_code in   ('1001', '1002', '1003', '1004')
                                 and inv_erp.attribute11 = 'CIMS'
                                 and inv_erp.attribute13 = 'G'||sh.so_num
                                 and inv_erp.attribute_category = 'ICP'
                                 --and inv_erp.transaction_date = to_date(V_End_Date, 'yyyy-mm-dd')
                                 and not exists(select 1 from cims.T_IMS_ERP_Check iec
                                                       where iec.business_num = sh.so_num
                                                             and iec.order_type = '销售单'
                                                             and iec.transaction_type = 'SO事业部间关联交易-需方子库转移')
                               group by '销售单',
                                        'SO事业部间关联交易-需方子库转移',
                                        sh.entity_id,
                                        sh.so_num,
                                        sh.ERP_LOGIST_RECEIVE_DATE,
                                        sh.nosettled_inventory_code,
                                        'Z');

                   insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    'SO事业部间关联交易-需方结束' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;
                  commit;     
  
            if to_char(sysdate,'hh24') >= '06' then
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '超过6点，停止运行' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                    from dual;
               commit;
               return;
             end if;

   --1001 销售单,1002 销售红冲单,1003 退货单,1004 退货红冲单

        --销售结算（SO）
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    'SO结算开始' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;
                 commit;

                 insert into cims.T_IMS_ERP_Check
                   (check_id,
                    order_type,
                    transaction_type,
                    entity_id,
                    business_num,
                    transaction_date,
                    inv_code,
                    error_flag,
                    gerp_qty)
                    select S_Ims_ERP_Check_N.nextval,
                          order_type,
                          transaction_type,
                          entity_id,
                          business_num,
                          transaction_date,
                          inv_code,
                          error_flag,
                          gerp_qty
                    from
                    (
                       select /*+leading(so) use_nl(so,mso)*/
                             '销售单' order_type,
                              'SO结算' transaction_type,
                              so.entity_id,
                              so.so_num business_num,
                              so.settle_date transaction_date,
                              so.nosettled_inventory_code inv_code,
                              'Z' error_flag,
                              sum(mmt.transaction_quantity) gerp_qty
                         FROM cims.t_so_header                           so,
                              cims.t_inv_organization io,
                              apps.mtl_sales_orders@mdims2mderp          mso,
                              apps.mtl_material_transactions@mdims2mderp mmt
                        where so.settle_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                          and so.settle_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                          and so.entity_id not in(28,29,32)
                          and so.entity_id = io.entity_id
                          and so.erp_ou_id = io.operating_unit
                          --and nvl(so.entity_cust_flag,'N') = 'N' --由于是单边关联交易，不再对内外部客户做分别处理（20170104）。
                          and mso.segment1 = TO_CHAR(so.so_num)
                          and mmt.transaction_source_id = mso.sales_order_id
                          and mmt.organization_id = io.organization_id
                             --transaction_source_type_id,2,8,12退货
                          and mmt.transaction_source_type_id IN (2, 8, 12)
                             --transaction_type_id 15 退货，33销售
                          and mmt.transaction_type_id in (33, 15)
                          --and mmt.organization_id in(275,795,800,802,782,588,589,596,120,122,807,582,809)
                          and mmt.transaction_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                          and mmt.transaction_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                          and not exists(select 1 from cims.T_IMS_ERP_Check iec
                                                     where iec.business_num = so.so_num
                                                           and iec.order_type = '销售单'
                                                           and iec.transaction_type = 'SO结算')
                        group by '销售单',
                                 'SO结算',
                                 so.entity_id,
                                 so.so_num,
                                 so.settle_date,
                                 so.nosettled_inventory_code,
                                 'Z');

               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    'SO结算结束' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;
               commit;

            if to_char(sysdate,'hh24') >= '06' then
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '超过6点，停止运行' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                    from dual;
               commit;
               return;
             end if;

               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    'SO关联交易开始-拉式' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;

               commit;

              
               --拉式关联交易
               insert into cims.T_IMS_ERP_Check
                      (check_id,
                       order_type,
                       transaction_type,
                       entity_id,
                       business_num,
                       transaction_date,
                       inv_code,
                       error_flag,
                       gerp_qty)
                       select S_Ims_ERP_Check_N.nextval,
                             order_type,
                             transaction_type,
                             entity_id,
                             business_num,
                             transaction_date,
                             inv_code,
                             error_flag,
                             gerp_qty
                        from (
                              select  /*+leading(so) use_nl(so,inv_erp)*/
                                    '销售单' order_type,
                                     'ICP关联交易' transaction_type,
                                     so.entity_id,
                                     so.so_num business_num,
                                     so.settle_date transaction_date,
                                     so.middle_inv_code inv_code,
                                     'Z' error_flag,
                                     sum(inv_erp.transaction_quantity) gerp_qty
                                from cims.t_so_header                      so,
                                     cims.t_so_type_extend bt,
                                     cims.t_inv_inventories ii,
                                     apps.mtl_material_transactions@mdims2mderp inv_erp
                               where so.settle_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                                 and so.settle_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                                 and ((so.entity_id in(14,15,17) and so.trx_mode = 'PULL'))
                                 and so.bill_type_id = bt.bill_type_id
                                 and so.entity_id = bt.entity_id
                                 and so.entity_id not in(28,29,32)
                                 and nvl(bt.promotion_flay,'N')='N'
                                 and ii.inventory_code = so.middle_inv_code
                                 and ii.entity_id = so.entity_id
                                 and inv_erp.organization_id = ii.organization_id
                                 and inv_erp.attribute11 = 'CIMS'
                                 and inv_erp.attribute13 = so.so_num
                                 and inv_erp.subinventory_code = so.nosettled_inventory_code
                                 --and inv_erp.transaction_date = to_date(V_End_Date, 'yyyy-mm-dd')
                                 and not exists(select 1 from T_IMS_ERP_Check iec
                                                         where iec.business_num = so.so_num
                                                               and iec.order_type = '销售单'
                                                               and iec.transaction_type = 'ICP关联交易')
                               group by '销售单',
                                        'ICP关联交易',
                                        so.entity_id,
                                        so.so_num,
                                        so.settle_date,
                                        so.middle_inv_code,
                                        'Z');

                 insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    'SO关联交易结束-拉式' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;

                 commit;



               update cims.T_IMS_ERP_Check iec
                       set cims_qty =
                           (select sum(sld.component_qty*decode(so.biz_src_bill_type_code,'1001',-1, '1002',1, '1003',1, '1004',-1))
                              from cims.t_so_header so, cims.t_so_line_detail sld
                             where so.so_num = iec.business_num
                               and so.so_header_id = sld.so_header_id)
                     where iec.order_type = '销售单'
                           and iec.transaction_type <> 'SO事业部间关联交易-需方子库转移'
                           and iec.transaction_date>= to_date(V_Begin_Date, 'yyyy-mm-dd')
                           and iec.transaction_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                           and iec.error_flag = 'Z';
                           
                  update cims.T_IMS_ERP_Check iec
                       set cims_qty =
                           (select sum(sld.component_qty*decode(so.biz_src_bill_type_code,'1001',1, '1002',-1, '1003',-1, '1004',1))
                              from cims.t_so_header so, cims.t_so_line_detail sld
                             where so.so_num = iec.business_num
                               and so.so_header_id = sld.so_header_id)
                     where iec.order_type = '销售单'
                           and iec.transaction_type = 'SO事业部间关联交易-需方子库转移'
                           and iec.transaction_date>= to_date(V_Begin_Date, 'yyyy-mm-dd')
                           and iec.transaction_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                           and iec.error_flag = 'Z';

              commit;

            if to_char(sysdate,'hh24') >= '06' then
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '超过6点，停止运行' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                    from dual;
               commit;
               return;
             end if;

             --推广物料
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '推广物料开始' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;

                commit;

                insert into cims.T_IMS_ERP_Check
                      (check_id,
                       order_type,
                       transaction_type,
                       entity_id,
                       business_num,
                       transaction_date,
                       inv_code,
                       error_flag,
                       gerp_qty)
                    select S_Ims_ERP_Check_N.nextval,
                           order_type,
                           transaction_type,
                           entity_id,
                           business_num,
                           transaction_date,
                           inv_code,
                           error_flag,
                           gerp_qty
                      from
                      (
                          select  /*+leading(sh) use_nl(sh,inv_erp)*/
                                 '推广领用' order_type,
                                 '推广发放' transaction_type,
                                 sh.entity_id entity_id,
                                 sh.pmt_send_num business_num,
                                 sh.send_date transaction_date,
                                 sh.ship_inventory_code inv_code,
                                 'Z' error_flag,
                                 sum(inv_erp.transaction_quantity) gerp_qty
                            from cims.T_PMT_COLLAR_SEND_HEAD                sh,
                                 cims.t_inv_inventories ii,
                                 apps.mtl_material_transactions@mdims2mderp inv_erp
                           where sh.send_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                             and sh.send_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                             and sh.entity_id not in(28,29,32)
                             and ii.inventory_code = sh.ship_inventory_code
                             and ii.entity_id = sh.entity_id
                             and inv_erp.organization_id = ii.organization_id
                             and inv_erp.transaction_reference = sh.pmt_send_num
                             and inv_erp.subinventory_code = sh.ship_inventory_code
                             and inv_erp.source_code = 'CIMS'
                             --and inv_erp.transaction_date = to_date(V_End_Date, 'yyyy-mm-dd')
                             and not exists(select 1 from cims.T_IMS_ERP_Check iec
                                                       where iec.business_num = sh.pmt_send_num
                                                             and iec.order_type = '推广领用')
                           group by '推广领用',
                                    '推广发放',
                                    sh.entity_id,
                                    sh.pmt_send_num,
                                    sh.send_date,
                                    sh.ship_inventory_code,
                                    'Z');

               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '推广物料结束' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;

                commit;

                update cims.T_IMS_ERP_Check iec
                    set cims_qty =
                        (select sum(sl.rcv_qty * decode(t.action_type, '01', 1, '02', -1, 1))
                           from cims.T_PMT_COLLAR_SEND_HEAD sh
                                ,cims.t_pmt_collar_send_line sl
                                ,cims.t_inv_bill_types b
                                ,cims.t_inv_transaction_types t
                          where sh.collar_send_head_id = sl.collar_send_head_id
                            and iec.business_num = sh.pmt_send_num
                            and sh.entity_id = b.entity_id
                            and sh.bill_type_id = b.bill_type_id
                            and b.transaction_type_id = t.transaction_type_id
                            )
                  where iec.order_type = '推广领用'
                        and iec.transaction_date>= to_date(V_Begin_Date, 'yyyy-mm-dd')
                        and iec.transaction_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                        and iec.error_flag = 'Z';

                 commit;

            if to_char(sysdate,'hh24') >= '06' then
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '超过6点，停止运行' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                    from dual;
               commit;
               return;
             end if;


         --调拨发出
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '调拨发出开始' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;

                commit;

                insert into cims.T_IMS_ERP_Check
                     (check_id,
                      order_type,
                      transaction_type,
                      entity_id,
                      business_num,
                      transaction_date,
                      inv_code,
                      error_flag,
                      gerp_qty)
                      select S_Ims_ERP_Check_N.nextval,
                            order_type,
                            transaction_type,
                            entity_id,
                            business_num,
                            transaction_date,
                            inv_code,
                            error_flag,
                            gerp_qty
                        from
                        (
                             select   /*+leading(sh) use_nl(sh,inv_erp)*/
                                    '调拨单' order_type,
                                    '调拨发出' transaction_type,
                                    sh.entity_id entity_id,
                                    sh.trsf_order_num business_num,
                                    sh.audit_date transaction_date,
                                    sh.ship_inv_code inv_code,
                                    'Z' error_flag,
                                    sum(inv_erp.transaction_quantity*decode(bt.cancel_flag,'Y',-1,1)) gerp_qty
                               from cims.t_inv_trsf_order  sh,
                                    cims.t_inv_bill_types bt,
                                    cims.t_inv_inventories ii,
                                    apps.mtl_material_transactions@mdims2mderp inv_erp
                              where sh.audit_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                                and sh.audit_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                                and sh.entity_id not in(28,29,32)
                                and sh.ship_inv_code <> sh.consignee_inv_code
                                and sh.bill_type_id = bt.bill_type_id
                                and sh.entity_id = bt.entity_id
                                and ii.inventory_code = sh.ship_inv_code
                                and ii.entity_id = sh.entity_id
                                and inv_erp.organization_id = ii.organization_id
                                and inv_erp.transaction_reference = sh.trsf_order_num
                                and inv_erp.subinventory_code = decode(bt.cancel_flag,'Y',sh.consignee_inv_code,sh.ship_inv_code)
                                and inv_erp.source_code = 'CIMS'
                                and inv_erp.transfer_subinventory = nvl(sh.traveling_inv_code, sh.consignee_inv_code)and inv_erp.transaction_date = to_date(V_End_Date, 'yyyy-mm-dd')
                                and not exists(select 1 from cims.T_IMS_ERP_Check iec
                                                         where iec.business_num = sh.trsf_order_num
                                                               and iec.order_type = '调拨单'
                                                               and iec.transaction_type = '调拨发出')
                              group by '调拨单',
                                       '调拨发出',
                                       sh.entity_id,
                                       sh.trsf_order_num,
                                       sh.audit_date,
                                       sh.ship_inv_code,
                                       'Z');

               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '调拨发出结束' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;

                commit;

            if to_char(sysdate,'hh24') >= '06' then
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '超过6点，停止运行' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                    from dual;
               commit;
               return;
             end if;


        --调拨接收
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '调拨接收开始' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;

                commit;

                insert into cims.T_IMS_ERP_Check
                       (check_id,
                        order_type,
                        transaction_type,
                        entity_id,
                        business_num,
                        transaction_date,
                        inv_code,
                        error_flag,
                        gerp_qty)
                        select S_Ims_ERP_Check_N.nextval,
                              order_type,
                              transaction_type,
                              entity_id,
                              business_num,
                              transaction_date,
                              inv_code,
                              error_flag,
                              gerp_qty
                        from
                        (
                          select   /*+leading(sh) use_nl(sh,inv_erp)*/
                              '调拨单' order_type,
                              '调拨接收' transaction_type,
                              sh.entity_id entity_id,
                              sh.trsf_order_num business_num,
                              sh.rcv_date transaction_date,
                              sh.consignee_inv_code inv_code,
                              'Z' error_flag,
                              sum(inv_erp.transaction_quantity*decode(bt.cancel_flag,'Y',-1,1)) gerp_qty
                         from cims.t_inv_trsf_order                      sh,
                              cims.t_inv_bill_types bt,
                              cims.t_inv_inventories ii,
                              apps.mtl_material_transactions@mdims2mderp inv_erp
                        where sh.rcv_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                          and sh.rcv_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                          and sh.entity_id not in(28,29,32)
                          and sh.ship_inv_code <> sh.consignee_inv_code
                          and ii.inventory_code = sh.traveling_inv_code
                          and sh.bill_type_id = bt.bill_type_id
                          and sh.entity_id = bt.entity_id
                          and ii.entity_id = sh.entity_id
                          and inv_erp.organization_id = ii.organization_id
                          and inv_erp.transaction_reference = sh.trsf_order_num
                          and inv_erp.subinventory_code = sh.traveling_inv_code
                          and inv_erp.source_code = 'CIMS'
                          and inv_erp.transfer_subinventory = decode(bt.cancel_flag,'Y',sh.ship_inv_code,sh.consignee_inv_code)
                          --and inv_erp.transaction_date = to_date(V_End_Date, 'yyyy-mm-dd')
                          and not exists(select 1 from cims.T_IMS_ERP_Check iec
                                                 where iec.business_num = sh.trsf_order_num
                                                       and iec.order_type = '调拨单'
                                                       and iec.transaction_type = '调拨接收')
                        group by '调拨单',
                                 '调拨接收',
                                 sh.entity_id,
                                 sh.trsf_order_num,
                                 sh.rcv_date,
                                 sh.consignee_inv_code,
                                 'Z');

               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '调拨接收结束' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;
                    commit;

                    --更新调拨单的CIMS数量
                    update cims.T_IMS_ERP_Check iec
                        set cims_qty =
                            (select sum(sl.billed_qty * decode(b.cancel_flag,'Y',1,-1))
                               from cims.t_inv_trsf_order             sh,
                                    cims.t_inv_trsf_order_line_detail sl,
                                    cims.t_inv_bill_types b
                              where sh.trsf_order_id = sl.trsf_order_id
                                    and sh.bill_type_id = b.bill_type_id
                                    and sh.entity_id = b.entity_id
                                and iec.business_num = sh.trsf_order_num)
                      where iec.order_type = '调拨单'
                        and iec.transaction_date>= to_date(V_Begin_Date, 'yyyy-mm-dd')
                        and iec.transaction_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                        and iec.error_flag = 'Z';

                      commit;

            if to_char(sysdate,'hh24') >= '06' then
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '超过6点，停止运行' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                    from dual;
               commit;
               return;
             end if;


        --盘点单
        /*select * from cims.t_inv_check_orders;
        select * from cims.t_inv_check_order_lines;*/
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '盘点开始' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;

                   commit;

                   insert into cims.T_IMS_ERP_Check
                          (check_id,
                           order_type,
                           transaction_type,
                           entity_id,
                           business_num,
                           transaction_date,
                           inv_code,
                           error_flag,
                           gerp_qty)
                         select S_Ims_ERP_Check_N.nextval,
                               order_type,
                               transaction_type,
                               entity_id,
                               business_num,
                               transaction_date,
                               inv_code,
                               error_flag,
                               gerp_qty
                           from
                           (
                              select    /*+leading(sh) use_nl(sh,inv_erp)*/
                                    '盘点' order_type,
                                     '盘点' transaction_type,
                                     sh.entity_id entity_id,
                                     sh.check_order_num business_num,
                                     sh.exec_date transaction_date,
                                     sh.inv_code inv_code,
                                     'Z' error_flag,
                                     sum(inv_erp.transaction_quantity) gerp_qty
                                from cims.t_inv_check_orders                    sh,
                                     cims.t_inv_inventories ii,
                                     apps.mtl_material_transactions@mdims2mderp inv_erp
                               where sh.exec_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                                 and sh.exec_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                                 and sh.entity_id not in(28,29,32)
                                 and ii.inventory_code = sh.inv_code
                                 and ii.entity_id = sh.entity_id
                                 and inv_erp.organization_id = ii.organization_id
                                 and inv_erp.transaction_reference = sh.check_order_num
                                 and inv_erp.subinventory_code = sh.inv_code
                                 and inv_erp.source_code = 'CIMS'
                                 --and inv_erp.transaction_date = to_date(V_End_Date, 'yyyy-mm-dd')
                                 and not exists(select 1 from cims.T_IMS_ERP_Check iec
                                                     where iec.business_num = sh.check_order_num
                                                           and iec.order_type = '盘点')
                               group by '盘点',
                                        '盘点',
                                        sh.entity_id,
                                        sh.check_order_num,
                                        sh.exec_date,
                                        sh.inv_code,
                                        'Z');

               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '盘点结束' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;

                commit;

                update cims.T_IMS_ERP_Check iec
                              set cims_qty =
                                  (select sum(sl.billed_qty*decode(t.action_type, '01', 1, '02', -1, 1))
                                     from cims.t_inv_check_orders      sh
                                          ,cims.t_inv_check_order_lines sl
                                          ,cims.t_inv_bill_types b
                                          ,cims.t_inv_transaction_types t
                                    where sh.check_order_id = sl.check_order_id
                                      and sh.entity_id = b.entity_id
                                      and sh.check_order_type = b.bill_type_code
                                      and b.transaction_type_id = t.transaction_type_id
                                      and iec.business_num = sh.check_order_num)
                            where order_type = '盘点'
                              and iec.transaction_date>= to_date(V_Begin_Date, 'yyyy-mm-dd')
                              and iec.transaction_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                              and iec.error_flag = 'Z';

                commit;



                    --设置对账成功。

                    update cims.T_IMS_ERP_Check iec
                       set error_flag = 'N',iec.error_mess = '成功',erp_error = Null
                     where iec.gerp_qty = iec.cims_qty
                       and iec.transaction_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                       and iec.transaction_date < to_date(V_End_Date, 'yyyy-mm-dd')+1;

                     commit;

        end p_inv_check;
 ------------------------------------------------------------------------------------------------
 ------------------------------------------------------------------------------------------------
  --插入ERP中没有库存事务的单据
  procedure P_Inv_ERP_No_Trans
        is
          V_Begin_Date varchar2(15);
          v_end_date  varchar2(15);
        begin
          --每月1-5日，对账上一个月1日至今天的单据。5日后对本月的单据。
           if to_char(sysdate,'dd') <= '06' then
              V_Begin_Date := to_char(trunc(add_months(sysdate,-1),'MM'),'YYYY-MM-DD');
           else
              V_Begin_Date := to_char(trunc(sysdate,'mm'),'YYYY-MM-DD');
           end if;

           --取end_date
           if to_char(sysdate,'hh24') >'08' then
             v_end_date := to_char(trunc(sysdate),'YYYY-MM-DD');
           else
              v_end_date := to_char(trunc(sysdate-1),'YYYY-MM-DD');
           end if;

          --插入在同一区间内，ERP中没有库存事务的中转单
                    insert into cims.T_IMS_ERP_Check
                      (check_id,
                       order_type,
                       transaction_type,
                       entity_id,
                       business_num,
                       inv_code,
                       transaction_date,
                       error_mess,
                       error_flag,
                       cims_qty)
                       select S_Ims_ERP_Check_N.nextval,
                             order_type,
                             transaction_type,
                             entity_id,
                             business_num,
                             inv_code,
                             transaction_date,
                             error_mess,
                             error_flag,
                             cims_qty
                       from (
                            select '采购单' order_type,
                                   decode(ph.Erp_Trancation,
                                          '01',
                                          'PO子库转移',
                                          '02',
                                          'PO子库转移',
                                          '05',
                                          'PO采购',
                                          '06',
                                          'PO采购',
                                          '07',
                                          'ICP关联交易',
                                          '08',
                                          'ICP关联交易',
                                          '09',
                                          'ICP关联交易',
                                          '10',
                                          '推广物料发放',
                                          '11',
                                          '关联交易销售单接收',
                                          '12',
                                          '推广物料发放'
                                          ) transaction_type,
                                   ph.entity_id,
                                   ph.po_num business_num,
                                   ph.inv_finance_code inv_code,
                                   ph.exec_date transaction_date,
                                   'ERP相同周期内暂时未产生库存事务' error_mess,
                                   'Y' error_flag,
                                   sum(pl.billed_qty*decode(t.action_type, '01', 1, '02', -1, 1)) cims_qty
                              from cims.t_inv_po_headers ph
                                   ,cims.t_inv_po_lines pl
                                   ,cims.t_inv_bill_types b
                                   ,cims.t_inv_transaction_types t
                             where ph.exec_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                               and ph.exec_date <= to_date(V_End_Date, 'yyyy-mm-dd')
                               and ph.entity_id not in(28,29,32)
                               and ph.po_id = pl.po_id
                               and ph.po_type_id = b.bill_type_id
                               and ph.entity_id = b.entity_id
                               and b.transaction_type_id = t.transaction_type_id
                               and nvl(ph.close_flag,'N') = 'N'
                               and not exists (select 1
                                      from cims.T_IMS_ERP_Check iec
                                     where ph.po_num = iec.business_num
                                       and iec.order_type = '采购单')
                             group by '采购单',
                                      decode(ph.Erp_Trancation,
                                          '01',
                                          'PO子库转移',
                                          '02',
                                          'PO子库转移',
                                          '05',
                                          'PO采购',
                                          '06',
                                          'PO采购',
                                          '07',
                                          'ICP关联交易',
                                          '08',
                                          'ICP关联交易',
                                          '09',
                                          'ICP关联交易',
                                          '10',
                                          '推广物料发放',
                                          '11',
                                          '关联交易销售单接收',
                                          '12',
                                          '推广物料发放'
                                          ) ,
                                      ph.entity_id,
                                      ph.po_num,
                                      ph.inv_finance_code,
                                      ph.exec_date,
                                      'ERP相同周期内暂时未产生库存事务',
                                      'Y');

               commit;

          --插入没有做子库转移的销售单据。
                  insert into cims.T_IMS_ERP_Check
                      (check_id,
                       order_type,
                       transaction_type,
                       entity_id,
                       business_num,
                       inv_code,
                       transaction_date,
                       error_mess,
                       error_flag
                       ,cims_qty)
                       select S_Ims_ERP_Check_N.nextval,
                               order_type,
                               transaction_type,
                               entity_id,
                               business_num,
                               inv_code,
                               transaction_date,
                               error_mess,
                               error_flag
                               ,cims_qty
                       from (
                          select '销售单' order_type,
                                 'SO子库转移' transaction_type,
                                 so.entity_id,
                                 so.so_num business_num,
                                 nvl(so.ship_inv_code, so.CONSIGNEE_INV_CODE) inv_code,
                                 so.so_date transaction_date,
                                 decode(so.audit_flag,'N','单据未审核，无法引入ERP','ERP相同周期内暂时未产生子库转移的库存事务') error_mess,
                                 'Y' error_flag,
                                 sum(sld.component_qty*decode(so.biz_src_bill_type_code,'1001',-1, '1002',1, '1003',1, '1004',-1)) cims_qty
                            from cims.t_so_header so, cims.t_so_line_detail SLD
                           where so.so_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                             and so.so_date <= to_date(V_End_Date, 'yyyy-mm-dd')
                             and so.entity_id not in(28,29,32)
                             and so.so_header_id = sld.so_header_id
                             and so.biz_src_bill_type_code in
                                 ('1001', '1002', '1003', '1004')
                             and sld.item_qty <> 0
                             and not exists
                                         (select 1
                                                  from cims.T_IMS_ERP_Check iec
                                                 where so.so_num = iec.business_num
                                                   and iec.order_type = '销售单'
                                                   and iec.transaction_type = 'SO子库转移')
                              group by '销售单',
                                       'SO子库转移',
                                       so.entity_id,
                                       so.so_num,
                                       nvl(so.ship_inv_code,so.CONSIGNEE_INV_CODE),
                                       so.so_date,
                                       decode(so.audit_flag,'N','单据未审核，无法引入ERP','ERP相同周期内暂时未产生子库转移的库存事务'),
                                       'Y');

                       commit;

          --插入没有做SO关联交易--供方的销售单据。
                  insert into cims.T_IMS_ERP_Check
                      (check_id,
                       order_type,
                       transaction_type,
                       entity_id,
                       business_num,
                       inv_code,
                       transaction_date,
                       error_mess,
                       error_flag
                       ,cims_qty)
                       select S_Ims_ERP_Check_N.nextval,
                               order_type,
                               transaction_type,
                               entity_id,
                               business_num,
                               inv_code,
                               transaction_date,
                               error_mess,
                               error_flag
                               ,cims_qty
                       from (
                          select '销售单' order_type,
                                 'SO事业部间关联交易-供方' transaction_type,
                                 so.entity_id,
                                 so.so_num business_num,
                                 so.nosettled_inventory_code inv_code,
                                 so.ERP_LOGIST_RECEIVE_DATE transaction_date,
                                 'ERP相同周期内暂时未产生子库转移的库存事务' error_mess,
                                 'Y' error_flag,
                                 sum(sld.component_qty*decode(so.biz_src_bill_type_code,'1001',-1, '1002',1, '1003',1, '1004',-1)) cims_qty
                            from cims.t_so_header so, cims.t_so_line_detail SLD
                           where so.ERP_LOGIST_RECEIVE_DATE >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                             and so.ERP_LOGIST_RECEIVE_DATE < to_date(V_End_Date, 'yyyy-mm-dd')+1
                             and so.ERP_LOGIST_RECEIVE_FLAG = 'Y'
                             and so.entity_id not in(28,29,32)
                             and so.middle_inv_code <> so.nosettled_inventory_code
                             and so.so_header_id = sld.so_header_id
                             and so.biz_src_bill_type_code in   ('1001', '1002', '1003', '1004')
                             and sld.item_qty <> 0
                             and not exists
                                         (select 1
                                                  from cims.T_IMS_ERP_Check iec
                                                 where so.so_num = iec.business_num
                                                   and iec.order_type = '销售单'
                                                   and iec.transaction_type = 'SO事业部间关联交易-供方')
                              group by '销售单',
                                       'SO事业部间关联交易-供方',
                                       so.entity_id,
                                       so.so_num,
                                       so.nosettled_inventory_code,
                                       so.ERP_LOGIST_RECEIVE_DATE,
                                       'ERP相同周期内暂时未产生子库转移的库存事务',
                                       'Y');

                       commit;

          --插入没有做SO关联交易--需方的销售单据。
                  insert into cims.T_IMS_ERP_Check
                      (check_id,
                       order_type,
                       transaction_type,
                       entity_id,
                       business_num,
                       inv_code,
                       transaction_date,
                       error_mess,
                       error_flag
                       ,cims_qty)
                       select S_Ims_ERP_Check_N.nextval,
                               order_type,
                               transaction_type,
                               entity_id,
                               business_num,
                               inv_code,
                               transaction_date,
                               error_mess,
                               error_flag
                               ,cims_qty
                       from (
                          select '销售单' order_type,
                                 'SO事业部间关联交易-需方子库转移' transaction_type,
                                 so.entity_id,
                                 so.so_num business_num,
                                 so.nosettled_inventory_code inv_code,
                                 so.ERP_LOGIST_RECEIVE_DATE transaction_date,
                                 'ERP相同周期内暂时未产生子库转移的库存事务' error_mess,
                                 'Y' error_flag,
                                 sum(sld.item_qty*decode(so.biz_src_bill_type_code,'1001',1, '1002',-1, '1003',-1, '1004',1)) cims_qty
                            from cims.t_so_header so, cims.t_so_line SLD
                           where so.ERP_LOGIST_RECEIVE_DATE >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                             and so.ERP_LOGIST_RECEIVE_DATE < to_date(V_End_Date, 'yyyy-mm-dd')+1
                             and so.ERP_LOGIST_RECEIVE_FLAG = 'Y'
                             and so.entity_id not in(28,29,32)
                             and so.middle_inv_code <> so.nosettled_inventory_code
                             and so.so_header_id = sld.so_header_id
                             and so.biz_src_bill_type_code in   ('1001', '1002', '1003', '1004')
                             and sld.item_qty <> 0
                             and not exists
                                         (select 1
                                                  from cims.T_IMS_ERP_Check iec
                                                 where so.so_num = iec.business_num
                                                   and iec.order_type = '销售单'
                                                   and iec.transaction_type = 'SO事业部间关联交易-需方子库转移')
                              group by '销售单',
                                       'SO事业部间关联交易-需方子库转移',
                                       so.entity_id,
                                       so.so_num,
                                       so.nosettled_inventory_code,
                                       so.ERP_LOGIST_RECEIVE_DATE,
                                       'ERP相同周期内暂时未产生子库转移的库存事务',
                                       'Y');

                       commit;
                                              
               --SO没有关联交易的单据
                   insert into cims.T_IMS_ERP_Check
                        (check_id,
                         order_type,
                         transaction_type,
                         entity_id,
                         business_num,
                         inv_code,
                         transaction_date,
                         error_mess,
                         error_flag,
                         cims_qty)
                       select S_Ims_ERP_Check_N.nextval,
                               order_type,
                               transaction_type,
                               entity_id,
                               business_num,
                               inv_code,
                               transaction_date,
                               error_mess,
                               error_flag,
                               cims_qty
                        from
                         (
                            select '销售单' order_type,
                                   'ICP关联交易' transaction_type,
                                   so.entity_id,
                                   so.so_num business_num,
                                   so.middle_inv_code inv_code,
                                   so.settle_date transaction_date,
                                   'ERP相同周期内暂时未产生关联交易的库存事务' error_mess,
                                   'Y' error_flag,
                                   sum(sld.component_qty*decode(so.biz_src_bill_type_code,'1001',-1, '1002',1, '1003',1, '1004',-1)) cims_qty
                              from cims.t_so_header so,
                                   cims.t_so_line_detail sld,
                                   cims.t_so_type_extend bt
                             where so.settle_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                               and so.settle_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                               and so.entity_id not in(28,29,32)
                               and so.so_header_id = sld.so_header_id
                               and so.bill_type_id = bt.bill_type_id
                               and so.entity_id = bt.entity_id
                               and nvl(bt.promotion_flay,'N') = 'N'
                               and so.biz_src_bill_type_code in ('1001', '1002', '1003', '1004')
                               and  (so.entity_id in(14,15,17) and so.trx_mode = 'PULL')
                               /*
                               and ((so.entity_id in(10,11,12) and so.entity_cust_flag = 'Y')
                                                    or (so.entity_id in(14,15,17) and so.trx_mode = 'PULL'))
                               */
                               and sld.item_qty <> 0
                               and not exists
                                       (select 1
                                                from cims.T_IMS_ERP_Check iec
                                               where so.so_num = iec.business_num
                                                 and iec.order_type = '销售单'
                                                 and iec.transaction_type = 'ICP关联交易')
                             group by '销售单',
                                      'ICP关联交易',
                                      so.entity_id,
                                      so.so_num,
                                      so.middle_inv_code,
                                      so.settle_date,
                                      'ERP相同周期内暂时未产生关联交易的库存事务',
                                      'Y');

               commit;


          --插入没有销售发出的库存事务的单据
              insert into cims.T_IMS_ERP_Check
                        (check_id,
                         order_type,
                         transaction_type,
                         entity_id,
                         business_num,
                         inv_code,
                         transaction_date,
                         error_mess,
                         error_flag,
                         cims_qty)
                       select S_Ims_ERP_Check_N.nextval,
                               order_type,
                               transaction_type,
                               entity_id,
                               business_num,
                               inv_code,
                               transaction_date,
                               error_mess,
                               error_flag,
                               cims_qty
                        from
                         (
                            select '销售单' order_type,
                                   'SO结算' transaction_type,
                                   so.entity_id,
                                   so.so_num business_num,
                                   so.middle_inv_code inv_code,
                                   so.settle_date transaction_date,
                                   'ERP相同周期内暂时未产生销售发出（退回）的库存事务' error_mess,
                                   'Y' error_flag,
                                   sum(sld.component_qty*decode(so.biz_src_bill_type_code,'1001',-1, '1002',1, '1003',1, '1004',-1)) cims_qty
                              from cims.t_so_header so, cims.t_so_line_detail sld
                             where so.settle_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                               and so.settle_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                               and so.entity_id not in(28,29,32)
                               and so.so_header_id = sld.so_header_id
                               and so.biz_src_bill_type_code in
                                   ('1001', '1002', '1003', '1004')
                               --and nvl(so.entity_cust_flag,'N') = 'N'  --内部单位的要排除。
                               and sld.component_qty <> 0
                               and not exists
                                       (select 1
                                                from cims.T_IMS_ERP_Check iec
                                               where so.so_num = iec.business_num
                                                 and iec.order_type = '销售单'
                                                 and iec.transaction_type = 'SO结算')
                             group by '销售单',
                                      'SO结算',
                                      so.entity_id,
                                      so.so_num,
                                      so.middle_inv_code,
                                      so.settle_date,
                                      'ERP相同周期内暂时未产生销售发出（退回）的库存事务',
                                      'Y');

                 commit;

              --在ERP没有的单据。
             insert into cims.T_IMS_ERP_Check
                     (check_id,
                      order_type,
                      transaction_type,
                      entity_id,
                      business_num,
                      inv_code,
                      transaction_date,
                      error_mess,
                      error_flag,
                      cims_qty)
                     select S_Ims_ERP_Check_N.nextval,
                             order_type,
                             transaction_type,
                             entity_id,
                             business_num,
                             inv_code,
                             transaction_date,
                             error_mess,
                             error_flag,
                             cims_qty
                          from (select '推广领用' order_type,
                                '推广发放' transaction_type,
                                so.entity_id,
                                so.pmt_send_num business_num,
                                so.ship_inventory_code inv_code,
                                so.send_date transaction_date,
                                'ERP相同周期内暂时未产生库存事务' error_mess,
                                'Y' error_flag,
                                sum(sld.rcv_qty * decode(t.action_type, '01', 1, '02', -1, 1)) cims_qty
                           from cims.T_PMT_COLLAR_SEND_HEAD so
                                ,cims.t_pmt_collar_send_line sld
                                ,cims.t_inv_bill_types b
                                ,cims.t_inv_transaction_types t
                          where so.send_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                            and so.send_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                            and so.entity_id not in(28,29,32)
                            and so.collar_send_head_id = sld.collar_send_head_id
                            and so.bill_type_id = b.bill_type_id
                            and so.entity_id = b.entity_id
                            and b.transaction_type_id = t.transaction_type_id
                            and not exists (select 1
                                   from cims.T_IMS_ERP_Check iec
                                  where so.pmt_send_num = iec.business_num
                                    and iec.order_type = '推广领用')
                          group by '推广领用',
                                   '推广发放',
                                   so.entity_id,
                                   so.pmt_send_num,
                                   so.ship_inventory_code,
                                   so.send_date,
                                   'ERP相同周期内暂时未产生库存事务',
                                   'Y');

                      commit;
           --在ERP中没有调拨单据
            insert into cims.T_IMS_ERP_Check
                        (check_id,
                         order_type,
                         transaction_type,
                         entity_id,
                         business_num,
                         inv_code,
                         transaction_date,
                         error_mess,
                         error_flag,
                         cims_qty)
                        select S_Ims_ERP_Check_N.nextval,
                              order_type,
                               transaction_type,
                               entity_id,
                               business_num,
                               inv_code,
                               transaction_date,
                               error_mess,
                               error_flag,
                               cims_qty
                          from
                          (
                         select '调拨单' order_type,
                               '调拨发出' transaction_type,
                               sh.entity_id,
                               sh.trsf_order_num business_num,
                               sh.ship_inv_code inv_code,
                               sh.audit_date transaction_date,
                               'ERP相同周期内暂时未产生调拨发出库存事务' error_mess,
                               'Y' error_flag,
                               sum(sl.billed_qty * decode(b.cancel_flag,'Y',1,-1)) cims_qty
                          from cims.t_inv_trsf_order sh,
                               cims.t_inv_trsf_order_line_detail sl,
                               cims.t_inv_bill_types b
                         where sh.audit_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                           and sh.audit_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                           and sh.entity_id not in(28,29,32)
                           and sh.ship_inv_code <> sh.consignee_inv_code
                           and sh.trsf_order_id = sl.trsf_order_id
                           and sh.bill_type_id = b.bill_type_id
                           and sh.entity_id = b.entity_id
                           and sl.billed_qty <> 0
                           and not exists (select 1
                                  from cims.T_IMS_ERP_Check iec
                                 where sh.trsf_order_num = iec.business_num
                                   and iec.order_type = '调拨单'
                                   and iec.transaction_type = '调拨发出')
                         group by '调拨单',
                                  '调拨发出',
                                  sh.entity_id,
                                  sh.trsf_order_num,
                                  sh.ship_inv_code,
                                  sh.audit_date,
                                  'ERP相同周期内暂时未产生调拨发出库存事务',
                                  'Y');

                commit;
           --在ERP中没有调拨接收
                     insert into cims.T_IMS_ERP_Check
                       (check_id,
                        order_type,
                        transaction_type,
                        entity_id,
                        business_num,
                        inv_code,
                        transaction_date,
                        error_mess,
                        error_flag,
                        cims_qty)
                       select S_Ims_ERP_Check_N.nextval,
                              order_type,
                              transaction_type,
                              entity_id,
                              business_num,
                              inv_code,
                              transaction_date,
                              error_mess,
                              error_flag,
                              cims_qty
                        from(
                             select '调拨单' order_type,
                                    '调拨接收' transaction_type,
                                    sh.entity_id,
                                    sh.trsf_order_num business_num,
                                    sh.consignee_inv_code inv_code,
                                    sh.rcv_date transaction_date,
                                    'ERP相同周期内暂时未产生调拨接收库存事务' error_mess,
                                    'Y' error_flag,
                                    sum(sl.billed_qty * decode(b.cancel_flag,'Y',1,-1)) cims_qty
                               from cims.t_inv_trsf_order             sh,
                                    cims.t_inv_trsf_order_line_detail sl,
                                    cims.t_inv_bill_types b
                              where sh.rcv_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                                and sh.rcv_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                                and sh.entity_id not in(28,29,32)
                                and sh.ship_inv_code <> sh.consignee_inv_code
                                and sh.traveling_inv_code is not null
                                and sh.trsf_order_id = sl.trsf_order_id
                                and sh.bill_type_id = b.bill_type_id
                                and sh.entity_id = b.entity_id
                                and sl.billed_qty <> 0
                                and not exists (select 1
                                       from cims.T_IMS_ERP_Check iec
                                      where sh.trsf_order_num = iec.business_num
                                        and iec.order_type = '调拨单'
                                        and iec.transaction_type = '调拨接收')
                              group by '调拨单',
                                       '调拨接收',
                                       sh.entity_id,
                                       sh.trsf_order_num,
                                       sh.consignee_inv_code,
                                       sh.rcv_date,
                                       'ERP相同周期内暂时未产生调拨接收库存事务',
                                       'Y');
                        commit;

               --在ERP中没有盘点事务
               insert into cims.T_IMS_ERP_Check
                              (check_id,
                               order_type,
                               transaction_type,
                               entity_id,
                               business_num,
                               transaction_date,
                               inv_code,
                               error_mess,
                               error_flag,
                               cims_qty)
                              select S_Ims_ERP_Check_N.nextval,
                                     order_type,
                                     transaction_type,
                                     entity_id,
                                     business_num,
                                     transaction_date,
                                     inv_code,
                                     error_mess,
                                     error_flag,
                                     cims_qty
                                from
                                (
                                    select '盘点' order_type,
                                           '盘点' transaction_type,
                                           sh.entity_id,
                                           sh.check_order_num business_num,
                                           sh.exec_date transaction_date,
                                           sh.inv_code,
                                           'ERP相同周期内暂时未产生盘点库存事务' error_mess,
                                           'Y' error_flag,
                                           sum(sl.billed_qty*decode(t.action_type, '01', 1, '02', -1, 1)) cims_qty
                                      from cims.t_inv_check_orders sh
                                           ,cims.t_inv_check_order_lines sl
                                           ,cims.t_inv_bill_types b
                                           ,cims.t_inv_transaction_types t
                                     where sh.exec_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                                       and sh.exec_date < to_date(V_End_Date, 'yyyy-mm-dd')+1
                                       and sh.entity_id not in(28,29,32)
                                       and sh.check_order_id = sl.check_order_id
                                       and sh.entity_id = b.entity_id
                                       and sh.check_order_type = b.bill_type_code
                                       and b.transaction_type_id = t.transaction_type_id
                                       and sl.billed_qty <> 0
                                       and not exists (select 1
                                              from cims.T_IMS_ERP_Check iec
                                             where sh.check_order_num = iec.business_num
                                               and iec.order_type = '盘点'
                                               and iec.transaction_type = '盘点')
                                     group by '盘点',
                                              '盘点',
                                              sh.entity_id,
                                              sh.check_order_num,
                                              sh.exec_date,
                                              sh.inv_code,
                                              'ERP相同周期内暂时未产生盘点库存事务',
                                              'Y');

                    commit;

  end P_Inv_ERP_No_Trans;
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
  --设置对账成功、失败信息
procedure p_Set_Check_Mess
  is
          V_Begin_Date varchar2(15);
          v_end_date  varchar2(15);
   begin
          --每月1-5日，对账上一个月1日至今天的单据。5日后对本月的单据。
           if to_char(sysdate,'dd') <= '06' then
              V_Begin_Date := to_char(trunc(add_months(sysdate,-1),'MM'),'YYYY-MM-DD');
           else
              V_Begin_Date := to_char(trunc(sysdate,'mm'),'YYYY-MM-DD');
           end if;

           --取当前日期的前一天
           v_end_date := to_char(trunc(sysdate-1),'YYYY-MM-DD');

          insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '更新错误原因' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;

             commit;

               --更新错误原因
               --关联订单（错误日志）
               update T_IMS_ERP_Check iec set iec.erp_error = (select decode(nvl(decode(ERROR_MSG,'调用服务成功',null,ERROR_MSG),RESPONSEMESSAGE),'调用服务成功',null,nvl(decode(ERROR_MSG,'调用服务成功',null,ERROR_MSG),RESPONSEMESSAGE))
                                              from cims.INTF_CUX_ICP_ORDER_REQ_HEADERS r
                                                   where r.source_orders = decode(iec.transaction_type,'SO事业部间关联交易-需方子库转移','G'||iec.business_num,iec.business_num)
                                                         and iec.transaction_type in ('ICP关联交易','SO事业部间关联交易-需方子库转移')
                                                         and iec.entity_id = r.entity_id
                                                         --and r.x_icp_seq_id is null
                                                         and ((r.RESPONSETYPE in('W','E') and r.STATUS='P') or (r.STATUS='E'))
                                                         and rownum = 1)
                                             where iec.error_flag = 'Y'
                                                   and iec.transaction_type   in ('ICP关联交易','SO事业部间关联交易-需方子库转移')
                                                   and exists(select 1 from cims.INTF_CUX_ICP_ORDER_REQ_HEADERS re
                                                                where re.source_orders =decode(iec.transaction_type,'SO事业部间关联交易-需方子库转移','G'||iec.business_num,iec.business_num)
                                                                       and iec.transaction_type  in ('ICP关联交易','SO事业部间关联交易-需方子库转移')
                                                                       and iec.entity_id = re.entity_id);
                                                                       
                                                                       --and ((re.RESPONSETYPE in('W','E') and re.STATUS='P') or (re.STATUS='E')));

             commit;
             
             
              --未产生关联订单
              update T_IMS_ERP_Check iec set iec.error_mess = '未产生关联订单接口数据' --,iec.erp_error = '未产生关联订单'
                                            where iec.error_flag = 'Y'
                                                   and iec.transaction_type in ('ICP关联交易','SO事业部间关联交易-需方子库转移')
                                                   and iec.erp_error is null
                                                   and not exists(select 1 from cims.INTF_CUX_ICP_ORDER_REQ_HEADERS re
                                                                where re.source_orders = decode(iec.transaction_type,'SO事业部间关联交易-需方子库转移','G'||iec.business_num,iec.business_num)
                                                                       and iec.transaction_type in('ICP关联交易','SO事业部间关联交易-需方子库转移')
                                                                       and iec.entity_id = re.entity_id);
                                                                       --and re.creation_date >= sysdate - 45)
                                                                       
                                                  

             /*
              --关联物流（错误日志）发出。
              --2018.9.28不再细分关联交易的步骤，直接引用responsemessage_1，responsemessage_2
              update T_IMS_ERP_Check iec set iec.erp_error = (select decode(RESPONSEMESSAGE_1,'调用服务成功',null,RESPONSEMESSAGE_1)
                                              from cims.INTF_CUX_ICP_LOGIST_REQ_HEADER r
                                                   where r.REQUIREMENT_ORDER_NUM = iec.business_num --decode(iec.transaction_type,'ICP关联交易(内部客户)','G'||iec.business_num,iec.business_num)
                                                         and iec.transaction_type  in('ICP关联交易','SO事业部间关联交易-需方子库转移')
                                                         and iec.entity_id = r.entity_id
                                                         and r.x_icp_seq_id is null
                                                         and rownum = 1)
                                             where iec.error_flag = 'Y'
                                                   and iec.erp_error is null
                                                   and iec.transaction_type  in ('ICP关联交易','SO事业部间关联交易-需方子库转移')
                                                   and exists(select RESPONSEMESSAGE_1
                                                            from cims.INTF_CUX_ICP_LOGIST_REQ_HEADER re
                                                                 where re.REQUIREMENT_ORDER_NUM = decode(iec.transaction_type,'SO事业部间关联交易-需方子库转移','G'||iec.business_num,iec.business_num)
                                                                       and iec.transaction_type in('ICP关联交易','SO事业部间关联交易-需方子库转移')
                                                                       and iec.entity_id = re.entity_id
                                                                       and re.x_icp_seq_id is null
                                                                       );

            */
            /*
            --未产生关联物流
            --2018.9.28不再细分关联交易的步骤，直接引用responsemessage_1，responsemessage_2
            update T_IMS_ERP_Check iec set iec.error_mess = '未产生关联物流-发出'--,iec.erp_error = '未产生关联物流--发出'
                                             where iec.error_flag = 'Y'
                                                   and iec.erp_error is null
                                                   and iec.transaction_type  in ('ICP关联交易','SO事业部间关联交易-需方子库转移')
                                                   and exists(select RESPONSEMESSAGE_1
                                                            from cims.INTF_CUX_ICP_LOGIST_REQ_HEADER re
                                                                 where re.REQUIREMENT_ORDER_NUM = decode(iec.transaction_type,'SO事业部间关联交易-需方子库转移','G'||iec.business_num,iec.business_num)
                                                                       and iec.transaction_type in ('ICP关联交易','SO事业部间关联交易-需方子库转移')
                                                                       and iec.entity_id = re.entity_id
                                                                       and re.x_icp_seq_id is null
                                                                       );

            commit;
            */
            /*
            --关联物流（错误日志）接收
            --2018.9.28不再细分关联交易的步骤，直接引用responsemessage_1，responsemessage_2
            update T_IMS_ERP_Check iec set iec.erp_error = (select decode(RESPONSEMESSAGE_2,'调用服务成功',null,RESPONSEMESSAGE_2)
                                              from cims.INTF_CUX_ICP_LOGIST_REQ_HEADER r
                                                   where r.REQUIREMENT_ORDER_NUM = decode(iec.transaction_type,'SO事业部间关联交易-需方子库转移','G'||iec.business_num,iec.business_num)
                                                         and iec.transaction_type in('ICP关联交易','SO事业部间关联交易-需方子库转移')
                                                         and iec.entity_id = r.entity_id
                                                         and r.x_icp_seq_id is not null
                                                         and ((r.RESPONSETYPE_2 in('W','E') and r.STATUS_RECEIVE='P') or r.STATUS_RECEIVE='E')
                                                         and rownum = 1)
                                             where iec.error_flag = 'Y'
                                                   and iec.erp_error is null
                                                   and iec.transaction_type in('ICP关联交易','SO事业部间关联交易-需方子库转移')
                                                   and exists(select RESPONSEMESSAGE_2
                                                              from cims.INTF_CUX_ICP_LOGIST_REQ_HEADER re
                                                                   where re.REQUIREMENT_ORDER_NUM = decode(iec.transaction_type,'SO事业部间关联交易-需方子库转移','G'||iec.business_num,iec.business_num)
                                                                         and iec.transaction_type in('ICP关联交易','SO事业部间关联交易-需方子库转移')
                                                                         and iec.entity_id = re.entity_id
                                                                         and re.x_icp_seq_id is not null
                                                                         and ((re.RESPONSETYPE_2 in('W','E') and re.STATUS_RECEIVE='P') or  re.STATUS_RECEIVE='E')
                                                                         );


             */
             /*
             --2018.9.28不再细分关联交易的步骤，直接引用responsemessage_1，responsemessage_2
             --未产生关联物流接收
             update T_IMS_ERP_Check iec set iec.error_mess = '未产生关联物流-接收'--,iec.erp_error = '未产生关联物流-接收'
                                             where iec.error_flag = 'Y'
                                                   and iec.erp_error is null
                                                   and iec.transaction_type in('ICP关联交易','SO事业部间关联交易-需方子库转移')
                                                   and exists(select RESPONSEMESSAGE_2
                                                              from cims.INTF_CUX_ICP_LOGIST_REQ_HEADER re
                                                                   where re.REQUIREMENT_ORDER_NUM = decode(iec.transaction_type,'SO事业部间关联交易-需方子库转移','G'||iec.business_num,iec.business_num)
                                                                         and iec.transaction_type in('ICP关联交易','SO事业部间关联交易-需方子库转移')
                                                                         and iec.entity_id = re.entity_id
                                                                         and re.x_icp_seq_id is not null
                                                                         and ((re.RESPONSETYPE_2 in('W','E') and re.STATUS_RECEIVE='P') or  re.STATUS_RECEIVE='E')
                                                                         );
             commit;
             */

             /*
             --2018.9.28不再细分关联交易的步骤，直接引用responsemessage_1，responsemessage_2
             --直接查询关联交易错误日志。
             update T_IMS_ERP_Check iec set iec.erp_error =(
                           select a.error_message
                           from apps.cux_icp_errmsg_v@mdims2mderp a
                                ,cims.INTF_CUX_ICP_LOGIST_REQ_HEADER c
                                ,cims.t_ims_erp_check d
                              where d.error_flag = 'Y'
                                    and d.transaction_type  in ('ICP关联交易','SO事业部间关联交易-需方子库转移')
                                    and a.req_header_id = c.req_header_id
                                    and c.requirement_order_num = decode(iec.transaction_type,'SO事业部间关联交易-需方子库转移','G'||iec.business_num,iec.business_num)
                                    and d.business_num = iec.business_num
                                    and a.errmsg_seq_id in(select max(errmsg_seq_id) from apps.cux_icp_errmsg_v@mdims2mderp b
                                          where b.req_header_id = a.req_header_id)
                                                 and a.creation_date>= to_date(V_Begin_Date, 'yyyy-mm-dd')
                                                 and iec.transaction_date < to_date(V_End_Date, 'yyyy-mm-dd')+1)
                            where iec.error_flag = 'Y'
                                  and iec.erp_error is null
                                  and iec.transaction_type  in ('ICP关联交易','SO事业部间关联交易-需方子库转移');
             commit;
             */

             --直接查询关联交易错误日志。
             --2018.9.28不再细分关联交易的步骤，直接引用responsemessage_1，responsemessage_2
             update T_IMS_ERP_Check iec set iec.erp_error =(
                                    select substrb(c.responsemessage_1||c.responsemessage_2,1,4000)
                                    from cims.INTF_CUX_ICP_LOGIST_REQ_HEADER c
                                       where c.requirement_order_num 
                                                  = decode(iec.transaction_type,'SO事业部间关联交易-需方子库转移','G'||iec.business_num,iec.business_num))
                              where iec.error_flag = 'Y'
                                  and iec.erp_error is null
                                  and iec.transaction_type  in ('ICP关联交易','SO事业部间关联交易-需方子库转移');
             commit;

             --如果没有查找到ERP的库存事务，则查询是否产生了关联交易
             update T_IMS_ERP_Check iec set iec.error_mess = (select '已产生关联交易，但是未ERP库存事务，关联物流号:'||to_char(X_ICP_SEQ_ID)
                                              from cims.INTF_CUX_ICP_LOGIST_REQ_HEADER r
                                                   where r.REQUIREMENT_ORDER_NUM = iec.business_num
                                                         and iec.transaction_type in ('ICP关联交易','SO事业部间关联交易-需方子库转移')
                                                         and iec.entity_id = r.entity_id
                                                         and X_ICP_SEQ_ID is not Null
                                                         and rownum = 1)
                                             where iec.error_flag = 'Y'
                                                   and iec.transaction_type in ('ICP关联交易','SO事业部间关联交易-需方子库转移');

             /*
             20170104现已为单边关联交易
             --更新内部销售的关联交易。
             update T_IMS_ERP_Check iec set iec.error_mess = (select '已产生关联交易，但是未ERP库存事务，关联物流号:'||to_char(X_ICP_SEQ_ID)
                                              from cims.INTF_CUX_ICP_LOGIST_REQ_HEADER r
                                                   where r.REQUIREMENT_ORDER_NUM = 'G'||iec.business_num
                                                         and iec.order_type = '销售单'
                                                         and iec.transaction_type =  'ICP关联交易' --in ('ICP关联交易','ICP关联交易(内部客户)')
                                                         and iec.entity_id = r.entity_id
                                                         and X_ICP_SEQ_ID is not Null
                                                         and rownum = 1)
                                             where iec.error_flag = 'Y'
                                                   and iec.transaction_type =  'ICP关联交易' --in ('ICP关联交易','ICP关联交易(内部客户)')
                                                   and iec.order_type = '销售单';
            */

             --错误信息(PO采购)
             update T_IMS_ERP_Check iec set iec.erp_error = (select decode(nvl(decode(ERROR_MSG,'调用服务成功',null,ERROR_MSG),RESPONSEMESSAGE),'调用服务成功',null,nvl(decode(ERROR_MSG,'调用服务成功',null,ERROR_MSG),RESPONSEMESSAGE))
                                              from cims.intf_cux_po_order r
                                                   where r.PO_NUMBER = iec.business_num
                                                         and iec.transaction_type = 'PO采购'
                                                         and ((r.RESPONSE_TYPE in('W','E') and (r.STATUS_STANDARD='P' or r.status_return ='P' and r.status_rav = 'P'))
                                                             or (r.STATUS_STANDARD='E' or r.status_return ='E' and r.status_rav = 'E'))
                                                         and rownum = 1)
                                             where iec.error_flag = 'Y'
                                                   --and iec.erp_error is null
                                                   and iec.transaction_type = 'PO采购'
                                                   and exists(select 1
                                                              from cims.intf_cux_po_order re
                                                                   where re.PO_NUMBER = iec.business_num
                                                                         and iec.transaction_type = 'PO采购'
                                                                         and ((re.RESPONSE_TYPE in('W','E') and (re.STATUS_STANDARD='P' or re.status_return ='P' and re.status_rav = 'P'))
                                                                             or (re.STATUS_STANDARD='E' or re.status_return ='E' and re.status_rav = 'E'))
                                                             );

             commit;

             --子库转移的错误日志
             update T_IMS_ERP_Check iec set iec.erp_error = (select decode(nvl(decode(ERROR_MSG,'调用服务成功',null,ERROR_MSG),RESPONSE_MESSAGE),'调用服务成功',null,nvl(decode(ERROR_MSG,'调用服务成功',null,ERROR_MSG),RESPONSE_MESSAGE))
                                              from cims.intf_inv_transaction_head r
                                                   where r.ORDER_NUM = iec.business_num
                                                         and iec.transaction_type in('PO子库转移','SO子库转移','调拨发出','调拨接收','盘点','推广发放','SO事业部间关联交易-供方')
                                                         and iec.entity_id = r.entity_id
                                                         and ((r.RESPONSE_TYPE in('W','E') and r.STATUS='P') or r.STATUS='E')
                                                         and rownum = 1)
                                             where iec.error_flag = 'Y'
                                                   --and iec.erp_error is null
                                                   and iec.transaction_type in('PO子库转移','SO子库转移','调拨发出','调拨接收','盘点','推广发放','SO事业部间关联交易-供方')
                                                   and exists( select 1
                                                            from cims.intf_inv_transaction_head re
                                                                 where re.ORDER_NUM = iec.business_num
                                                                       and iec.transaction_type in('PO子库转移','SO子库转移','调拨发出','调拨接收','盘点','推广发放','SO事业部间关联交易-供方')
                                                                       and iec.entity_id = re.entity_id
                                                                       and ((re.RESPONSE_TYPE in('W','E') and re.STATUS='P') or re.STATUS='E')) ;

             commit;

             --SO生成的错误
             update T_IMS_ERP_Check iec set iec.erp_error = (select decode(ERROR_MSG,'调用服务成功',null,ERROR_MSG)||'-ESB：'||nvl(r.gen_request_id,'空')
                                                                                                from cims.INTF_OE_HEADERS_IFACE_ALL r
                                                                                                     where r.ORDER_NUMBER = iec.business_num
                                                                                                           and iec.transaction_type = 'SO结算'
                                                                                                           and rownum = 1)
                                             where iec.error_flag = 'Y'
                                                   --and iec.erp_error is null
                                                   and iec.transaction_type = 'SO结算'
                                                   and exists(select ERROR_MSG
                                                            from cims.INTF_OE_HEADERS_IFACE_ALL re
                                                                 where re.ORDER_NUMBER = iec.business_num
                                                                       and iec.transaction_type = 'SO结算'
                                                                       and re.GEN_TRX_STATUS = 'E');
             commit;

             --判断是否生产SO
             update T_IMS_ERP_Check iec set iec.error_mess = 'SO没有生成，ESB：'||(select nvl(r.gen_request_id,'空') 
                                                                                                                    from cims.INTF_OE_HEADERS_IFACE_ALL r
                                                                                                                           where r.ORDER_NUMBER = iec.business_num
                                                                                                                                 and iec.transaction_type = 'SO结算'
                                                                                                                                 and rownum = 1)
                                                           ,iec.erp_error = 'SO没有生成'||iec.erp_error
                                             where iec.error_flag = 'Y'
                                                   and iec.transaction_type = 'SO结算'
                                                   and exists(select ERROR_MSG
                                                            from cims.INTF_OE_HEADERS_IFACE_ALL re
                                                                 where re.ORDER_NUMBER = iec.business_num
                                                                       and iec.transaction_type = 'SO结算'
                                                                       and nvl(re.GEN_TRX_STATUS,'N') not in('E','S'));
                 
                 update T_IMS_ERP_Check iec set iec.error_mess = 'SO已生成，ESB：'||(select nvl(r.gen_request_id,'空') 
                                                                                                                    from cims.INTF_OE_HEADERS_IFACE_ALL r
                                                                                                                           where r.ORDER_NUMBER = iec.business_num
                                                                                                                                 and iec.transaction_type = 'SO结算'
                                                                                                                                 and rownum = 1)
                                                           ,iec.erp_error = 'SO已生成'||iec.erp_error
                                             where iec.error_flag = 'Y'
                                                   and iec.transaction_type = 'SO结算'
                                                   and exists ( select 1 from apps.oe_order_headers_all@mdims2mderp a
                                                              where a.order_number = iec.business_num) ;                                                                    

             commit;

             --SO变更的错误
             update T_IMS_ERP_Check iec set iec.erp_error = (select decode(ERROR_MSG,'调用服务成功',null,ERROR_MSG)||' - ESB：'||nvl(r.update_request_id,'空')
                                                                                  from cims.INTF_OE_HEADERS_IFACE_ALL r
                                                                                       where r.ORDER_NUMBER = iec.business_num
                                                                                             and iec.transaction_type = 'SO结算'
                                                                                             and rownum = 1)
                                             where iec.error_flag = 'Y'
                                                   --and iec.erp_error is null
                                                   and iec.transaction_type = 'SO结算'
                                                   and exists(select ERROR_MSG
                                                              from cims.INTF_OE_HEADERS_IFACE_ALL re
                                                                   where re.ORDER_NUMBER = iec.business_num
                                                                         and iec.transaction_type = 'SO结算'
                                                                         and re.UPDATE_TRX_STATUS = 'E');

             commit;

             --判读是否SO没有变更
             update T_IMS_ERP_Check iec set iec.error_mess = 'SO没有变更，ESB：'||(select nvl(r.update_request_id,'空') 
                                                                                                                    from cims.INTF_OE_HEADERS_IFACE_ALL r
                                                                                                                           where r.ORDER_NUMBER = iec.business_num
                                                                                                                                 and iec.transaction_type = 'SO结算'
                                                                                                                                 and rownum = 1)
                                                           ,iec.erp_error = 'SO没有变更'||iec.erp_error
                                             where iec.error_flag = 'Y'
                                                   and iec.cims_qty < 0
                                                   --and iec.erp_error is null
                                                   and iec.transaction_type = 'SO结算'
                                                   and exists(select ERROR_MSG
                                                              from cims.INTF_OE_HEADERS_IFACE_ALL re
                                                                   where re.ORDER_NUMBER = iec.business_num
                                                                         and iec.transaction_type = 'SO结算'
                                                                         and nvl(re.UPDATE_TRX_STATUS,'N') not in('E','S')
                                                                         and re.GEN_TRX_STATUS = 'S');
                                                                         
               update T_IMS_ERP_Check iec set iec.error_mess = 'SO已变更，ESB：'||(select nvl(r.gen_request_id,'空') 
                                                                                                                    from cims.INTF_OE_HEADERS_IFACE_ALL r
                                                                                                                           where r.ORDER_NUMBER = iec.business_num
                                                                                                                                 and iec.transaction_type = 'SO结算'
                                                                                                                                 and rownum = 1)
                                                           ,iec.erp_error = 'SO已变更'||iec.erp_error
                                             where iec.error_flag = 'Y'
                                                   and iec.transaction_type = 'SO结算'
                                                   and exists ( select 1 from apps.oe_order_headers_all@mdims2mderp a
                                                              where a.order_number = iec.business_num
                                                              and a.flow_status_code in ('BOOKED', 'CLOSED')) ;  
             commit;

             --SO--RMA错误
             update T_IMS_ERP_Check iec set iec.erp_error = (select decode(ERROR_MSG,'调用服务成功',null,ERROR_MSG)||'-ESB:'||nvl(r.rma_receive_request_id,'空')
                                              from cims.INTF_OE_HEADERS_IFACE_ALL r
                                                   where r.ORDER_NUMBER = iec.business_num
                                                         and iec.transaction_type = 'SO结算'
                                                         and RMA_RECEIVE_TRX_STATUS = 'E'
                                                         and rownum = 1)
                                             where iec.error_flag = 'Y'
                                                   and iec.transaction_type = 'SO结算'
                                                   and exists(select ERROR_MSG
                                                        from cims.INTF_OE_HEADERS_IFACE_ALL re
                                                             where re.ORDER_NUMBER = iec.business_num
                                                                   and iec.transaction_type = 'SO结算'
                                                                   and RMA_RECEIVE_TRX_STATUS = 'E');
             commit;

             --判读是否SO没有变更
             update T_IMS_ERP_Check iec set iec.error_mess = 'SO-RMA没有变更，ESB：'||(select nvl(r.rma_receive_request_id,'空') 
                                                                                                                    from cims.INTF_OE_HEADERS_IFACE_ALL r
                                                                                                                           where r.ORDER_NUMBER = iec.business_num
                                                                                                                                 and iec.transaction_type = 'SO结算'
                                                                                                                                 and rownum = 1)
                                                             ,iec.erp_error = 'SO-RMA没有变更'||iec.erp_error
                                             where iec.error_flag = 'Y'
                                                   and iec.cims_qty > 0
                                                   --and iec.erp_error is null
                                                   and iec.transaction_type = 'SO结算'
                                                   and exists(select ERROR_MSG
                                                              from cims.INTF_OE_HEADERS_IFACE_ALL re
                                                                   where re.ORDER_NUMBER = iec.business_num
                                                                         and iec.transaction_type = 'SO结算'
                                                                         and nvl(re.RMA_RECEIVE_TRX_STATUS,'N') not in('E','S')
                                                                         and re.GEN_TRX_STATUS = 'S');

             commit;

            --更新SO头、行状态不一致的错误
            update T_IMS_ERP_Check iec set iec.erp_error = 'G-ERP SO变更时头、行状态不一致，需ERP解决'
                                   where iec.error_flag = 'Y'
                                         and iec.transaction_type = 'SO结算'
                                         and exists (select 1
                                               from  cims.t_so_header sh
                                                     ,apps.oe_order_headers_all@mdims2mderp a
                                                    where sh.so_num = iec.business_num
                                                          and sh.entity_id = iec.entity_id
                                                          and a.order_number = sh.so_num
                                                          and a.org_id = sh.erp_ou_id
                                                          and a.flow_status_code in ('BOOKED', 'CLOSED')
                                                          and exists (select 1
                                                              from apps.oe_order_lines_all@mdims2mderp l
                                                                     where a.header_id = l.header_id
                                                                       and l.flow_status_code = 'ENTERED'));

            --设置内部客户关联交易-结算，已产生关联交易未产生库存事务的。
            update T_IMS_ERP_Check iec set iec.error_mess = (select '已产生关联交易，但是未ERP库存事务，关联物流号:'||to_char(X_ICP_SEQ_ID)
                                              from cims.INTF_CUX_ICP_LOGIST_REQ_HEADER r
                                                   where r.REQUIREMENT_ORDER_NUM = 'G'||iec.business_num
                                                         and iec.order_type = '销售单'
                                                         and iec.transaction_type = 'SO结算'
                                                         and iec.entity_id = r.entity_id
                                                         and X_ICP_SEQ_ID is not Null
                                                         and rownum = 1)
                                             where iec.error_flag = 'Y'
                                                   and iec.transaction_type = 'SO结算'
                                                   and iec.order_type = '销售单'
                                                   and exists (select 1 from cims.t_so_header so
                                                                      where so.so_num = iec.business_num
                                                                            and nvl(so.entity_cust_flag,'N') = 'Y')
                                                   and exists(select 1 from cims.INTF_CUX_ICP_LOGIST_REQ_HEADER CH
                                                                     where  ch.REQUIREMENT_ORDER_NUM = 'G'||iec.business_num
                                                                            and iec.order_type = '销售单'
                                                                             and iec.transaction_type = 'SO结算'
                                                                             and iec.entity_id = ch.entity_id
                                                                             and ch.X_ICP_SEQ_ID is not Null);

            --对于状态为Y，且没有接口有错误显示的设置为Z。
            update cims.T_IMS_ERP_Check iec
                       set error_flag = 'Z',error_mess = to_char(sysdate,'yyyy-mm-dd hh24:mi')||'需和G-ERP进一步核实：'||error_mess
                     where error_flag = 'Y'
                       and iec.erp_error is null
                       and iec.transaction_date >= to_date(V_Begin_Date, 'yyyy-mm-dd')
                       and iec.transaction_date < to_date(V_End_Date, 'yyyy-mm-dd')+1;

                    commit;
           
           --插入跨事业部关联交易，价格错误的单据
           insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         business_num,
                                         transaction_date,
                                         inv_code,
                                         ERP_ERROR,
                                         ERROR_MESS,
                                         error_flag
                                         )
                select S_Ims_ERP_Check_N.nextval,
                              '跨事业部关联交易错误' order_type,
                              'IMS-PO无关联交易' transaction_type,
                              ph.entity_id,
                              ph.po_num||','||ph.SCHED_ORDER_NUM,
                              ph.exec_date,
                              ph.inv_finance_code,
                              t.price_err_msg,
                              '跨事业部销售单没有生成关联交易接口记录，导致接收物流无法进行',
                              'Y'
                  from cims.intf_cux_icp_logist_req_header t 
                       ,cims.t_inv_po_headers ph
                    where t.PRICE_CHECK_FLAG = 'Y' 
                          and t.price_err_flag = 'Y'
                          and ph.SCHED_ORDER_NUM = t.requirement_order_num
                          and ph.billed_date >= sysdate - 60;
       
       commit;
       --35主体工程公司，没有自动完成销售转采购
       insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         business_num,
                                         transaction_date,
                                         ERP_ERROR,
                                         ERROR_MESS,
                                         error_flag
                                         ) 
        SELECT S_Ims_ERP_Check_N.nextval,
                    '销售转采购' order_type,
                    '销售转采购错误' transaction_type,
                     h.entity_id,
                     h.so_num,
                     h.audit_date,
                     h.to_supp_msg,
                     '没有自动完成销售转采购,修复错误后由job处理',
                     'Y'
               FROM cims.T_SO_HEADER H
           WHERE EXISTS (SELECT 1
                    FROM cims.T_BD_CENTER_RELATION R
                   WHERE R.HQ_ACCOUNT_ID = H.ACCOUNT_ID
                     AND R.HQ_ENTITY_ID = H.ENTITY_ID
                     AND R.SC_ENTITY_ID = 35)
             AND EXISTS (SELECT 1
                    FROM cims.T_PLN_ORDER_TYPE_RELA TR
                   WHERE TR.RELATION_TYPE = 'SO_TO_POX'
                     AND TR.SOURCE_ORDER_TYPE_ID = H.BILL_TYPE_ID
                     AND TR.SOURCE_ENTITY_ID = H.ENTITY_ID
                     AND TR.TRANSFER_ENTITY_ID = 35)
             AND H.BIZ_SRC_BILL_TYPE_CODE <> '1003' --//非销售退货单
             AND H.SO_STATUS <> '10' --//非制单状态
             AND NVL(H.ANNTO_RECEIVE_FLAG, 'N') = 'N' --//非安得接收
             AND (H.DIRECT_SHIP_FLAG = 'Y' OR H.SELF_PICK_FLAG = 'Y') --//直发或自提
             AND NVL(H.TO_SUPP_FLAG, 'N') = 'N' --//未转采购
             AND H.SO_DATE >= TRUNC(SYSDATE) - 90 --//取3个月内单据
             --需自动转采购主体
             AND EXISTS (SELECT 1
                    FROM cims.T_BD_PARAM_LIST L, cims.T_BD_PARAM_ENTITY E
                   WHERE L.PARAM_LIST_ID = E.PARAM_LIST_ID
                     AND E.ENTITY_ID = H.ENTITY_ID
                     AND L.PARAM_CODE = 'SO_TO_POX_AUTO_EXE'
                     AND E.ENTITY_VALUE = 'Y')
             AND NOT EXISTS (SELECT 1 FROM CIMS.T_INV_PO_HEADERS PH
                              WHERE PH.SOURCE_ORDER_NUM = H.SO_NUM
                                AND PH.SOURCE_TYPE = '销售转采购');
           commit;
                                           

     end p_Set_Check_Mess;

------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
     --对当月的账务
     procedure p_month_inv_check
      is
        V_Begin_Date date;
        v_end_date date;
      begin
           insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '对账开始' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                    from dual;
            
            delete from cims.T_IMS_ERP_Check iec 
                   where iec.transaction_date < add_months(trunc(sysdate,'mm'),-3);
            
            commit;
 
           --每月1-5日，对账上一个月1日至今天的单据。5日后对本月的单据。
           if to_char(sysdate,'dd') <= '06' then
              V_Begin_Date := trunc(add_months(sysdate,-1),'MM');
           else
              V_Begin_Date := trunc(sysdate,'mm');
           end if;

           v_end_date := V_Begin_Date;

           delete from T_IMS_ERP_Check iec
                      where iec.error_flag in('Y','Z');

           delete from T_IMS_ERP_Check iec
                      where iec.entity_id = 0;
           commit;

           loop
             if to_char(sysdate,'hh24') >= '06' then
               insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '超过6点，停止运行' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                    from dual;
               commit;
               exit;
             end if;
             insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    to_char(V_Begin_Date,'mm-dd')||'日对账开始' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                    from dual;
                    
             p_inv_check(V_Begin_Date,v_end_date);
             
             insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    to_char(V_Begin_Date,'mm-dd')||'日对账结束' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                    from dual;
             v_end_date := v_end_date + 1;
             V_Begin_Date := v_end_date;
             if v_end_date > trunc(sysdate) then
               exit;
             end if;
           end loop;

           P_Inv_ERP_No_Trans;

           p_Set_Check_Mess;

           insert into cims.T_IMS_ERP_Check(check_id,
                                         order_type,
                                         transaction_type,
                                         entity_id,
                                         transaction_date,
                                         error_flag
                                         )
                        select S_Ims_ERP_Check_N.nextval,
                                    '运行计时' order_type,
                                    '对账结束' transaction_type,
                                    0 entity_id,
                                    sysdate transaction_date,
                                    'N' error_flag
                        from dual;

            commit;

      end p_month_inv_check;

end PKG_CIMS_ERP_Check;
/

