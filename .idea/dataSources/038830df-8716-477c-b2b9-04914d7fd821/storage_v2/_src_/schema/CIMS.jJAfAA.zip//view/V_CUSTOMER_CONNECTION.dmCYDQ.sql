create view V_CUSTOMER_CONNECTION as
select CONNECTION_ID,
       ENTITY_ID,
       CUSTOMER_ID,
       CUSTOMER_CODE,
       CONNECTION_RELATION,
       CONNECTION_CUSTOM_CODE,
       ACTIVE_FLAG,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATE_DATE,
       LAST_UPDATE_BY,
       LAST_INTERFACE_DATE,
       SIEBEL_CUSTOMER_ID,
       SIEBEL_CONNECTION_ID,
       PRE_FIELD_01,
       PRE_FIELD_02,
       PRE_FIELD_03,
       PRE_FIELD_04,
       PRE_FIELD_05,
       PRE_FIELD_06
  from T_CUSTOMER_CONNECTION with read only
/

comment on column V_CUSTOMER_CONNECTION.CONNECTION_ID is '关联关系ID'
/

comment on column V_CUSTOMER_CONNECTION.ENTITY_ID is '主体ID'
/

comment on column V_CUSTOMER_CONNECTION.CUSTOMER_ID is '客户ID'
/

comment on column V_CUSTOMER_CONNECTION.CUSTOMER_CODE is '客户编码'
/

comment on column V_CUSTOMER_CONNECTION.CONNECTION_RELATION is '关联关系'
/

comment on column V_CUSTOMER_CONNECTION.CONNECTION_CUSTOM_CODE is '关联客户编码'
/

comment on column V_CUSTOMER_CONNECTION.ACTIVE_FLAG is '是否有效(Y/N)'
/

comment on column V_CUSTOMER_CONNECTION.CREATED_BY is '创建人'
/

comment on column V_CUSTOMER_CONNECTION.CREATION_DATE is '创建日期'
/

comment on column V_CUSTOMER_CONNECTION.LAST_UPDATE_DATE is '最后修改时间'
/

comment on column V_CUSTOMER_CONNECTION.LAST_UPDATE_BY is '最后修改人'
/

comment on column V_CUSTOMER_CONNECTION.LAST_INTERFACE_DATE is '最后同步时间'
/

comment on column V_CUSTOMER_CONNECTION.SIEBEL_CUSTOMER_ID is '主数据客户ID'
/

comment on column V_CUSTOMER_CONNECTION.SIEBEL_CONNECTION_ID is '主数据关联关系ID'
/

comment on column V_CUSTOMER_CONNECTION.PRE_FIELD_01 is '预留字段1'
/

comment on column V_CUSTOMER_CONNECTION.PRE_FIELD_02 is '预留字段2'
/

comment on column V_CUSTOMER_CONNECTION.PRE_FIELD_03 is '预留字段3'
/

comment on column V_CUSTOMER_CONNECTION.PRE_FIELD_04 is '预留字段4'
/

comment on column V_CUSTOMER_CONNECTION.PRE_FIELD_05 is '预留字段5'
/

comment on column V_CUSTOMER_CONNECTION.PRE_FIELD_06 is '预留字段6'
/

