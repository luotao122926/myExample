create procedure P_INV_TRSF_TRANSACTION(I_ENTITY_ID IN INTEGER) IS
  /**
  调拨单对账逻辑：
  1、获取已产生库存事务的调拨单，比对CIMS与GERP的库存事务汇总数(单据号、仓库、产品)
  2、获取CIMS单据应该产生库存事务，但未产生库存事务的单据信息
  */
  /** v1.1
     增加不需要对账内容
  
  */

  /** v1.2
      1、完善调拨库存事务，A->B->C，增加库存事务差异核对，存在不一致时删除已对账的调拨单，重新对账  
      2、性能优化
  */

  --declare
  -- Local variables here
  --  i integer;

  -- 记录数比较
  i_inv_bill_count integer;

  --CIMS库存事务记录数
  count_inv_cims integer;
  --GERP库存事务记录数
  count_inv_gerp integer;

  --数量
  i_qty_temp number;

  -- 主体
  v_entity_id integer;

  -- 执行SQL后是否及时提交事务
  b_immediate_commit boolean;

  -- 单据对账结果
  str_status varchar2(2);
  -- 对账开始日期
  str_start_date varchar2(20);
  -- 对账结束日期
  str_end_date varchar2(20);
  -- 错误信息
  str_msg varchar2(2000);
  -- 对账过程中单据行信息
  str_bill_line_msg varchar2(2000);

  -- 备注长度，1000个字(数字、字母、汉字均按照1个字计算)
  i_remark_length number := 1000;

  --单据最终状态-接收
  str_status_end varchar2(2);

  --单据状态名称
  str_status_meaning varchar2(20);

  -- 调拨单、仓库、产品编码、CIMS数量、GERP数量，差异原因
  str_select_sql varchar2(4000);
  -- 插入对照表SQL
  str_insert_sql varchar2(4000);
  -- 删除已出错单据
  str_delete_sql varchar2(4000);

  --  CIMS已发生库存事务单据
  cursor trsf_all(in_entity_id number, in_start_date varchar2, in_end_date varchar2) is
    select inv_trsf.trsf_order_num bill_no,
           bill_type.bill_period_head_id,
           bill_type.bill_type_name bill_type
      from cims.t_inv_trsf_order inv_trsf, cims.t_inv_bill_types bill_type
     where inv_trsf.entity_id = in_entity_id
          --and inv_trsf.trsf_order_num='B100001373'
       and inv_trsf.bill_type_id = bill_type.bill_type_id
       and exists (select 1
              from cims.t_inv_transaction_history invh
             where invh.business_num = inv_trsf.trsf_order_num
               and invh.transaction_date >=
                   to_date(in_start_date, 'yyyy-mm-dd')
               and invh.transaction_date <
                   to_date(in_end_date, 'yyyy-mm-dd'))
       and not exists
     (select 1
              from cims.t_inv_taction_reconciliation rec
             where rec.business_num = inv_trsf.trsf_order_num
                  --and rec.inv_code = inv_trsf.ship_inv_code
               and rec.entity_id = in_entity_id);

  -- 单据周期
  cursor bill_period(in_period_head_id number) is
    select inv_period_l.bill_status_code status
      from cims.t_inv_bill_period_line inv_period_l
     where inv_period_l.transaction_flag = 'Y'
       and inv_period_l.bill_period_head_id = in_period_head_id;

  -- 调拨单库存事务 ----, in_status varchar2
  cursor trsf_inv_cims(in_entity_id number, in_bill_no varchar2) is
    select 'CIMS' sys_name,
           inv_his.business_num bill_no,
           inv_his.inventory_code inv_code,
           inv_his.item_code,
           sum(inv_his.transaction_quantity) qty
      from cims.t_inv_transaction_history inv_his
     where inv_his.entity_id = in_entity_id
       and inv_his.business_num = in_bill_no
    --and inv_his.business_state = in_status
     group by inv_his.business_num,
              inv_his.inventory_code,
              inv_his.item_code;

  -- 调拨单未产生库存事务，与单据周期关联
  cursor trsf_inv_cims_nexists(in_entity_id number, in_status_end varchar2) is
    select bill_no, inv_code, item_code, status, bill_type, sum(qty) qty
      from (select trsf.trsf_order_num bill_no,
                   decode(bill_type.cancel_flag,
                          'Y',
                          trsf.consignee_inv_code,
                          trsf.ship_inv_code) inv_code,
                   trsf_d.item_code item_code,
                   period_l.bill_status_code status,
                   bill_type.bill_type_name bill_type,
                   trsf_d.billed_qty qty
              from cims.t_inv_trsf_order             trsf,
                   cims.t_inv_trsf_order_line_detail trsf_d,
                   cims.t_inv_bill_types             bill_type,
                   cims.t_inv_bill_period_line       period_l
             where trsf.bill_type_id = bill_type.bill_type_id
               and bill_type.bill_period_head_id =
                   period_l.bill_period_head_id
               and trsf.trsf_order_id = trsf_d.trsf_order_id
               and bill_type.entity_id = in_entity_id
               and period_l.transaction_flag = 'Y'
               and period_l.bill_status_code <> in_status_end
               and trsf.trsf_order_status >= period_l.bill_status_code
               and not exists
             (select 1
                      from cims.t_inv_transaction_history invh
                     where invh.business_num = trsf.trsf_order_num
                       and invh.inventory_code =
                           decode(bill_type.cancel_flag,
                                  'Y',
                                  trsf.consignee_inv_code,
                                  trsf.ship_inv_code)
                       and invh.item_code = trsf_d.item_code
                       and invh.business_state = period_l.bill_status_code)
            union all
            select trsf.trsf_order_num bill_no,
                   decode(bill_type.cancel_flag,
                          'Y',
                          trsf.ship_inv_code,
                          trsf.consignee_inv_code) inv_code,
                   trsf_d.item_code item_code,
                   period_l.bill_status_code status,
                   bill_type.bill_type_name bill_type,
                   trsf_d.billed_qty qty
              from cims.t_inv_trsf_order             trsf,
                   cims.t_inv_trsf_order_line_detail trsf_d,
                   cims.t_inv_bill_types             bill_type,
                   cims.t_inv_bill_period_line       period_l
             where trsf.bill_type_id = bill_type.bill_type_id
               and bill_type.bill_period_head_id =
                   period_l.bill_period_head_id
               and trsf.trsf_order_id = trsf_d.trsf_order_id
               and bill_type.entity_id = in_entity_id
               and period_l.bill_status_code = in_status_end
               and period_l.transaction_flag = 'Y'
               and trsf.trsf_order_status >= period_l.bill_status_code
               and not exists
             (select 1
                      from cims.t_inv_transaction_history invh
                     where invh.business_num = trsf.trsf_order_num
                       and invh.inventory_code =
                           decode(bill_type.cancel_flag,
                                  'Y',
                                  trsf.ship_inv_code,
                                  trsf.consignee_inv_code)
                       and invh.item_code = trsf_d.item_code
                       and invh.business_state = period_l.bill_status_code))
     group by bill_no, inv_code, item_code, status, bill_type;

  -- 获取需删除重新对账的单据
  cursor c_get_reconciliation_bills(in_entity_id_f in varchar2) is
    select distinct his.business_num
      from cims.t_inv_transaction_history his
     where his.entity_id = in_entity_id_f
       and exists (select 1
              from cims.t_inv_taction_reconciliation rec
             where rec.entity_id = in_entity_id_f
               and rec.reconciliation_type = 'TRSF_ORDER'
               and his.business_num = rec.business_num)
       and not exists (select 1
              from cims.t_inv_taction_reconciliation rec
             where rec.entity_id = in_entity_id_f
               and his.business_num = rec.business_num
               and his.item_code = rec.item_code
               and his.inventory_code = rec.inv_code)
       and not exists
     (select 1
              from cims.t_inv_taction_reconcil_line recl
             where recl.business_num = his.business_num);

  -- 返回不对账的SQL
  function f_get_n_reconciliation(in_entity_id_f in varchar2) return varchar2 is
    return_sql      varchar2(4000);
    return_sql_temp varchar2(4000);
  begin
    return_sql_temp := 'select inv_bill.bill_type_name business_type, ' ||
                       '       h.business_num bill_no, ' ||
                       '       h.inventory_code inv_code, ' ||
                       '       h.item_code item_code, ' ||
                       '       sum(h.transaction_quantity) cims_qty, ' ||
                       '       sum(h.transaction_quantity) gerp_qty ' ||
                       '  from cims.t_inv_transaction_history h, cims.t_inv_bill_types inv_bill ' ||
                       ' where h.entity_id = ' || in_entity_id_f ||
                       '   and h.bill_type_id = inv_bill.bill_type_id ' ||
                       '   and h.entity_id = inv_bill.entity_id ' ||
                       '  and not exists(select 1 from cims.t_inv_taction_reconciliation rec ' ||
                       '  where rec.entity_id=' || in_entity_id_f ||
                       '    and rec.business_num=h.business_num ' ||
                       '    and rec.inv_code=h.inventory_code ' ||
                       '    and rec.reconciliation_type = ''TRSF_ORDER''' ||
                       '    and rec.item_code=h.item_code)' ||
                       '   and exists (select 1 ' ||
                       '          from cims.t_inv_taction_reconcil_line recl ' ||
                       '         where h.business_num = recl.business_num ' ||
                       '           and recl.reconciliation_type = ''TRSF_ORDER'') ' ||
                       ' group by inv_bill.bill_type_name, ' ||
                       '          h.business_num, ' ||
                       '          h.inventory_code, ' ||
                       '          h.item_code ';
  
    return_sql := ' insert into cims.t_inv_taction_reconciliation ' ||
                  '  (entity_id, ' || '   business_type, ' ||
                  '   business_num, ' || '   reconciliation_time, ' ||
                  '   reconciliation_flag, ' || '   status, ' ||
                  '   inv_code, ' || '   item_code, ' || '   cims_qty, ' ||
                  '   gerp_qty, ' || '   remark, ' || '   created_by, ' ||
                  '   creation_date, ' || '   last_updated_by, ' ||
                  '   last_update_date,reconciliation_type,' ||
                  'erp_order_header_id,erp_logist_header_id) ' ||
                  ' select ' || in_entity_id_f ||
                  ' entity_id, business_type, bill_no  business_num, ' ||
                  ' sysdate  reconciliation_time, ' ||
                  ' ''00''  reconciliation_flag, decode(sign(cims_qty-cims_qty),0,''00'',''01'')  status, ' ||
                  '   inv_code, ' || '   item_code, ' || '   cims_qty, ' ||
                  ' cims_qty gerp_qty, ' ||
                  '   ''调拨单账务调整-无差异'' remark, ' ||
                  ' ''SYS''  created_by, ' || ' sysdate  creation_date, ' ||
                  ' ''SYS''  last_updated_by, ' ||
                  ' sysdate  last_update_date,''TRSF_ORDER'' reconciliation_type,0 erp_order_header_id,0 erp_logist_header_id from (' ||
                  return_sql_temp || ') bill_all ' || '  where 1=1 ';
  
    return return_sql;
  end;
begin
  -- Test statements here

  --v_entity_id        := 10;
  v_entity_id := I_ENTITY_ID;
  --str_start_date     := '2015-01-01';
  str_start_date     := to_char(sysdate - 90, 'yyyy-mm-dd');
  str_end_date       := to_char(sysdate + 1, 'yyyy-mm-dd'); --全部核对
  b_immediate_commit := true; -- 全过程处理一次完成

  str_status_end := '13'; --单据接收状态

  -- 删除对账失败单据 ''TRSF_ORDER'' reconciliation_type
  str_delete_sql := ' delete cims.t_inv_taction_reconciliation rec ' ||
                    '  where rec.entity_id = ' || v_entity_id ||
                    '   and rec.reconciliation_type= ''TRSF_ORDER''' ||
                    '   and exists (select 1 ' ||
                    '          from cims.t_inv_taction_reconciliation rec2 ' ||
                    '         where rec.business_num = rec2.business_num ' ||
                    '           and rec2.status = ''01''' ||
                    '           and rec2.reconciliation_type = ''TRSF_ORDER'')  ';

  execute immediate str_delete_sql;

  if b_immediate_commit then
    commit;
  end if;

  -- 需重新对账
  for reconciliation_bill01 in c_get_reconciliation_bills(v_entity_id) loop
    str_delete_sql := ' delete cims.t_inv_taction_reconciliation rec ' ||
                      '  where rec.entity_id = ' || v_entity_id ||
                      '   and rec.reconciliation_type= ''TRSF_ORDER''' ||
                      '   and  rec.business_num = ''' ||
                      reconciliation_bill01.business_num || '''';
  
    execute immediate str_delete_sql;
  
    -- 存在需要重新对账单据时，从1年前开始对账
    str_start_date := to_char(sysdate - 365, 'yyyy-mm-dd');
  
    if b_immediate_commit then
      commit;
    end if;
  end loop;

  --不参与对账单据
  str_insert_sql := f_get_n_reconciliation(v_entity_id);

  if str_insert_sql is not null then
    execute immediate str_insert_sql;
    if b_immediate_commit then
      commit;
    end if;
  end if;

  -- 所有调拨单
  for trsf_all_01 in trsf_all(v_entity_id, str_start_date, str_end_date) loop
    -- 单据周期
    --for bill_period_01 in bill_period(trsf_all_01.bill_period_head_id) loop
    -- str_delete_sql
    --exit when(trsf_all_01.status <> bill_period_01.status) and(bill_period_01.status <> '13');
  
    -- 区分不了ERP在途，合并校验
    for trsf_inv_cims_01 in trsf_inv_cims(v_entity_id, trsf_all_01.bill_no) loop
    
      -- count_inv_cims
      select count(*)
        into count_inv_cims
        from cims.t_inv_transaction_history invh
       where invh.entity_id = v_entity_id
         and invh.business_num = trsf_all_01.bill_no
         and invh.inventory_code = trsf_inv_cims_01.inv_code
         and invh.item_code = trsf_inv_cims_01.item_code;
    
      select count(*)
        into count_inv_gerp
        from apps.mtl_material_transactions@mdims2mderp inv_erp,
             apps.mtl_system_items_b@mdims2mderp        mtl
       where 1 = 1
         and inv_erp.inventory_item_id = mtl.inventory_item_id
         and inv_erp.organization_id = mtl.organization_id
         and inv_erp.transaction_reference = trsf_all_01.bill_no
         and inv_erp.subinventory_code = trsf_inv_cims_01.inv_code
         and mtl.segment1 = trsf_inv_cims_01.item_code
         and inv_erp.source_code = 'CIMS';
    
      select sum(inv_erp.transaction_quantity)
        into i_qty_temp
        from apps.mtl_material_transactions@mdims2mderp inv_erp,
             apps.mtl_system_items_b@mdims2mderp        mtl
       where 1 = 1
         and inv_erp.inventory_item_id = mtl.inventory_item_id
         and inv_erp.organization_id = mtl.organization_id
         and inv_erp.transaction_reference = trsf_inv_cims_01.bill_no
         and inv_erp.subinventory_code = trsf_inv_cims_01.inv_code
         and mtl.segment1 = trsf_inv_cims_01.item_code
         and inv_erp.source_code = 'CIMS';
    
      if (count_inv_cims = count_inv_gerp) and
         (trsf_inv_cims_01.qty = i_qty_temp) then
        begin
          str_bill_line_msg := null; --'调拨单无差异';
        end;
      else
        begin
          select count(*)
            into i_inv_bill_count
            from cims.intf_inv_transaction_head invh
           where invh.order_num = trsf_inv_cims_01.bill_no
             and invh.status <> 'S';
        
          -- 取其中1个的事务异常
          if i_inv_bill_count >= 1 then
            begin
              select decode(nvl(invh.error_flag, 'N'),
                            'Y',
                            invh.error_msg,
                            decode(nvl(invh.response_type, 'N'),
                                   'E',
                                   invh.response_message,
                                   '等待GERP返回调拨单处理结果'))
                into str_bill_line_msg
                from cims.intf_inv_transaction_head invh
               where invh.order_num = trsf_inv_cims_01.bill_no
                 and invh.status <> 'S'
                 and rownum < 2;
            
              if str_bill_line_msg is not null then
                str_bill_line_msg := '调拨单有差异,' || str_bill_line_msg;
              end if;
            end;
          else
            begin
              if (trsf_inv_cims_01.qty = i_qty_temp) then
                str_bill_line_msg := null; --'调拨单有差异，库存事务数相同，库存事务重复';
              else
                str_bill_line_msg := '调拨单有差异，GERP返回处理成功，CIMS与GERP库存事务数量不同，建议人工核对';
              end if;
            end;
          end if; -- end if i_inv_bill_count >= 1
        end;
        --end if; -- if (count_inv_cims > count_inv_gerp)
      end if; -- end 库存事务数量、记录数不一致 if (count_inv_cims = count_inv_gerp) and
    
      if str_bill_line_msg is null then
        str_msg    := '调拨单无差异';
        str_status := '00';
      else
        str_msg    := str_bill_line_msg;
        str_status := '01';
      end if;
    
      str_select_sql := 'select bill_no,inv_code,item_code,sum(cims_qty) cims_qty,' ||
                        'sum(gerp_qty) gerp_qty,substr(''' || str_msg ||
                        ''',1,' || i_remark_length || ') remark ' ||
                        ' from (select invh.business_num bill_no,' ||
                        '  invh.inventory_code inv_code,' ||
                        '  invh.item_code,' ||
                        '  invh.transaction_quantity cims_qty,' ||
                        '  0 gerp_qty ' ||
                        '  from cims.t_inv_transaction_history invh' ||
                        ' where invh.entity_id = ' || v_entity_id ||
                        ' and invh.business_num = ''' ||
                        trsf_all_01.bill_no ||
                        ''' and invh.inventory_code = ''' ||
                        trsf_inv_cims_01.inv_code ||
                        ''' and invh.item_code = ''' ||
                        trsf_inv_cims_01.item_code || ''' union all ' ||
                        ' select inv_erp.transaction_reference bill_no,' ||
                        '  inv_erp.subinventory_code inv_code,' ||
                        '  mtl.segment1 item_code,' || '  0 cims_qty,' ||
                        '  inv_erp.transaction_quantity gerp_qty ' ||
                        '  from apps.mtl_material_transactions@mdims2mderp inv_erp,' ||
                        '  apps.mtl_system_items_b@mdims2mderp        mtl' ||
                        ' where 1 = 1 ' ||
                        ' and inv_erp.inventory_item_id = mtl.inventory_item_id ' ||
                        ' and inv_erp.organization_id = mtl.organization_id ' ||
                        '   and inv_erp.transaction_reference = ''' ||
                        trsf_all_01.bill_no ||
                        ''' and inv_erp.subinventory_code = ''' ||
                        trsf_inv_cims_01.inv_code ||
                        ''' and mtl.segment1 = ''' ||
                        trsf_inv_cims_01.item_code ||
                        ''' and inv_erp.source_code=''CIMS'')' ||
                        ' group by bill_no,inv_code,item_code ';
    
      str_insert_sql := ' insert into cims.t_inv_taction_reconciliation ' ||
                        '  (entity_id, ' || '   business_type, ' ||
                        '   business_num, ' || '   reconciliation_time, ' ||
                        '   reconciliation_flag, ' || '   status, ' ||
                        '   inv_code, ' || '   item_code, ' ||
                        '   cims_qty, ' || '   gerp_qty, ' || '   remark, ' ||
                        '   created_by, ' || '   creation_date, ' ||
                        '   last_updated_by, ' ||
                        '   last_update_date,reconciliation_type) ' ||
                        ' select ' || v_entity_id || ' entity_id, ''' ||
                        trsf_all_01.bill_type || '''   business_type, ''' ||
                        trsf_all_01.bill_no || '''   business_num, ' ||
                        ' sysdate  reconciliation_time, ' ||
                        ' ''00''  reconciliation_flag, ' || ' ''' ||
                        str_status || '''  status, ' || '   inv_code, ' ||
                        '   item_code, ' || '   cims_qty, ' ||
                        '   gerp_qty, ' || '   remark, ' ||
                        ' ''SYS''  created_by, ' ||
                        ' sysdate  creation_date, ' ||
                        ' ''SYS''  last_updated_by, ' ||
                        ' sysdate  last_update_date,''TRSF_ORDER'' reconciliation_type from (' ||
                        str_select_sql || ') bill_all ' || '  where 1=1 ' ||
                        '  and not exists(select 1 from cims.t_inv_taction_reconciliation recc' ||
                        '  where recc.entity_id=' || v_entity_id ||
                        ' and recc.business_num=bill_all.bill_no ' ||
                        ' and recc.inv_code=bill_all.inv_code ' ||
                        ' and recc.reconciliation_type = ''TRSF_ORDER''' ||
                        ' and recc.item_code=bill_all.item_code)';
    
      --dbms_output.put_line(str_select_sql);    
      -- execute immediate str_select_sql;
      execute immediate str_insert_sql;
    
      if b_immediate_commit then
        commit;
      end if;
    
    end loop; -- end  for trsf_inv_cims_01
  
  end loop; -- end 调拨单 for trsf_all_01

  -- 应该产生库存事务但未产生库存事务单据
  for trsf_inv_cims_nexists_01 in trsf_inv_cims_nexists(v_entity_id,
                                                        str_status_end) loop
    -- str_status_meaning
    select codelist.code_name
      into str_status_meaning
      from cims.up_codelist codelist
     where codelist.codetype = 'INV_TRSF_ORDER_STATUS'
       and codelist.code_value = trsf_inv_cims_nexists_01.status
       and rownum < 2;
  
    str_bill_line_msg := '调拨单有差异，单据在' || str_status_meaning ||
                         '时CIMS未产生库存事务,数量' ||
                         trsf_inv_cims_nexists_01.qty;
  
    select nvl(sum(inv_erp.transaction_quantity), 0) qty
      into i_qty_temp
      from apps.mtl_material_transactions@mdims2mderp inv_erp,
           apps.mtl_system_items_b@mdims2mderp        mtl
     where 1 = 1
       and inv_erp.inventory_item_id = mtl.inventory_item_id
       and inv_erp.organization_id = mtl.organization_id
       and inv_erp.transaction_reference = trsf_inv_cims_nexists_01.bill_no
       and inv_erp.subinventory_code = trsf_inv_cims_nexists_01.inv_code
       and mtl.segment1 = trsf_inv_cims_nexists_01.item_code
       and inv_erp.source_code = 'CIMS';
  
    str_select_sql := ' select ''' || trsf_inv_cims_nexists_01.bill_no ||
                      ''' bill_no ,''' || trsf_inv_cims_nexists_01.inv_code ||
                      ''' inv_code,''' ||
                      trsf_inv_cims_nexists_01.item_code || ''' item_code,' || '''' ||
                      trsf_inv_cims_nexists_01.bill_type ||
                      ''' bill_type,0 cims_qty,' || ' ' || i_qty_temp ||
                      ' gerp_qty,substr(''' || str_bill_line_msg || ''',1,' ||
                      i_remark_length || ') remark ' || ' from dual ';
  
    str_insert_sql := ' insert into cims.t_inv_taction_reconciliation ' ||
                      '  (entity_id, ' || '   business_type, ' ||
                      '   business_num, ' || '   reconciliation_time, ' ||
                      '   reconciliation_flag, ' || '   status, ' ||
                      '   inv_code, ' || '   item_code, ' ||
                      '   cims_qty, ' || '   gerp_qty, ' || '   remark, ' ||
                      '   created_by, ' || '   creation_date, ' ||
                      '   last_updated_by, ' ||
                      '   last_update_date,reconciliation_type) ' ||
                      ' select ' || v_entity_id ||
                      ' entity_id, bill_type  business_type, ''' ||
                      trsf_inv_cims_nexists_01.bill_no ||
                      '''   business_num, ' ||
                      ' sysdate  reconciliation_time, ' ||
                      ' ''00''  reconciliation_flag, ' ||
                      ' ''01''  status, ' || '   inv_code, ' ||
                      '   item_code, ' || '   cims_qty, ' ||
                      '   gerp_qty, ' || '   remark, ' ||
                      ' ''SYS''  created_by, ' ||
                      ' sysdate  creation_date, ' ||
                      ' ''SYS''  last_updated_by, ' ||
                      ' sysdate  last_update_date,''TRSF_ORDER'' reconciliation_type from (' ||
                      str_select_sql || ') bill_all ' || '  where 1=1 ' ||
                      '  and not exists(select 1 from cims.t_inv_taction_reconciliation recc' ||
                      '  where recc.entity_id=' || v_entity_id ||
                      ' and recc.business_num=bill_all.bill_no ' ||
                      ' and recc.inv_code=bill_all.inv_code ' ||
                      ' and recc.reconciliation_type = ''TRSF_ORDER''' ||
                      ' and recc.item_code=bill_all.item_code)';
  
    --execute immediate str_select_sql;
    execute immediate str_insert_sql;
    if b_immediate_commit then
      commit;
    end if;
  end loop;

  commit;

end P_INV_TRSF_TRANSACTION;
/

