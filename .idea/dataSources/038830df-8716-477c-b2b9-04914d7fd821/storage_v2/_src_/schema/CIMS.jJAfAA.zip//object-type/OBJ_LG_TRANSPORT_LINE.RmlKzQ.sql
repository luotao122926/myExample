create TYPE "OBJ_LG_TRANSPORT_LINE" As Object
(
  ENTITY_ID            NUMBER,
  Transport_Line_Id    Number,
  Transport_Line_Code  Varchar2(32),
  Transport_Line_Name  Varchar2(240),
  Begin_Area_Id        Number,
  Begin_Area_Code      Varchar2(32),
  Begin_Area_Name      Varchar2(240),
  Src_Begin_Area_Code  Varchar2(32),
  End_Area_Id          Number,
  End_Area_Code        Varchar2(32),
  End_Area_Name        Varchar2(240),
  Src_End_Area_Code    Varchar2(32),
  Min_Transport_Volume Number,
  Max_Transport_Volume Number,
  Transport_Mileage    Number,
  Ship_Mode            Varchar2(32),
  Valid_State          Varchar2(32),
  Transport_Line_Days  Number,
  INTEGRAL_TRANSPORT_DAYS number,
  SCATTE_TRANSPORT_DAYS NUMBER,
  ASSEMBLE_LINE        Varchar2(50),
  ASSEMBLE_LINE_NAME   Varchar2(240),
  transport_line_type  Varchar2(32),
  prescription         Varchar2(32),
  prescription_name    Varchar2(100)
)
/

