create view V_INV_STORAGE_CONTRACT_LINE as
Select t."INV_CONT_LINE_ID",
       t."ENTITY_ID",t."INV_CONT_HEAD_ID",
       t."MONTHS",
       t."USE_AREA",
       t."SUM_AMOUNT",
       t."INV_CGARGES_AMOUNT",
       t."INV_MANAGE_AMOUNT",
       t."CHARGES_TOTAL",
       t."CHARGES_TOTAL_WITH_TAX",
       t."TAXES",t."TAX_RATE",
       t."ADJUST_AMOUNT",
       t."ADJUST_BY",
       t."ADJUST_BY_NAME",
       t."ADJUST_DATE",
       t."ADJUST_MRP_NUM",
       t."CLEARED_LOT",
       t."TO_DOC_INFO_FLAG",
       t."DOC_LAND_ID",
       t."DOC_LAND_CODE",
       t."DOC_LAND_TITLE",
       t."TO_EMS_FLAG",
       t."TO_EMS_ERR_MSG",
       t."TO_EMS_DATE",
       t."CREATED_BY",
       t."CREATION_DATE",
       t."LAST_UPDATED_BY",
       t."LAST_UPDATE_DATE",
       t."REMARK",
       t."INC_DEC_AMOUNT",
       t."INV_CONT_RELATE_ID_ALL"
   From T_INV_STORAGE_CONTRACT_LINE t
/

comment on table V_INV_STORAGE_CONTRACT_LINE is '仓储合同信息行表'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.INV_CONT_LINE_ID is '仓库合同行ID'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.ENTITY_ID is '主体ID'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.INV_CONT_HEAD_ID is '仓储合同头ID'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.MONTHS is '月份'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.USE_AREA is '使用面积'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.SUM_AMOUNT is '总额'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.INV_CGARGES_AMOUNT is '仓储费金额'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.INV_MANAGE_AMOUNT is '管理费金额'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.CHARGES_TOTAL is '费用总额'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.CHARGES_TOTAL_WITH_TAX is '费用总额(含税)'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.TAXES is '税额'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.TAX_RATE is '税率'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.ADJUST_AMOUNT is '扣转款金额'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.ADJUST_BY is '调整人'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.ADJUST_BY_NAME is '调整人姓名'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.ADJUST_DATE is '调整日期'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.ADJUST_MRP_NUM is '调整凭证'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.CLEARED_LOT is '结算批号'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.TO_DOC_INFO_FLAG is '申请批文标志'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.DOC_LAND_ID is '批文头ID'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.DOC_LAND_CODE is '批文编码'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.DOC_LAND_TITLE is '批文标题'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.TO_EMS_FLAG is '引入EMS接口标志'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.TO_EMS_ERR_MSG is '引入EMS接口错误信息'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.TO_EMS_DATE is '引EMS接口日期'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.CREATED_BY is '创建者'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.CREATION_DATE is '创建日期'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.LAST_UPDATED_BY is '更新者'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.LAST_UPDATE_DATE is '更新日期'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.REMARK is '备注'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.INC_DEC_AMOUNT is '增减金额'
/

comment on column V_INV_STORAGE_CONTRACT_LINE.INV_CONT_RELATE_ID_ALL is '根据合同选中的行，行ID的值，使用“，”分隔开'
/

