create package      PKG_CREDIT_INTF_CCS is
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-08-01
  *     创建者：梁颜明
  *   功能说明：CSS调用小电铺底单据从接口表同步到业务表的处理
  *
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_INTF_CREDIT_DELAYPAY_BILL(P_SRC_BILL_ID IN NUMBER, --接口铺底单据ID
                                          P_BILL_ID     OUT NUMBER, --铺底单据ID
                                          P_RESULT      IN OUT NUMBER, --返回错误ID
                                          P_ERR_MSG     IN OUT VARCHAR2 --返回错误信息
                                          );
end PKG_CREDIT_INTF_CCS;
/

