create view V_AR_CASH_TURNFEE_AMOUNT as
select sum(t1.amount) as amount                                --核销金额
          ,t2.customer_id                                         --转出客户ID
          ,t2.customer_code                                       --转出客户编码
          ,t2.customer_name                                       --转出客户名称
          ,t2.account_id                                          --转出账户ID
          ,t2.account_code                                        --转出账户编码
          ,t2.account_name                                        --转出账户名称
          ,t2.erp_ou_id                                           --erp_ou_id
  from T_SO_ORDER_RECEIPT                t1                                           --核销表
      ,T_AR_CASH_RECEIPT_HEADERS         t2                                           --收款头表
  where t1.cash_receipt_id = t2.cash_receipt_id AND T1.TO_ERP_FLAG='N'
  group by
           t2.customer_id
          ,t2.customer_code
          ,t2.customer_name
          ,t2.account_id
          ,t2.account_code
          ,t2.account_name
          ,t2.cash_receipt_id
          ,t2.erp_ou_id
/

