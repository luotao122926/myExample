create view V_SO_HEADER_FOR_AR as
SELECT SO_HEADER_ID,
       ENTITY_ID,
       SALES_YEAR_ID,
       BILL_TYPE_ID,
       BILL_TYPE_CODE,
       BILL_TYPE_NAME,
       BIZ_SRC_BILL_TYPE_ID,
       BIZ_SRC_BILL_TYPE_CODE,
       BIZ_SRC_BILL_TYPE_NAME,
       SO_NUM,
       SO_STATUS,
       SO_DATE,
       ORIG_SO_NUM,
       SRC_BILL_TYPE_ID,
       SRC_BILL_ID,
       SRC_BILL_NUM,
       PROJECT_TYPE_CODE,
       PROJECT_ID,
       PROJECT_NUM,
       BRAND_ID,
       BRAND_CODE,
       BRAND_NAME,
       SALES_MAIN_TYPE,
       SALES_MAIN_TYPE_NAME,
       CUSTOMER_ID,
       CUSTOMER_CODE,
       CUSTOMER_NAME,
       ACCOUNT_ID,
       ACCOUNT_CODE,
       ACCOUNT_NAME,
       CUST_ORDER_NUM,
       CUST_ORDER_DATE,
       SALES_CENTER_ID,
       SALES_CENTER_CODE,
       SALES_CENTER_NAME,
       PROJ_REG_CODE,
       SHIP_INV_ID,
       SHIP_INV_CODE,
       SHIP_INV_NAME,
       CONSIGNEE_INV_ID,
       CONSIGNEE_INV_CODE,
       CONSIGNEE_INV_NAME,
       CONSIGNEE_ADDRESS_ID,
       CONSIGNEE_ADDRESS,
       CONSIGNEE_PROVINCE_CODE,
       CONSIGNEE_CITY_CODE,
       CONSIGNEE_DISTRICT_CODE,
       MIDDLE_INV_ID,
       MIDDLE_INV_CODE,
       MIDDLE_INV_NAME,
       SELF_PICK_FLAG,
       SHIP_WAY,
       SHIP_WAY_NAME,
       VEHICLE_NUM,
       CONTRACT_CODE,
       SHIP_INFO_ID,
       VENDOR_ID,
       VENDOR_NAME,
       INC_DEC_CODE,
       COMPENSATION_FLAG,
       SHIP_FLAG,
       SHIP_DATE,
       DIRECT_SHIP_FLAG,
       RECEIVE_FLAG,
       RECEIVE_DATE,
       CHECKED_ACCOUNT_FLAG,
       CHECKED_ACCOUNT_DATE,
       REVERSAL_FLAG,
       APPLIED_FLAG,
       APPLIED_DATE,
       REMARK,
       AUDIT_BY,
       AUDIT_FLAG,
       AUDIT_RESULT,
       AUDIT_OPINION,
       AUDIT_DATE,
       LIST_AMOUNT,
       SETTLE_AMOUNT,
       DISCOUNT_AMOUNT,
       SETTLE_FLAG,
       SETTLED_BY,
       SETTLE_DATE,
       PRINT_PRICE_FLAG,
       ALLOW_AUTO_SETTLE_FLAG,
       LOCKED_FLAG,
       PRINTED_TIMES,
       INV_TRANS_FLAG1,
       INV_TRANS_FLAG2,
       INV_TRANS_TIME2,
       INV_TRANS_TIME1,
       FUND_CTRL_MODE,
       FUND_SRC_TYPE,
       FUND_SRC_NUM,
       CANCLED_BY,
       CANCLED_DATE,
       CLOSED_BY,
       CLOSED_DATE,
       REVERSALED_BY,
       REVERSALED_DATE,
       ERP_OU_ID,
       ERP_SUBINV_ID,
       ERP_SO_ID,
       ERP_SO_CODE,
       ERP_PICK_FLAG,
       ERP_SHIP_FLAG,
       ERP_SHIP_CODE,
       ERP_ARINVOICE_CODE,
       ERP_RECEIVED_FLAG,
       ERP_CREDIT_MEMO_CODE,
       ERP_RMA_ID,
       ERP_RMA_NUM,
       FACTORY_PO_ID,
       FACTORY_PO_NUM,
       RELATED_TRANS_ID,
       RELATED_TRANS_NUM,
       REBATE_YEAR,
       PAYMENT_SRC,
       DISCOUNT_ITEM,
       DISCOUNT_MODE,
       MACHINE_MODEL,
       DISCOUNT_PROVE_FLAG,
       RECEIVED_DISCOUNT_PROVE_FLAG,
       SALES_PRICE_ID,
       SALES_REGION,
       PAYMENT_TERMS,
       INVOICE_APPLY_ID,
       INVOICE_NUM_LIST,
       INVOICE_DATE,
       INVOICE_TYPE,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATED_BY,
       LAST_UPDATE_DATE,
       RETURN_TYPE,
       RETURN_MODE,
       CREATED_MODE,
       INVOICE_CORPORATION,
       ERP_OU_NAME,
       CASH_TURNFEE_ID,
       ERP_SUBINV_CODE,
       ERP_ARINVOICE_ID,
       SRC_TYPE,
       SRC_BILL_TYPE_CODE,
       SRC_BILL_TYPE_NAME,
       MONTH_DISCOUNT_AMOUNT,
       PROJECT_AMOUNT,
       LAST_PRINTED_BY,
       LAST_PRINTED_DATE,
       RAW_SRC_TYPE,
       RAW_SRC_BILL_TYPE_ID,
       RAW_SRC_BILL_TYPE_CODE,
       RAW_SRC_BILL_ID,
       RAW_SRC_BILL_NUM,
       SO.ENTITY_CUST_FLAG,
       SO.CUSTOMER_REGISTRATION_CODE,
     so.sys_source_order_num
  FROM T_SO_HEADER SO
 WHERE NOT exists (SELECT ar.SO_HEADER_ID FROM V_SO_HEADER_BLUE_FOR_AR ar where SO.SO_HEADER_ID=ar.SO_HEADER_ID)
    AND NOT exists (SELECT H.SO_HEADER_ID FROM T_SO_HEADER H where SO.SO_HEADER_ID=H.SO_HEADER_ID and H.CREATED_BY = 'ECM' AND H.INVOICE_TYPE = '4')
    AND (NOT exists (SELECT ars.SO_NUM FROM V_SO_HEADER_BLUE_FOR_AR ars where SO.ORIG_SO_NUM=ars.SO_NUM) OR SO.ORIG_SO_NUM IS NULL)
with read only
/

comment on column V_SO_HEADER_FOR_AR.SO_HEADER_ID is '销售单据头ID'
/

comment on column V_SO_HEADER_FOR_AR.ENTITY_ID is '主体ID'
/

comment on column V_SO_HEADER_FOR_AR.SALES_YEAR_ID is '销售年度ID'
/

comment on column V_SO_HEADER_FOR_AR.BILL_TYPE_ID is '业务单据类型：从库存模块的业务单据类型表获取，包括对应的ERP订单类型（8种）。'
/

comment on column V_SO_HEADER_FOR_AR.BILL_TYPE_CODE is '业务单据类型编码'
/

comment on column V_SO_HEADER_FOR_AR.BILL_TYPE_NAME is '业务单据类型名称'
/

comment on column V_SO_HEADER_FOR_AR.BIZ_SRC_BILL_TYPE_ID is '业务单据源类型ID'
/

comment on column V_SO_HEADER_FOR_AR.BIZ_SRC_BILL_TYPE_CODE is '业务单据源类型编码：业务单据类型对应的销售单据源类型编码'
/

comment on column V_SO_HEADER_FOR_AR.BIZ_SRC_BILL_TYPE_NAME is '业务单据源类型名称：业务单据类型对应的销售单据源类型名称'
/

comment on column V_SO_HEADER_FOR_AR.SO_NUM is '单据号'
/

comment on column V_SO_HEADER_FOR_AR.SO_STATUS is '单据状态：10制单、11审核、12已结算'
/

comment on column V_SO_HEADER_FOR_AR.SO_DATE is '单据日期'
/

comment on column V_SO_HEADER_FOR_AR.ORIG_SO_NUM is '原单据号：主要是红冲单对应的原单据号。'
/

comment on column V_SO_HEADER_FOR_AR.SRC_BILL_TYPE_ID is '来源单据类型(直接来源)：计划订单、提货订单、调拨单、备货单、退货申请单、F单、F红冲单、折让单互转时的源单等。'
/

comment on column V_SO_HEADER_FOR_AR.SRC_BILL_ID is '来源单据ID(直接来源)：其实就是来源单据头ID'
/

comment on column V_SO_HEADER_FOR_AR.SRC_BILL_NUM is '来源单据号(直接来源)'
/

comment on column V_SO_HEADER_FOR_AR.PROJECT_TYPE_CODE is '批文类型编码：LIMIT-限量批文，PG-工程机批文'
/

comment on column V_SO_HEADER_FOR_AR.PROJECT_ID is '批文ID'
/

comment on column V_SO_HEADER_FOR_AR.PROJECT_NUM is '批文单号'
/

comment on column V_SO_HEADER_FOR_AR.BRAND_ID is '品牌ID'
/

comment on column V_SO_HEADER_FOR_AR.BRAND_CODE is '品牌代码'
/

comment on column V_SO_HEADER_FOR_AR.BRAND_NAME is '品牌名称'
/

comment on column V_SO_HEADER_FOR_AR.SALES_MAIN_TYPE is '营销大类编码'
/

comment on column V_SO_HEADER_FOR_AR.SALES_MAIN_TYPE_NAME is '营销大类名称'
/

comment on column V_SO_HEADER_FOR_AR.CUSTOMER_ID is '客户ID'
/

comment on column V_SO_HEADER_FOR_AR.CUSTOMER_CODE is '客户编码'
/

comment on column V_SO_HEADER_FOR_AR.CUSTOMER_NAME is '客户名称'
/

comment on column V_SO_HEADER_FOR_AR.ACCOUNT_ID is '帐户ID'
/

comment on column V_SO_HEADER_FOR_AR.ACCOUNT_CODE is '帐户编码'
/

comment on column V_SO_HEADER_FOR_AR.ACCOUNT_NAME is '帐户名称'
/

comment on column V_SO_HEADER_FOR_AR.CUST_ORDER_NUM is '客户订单号：苏宁、国美等美的外部客户的系统订单号。'
/

comment on column V_SO_HEADER_FOR_AR.CUST_ORDER_DATE is '客户订单日期'
/

comment on column V_SO_HEADER_FOR_AR.SALES_CENTER_ID is '营销中心ID'
/

comment on column V_SO_HEADER_FOR_AR.SALES_CENTER_CODE is '营销中心编码'
/

comment on column V_SO_HEADER_FOR_AR.SALES_CENTER_NAME is '营销中心名称'
/

comment on column V_SO_HEADER_FOR_AR.PROJ_REG_CODE is '项目登录号'
/

comment on column V_SO_HEADER_FOR_AR.SHIP_INV_ID is '发货仓库ID'
/

comment on column V_SO_HEADER_FOR_AR.SHIP_INV_CODE is '发货仓库编码'
/

comment on column V_SO_HEADER_FOR_AR.SHIP_INV_NAME is '发货仓库名称'
/

comment on column V_SO_HEADER_FOR_AR.CONSIGNEE_INV_ID is '收货仓库ID'
/

comment on column V_SO_HEADER_FOR_AR.CONSIGNEE_INV_CODE is '收货仓库编码'
/

comment on column V_SO_HEADER_FOR_AR.CONSIGNEE_INV_NAME is '收货仓库名称'
/

comment on column V_SO_HEADER_FOR_AR.CONSIGNEE_ADDRESS_ID is '收货地址ID'
/

comment on column V_SO_HEADER_FOR_AR.CONSIGNEE_ADDRESS is '收货地址'
/

comment on column V_SO_HEADER_FOR_AR.CONSIGNEE_PROVINCE_CODE is '收货省编码'
/

comment on column V_SO_HEADER_FOR_AR.CONSIGNEE_CITY_CODE is '收货市编码'
/

comment on column V_SO_HEADER_FOR_AR.CONSIGNEE_DISTRICT_CODE is '收货县(区)编码'
/

comment on column V_SO_HEADER_FOR_AR.MIDDLE_INV_ID is '中间仓库ID'
/

comment on column V_SO_HEADER_FOR_AR.MIDDLE_INV_CODE is '中间仓库编码'
/

comment on column V_SO_HEADER_FOR_AR.MIDDLE_INV_NAME is '中间仓库名称，主要在进行（子库）库存转移，包括：待结算仓库、退货未结算仓库等，从库存管理的相关配置表获取。'
/

comment on column V_SO_HEADER_FOR_AR.SELF_PICK_FLAG is '自提标记'
/

comment on column V_SO_HEADER_FOR_AR.SHIP_WAY is '发运方式编码'
/

comment on column V_SO_HEADER_FOR_AR.SHIP_WAY_NAME is '发运方式名称'
/

comment on column V_SO_HEADER_FOR_AR.VEHICLE_NUM is '排车编号'
/

comment on column V_SO_HEADER_FOR_AR.CONTRACT_CODE is '运输合同号'
/

comment on column V_SO_HEADER_FOR_AR.SHIP_INFO_ID is '发货信息ID'
/

comment on column V_SO_HEADER_FOR_AR.VENDOR_ID is '承运商ID'
/

comment on column V_SO_HEADER_FOR_AR.VENDOR_NAME is '承运商名称'
/

comment on column V_SO_HEADER_FOR_AR.INC_DEC_CODE is '费用增减单编号：销售全赔单费用增减单编号，物流模块回写。'
/

comment on column V_SO_HEADER_FOR_AR.COMPENSATION_FLAG is '全赔标识：销售全赔标识，N-否，Y-是。差异签收产生给承运商的销售单，都是销售全赔单。'
/

comment on column V_SO_HEADER_FOR_AR.SHIP_FLAG is '发货标记'
/

comment on column V_SO_HEADER_FOR_AR.SHIP_DATE is '发货日期'
/

comment on column V_SO_HEADER_FOR_AR.DIRECT_SHIP_FLAG is '直发标记'
/

comment on column V_SO_HEADER_FOR_AR.RECEIVE_FLAG is '签收标记'
/

comment on column V_SO_HEADER_FOR_AR.RECEIVE_DATE is '签收日期'
/

comment on column V_SO_HEADER_FOR_AR.CHECKED_ACCOUNT_FLAG is '对帐标记'
/

comment on column V_SO_HEADER_FOR_AR.CHECKED_ACCOUNT_DATE is '对账日期'
/

comment on column V_SO_HEADER_FOR_AR.REVERSAL_FLAG is '红冲标记：10-未红冲，11-全部红冲，12-部分红冲'
/

comment on column V_SO_HEADER_FOR_AR.APPLIED_FLAG is '核销标记：0-全部核销，1-部分核销，2-未核销'
/

comment on column V_SO_HEADER_FOR_AR.APPLIED_DATE is '核销日期'
/

comment on column V_SO_HEADER_FOR_AR.REMARK is '备注'
/

comment on column V_SO_HEADER_FOR_AR.AUDIT_BY is '审核人'
/

comment on column V_SO_HEADER_FOR_AR.AUDIT_FLAG is '审核标识'
/

comment on column V_SO_HEADER_FOR_AR.AUDIT_RESULT is '审核结果'
/

comment on column V_SO_HEADER_FOR_AR.AUDIT_OPINION is '审核意见'
/

comment on column V_SO_HEADER_FOR_AR.AUDIT_DATE is '审核日期'
/

comment on column V_SO_HEADER_FOR_AR.LIST_AMOUNT is '列表总金额：行产品列表金额汇总'
/

comment on column V_SO_HEADER_FOR_AR.SETTLE_AMOUNT is '结算总金额：行产品结算金额汇总'
/

comment on column V_SO_HEADER_FOR_AR.DISCOUNT_AMOUNT is '扣率折让总金额：行产品扣率折让汇总，销售单、退货单时，为使用的扣率折让金额（核销折让金额）；扣率折让单时为折让单本身的扣率折让金额（F单返利上账金额）；销售折让单、折让证明单为0。'
/

comment on column V_SO_HEADER_FOR_AR.SETTLE_FLAG is '结算标识'
/

comment on column V_SO_HEADER_FOR_AR.SETTLED_BY is '结算人'
/

comment on column V_SO_HEADER_FOR_AR.SETTLE_DATE is '结算日期'
/

comment on column V_SO_HEADER_FOR_AR.PRINT_PRICE_FLAG is '打印单价标识：用于控制打印销售单时，是否打印出产品列表价格。'
/

comment on column V_SO_HEADER_FOR_AR.ALLOW_AUTO_SETTLE_FLAG is '允许自动结算标识：用于控制是否参与自动结算。（预留暂不用）'
/

comment on column V_SO_HEADER_FOR_AR.LOCKED_FLAG is '锁定标识'
/

comment on column V_SO_HEADER_FOR_AR.PRINTED_TIMES is '打印次数'
/

comment on column V_SO_HEADER_FOR_AR.INV_TRANS_FLAG1 is '物料事务处理标识(制单)'
/

comment on column V_SO_HEADER_FOR_AR.INV_TRANS_FLAG2 is '物料事务处理标识(结算)'
/

comment on column V_SO_HEADER_FOR_AR.INV_TRANS_TIME2 is '物料事务处理时间(结算)'
/

comment on column V_SO_HEADER_FOR_AR.INV_TRANS_TIME1 is '物料事务处理时间(制单)'
/

comment on column V_SO_HEADER_FOR_AR.FUND_CTRL_MODE is '款项控制方式：用于控制款型所属类型的。'
/

comment on column V_SO_HEADER_FOR_AR.FUND_SRC_TYPE is '款项来源类型'
/

comment on column V_SO_HEADER_FOR_AR.FUND_SRC_NUM is '款项来源号'
/

comment on column V_SO_HEADER_FOR_AR.CANCLED_BY is '取消人ID'
/

comment on column V_SO_HEADER_FOR_AR.CANCLED_DATE is '取消日期'
/

comment on column V_SO_HEADER_FOR_AR.CLOSED_BY is '关闭人ID'
/

comment on column V_SO_HEADER_FOR_AR.CLOSED_DATE is '关闭日期'
/

comment on column V_SO_HEADER_FOR_AR.REVERSALED_BY is '红冲人ID'
/

comment on column V_SO_HEADER_FOR_AR.REVERSALED_DATE is '红冲日期'
/

comment on column V_SO_HEADER_FOR_AR.ERP_OU_ID is 'ERP的OU ID：取库存组织表的经营单位ID。'
/

comment on column V_SO_HEADER_FOR_AR.ERP_SUBINV_ID is '对应ERP子库组织ID：取发货仓库/收货仓库对应的库存组织ID'
/

comment on column V_SO_HEADER_FOR_AR.ERP_SO_ID is 'ERP SO订单ID：销售订单、销售折让订单、折让证明订单统称为SO订单'
/

comment on column V_SO_HEADER_FOR_AR.ERP_SO_CODE is 'ERP SO订单号'
/

comment on column V_SO_HEADER_FOR_AR.ERP_PICK_FLAG is 'ERP挑库标记'
/

comment on column V_SO_HEADER_FOR_AR.ERP_SHIP_FLAG is 'ERP发运标记'
/

comment on column V_SO_HEADER_FOR_AR.ERP_SHIP_CODE is 'ERP发运号'
/

comment on column V_SO_HEADER_FOR_AR.ERP_ARINVOICE_CODE is 'ERP应收(AR)发票号'
/

comment on column V_SO_HEADER_FOR_AR.ERP_RECEIVED_FLAG is 'ERP接收入库标记'
/

comment on column V_SO_HEADER_FOR_AR.ERP_CREDIT_MEMO_CODE is 'ERP贷项通知号'
/

comment on column V_SO_HEADER_FOR_AR.ERP_RMA_ID is 'ERP退货单ID'
/

comment on column V_SO_HEADER_FOR_AR.ERP_RMA_NUM is 'ERP退货单号'
/

comment on column V_SO_HEADER_FOR_AR.FACTORY_PO_ID is '工厂PO订单ID'
/

comment on column V_SO_HEADER_FOR_AR.FACTORY_PO_NUM is '工厂PO订单号'
/

comment on column V_SO_HEADER_FOR_AR.RELATED_TRANS_ID is '关联交易订单ID'
/

comment on column V_SO_HEADER_FOR_AR.RELATED_TRANS_NUM is '关联交易订单号'
/

comment on column V_SO_HEADER_FOR_AR.REBATE_YEAR is '返利年度'
/

comment on column V_SO_HEADER_FOR_AR.PAYMENT_SRC is '支付来源'
/

comment on column V_SO_HEADER_FOR_AR.DISCOUNT_ITEM is '折让项目'
/

comment on column V_SO_HEADER_FOR_AR.DISCOUNT_MODE is '折让方式'
/

comment on column V_SO_HEADER_FOR_AR.MACHINE_MODEL is '涉及机型'
/

comment on column V_SO_HEADER_FOR_AR.DISCOUNT_PROVE_FLAG is '是否开折让证明'
/

comment on column V_SO_HEADER_FOR_AR.RECEIVED_DISCOUNT_PROVE_FLAG is '是否收到折让证明'
/

comment on column V_SO_HEADER_FOR_AR.SALES_PRICE_ID is '销售价目'
/

comment on column V_SO_HEADER_FOR_AR.SALES_REGION is '销售区域'
/

comment on column V_SO_HEADER_FOR_AR.PAYMENT_TERMS is '付款条件'
/

comment on column V_SO_HEADER_FOR_AR.INVOICE_APPLY_ID is '开票申请单ID'
/

comment on column V_SO_HEADER_FOR_AR.INVOICE_NUM_LIST is '发票号串：多个发票号用逗号分隔（,）。'
/

comment on column V_SO_HEADER_FOR_AR.INVOICE_DATE is '发票日期：一张销售单只有一个发票开票日期。'
/

comment on column V_SO_HEADER_FOR_AR.INVOICE_TYPE is '发票类型'
/

comment on column V_SO_HEADER_FOR_AR.CREATED_BY is '创建人ID'
/

comment on column V_SO_HEADER_FOR_AR.CREATION_DATE is '创建日期'
/

comment on column V_SO_HEADER_FOR_AR.LAST_UPDATED_BY is '最后更新人'
/

comment on column V_SO_HEADER_FOR_AR.LAST_UPDATE_DATE is '最后更新日期'
/

comment on column V_SO_HEADER_FOR_AR.RETURN_TYPE is '退货类型：完好、破损、残次'
/

comment on column V_SO_HEADER_FOR_AR.RETURN_MODE is '退货方式：1-推式，2-拉式源单退回，3-拉式反向销售'
/

comment on column V_SO_HEADER_FOR_AR.CREATED_MODE is '制单方式：10-自动，20-人工，30-自动的一种特殊情况'
/

comment on column V_SO_HEADER_FOR_AR.INVOICE_CORPORATION is '开票单位：手工制单时人工录入，自动制单时默认为客户名称。'
/

comment on column V_SO_HEADER_FOR_AR.ERP_OU_NAME is 'ERP的OU名称：取库存组织表的经营单位名称字段。'
/

comment on column V_SO_HEADER_FOR_AR.CASH_TURNFEE_ID is '转款ID：财务的转款ID，由财务管理模块回写。'
/

comment on column V_SO_HEADER_FOR_AR.ERP_SUBINV_CODE is '对应ERP子库组织编码：子库是指仓库，取发货仓库/收货仓库对应的库存组织编码'
/

comment on column V_SO_HEADER_FOR_AR.ERP_ARINVOICE_ID is 'ERP(AR)发票头ID'
/

comment on column V_SO_HEADER_FOR_AR.SRC_TYPE is '来源类型标识（直接来源）：01计划订单 02提货订单 03调拨订单 04促销品 09采购单据 10调拨单据 11备货单据 12财务单据 13退货申请 14F单 15电商 SL_BILL库位单'
/

comment on column V_SO_HEADER_FOR_AR.SRC_BILL_TYPE_CODE is '来源单据类型编码(直接来源)'
/

comment on column V_SO_HEADER_FOR_AR.SRC_BILL_TYPE_NAME is '来源单据类型名称(直接来源)'
/

comment on column V_SO_HEADER_FOR_AR.MONTH_DISCOUNT_AMOUNT is '月返总金额：行产品月返金额汇总'
/

comment on column V_SO_HEADER_FOR_AR.PROJECT_AMOUNT is '批文总金额：行产品批文金额汇总'
/

comment on column V_SO_HEADER_FOR_AR.LAST_PRINTED_BY is '最后打印人'
/

comment on column V_SO_HEADER_FOR_AR.LAST_PRINTED_DATE is '最后打印时间'
/

comment on column V_SO_HEADER_FOR_AR.RAW_SRC_TYPE is '最原始的来源类型标识：用于记录单据最开始的来源，主要用于解决F红冲单触发生成折让红冲单等情况，01计划订单 02提货订单 03调拨订单 04促销品 09采购单据 10调拨单据 11备货单据 12财务单据 13退货申请 14F单 15电商'
/

comment on column V_SO_HEADER_FOR_AR.RAW_SRC_BILL_TYPE_ID is '最原始的来源单据类型ID'
/

comment on column V_SO_HEADER_FOR_AR.RAW_SRC_BILL_TYPE_CODE is '最原始的来源单据类型编码'
/

comment on column V_SO_HEADER_FOR_AR.RAW_SRC_BILL_ID is '最原始的来源单据ID'
/

comment on column V_SO_HEADER_FOR_AR.RAW_SRC_BILL_NUM is '最原始的来源单据编码'
/

comment on column V_SO_HEADER_FOR_AR.ENTITY_CUST_FLAG is '是否事业部客户'
/

comment on column V_SO_HEADER_FOR_AR.CUSTOMER_REGISTRATION_CODE is '客户税票号'
/

comment on column V_SO_HEADER_FOR_AR.SYS_SOURCE_ORDER_NUM is '外部系统单据号'
/

