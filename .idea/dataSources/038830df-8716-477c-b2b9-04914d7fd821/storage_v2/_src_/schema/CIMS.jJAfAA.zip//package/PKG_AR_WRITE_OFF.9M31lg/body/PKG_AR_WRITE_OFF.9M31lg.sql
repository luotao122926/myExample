create PACKAGE BODY      PKG_AR_WRITE_OFF AS

  -- 核销(按照流程执行核销)
  PROCEDURE P_AR_WRITE_OFFS
  (
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  ) IS
  
  P_LOG_RESULT VARCHAR2(400);
  BEGIN
    -- 修复为空的核销状态
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AUTO_REPAIR_MATCH_STATUS', '-1','记录时间');
    --PKG_AR_WRITE_OFF.P_AUTO_REPAIR_MATCH_STATUS(P_RESULT, P_MESSAGE);
    
    -- 退款申请进行撤回修改、撤回作废、GTMS已驳回
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_CASH_STATUS', '-1','记录时间');
   -- PKG_AR_WRITE_OFF.P_AR_CASH_STATUS(P_RESULT, P_MESSAGE);
    
    -- 结算更改（修改折扣率）
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_SETTLED_WRITE_OFF', '-1','记录时间');
   -- PKG_AR_WRITE_OFF.P_AR_SETTLED_WRITE_OFF(P_RESULT, P_MESSAGE);
    
    -- 收款冲销后，收款冲销单跟原收款单进行核销
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_RECEIPT_INVOICE_WRITE_OFF', '-1','记录时间');
  --  PKG_AR_WRITE_OFF.P_AR_RECEIPT_INVOICE_WRITE_OFF(P_RESULT, P_MESSAGE);
   
   -- 核销金额大于单据金额数据自动修复(默认开启自动修复)
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AUTO_REPAIR_ORDER_RECEIPT', '-1','记录时间');
  --  PKG_AR_WRITE_OFF.P_AUTO_REPAIR_ORDER_RECEIPT(PKG_AR_WRITE_OFF.V_YES, P_RESULT, P_MESSAGE);
   
    -- 客户自动核销处理
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFFS_TRAN', '-1','记录时间');
  --  PKG_AR_WRITE_OFF.P_AR_WRITE_OFFS_TRAN(P_RESULT, P_MESSAGE);
    
    -- 优先核销处理
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_PRIOR_WRITE_OFFS', '-1','记录时间');
  --  PKG_AR_WRITE_OFF.P_AR_PRIOR_WRITE_OFFS(P_RESULT, P_MESSAGE);
    
    -- 核销主过程
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFFS_MAIN', '-1','记录时间');
   -- PKG_AR_WRITE_OFF.P_AR_WRITE_OFFS_MAIN(P_RESULT, P_MESSAGE);
    
    -- 跨主体转款。生成制单状态的跨主体转款
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_CASH_TURNFEE_NEW', '-1','记录时间');
  --  PKG_AR_WRITE_OFF.P_AR_CASH_TURNFEE_NEW(P_RESULT, P_MESSAGE);
    
    -- 跨主体转款。确认制单状态的跨主体转款。引关联交易、生成正负收款，引ERP收款和AR发票
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_CASH_TURNFEE_COMMIT', '-1','记录时间');
  --  PKG_AR_WRITE_OFF.P_AR_CASH_TURNFEE_COMMIT(P_RESULT, P_MESSAGE);
    
    -- 核销关系推送ERP
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_ORDER_RECEIPT_TO_ERP', '-1','记录时间');
   -- PKG_AR_WRITE_OFF.P_SO_ORDER_RECEIPT_TO_ERP(P_RESULT, P_MESSAGE);
    
    -- 同一张收款和发票只能核销一次。核销汇总后推送ERP
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_ORDER_RECEIPT_ERP_CHECK', '-1','记录时间');
  --  PKG_AR_WRITE_OFF.P_SO_ORDER_RECEIPT_ERP_CHECK(P_RESULT, P_MESSAGE);
    
    -- 核销关系取消
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_ORDER_RECEIPT_ERP_CANCEL', '-1','记录时间');
  --  PKG_AR_WRITE_OFF.P_SO_ORDER_RECEIPT_ERP_CANCEL(P_RESULT, P_MESSAGE);
    
    -- 坏账
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_BAD_BILL_PROVISION_REPROT', '-1','记录时间');
   -- PKG_AR_WRITE_OFF.P_SO_BAD_BILL_PROVISION_REPROT(SYSDATE - 1, P_RESULT, P_MESSAGE);
  --  PKG_AR_WRITE_OFF.P_SO_BAD_BILL_PROVISION_PREC_R(SYSDATE - 1, P_RESULT, P_MESSAGE);
    
    -- 刷新物化视图
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_REFRESH_MATERIALIZED_VIEW', '-1','记录时间');
   -- PKG_AR_WRITE_OFF.P_REFRESH_MATERIALIZED_VIEW(PKG_AR_WRITE_OFF.MV_AR_WRITE_OFF_CHECK_REP_NEW, P_RESULT, P_MESSAGE);
    
    -- 核销校验(默认不开启校验)
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFF_CHECK', '-1','记录时间');
   -- PKG_AR_WRITE_OFF.P_AR_WRITE_OFF_CHECK(PKG_AR_WRITE_OFF.V_NO, P_RESULT, P_MESSAGE);
    
    -- 重置核销状态
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_RESET_WRITE_OFF_STATUS', '-1','记录时间');
   -- PKG_AR_WRITE_OFF.P_RESET_WRITE_OFF_STATUS(P_RESULT, P_MESSAGE);
    
    --冻结账龄日报表
  --  P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_AGE_FREEZE', '-1','记录时间');
  --  PKG_AR_WRITE_OFF.P_AR_AGE_FREEZE(to_char((SYSDATE-1),'yyyy-mm-dd'),P_RESULT, P_MESSAGE);
    
    --重置接口状态
  --  P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITEOFF_RESET_START', '-1','记录时间');
  --  P_AR_WRITEOFF_RESET(P_RESULT, P_MESSAGE);
    
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITEOFF_RESET_END', '-1','记录时间');
    
    COMMIT;
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFFS', SQLCODE,
            '账龄核销失败！。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    RETURN ;
  END;

  --客户自动核销处理
  PROCEDURE P_AR_WRITE_OFFS_TRAN
  (
    IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  ) IS
   V_MATCHED_COUNT            NUMBER;
   V_PARAM_ENTITY_ID NUMBER;
   V_AUTO_WRITE_OFF VARCHAR2(100); 
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    V_PARAM_ENTITY_ID := IN_ENTITY_ID;
    -- 插入核销事物表（事物日期设置为前一条的日期）
    FOR ROW_CUST_ACCOUNT IN (SELECT DISTINCT T.ENTITY_ID, T.CUSTOMER_ID, T.CUSTOMER_CODE, T.CUSTOMER_NAME, T.ACCOUNT_ID, TRUNC(SYSDATE - 1, 'DD') AS TRAN_DATE
                            FROM (
                                  SELECT H.ENTITY_ID, H.CUSTOMER_ID, H.CUSTOMER_CODE, H.CUSTOMER_NAME, H.ACCOUNT_ID FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H WHERE H.ENTITY_ID = V_PARAM_ENTITY_ID
                                  UNION
                                  SELECT H.ENTITY_ID, H.CUSTOMER_ID, H.CUSTOMER_CODE, H.CUSTOMER_NAME, H.ACCOUNT_ID FROM CIMS.T_SO_HEADER H WHERE H.ENTITY_ID = V_PARAM_ENTITY_ID
                            ) T
                             --WHERE EXISTS(
                            --   SELECT CA.ACCOUNT_ID FROM T_CUSTOMER_ACCOUNT CA WHERE CA.ACCOUNT_ID=T.ACCOUNT_ID AND CA.IS_AUTO_WRITF_OFF='Y'
                          --   )
--                            WHERE EXISTS (SELECT * FROM CIMS.V_AR_WRITE_OFF_CUST_ACCOUNT CA
--                                         WHERE CA.ACCOUNT_ID = T.ACCOUNT_ID AND CA.CUSTOMER_ID = T.CUSTOMER_ID AND CA.ENTITY_ID = T.ENTITY_ID
--                                               AND CA.ACCOUNT_STATUS = '1' AND CA.ACTIVE_FLAG = 'Active')
                            ORDER BY T.ENTITY_ID, T.CUSTOMER_ID, T.ACCOUNT_ID) LOOP
      BEGIN
        UPDATE CIMS.T_AR_AUTO_WRITE_OFFS_TRAN T SET T.WRITE_OFFS_FLAG = PKG_AR_WRITE_OFF.V_YES
        WHERE T.CUSTOMER_ID = ROW_CUST_ACCOUNT.CUSTOMER_ID
            AND T.ACCOUNT_ID = ROW_CUST_ACCOUNT.ACCOUNT_ID
            AND T.ENTITY_ID = ROW_CUST_ACCOUNT.ENTITY_ID
            AND T.TRAN_DATE < ROW_CUST_ACCOUNT.TRAN_DATE
            AND T.WRITE_OFFS_FLAG = PKG_AR_WRITE_OFF.V_NO;
        SELECT COUNT(*) INTO V_MATCHED_COUNT FROM CIMS.T_AR_AUTO_WRITE_OFFS_TRAN T
        WHERE T.CUSTOMER_ID = ROW_CUST_ACCOUNT.CUSTOMER_ID
              AND T.ACCOUNT_ID = ROW_CUST_ACCOUNT.ACCOUNT_ID
              AND T.ENTITY_ID = ROW_CUST_ACCOUNT.ENTITY_ID
              AND T.TRAN_DATE = ROW_CUST_ACCOUNT.TRAN_DATE;
        BEGIN
          SELECT CA.IS_AUTO_WRITF_OFF INTO V_AUTO_WRITE_OFF FROM cims.T_CUSTOMER_ACCOUNT CA WHERE CA.ACCOUNT_ID=ROW_CUST_ACCOUNT.ACCOUNT_ID ;      
        EXCEPTION
           WHEN NO_DATA_FOUND THEN
                V_AUTO_WRITE_OFF := 'Y';
        END;    
        IF V_MATCHED_COUNT <= 0 THEN
          INSERT INTO T_AR_AUTO_WRITE_OFFS_TRAN(
               WRITE_OFFS_TRAN_ID, ENTITY_ID, CUSTOMER_ID, CUSTOMER_CODE, CUSTOMER_NAME/**, SALES_CENTER_ID**/, ACCOUNT_ID, WRITE_OFFS_FLAG, TRAN_DATE,IS_AUTO_WRITF_OFF)
          VALUES(S_AR_AUTO_WRITE_OFFS_TRAN.NEXTVAL, ROW_CUST_ACCOUNT.ENTITY_ID, ROW_CUST_ACCOUNT.CUSTOMER_ID, ROW_CUST_ACCOUNT.CUSTOMER_CODE, ROW_CUST_ACCOUNT.CUSTOMER_NAME,
               /**ROW_CUST_ACCOUNT.SALES_CENTER_ID, **/ROW_CUST_ACCOUNT.ACCOUNT_ID, PKG_AR_WRITE_OFF.V_NO, ROW_CUST_ACCOUNT.TRAN_DATE,V_AUTO_WRITE_OFF);
        ELSE
          UPDATE CIMS.T_AR_AUTO_WRITE_OFFS_TRAN T SET T.WRITE_OFFS_FLAG = PKG_AR_WRITE_OFF.V_NO
          WHERE T.CUSTOMER_ID = ROW_CUST_ACCOUNT.CUSTOMER_ID
              AND T.ACCOUNT_ID = ROW_CUST_ACCOUNT.ACCOUNT_ID
              AND T.ENTITY_ID = ROW_CUST_ACCOUNT.ENTITY_ID
              AND T.IS_AUTO_WRITF_OFF = V_AUTO_WRITE_OFF
              AND T.TRAN_DATE = ROW_CUST_ACCOUNT.TRAN_DATE;
        END IF;
        COMMIT;
      EXCEPTION WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
        P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFFS_TRAN', SQLCODE,
                '客户自动核销处理出错！主体：'||ROW_CUST_ACCOUNT.ENTITY_ID||
                '、客户：'||ROW_CUST_ACCOUNT.CUSTOMER_CODE||'、账户'||ROW_CUST_ACCOUNT.ACCOUNT_ID||
                '。错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
      END;
    END LOOP;
    P_RESULT := '客户自动核销处理过程执行成功！';
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFFS_TRAN', SQLCODE,
            '客户自动核销处理出错！错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    RETURN ;
  END;

  -- 销售单(1001)、退货单(1003)、销售折让单(1005)、折让证明单(1007) 如果当天存在红冲单，需优先核销
  PROCEDURE P_AR_PRIOR_WRITE_OFFS
  (
    IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  ) IS
  -- 主体ID
  V_ENTITY_ID                T_AR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID%TYPE ;
  -- 客户ID
  V_CUSTOMER_ID              T_AR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID%TYPE ;
  -- 账户ID
  V_ACCOUNT_ID               T_AR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID%TYPE ;
  V_AR_CONF_INITIAL          T_AR_AUTO_WRITE_OFFS_TRAN.AR_CONF_INITIAL%TYPE;
  -- 查询红单sql
  V_SO_RED_SQL               VARCHAR2(3000);
  V_RED_DATE                 DATE;
  -- 单据号
  V_PRIOR_SO_NUM             T_SO_HEADER.SO_NUM%TYPE;
  -- 核销金额
  V_MATCH_AMOUNT_TOTAL       NUMBER := 0;
  -- 应参与核销日期
  V_SHOULD_WRITE_OFF_DATE      DATE;

  TYPE REF_CURSOR_TYPE       IS REF CURSOR;                          --定义一个动态游标类型
  V_DYNAMIC_CURSOR           REF_CURSOR_TYPE;                        -- 动态游标
  ROW_RED_SO_HEADER          T_SO_HEADER%ROWTYPE;
  ROW_SO_ORDER_RECEIPT       T_SO_ORDER_RECEIPT%ROWTYPE;
  --  销售单(1001)、退货单(1003)、销售折让单(1005)、折让证明单(1007) 如果当天存在红冲单，需优先核销
  CURSOR CUR_PRIOR_SO_HEADER IS
    SELECT DISTINCT S.ENTITY_ID, S.CUSTOMER_ID, S.CUSTOMER_CODE, S.CUSTOMER_NAME, S.ACCOUNT_ID, S.SALES_CENTER_ID, S.SO_HEADER_ID, S.SO_NUM,
           S.BIZ_SRC_BILL_TYPE_CODE, S.SETTLE_AMOUNT, S.SO_STATUS, S.APPLIED_PLUS_MINUS_FLAG,
           S.SO_DATE, S.SHIP_FLAG, S.SHIP_DATE, S.SETTLE_FLAG, S.SETTLE_DATE, S.RECEIVE_FLAG, S.RECEIVE_DATE, S.CHECKED_ACCOUNT_FLAG, S.CHECKED_ACCOUNT_DATE,
           S.APPLIED_FLAG, S.APPLIED_DATE, S.ERP_OU_ID, S.SHOULD_WRITE_OFF_DATE, S.AR_CONF_WRITE_OFF_DATE
    FROM CIMS.V_AR_SO_WRITE_OFF_INITIAL_CONF S
    WHERE S.SHOULD_WRITE_OFF_DATE < SHOULD_WRITE_OFF_DATE
          AND S.SETTLE_AMOUNT <> 0
          -- 取销售单(1001)、退货单(1003)、销售折让单(1005)、折让证明单(1007)
          AND S.BIZ_SRC_BILL_TYPE_CODE IN (PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO,
                                          PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_RETURN,
                                          PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT,
                                          PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_DISCOUNT)
          -- 取未核销的单据
          AND S.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE
--          AND PKG_AR_WRITE_OFF.F_AR_HAS_ORDER_RECIPET(S.SO_HEADER_ID, S.BIZ_SRC_BILL_TYPE_CODE) = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE
          -- 取全部红冲或部分红冲的单据
          AND S.REVERSAL_FLAG IN (PKG_AR_WRITE_OFF.V_REVERSAL_FLAG_ALL, PKG_AR_WRITE_OFF.V_REVERSAL_FLAG_PART)
          AND S.ACCOUNT_ID = V_ACCOUNT_ID
          AND S.CUSTOMER_ID = V_CUSTOMER_ID
          AND S.ENTITY_ID = V_ENTITY_ID;
  --销售单(1001)、退货单(1003)、销售折让单(1005)、折让证明单(1007) 如果当天存在红冲单游标行数据
  ROW_PRIOR_SO_HEADER CUR_PRIOR_SO_HEADER%ROWTYPE;
     V_PARAM_ENTITY_ID NUMBER;
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    V_PARAM_ENTITY_ID := IN_ENTITY_ID; 
    -- 循环核销事物
    FOR CUR_AUTO_WRITE_OFFS_TRAN IN (SELECT T.* FROM T_AR_AUTO_WRITE_OFFS_TRAN T
                                 WHERE  T.WRITE_OFFS_FLAG = PKG_AR_WRITE_OFF.V_NO AND T.ENTITY_ID = V_PARAM_ENTITY_ID  ORDER BY T.TRAN_DATE, T.ENTITY_ID, T.CUSTOMER_CODE)
    LOOP
      BEGIN
        -- 赋值主体、客户、账户值给变量
        V_ENTITY_ID := CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID;
        V_CUSTOMER_ID := CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID;
        V_ACCOUNT_ID := CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID;
        V_SHOULD_WRITE_OFF_DATE := CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE + 1;
        -- 循环需优先核销的蓝单结果集
        FOR ROW_PRIOR_SO_HEADER IN CUR_PRIOR_SO_HEADER
        LOOP
          BEGIN
            V_PRIOR_SO_NUM := ROW_PRIOR_SO_HEADER.SO_NUM;
            -- 查找蓝单对应的红单信息
            -- 发货日期、发货标识、收货日期、收货标识从蓝单复制过来的。对账字段不是，跟蓝单没关系。
            V_SO_RED_SQL := 'SELECT H.* FROM T_SO_HEADER H WHERE H.ORIG_SO_NUM = :V1';
            V_SO_RED_SQL := V_SO_RED_SQL||' AND H.APPLIED_FLAG = '''||PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE||'''';
--            V_SO_RED_SQL := V_SO_RED_SQL||' AND PKG_AR_WRITE_OFF.F_AR_HAS_ORDER_RECIPET(SO_HEADER_ID, BIZ_SRC_BILL_TYPE_CODE) = '''||PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE||'''';
            -- 销售单(1001)
            IF ROW_PRIOR_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO THEN
              -- 取得销售单应收配置时点
              V_AR_CONF_INITIAL := ROW_PRIOR_SO_HEADER.AR_CONF_WRITE_OFF_DATE;
              IF V_AR_CONF_INITIAL = PKG_AR_WRITE_OFF.V_AR_CONF_INITIAL_SHIP THEN --发货确认
                V_SO_RED_SQL := V_SO_RED_SQL||' AND SHIP_FLAG = '''||PKG_AR_WRITE_OFF.V_YES||''' AND TRUNC(SHIP_DATE) = :V2 AND SETTLE_AMOUNT <> 0';
                V_RED_DATE := TRUNC(ROW_PRIOR_SO_HEADER.SHIP_DATE);
              ELSIF V_AR_CONF_INITIAL = PKG_AR_WRITE_OFF.V_AR_CONF_INITIAL_RECEIVE THEN -- 收货确认
                V_SO_RED_SQL := V_SO_RED_SQL||' AND RECEIVE_FLAG = '''||PKG_AR_WRITE_OFF.V_YES||''' AND TRUNC(RECEIVE_DATE) = :V2 AND SETTLE_AMOUNT <> 0';
                V_RED_DATE := TRUNC(ROW_PRIOR_SO_HEADER.RECEIVE_DATE);
              ELSIF V_AR_CONF_INITIAL = PKG_AR_WRITE_OFF.V_AR_CONF_INITIAL_CHECKED THEN -- 客户对账
                V_SO_RED_SQL := V_SO_RED_SQL||' AND CHECKED_ACCOUNT_FLAG = '''||PKG_AR_WRITE_OFF.V_YES||''' AND TRUNC(CHECKED_ACCOUNT_DATE) = :V2 AND SETTLE_AMOUNT <> 0';
                V_RED_DATE := TRUNC(ROW_PRIOR_SO_HEADER.CHECKED_ACCOUNT_DATE);
              END IF;
            ELSIF ROW_PRIOR_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE IN (PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_RETURN, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_DISCOUNT) THEN --退货单(1003)、折让证明单(1007)
              V_SO_RED_SQL := V_SO_RED_SQL||' AND SETTLE_FLAG = '''||PKG_AR_WRITE_OFF.V_YES||''' AND TRUNC(SETTLE_DATE) = :V2 AND SETTLE_AMOUNT <> 0';
              V_RED_DATE := TRUNC(ROW_PRIOR_SO_HEADER.SETTLE_DATE);
            ELSIF ROW_PRIOR_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE = PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT THEN --销售折让单(1005)
              V_SO_RED_SQL := V_SO_RED_SQL||' AND TRUNC(SO_DATE) = :V2 AND SETTLE_AMOUNT <> 0';
              V_RED_DATE := TRUNC(ROW_PRIOR_SO_HEADER.SO_DATE);
            END IF;
            -- 蓝单累计核销金额
            V_MATCH_AMOUNT_TOTAL := 0;
            OPEN V_DYNAMIC_CURSOR FOR V_SO_RED_SQL USING ROW_PRIOR_SO_HEADER.SO_NUM, V_RED_DATE;
            LOOP
                FETCH V_DYNAMIC_CURSOR INTO ROW_RED_SO_HEADER;
                EXIT WHEN V_DYNAMIC_CURSOR%NOTFOUND;
                -- 红冲单完全核销,蓝单部分核销
                IF ABS(ROUND(ROW_PRIOR_SO_HEADER.SETTLE_AMOUNT, 2)) > ABS(ROUND(ROW_RED_SO_HEADER.SETTLE_AMOUNT, 2)) THEN
                  -- 红冲单完全核销
                  UPDATE CIMS.T_SO_HEADER H SET H.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL,
                         H.APPLIED_DATE = SYSDATE
                  WHERE H.SO_NUM = ROW_RED_SO_HEADER.SO_NUM;
                  -- 蓝单部分核销
                  UPDATE CIMS.T_SO_HEADER H SET H.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART,
                         H.APPLIED_DATE = SYSDATE
                  WHERE H.SO_NUM = ROW_PRIOR_SO_HEADER.SO_NUM;
                ELSIF ABS(ROUND(ROW_PRIOR_SO_HEADER.SETTLE_AMOUNT, 2)) = ABS(ROUND(ROW_RED_SO_HEADER.SETTLE_AMOUNT, 2)) THEN -- 红冲单完全核销,蓝单完全核销
                  -- 红冲单完全核销,蓝单完全核销
                  UPDATE CIMS.T_SO_HEADER H SET H.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL,
                         H.APPLIED_DATE = SYSDATE
                  WHERE H.SO_NUM IN (ROW_RED_SO_HEADER.SO_NUM, ROW_PRIOR_SO_HEADER.SO_NUM);
                ELSE
                  ROLLBACK;
                  P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                  P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_PRIOR_WRITE_OFFS',
                        SQLCODE,
                        '【数据异常】蓝单金额不能大于红冲单金额，请检查！蓝单SO_NUM：'||ROW_PRIOR_SO_HEADER.SO_NUM||
                        '(金额：'||ABS(ROUND(ROW_PRIOR_SO_HEADER.SETTLE_AMOUNT, 2))||')。红冲单SO_NUM：'||ROW_RED_SO_HEADER.SO_NUM||
                        '(金额：'||ABS(ROUND(ROW_RED_SO_HEADER.SETTLE_AMOUNT, 2))||')。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                  CONTINUE; -- 跳出循环
                END IF;
                ROW_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID := S_SO_ORDER_RECEIPT.NEXTVAL;
                ROW_SO_ORDER_RECEIPT.ENTITY_ID := ROW_RED_SO_HEADER.ENTITY_ID;
                ROW_SO_ORDER_RECEIPT.CUSROMER_CODE := ROW_RED_SO_HEADER.CUSTOMER_CODE;
                ROW_SO_ORDER_RECEIPT.CUSROMER_NAME := ROW_RED_SO_HEADER.CUSTOMER_NAME;
                ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_CODE := ROW_RED_SO_HEADER.SALES_MAIN_TYPE;
                ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_NAME := ROW_RED_SO_HEADER.SALES_MAIN_TYPE_NAME;
                ROW_SO_ORDER_RECEIPT.AMOUNT := ABS(ROUND(ROW_RED_SO_HEADER.SETTLE_AMOUNT, 2));
                ROW_SO_ORDER_RECEIPT.MATCH_DATE := CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE; -- 核销日期取事物日期
                ROW_SO_ORDER_RECEIPT.TO_ERP_FLAG := PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N;
                ROW_SO_ORDER_RECEIPT.REMARK := '当天财务单优先核销';
                IF ROW_PRIOR_SO_HEADER.APPLIED_PLUS_MINUS_FLAG = 1 THEN -- 蓝单为应收,红单为回款
                	ROW_SO_ORDER_RECEIPT.SO_HEAD_ID := ROW_PRIOR_SO_HEADER.SO_HEADER_ID;
                  ROW_SO_ORDER_RECEIPT.ORDER_TYPE := ROW_PRIOR_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE;
                  ROW_SO_ORDER_RECEIPT.ORDER_DATE := ROW_PRIOR_SO_HEADER.SO_DATE;
                  ROW_SO_ORDER_RECEIPT.ORDER_NUMBER := ROW_PRIOR_SO_HEADER.SO_NUM;
                  ROW_SO_ORDER_RECEIPT.ORDER_ERP_OU_ID := ROW_PRIOR_SO_HEADER.ERP_OU_ID;

                  ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_ID := ROW_RED_SO_HEADER.SO_HEADER_ID;
                  ROW_SO_ORDER_RECEIPT.RECEIPT_TYPE := ROW_RED_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE;
                  ROW_SO_ORDER_RECEIPT.RECEIPT_DATE := ROW_RED_SO_HEADER.SO_DATE;
                  ROW_SO_ORDER_RECEIPT.RECEIPT_NUMBER := ROW_RED_SO_HEADER.SO_NUM;
                  ROW_SO_ORDER_RECEIPT.RECEIPT_ERP_OU_ID := ROW_RED_SO_HEADER.ERP_OU_ID;
                ELSE -- 蓝单为回款，红单为应收
                	ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_ID := ROW_PRIOR_SO_HEADER.SO_HEADER_ID;
                  ROW_SO_ORDER_RECEIPT.RECEIPT_TYPE := ROW_PRIOR_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE;
                  ROW_SO_ORDER_RECEIPT.RECEIPT_DATE := ROW_PRIOR_SO_HEADER.SO_DATE;
                  ROW_SO_ORDER_RECEIPT.RECEIPT_NUMBER := ROW_PRIOR_SO_HEADER.SO_NUM;
                  ROW_SO_ORDER_RECEIPT.RECEIPT_ERP_OU_ID := ROW_PRIOR_SO_HEADER.ERP_OU_ID;

                  ROW_SO_ORDER_RECEIPT.SO_HEAD_ID := ROW_RED_SO_HEADER.SO_HEADER_ID;
                  ROW_SO_ORDER_RECEIPT.ORDER_TYPE := ROW_RED_SO_HEADER.BIZ_SRC_BILL_TYPE_CODE;
                  ROW_SO_ORDER_RECEIPT.ORDER_DATE := ROW_RED_SO_HEADER.SO_DATE;
                  ROW_SO_ORDER_RECEIPT.ORDER_NUMBER := ROW_RED_SO_HEADER.SO_NUM;
                  ROW_SO_ORDER_RECEIPT.ORDER_ERP_OU_ID := ROW_RED_SO_HEADER.ERP_OU_ID;
                END IF;
                ROW_SO_ORDER_RECEIPT.LAST_UPDATE_DATE := SYSDATE;
                -- 插入核销关系
                INSERT INTO T_SO_ORDER_RECEIPT VALUES ROW_SO_ORDER_RECEIPT;
                V_MATCH_AMOUNT_TOTAL := V_MATCH_AMOUNT_TOTAL + ROW_RED_SO_HEADER.SETTLE_AMOUNT;
            END LOOP;
            CLOSE V_DYNAMIC_CURSOR;
            -- 蓝单被完全红冲核销完
            IF ABS(ROUND(V_MATCH_AMOUNT_TOTAL, 2)) = ABS(ROUND(ROW_PRIOR_SO_HEADER.SETTLE_AMOUNT, 2)) THEN
            	UPDATE CIMS.T_SO_HEADER H SET H.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL,
                     H.APPLIED_DATE = SYSDATE
              WHERE H.SO_NUM = ROW_PRIOR_SO_HEADER.SO_NUM;
            END IF;
            COMMIT;
          EXCEPTION WHEN OTHERS THEN
            ROLLBACK;
            P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
            P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_PRIOR_WRITE_OFFS', SQLCODE,
                      '优先核销单据出错！错误日志：单据号：'||V_PRIOR_SO_NUM||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
          END;
        END LOOP;
      EXCEPTION WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
        P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_PRIOR_WRITE_OFFS', SQLCODE,
            '优先核销核销事物出错！错误日志：主体：'||CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID||
            '，客户'||CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID||
            '，账户：'||CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID||
            '，事物处理日期：'||TO_CHAR(CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE, 'yyyy-MM-dd')||
            '。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
      END;
    END LOOP;
    P_RESULT := '优先核销过程执行成功！';
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_PRIOR_WRITE_OFFS', SQLCODE,
            '优先核销出错！错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    RETURN ;
  END;
  
  
  
      -- 大额到款单提前核销
  PROCEDURE P_AR_AMOUNT_WRITE_OFFS
  (
    IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  ) IS
    V_APPLIED_RH_AMOUNT NUMBER;
    V_APPLIED_SH_AMOUNT NUMBER;
    V_WAIT_RH_AMOUNT NUMBER;
    V_WAIT_SH_AMOUNT NUMBER;
    V_REMAK VARCHAR2(1000);
    V_ERP_FLAG  VARCHAR2(2);
    V_WIRTE_MOUNT NUMBER;
    V_WIRTE_DATE DATE;
    V_PARAM_MAX_AMOUNT  NUMBER;
  BEGIN
      P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;  
      V_WIRTE_DATE := TRUNC(SYSDATE);
      V_PARAM_MAX_AMOUNT := PKG_BD.F_GET_PARAMETER_VALUE('AR_PARAM_MAX_AMOUNT', IN_ENTITY_ID, NULL, NULL);  
      FOR 
          V_RECEIPT_HEADERS_ROW 
       IN(  SELECT 
               * 
              FROM
                CIMS.T_AR_CASH_RECEIPT_HEADERS CH 
              WHERE CH.AMOUNT >= V_PARAM_MAX_AMOUNT 
              AND CH.CASH_RECEIPT_DATE>= SYSDATE-30
              AND CH.RECEIPT_STATUS_ID IN(3, 5, 6)   --已确认状态 已审核  已汇
              AND CH.ATTRIBUTE5 IN('2','1')          --未核销完成
              AND CH.CASH_RECEIPT_DATE <V_WIRTE_DATE
              AND CH.Entity_Id = IN_ENTITY_ID
         )LOOP
            BEGIN  
                     BEGIN 
                        SELECT  
                            SUM(R.AMOUNT) AMOUNT 
                        INTO 
                              V_APPLIED_RH_AMOUNT
                        FROM CIMS.T_SO_ORDER_RECEIPT R
                        WHERE ((R.TO_ERP_FLAG = 'C' AND R.CASH_TURNFEE_ID IS NULL) OR R.TO_ERP_FLAG IN ('Y', 'N'))
                        AND R.RECEIPT_NUMBER = V_RECEIPT_HEADERS_ROW.CASH_RECEIPT_CODE;
                     EXCEPTION
                           WHEN NO_DATA_FOUND THEN
                            V_APPLIED_RH_AMOUNT := 0;
                      END; 
                     V_APPLIED_RH_AMOUNT := NVL(V_APPLIED_RH_AMOUNT,0);
                     
                     V_WAIT_RH_AMOUNT := V_RECEIPT_HEADERS_ROW.AMOUNT - V_APPLIED_RH_AMOUNT; 
                    
                     IF V_WAIT_RH_AMOUNT>0 THEN 
                         FOR 
                           SO_HEADER_ROW 
                         IN( 
                             SELECT 
                                  SH.SO_HEADER_ID
                                 ,SH.SO_NUM
                                 ,SH.ERP_OU_ID
                                 ,SH.SALES_MAIN_TYPE
                                 ,SH.SALES_MAIN_TYPE_NAME
                                 ,IC.ITEM_CLASS_ID
                                 ,SH.SETTLE_AMOUNT
                                 ,SH.BIZ_SRC_BILL_TYPE_CODE
                                 ,SH.ENTITY_ID
                                 ,SH.CUSTOMER_CODE
                                 ,SH.CUSTOMER_NAME
                                 ,SH.SO_DATE 
                                 ,SH.SYS_SOURCE_ORDER_NUM
                              FROM 
                                  T_SO_HEADER SH 
                              LEFT JOIN T_BD_ITEM_CLASS IC ON SH.SALES_MAIN_TYPE = IC.CLASS_CODE AND IC.CLASS_TYPE='M'
                              where sh.entity_id= V_RECEIPT_HEADERS_ROW.ENTITY_ID 
                                and sh.customer_code= V_RECEIPT_HEADERS_ROW.CUSTOMER_CODE
                                and sh.account_id= V_RECEIPT_HEADERS_ROW.ACCOUNT_ID
                                and sh.erp_ou_id=V_RECEIPT_HEADERS_ROW.erp_ou_id
                                and sh.biz_src_bill_type_code='1001'
                                and sh.so_status>=10
                                and sh.applied_flag in('1','2')
                                and sh.settle_amount>0
                                AND SH.So_Date < V_WIRTE_DATE
                           )LOOP
                              BEGIN 
                                    BEGIN 
                                      SELECT  
                                         SUM(R.AMOUNT) AMOUNT 
                                           INTO 
                                              V_APPLIED_SH_AMOUNT
                                         FROM CIMS.T_SO_ORDER_RECEIPT R
                                         WHERE ((R.TO_ERP_FLAG = 'C' AND R.CASH_TURNFEE_ID IS NULL) OR R.TO_ERP_FLAG IN ('Y', 'N'))
                                          and  R.ORDER_NUMBER = SO_HEADER_ROW.SO_NUM;
                                      EXCEPTION
                                         WHEN NO_DATA_FOUND THEN
                                              V_APPLIED_SH_AMOUNT := 0;
                                      END;  
                                      V_APPLIED_SH_AMOUNT := NVL(V_APPLIED_SH_AMOUNT,0); 
                                      V_WAIT_SH_AMOUNT := SO_HEADER_ROW.SETTLE_AMOUNT-V_APPLIED_SH_AMOUNT;
                                      
                                      IF V_WAIT_RH_AMOUNT < V_WAIT_SH_AMOUNT THEN 
                                          EXIT;
                                      END IF;
                                      
                                      IF V_WAIT_RH_AMOUNT>0 AND V_WAIT_RH_AMOUNT>=V_WAIT_SH_AMOUNT THEN 
                                         V_ERP_FLAG := 'N';
                                         V_REMAK := '同OU不区分营销大类单单核销'; 
                                         
                                         V_WIRTE_MOUNT := V_WAIT_SH_AMOUNT;
                                         V_WAIT_RH_AMOUNT := V_WAIT_RH_AMOUNT - V_WIRTE_MOUNT;
                                            
                                         INSERT INTO T_SO_ORDER_RECEIPT (
                                                ORDER_RECEIPT_ID                --核销ID
                                               ,CASH_RECEIPT_ID                 --收款单据ID
                                               ,CASH_RECEIPT_LINES_ID           --收款单据行ID
                                               ,RECEIPT_NUMBER                  --收款单据号
                                               ,SO_HEAD_ID                      --财务单据ID
                                               ,SO_HEAD_LINES_ID                -- 财务单据行ID
                                               ,ORDER_NUMBER                    --财务单据号
                                               ,RECEIPT_TYPE                    --回款单据类型
                                               ,ORDER_TYPE                      --应收单据类型
                                               ,AMOUNT                          --金额
                                               ,MATCH_DATE                      --核销日期
                                               ,ORDER_DATE                      --应收单据日期
                                               ,RECEIPT_DATE                    --回款单据日期
                                               ,CUSROMER_NAME                   --客户名称
                                               ,CUSROMER_CODE                   --客户编码
                                               ,ENTITY_ID                       --主体ID
                                               ,SALES_MAIN_TYPE_ID              --营销大类ID
                                               ,SALES_MAIN_TYPE_CODE            --营销大类编码
                                               ,SALES_MAIN_TYPE_NAME            --营销大类名称
                                               ,TO_ERP_FLAG                     --是否引入ERP    Y:已引入ERP N:未引入ERP C:不引入ERP
                                               ,REMARK                          -- 备注
                                               ,ORDER_ERP_OU_ID                 --应收ERP OU ID
                                               ,RECEIPT_ERP_OU_ID               --回款ERP OU ID
                                               ,LAST_UPDATE_DATE
                                               ,RELATED_TRANSACTION_NUMBER
                                             ) VALUES (
                                                S_SO_ORDER_RECEIPT.NEXTVAL          --序列
                                                ,V_RECEIPT_HEADERS_ROW.CASH_RECEIPT_ID               --[收款单据ID]
                                                ,NULL         --收款单据行ID
                                                ,V_RECEIPT_HEADERS_ROW.CASH_RECEIPT_CODE           --收款单据号
                                                ,SO_HEADER_ROW.SO_HEADER_ID              --财务单据ID
                                                ,NULL        -- 应收单据行ID
                                                ,SO_HEADER_ROW.SO_NUM          --财务单据号
                                                ,'1'          --回款单据类型
                                                ,SO_HEADER_ROW.BIZ_SRC_BILL_TYPE_CODE        --应收单据类型
                                                ,V_WIRTE_MOUNT --核销金额
                                                ,TRUNC(SYSDATE, 'DD')-1 --核销日期
                                                ,SO_HEADER_ROW.SO_DATE            --应收单据日期
                                                ,V_RECEIPT_HEADERS_ROW.CASH_RECEIPT_DATE             --回款单据日期
                                                ,SO_HEADER_ROW.CUSTOMER_NAME         --客户名称
                                                ,SO_HEADER_ROW.CUSTOMER_CODE         --客户编码
                                                ,SO_HEADER_ROW.ENTITY_ID             --主体ID
                                                ,SO_HEADER_ROW.ITEM_CLASS_ID--营销大类ID
                                                ,SO_HEADER_ROW.SALES_MAIN_TYPE--营销大类编码
                                                ,SO_HEADER_ROW.SALES_MAIN_TYPE_NAME--营销大类名称
                                                ,V_ERP_FLAG 
                                                ,V_REMAK
                                                ,SO_HEADER_ROW.ERP_OU_ID
                                                ,V_RECEIPT_HEADERS_ROW.ERP_OU_ID
                                                ,SYSDATE
                                                ,SO_HEADER_ROW.SYS_SOURCE_ORDER_NUM
                                           );                              
                                           UPDATE  CIMS.T_SO_HEADER H  SET APPLIED_FLAG='0',H.LAST_UPDATE_DATE=SYSDATE WHERE H.SO_NUM = SO_HEADER_ROW.SO_NUM;
                                         
                                          COMMIT;       
                                      END IF; 
                              END;
                           END LOOP;
                           --更新单据日期 便宜更新单据核销状态
                           UPDATE  CIMS.T_AR_CASH_RECEIPT_HEADERS H  SET H.UPDATED_DATE=SYSDATE WHERE H.CASH_RECEIPT_CODE = V_RECEIPT_HEADERS_ROW.CASH_RECEIPT_CODE;
                    END IF;  
           EXCEPTION            
              WHEN OTHERS THEN
                 ROLLBACK;
                 P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                 P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_AMOUNT_WRITE_OFFS', SQLCODE,V_RECEIPT_HEADERS_ROW.CASH_RECEIPT_CODE||'核销出错！错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);                 
            END;
         END LOOP;  
  EXCEPTION 
      WHEN OTHERS THEN
        ROLLBACK;
           P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
           P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_AMOUNT_WRITE_OFFS', SQLCODE,
            '大额到款单提前核销出错！错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
          RETURN ;
   END;
  
    -- 网批按单据对照关系 单单核销
  PROCEDURE P_AR_NET_WRITE_OFFS
  (
    IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  ) IS
      V_PARAM_ENTITY_ID    NUMBER; 
      V_RECEIPT_METHOD_ID  NUMBER;  
      V_APPLIED_RH_AMOUNT  NUMBER; 
      V_APPLIED_SH_AMOUNT  NUMBER; 
      V_WAIT_RH_AMOUNT  NUMBER; 
      V_WAIT_SH_AMOUNT  NUMBER; 
      V_WIRTE_MOUNT     NUMBER; 
      V_REMAK VARCHAR2(1000);
      V_ERP_FLAG  VARCHAR2(2);
      V_RECEIPT_CODE VARCHAR2(100); 
      V_RECEIPT_HEADERS_ROW     T_AR_CASH_RECEIPT_HEADERS%Rowtype;
  BEGIN
        P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;  
        V_PARAM_ENTITY_ID := IN_ENTITY_ID;

        FOR SO_HEADER_ROW IN (
                SELECT 
                    SH.SO_HEADER_ID
                   ,SH.SO_NUM
                   ,SH.ERP_OU_ID
                   ,SH.SALES_MAIN_TYPE
                   ,SH.SALES_MAIN_TYPE_NAME
                   ,IC.ITEM_CLASS_ID
                   ,SH.SETTLE_AMOUNT
                   ,SH.BIZ_SRC_BILL_TYPE_CODE
                   ,SH.ENTITY_ID
                   ,SH.CUSTOMER_CODE
                   ,SH.CUSTOMER_NAME
                   ,SH.SO_DATE 
                   ,SH.SYS_SOURCE_ORDER_NUM
                FROM 
                    T_SO_HEADER SH 
                LEFT JOIN T_BD_ITEM_CLASS IC ON SH.SALES_MAIN_TYPE = IC.CLASS_CODE AND IC.CLASS_TYPE='M'
                WHERE SH.ENTITY_ID = IN_ENTITY_ID
                 AND SH.SO_DATE> TO_DATE('2019-03-15','yyyy-mm-dd') 
                 AND SH.BIZ_SRC_BILL_TYPE_CODE = PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
                 AND SH.APPLIED_FLAG IN('1','2') 
                 AND SH.FUND_CHECK_MODE='ORDER'
                 AND EXISTS (SELECT 1 FROM  CIMS.T_AR_MPAY_STREAM M WHERE  M.ENTITY_ID =SH.ENTITY_ID  AND  M.OUT_TRADE_NO = SH.SYS_SOURCE_ORDER_NUM ) 
         )LOOP
           BEGIN 
                BEGIN 
                     SELECT  
                         SUM(R.AMOUNT) AMOUNT 
                       INTO 
                          V_APPLIED_SH_AMOUNT
                     FROM CIMS.T_SO_ORDER_RECEIPT R
                     WHERE ((R.TO_ERP_FLAG = 'C' AND R.CASH_TURNFEE_ID IS NULL) OR R.TO_ERP_FLAG IN ('Y', 'N'))
                      and  R.ORDER_NUMBER = SO_HEADER_ROW.SO_NUM;
                EXCEPTION
                     WHEN NO_DATA_FOUND THEN
                          V_APPLIED_SH_AMOUNT := 0;
                END;  
                V_APPLIED_SH_AMOUNT := NVL(V_APPLIED_SH_AMOUNT,0);
                                   
                V_WAIT_SH_AMOUNT := SO_HEADER_ROW.SETTLE_AMOUNT-V_APPLIED_SH_AMOUNT;
                             
                IF  V_WAIT_SH_AMOUNT > 0 THEN
                      BEGIN                   
                          SELECT 
                              MD.CASH_RECEIPT_CODE
                          INTO
                              V_RECEIPT_CODE     
                          FROM 
                              T_AR_MPAY_CASH_DETAIL MD 
                          WHERE  MD.OUT_TRADE_NO = SO_HEADER_ROW.SYS_SOURCE_ORDER_NUM
                             AND MD.CASH_RECEIPT_CODE IS NOT NULL 
                             AND ROWNUM=1;
                      EXCEPTION
                         WHEN NO_DATA_FOUND THEN --订单无收款记录
                           CONTINUE;
                      END;

                    
                      SELECT 
                         RH.*
                      INTO
                         V_RECEIPT_HEADERS_ROW  
                      FROM 
                        T_AR_CASH_RECEIPT_HEADERS RH
                      WHERE RH.ENTITY_ID = V_PARAM_ENTITY_ID 
                      AND RH.CASH_RECEIPT_CODE = V_RECEIPT_CODE;
                   
                         BEGIN 
                             SELECT  
                                  SUM(R.AMOUNT) AMOUNT 
                               INTO 
                                    V_APPLIED_RH_AMOUNT
                             FROM CIMS.T_SO_ORDER_RECEIPT R
                             WHERE ((R.TO_ERP_FLAG = 'C' AND R.CASH_TURNFEE_ID IS NULL) OR R.TO_ERP_FLAG IN ('Y', 'N'))
                             AND R.RECEIPT_NUMBER = V_RECEIPT_HEADERS_ROW.CASH_RECEIPT_CODE;
                         EXCEPTION
                                 WHEN NO_DATA_FOUND THEN
                                  V_APPLIED_RH_AMOUNT := 0;
                          END; 
                          V_APPLIED_RH_AMOUNT := NVL(V_APPLIED_RH_AMOUNT,0);
                                   
                          V_WAIT_RH_AMOUNT := V_RECEIPT_HEADERS_ROW.AMOUNT - V_APPLIED_RH_AMOUNT;
                          IF V_WAIT_RH_AMOUNT < V_WAIT_SH_AMOUNT THEN 
                              --撤销非单单核销记录
                              PKG_AR_WRITE_OFF.P_CANCEL_ORDER_RECEIPT(V_RECEIPT_HEADERS_ROW.CASH_RECEIPT_CODE, '1','ORDER', '#撤销非单单核销', PKG_AR_WRITE_OFF.V_YES, P_RESULT, P_MESSAGE);
                              IF P_MESSAGE <> PKG_AR_WRITE_OFF.V_SUCCESS THEN
                                   NULL;
                              ELSE      
                                  BEGIN 
                                     SELECT  
                                          SUM(R.AMOUNT) AMOUNT 
                                       INTO 
                                            V_APPLIED_RH_AMOUNT
                                     FROM CIMS.T_SO_ORDER_RECEIPT R
                                     WHERE ((R.TO_ERP_FLAG = 'C' AND R.CASH_TURNFEE_ID IS NULL) OR R.TO_ERP_FLAG IN ('Y', 'N'))
                                     AND R.RECEIPT_NUMBER = V_RECEIPT_HEADERS_ROW.CASH_RECEIPT_CODE;
                                  EXCEPTION
                                         WHEN NO_DATA_FOUND THEN
                                          V_APPLIED_RH_AMOUNT := 0;
                                   END;
                                   V_APPLIED_RH_AMOUNT := NVL(V_APPLIED_RH_AMOUNT,0);   
                              END IF;  
                          END IF;
                          V_WAIT_RH_AMOUNT := V_RECEIPT_HEADERS_ROW.AMOUNT - V_APPLIED_RH_AMOUNT;
                                
                          IF V_WAIT_RH_AMOUNT >= V_WAIT_SH_AMOUNT THEN
                               V_WIRTE_MOUNT := V_WAIT_SH_AMOUNT;
                          ELSE
                              V_WIRTE_MOUNT := V_WAIT_RH_AMOUNT;
                          END IF; 
                                  
                          IF  SO_HEADER_ROW.ERP_OU_ID = V_RECEIPT_HEADERS_ROW.ERP_OU_ID THEN
                               V_ERP_FLAG := 'N';
                               V_REMAK := '同OU不区分营销大类单单核销';
                          ELSE
                               V_ERP_FLAG := 'C';
                               V_REMAK := '不同OU不区分营销大类单单核销';
                          END IF;

                          INSERT INTO T_SO_ORDER_RECEIPT (
                                        ORDER_RECEIPT_ID                --核销ID
                                       ,CASH_RECEIPT_ID                 --收款单据ID
                                       ,CASH_RECEIPT_LINES_ID           --收款单据行ID
                                       ,RECEIPT_NUMBER                  --收款单据号
                                       ,SO_HEAD_ID                      --财务单据ID
                                       ,SO_HEAD_LINES_ID                -- 财务单据行ID
                                       ,ORDER_NUMBER                    --财务单据号
                                       ,RECEIPT_TYPE                    --回款单据类型
                                       ,ORDER_TYPE                      --应收单据类型
                                       ,AMOUNT                          --金额
                                       ,MATCH_DATE                      --核销日期
                                       ,ORDER_DATE                      --应收单据日期
                                       ,RECEIPT_DATE                    --回款单据日期
                                       ,CUSROMER_NAME                   --客户名称
                                       ,CUSROMER_CODE                   --客户编码
                                       ,ENTITY_ID                       --主体ID
                                       ,SALES_MAIN_TYPE_ID              --营销大类ID
                                       ,SALES_MAIN_TYPE_CODE            --营销大类编码
                                       ,SALES_MAIN_TYPE_NAME            --营销大类名称
                                       ,TO_ERP_FLAG                     --是否引入ERP    Y:已引入ERP N:未引入ERP C:不引入ERP
                                       ,REMARK                          -- 备注
                                       ,ORDER_ERP_OU_ID                 --应收ERP OU ID
                                       ,RECEIPT_ERP_OU_ID               --回款ERP OU ID
                                       ,LAST_UPDATE_DATE
                                       ,RELATED_TRANSACTION_NUMBER
                                     ) VALUES (
                                        S_SO_ORDER_RECEIPT.NEXTVAL          --序列
                                        ,V_RECEIPT_HEADERS_ROW.CASH_RECEIPT_ID               --[收款单据ID]
                                        ,NULL         --收款单据行ID
                                        ,V_RECEIPT_HEADERS_ROW.CASH_RECEIPT_CODE           --收款单据号
                                        ,SO_HEADER_ROW.SO_HEADER_ID              --财务单据ID
                                        ,NULL        -- 应收单据行ID
                                        ,SO_HEADER_ROW.SO_NUM          --财务单据号
                                        ,'1'          --回款单据类型
                                        ,SO_HEADER_ROW.BIZ_SRC_BILL_TYPE_CODE        --应收单据类型
                                        ,V_WIRTE_MOUNT --核销金额
                                        ,TRUNC(SYSDATE, 'DD')-1 --核销日期
                                        ,SO_HEADER_ROW.SO_DATE            --应收单据日期
                                        ,V_RECEIPT_HEADERS_ROW.CASH_RECEIPT_DATE             --回款单据日期
                                        ,SO_HEADER_ROW.CUSTOMER_NAME         --客户名称
                                        ,SO_HEADER_ROW.CUSTOMER_CODE         --客户编码
                                        ,SO_HEADER_ROW.ENTITY_ID             --主体ID
                                        ,SO_HEADER_ROW.ITEM_CLASS_ID--营销大类ID
                                        ,SO_HEADER_ROW.SALES_MAIN_TYPE--营销大类编码
                                        ,SO_HEADER_ROW.SALES_MAIN_TYPE_NAME--营销大类名称
                                        ,V_ERP_FLAG 
                                        ,V_REMAK
                                        ,SO_HEADER_ROW.ERP_OU_ID
                                        ,V_RECEIPT_HEADERS_ROW.ERP_OU_ID
                                        ,SYSDATE
                                        ,SO_HEADER_ROW.SYS_SOURCE_ORDER_NUM
                                   );
                                                               
                                   IF V_WAIT_RH_AMOUNT >= V_WAIT_SH_AMOUNT THEN
                                        UPDATE  CIMS.T_SO_HEADER H  SET APPLIED_FLAG='0',H.LAST_UPDATE_DATE=SYSDATE WHERE H.SO_NUM = SO_HEADER_ROW.SO_NUM;
                                   ELSE
                                        UPDATE  CIMS.T_SO_HEADER H  SET APPLIED_FLAG='1',H.LAST_UPDATE_DATE=SYSDATE WHERE H.SO_NUM = SO_HEADER_ROW.SO_NUM;  
                                   END IF;
                                 COMMIT;    
                         END IF;            
                   END;
                END LOOP;   --销售单 循环结束
      /*
        
        BEGIN 
           SELECT 
               RECEIPT_METHOD_ID
           INTO 
               V_RECEIPT_METHOD_ID
           FROM T_AR_RECEIPT_METHODS 
           WHERE ENTITY_ID = V_PARAM_ENTITY_ID 
           AND RECEIPT_METHOD_NAME='电汇-网批';
        EXCEPTION
           WHEN NO_DATA_FOUND THEN
             RETURN;  --没有网批收款方法的主体  直接跳过
        END;
        

         FOR  RECEIPT_HEADERS_ROW IN (
              SELECT 
                 RH.CASH_RECEIPT_ID
                ,RH.CASH_RECEIPT_CODE
                ,RH.AMOUNT
                ,RH.ERP_OU_ID
                ,RH.ENTITY_ID
                ,RH.ACCOUNT_ID
                ,RH.CASH_RECEIPT_DATE
              FROM 
                T_AR_CASH_RECEIPT_HEADERS RH
              WHERE RH.ENTITY_ID = V_PARAM_ENTITY_ID 
              AND RH.RECEIPT_METHOD_ID = V_RECEIPT_METHOD_ID
              AND RH.ATTRIBUTE5 IN('1','2')
         )LOOP
            BEGIN 
                BEGIN 
                   SELECT  SUM(R.AMOUNT) AMOUNT 
                     INTO 
                          V_APPLIED_RH_AMOUNT
                   FROM CIMS.T_SO_ORDER_RECEIPT R
                   WHERE ((R.TO_ERP_FLAG = 'C' AND R.CASH_TURNFEE_ID IS NULL) OR R.TO_ERP_FLAG IN ('Y', 'N'))
                    and R.RECEIPT_NUMBER = RECEIPT_HEADERS_ROW.CASH_RECEIPT_CODE;
               EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                       V_APPLIED_RH_AMOUNT := 0;
               END;  
               
               V_WAIT_RH_AMOUNT := RECEIPT_HEADERS_ROW.AMOUNT - V_APPLIED_RH_AMOUNT;
            
               FOR  CASH_DETAIL_ROW IN (
                  SELECT 
                     MD.OUT_TRADE_NO
                   FROM 
                     T_AR_MPAY_CASH_DETAIL MD 
                  WHERE  MD.CASH_RECEIPT_CODE = RECEIPT_HEADERS_ROW.CASH_RECEIPT_CODE
               )LOOP
                  BEGIN
                      FOR SO_HEADER_ROW IN (
                              SELECT 
                                SH.SO_HEADER_ID
                                ,SH.SO_NUM
                                ,SH.ERP_OU_ID
                                ,SH.SALES_MAIN_TYPE
                                ,SH.SALES_MAIN_TYPE_NAME
                                ,IC.ITEM_CLASS_ID
                                ,SH.SETTLE_AMOUNT
                                ,SH.BIZ_SRC_BILL_TYPE_CODE
                                ,SH.ENTITY_ID
                                ,SH.CUSTOMER_CODE
                                ,SH.CUSTOMER_NAME
                                ,SH.SO_DATE
                               FROM T_SO_HEADER SH 
                               LEFT JOIN T_BD_ITEM_CLASS IC ON SH.SALES_MAIN_TYPE = IC.CLASS_CODE AND IC.CLASS_TYPE='M'
                              WHERE  SH.ACCOUNT_ID = RECEIPT_HEADERS_ROW.ACCOUNT_ID 
                              AND SH.ENTITY_ID =RECEIPT_HEADERS_ROW.ENTITY_ID  
                              AND SH.SYS_SOURCE_ORDER_NUM = CASH_DETAIL_ROW.OUT_TRADE_NO
                              AND SH.BIZ_SRC_BILL_TYPE_CODE = '1001' 
                              AND SH.APPLIED_FLAG  IN('1','2') 
                              ORDER BY SH.SO_DATE     
                        )loop
                             BEGIN 
                                  BEGIN 
                                       SELECT  
                                           SUM(R.AMOUNT) AMOUNT 
                                         INTO 
                                            V_APPLIED_SH_AMOUNT
                                       FROM CIMS.T_SO_ORDER_RECEIPT R
                                       WHERE ((R.TO_ERP_FLAG = 'C' AND R.CASH_TURNFEE_ID IS NULL) OR R.TO_ERP_FLAG IN ('Y', 'N'))
                                        and  R.ORDER_NUMBER = SO_HEADER_ROW.SO_NUM;
                                  EXCEPTION
                                       WHEN NO_DATA_FOUND THEN
                                            V_APPLIED_SH_AMOUNT := 0;
                                  END;  
                                   
                                  V_WAIT_SH_AMOUNT := SO_HEADER_ROW.SETTLE_AMOUNT-V_APPLIED_SH_AMOUNT;
                             
                                  IF V_WAIT_RH_AMOUNT > 0 AND V_WAIT_SH_AMOUNT > 0 THEN
                                    
                                       IF V_WAIT_RH_AMOUNT >= V_WAIT_SH_AMOUNT THEN
                                            V_WIRTE_MOUNT := V_WAIT_SH_AMOUNT;
                                       ELSE
                                            V_WIRTE_MOUNT := V_WAIT_RH_AMOUNT;
                                       END IF; 
                                       
                                       IF  SO_HEADER_ROW.ERP_OU_ID = RECEIPT_HEADERS_ROW.ERP_OU_ID THEN
                                           V_ERP_FLAG := 'N';
                                           V_REMAK := '同OU不区分营销大类单单核销';
                                       ELSE
                                           V_ERP_FLAG := 'C';
                                           V_REMAK := '不同OU不区分营销大类单单核销';
                                       END IF;

                                       INSERT INTO T_SO_ORDER_RECEIPT (
                                                    ORDER_RECEIPT_ID                --核销ID
                                                   ,CASH_RECEIPT_ID                 --收款单据ID
                                                   ,CASH_RECEIPT_LINES_ID           --收款单据行ID
                                                   ,RECEIPT_NUMBER                  --收款单据号
                                                   ,SO_HEAD_ID                      --财务单据ID
                                                   ,SO_HEAD_LINES_ID                -- 财务单据行ID
                                                   ,ORDER_NUMBER                    --财务单据号
                                                   ,RECEIPT_TYPE                    --回款单据类型
                                                   ,ORDER_TYPE                      --应收单据类型
                                                   ,AMOUNT                          --金额
                                                   ,MATCH_DATE                      --核销日期
                                                   ,ORDER_DATE                      --应收单据日期
                                                   ,RECEIPT_DATE                    --回款单据日期
                                                   ,CUSROMER_NAME                   --客户名称
                                                   ,CUSROMER_CODE                   --客户编码
                                                   ,ENTITY_ID                       --主体ID
                                                   ,SALES_MAIN_TYPE_ID              --营销大类ID
                                                   ,SALES_MAIN_TYPE_CODE            --营销大类编码
                                                   ,SALES_MAIN_TYPE_NAME            --营销大类名称
                                                   ,TO_ERP_FLAG                     --是否引入ERP    Y:已引入ERP N:未引入ERP C:不引入ERP
                                                   ,REMARK                          -- 备注
                                                   ,ORDER_ERP_OU_ID                 --应收ERP OU ID
                                                   ,RECEIPT_ERP_OU_ID               --回款ERP OU ID
                                                   ,LAST_UPDATE_DATE
                                                 ) VALUES (
                                                    S_SO_ORDER_RECEIPT.NEXTVAL          --序列
                                                    ,RECEIPT_HEADERS_ROW.CASH_RECEIPT_ID               --[收款单据ID]
                                                    ,NULL         --收款单据行ID
                                                    ,RECEIPT_HEADERS_ROW.CASH_RECEIPT_CODE           --收款单据号
                                                    ,SO_HEADER_ROW.SO_HEADER_ID              --财务单据ID
                                                    ,NULL        -- 应收单据行ID
                                                    ,SO_HEADER_ROW.SO_NUM          --财务单据号
                                                    ,'1'          --回款单据类型
                                                    ,SO_HEADER_ROW.BIZ_SRC_BILL_TYPE_CODE        --应收单据类型
                                                    ,V_WIRTE_MOUNT --核销金额
                                                    ,TRUNC(SYSDATE, 'DD')-1 --核销日期
                                                    ,SO_HEADER_ROW.SO_DATE            --应收单据日期
                                                    ,RECEIPT_HEADERS_ROW.CASH_RECEIPT_DATE             --回款单据日期
                                                    ,SO_HEADER_ROW.CUSTOMER_NAME         --客户名称
                                                    ,SO_HEADER_ROW.CUSTOMER_CODE         --客户编码
                                                    ,SO_HEADER_ROW.ENTITY_ID             --主体ID
                                                    ,SO_HEADER_ROW.ITEM_CLASS_ID--营销大类ID
                                                    ,SO_HEADER_ROW.SALES_MAIN_TYPE--营销大类编码
                                                    ,SO_HEADER_ROW.SALES_MAIN_TYPE_NAME--营销大类名称
                                                    ,V_ERP_FLAG 
                                                    ,V_REMAK
                                                    ,SO_HEADER_ROW.ERP_OU_ID
                                                    ,RECEIPT_HEADERS_ROW.ERP_OU_ID
                                                    ,SYSDATE
                                               );
                                               
                                               IF V_WAIT_RH_AMOUNT >= V_WAIT_SH_AMOUNT THEN
                                                    UPDATE  CIMS.T_SO_HEADER H  SET APPLIED_FLAG='0',H.LAST_UPDATE_DATE=SYSDATE WHERE H.SO_NUM = SO_HEADER_ROW.SO_NUM;
                                               ELSE
                                                    UPDATE  CIMS.T_SO_HEADER H  SET APPLIED_FLAG='1',H.LAST_UPDATE_DATE=SYSDATE WHERE H.SO_NUM = SO_HEADER_ROW.SO_NUM;  
                                               END IF;  
                                               
                                               V_WAIT_RH_AMOUNT := V_WAIT_RH_AMOUNT - V_WIRTE_MOUNT;  
                                 ELSE
                                     EXIT;                  
                                 END IF;
                             END;
                          END LOOP;   --销售单 循环结束
                     END;
                  END LOOP;   --提现明细 循环结束
                  
                 IF V_WAIT_RH_AMOUNT = 0 THEN
                     UPDATE  CIMS.T_AR_CASH_RECEIPT_HEADERS RH  SET RH.ATTRIBUTE5='0',RH.UPDATED_DATE=SYSDATE WHERE RH.CASH_RECEIPT_CODE = RECEIPT_HEADERS_ROW.CASH_RECEIPT_CODE;
                 ELSIF V_WAIT_RH_AMOUNT >0 AND  RECEIPT_HEADERS_ROW.AMOUNT > V_WAIT_RH_AMOUNT THEN
                     UPDATE  CIMS.T_AR_CASH_RECEIPT_HEADERS RH  SET RH.ATTRIBUTE5='1',RH.UPDATED_DATE=SYSDATE WHERE RH.CASH_RECEIPT_CODE = RECEIPT_HEADERS_ROW.CASH_RECEIPT_CODE;
                 END IF;             
            END;
         END LOOP;  --  到款单 循环结束   
         **/
         
        --退款单 销售红冲单 单单核销  
        BEGIN 
           SELECT 
               RECEIPT_METHOD_ID
           INTO 
               V_RECEIPT_METHOD_ID
           FROM T_AR_RECEIPT_METHODS 
           WHERE ENTITY_ID = V_PARAM_ENTITY_ID 
           AND RECEIPT_METHOD_NAME='退款（网批）';
        EXCEPTION
           WHEN NO_DATA_FOUND THEN
             RETURN;  --没有网批退款方法的主体  直接跳过
        END;
        
         FOR  RECEIPT_HEADERS_ROW IN (
              SELECT 
                  TH.ATTRIBUTE4   --退款单对应的退货 或 红冲单
                 ,RH.CASH_RECEIPT_ID
                 ,RH.CASH_RECEIPT_CODE
                 ,ABS(RH.AMOUNT) AMOUNT
                 ,RH.ERP_OU_ID
                 ,RH.ENTITY_ID
                 ,RH.ACCOUNT_ID
                 ,RH.CASH_RECEIPT_DATE
              FROM 
                 T_AR_CASH_RECEIPT_HEADERS RH
              LEFT JOIN CIMS.T_AR_REFUND_APPLY_HEADERS TH ON TH.REFUND_APPLY_ID  = RH.REFUND_APPLY_ID
              WHERE RH.ENTITY_ID = V_PARAM_ENTITY_ID 
                AND RH.RECEIPT_METHOD_ID = V_RECEIPT_METHOD_ID
                AND RH.ATTRIBUTE5 IN('2')
         )LOOP
            BEGIN 
                BEGIN 
                   SELECT  SUM(R.AMOUNT) AMOUNT 
                     INTO 
                          V_APPLIED_RH_AMOUNT
                   FROM CIMS.T_SO_ORDER_RECEIPT R
                   WHERE ((R.TO_ERP_FLAG = 'C' AND R.CASH_TURNFEE_ID IS NULL) OR R.TO_ERP_FLAG IN ('Y', 'N'))
                    and R.RECEIPT_NUMBER = RECEIPT_HEADERS_ROW.CASH_RECEIPT_CODE;
               EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                       V_APPLIED_RH_AMOUNT := 0;
               END;  
               
               V_WAIT_RH_AMOUNT := RECEIPT_HEADERS_ROW.AMOUNT - V_APPLIED_RH_AMOUNT;
            
                FOR SO_HEADER_ROW IN (
                        SELECT 
                          SH.SO_HEADER_ID
                          ,SH.SO_NUM
                          ,SH.ERP_OU_ID
                          ,SH.SALES_MAIN_TYPE
                          ,SH.SALES_MAIN_TYPE_NAME
                          ,IC.ITEM_CLASS_ID
                          ,SH.SETTLE_AMOUNT
                          ,SH.BIZ_SRC_BILL_TYPE_CODE
                          ,SH.ENTITY_ID
                          ,SH.CUSTOMER_CODE
                          ,SH.CUSTOMER_NAME
                          ,SH.SO_DATE
                          ,SH.SYS_SOURCE_ORDER_NUM
                         FROM T_SO_HEADER SH 
                         LEFT JOIN T_BD_ITEM_CLASS IC ON SH.SALES_MAIN_TYPE = IC.CLASS_CODE AND IC.CLASS_TYPE='M'
                        WHERE  SH.ACCOUNT_ID = RECEIPT_HEADERS_ROW.ACCOUNT_ID 
                        AND SH.ENTITY_ID =RECEIPT_HEADERS_ROW.ENTITY_ID  
                        AND SH.SO_NUM = RECEIPT_HEADERS_ROW.ATTRIBUTE4
                        AND SH.BIZ_SRC_BILL_TYPE_CODE IN('1002','1003')  --退货 或者 红冲
                        AND SH.APPLIED_FLAG  IN('2') 
                        ORDER BY SH.SO_DATE     
                  )loop
                       BEGIN 
                            BEGIN 
                                 SELECT  
                                     SUM(R.AMOUNT) AMOUNT 
                                   INTO 
                                      V_APPLIED_SH_AMOUNT
                                 FROM CIMS.T_SO_ORDER_RECEIPT R
                                 WHERE ((R.TO_ERP_FLAG = 'C' AND R.CASH_TURNFEE_ID IS NULL) OR R.TO_ERP_FLAG IN ('Y', 'N'))
                                  and  R.ORDER_NUMBER = SO_HEADER_ROW.SO_NUM;
                            EXCEPTION
                                 WHEN NO_DATA_FOUND THEN
                                      V_APPLIED_SH_AMOUNT := 0;
                            END;  
                                   
                            V_WAIT_SH_AMOUNT := SO_HEADER_ROW.SETTLE_AMOUNT-V_APPLIED_SH_AMOUNT;
                            
                            IF V_WAIT_SH_AMOUNT <= 0 OR V_WAIT_RH_AMOUNT > V_WAIT_SH_AMOUNT THEN
                                   --撤销非单单核销记录
                                PKG_AR_WRITE_OFF.P_CANCEL_ORDER_RECEIPT(SO_HEADER_ROW.SO_NUM, SO_HEADER_ROW.BIZ_SRC_BILL_TYPE_CODE,'ORDER', '#撤销非单单核销', PKG_AR_WRITE_OFF.V_YES, P_RESULT, P_MESSAGE);
                                IF P_MESSAGE <> PKG_AR_WRITE_OFF.V_SUCCESS THEN
                                     NULL;
                                ELSE     
                                      BEGIN 
                                         SELECT  
                                            SUM(R.AMOUNT) AMOUNT 
                                              INTO 
                                             V_APPLIED_SH_AMOUNT
                                           FROM CIMS.T_SO_ORDER_RECEIPT R
                                           WHERE ((R.TO_ERP_FLAG = 'C' AND R.CASH_TURNFEE_ID IS NULL) OR R.TO_ERP_FLAG IN ('Y', 'N'))
                                            and  R.ORDER_NUMBER = SO_HEADER_ROW.SO_NUM;
                                        EXCEPTION
                                           WHEN NO_DATA_FOUND THEN
                                                V_APPLIED_SH_AMOUNT := 0;
                                        END;  
                                      V_WAIT_SH_AMOUNT := SO_HEADER_ROW.SETTLE_AMOUNT-V_APPLIED_SH_AMOUNT;
                                END IF;     
                            END IF;
                            
                             
                            IF V_WAIT_RH_AMOUNT > 0 AND V_WAIT_SH_AMOUNT > 0 THEN
                                    
                                 IF V_WAIT_RH_AMOUNT >= V_WAIT_SH_AMOUNT THEN
                                      V_WIRTE_MOUNT := V_WAIT_SH_AMOUNT;
                                 ELSE
                                      V_WIRTE_MOUNT := V_WAIT_RH_AMOUNT;
                                 END IF; 
                                       
                                 IF  SO_HEADER_ROW.ERP_OU_ID = RECEIPT_HEADERS_ROW.ERP_OU_ID THEN
                                     V_ERP_FLAG := 'N';
                                     V_REMAK := '同OU不区分营销大类单单核销';
                                 ELSE
                                     V_ERP_FLAG := 'C';
                                     V_REMAK := '不同OU不区分营销大类单单核销';
                                 END IF;

                                 INSERT INTO T_SO_ORDER_RECEIPT (
                                              ORDER_RECEIPT_ID                --核销ID
                                             ,CASH_RECEIPT_ID                 --收款单据ID
                                             ,CASH_RECEIPT_LINES_ID           --收款单据行ID
                                             ,RECEIPT_NUMBER                  --收款单据号
                                             ,SO_HEAD_ID                      --财务单据ID
                                             ,SO_HEAD_LINES_ID                -- 财务单据行ID
                                             ,ORDER_NUMBER                    --财务单据号
                                             ,RECEIPT_TYPE                    --回款单据类型
                                             ,ORDER_TYPE                      --应收单据类型
                                             ,AMOUNT                          --金额
                                             ,MATCH_DATE                      --核销日期
                                             ,ORDER_DATE                      --应收单据日期
                                             ,RECEIPT_DATE                    --回款单据日期
                                             ,CUSROMER_NAME                   --客户名称
                                             ,CUSROMER_CODE                   --客户编码
                                             ,ENTITY_ID                       --主体ID
                                             ,SALES_MAIN_TYPE_ID              --营销大类ID
                                             ,SALES_MAIN_TYPE_CODE            --营销大类编码
                                             ,SALES_MAIN_TYPE_NAME            --营销大类名称
                                             ,TO_ERP_FLAG                     --是否引入ERP    Y:已引入ERP N:未引入ERP C:不引入ERP
                                             ,REMARK                          -- 备注
                                             ,ORDER_ERP_OU_ID                 --应收ERP OU ID
                                             ,RECEIPT_ERP_OU_ID               --回款ERP OU ID
                                             ,LAST_UPDATE_DATE
                                             ,RELATED_TRANSACTION_NUMBER
                                           ) VALUES (
                                              S_SO_ORDER_RECEIPT.NEXTVAL          --序列
                                              ,RECEIPT_HEADERS_ROW.CASH_RECEIPT_ID               --[收款单据ID]
                                              ,NULL         --收款单据行ID
                                              ,RECEIPT_HEADERS_ROW.CASH_RECEIPT_CODE           --收款单据号
                                              ,SO_HEADER_ROW.SO_HEADER_ID              --财务单据ID
                                              ,NULL        -- 应收单据行ID
                                              ,SO_HEADER_ROW.SO_NUM          --财务单据号
                                              ,'1'          --回款单据类型
                                              ,SO_HEADER_ROW.BIZ_SRC_BILL_TYPE_CODE        --应收单据类型
                                              ,V_WIRTE_MOUNT --核销金额
                                              ,TRUNC(SYSDATE, 'DD')-1 --核销日期
                                              ,SO_HEADER_ROW.SO_DATE            --应收单据日期
                                              ,RECEIPT_HEADERS_ROW.CASH_RECEIPT_DATE             --回款单据日期
                                              ,SO_HEADER_ROW.CUSTOMER_NAME         --客户名称
                                              ,SO_HEADER_ROW.CUSTOMER_CODE         --客户编码
                                              ,SO_HEADER_ROW.ENTITY_ID             --主体ID
                                              ,SO_HEADER_ROW.ITEM_CLASS_ID--营销大类ID
                                              ,SO_HEADER_ROW.SALES_MAIN_TYPE--营销大类编码
                                              ,SO_HEADER_ROW.SALES_MAIN_TYPE_NAME--营销大类名称
                                              ,V_ERP_FLAG 
                                              ,V_REMAK
                                              ,SO_HEADER_ROW.ERP_OU_ID
                                              ,RECEIPT_HEADERS_ROW.ERP_OU_ID
                                              ,SYSDATE
                                              ,NVL(SO_HEADER_ROW.SYS_SOURCE_ORDER_NUM,SO_HEADER_ROW.SO_NUM)
                                         );
                                               
                                         IF V_WAIT_RH_AMOUNT >= V_WAIT_SH_AMOUNT THEN
                                              UPDATE  CIMS.T_SO_HEADER H  SET APPLIED_FLAG='0',H.LAST_UPDATE_DATE=SYSDATE WHERE H.SO_NUM = SO_HEADER_ROW.SO_NUM;
                                         ELSE
                                              UPDATE  CIMS.T_SO_HEADER H  SET APPLIED_FLAG='1',H.LAST_UPDATE_DATE=SYSDATE WHERE H.SO_NUM = SO_HEADER_ROW.SO_NUM;  
                                         END IF;  
                                               
                                         V_WAIT_RH_AMOUNT := V_WAIT_RH_AMOUNT - V_WIRTE_MOUNT;  
                                         
                           ELSE
                               EXIT;                  
                           END IF;
                       END;
                    END LOOP;   --销售单 循环结束
                  
                 IF V_WAIT_RH_AMOUNT = 0 THEN
                     UPDATE  CIMS.T_AR_CASH_RECEIPT_HEADERS RH  SET RH.ATTRIBUTE5='0',RH.UPDATED_DATE=SYSDATE WHERE RH.CASH_RECEIPT_CODE = RECEIPT_HEADERS_ROW.CASH_RECEIPT_CODE;
                 ELSIF V_WAIT_RH_AMOUNT >0 AND  RECEIPT_HEADERS_ROW.AMOUNT > V_WAIT_RH_AMOUNT THEN
                     UPDATE  CIMS.T_AR_CASH_RECEIPT_HEADERS RH  SET RH.ATTRIBUTE5='1',RH.UPDATED_DATE=SYSDATE WHERE RH.CASH_RECEIPT_CODE = RECEIPT_HEADERS_ROW.CASH_RECEIPT_CODE;
                 END IF;   
                 COMMIT;             
            END;
         END LOOP;  --  到款单 循环结束   
        
  EXCEPTION 
      WHEN OTHERS THEN
        ROLLBACK;
          P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
          P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_NET_WRITE_OFFS', SQLCODE,
            '单单核销出错！错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
          RETURN ;
  END;

  -- 核销主过程
  PROCEDURE P_AR_WRITE_OFFS_MAIN
  (
     IN_ENTITY_ID IN  NUMBER,  --主体 
      IN_MOD      IN  NUMBER,  --mod参数
      IN_MOD_REN  IN  NUMBER,  --mod余数
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  ) IS
  -- 核销金额
  V_MATCH_AMOUNT                    T_SO_ORDER_RECEIPT.AMOUNT%TYPE;
  -- 参与核销类型
  V_MATCH_TYPE_SO                   NUMBER := 1; -- 1表示应收；
  V_MATCH_TYPE_AR                   NUMBER := -1;-- -1表示回款
  V_COUNT_SO                        NUMBER; -- 需核销的应收单据记录数
  V_COUNT_AR                        NUMBER; -- 需核销的回款单据记录数

  V_AR_SALE_MAIN_TYPE               PKG_AR_WRITE_OFF.AR_SALE_MAIN_TYPE;--是否区分营销大类。Y：区分；N：不区分
  V_DEFAULT_SALE_MAIN_TYPE_VALUE    VARCHAR2(100);--不区分营销大类时，默认的营销大类ID。
  V_DEFAULT_SALE_MAIN_TYPE_FIELD    VARCHAR2(100);--区分营销大类时，查询的FIELD NAME

  V_DYNAMIC_SQL                     VARCHAR2(2000); -- 动态sql
  TYPE REF_CURSOR_TYPE              IS REF CURSOR;  --定义一个动态游标类型
  V_DYNAMIC_CURSOR                  REF_CURSOR_TYPE;-- 动态游标
  ROW_RECIEPT                       T_AR_RECIEPT_WRITE_OFF%ROWTYPE ;
  ROW_RECIEPT_DIFF_OU               T_AR_RECIEPT_WRITE_OFF%ROWTYPE ;
--  V_AR_SO_RECEIPT_COUNT             NUMBER;
--  V_AR_POSITIVE_NEGATIVE_COUNT      NUMBER;--收款行表是否同时存在正负收款行

  V_PARAM_ENTITY_ID NUMBER;   
  V_PARAM_IS_DIFFOU VARCHAR2(100);
  
  V_PARAM_AGE_MONTH_END VARCHAR2(100);    
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    V_PARAM_ENTITY_ID :=IN_ENTITY_ID;
    
    V_PARAM_AGE_MONTH_END := PKG_BD.F_GET_PARAMETER_VALUE('AR_AGE_DATE_MONTH_END', V_PARAM_ENTITY_ID, NULL, NULL);  
    -- 根据主体判断是否区分营销大类核销
    V_AR_SALE_MAIN_TYPE := PKG_AR_WRITE_OFF.F_AR_DEFAULT_SALE_MAIN_TYPE(V_PARAM_ENTITY_ID);
    
    -- 循环核销事物
    FOR CUR_AUTO_WRITE_OFFS_TRAN IN (SELECT T.* FROM T_AR_AUTO_WRITE_OFFS_TRAN T
                                    WHERE T.ENTITY_ID = V_PARAM_ENTITY_ID AND  T.WRITE_OFFS_FLAG = PKG_AR_WRITE_OFF.V_NO
                                     and mod(T.CUSTOMER_ID,IN_MOD)=IN_MOD_REN
                                    )
    LOOP
      BEGIN
        -- 销售单插入核销应收数据
        INSERT INTO T_AR_REDIRECT_WRITE_OFF(
                REDIRECT_WRITE_OFF_ID,
                ENTITY_ID,
                CUSTOMER_ID,
                CUSTOMER_CODE,
                CUSTOMER_NAME,
                ACCOUNT_ID,
                SALES_CENTER_ID,
                SALES_CENTER_CODE,
                SALES_CENTER_NAME,
                ERP_OU_ID,
                ERP_OU_NAME,
                SALES_MAIN_TYPE_ID,
                SALES_MAIN_TYPE_CODE,
                SALES_MAIN_TYPE_NAME,
                ORDER_MAIN_TYPE,
                SO_ORDER_TYPE,
                ORDER_ID,
                ORDER_LINES_ID,
                ORDER_NUMBER,
                ORDER_DATE,
                MATCH_DATE,
                AGE_DATE,
                ORDER_AMOUNT,
                WRITE_OFF_AMOUNT,
                WRITE_OFF_AMOUNT2,
                USED_FLAG,
                SO_STATUS,
                FUND_CHECK_MODE 
        )
        SELECT S_AR_REDIRECT_WRITE_OFF.NEXTVAL, S.ENTITY_ID, S.CUSTOMER_ID, S.CUSTOMER_CODE, S.CUSTOMER_NAME, S.ACCOUNT_ID,
             S.SALES_CENTER_ID, S.SALES_CENTER_CODE, S.SALES_CENTER_NAME, S.ERP_OU_ID, S.ERP_OU_NAME,
             BDIC.ITEM_CLASS_ID AS SALES_MAIN_TYPE_ID, S.SALES_MAIN_TYPE AS SALES_MAIN_TYPE_CODE, S.SALES_MAIN_TYPE_NAME,
             '2'AS ORDER_MAIN_TYPE, S.BIZ_SRC_BILL_TYPE_CODE, S.SO_HEADER_ID, NULL AS ORDER_LINES_ID, S.SO_NUM, S.SO_DATE,
             CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE AS MATCH_DATE, S.SHOULD_WRITE_OFF_DATE AS AGE_DATE,  --参与核销时点作为账龄日期
             ROUND(NVL(S.SETTLE_AMOUNT, 0), 2) AS ORDER_AMOUNT, NVL(RECEIPT.WRITE_OFF_AMOUNT, 0) AS WRITE_OFF_AMOUNT,
             (ROUND(NVL(S.SETTLE_AMOUNT, 0), 2) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) AS WRITE_OFF_AMOUNT2,
             (CASE WHEN NVL(RECEIPT.WRITE_OFF_AMOUNT, 0) = 0 THEN '2'
                   WHEN (ROUND(NVL(S.SETTLE_AMOUNT, 0), 2) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) > 0 THEN '1'
                   WHEN (ROUND(NVL(S.SETTLE_AMOUNT, 0), 2) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) = 0 THEN '0' END) AS USED_FLAG
             ,S.SO_STATUS, 
             (CASE WHEN S.FUND_CHECK_MODE = 'ORDER' AND M.MPAY_STREAM_ID IS NOT NULL THEN 'ORDER' ELSE 'CREDIT' END) FUND_CHECK_MODE
        FROM CIMS.V_AR_SO_WRITE_OFF_INITIAL_CONF S
        LEFT JOIN CIMS.T_AR_MPAY_STREAM M ON  M.ENTITY_ID =S.ENTITY_ID  AND  M.OUT_TRADE_NO = S.SYS_SOURCE_ORDER_NUM  AND M.CASH_STATUS = '1'
        LEFT JOIN (SELECT BIC.ITEM_CLASS_ID, BIC.CLASS_CODE, BIC.CLASS_NAME, BIC.ENTITY_ID
                  FROM CIMS.T_BD_ITEM_CLASS BIC
                  WHERE BIC.CLASS_TYPE = 'M' AND BIC.ACTIVE_FLAG = 'Y') BDIC
             ON BDIC.CLASS_CODE = S.SALES_MAIN_TYPE AND BDIC.ENTITY_ID = S.ENTITY_ID
        LEFT JOIN (SELECT R.SO_HEAD_ID, R.ORDER_TYPE, NVL(SUM(R.AMOUNT), 0) AS WRITE_OFF_AMOUNT
                          FROM CIMS.T_SO_ORDER_RECEIPT R
                          WHERE ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N))
                          GROUP BY R.SO_HEAD_ID, R.ORDER_TYPE) RECEIPT
             ON S.SO_HEADER_ID = RECEIPT.SO_HEAD_ID AND S.BIZ_SRC_BILL_TYPE_CODE = RECEIPT.ORDER_TYPE
        WHERE S.SHOULD_WRITE_OFF_DATE < CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE + 1
              AND S.SETTLE_AMOUNT <> 0
              -- 取销售单(1001)、销售红冲单(1002)、退货单(1003)、退货红冲单(1004)、销售折让单(1005)、销售折让红冲单(1006)、折让证明单(1007) 、折让证明红冲单(1008)
              AND S.BIZ_SRC_BILL_TYPE_CODE IN (PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_RED,
                                              PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_RETURN, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_RETURN_RED,
                                              PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT_RED,
                                              PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_DISCOUNT, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_DISCOUNT_RED)
              -- 取未核销或部分核销的单据
              AND S.APPLIED_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART)
--              AND PKG_AR_WRITE_OFF.F_AR_HAS_ORDER_RECIPET(S.SO_HEADER_ID, S.BIZ_SRC_BILL_TYPE_CODE) IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART)
              -- 应收
              AND S.APPLIED_PLUS_MINUS_FLAG = V_MATCH_TYPE_SO
              AND S.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
              AND S.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
              AND S.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID ;
           /*  AND NOT EXISTS (SELECT    --有支付的订单模式的单据不参与滚动核销
                        SH.SO_HEADER_ID
                    FROM 
                        T_SO_HEADER SH 
                    WHERE SH.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID
                     AND SH.SO_HEADER_ID = S.SO_HEADER_ID
                     AND SH.BIZ_SRC_BILL_TYPE_CODE = PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
                     AND SH.FUND_CHECK_MODE='ORDER'
                     AND EXISTS (SELECT 1 FROM  CIMS.T_AR_MPAY_STREAM M WHERE  M.ENTITY_ID =SH.ENTITY_ID  AND  M.OUT_TRADE_NO = SH.SYS_SOURCE_ORDER_NUM ) ) ;
        */
        -- 销售单插入回款核销数据
        INSERT INTO T_AR_RECIEPT_WRITE_OFF(
                WRITE_OFF_ID,
                ENTITY_ID,
                CUSTOMER_ID,
                CUSTOMER_CODE,
                CUSTOMER_NAME,
                ACCOUNT_ID,
                SALES_CENTER_ID,
                SALES_CENTER_CODE,
                SALES_CENTER_NAME,
                ERP_OU_ID,
                ERP_OU_NAME,
                SALES_MAIN_TYPE_ID,
                SALES_MAIN_TYPE_CODE,
                SALES_MAIN_TYPE_NAME,
                ORDER_MAIN_TYPE,
                SO_ORDER_TYPE,
                ORDER_ID,
                ORDER_LINES_ID,
                ORDER_NUMBER,
                ORDER_DATE,
                MATCH_DATE,
                AGE_DATE,
                ORDER_AMOUNT,
                WRITE_OFF_AMOUNT,
                WRITE_OFF_AMOUNT2,
                USED_FLAG,
                SO_STATUS
        )
        SELECT S_AR_RECIEPT_WRITE_OFF.NEXTVAL, S.ENTITY_ID, S.CUSTOMER_ID, S.CUSTOMER_CODE, S.CUSTOMER_NAME, S.ACCOUNT_ID,
             S.SALES_CENTER_ID, S.SALES_CENTER_CODE, S.SALES_CENTER_NAME, S.ERP_OU_ID, S.ERP_OU_NAME,
             BDIC.ITEM_CLASS_ID AS SALES_MAIN_TYPE_ID, S.SALES_MAIN_TYPE AS SALES_MAIN_TYPE_CODE, S.SALES_MAIN_TYPE_NAME,
             '2'AS ORDER_MAIN_TYPE, S.BIZ_SRC_BILL_TYPE_CODE, S.SO_HEADER_ID, NULL AS ORDER_LINES_ID, S.SO_NUM, S.SO_DATE,
             CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE AS MATCH_DATE, S.SHOULD_WRITE_OFF_DATE AS AGE_DATE, --参与核销时点作为账龄日期
             ROUND(NVL(S.SETTLE_AMOUNT, 0), 2) AS ORDER_AMOUNT, NVL(RECEIPT.WRITE_OFF_AMOUNT, 0) AS WRITE_OFF_AMOUNT,
             (ROUND(NVL(S.SETTLE_AMOUNT, 0), 2) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) AS WRITE_OFF_AMOUNT2,
             (CASE WHEN NVL(RECEIPT.WRITE_OFF_AMOUNT, 0) = 0 THEN '2'
                   WHEN (ROUND(NVL(S.SETTLE_AMOUNT, 0), 2) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) > 0 THEN '1'
                   WHEN (ROUND(NVL(S.SETTLE_AMOUNT, 0), 2) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) = 0 THEN '0' END) AS USED_FLAG
               ,S.SO_STATUS
    FROM CIMS.V_AR_SO_WRITE_OFF_INITIAL_CONF S
        LEFT JOIN (SELECT BIC.ITEM_CLASS_ID, BIC.CLASS_CODE, BIC.CLASS_NAME, BIC.ENTITY_ID
                  FROM CIMS.T_BD_ITEM_CLASS BIC
                  WHERE BIC.CLASS_TYPE = 'M' AND BIC.ACTIVE_FLAG = 'Y') BDIC
             ON BDIC.CLASS_CODE = S.SALES_MAIN_TYPE AND BDIC.ENTITY_ID = S.ENTITY_ID
        LEFT JOIN (SELECT R.CASH_RECEIPT_ID, R.RECEIPT_TYPE, NVL(SUM(R.AMOUNT), 0) AS WRITE_OFF_AMOUNT
                          FROM CIMS.T_SO_ORDER_RECEIPT R
                          WHERE ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N))
                          GROUP BY R.CASH_RECEIPT_ID, R.RECEIPT_TYPE) RECEIPT
              ON S.SO_HEADER_ID = RECEIPT.CASH_RECEIPT_ID AND S.BIZ_SRC_BILL_TYPE_CODE = RECEIPT.RECEIPT_TYPE
        WHERE S.SHOULD_WRITE_OFF_DATE < CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE + 1
              AND S.SETTLE_AMOUNT <> 0
              -- 取销售单(1001)、销售红冲单(1002)、退货单(1003)、退货红冲单(1004)、销售折让单(1005)、销售折让红冲单(1006)、折让证明单(1007) 、折让证明红冲单(1008)
              AND S.BIZ_SRC_BILL_TYPE_CODE IN (PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_RED,
                                              PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_RETURN, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_RETURN_RED,
                                              PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT_RED,
                                              PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_DISCOUNT, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_DISCOUNT_RED)
              -- 取未核销或部分核销的单据
              AND S.APPLIED_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART)
--              AND PKG_AR_WRITE_OFF.F_AR_HAS_ORDER_RECIPET(S.SO_HEADER_ID, S.BIZ_SRC_BILL_TYPE_CODE) IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART)
              -- 回款
              AND S.APPLIED_PLUS_MINUS_FLAG = V_MATCH_TYPE_AR
              AND S.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
              AND S.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
              AND S.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID;
        -- 负数到款单插入核销应收数据
        INSERT INTO T_AR_REDIRECT_WRITE_OFF(
                REDIRECT_WRITE_OFF_ID,
                ENTITY_ID,
                CUSTOMER_ID,
                CUSTOMER_CODE,
                CUSTOMER_NAME,
                ACCOUNT_ID,
                SALES_CENTER_ID,
                SALES_CENTER_CODE,
                SALES_CENTER_NAME,
                ERP_OU_ID,
                ERP_OU_NAME,
                SALES_MAIN_TYPE_ID,
                SALES_MAIN_TYPE_CODE,
                SALES_MAIN_TYPE_NAME,
                ORDER_MAIN_TYPE,
                SO_ORDER_TYPE,
                ORDER_ID,
                ORDER_LINES_ID,
                ORDER_NUMBER,
                ORDER_DATE,
                MATCH_DATE,
                AGE_DATE,
                ORDER_AMOUNT,
                WRITE_OFF_AMOUNT,
                WRITE_OFF_AMOUNT2,
                USED_FLAG,
                SO_STATUS,
                FUND_CHECK_MODE
        )
        SELECT S_AR_REDIRECT_WRITE_OFF.NEXTVAL, H.ENTITY_ID, H.CUSTOMER_ID, H.CUSTOMER_CODE, H.CUSTOMER_NAME,
               H.ACCOUNT_ID, H.SALES_CENTER_ID, U.CODE AS SALES_CENTER_CODE, U.NAME AS SALES_CENTER_NAME,
               H.ERP_OU_ID, H.ERP_OU_NAME,
               -- 取默认营销大类
               V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_ID, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_NAME,
               '1' AS ORDER_MAIN_TYPE, '1' AS SO_ORDER_TYPE,
               H.CASH_RECEIPT_ID, NULL AS CASH_RECEIPT_LINES_ID, H.CASH_RECEIPT_CODE AS ORDER_NUMBER,
               H.CASH_RECEIPT_DATE AS ORDER_DATE, CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE AS MATCH_DATE,
               H.REVIEWED_DATE AS AGE_DATE, ABS(H.AMOUNT) AS ORDER_AMOUNT,
               NVL(RECEIPT.WRITE_OFF_AMOUNT, 0) AS WRITE_OFF_AMOUNT,
               (ABS(H.AMOUNT) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) AS WRITE_OFF_AMOUNT2,
               (CASE WHEN NVL(RECEIPT.WRITE_OFF_AMOUNT, 0) = 0 THEN '2'
                     WHEN (ABS(H.AMOUNT) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) > 0 THEN '1'
                     WHEN (ABS(H.AMOUNT) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) = 0 THEN '0' END) AS USED_FLAG
               ,'2'||H.RECEIPT_STATUS_ID,'CREDIT'
        FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
        LEFT JOIN CIMS.UP_ORG_UNIT U ON H.SALES_CENTER_ID = U.UNIT_ID
        LEFT JOIN (SELECT R.SO_HEAD_ID, NVL(SUM(R.AMOUNT), 0) AS WRITE_OFF_AMOUNT
                          FROM CIMS.T_SO_ORDER_RECEIPT R
                          WHERE ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                              OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N))
                                AND R.ORDER_TYPE = '1'
                          GROUP BY R.SO_HEAD_ID) RECEIPT
             ON H.CASH_RECEIPT_ID = RECEIPT.SO_HEAD_ID
        WHERE /**NOT EXISTS (SELECT S.* FROM CIMS.T_AR_RECEIPT_METHODS S
                         WHERE S.IN_TURNFEE = H.RECEIPT_METHOD_ID
                               AND S.RECEIPT_METHOD_NAME = PKG_AR_WRITE_OFF.V_CROSS_OU_METHOD_NAME) -- 非跨主体转入单据
              AND NOT EXISTS (SELECT S.* FROM CIMS.T_AR_RECEIPT_METHODS S
                         WHERE S.OUT_TURNFEE = H.RECEIPT_METHOD_ID
                               AND S.RECEIPT_METHOD_NAME = PKG_AR_WRITE_OFF.V_CROSS_OU_METHOD_NAME) -- 非跨主体转出单据
              AND**/ EXISTS (SELECT 1 FROM CIMS.T_AR_CASH_RECEIPT_LINES L WHERE H.CASH_RECEIPT_ID = L.CASH_RECEIPT_ID)
              AND EXISTS (SELECT 1 FROM CIMS.T_SO_ORDER_RECEIPT R WHERE R.SO_HEAD_LINES_ID IS NULL AND R.ORDER_NUMBER = H.CASH_RECEIPT_CODE)
              AND H.REVIEWED_DATE < CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE + 1
              AND H.RECEIPT_STATUS_ID IN (3, 15 ,16)   -- 3:已确认,15:GTMS-付款成功,退款扣货款冲销
              -- 取未核销或部分核销的单据
              AND H.ATTRIBUTE5 IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART)
              -- 应收
              AND H.AMOUNT < 0
              AND H.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
              AND H.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
              AND H.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID;
        INSERT INTO T_AR_REDIRECT_WRITE_OFF(
                REDIRECT_WRITE_OFF_ID,
                ENTITY_ID,
                CUSTOMER_ID,
                CUSTOMER_CODE,
                CUSTOMER_NAME,
                ACCOUNT_ID,
                SALES_CENTER_ID,
                SALES_CENTER_CODE,
                SALES_CENTER_NAME,
                ERP_OU_ID,
                ERP_OU_NAME,
                SALES_MAIN_TYPE_ID,
                SALES_MAIN_TYPE_CODE,
                SALES_MAIN_TYPE_NAME,
                ORDER_MAIN_TYPE,
                SO_ORDER_TYPE,
                ORDER_ID,
                ORDER_LINES_ID,
                ORDER_NUMBER,
                ORDER_DATE,
                MATCH_DATE,
                AGE_DATE,
                ORDER_AMOUNT,
                WRITE_OFF_AMOUNT,
                WRITE_OFF_AMOUNT2,
                USED_FLAG,
                SO_STATUS,
                FUND_CHECK_MODE
        )
        SELECT S_AR_REDIRECT_WRITE_OFF.NEXTVAL, H.ENTITY_ID, H.CUSTOMER_ID, H.CUSTOMER_CODE, H.CUSTOMER_NAME,
               H.ACCOUNT_ID, H.SALES_CENTER_ID, U.CODE AS SALES_CENTER_CODE, U.NAME AS SALES_CENTER_NAME,
               H.ERP_OU_ID, H.ERP_OU_NAME,
               H.SALES_MAIN_TYPE_ID, H.SALES_MAIN_TYPE_CODE, H.SALES_MAIN_TYPE_NAME,
               '1' AS ORDER_MAIN_TYPE, '1' AS SO_ORDER_TYPE,
               H.CASH_RECEIPT_ID, H.CASH_RECEIPT_LINES_ID, H.CASH_RECEIPT_CODE AS ORDER_NUMBER,
               H.CASH_RECEIPT_DATE AS ORDER_DATE, CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE AS MATCH_DATE,
               H.REVIEWED_DATE AS AGE_DATE, ABS(H.AMOUNT) AS ORDER_AMOUNT,
               NVL(RECEIPT.WRITE_OFF_AMOUNT, 0) AS WRITE_OFF_AMOUNT,
               (ABS(H.AMOUNT) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) AS WRITE_OFF_AMOUNT2,
               (CASE WHEN NVL(RECEIPT.WRITE_OFF_AMOUNT, 0) = 0 THEN '2'
                     WHEN (ABS(H.AMOUNT) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) > 0 THEN '1'
                     WHEN (ABS(H.AMOUNT) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) = 0 THEN '0' END) AS USED_FLAG
               ,'2'||H.RECEIPT_STATUS_ID ,'CREDIT'
        FROM CIMS.V_AR_CASH_RECEIPT_HEADER_LINES H
        LEFT JOIN CIMS.UP_ORG_UNIT U ON H.SALES_CENTER_ID = U.UNIT_ID
        LEFT JOIN (SELECT R.SO_HEAD_ID, R.SO_HEAD_LINES_ID, NVL(SUM(R.AMOUNT), 0) AS WRITE_OFF_AMOUNT
                          FROM CIMS.T_SO_ORDER_RECEIPT R
                          WHERE ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                              OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N))
                                AND R.ORDER_TYPE = '1'
                          GROUP BY R.SO_HEAD_ID, R.SO_HEAD_LINES_ID) RECEIPT
             ON H.CASH_RECEIPT_ID = RECEIPT.SO_HEAD_ID AND H.CASH_RECEIPT_LINES_ID = RECEIPT.SO_HEAD_LINES_ID
        WHERE /**NOT EXISTS (SELECT S.* FROM CIMS.T_AR_RECEIPT_METHODS S
                         WHERE S.IN_TURNFEE = H.RECEIPT_METHOD_ID
                               AND S.RECEIPT_METHOD_NAME = PKG_AR_WRITE_OFF.V_CROSS_OU_METHOD_NAME) -- 非跨主体转入单据
              AND NOT EXISTS (SELECT S.* FROM CIMS.T_AR_RECEIPT_METHODS S
                         WHERE S.OUT_TURNFEE = H.RECEIPT_METHOD_ID
                               AND S.RECEIPT_METHOD_NAME = PKG_AR_WRITE_OFF.V_CROSS_OU_METHOD_NAME) -- 非跨主体转出单据
              AND**/ EXISTS (SELECT 1 FROM CIMS.T_AR_CASH_RECEIPT_LINES L WHERE H.CASH_RECEIPT_ID = L.CASH_RECEIPT_ID /**AND L.CASH_RECEIPT_LINES_ID IS NOT NULL**/)
              AND NOT EXISTS (SELECT 1 FROM CIMS.T_SO_ORDER_RECEIPT R WHERE R.SO_HEAD_LINES_ID IS NULL AND R.ORDER_NUMBER = H.CASH_RECEIPT_CODE)
              AND H.REVIEWED_DATE < CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE + 1
              AND H.RECEIPT_STATUS_ID IN (3, 15 ,16)   -- 3:已确认,15:GTMS-付款成功,退款扣货款冲销
              -- 取未核销或部分核销的单据
              AND H.ATTRIBUTE5 IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART)
              -- 应收(排除客户内产品转让头金额为0)
              AND EXISTS (SELECT 1 FROM CIMS.T_AR_CASH_RECEIPT_HEADERS RH WHERE RH.CASH_RECEIPT_ID = H.CASH_RECEIPT_ID AND RH.AMOUNT < 0)
              AND H.AMOUNT < 0
              AND H.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
              AND H.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
              AND H.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID;
        /**FOR ROW_AR_CASH_RECEIPT_HEADER IN (SELECT DISTINCT H.ENTITY_ID, H.CUSTOMER_ID, H.CUSTOMER_CODE, H.CUSTOMER_NAME,
                         H.ACCOUNT_ID, H.SALES_CENTER_ID, U.CODE AS SALES_CENTER_CODE, U.NAME AS SALES_CENTER_NAME,
                         H.ERP_OU_ID, H.ERP_OU_NAME,
                         -- 取默认营销大类
                         V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_ID, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_NAME,
                         '1' AS ORDER_MAIN_TYPE, '1' AS SO_ORDER_TYPE,
                         H.CASH_RECEIPT_ID, NULL AS CASH_RECEIPT_LINES_ID, H.CASH_RECEIPT_CODE AS ORDER_NUMBER,
                         H.CASH_RECEIPT_DATE AS ORDER_DATE, CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE AS MATCH_DATE,
                         H.REVIEWED_DATE AS AGE_DATE, ABS(H.AMOUNT) AS ORDER_AMOUNT
                  FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
                  LEFT JOIN CIMS.UP_ORG_UNIT U ON H.SALES_CENTER_ID = U.UNIT_ID
                  WHERE  EXISTS (SELECT 1 FROM CIMS.T_AR_CASH_RECEIPT_LINES L WHERE H.CASH_RECEIPT_ID = L.CASH_RECEIPT_ID)
                        AND H.REVIEWED_DATE < CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE + 1
                        AND H.RECEIPT_STATUS_ID IN (3, 15)   -- 3:已确认,15:GTMS-付款成功
                        -- 取未核销或部分核销的单据
                        AND H.ATTRIBUTE5 IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART)
--                        AND PKG_AR_WRITE_OFF.F_AR_HAS_ORDER_RECIPET(H.CASH_RECEIPT_ID, '1') IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART)
                        -- 应收
                        AND H.AMOUNT < 0
                        AND H.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
                        AND H.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
                        AND H.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID) LOOP
        	SELECT (CASE WHEN ABS(SUM(L.AMOUNT)) = SUM(ABS(L.AMOUNT)) THEN 0 ELSE 1 END) INTO V_AR_POSITIVE_NEGATIVE_COUNT
          FROM CIMS.T_AR_CASH_RECEIPT_LINES L WHERE L.CASH_RECEIPT_ID = ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_ID;
          IF V_AR_POSITIVE_NEGATIVE_COUNT <> 0 THEN -- 单据的收款行存在同时为正数、负数的收款明细
            P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFFS_MAIN', SQLCODE,
                  '负数单据收款行存在同时为正数、负数的收款明细！错误日志：单据号：'||ROW_AR_CASH_RECEIPT_HEADER.ORDER_NUMBER||
                  '，事物处理日期：'||TO_CHAR(CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE, 'yyyy-MM-dd')||
                  '。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
--          	CONTINUE;
          END IF;
          SELECT COUNT(*) INTO V_AR_SO_RECEIPT_COUNT FROM CIMS.T_SO_ORDER_RECEIPT R
          WHERE R.SO_HEAD_LINES_ID IS NULL --兼容历史数据
                AND R.ORDER_TYPE = '1'
                AND R.SO_HEAD_ID = ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_ID;
          IF V_AR_POSITIVE_NEGATIVE_COUNT <> 0 OR V_AR_SO_RECEIPT_COUNT > 0 THEN -- 负数收款作为应收，存在未写入SO_HEAD_LINES_ID的数据。根据收款头写入汇总金额。
          	INSERT INTO T_AR_REDIRECT_WRITE_OFF(
                  REDIRECT_WRITE_OFF_ID,
                  ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  CUSTOMER_NAME,
                  ACCOUNT_ID,
                  SALES_CENTER_ID,
                  SALES_CENTER_CODE,
                  SALES_CENTER_NAME,
                  ERP_OU_ID,
                  ERP_OU_NAME,
                  SALES_MAIN_TYPE_ID,
                  SALES_MAIN_TYPE_CODE,
                  SALES_MAIN_TYPE_NAME,
                  ORDER_MAIN_TYPE,
                  SO_ORDER_TYPE,
                  ORDER_ID,
                  ORDER_LINES_ID,
                  ORDER_NUMBER,
                  ORDER_DATE,
                  MATCH_DATE,
                  AGE_DATE,
                  ORDER_AMOUNT,
                  WRITE_OFF_AMOUNT,
                  WRITE_OFF_AMOUNT2,
                  USED_FLAG
            ) VALUES (
                  S_AR_REDIRECT_WRITE_OFF.NEXTVAL,
                  ROW_AR_CASH_RECEIPT_HEADER.ENTITY_ID,
                  ROW_AR_CASH_RECEIPT_HEADER.CUSTOMER_ID,
                  ROW_AR_CASH_RECEIPT_HEADER.CUSTOMER_CODE,
                  ROW_AR_CASH_RECEIPT_HEADER.CUSTOMER_NAME,
                  ROW_AR_CASH_RECEIPT_HEADER.ACCOUNT_ID,
                  ROW_AR_CASH_RECEIPT_HEADER.SALES_CENTER_ID,
                  ROW_AR_CASH_RECEIPT_HEADER.SALES_CENTER_CODE,
                  ROW_AR_CASH_RECEIPT_HEADER.SALES_CENTER_NAME,
                  ROW_AR_CASH_RECEIPT_HEADER.ERP_OU_ID,
                  ROW_AR_CASH_RECEIPT_HEADER.ERP_OU_NAME,
                  ROW_AR_CASH_RECEIPT_HEADER.SALE_MAIN_TYPE_ID,
                  ROW_AR_CASH_RECEIPT_HEADER.SALE_MAIN_TYPE_CODE,
                  ROW_AR_CASH_RECEIPT_HEADER.SALE_MAIN_TYPE_NAME,
                  ROW_AR_CASH_RECEIPT_HEADER.ORDER_MAIN_TYPE,
                  ROW_AR_CASH_RECEIPT_HEADER.SO_ORDER_TYPE,
                  ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_ID,
                  ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_LINES_ID,
                  ROW_AR_CASH_RECEIPT_HEADER.ORDER_NUMBER,
                  ROW_AR_CASH_RECEIPT_HEADER.ORDER_DATE,
                  ROW_AR_CASH_RECEIPT_HEADER.MATCH_DATE,
                  ROW_AR_CASH_RECEIPT_HEADER.AGE_DATE,
                  ROW_AR_CASH_RECEIPT_HEADER.ORDER_AMOUNT,-- 单据金额
                  (SELECT NVL(SUM(R.AMOUNT), 0) FROM CIMS.T_SO_ORDER_RECEIPT R
                          WHERE R.ORDER_TYPE = '1' AND R.SO_HEAD_ID = ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_ID
                                AND ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N)) ),--核销金额
                  (SELECT ROW_AR_CASH_RECEIPT_HEADER.ORDER_AMOUNT - NVL(SUM(R.AMOUNT), 0) FROM CIMS.T_SO_ORDER_RECEIPT R
                          WHERE R.ORDER_TYPE = '1' AND R.SO_HEAD_ID = ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_ID
                                AND ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N))),--未核销金额
                  (SELECT (CASE WHEN NVL(SUM(R.AMOUNT), 0) = 0 THEN '2'
                            WHEN ROW_AR_CASH_RECEIPT_HEADER.ORDER_AMOUNT - NVL(SUM(R.AMOUNT), 0) > 0 THEN '1'
                            WHEN ROW_AR_CASH_RECEIPT_HEADER.ORDER_AMOUNT - NVL(SUM(R.AMOUNT), 0) = 0 THEN '0' END) FROM CIMS.T_SO_ORDER_RECEIPT R
                          WHERE R.ORDER_TYPE = '1' AND R.SO_HEAD_ID = ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_ID
                                AND ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N)))
            );
          ELSE-- 负数收款作为应收，全部写入SO_HEAD_LINES_ID的数据。根据收款行写入大类到款金额。
          	FOR ROW_AR_CASH_RECEIPT_LINE IN (SELECT * FROM CIMS.T_AR_CASH_RECEIPT_LINES L WHERE L.CASH_RECEIPT_ID = ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_ID) LOOP
            	INSERT INTO T_AR_REDIRECT_WRITE_OFF(
                    REDIRECT_WRITE_OFF_ID,
                    ENTITY_ID,
                    CUSTOMER_ID,
                    CUSTOMER_CODE,
                    CUSTOMER_NAME,
                    ACCOUNT_ID,
                    SALES_CENTER_ID,
                    SALES_CENTER_CODE,
                    SALES_CENTER_NAME,
                    ERP_OU_ID,
                    ERP_OU_NAME,
                    SALES_MAIN_TYPE_ID,
                    SALES_MAIN_TYPE_CODE,
                    SALES_MAIN_TYPE_NAME,
                    ORDER_MAIN_TYPE,
                    SO_ORDER_TYPE,
                    ORDER_ID,
                    ORDER_LINES_ID,
                    ORDER_NUMBER,
                    ORDER_DATE,
                    MATCH_DATE,
                    AGE_DATE,
                    ORDER_AMOUNT,
                    WRITE_OFF_AMOUNT,
                    WRITE_OFF_AMOUNT2,
                    USED_FLAG
              ) VALUES (
                    S_AR_REDIRECT_WRITE_OFF.NEXTVAL,
                    ROW_AR_CASH_RECEIPT_HEADER.ENTITY_ID,
                    ROW_AR_CASH_RECEIPT_HEADER.CUSTOMER_ID,
                    ROW_AR_CASH_RECEIPT_HEADER.CUSTOMER_CODE,
                    ROW_AR_CASH_RECEIPT_HEADER.CUSTOMER_NAME,
                    ROW_AR_CASH_RECEIPT_HEADER.ACCOUNT_ID,
                    ROW_AR_CASH_RECEIPT_HEADER.SALES_CENTER_ID,
                    ROW_AR_CASH_RECEIPT_HEADER.SALES_CENTER_CODE,
                    ROW_AR_CASH_RECEIPT_HEADER.SALES_CENTER_NAME,
                    ROW_AR_CASH_RECEIPT_HEADER.ERP_OU_ID,
                    ROW_AR_CASH_RECEIPT_HEADER.ERP_OU_NAME,
                    ROW_AR_CASH_RECEIPT_LINE.SALES_MAIN_TYPE_ID,
                    ROW_AR_CASH_RECEIPT_LINE.SALES_MAIN_TYPE_CODE,
                    ROW_AR_CASH_RECEIPT_LINE.SALES_MAIN_TYPE_NAME,
                    ROW_AR_CASH_RECEIPT_HEADER.ORDER_MAIN_TYPE,
                    ROW_AR_CASH_RECEIPT_HEADER.SO_ORDER_TYPE,
                    ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_ID,
                    ROW_AR_CASH_RECEIPT_LINE.CASH_RECEIPT_LINES_ID,
                    ROW_AR_CASH_RECEIPT_HEADER.ORDER_NUMBER,
                    ROW_AR_CASH_RECEIPT_HEADER.ORDER_DATE,
                    ROW_AR_CASH_RECEIPT_HEADER.MATCH_DATE,
                    ROW_AR_CASH_RECEIPT_HEADER.AGE_DATE,
                    ABS(ROW_AR_CASH_RECEIPT_LINE.AMOUNT),  -- 单据金额
                    (SELECT NVL(SUM(R.AMOUNT), 0) FROM CIMS.T_SO_ORDER_RECEIPT R
                       WHERE R.ORDER_TYPE = '1'
                             AND R.SO_HEAD_ID = ROW_AR_CASH_RECEIPT_LINE.CASH_RECEIPT_ID
                             AND R.SO_HEAD_LINES_ID = ROW_AR_CASH_RECEIPT_LINE.CASH_RECEIPT_LINES_ID
                             AND ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                 OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N))),-- 核销金额
                    (SELECT ABS(ROW_AR_CASH_RECEIPT_LINE.AMOUNT) - NVL(SUM(R.AMOUNT), 0) FROM CIMS.T_SO_ORDER_RECEIPT R
                       WHERE R.ORDER_TYPE = '1'
                             AND R.SO_HEAD_ID = ROW_AR_CASH_RECEIPT_LINE.CASH_RECEIPT_ID
                             AND R.SO_HEAD_LINES_ID = ROW_AR_CASH_RECEIPT_LINE.CASH_RECEIPT_LINES_ID
                             AND ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                 OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N))), -- 未核销金额
                    (SELECT (CASE WHEN NVL(SUM(R.AMOUNT), 0) = 0 THEN '2'
                            WHEN ABS(ROW_AR_CASH_RECEIPT_LINE.AMOUNT) - NVL(SUM(R.AMOUNT), 0) > 0 THEN '1'
                            WHEN ABS(ROW_AR_CASH_RECEIPT_LINE.AMOUNT) - NVL(SUM(R.AMOUNT), 0) = 0 THEN '0' END) FROM CIMS.T_SO_ORDER_RECEIPT R
                       WHERE R.ORDER_TYPE = '1'
                             AND R.SO_HEAD_ID = ROW_AR_CASH_RECEIPT_LINE.CASH_RECEIPT_ID
                             AND R.SO_HEAD_LINES_ID = ROW_AR_CASH_RECEIPT_LINE.CASH_RECEIPT_LINES_ID
                             AND ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                 OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N)))
              );
            END LOOP;
          END IF;
        END LOOP;**/
        -- 到款单插入核销回款数据
        INSERT INTO T_AR_RECIEPT_WRITE_OFF(
                WRITE_OFF_ID,
                ENTITY_ID,
                CUSTOMER_ID,
                CUSTOMER_CODE,
                CUSTOMER_NAME,
                ACCOUNT_ID,
                SALES_CENTER_ID,
                SALES_CENTER_CODE,
                SALES_CENTER_NAME,
                ERP_OU_ID,
                ERP_OU_NAME,
                SALES_MAIN_TYPE_ID,
                SALES_MAIN_TYPE_CODE,
                SALES_MAIN_TYPE_NAME,
                ORDER_MAIN_TYPE,
                SO_ORDER_TYPE,
                ORDER_ID,
                ORDER_LINES_ID,
                ORDER_NUMBER,
                ORDER_DATE,
                MATCH_DATE,
                AGE_DATE,
                ORDER_AMOUNT,
                WRITE_OFF_AMOUNT,
                WRITE_OFF_AMOUNT2,
                USED_FLAG,
                SO_STATUS
        )
        SELECT S_AR_RECIEPT_WRITE_OFF.NEXTVAL, H.ENTITY_ID, H.CUSTOMER_ID, H.CUSTOMER_CODE, H.CUSTOMER_NAME,
               H.ACCOUNT_ID, H.SALES_CENTER_ID, U.CODE AS SALES_CENTER_CODE, U.NAME AS SALES_CENTER_NAME,
               H.ERP_OU_ID, H.ERP_OU_NAME,
               -- 取默认营销大类
               V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_ID, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_NAME,
               '1' AS ORDER_MAIN_TYPE, '1' AS SO_ORDER_TYPE,
               H.CASH_RECEIPT_ID, NULL AS CASH_RECEIPT_LINES_ID, H.CASH_RECEIPT_CODE AS ORDER_NUMBER,
               H.CASH_RECEIPT_DATE AS ORDER_DATE, CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE AS MATCH_DATE,
               H.REVIEWED_DATE AS AGE_DATE, ABS(H.AMOUNT) AS ORDER_AMOUNT,
               NVL(RECEIPT.WRITE_OFF_AMOUNT, 0) AS WRITE_OFF_AMOUNT,
               (ABS(H.AMOUNT) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) AS WRITE_OFF_AMOUNT2,
               (CASE WHEN NVL(RECEIPT.WRITE_OFF_AMOUNT, 0) = 0 THEN '2'
                     WHEN (ABS(H.AMOUNT) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) > 0 THEN '1'
                     WHEN (ABS(H.AMOUNT) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) = 0 THEN '0' END) AS USED_FLAG
              ,'2'||H.RECEIPT_STATUS_ID  
        FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
        LEFT JOIN CIMS.UP_ORG_UNIT U ON H.SALES_CENTER_ID = U.UNIT_ID
        LEFT JOIN (SELECT R.CASH_RECEIPT_ID, NVL(SUM(R.AMOUNT), 0) AS WRITE_OFF_AMOUNT
                          FROM CIMS.T_SO_ORDER_RECEIPT R
                          WHERE ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                                OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N))
                                 AND R.RECEIPT_TYPE = '1'
                          GROUP BY R.CASH_RECEIPT_ID) RECEIPT
             ON H.CASH_RECEIPT_ID = RECEIPT.CASH_RECEIPT_ID
        WHERE EXISTS (SELECT 1 FROM CIMS.T_AR_CASH_RECEIPT_LINES L WHERE H.CASH_RECEIPT_ID = L.CASH_RECEIPT_ID)
              AND EXISTS (SELECT 1 FROM CIMS.T_SO_ORDER_RECEIPT R WHERE R.CASH_RECEIPT_LINES_ID IS NULL  AND R.RECEIPT_NUMBER = H.CASH_RECEIPT_CODE)
              AND H.REVIEWED_DATE < CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE + 1
              AND H.RECEIPT_STATUS_ID IN (3, 5, 6)   -- 3:已确认,5:已审核,6:已汇
              -- 取未核销或部分核销的单据
              AND H.ATTRIBUTE5 IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART)
              -- 回款
              AND H.AMOUNT > 0
              AND H.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
              AND H.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
              AND H.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID;
        INSERT INTO T_AR_RECIEPT_WRITE_OFF(
                WRITE_OFF_ID,
                ENTITY_ID,
                CUSTOMER_ID,
                CUSTOMER_CODE,
                CUSTOMER_NAME,
                ACCOUNT_ID,
                SALES_CENTER_ID,
                SALES_CENTER_CODE,
                SALES_CENTER_NAME,
                ERP_OU_ID,
                ERP_OU_NAME,
                SALES_MAIN_TYPE_ID,
                SALES_MAIN_TYPE_CODE,
                SALES_MAIN_TYPE_NAME,
                ORDER_MAIN_TYPE,
                SO_ORDER_TYPE,
                ORDER_ID,
                ORDER_LINES_ID,
                ORDER_NUMBER,
                ORDER_DATE,
                MATCH_DATE,
                AGE_DATE,
                ORDER_AMOUNT,
                WRITE_OFF_AMOUNT,
                WRITE_OFF_AMOUNT2,
                USED_FLAG,
                SO_STATUS
        )
        SELECT S_AR_RECIEPT_WRITE_OFF.NEXTVAL, H.ENTITY_ID, H.CUSTOMER_ID, H.CUSTOMER_CODE, H.CUSTOMER_NAME,
               H.ACCOUNT_ID, H.SALES_CENTER_ID, U.CODE AS SALES_CENTER_CODE, U.NAME AS SALES_CENTER_NAME,
               H.ERP_OU_ID, H.ERP_OU_NAME,
               H.SALES_MAIN_TYPE_ID, H.SALES_MAIN_TYPE_CODE, H.SALES_MAIN_TYPE_NAME,
               '1' AS ORDER_MAIN_TYPE, '1' AS SO_ORDER_TYPE,
               H.CASH_RECEIPT_ID, H.CASH_RECEIPT_LINES_ID, H.CASH_RECEIPT_CODE AS ORDER_NUMBER,
               H.CASH_RECEIPT_DATE AS ORDER_DATE, CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE AS MATCH_DATE,
               H.REVIEWED_DATE AS AGE_DATE, ABS(H.AMOUNT) AS ORDER_AMOUNT,
               NVL(RECEIPT.WRITE_OFF_AMOUNT, 0) AS WRITE_OFF_AMOUNT,
               (ABS(H.AMOUNT) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) AS WRITE_OFF_AMOUNT2,
               (CASE WHEN NVL(RECEIPT.WRITE_OFF_AMOUNT, 0) = 0 THEN '2'
                     WHEN (ABS(H.AMOUNT) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) > 0 THEN '1'
                     WHEN (ABS(H.AMOUNT) - NVL(RECEIPT.WRITE_OFF_AMOUNT, 0)) = 0 THEN '0' END) AS USED_FLAG
               ,'2'||H.RECEIPT_STATUS_ID  
        FROM CIMS.V_AR_CASH_RECEIPT_HEADER_LINES H
        LEFT JOIN CIMS.UP_ORG_UNIT U ON H.SALES_CENTER_ID = U.UNIT_ID
        LEFT JOIN (SELECT R.CASH_RECEIPT_ID, R.CASH_RECEIPT_LINES_ID, NVL(SUM(R.AMOUNT), 0) AS WRITE_OFF_AMOUNT
                          FROM CIMS.T_SO_ORDER_RECEIPT R
                          WHERE ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                                OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N))
                                 AND R.RECEIPT_TYPE = '1'
                          GROUP BY R.CASH_RECEIPT_ID, R.CASH_RECEIPT_LINES_ID) RECEIPT
             ON H.CASH_RECEIPT_ID = RECEIPT.CASH_RECEIPT_ID AND H.CASH_RECEIPT_LINES_ID = RECEIPT.CASH_RECEIPT_LINES_ID
        WHERE /**NOT EXISTS (SELECT S.* FROM CIMS.T_AR_RECEIPT_METHODS S
                         WHERE S.IN_TURNFEE = H.RECEIPT_METHOD_ID
                               AND S.RECEIPT_METHOD_NAME = PKG_AR_WRITE_OFF.V_CROSS_OU_METHOD_NAME) -- 非跨主体转入单据
              AND NOT EXISTS (SELECT S.* FROM CIMS.T_AR_RECEIPT_METHODS S
                         WHERE S.OUT_TURNFEE = H.RECEIPT_METHOD_ID
                               AND S.RECEIPT_METHOD_NAME = PKG_AR_WRITE_OFF.V_CROSS_OU_METHOD_NAME)**/ -- 非跨主体转出单据
              EXISTS (SELECT 1 FROM CIMS.T_AR_CASH_RECEIPT_LINES L WHERE H.CASH_RECEIPT_ID = L.CASH_RECEIPT_ID)
              AND NOT EXISTS (SELECT 1 FROM CIMS.T_SO_ORDER_RECEIPT R WHERE R.CASH_RECEIPT_LINES_ID IS NULL AND R.RECEIPT_NUMBER = H.CASH_RECEIPT_CODE)
              AND H.REVIEWED_DATE < CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE + 1
              AND H.RECEIPT_STATUS_ID IN (3, 5, 6)   -- 3:已确认,5:已审核,6:已汇
              -- 取未核销或部分核销的单据
              AND H.ATTRIBUTE5 IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART)
              -- 回款(排除客户内产品转让头金额为0)
              AND EXISTS (SELECT 1 FROM CIMS.T_AR_CASH_RECEIPT_HEADERS RH WHERE RH.CASH_RECEIPT_ID = H.CASH_RECEIPT_ID AND RH.AMOUNT > 0)
              AND H.AMOUNT > 0
              AND H.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
              AND H.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
              AND H.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID;
        /**FOR ROW_AR_CASH_RECEIPT_HEADER IN (SELECT DISTINCT H.ENTITY_ID, H.CUSTOMER_ID, H.CUSTOMER_CODE, H.CUSTOMER_NAME,
                               H.ACCOUNT_ID, H.SALES_CENTER_ID, U.CODE AS SALES_CENTER_CODE, U.NAME AS SALES_CENTER_NAME,
                               H.ERP_OU_ID, H.ERP_OU_NAME,
                               -- 取默认营销大类
                               V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_ID, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_NAME,
                               '1' AS ORDER_MAIN_TYPE, '1' AS SO_ORDER_TYPE,
                               H.CASH_RECEIPT_ID, NULL AS CASH_RECEIPT_LINES_ID, H.CASH_RECEIPT_CODE AS ORDER_NUMBER,
                               H.CASH_RECEIPT_DATE AS ORDER_DATE, CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE AS MATCH_DATE,
                               H.REVIEWED_DATE AS AGE_DATE, ABS(H.AMOUNT) AS ORDER_AMOUNT
                        FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
                        LEFT JOIN CIMS.UP_ORG_UNIT U ON H.SALES_CENTER_ID = U.UNIT_ID
                        WHERE EXISTS (SELECT * FROM CIMS.T_AR_CASH_RECEIPT_LINES L WHERE H.CASH_RECEIPT_ID = L.CASH_RECEIPT_ID)
                              AND H.REVIEWED_DATE < CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE + 1
                              AND H.RECEIPT_STATUS_ID IN (3, 5, 6)   -- 3:已确认,5:已审核,6:已汇
                              -- 取未核销或部分核销的单据
                              AND H.ATTRIBUTE5 IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART)
--                              AND PKG_AR_WRITE_OFF.F_AR_HAS_ORDER_RECIPET(H.CASH_RECEIPT_ID, '1') IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART)
                              -- 回款
                              AND H.AMOUNT > 0
                              AND H.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
                              AND H.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
                              AND H.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID) LOOP
        	SELECT (CASE WHEN ABS(SUM(L.AMOUNT)) = SUM(ABS(L.AMOUNT)) THEN 0 ELSE 1 END) INTO V_AR_POSITIVE_NEGATIVE_COUNT
          FROM CIMS.T_AR_CASH_RECEIPT_LINES L WHERE L.CASH_RECEIPT_ID = ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_ID;
          IF V_AR_POSITIVE_NEGATIVE_COUNT <> 0 THEN -- 单据的收款行存在同时为正数、负数的收款明细
            P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFFS_MAIN', SQLCODE,
                  '正数单据收款行存在同时为正数、负数的收款明细！错误日志：单据号：'||ROW_AR_CASH_RECEIPT_HEADER.ORDER_NUMBER||
                  '，事物处理日期：'||TO_CHAR(CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE, 'yyyy-MM-dd')||
                  '。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
--          	CONTINUE;
          END IF;
        	SELECT COUNT(*) INTO V_AR_SO_RECEIPT_COUNT FROM CIMS.T_SO_ORDER_RECEIPT R
          WHERE R.CASH_RECEIPT_LINES_ID IS NULL --兼容历史数据
                AND R.RECEIPT_TYPE = '1'
                AND R.CASH_RECEIPT_ID = ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_ID;
          IF V_AR_POSITIVE_NEGATIVE_COUNT <> 0 OR V_AR_SO_RECEIPT_COUNT > 0 THEN -- 正数收款作为应收，存在未写入CASH_RECEIPT_LINES_ID的数据。根据收款头写入汇总金额。
          	INSERT INTO T_AR_RECIEPT_WRITE_OFF(
                  WRITE_OFF_ID,
                  ENTITY_ID,
                  CUSTOMER_ID,
                  CUSTOMER_CODE,
                  CUSTOMER_NAME,
                  ACCOUNT_ID,
                  SALES_CENTER_ID,
                  SALES_CENTER_CODE,
                  SALES_CENTER_NAME,
                  ERP_OU_ID,
                  ERP_OU_NAME,
                  SALES_MAIN_TYPE_ID,
                  SALES_MAIN_TYPE_CODE,
                  SALES_MAIN_TYPE_NAME,
                  ORDER_MAIN_TYPE,
                  SO_ORDER_TYPE,
                  ORDER_ID,
                  ORDER_LINES_ID,
                  ORDER_NUMBER,
                  ORDER_DATE,
                  MATCH_DATE,
                  AGE_DATE,
                  ORDER_AMOUNT,
                  WRITE_OFF_AMOUNT,
                  WRITE_OFF_AMOUNT2,
                  USED_FLAG
            ) VALUES (
                  S_AR_RECIEPT_WRITE_OFF.NEXTVAL,
                  ROW_AR_CASH_RECEIPT_HEADER.ENTITY_ID,
                  ROW_AR_CASH_RECEIPT_HEADER.CUSTOMER_ID,
                  ROW_AR_CASH_RECEIPT_HEADER.CUSTOMER_CODE,
                  ROW_AR_CASH_RECEIPT_HEADER.CUSTOMER_NAME,
                  ROW_AR_CASH_RECEIPT_HEADER.ACCOUNT_ID,
                  ROW_AR_CASH_RECEIPT_HEADER.SALES_CENTER_ID,
                  ROW_AR_CASH_RECEIPT_HEADER.SALES_CENTER_CODE,
                  ROW_AR_CASH_RECEIPT_HEADER.SALES_CENTER_NAME,
                  ROW_AR_CASH_RECEIPT_HEADER.ERP_OU_ID,
                  ROW_AR_CASH_RECEIPT_HEADER.ERP_OU_NAME,
                  ROW_AR_CASH_RECEIPT_HEADER.SALE_MAIN_TYPE_ID,
                  ROW_AR_CASH_RECEIPT_HEADER.SALE_MAIN_TYPE_CODE,
                  ROW_AR_CASH_RECEIPT_HEADER.SALE_MAIN_TYPE_NAME,
                  ROW_AR_CASH_RECEIPT_HEADER.ORDER_MAIN_TYPE,
                  ROW_AR_CASH_RECEIPT_HEADER.SO_ORDER_TYPE,
                  ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_ID,
                  ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_LINES_ID,
                  ROW_AR_CASH_RECEIPT_HEADER.ORDER_NUMBER,
                  ROW_AR_CASH_RECEIPT_HEADER.ORDER_DATE,
                  ROW_AR_CASH_RECEIPT_HEADER.MATCH_DATE,
                  ROW_AR_CASH_RECEIPT_HEADER.AGE_DATE,
                  ROW_AR_CASH_RECEIPT_HEADER.ORDER_AMOUNT,-- 单据金额
                  (SELECT NVL(SUM(R.AMOUNT), 0) FROM CIMS.T_SO_ORDER_RECEIPT R
                          WHERE R.RECEIPT_TYPE = '1' AND R.CASH_RECEIPT_ID = ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_ID
                             AND ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                 OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N))),--核销金额
                  (SELECT ROW_AR_CASH_RECEIPT_HEADER.ORDER_AMOUNT - NVL(SUM(R.AMOUNT), 0) FROM CIMS.T_SO_ORDER_RECEIPT R
                          WHERE R.RECEIPT_TYPE = '1' AND R.CASH_RECEIPT_ID = ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_ID
                             AND ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                 OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N))),--未核销金额
                  (SELECT (CASE WHEN NVL(SUM(R.AMOUNT), 0) = 0 THEN '2'
                            WHEN ROW_AR_CASH_RECEIPT_HEADER.ORDER_AMOUNT - NVL(SUM(R.AMOUNT), 0) > 0 THEN '1'
                            WHEN ROW_AR_CASH_RECEIPT_HEADER.ORDER_AMOUNT - NVL(SUM(R.AMOUNT), 0) = 0 THEN '0' END) FROM CIMS.T_SO_ORDER_RECEIPT R
                          WHERE R.RECEIPT_TYPE = '1' AND R.CASH_RECEIPT_ID = ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_ID
                             AND ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                 OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N)))
            );
          ELSE-- 正数收款作为应收，全部写入CASH_RECEIPT_LINES_ID的数据。根据收款行写入大类到款金额。
          	FOR ROW_AR_CASH_RECEIPT_LINE IN (SELECT * FROM CIMS.T_AR_CASH_RECEIPT_LINES L WHERE L.CASH_RECEIPT_ID = ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_ID) LOOP
            	INSERT INTO T_AR_RECIEPT_WRITE_OFF(
                    WRITE_OFF_ID,
                    ENTITY_ID,
                    CUSTOMER_ID,
                    CUSTOMER_CODE,
                    CUSTOMER_NAME,
                    ACCOUNT_ID,
                    SALES_CENTER_ID,
                    SALES_CENTER_CODE,
                    SALES_CENTER_NAME,
                    ERP_OU_ID,
                    ERP_OU_NAME,
                    SALES_MAIN_TYPE_ID,
                    SALES_MAIN_TYPE_CODE,
                    SALES_MAIN_TYPE_NAME,
                    ORDER_MAIN_TYPE,
                    SO_ORDER_TYPE,
                    ORDER_ID,
                    ORDER_LINES_ID,
                    ORDER_NUMBER,
                    ORDER_DATE,
                    MATCH_DATE,
                    AGE_DATE,
                    ORDER_AMOUNT,
                    WRITE_OFF_AMOUNT,
                    WRITE_OFF_AMOUNT2,
                    USED_FLAG
              ) VALUES (
                    S_AR_RECIEPT_WRITE_OFF.NEXTVAL,
                    ROW_AR_CASH_RECEIPT_HEADER.ENTITY_ID,
                    ROW_AR_CASH_RECEIPT_HEADER.CUSTOMER_ID,
                    ROW_AR_CASH_RECEIPT_HEADER.CUSTOMER_CODE,
                    ROW_AR_CASH_RECEIPT_HEADER.CUSTOMER_NAME,
                    ROW_AR_CASH_RECEIPT_HEADER.ACCOUNT_ID,
                    ROW_AR_CASH_RECEIPT_HEADER.SALES_CENTER_ID,
                    ROW_AR_CASH_RECEIPT_HEADER.SALES_CENTER_CODE,
                    ROW_AR_CASH_RECEIPT_HEADER.SALES_CENTER_NAME,
                    ROW_AR_CASH_RECEIPT_HEADER.ERP_OU_ID,
                    ROW_AR_CASH_RECEIPT_HEADER.ERP_OU_NAME,
                    ROW_AR_CASH_RECEIPT_LINE.SALES_MAIN_TYPE_ID,
                    ROW_AR_CASH_RECEIPT_LINE.SALES_MAIN_TYPE_CODE,
                    ROW_AR_CASH_RECEIPT_LINE.SALES_MAIN_TYPE_NAME,
                    ROW_AR_CASH_RECEIPT_HEADER.ORDER_MAIN_TYPE,
                    ROW_AR_CASH_RECEIPT_HEADER.SO_ORDER_TYPE,
                    ROW_AR_CASH_RECEIPT_HEADER.CASH_RECEIPT_ID,
                    ROW_AR_CASH_RECEIPT_LINE.CASH_RECEIPT_LINES_ID,
                    ROW_AR_CASH_RECEIPT_HEADER.ORDER_NUMBER,
                    ROW_AR_CASH_RECEIPT_HEADER.ORDER_DATE,
                    ROW_AR_CASH_RECEIPT_HEADER.MATCH_DATE,
                    ROW_AR_CASH_RECEIPT_HEADER.AGE_DATE,
                    ABS(ROW_AR_CASH_RECEIPT_LINE.AMOUNT),  -- 单据金额
                    (SELECT NVL(SUM(R.AMOUNT), 0) FROM CIMS.T_SO_ORDER_RECEIPT R
                       WHERE R.RECEIPT_TYPE = '1'
                             AND R.CASH_RECEIPT_ID = ROW_AR_CASH_RECEIPT_LINE.CASH_RECEIPT_ID
                             AND R.CASH_RECEIPT_LINES_ID = ROW_AR_CASH_RECEIPT_LINE.CASH_RECEIPT_LINES_ID
                             AND ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                 OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N))),-- 核销金额
                    (SELECT ABS(ROW_AR_CASH_RECEIPT_LINE.AMOUNT) - NVL(SUM(R.AMOUNT), 0) FROM CIMS.T_SO_ORDER_RECEIPT R
                       WHERE R.RECEIPT_TYPE = '1'
                             AND R.CASH_RECEIPT_ID = ROW_AR_CASH_RECEIPT_LINE.CASH_RECEIPT_ID
                             AND R.CASH_RECEIPT_LINES_ID = ROW_AR_CASH_RECEIPT_LINE.CASH_RECEIPT_LINES_ID
                             AND ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                 OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N))), -- 未核销金额
                    (SELECT (CASE WHEN NVL(SUM(R.AMOUNT), 0) = 0 THEN '2'
                            WHEN ABS(ROW_AR_CASH_RECEIPT_LINE.AMOUNT) - NVL(SUM(R.AMOUNT), 0) > 0 THEN '1'
                            WHEN ABS(ROW_AR_CASH_RECEIPT_LINE.AMOUNT) - NVL(SUM(R.AMOUNT), 0) = 0 THEN '0' END) FROM CIMS.T_SO_ORDER_RECEIPT R
                       WHERE R.RECEIPT_TYPE = '1'
                             AND R.CASH_RECEIPT_ID = ROW_AR_CASH_RECEIPT_LINE.CASH_RECEIPT_ID
                             AND R.CASH_RECEIPT_LINES_ID = ROW_AR_CASH_RECEIPT_LINE.CASH_RECEIPT_LINES_ID
                             AND ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                 OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N)))
              );
            END LOOP;
          END IF;
        END LOOP;**/
        COMMIT;
      EXCEPTION WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
        P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFFS_MAIN', SQLCODE,
            '需核销单据插入核销临时表出错！错误日志：主体：'||CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID||
            '，客户'||CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID||
            '，账户：'||CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID||
            '，中心：'||CUR_AUTO_WRITE_OFFS_TRAN.SALES_CENTER_ID||
            '，事物处理日期：'||TO_CHAR(CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE, 'yyyy-MM-dd')||
            '。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
      END;
    END LOOP;

    -- 循环核销事物，开始核销
    FOR CUR_AUTO_WRITE_OFFS_TRAN IN (SELECT T.* FROM T_AR_AUTO_WRITE_OFFS_TRAN T
                                 WHERE T.ENTITY_ID = V_PARAM_ENTITY_ID AND  T.WRITE_OFFS_FLAG = PKG_AR_WRITE_OFF.V_NO 
                                    and mod(T.CUSTOMER_ID,IN_MOD)=IN_MOD_REN
                                 ORDER BY T.TRAN_DATE, T.ENTITY_ID, T.CUSTOMER_CODE)
    LOOP
      BEGIN
        
     --    BEGIN
     --       SELECT
     --           IS_OU 
     --        INTO 
     --           V_PARAM_IS_DIFFOU
    --         FROM T_AR_WRITE_CONFIG CF
    --         WHERE CF.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID
     --        AND CF.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
      --       AND CF.ACCOUNT_ID =  CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
      --       AND ROWNUM=1;
      --    EXCEPTION
      --       WHEN NO_DATA_FOUND THEN
      --           V_PARAM_IS_DIFFOU := 'Y';
       --   END; 
       --   V_PARAM_IS_DIFFOU := NVL(V_PARAM_IS_DIFFOU,'Y');
         
        -- 根据主体判断是否区分营销大类核销
        V_AR_SALE_MAIN_TYPE := PKG_AR_WRITE_OFF.F_AR_DEFAULT_SALE_MAIN_TYPE(CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID);
        
        IF NVL(CUR_AUTO_WRITE_OFFS_TRAN.IS_AUTO_WRITF_OFF,'Y') = 'Y' THEN
        
                --跳出外层循环
                <<FLAG_SO>>
               --应收款未核销临时表是否有数据
               SELECT COUNT(*)
                 INTO V_COUNT_SO
                 FROM T_AR_REDIRECT_WRITE_OFF RWO
                WHERE RWO.WRITE_OFF_AMOUNT2 > 0
                  AND RWO.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
                  AND RWO.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
                  AND RWO.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID
                  AND ROWNUM<=1;
                 --跳出内层循环标识
                 <<FLAG_AR>>
               --回款未核销临时表是否有数据
               SELECT COUNT(*)
                 INTO V_COUNT_AR
                 FROM T_AR_RECIEPT_WRITE_OFF RWO
                WHERE RWO.WRITE_OFF_AMOUNT2 > 0
                  AND RWO.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
                  AND RWO.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
                  AND RWO.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID
                  AND ROWNUM<=1;
                --应收款临时表【有数据 】
                IF (V_COUNT_SO > 0) THEN
                   --循环应收临时表
                   FOR ROW_REDIRECT IN (SELECT RWO.* FROM T_AR_REDIRECT_WRITE_OFF RWO
                                 WHERE RWO.WRITE_OFF_AMOUNT2 > 0
                                   AND RWO.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
                                   AND RWO.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
                                   AND RWO.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID
                                   AND RWO.FUND_CHECK_MODE ='CREDIT'
                                /**   AND NOT EXISTS (SELECT    --有支付的订单模式的单据不参与滚动核销
                                          SH.SO_HEADER_ID
                                      FROM 
                                          T_SO_HEADER SH 
                                      WHERE SH.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID
                                       AND SH.SO_HEADER_ID = RWO.ORDER_ID
                                       AND SH.SO_NUM = RWO.ORDER_NUMBER
                                       AND SH.BIZ_SRC_BILL_TYPE_CODE = PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
                                       AND SH.FUND_CHECK_MODE='ORDER'
                                       AND EXISTS (SELECT 1 FROM  CIMS.T_AR_MPAY_STREAM M WHERE  M.ENTITY_ID =SH.ENTITY_ID  AND  M.OUT_TRADE_NO = SH.SYS_SOURCE_ORDER_NUM ) ) */
                                   ORDER BY RWO.AGE_DATE ASC, RWO.ERP_OU_ID ASC)
                   LOOP
                     --回款临时表【有数据】
                     IF(V_COUNT_AR > 0) THEN
                        SELECT DECODE(UPPER(V_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF), PKG_AR_WRITE_OFF.V_YES,
                                      'RWO.SALES_MAIN_TYPE_CODE', ''''||V_AR_SALE_MAIN_TYPE.DEFAULT_SALE_MAIN_TYPE_ID||'''')
                               INTO V_DEFAULT_SALE_MAIN_TYPE_FIELD FROM DUAL;
                        SELECT DECODE(UPPER(V_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF), PKG_AR_WRITE_OFF.V_YES,
                                      ROW_REDIRECT.SALES_MAIN_TYPE_CODE, V_AR_SALE_MAIN_TYPE.DEFAULT_SALE_MAIN_TYPE_ID)
                               INTO V_DEFAULT_SALE_MAIN_TYPE_VALUE FROM DUAL;
                        V_DYNAMIC_SQL := 'SELECT RWO.* FROM T_AR_RECIEPT_WRITE_OFF RWO '
                                        ||'WHERE '||V_DEFAULT_SALE_MAIN_TYPE_FIELD||' = '''||V_DEFAULT_SALE_MAIN_TYPE_VALUE||''''
                                        ||' AND RWO.WRITE_OFF_AMOUNT2 > 0 AND RWO.CUSTOMER_ID = '||ROW_REDIRECT.CUSTOMER_ID
                                        ||' AND RWO.ACCOUNT_ID = '||ROW_REDIRECT.ACCOUNT_ID
                                        ||' AND RWO.ERP_OU_ID = '||ROW_REDIRECT.ERP_OU_ID
                                        ||' AND RWO.ENTITY_ID = '||ROW_REDIRECT.ENTITY_ID
                                        ||' ORDER BY  RWO.AGE_DATE ASC';
                        --dbms_output.put_line(V_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF||'.同OU V_DYNAMIC_SQL : '||V_DYNAMIC_SQL);
                        --回款临时表游标[B] 同OU 核销
                        OPEN V_DYNAMIC_CURSOR FOR V_DYNAMIC_SQL;
                        LOOP
                          FETCH V_DYNAMIC_CURSOR INTO ROW_RECIEPT;
                          EXIT WHEN V_DYNAMIC_CURSOR%NOTFOUND;
                          BEGIN
                            -- 插入核销关系。核销金额 LEAST(ROW_REDIRECT.WRITE_OFF_AMOUNT2, ROW_RECIEPT.WRITE_OFF_AMOUNT2)
                            INSERT INTO T_SO_ORDER_RECEIPT (
                                  ORDER_RECEIPT_ID                --核销ID
                                 ,CASH_RECEIPT_ID                 --收款单据ID
                                 ,CASH_RECEIPT_LINES_ID           --收款单据行ID
                                 ,RECEIPT_NUMBER                  --收款单据号
                                 ,SO_HEAD_ID                      --财务单据ID
                                 ,SO_HEAD_LINES_ID                -- 财务单据行ID
                                 ,ORDER_NUMBER                    --财务单据号
                                 ,RECEIPT_TYPE                    --回款单据类型
                                 ,ORDER_TYPE                      --应收单据类型
                                 ,AMOUNT                          --金额
                                 ,MATCH_DATE                      --核销日期
                                 ,ORDER_DATE                      --应收单据日期
                                 ,RECEIPT_DATE                    --回款单据日期
                                 ,CUSROMER_NAME                   --客户名称
                                 ,CUSROMER_CODE                   --客户编码
                                 ,ENTITY_ID                       --主体ID
                                 ,SALES_MAIN_TYPE_ID              --营销大类ID
                                 ,SALES_MAIN_TYPE_CODE            --营销大类编码
                                 ,SALES_MAIN_TYPE_NAME            --营销大类名称
                                 ,TO_ERP_FLAG                     --是否引入ERP    Y:已引入ERP N:未引入ERP C:不引入ERP
                                 ,REMARK                          -- 备注
                                 ,ORDER_ERP_OU_ID                 --应收ERP OU ID
                                 ,RECEIPT_ERP_OU_ID               --回款ERP OU ID
                                 ,LAST_UPDATE_DATE
                               ) VALUES (
                                  S_SO_ORDER_RECEIPT.NEXTVAL          --序列
                                  ,ROW_RECIEPT.ORDER_ID               --退货单ORDER_ID（回款）[收款单据ID]
                                  ,ROW_RECIEPT.ORDER_LINES_ID         --收款单据行ID
                                  ,ROW_RECIEPT.ORDER_NUMBER           --收款单据号
                                  ,ROW_REDIRECT.ORDER_ID              --财务单据ID
                                  ,ROW_REDIRECT.ORDER_LINES_ID        -- 应收单据行ID
                                  ,ROW_REDIRECT.ORDER_NUMBER          --财务单据号
                                  ,ROW_RECIEPT.SO_ORDER_TYPE          --回款单据类型
                                  ,ROW_REDIRECT.SO_ORDER_TYPE         --应收单据类型
                                  ,LEAST(ROW_REDIRECT.WRITE_OFF_AMOUNT2, ROW_RECIEPT.WRITE_OFF_AMOUNT2) --核销金额
                                  ,CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE --核销日期
                                  ,ROW_REDIRECT.ORDER_DATE            --应收单据日期
                                  ,ROW_RECIEPT.ORDER_DATE             --回款单据日期
                                  ,ROW_REDIRECT.CUSTOMER_NAME         --客户名称
                                  ,ROW_REDIRECT.CUSTOMER_CODE         --客户编码
                                  ,ROW_REDIRECT.ENTITY_ID             --主体ID
                                  ,(SELECT DECODE(UPPER(V_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF), PKG_AR_WRITE_OFF.V_YES, ROW_RECIEPT.SALES_MAIN_TYPE_ID, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_ID) FROM DUAL)--营销大类ID
                                  ,(SELECT DECODE(UPPER(V_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF), PKG_AR_WRITE_OFF.V_YES, ROW_RECIEPT.SALES_MAIN_TYPE_CODE, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE) FROM DUAL)--营销大类编码
                                  ,(SELECT DECODE(UPPER(V_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF), PKG_AR_WRITE_OFF.V_YES, ROW_RECIEPT.SALES_MAIN_TYPE_NAME, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_NAME) FROM DUAL)--营销大类名称
                                  ,PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N
                                  ,'同OU、'||DECODE(UPPER(V_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF), PKG_AR_WRITE_OFF.V_YES, '区分营销大类', '不区分营销大类')||'正常核销'
                                  ,ROW_REDIRECT.ERP_OU_ID
                                  ,ROW_RECIEPT.ERP_OU_ID
                                  ,SYSDATE
                             );
                            -- 应收 > 回款。回款完全核销
                            IF ROW_REDIRECT.WRITE_OFF_AMOUNT2 > ROW_RECIEPT.WRITE_OFF_AMOUNT2 THEN
                              V_MATCH_AMOUNT := ROW_RECIEPT.WRITE_OFF_AMOUNT2;
                              -- 更新应收的核销状态
                            --  IF (ROW_REDIRECT.SO_ORDER_TYPE = '1') THEN -- 应收为到款单
                                --  UPDATE T_AR_CASH_RECEIPT_HEADERS T
                                  --   SET T.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, T.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                                  -- WHERE T.CASH_RECEIPT_CODE = ROW_REDIRECT.ORDER_NUMBER;
                            --  ELSE -- 应收为销售单
                                --  UPDATE T_SO_HEADER T
                                --     SET T.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, T.APPLIED_DATE = SYSDATE
                                 --  WHERE T.SO_NUM = ROW_REDIRECT.ORDER_NUMBER;
                           --   END IF;
                              -- 更新回款的核销状态
                            --  IF (ROW_RECIEPT.SO_ORDER_TYPE = '1') THEN -- 回款为到款单
                                --  UPDATE T_AR_CASH_RECEIPT_HEADERS T
                                 --    SET T.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, T.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                                 --  WHERE T.CASH_RECEIPT_CODE = ROW_RECIEPT.ORDER_NUMBER;
                            --  ELSE -- 回款为销售单
                                 -- UPDATE T_SO_HEADER T
                                 --    SET T.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, T.APPLIED_DATE = SYSDATE
                                 --  WHERE T.SO_NUM = ROW_RECIEPT.ORDER_NUMBER;
                            --  END IF;
                              -- 更新应收临时表的核销金额和未核销金额
                              UPDATE T_AR_REDIRECT_WRITE_OFF TR
                                     SET TR.WRITE_OFF_AMOUNT = ROW_REDIRECT.WRITE_OFF_AMOUNT + V_MATCH_AMOUNT,
                                     TR.WRITE_OFF_AMOUNT2 = ROW_REDIRECT.WRITE_OFF_AMOUNT2 - V_MATCH_AMOUNT,
                                     TR.USED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART --部分核销
                              WHERE TR.REDIRECT_WRITE_OFF_ID = ROW_REDIRECT.REDIRECT_WRITE_OFF_ID;
                              -- 删除回款临时表的数据
                              DELETE FROM T_AR_RECIEPT_WRITE_OFF TW WHERE TW.WRITE_OFF_ID = ROW_RECIEPT.WRITE_OFF_ID;
                            ELSIF ROW_REDIRECT.WRITE_OFF_AMOUNT2 = ROW_RECIEPT.WRITE_OFF_AMOUNT2 THEN-- 应收 = 回款。应收、回款完全核销
                              V_MATCH_AMOUNT := ROW_RECIEPT.WRITE_OFF_AMOUNT2;
                              -- 更新应收的核销状态
                            --  IF (ROW_REDIRECT.SO_ORDER_TYPE = '1') THEN -- 应收为到款单
                                --  UPDATE T_AR_CASH_RECEIPT_HEADERS T
                                 --    SET T.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, T.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                                  -- WHERE T.CASH_RECEIPT_CODE = ROW_REDIRECT.ORDER_NUMBER;
                           --   ELSE -- 应收为销售单
                                 -- UPDATE T_SO_HEADER T
                                 --    SET T.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, T.APPLIED_DATE = SYSDATE
                                 --  WHERE T.SO_NUM = ROW_REDIRECT.ORDER_NUMBER;
                            --  END IF;
                              -- 更新回款的核销状态
                            --  IF (ROW_RECIEPT.SO_ORDER_TYPE = '1') THEN -- 回款为到款单
                                --  UPDATE T_AR_CASH_RECEIPT_HEADERS T
                                 --    SET T.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, T.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                                 --  WHERE T.CASH_RECEIPT_CODE = ROW_RECIEPT.ORDER_NUMBER;
                           --   ELSE -- 回款为销售单
                               --   UPDATE T_SO_HEADER T
                                --     SET T.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, T.APPLIED_DATE = SYSDATE
                                --   WHERE T.SO_NUM = ROW_RECIEPT.ORDER_NUMBER;
                           --   END IF;
                              -- 删除应收临时表的数据
                              DELETE FROM T_AR_REDIRECT_WRITE_OFF TW WHERE TW.REDIRECT_WRITE_OFF_ID = ROW_REDIRECT.REDIRECT_WRITE_OFF_ID;
                              -- 删除回款临时表的数据
                              DELETE FROM T_AR_RECIEPT_WRITE_OFF TW WHERE TW.WRITE_OFF_ID = ROW_RECIEPT.WRITE_OFF_ID;
                            ELSIF ROW_REDIRECT.WRITE_OFF_AMOUNT2 < ROW_RECIEPT.WRITE_OFF_AMOUNT2 THEN-- 应收 < 回款。应收完全核销
                              V_MATCH_AMOUNT := ROW_REDIRECT.WRITE_OFF_AMOUNT2;
                              -- 更新应收的核销状态
                            --  IF (ROW_REDIRECT.SO_ORDER_TYPE = '1') THEN -- 应收为到款单
                                --  UPDATE T_AR_CASH_RECEIPT_HEADERS T
                                --     SET T.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, T.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                                 --  WHERE T.CASH_RECEIPT_CODE = ROW_REDIRECT.ORDER_NUMBER;
                           --   ELSE -- 应收为销售单
                               --  UPDATE T_SO_HEADER T
                               --      SET T.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, T.APPLIED_DATE = SYSDATE
                               --    WHERE T.SO_NUM = ROW_REDIRECT.ORDER_NUMBER;
                          --    END IF;
                              -- 更新回款的核销状态
                            --  IF (ROW_RECIEPT.SO_ORDER_TYPE = '1') THEN -- 回款为到款单
                              --    UPDATE T_AR_CASH_RECEIPT_HEADERS T
                               --      SET T.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, T.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                               --    WHERE T.CASH_RECEIPT_CODE = ROW_RECIEPT.ORDER_NUMBER;
                             -- ELSE -- 回款为销售单
                               --   UPDATE T_SO_HEADER T
                                --     SET T.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, T.APPLIED_DATE = SYSDATE
                                --   WHERE T.SO_NUM = ROW_RECIEPT.ORDER_NUMBER;
                             -- END IF;
                              -- 删除应收临时表的核销金额和未核销金额
                              DELETE FROM T_AR_REDIRECT_WRITE_OFF TW WHERE TW.REDIRECT_WRITE_OFF_ID = ROW_REDIRECT.REDIRECT_WRITE_OFF_ID;
                              -- 更新回款临时表的数据
                              UPDATE T_AR_RECIEPT_WRITE_OFF TR
                                     SET TR.WRITE_OFF_AMOUNT = ROW_RECIEPT.WRITE_OFF_AMOUNT + V_MATCH_AMOUNT,
                                     TR.WRITE_OFF_AMOUNT2 = ROW_RECIEPT.WRITE_OFF_AMOUNT2 - V_MATCH_AMOUNT,
                                     TR.USED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART --部分核销
                              WHERE TR.WRITE_OFF_ID = ROW_RECIEPT.WRITE_OFF_ID;
                            END IF;
                            COMMIT;
                            GOTO FLAG_SO;
                            /**IF ROW_REDIRECT.WRITE_OFF_AMOUNT2 > ROW_RECIEPT.WRITE_OFF_AMOUNT2 THEN --应收 > 回款。回款完全核销
                              GOTO FLAG_AR;
                            ELSIF ROW_REDIRECT.WRITE_OFF_AMOUNT2 = ROW_RECIEPT.WRITE_OFF_AMOUNT2 THEN-- 应收 = 回款。应收、回款完全核销
                              GOTO FLAG_SO;
                            ELSIF ROW_REDIRECT.WRITE_OFF_AMOUNT2 < ROW_RECIEPT.WRITE_OFF_AMOUNT2 THEN-- 应收 < 回款。应收完全核销
                              GOTO FLAG_SO;
                            END IF;**/
                          EXCEPTION WHEN OTHERS THEN
                            ROLLBACK;
                            P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                            P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFFS_MAIN', SQLCODE,
                                '核销(是否区分营销大类:'||UPPER(V_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF)||')出错！错误日志：应收单据号：'||ROW_REDIRECT.ORDER_NUMBER||
                                '，回款单据号：'||ROW_RECIEPT.ORDER_NUMBER||
                                '，核销金额：'||V_MATCH_AMOUNT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                            GOTO FLAG_SO;
                          END;
                        END LOOP;
                        CLOSE V_DYNAMIC_CURSOR;
                  
                  IF ROW_REDIRECT.CUSTOMER_CODE NOT LIKE 'E%' AND ROW_REDIRECT.ENTITY_ID = 10 THEN --只有家用做跨OU核销
                        -- 不同OU 且 收款单数据 核销(** 跨主体收款单不能形成跨主体核销关系；单据的账户、客户必须有效才能生成跨主体单据，否则，无法通过跨主体确认校验)
                        V_DYNAMIC_SQL := 'SELECT RWO.* FROM T_AR_RECIEPT_WRITE_OFF RWO'
                                        ||' WHERE '||V_DEFAULT_SALE_MAIN_TYPE_FIELD||' = '''||V_DEFAULT_SALE_MAIN_TYPE_VALUE||''''
                                        ||' AND EXISTS (SELECT * FROM CIMS.V_AR_WRITE_OFF_CUST_ACCOUNT CA'
                                        ||' WHERE CA.ACCOUNT_ID = RWO.ACCOUNT_ID AND CA.CUSTOMER_ID = RWO.CUSTOMER_ID AND CA.ENTITY_ID = RWO.ENTITY_ID'
                                        ||' AND CA.ACCOUNT_STATUS = ''1'' AND CA.ACTIVE_FLAG = ''Active'')'
                                        ||' AND PKG_AR_WRITE_OFF.F_AR_IS_CROSS_OU_BILL('''||ROW_REDIRECT.ORDER_NUMBER||''') = '''||PKG_AR_WRITE_OFF.V_NO||''''
                                        ||' AND PKG_AR_WRITE_OFF.F_AR_IS_CROSS_OU_BILL(RWO.ORDER_NUMBER) = '''||PKG_AR_WRITE_OFF.V_NO||''''
                                        ||' AND RWO.WRITE_OFF_AMOUNT2 > 0 AND RWO.CUSTOMER_ID = '||ROW_REDIRECT.CUSTOMER_ID
        --                                ||' AND RWO.SALES_CENTER_ID = '||ROW_REDIRECT.SALES_CENTER_ID
                                        ||' AND RWO.ACCOUNT_ID = '||ROW_REDIRECT.ACCOUNT_ID
                                        ||' AND RWO.ERP_OU_ID <> '||ROW_REDIRECT.ERP_OU_ID
                                        ||' AND RWO.ENTITY_ID = '||ROW_REDIRECT.ENTITY_ID
                                        ||' AND RWO.SO_ORDER_TYPE = ''1'''
                                        ||' ORDER BY RWO.AGE_DATE ASC,RWO.ERP_OU_ID ASC';
        --                dbms_output.put_line(UPPER(V_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF)||'.不同OU V_DYNAMIC_SQL : '||V_DYNAMIC_SQL);
                        OPEN V_DYNAMIC_CURSOR FOR V_DYNAMIC_SQL;
                        LOOP
                          FETCH V_DYNAMIC_CURSOR INTO ROW_RECIEPT_DIFF_OU;
                          EXIT WHEN V_DYNAMIC_CURSOR%NOTFOUND;
                          BEGIN
                            -- 插入核销关系。核销金额 LEAST(ROW_REDIRECT.WRITE_OFF_AMOUNT2, ROW_RECIEPT_DIFF_OU.WRITE_OFF_AMOUNT2)
                            INSERT INTO T_SO_ORDER_RECEIPT (
                                  ORDER_RECEIPT_ID                --核销ID
                                 ,CASH_RECEIPT_ID                 --收款单据ID
                                 ,CASH_RECEIPT_LINES_ID           --收款单据行ID
                                 ,RECEIPT_NUMBER                  --收款单据号
                                 ,SO_HEAD_ID                      --财务单据ID
                                 ,SO_HEAD_LINES_ID                -- 财务单据行ID
                                 ,ORDER_NUMBER                    --财务单据号
                                 ,RECEIPT_TYPE                    --回款单据类型
                                 ,ORDER_TYPE                      --应收单据类型
                                 ,AMOUNT                          --金额
                                 ,MATCH_DATE                      --核销日期
                                 ,ORDER_DATE                      --应收单据日期
                                 ,RECEIPT_DATE                    --回款单据日期
                                 ,CUSROMER_NAME                   --客户名称
                                 ,CUSROMER_CODE                   --客户编码
                                 ,ENTITY_ID                       --主体ID
                                 ,SALES_MAIN_TYPE_ID              --营销大类ID
                                 ,SALES_MAIN_TYPE_CODE            --营销大类编码
                                 ,SALES_MAIN_TYPE_NAME            --营销大类名称
                                 ,TO_ERP_FLAG                     --是否引入ERP    Y:已引入ERP N:未引入ERP C:不引入ERP
                                 ,REMARK                          -- 备注
                                 ,ORDER_ERP_OU_ID                 --应收ERP OU ID
                                 ,RECEIPT_ERP_OU_ID               --回款ERP OU ID
                                 ,LAST_UPDATE_DATE
                               ) VALUES (
                                  S_SO_ORDER_RECEIPT.NEXTVAL          --序列
                                  ,ROW_RECIEPT_DIFF_OU.ORDER_ID               --退货单ORDER_ID（回款）[收款单据ID]
                                  ,ROW_RECIEPT_DIFF_OU.ORDER_LINES_ID         --收款单据行ID
                                  ,ROW_RECIEPT_DIFF_OU.ORDER_NUMBER           --收款单据号
                                  ,ROW_REDIRECT.ORDER_ID              --财务单据ID
                                  ,ROW_REDIRECT.ORDER_LINES_ID        -- 应收单据行ID
                                  ,ROW_REDIRECT.ORDER_NUMBER          --财务单据号
                                  ,ROW_RECIEPT_DIFF_OU.SO_ORDER_TYPE          --回款单据类型
                                  ,ROW_REDIRECT.SO_ORDER_TYPE         --应收单据类型
                                  ,LEAST(ROW_REDIRECT.WRITE_OFF_AMOUNT2, ROW_RECIEPT_DIFF_OU.WRITE_OFF_AMOUNT2) --核销金额
                                  ,CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE --核销日期
                                  ,ROW_REDIRECT.ORDER_DATE            --应收单据日期
                                  ,ROW_RECIEPT_DIFF_OU.ORDER_DATE             --回款单据日期
                                  ,ROW_REDIRECT.CUSTOMER_NAME         --客户名称
                                  ,ROW_REDIRECT.CUSTOMER_CODE         --客户编码
                                  ,ROW_REDIRECT.ENTITY_ID             --主体ID
                                  ,(SELECT DECODE(UPPER(V_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF), PKG_AR_WRITE_OFF.V_YES, ROW_RECIEPT_DIFF_OU.SALES_MAIN_TYPE_ID, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_ID) FROM DUAL)--营销大类ID
                                  ,(SELECT DECODE(UPPER(V_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF), PKG_AR_WRITE_OFF.V_YES, ROW_RECIEPT_DIFF_OU.SALES_MAIN_TYPE_CODE, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE) FROM DUAL)--营销大类编码
                                  ,(SELECT DECODE(UPPER(V_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF), PKG_AR_WRITE_OFF.V_YES, ROW_RECIEPT_DIFF_OU.SALES_MAIN_TYPE_NAME, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_NAME) FROM DUAL)--营销大类名称
                                  ,PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C --不同OU核销，跨主体单据
                                  ,'不同OU、'||DECODE(UPPER(V_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF), PKG_AR_WRITE_OFF.V_YES, '区分营销大类', '不区分营销大类')||'核销，跨主体核销关系'
                                  ,ROW_REDIRECT.ERP_OU_ID
                                  ,ROW_RECIEPT_DIFF_OU.ERP_OU_ID
                                  ,SYSDATE
                             );
                            -- 应收 > 回款。回款完全核销
                            IF ROW_REDIRECT.WRITE_OFF_AMOUNT2 > ROW_RECIEPT_DIFF_OU.WRITE_OFF_AMOUNT2 THEN
                              V_MATCH_AMOUNT := ROW_RECIEPT_DIFF_OU.WRITE_OFF_AMOUNT2;
                              -- 更新应收的核销状态
                           --   IF (ROW_REDIRECT.SO_ORDER_TYPE = '1') THEN -- 应收为到款单
                               --   UPDATE T_AR_CASH_RECEIPT_HEADERS T
                                 --    SET T.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, T.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                                --   WHERE T.CASH_RECEIPT_CODE = ROW_REDIRECT.ORDER_NUMBER;
                            --  ELSE -- 应收为销售单
                                --  UPDATE T_SO_HEADER T
                                --     SET T.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, T.APPLIED_DATE = SYSDATE
                                --   WHERE T.SO_NUM = ROW_REDIRECT.ORDER_NUMBER;
                            --  END IF;
                              -- 更新回款的核销状态
                           --   IF (ROW_RECIEPT_DIFF_OU.SO_ORDER_TYPE = '1') THEN -- 回款为到款单
                                --  UPDATE T_AR_CASH_RECEIPT_HEADERS T
                                --     SET T.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, T.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                                --   WHERE T.CASH_RECEIPT_CODE = ROW_RECIEPT_DIFF_OU.ORDER_NUMBER;
                              --ELSE -- 回款为销售单
                                --  UPDATE T_SO_HEADER T
                                --     SET T.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, T.APPLIED_DATE = SYSDATE
                                --   WHERE T.SO_NUM = ROW_RECIEPT_DIFF_OU.ORDER_NUMBER;
                            --  END IF;
                              -- 更新应收临时表的核销金额和未核销金额
                              UPDATE T_AR_REDIRECT_WRITE_OFF TR
                                     SET TR.WRITE_OFF_AMOUNT = ROW_REDIRECT.WRITE_OFF_AMOUNT + V_MATCH_AMOUNT,
                                     TR.WRITE_OFF_AMOUNT2 = ROW_REDIRECT.WRITE_OFF_AMOUNT2 - V_MATCH_AMOUNT,
                                     TR.USED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART --部分核销
                              WHERE TR.REDIRECT_WRITE_OFF_ID = ROW_REDIRECT.REDIRECT_WRITE_OFF_ID;
                              -- 删除回款临时表的数据
                              DELETE FROM T_AR_RECIEPT_WRITE_OFF TW WHERE TW.WRITE_OFF_ID = ROW_RECIEPT_DIFF_OU.WRITE_OFF_ID;
                            ELSIF ROW_REDIRECT.WRITE_OFF_AMOUNT2 = ROW_RECIEPT_DIFF_OU.WRITE_OFF_AMOUNT2 THEN-- 应收 = 回款。应收、回款完全核销
                              V_MATCH_AMOUNT := ROW_RECIEPT_DIFF_OU.WRITE_OFF_AMOUNT2;
                              -- 更新应收的核销状态
                          --    IF (ROW_REDIRECT.SO_ORDER_TYPE = '1') THEN -- 应收为到款单
                                --  UPDATE T_AR_CASH_RECEIPT_HEADERS T
                                   --  SET T.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, T.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                                 --  WHERE T.CASH_RECEIPT_CODE = ROW_REDIRECT.ORDER_NUMBER;
                          --    ELSE -- 应收为销售单
                                 -- UPDATE T_SO_HEADER T
                                  --   SET T.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, T.APPLIED_DATE = SYSDATE
                                --   WHERE T.SO_NUM = ROW_REDIRECT.ORDER_NUMBER;
                           --   END IF;
                              -- 更新回款的核销状态
                           --   IF (ROW_RECIEPT_DIFF_OU.SO_ORDER_TYPE = '1') THEN -- 回款为到款单
                                 -- UPDATE T_AR_CASH_RECEIPT_HEADERS T
                                  --   SET T.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, T.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                                 --  WHERE T.CASH_RECEIPT_CODE = ROW_RECIEPT_DIFF_OU.ORDER_NUMBER;
                           --   ELSE -- 回款为销售单
                                 -- UPDATE T_SO_HEADER T
                                  --   SET T.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, T.APPLIED_DATE = SYSDATE
                                 --  WHERE T.SO_NUM = ROW_RECIEPT_DIFF_OU.ORDER_NUMBER;
                           --   END IF;
                              -- 删除应收临时表的数据
                              DELETE FROM T_AR_REDIRECT_WRITE_OFF TW WHERE TW.REDIRECT_WRITE_OFF_ID = ROW_REDIRECT.REDIRECT_WRITE_OFF_ID;
                              -- 删除回款临时表的数据
                              DELETE FROM T_AR_RECIEPT_WRITE_OFF TW WHERE TW.WRITE_OFF_ID = ROW_RECIEPT_DIFF_OU.WRITE_OFF_ID;
                            ELSIF ROW_REDIRECT.WRITE_OFF_AMOUNT2 < ROW_RECIEPT_DIFF_OU.WRITE_OFF_AMOUNT2 THEN-- 应收 < 回款。应收完全核销
                              V_MATCH_AMOUNT := ROW_REDIRECT.WRITE_OFF_AMOUNT2;
                              -- 更新应收的核销状态
                           --   IF (ROW_REDIRECT.SO_ORDER_TYPE = '1') THEN -- 应收为到款单
                                 -- UPDATE T_AR_CASH_RECEIPT_HEADERS T
                                --     SET T.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, T.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                                 --  WHERE T.CASH_RECEIPT_CODE = ROW_REDIRECT.ORDER_NUMBER;
                          --    ELSE -- 应收为销售单
                               --   UPDATE T_SO_HEADER T
                                --     SET T.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, T.APPLIED_DATE = SYSDATE
                                --   WHERE T.SO_NUM = ROW_REDIRECT.ORDER_NUMBER;
                          --    END IF;
                              -- 更新回款的核销状态
                          --    IF (ROW_RECIEPT_DIFF_OU.SO_ORDER_TYPE = '1') THEN -- 回款为到款单
                               --   UPDATE T_AR_CASH_RECEIPT_HEADERS T
                                --     SET T.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, T.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                                --   WHERE T.CASH_RECEIPT_CODE = ROW_RECIEPT_DIFF_OU.ORDER_NUMBER;
                          --    ELSE -- 回款为销售单
                               --   UPDATE T_SO_HEADER T
                               --      SET T.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, T.APPLIED_DATE = SYSDATE
                               --   WHERE T.SO_NUM = ROW_RECIEPT_DIFF_OU.ORDER_NUMBER;
                           --   END IF;
                              -- 删除应收临时表的核销金额和未核销金额
                              DELETE FROM T_AR_REDIRECT_WRITE_OFF TW WHERE TW.REDIRECT_WRITE_OFF_ID = ROW_REDIRECT.REDIRECT_WRITE_OFF_ID;
                              -- 更新回款临时表的数据
                              UPDATE T_AR_RECIEPT_WRITE_OFF TR
                                     SET TR.WRITE_OFF_AMOUNT = ROW_RECIEPT_DIFF_OU.WRITE_OFF_AMOUNT + V_MATCH_AMOUNT,
                                     TR.WRITE_OFF_AMOUNT2 = ROW_RECIEPT_DIFF_OU.WRITE_OFF_AMOUNT2 - V_MATCH_AMOUNT,
                                     TR.USED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART --部分核销
                              WHERE TR.WRITE_OFF_ID = ROW_RECIEPT_DIFF_OU.WRITE_OFF_ID;
                            END IF;
                            COMMIT;
                            GOTO FLAG_SO;
                            /**IF ROW_REDIRECT.WRITE_OFF_AMOUNT2 > ROW_RECIEPT_DIFF_OU.WRITE_OFF_AMOUNT2 THEN --应收 > 回款。回款完全核销
                              GOTO FLAG_AR;
                            ELSIF ROW_REDIRECT.WRITE_OFF_AMOUNT2 = ROW_RECIEPT_DIFF_OU.WRITE_OFF_AMOUNT2 THEN-- 应收 = 回款。应收、回款完全核销
                              GOTO FLAG_SO;
                            ELSIF ROW_REDIRECT.WRITE_OFF_AMOUNT2 < ROW_RECIEPT_DIFF_OU.WRITE_OFF_AMOUNT2 THEN-- 应收 < 回款。应收完全核销
                              GOTO FLAG_SO;
                            END IF;**/
                          EXCEPTION WHEN OTHERS THEN
                            ROLLBACK;
                            P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                            P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFFS_MAIN', SQLCODE,
                                '不同OU核销(是否区分营销大类:'||UPPER(V_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF)||')出错！错误日志：应收单据号：'||ROW_REDIRECT.ORDER_NUMBER||
                                '，回款单据号：'||ROW_RECIEPT_DIFF_OU.ORDER_NUMBER||
                                '，核销金额：'||V_MATCH_AMOUNT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                            GOTO FLAG_SO;
                          END;
                        END LOOP;
                        CLOSE V_DYNAMIC_CURSOR;
                      END IF;  
                        
                     END IF;
                   END LOOP;
                END IF;
          END IF;        
                

        --先删除当天账龄表数据
        DELETE T_SO_ACCOUNT_AGE T
        WHERE T.MATCH_DATE = CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE
           AND t.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
           AND T.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
           AND T.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID;
        COMMIT;
        -- 插入应收账龄
        BEGIN
          INSERT INTO T_SO_ACCOUNT_AGE
             (
              ACCOUNT_AGE_ID                  --财龄ID
             ,CUSTOMER_ID                     --客户ID
             ,ORDER_MAIN_TYPE                 --单据主类型（收款单/财务单）
             ,AR_TYPE                         --应收类型（应收款：1，回款：2）
             ,SO_ORDER_TYPE                   --单据类型
             ,ORDER_ID                        --单据ID
             ,ORDER_LINES_ID                  --单据行ID
             ,ORDER_NUMBER                    --单据号
             ,ORDER_DATE                      --单据日期
             ,MATCH_DATE                      --核销日期
             ,AGE_DATE                        --账龄日期
             ,ORDER_AMOUNT                    --单据金额
             ,WRITE_OFF_AMOUNT                --核销金额
             ,WRITE_OFF_AMOUNT2               --未核销金额
             ,USED_FLAG                       --核销标志（0:全部核销；1:部分核销；2:未核销）
             ,SETTLED_FLAG                    --结算标志(0:已结算；1:未结算)
             ,CUSTOMER_CODE                   --客户编码
             ,CUSTOMER_NAME                   --客户名称
             ,ENTITY_ID                       --主体ID
             ,SALES_MAIN_TYPE_ID              --营销大类ID
             ,SALES_MAIN_TYPE_CODE            --营销大类编码
             ,SALES_MAIN_TYPE_NAME            --营销大类名称
             ,SALES_CENTER_ID                 --营销中心ID
             ,SALES_CENTER_CODE               --营销中心编码
             ,SALES_CENTER_NAME               --营销中心名称
             ,ERP_OU_ID                       --ERP_OU_ID
             ,ERP_OU_NAME                     --ERP_OU_NAME
             ,ACCOUNT_ID                      --账户ID
             ,PROTO_QUOTA                     --样机额度
             )
             SELECT
                S_SO_ACCOUNT_AGE.NEXTVAL          --序列
               ,T.CUSTOMER_ID                     --客户ID
               ,T.ORDER_MAIN_TYPE                 --单据主类型（收款单：1/财务单：2）
               ,'1'                               --应收类型（应收款：1，回款：2）
               ,T.SO_ORDER_TYPE                   --单据类型
               ,T.ORDER_ID                        --单据ID
               ,T.ORDER_LINES_ID                  --单据行ID
               ,T.ORDER_NUMBER                    --单据号
               ,TRUNC(T.ORDER_DATE, 'DD')         --单据日期
               ,TRUNC(T.MATCH_DATE, 'DD')         --核销日期
               ,TRUNC(T.AGE_DATE, 'DD')           --账龄日期
               ,T.ORDER_AMOUNT                    --单据金额
               ,T.WRITE_OFF_AMOUNT                --核销金额
               ,T.WRITE_OFF_AMOUNT2               --未核销金额
               ,T.USED_FLAG                       --核销标志（0:全部核销；1:部分核销；2:未核销）
               ,NULL                              --结算标志(0:已结算；1:未结算)[临时表忘记建结算标志这个字段]
               ,T.CUSTOMER_CODE                   --客户编码
               ,T.CUSTOMER_NAME                   --客户名称
               ,T.ENTITY_ID                       --主体ID
               ,T.SALES_MAIN_TYPE_ID              --营销大类ID
               ,T.SALES_MAIN_TYPE_CODE            --营销大类编码
               ,T.SALES_MAIN_TYPE_NAME            --营销大类名称
               ,T.SALES_CENTER_ID                 --营销中心ID
               ,T.SALES_CENTER_CODE               --营销中心编码
               ,T.SALES_CENTER_NAME               --营销中心名称
               ,T.ERP_OU_ID                       --ERP_OU_ID
               ,T.ERP_OU_NAME                     --ERP_OU_NAME
               ,T.ACCOUNT_ID                      -- 账户ID
               ,(SELECT Q.PROTO_QUOTA 
                   FROM T_AR_PROTO_QUOTA Q
                   WHERE Q.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID
                      AND Q.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
                      AND Q.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
                      AND Q.ACTIVE_FLAG='Y'
                      AND ROWNUM=1)
             FROM T_AR_REDIRECT_WRITE_OFF T
             WHERE T.WRITE_OFF_AMOUNT2 > 0
             AND T.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
             AND  T.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
             AND T.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID;
          --删除应收款临时表
          DELETE T_AR_REDIRECT_WRITE_OFF TR
          WHERE TR.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
            AND TR.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID
            AND TR.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID;
          COMMIT;
        EXCEPTION WHEN OTHERS THEN
          ROLLBACK;
          P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
          P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFFS_NEW', SQLCODE,
              '插入应收账龄出错！错误日志：主体：'||CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID||
              '，客户'||CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID||
              '，账户：'||CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID||
              '，中心：'||CUR_AUTO_WRITE_OFFS_TRAN.SALES_CENTER_ID||
              '。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
        END;
        -- 插入回款账龄
        BEGIN
           INSERT INTO T_SO_ACCOUNT_AGE (
            ACCOUNT_AGE_ID                  --财龄ID
           ,CUSTOMER_ID                     --客户ID
           ,ORDER_MAIN_TYPE                 --单据主类型（收款单/财务单）
           ,AR_TYPE                         --应收类型（应收款：1，回款：2）
           ,SO_ORDER_TYPE                   --单据类型
           ,ORDER_ID                        --单据ID
           ,ORDER_LINES_ID                  --单据行ID
           ,ORDER_NUMBER                    --单据号
           ,ORDER_DATE                      --单据日期
           ,MATCH_DATE                      --核销日期
           ,AGE_DATE                        --账龄日期
           ,ORDER_AMOUNT                    --单据金额
           ,WRITE_OFF_AMOUNT                --核销金额
           ,WRITE_OFF_AMOUNT2               --未核销金额
           ,USED_FLAG                       --核销标志（0:全部核销；1:部分核销；2:未核销）
           ,SETTLED_FLAG                    --结算标志(0:已结算；1:未结算)
           ,CUSTOMER_CODE                   --客户编码
           ,CUSTOMER_NAME                   --客户名称
           ,ENTITY_ID                       --主体ID
           ,SALES_MAIN_TYPE_ID              --营销大类ID
           ,SALES_MAIN_TYPE_CODE            --营销大类编码
           ,SALES_MAIN_TYPE_NAME            --营销大类名称
           ,SALES_CENTER_ID                 --营销中心ID
           ,SALES_CENTER_CODE               --营销中心编码
           ,SALES_CENTER_NAME               --营销中心名称
           ,ERP_OU_ID                       --ERP_OU_ID
           ,ERP_OU_NAME                     --ERP_OU_NAME
           ,ACCOUNT_ID                      --账户ID
           ,PROTO_QUOTA                     --样机额度
           )  SELECT
              S_SO_ACCOUNT_AGE.NEXTVAL          --序列
             ,T.CUSTOMER_ID                     --客户ID
             ,T.ORDER_MAIN_TYPE                 --单据主类型（收款单：1/财务单：2）
             ,'2'                               --应收类型（应收款：1，回款：2）
             ,T.SO_ORDER_TYPE                   --单据类型
             ,T.ORDER_ID                        --单据ID
             ,T.ORDER_LINES_ID                  --单据行ID
             ,T.ORDER_NUMBER                    --单据号
             ,TRUNC(T.ORDER_DATE, 'DD')         --单据日期
             ,TRUNC(T.MATCH_DATE, 'DD')         --核销日期
             ,TRUNC(T.AGE_DATE, 'DD')           --账龄日期
             ,T.ORDER_AMOUNT                    --单据金额
             ,T.WRITE_OFF_AMOUNT                --核销金额
             ,T.WRITE_OFF_AMOUNT2               --未核销金额
             ,T.USED_FLAG                       --核销标志（0:全部核销；1:部分核销；2:未核销）
             ,NULL                              --结算标志(0:已结算；1:未结算)[临时表忘记建结算标志这个字段]
             ,T.CUSTOMER_CODE                   --客户编码
             ,T.CUSTOMER_NAME                   --客户名称
             ,T.ENTITY_ID                       --主体ID

             ,T.SALES_MAIN_TYPE_ID              --营销大类ID
             ,T.SALES_MAIN_TYPE_CODE            --营销大类编码
             ,T.SALES_MAIN_TYPE_NAME            --营销大类名称

             ,T.SALES_CENTER_ID                 --营销中心ID
             ,T.SALES_CENTER_CODE               --营销中心编码
             ,T.SALES_CENTER_NAME               --营销中心名称
             ,T.ERP_OU_ID                       --ERP_OU_ID
             ,T.ERP_OU_NAME                     --ERP_OU_NAME
             ,T.ACCOUNT_ID                      --账户ID
             ,(SELECT Q.PROTO_QUOTA 
                   FROM T_AR_PROTO_QUOTA Q
                   WHERE Q.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID
                      AND Q.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
                      AND Q.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
                      AND Q.ACTIVE_FLAG='Y'
                      AND ROWNUM=1)
             FROM T_AR_RECIEPT_WRITE_OFF T
             WHERE T.WRITE_OFF_AMOUNT2 > 0
               AND T.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
               AND T.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
               AND T.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID;
            --删除回款临时表
           DELETE T_AR_RECIEPT_WRITE_OFF TR
           WHERE TR.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
              AND TR.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
              AND TR.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID;
           COMMIT;
        EXCEPTION WHEN OTHERS THEN
          ROLLBACK;
          P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
          P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFFS_MAIN', SQLCODE,
              '插入回款账龄出错！错误日志：主体：'||CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID||
              '，客户'||CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID||
            '，账户：'||CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID||
            '，中心：'||CUR_AUTO_WRITE_OFFS_TRAN.SALES_CENTER_ID||
              '。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
        END;
        --先删除当天账龄沉淀表数据(可重复执行)
        DELETE T_SO_ACCOUNT_AGE_REPORT T
        WHERE T.MATCH_DATE = CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE
           AND t.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
           AND T.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
           AND T.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID;
        COMMIT;
        -- 将账龄数据插入账龄沉淀表
        INSERT INTO T_SO_ACCOUNT_AGE_REPORT(
             ACCOUNT_AGE_ID                                --财龄ID
            ,CUSTOMER_ID                                  --客户ID
            ,ORDER_MAIN_TYPE                              --单据主类型（收款单/财务单）1代表收款单、2代表财务单
            ,AR_TYPE                                      --应收类型（应收款/回款）1代表应收款，2代表回款
            ,SO_ORDER_TYPE                                --财务单据类型
            ,ORDER_ID                                      --单据ID
            ,ORDER_LINES_ID                                --单据行ID
            ,ORDER_NUMBER                                  --单据号
            ,ORDER_DATE                                    --单据日期
            ,AGE_DATE                                      --账龄日期
            ,ORDER_AMOUNT                                  --单据金额
            ,WRITE_OFF_AMOUNT                              --核销金额
            ,USED_FLAG                                    --核销标志（0:全部核销；1:部分核销；2:未核销）
            ,SETTLED_FLAG                                 --结算标志(0:已结算；1:未结算)
            ,CUSTOMER_CODE                                --客户编码
            ,CUSTOMER_NAME                                --客户名称
            ,ENTITY_ID                                    --主体ID
            ,SALES_MAIN_TYPE_ID                            --营销大类ID
            ,SALES_MAIN_TYPE_CODE                          --营销大类编码
            ,SALES_MAIN_TYPE_NAME                          --营销大类名称
            ,MATCH_DATE                                   --核销日期
            ,ERP_OU_ID                                    --ERP_OU_ID
            ,ERP_OU_NAME                                  --ERP_OU_NAME
            ,WRITE_OFF_AMOUNT2                            --未核销金额
            ,SALES_CENTER_ID                              --营销中心ID
            ,SALES_CENTER_CODE                            --营销中心编码
            ,SALES_CENTER_NAME                            --营销中心名称
            ,ACCOUNT_ID                                   --账户ID
            ,PROTO_QUOTA                                  --样机额度
            )  SELECT
            S_SO_ACCOUNT_AGE_REPORT.NEXTVAL
            ,T.CUSTOMER_ID
            ,T.ORDER_MAIN_TYPE
            ,T.AR_TYPE
            ,T.SO_ORDER_TYPE
            ,T.ORDER_ID
            ,T.ORDER_LINES_ID
            ,T.ORDER_NUMBER
            ,T.ORDER_DATE
            ,(CASE WHEN V_PARAM_AGE_MONTH_END='N' THEN T.AGE_DATE ELSE  TRUNC(LAST_DAY(T.AGE_DATE))  END)
            ,T.ORDER_AMOUNT
            ,T.WRITE_OFF_AMOUNT
            ,T.USED_FLAG
            ,T.SETTLED_FLAG
            ,T.CUSTOMER_CODE
            ,T.CUSTOMER_NAME
            ,T.ENTITY_ID
            ,T.SALES_MAIN_TYPE_ID
            ,T.SALES_MAIN_TYPE_CODE
            ,T.SALES_MAIN_TYPE_NAME
            ,T.MATCH_DATE
            ,T.ERP_OU_ID
            ,T.ERP_OU_NAME
            ,T.WRITE_OFF_AMOUNT2
            ,T.SALES_CENTER_ID
            ,T.SALES_CENTER_CODE
            ,T.SALES_CENTER_NAME
            ,T.ACCOUNT_ID
            ,T.PROTO_QUOTA
        FROM T_SO_ACCOUNT_AGE T
        WHERE T.MATCH_DATE = CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE
              AND T.CUSTOMER_ID = CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID
              AND T.ACCOUNT_ID = CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID
              AND T.ENTITY_ID = CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID;

        -- 更新事物处理标识
        UPDATE T_AR_AUTO_WRITE_OFFS_TRAN T
          SET  T.WRITE_OFFS_FLAG = PKG_AR_WRITE_OFF.V_YES
        WHERE T.WRITE_OFFS_TRAN_ID = CUR_AUTO_WRITE_OFFS_TRAN.WRITE_OFFS_TRAN_ID;
        COMMIT;
      EXCEPTION WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
        P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFFS_MAIN', SQLCODE,
            '核销出错！错误日志：主体：'||CUR_AUTO_WRITE_OFFS_TRAN.ENTITY_ID||
            '，客户'||CUR_AUTO_WRITE_OFFS_TRAN.CUSTOMER_ID||
            '，账户：'||CUR_AUTO_WRITE_OFFS_TRAN.ACCOUNT_ID||
            '，中心：'||CUR_AUTO_WRITE_OFFS_TRAN.SALES_CENTER_ID||
            '，事物处理日期：'||TO_CHAR(CUR_AUTO_WRITE_OFFS_TRAN.TRAN_DATE, 'yyyy-MM-dd')||
            '。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
      END;
    END LOOP;
    
    insert into T_BD_ERROR_LOG(ROW_ID,ERROR_CODE,ERROR_FROM,ERROR_DATE,ERROR_DESC,CREATED_DATE)select S_BD_EEROR_LOG.NEXTVAL,'0','WRITEOFF',sysdate,IN_ENTITY_ID||IN_MOD||IN_MOD_REN||'', sysdate from DUAL;
    commit;
    P_RESULT := '核销主过程执行成功！';
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFFS_MAIN', SQLCODE,
            '核销主过程出错！错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    RETURN ;
  END;

  -- 收款冲销后，收款冲销单跟原收款单进行核销
  PROCEDURE P_AR_RECEIPT_INVOICE_WRITE_OFF
  (
    IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  ) IS
  
      V_PARAM_ENTITY_ID NUMBER;
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    V_PARAM_ENTITY_ID := IN_ENTITY_ID;
    
    FOR CUR_W IN (SELECT * FROM T_AR_WRITE_OFF T WHERE T.USED_FLAG = PKG_AR_WRITE_OFF.V_NO and T.ENTITY_ID = V_PARAM_ENTITY_ID ORDER BY T.ORDER_DATE) LOOP
      BEGIN
        -- 取消原单的核销关系(OLD_ORDER_CODE为蓝单的单据号，ORDER_CODE为冲销单单据号)
        PKG_AR_WRITE_OFF.P_CANCEL_ORDER_RECEIPT(CUR_W.ORDER_CODE, '1','ALL', '#收款冲销', PKG_AR_WRITE_OFF.V_YES, P_RESULT, P_MESSAGE);
        PKG_AR_WRITE_OFF.P_CANCEL_ORDER_RECEIPT(CUR_W.OLD_ORDER_CODE, '1','ALL', '#收款冲销', PKG_AR_WRITE_OFF.V_YES, P_RESULT, P_MESSAGE);
        IF P_MESSAGE <> PKG_AR_WRITE_OFF.V_SUCCESS THEN
          RAISE PKG_AR_WRITE_OFF.V_BIZ_EXCEPTION;
        ELSE
          -- 生成原单和冲销单的核销关系
          PKG_AR_WRITE_OFF.P_CREATE_ORDER_RECEIPT(CUR_W.OLD_ORDER_CODE, '1', CUR_W.ORDER_CODE, TRUNC(CUR_W.ORDER_DATE, 'DD'), PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C, '#收款冲销', P_RESULT, P_MESSAGE);
          IF P_MESSAGE <> PKG_AR_WRITE_OFF.V_SUCCESS THEN
            RAISE PKG_AR_WRITE_OFF.V_BIZ_EXCEPTION;
          ELSE
            UPDATE CIMS.T_AR_WRITE_OFF T SET T.USED_FLAG = PKG_AR_WRITE_OFF.V_YES WHERE T.WRITE_OFF_ID = CUR_W.WRITE_OFF_ID;
          END IF;
        END IF;
        COMMIT;
      EXCEPTION
         WHEN PKG_AR_WRITE_OFF.V_BIZ_EXCEPTION THEN
          ROLLBACK;
          P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
          P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_RECEIPT_INVOICE_WRITE_OFF', SQLCODE,
                  '收款和收款核销优先核销出错！原单据号：'||CUR_W.ORDER_CODE||
                  '、冲销单号：'||CUR_W.OLD_ORDER_CODE||'。错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
        WHEN OTHERS THEN
          ROLLBACK;
          P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
          P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_RECEIPT_INVOICE_WRITE_OFF', SQLCODE,
                  '收款和收款核销优先核销出错！原单据号：'||CUR_W.ORDER_CODE||
                  '、冲销单号：'||CUR_W.OLD_ORDER_CODE||'。错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
      END;
    END LOOP;
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_RECEIPT_INVOICE_WRITE_OFF', SQLCODE,
            '收款和收款核销优先核销出错！错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    RETURN ;
  END;

  -- 退款申请进行撤回修改、撤回作废、GTMS已驳回
  PROCEDURE P_AR_CASH_STATUS
  (
       IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT      OUT VARCHAR2,
      P_MESSAGE     OUT VARCHAR2
  ) IS
       V_PARAM_ENTITY_ID NUMBER;
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    V_PARAM_ENTITY_ID := IN_ENTITY_ID;
    FOR CUR_W IN (SELECT * FROM T_AR_RECALL_STATUS T WHERE T.RECALL_FALG = PKG_AR_WRITE_OFF.V_NO AND T.ENTITY_ID = V_PARAM_ENTITY_ID   ORDER BY T.RECALL_DATE) LOOP
      BEGIN
        -- 取消原单的核销关系
        PKG_AR_WRITE_OFF.P_CANCEL_ORDER_RECEIPT(CUR_W.CASH_CODE, '1','ALL', '#退款撤回', PKG_AR_WRITE_OFF.V_YES, P_RESULT, P_MESSAGE);
        IF P_MESSAGE <> PKG_AR_WRITE_OFF.V_SUCCESS THEN
          RAISE PKG_AR_WRITE_OFF.V_BIZ_EXCEPTION;
        ELSE
          UPDATE CIMS.T_AR_RECALL_STATUS S SET S.RECALL_FALG = PKG_AR_WRITE_OFF.V_YES WHERE S.RECALL_ID = CUR_W.RECALL_ID;
        END IF;
        COMMIT;
      EXCEPTION
         WHEN PKG_AR_WRITE_OFF.V_BIZ_EXCEPTION THEN
          ROLLBACK;
          P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
          P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_CASH_STATUS', SQLCODE,
                  '款申请进行撤回修改、撤回作废、GTMS已驳回解除核销出错！单据号：'||CUR_W.CASH_CODE||'。错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
        WHEN OTHERS THEN
          ROLLBACK;
          P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
          P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_CASH_STATUS', SQLCODE,
                  '款申请进行撤回修改、撤回作废、GTMS已驳回解除核销出错！单据号：'||CUR_W.CASH_CODE||'。错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
      END;
    END LOOP;
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_CASH_STATUS', SQLCODE,
            '款申请进行撤回修改、撤回作废、GTMS已驳回解除核销出错！错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    RETURN ;
  END;

  -- 结算更改（修改折扣率）过程
  PROCEDURE P_AR_SETTLED_WRITE_OFF
  (
       IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT      OUT VARCHAR2,
      P_MESSAGE     OUT VARCHAR2
  ) IS
     V_PARAM_ENTITY_ID NUMBER;
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    V_PARAM_ENTITY_ID := IN_ENTITY_ID;
    FOR CUR_W IN (SELECT * FROM T_AR_SETTLED_WRITE_OFF T WHERE T.SETTLED_FLAG = PKG_AR_WRITE_OFF.V_NO AND T.ENTITY_ID= V_PARAM_ENTITY_ID ) LOOP
      BEGIN
        -- 取消原单的核销关系
        PKG_AR_WRITE_OFF.P_CANCEL_ORDER_RECEIPT(CUR_W.ORDER_CODE, CUR_W.ORDER_TYPE, 'ALL','#修改折扣率', PKG_AR_WRITE_OFF.V_YES, P_RESULT, P_MESSAGE);
        IF P_MESSAGE <> PKG_AR_WRITE_OFF.V_SUCCESS THEN
          RAISE PKG_AR_WRITE_OFF.V_BIZ_EXCEPTION;
        ELSE
          UPDATE CIMS.T_AR_SETTLED_WRITE_OFF WO SET WO.SETTLED_FLAG = PKG_AR_WRITE_OFF.V_YES WHERE WO.SETTLED_ID = CUR_W.SETTLED_ID;
        END IF;
        COMMIT;
      EXCEPTION
         WHEN PKG_AR_WRITE_OFF.V_BIZ_EXCEPTION THEN
          ROLLBACK;
          P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
          P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_SETTLED_WRITE_OFF', SQLCODE,
                '修改折扣率解除核销出错！单据号：'||CUR_W.ORDER_CODE||'。错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
        WHEN OTHERS THEN
          ROLLBACK;
          P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
          P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_SETTLED_WRITE_OFF', SQLCODE,
                '修改折扣率解除核销出错！单据号：'||CUR_W.ORDER_CODE||'。错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
      END;
    END LOOP;
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_SETTLED_WRITE_OFF', SQLCODE,
            '修改折扣率解除核销出错！错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    RETURN ;
  END;
  
  
  --解除未结算销售单 同账户存在已结算未核销的销售单 的核销关系   未发送ERP
  PROCEDURE P_CANCEL_NO_SETTLE_SO
  (
      IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  ) IS
      V_AMOUNT   NUMBER;
      V_AMOUNT7 NUMBER;
      V_AMOUNT30 NUMBER;
      V_AMOUNT60 NUMBER;
      V_AMOUNT90 NUMBER;
      V_SO_DATE7 DATE;
      V_SO_DATE30 DATE;
      V_SO_DATE60 DATE;
      V_SO_DATE90 DATE;
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    V_SO_DATE7 := SYSDATE-7;
    V_SO_DATE30 := SYSDATE-30;
    V_SO_DATE60 := SYSDATE-60;
    V_SO_DATE90 := SYSDATE-90;
    
       DELETE FROM T_AR_NO_SETTLE_WRITEOFF WHERE ENTITY_ID=IN_ENTITY_ID;
    
       INSERT INTO 
         T_AR_NO_SETTLE_WRITEOFF(
                 ENTITY_ID
                ,AMOUNT
                ,AMOUNT7
                ,AMOUNT30
                ,AMOUNT60
                ,AMOUNT90
                ,ACCOUNT_ID
                )
            SELECT 
                 IN_ENTITY_ID
                  ,SUM(RC.AMOUNT) AMOUNT
                  ,SUM(CASE WHEN RC.SO_DATE>=V_SO_DATE7 THEN RC.AMOUNT ELSE 0 END) AMOUNT7
                  ,SUM(CASE WHEN RC.SO_DATE<V_SO_DATE7 AND RC.SO_DATE>=V_SO_DATE30 THEN RC.AMOUNT ELSE 0 END) AMOUNT30
                  ,SUM(CASE WHEN RC.SO_DATE<V_SO_DATE30 AND RC.SO_DATE>=V_SO_DATE60  THEN  RC.AMOUNT ELSE 0 END) AMOUNT60
                  ,SUM(CASE WHEN RC.SO_DATE<V_SO_DATE60 AND RC.SO_DATE>=V_SO_DATE90  THEN  RC.AMOUNT ELSE 0 END) AMOUNT90
                  ,ACCOUNT_ID
             FROM (
                   SELECT R.AMOUNT
                         ,SH.SO_DATE
                         ,SH.ACCOUNT_ID 
                    FROM T_SO_ORDER_RECEIPT R 
                    LEFT JOIN T_SO_HEADER SH ON R.ORDER_NUMBER = SH.SO_NUM 
                    AND R.ORDER_TYPE in(PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
                    ,PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT_RED
                    )
                    WHERE
                         R.ENTITY_ID = IN_ENTITY_ID
                      AND R.TO_ERP_FLAG =  PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C 
                      AND SH.SO_STATUS = PKG_AR_WRITE_OFF.V_SO_STATUS_11 
                      AND R.RECEIPT_TYPE = '1' 
                      AND R.TMP_CASH_TURNFEE_ID IS NULL
                   UNION ALL
                    SELECT R.AMOUNT
                          ,SH.SO_DATE
                          ,SH.ACCOUNT_ID 
                    FROM T_SO_ORDER_RECEIPT R 
                    LEFT JOIN T_SO_HEADER SH ON R.ORDER_NUMBER = SH.SO_NUM 
                    AND  R.ORDER_TYPE  in(PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
                         ,PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT_RED
                    )
                    WHERE
                         R.ENTITY_ID = IN_ENTITY_ID 
                      AND R.TO_ERP_FLAG =PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N 
                      AND SH.SO_STATUS = PKG_AR_WRITE_OFF.V_SO_STATUS_11 
                      AND R.RECEIPT_TYPE = '1' 
            ) RC
            GROUP BY RC.ACCOUNT_ID;

     FOR SETTLE_BATCH_ROW IN (
          SELECT 
           SUM(H.SETTLE_AMOUNT) SETTLE_AMOUNT
          ,H.ACCOUNT_ID  
         FROM CIMS.T_SO_HEADER H 
         WHERE ENTITY_ID = IN_ENTITY_ID 
           AND BIZ_SRC_BILL_TYPE_CODE  in(PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
           ,PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT_RED
           )
           AND SETTLE_FLAG = 'Y' 
           AND H.APPLIED_FLAG IN(PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART,PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE)
           GROUP BY H.ACCOUNT_ID 
       )LOOP    
       BEGIN
          BEGIN 
             SELECT 
                SW.AMOUNT
               ,SW.AMOUNT7
               ,SW.AMOUNT30
               ,SW.Amount60
               ,SW.Amount90
               INTO
                 V_AMOUNT
                ,V_AMOUNT7
                ,V_AMOUNT30
                ,V_AMOUNT60
                ,V_AMOUNT90
              FROM 
                 T_AR_NO_SETTLE_WRITEOFF SW
              WHERE    
                  SW.ENTITY_ID = IN_ENTITY_ID
              AND SW.ACCOUNT_ID =  SETTLE_BATCH_ROW.ACCOUNT_ID;
           EXCEPTION
                WHEN NO_DATA_FOUND THEN
                   V_AMOUNT := 0;
                   V_AMOUNT7 := 0;
                   V_AMOUNT30 := 0;
                   V_AMOUNT60 := 0;
                   V_AMOUNT90 := 0;    
           END;  
           
           IF SETTLE_BATCH_ROW.SETTLE_AMOUNT>0 AND V_AMOUNT>0 THEN
                IF V_AMOUNT7 >= SETTLE_BATCH_ROW.SETTLE_AMOUNT THEN
                         update T_SO_ORDER_RECEIPT SOR 
                            set SOR.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D
                                ,REMARK =  SUBSTRB(SOR.REMARK||'#优先核销结算销售单'||'#解除核销关系', 1, 1000)
                          where SOR.ORDER_RECEIPT_ID IN(
                              SELECT R.ORDER_RECEIPT_ID 
                              FROM T_SO_ORDER_RECEIPT R 
                              LEFT JOIN T_SO_HEADER SH ON R.ORDER_NUMBER = SH.SO_NUM 
                              AND R.ORDER_TYPE  in(PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
                                                   ,PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT_RED    
                                                   )
                              WHERE
                                   R.ENTITY_ID = IN_ENTITY_ID 
                                AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C 
                                AND SH.SO_STATUS = PKG_AR_WRITE_OFF.V_SO_STATUS_11 
                                AND R.RECEIPT_TYPE = '1' 
                                AND SH.ACCOUNT_ID = SETTLE_BATCH_ROW.ACCOUNT_ID
                                AND SH.SO_DATE >=V_SO_DATE7
                                and R.TMP_CASH_TURNFEE_ID IS NULL );
                                
                              update T_SO_ORDER_RECEIPT SOR 
                                set SOR.TO_ERP_FLAG =  PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D
                                    ,REMARK =  SUBSTRB(SOR.REMARK||'#优先核销结算销售单'||'#解除核销关系', 1, 1000)
                              where SOR.ORDER_RECEIPT_ID IN(
                                  SELECT R.ORDER_RECEIPT_ID 
                                  FROM T_SO_ORDER_RECEIPT R 
                                  LEFT JOIN T_SO_HEADER SH ON R.ORDER_NUMBER = SH.SO_NUM 
                                   AND R.ORDER_TYPE  in(PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
                                                   ,PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT_RED
                                                   ) 
                                     WHERE
                                       R.ENTITY_ID = IN_ENTITY_ID 
                                    AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N 
                                    AND SH.SO_STATUS = PKG_AR_WRITE_OFF.V_SO_STATUS_11 
                                    AND R.RECEIPT_TYPE = '1'  
                                    AND SH.ACCOUNT_ID = SETTLE_BATCH_ROW.ACCOUNT_ID
                                    AND SH.SO_DATE >=V_SO_DATE7 );
                ElSIF (V_AMOUNT7 + V_AMOUNT30) >= SETTLE_BATCH_ROW.SETTLE_AMOUNT THEN                     
                            update T_SO_ORDER_RECEIPT SOR 
                            set SOR.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D
                                ,REMARK =  SUBSTRB(SOR.REMARK||'#优先核销结算销售单'||'#解除核销关系', 1, 1000)
                          where SOR.ORDER_RECEIPT_ID IN(
                              SELECT R.ORDER_RECEIPT_ID 
                              FROM T_SO_ORDER_RECEIPT R 
                              LEFT JOIN T_SO_HEADER SH ON R.ORDER_NUMBER = SH.SO_NUM 
                                                  AND R.ORDER_TYPE  in(PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
                                                   ,PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT_RED
                                                   ) 
                                     WHERE
                                   R.ENTITY_ID = IN_ENTITY_ID 
                                AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C 
                                AND SH.SO_STATUS = PKG_AR_WRITE_OFF.V_SO_STATUS_11 
                                AND R.RECEIPT_TYPE = '1' 
                                AND SH.ACCOUNT_ID = SETTLE_BATCH_ROW.ACCOUNT_ID
                                AND SH.SO_DATE >=V_SO_DATE30
                                and R.TMP_CASH_TURNFEE_ID IS NULL );
                                
                              update T_SO_ORDER_RECEIPT SOR 
                                set SOR.TO_ERP_FLAG =  PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D
                                    ,REMARK =  SUBSTRB(SOR.REMARK||'#优先核销结算销售单'||'#解除核销关系', 1, 1000)
                              where SOR.ORDER_RECEIPT_ID IN(
                                  SELECT R.ORDER_RECEIPT_ID 
                                  FROM T_SO_ORDER_RECEIPT R 
                                  LEFT JOIN T_SO_HEADER SH ON R.ORDER_NUMBER = SH.SO_NUM 
                                                    AND R.ORDER_TYPE  in(PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
                                                   ,PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT_RED
                                                   ) 
                                     WHERE
                                       R.ENTITY_ID = IN_ENTITY_ID 
                                    AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N 
                                    AND SH.SO_STATUS = PKG_AR_WRITE_OFF.V_SO_STATUS_11 
                                    AND R.RECEIPT_TYPE = '1'  
                                    AND SH.ACCOUNT_ID = SETTLE_BATCH_ROW.ACCOUNT_ID
                                    AND SH.SO_DATE >=V_SO_DATE30 );        
                                    
                ElSIF  (V_AMOUNT7 + V_AMOUNT30 + V_AMOUNT60)  >= SETTLE_BATCH_ROW.SETTLE_AMOUNT    THEN          
                         update T_SO_ORDER_RECEIPT SOR 
                            set SOR.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D
                                ,REMARK =  SUBSTRB(SOR.REMARK||'#优先核销结算销售单'||'#解除核销关系', 1, 1000)
                          where SOR.ORDER_RECEIPT_ID IN(
                              SELECT R.ORDER_RECEIPT_ID 
                              FROM T_SO_ORDER_RECEIPT R 
                              LEFT JOIN T_SO_HEADER SH ON R.ORDER_NUMBER = SH.SO_NUM 
                                                 AND R.ORDER_TYPE  in(PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
                                                   ,PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT_RED
                                                   ) 
                                     WHERE
                                   R.ENTITY_ID = IN_ENTITY_ID 
                                AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C 
                                AND SH.SO_STATUS = PKG_AR_WRITE_OFF.V_SO_STATUS_11 
                                AND R.RECEIPT_TYPE = '1' 
                                AND SH.ACCOUNT_ID = SETTLE_BATCH_ROW.ACCOUNT_ID
                                AND SH.SO_DATE >=V_SO_DATE60
                                and R.TMP_CASH_TURNFEE_ID IS NULL );
                                
                             update T_SO_ORDER_RECEIPT SOR 
                                set SOR.TO_ERP_FLAG =  PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D
                                    ,REMARK =  SUBSTRB(SOR.REMARK||'#优先核销结算销售单'||'#解除核销关系', 1, 1000)
                              where SOR.ORDER_RECEIPT_ID IN(
                                  SELECT R.ORDER_RECEIPT_ID 
                                  FROM T_SO_ORDER_RECEIPT R 
                                  LEFT JOIN T_SO_HEADER SH ON R.ORDER_NUMBER = SH.SO_NUM 
                                                      AND R.ORDER_TYPE  in(PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
                                                   ,PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT_RED
                                                   ) 
                                     WHERE
                                       R.ENTITY_ID = IN_ENTITY_ID 
                                    AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N 
                                    AND SH.SO_STATUS = PKG_AR_WRITE_OFF.V_SO_STATUS_11 
                                    AND R.RECEIPT_TYPE = '1'  
                                    AND SH.ACCOUNT_ID = SETTLE_BATCH_ROW.ACCOUNT_ID
                                    AND SH.SO_DATE >=V_SO_DATE60 )   ;
                ElSIF  (V_AMOUNT7 +V_AMOUNT30 + V_AMOUNT60 + V_AMOUNT90 )  >= SETTLE_BATCH_ROW.SETTLE_AMOUNT    THEN                       
                                    update T_SO_ORDER_RECEIPT SOR 
                            set SOR.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D
                                ,REMARK =  SUBSTRB(SOR.REMARK||'#优先核销结算销售单'||'#解除核销关系', 1, 1000)
                          where SOR.ORDER_RECEIPT_ID IN(
                              SELECT R.ORDER_RECEIPT_ID 
                              FROM T_SO_ORDER_RECEIPT R 
                              LEFT JOIN T_SO_HEADER SH ON R.ORDER_NUMBER = SH.SO_NUM 
                                                  AND R.ORDER_TYPE  in(PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
                                                   ,PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT_RED
                                                   ) 
                                     WHERE
                                   R.ENTITY_ID = IN_ENTITY_ID 
                                AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C 
                                AND SH.SO_STATUS = PKG_AR_WRITE_OFF.V_SO_STATUS_11 
                                AND R.RECEIPT_TYPE = '1' 
                                AND SH.ACCOUNT_ID = SETTLE_BATCH_ROW.ACCOUNT_ID
                                AND SH.SO_DATE >=V_SO_DATE90
                                and R.TMP_CASH_TURNFEE_ID IS NULL );
                                
                             update T_SO_ORDER_RECEIPT SOR 
                                set SOR.TO_ERP_FLAG =  PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D
                                    ,REMARK =  SUBSTRB(SOR.REMARK||'#优先核销结算销售单'||'#解除核销关系', 1, 1000)
                              where SOR.ORDER_RECEIPT_ID IN(
                                  SELECT R.ORDER_RECEIPT_ID 
                                  FROM T_SO_ORDER_RECEIPT R 
                                  LEFT JOIN T_SO_HEADER SH ON R.ORDER_NUMBER = SH.SO_NUM
                                                      AND R.ORDER_TYPE  in(PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
                                                   ,PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT_RED
                                                   ) 
                                     WHERE
                                       R.ENTITY_ID = IN_ENTITY_ID 
                                    AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N 
                                    AND SH.SO_STATUS = PKG_AR_WRITE_OFF.V_SO_STATUS_11 
                                    AND R.RECEIPT_TYPE = '1'  
                                    AND SH.ACCOUNT_ID = SETTLE_BATCH_ROW.ACCOUNT_ID
                                    AND SH.SO_DATE >=V_SO_DATE90 )  ;
                 ELSE                   
                           update T_SO_ORDER_RECEIPT SOR 
                              set SOR.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D
                                  ,REMARK =  SUBSTRB(SOR.REMARK||'#优先核销结算销售单'||'#解除核销关系', 1, 1000)
                            where SOR.ORDER_RECEIPT_ID IN(
                                SELECT R.ORDER_RECEIPT_ID 
                                FROM T_SO_ORDER_RECEIPT R 
                                LEFT JOIN T_SO_HEADER SH ON R.ORDER_NUMBER = SH.SO_NUM 
                                                   AND R.ORDER_TYPE  in(PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
                                                   ,PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT_RED
                                                   ) 
                                     WHERE
                                     R.ENTITY_ID = IN_ENTITY_ID 
                                  AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C 
                                  AND SH.SO_STATUS = PKG_AR_WRITE_OFF.V_SO_STATUS_11 
                                  AND R.RECEIPT_TYPE = '1' 
                                  and R.TMP_CASH_TURNFEE_ID IS NULL
                                  AND SH.ACCOUNT_ID = SETTLE_BATCH_ROW.ACCOUNT_ID
                             );
                           
                            update T_SO_ORDER_RECEIPT SOR 
                                set SOR.TO_ERP_FLAG =  PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D
                                    ,REMARK =  SUBSTRB(SOR.REMARK||'#优先核销结算销售单'||'#解除核销关系', 1, 1000)
                              where SOR.ORDER_RECEIPT_ID IN(
                                  SELECT R.ORDER_RECEIPT_ID 
                                  FROM T_SO_ORDER_RECEIPT R 
                                  LEFT JOIN T_SO_HEADER SH ON R.ORDER_NUMBER = SH.SO_NUM 
                                                      AND R.ORDER_TYPE  in(PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
                                                   ,PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT_RED
                                                   ) 
                                     WHERE
                                       R.ENTITY_ID = IN_ENTITY_ID 
                                    AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N 
                                    AND SH.SO_STATUS = PKG_AR_WRITE_OFF.V_SO_STATUS_11 
                                    AND R.RECEIPT_TYPE = '1' 
                                     AND SH.ACCOUNT_ID = SETTLE_BATCH_ROW.ACCOUNT_ID
                               );                         
                 END IF;
                 COMMIT;
              END IF;
        EXCEPTION WHEN OTHERS THEN
          P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
          P_RESULT := '解除核销关系出错！账户ID：'||SETTLE_BATCH_ROW.ACCOUNT_ID||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM;
          RETURN;
        END;

      END LOOP;
    /*
       update T_SO_ORDER_RECEIPT SOR 
          set SOR.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D
              ,REMARK =  SUBSTRB(SOR.REMARK||'#优先核销结算销售单'||'#解除核销关系', 1, 1000)
        where SOR.ORDER_RECEIPT_ID IN(
            SELECT R.ORDER_RECEIPT_ID 
            FROM T_SO_ORDER_RECEIPT R 
            LEFT JOIN T_SO_HEADER SH ON R.ORDER_NUMBER = SH.SO_NUM AND R.ORDER_TYPE = PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
            WHERE
                 R.ENTITY_ID = IN_ENTITY_ID 
              AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C 
              AND SH.SO_STATUS = PKG_AR_WRITE_OFF.V_SO_STATUS_11 
              AND R.RECEIPT_TYPE = '1' 
              and R.TMP_CASH_TURNFEE_ID IS NULL
              AND EXISTS ( 
                          SELECT 1 FROM CIMS.T_SO_HEADER H 
                          WHERE ENTITY_ID = IN_ENTITY_ID 
                          AND BIZ_SRC_BILL_TYPE_CODE = PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
                          AND SETTLE_FLAG = 'Y' 
                          AND H.APPLIED_FLAG IN(PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART,PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE)
                          AND SH.ACCOUNT_ID = H.ACCOUNT_ID ) 
         );
       
        update T_SO_ORDER_RECEIPT SOR 
            set SOR.TO_ERP_FLAG =  PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D
                ,REMARK =  SUBSTRB(SOR.REMARK||'#优先核销结算销售单'||'#解除核销关系', 1, 1000)
          where SOR.ORDER_RECEIPT_ID IN(
              SELECT R.ORDER_RECEIPT_ID 
              FROM T_SO_ORDER_RECEIPT R 
              LEFT JOIN T_SO_HEADER SH ON R.ORDER_NUMBER = SH.SO_NUM AND R.ORDER_TYPE = PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
              WHERE
                   R.ENTITY_ID = IN_ENTITY_ID 
                AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N 
                AND SH.SO_STATUS = PKG_AR_WRITE_OFF.V_SO_STATUS_11 
                AND R.RECEIPT_TYPE = '1' 
                AND EXISTS ( 
                            SELECT 1 FROM CIMS.T_SO_HEADER H 
                            WHERE ENTITY_ID = IN_ENTITY_ID 
                            AND BIZ_SRC_BILL_TYPE_CODE = PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO
                            AND SETTLE_FLAG = 'Y' 
                            AND H.APPLIED_FLAG IN(PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART,PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE)
                            AND SH.ACCOUNT_ID = H.ACCOUNT_ID ) 
           ); */
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
        P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
        P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_CANCEL_NO_SETTLE_SO', SQLCODE,
        '解除未结算销售单的核销关系出错！异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);   
  END;

  -- 解除核销关系
  PROCEDURE P_CANCEL_ORDER_RECEIPT
  (
      P_ORDER_NUMBER IN VARCHAR2,--原单单据号
      P_ORDER_TYPE IN VARCHAR2,-- 原单单据类型。ORDER_TYPE = 1，收款单；ORDER_TYPE in (1001,1002,1003,1004,1005,1006,1007,1008)销售单
      P_WRITE_FLAG IN VARCHAR2,  --部分冲销  根据标志 冲销指定类型数据  ALL 全部 | ORDER 单单核销
      P_REMARK     IN VARCHAR2, -- 备注
      P_CANCEL_ERP_YES_OR_NO IN VARCHAR2, --是否取消ERP核销关系
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  ) IS
  V_ORDER_RECEIPT_COUNT      NUMBER;--单据存在的核销关系记录数
  V_ORDER_MATCH_TYPE         NUMBER;--单据核销类型；1表示应收；-1表示回款
  V_ORDER_ID                 NUMBER;--单据ID
  V_ORDER_AMOUNT_RED         NUMBER;--核销单据金额
  V_P_ORDER_TYPE             VARCHAR2(10);
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    IF P_ORDER_TYPE = '-1' THEN
    	V_P_ORDER_TYPE := '1';
    ELSE
      V_P_ORDER_TYPE := P_ORDER_TYPE;
    END IF;
    IF V_P_ORDER_TYPE = '1' THEN -- 单据为收款单
    	SELECT H.CASH_RECEIPT_ID, (CASE WHEN H.AMOUNT > 0 THEN -1 ELSE 1 END)
             INTO V_ORDER_ID, V_ORDER_MATCH_TYPE
      FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
      WHERE H.CASH_RECEIPT_CODE = P_ORDER_NUMBER;
      UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS H SET H.UPDATED_DATE = SYSDATE WHERE  H.CASH_RECEIPT_CODE = P_ORDER_NUMBER;
    ELSE -- 单据为销售单
      SELECT S.SO_HEADER_ID, S.APPLIED_PLUS_MINUS_FLAG
             INTO V_ORDER_ID, V_ORDER_MATCH_TYPE
      FROM CIMS.V_AR_SO_HERDER_WRITE_OFF S
      WHERE S.SO_NUM = P_ORDER_NUMBER;
      UPDATE CIMS.T_SO_HEADER H SET H.LAST_UPDATE_DATE = SYSDATE WHERE H.SO_NUM = P_ORDER_NUMBER;
    END IF;
    IF V_ORDER_MATCH_TYPE = 1 THEN -- 应收
    	SELECT COUNT(*) INTO V_ORDER_RECEIPT_COUNT FROM CIMS.T_SO_ORDER_RECEIPT R
      WHERE R.TO_ERP_FLAG <> PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D AND R.SO_HEAD_ID = V_ORDER_ID AND R.ORDER_TYPE = V_P_ORDER_TYPE;
    ELSE -- 回款
      SELECT COUNT(*) INTO V_ORDER_RECEIPT_COUNT FROM CIMS.T_SO_ORDER_RECEIPT R
      WHERE R.TO_ERP_FLAG <> PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D AND R.CASH_RECEIPT_ID = V_ORDER_ID AND R.RECEIPT_TYPE = V_P_ORDER_TYPE;
    END IF;

    BEGIN
      IF V_ORDER_RECEIPT_COUNT > 0 THEN -- 原单据号存在核销关系
        IF V_ORDER_MATCH_TYPE = 1 THEN -- 原单据作为应收参与核销
          FOR CUR_SO_ORDER_RECEIPT IN (SELECT R.* FROM CIMS.T_SO_ORDER_RECEIPT R
                   WHERE R.TO_ERP_FLAG <> PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D 
                   AND R.SO_HEAD_ID = V_ORDER_ID
                   AND R.ORDER_TYPE = V_P_ORDER_TYPE
                   AND ('ALL'=P_WRITE_FLAG OR R.RELATED_TRANSACTION_NUMBER IS NOT NULL)
                 )
          LOOP
            -- 与之核销的单据为回款单据
            IF CUR_SO_ORDER_RECEIPT.RECEIPT_TYPE = '1' THEN --回款单为到款单
            	SELECT ABS(H.AMOUNT) INTO V_ORDER_AMOUNT_RED
              FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
              WHERE H.CASH_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.CASH_RECEIPT_ID;
              -- 修改与之核销的单据为回款单据核销状态
              IF V_ORDER_AMOUNT_RED > CUR_SO_ORDER_RECEIPT.AMOUNT THEN -- 回款单部分核销
              	UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS H
                       SET H.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, H.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                       ,UPDATED_DATE = SYSDATE
                WHERE H.CASH_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.CASH_RECEIPT_ID;
              ELSIF V_ORDER_AMOUNT_RED = CUR_SO_ORDER_RECEIPT.AMOUNT THEN -- 回款单全部核销
                UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS H
                       SET H.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, H.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                       ,UPDATED_DATE = SYSDATE
                WHERE H.CASH_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.CASH_RECEIPT_ID;
              ELSE
                UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS H
                       SET H.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, H.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                       ,UPDATED_DATE = SYSDATE
                WHERE H.CASH_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.CASH_RECEIPT_ID;
              END IF;
            ELSE --回款单为销售单
              SELECT ABS(ROUND(H.SETTLE_AMOUNT, 2)) INTO V_ORDER_AMOUNT_RED
              FROM CIMS.T_SO_HEADER H
              WHERE H.SO_HEADER_ID = CUR_SO_ORDER_RECEIPT.CASH_RECEIPT_ID;
              -- 修改与之核销的单据为回款单据核销状态
              IF V_ORDER_AMOUNT_RED > CUR_SO_ORDER_RECEIPT.AMOUNT THEN -- 回款单部分核销
              	UPDATE CIMS.T_SO_HEADER H
                       SET H.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, H.APPLIED_DATE = SYSDATE
                       ,LAST_UPDATE_DATE =SYSDATE
                WHERE H.SO_HEADER_ID = CUR_SO_ORDER_RECEIPT.CASH_RECEIPT_ID;
              ELSIF V_ORDER_AMOUNT_RED = CUR_SO_ORDER_RECEIPT.AMOUNT THEN -- 回款单全部核销
                UPDATE CIMS.T_SO_HEADER H
                       SET H.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, H.APPLIED_DATE = SYSDATE
                        ,LAST_UPDATE_DATE =SYSDATE
                WHERE H.SO_HEADER_ID = CUR_SO_ORDER_RECEIPT.CASH_RECEIPT_ID;
              ELSE -- 防止与之核销的销售单同时做修改折扣率的情况
                UPDATE CIMS.T_SO_HEADER H
                       SET H.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, H.APPLIED_DATE = SYSDATE
                        ,LAST_UPDATE_DATE =SYSDATE
                WHERE H.SO_HEADER_ID = CUR_SO_ORDER_RECEIPT.CASH_RECEIPT_ID;
              END IF;
            END IF;
            -- 2、解除核销关系
--            DELETE FROM CIMS.T_SO_ORDER_RECEIPT R WHERE R.ORDER_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
            UPDATE CIMS.T_SO_ORDER_RECEIPT R
                   SET R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D
                       ,LAST_UPDATE_DATE = SYSDATE
                       ,R.REMARK = SUBSTRB(R.REMARK||NVL(P_REMARK, '')||'#解除核销关系', 1, 1000)
            WHERE R.ORDER_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
            IF P_CANCEL_ERP_YES_OR_NO = PKG_AR_WRITE_OFF.V_YES THEN -- 取消ERP核销关系
            	UPDATE CIMS.INTF_AR_WRITEOFF I SET I.CANCEL_FLAG = PKG_AR_WRITE_OFF.V_YES, I.HANDLE_FLAG = PKG_AR_WRITE_OFF.V_NO WHERE I.ORDER_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
              UPDATE CIMS.INTF_AR_WRITEOFF_INV I SET I.CANCEL_FLAG = PKG_AR_WRITE_OFF.V_YES, I.HANDLE_FLAG = PKG_AR_WRITE_OFF.V_NO WHERE I.ORDER_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
            ELSE
              UPDATE CIMS.INTF_AR_WRITEOFF I SET I.CANCEL_FLAG = PKG_AR_WRITE_OFF.V_YES, I.HANDLE_FLAG = PKG_AR_WRITE_OFF.V_YES WHERE I.ORDER_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
              UPDATE CIMS.INTF_AR_WRITEOFF_INV I SET I.CANCEL_FLAG = PKG_AR_WRITE_OFF.V_YES, I.HANDLE_FLAG = PKG_AR_WRITE_OFF.V_YES WHERE I.ORDER_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
            END IF;
          END LOOP;
        ELSE -- 回款
          FOR CUR_SO_ORDER_RECEIPT IN (SELECT R.* FROM CIMS.T_SO_ORDER_RECEIPT R
                   WHERE R.TO_ERP_FLAG <> PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D 
                   AND R.CASH_RECEIPT_ID = V_ORDER_ID 
                   AND R.RECEIPT_TYPE = V_P_ORDER_TYPE
                   AND ('ALL'=P_WRITE_FLAG OR R.RELATED_TRANSACTION_NUMBER IS NOT NULL)
                 )
          LOOP
            -- 与之核销的单据为应收单据
            IF CUR_SO_ORDER_RECEIPT.ORDER_TYPE = '1' THEN --应收为到款单
            	SELECT ABS(H.AMOUNT) INTO V_ORDER_AMOUNT_RED
              FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
              WHERE H.CASH_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.SO_HEAD_ID;
              -- 修改与之核销的单据为回款单据核销状态
              IF V_ORDER_AMOUNT_RED > CUR_SO_ORDER_RECEIPT.AMOUNT THEN -- 应收部分核销
              	UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS H
                       SET H.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, H.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                       ,UPDATED_DATE = SYSDATE
                WHERE H.CASH_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.SO_HEAD_ID;
              ELSIF V_ORDER_AMOUNT_RED = CUR_SO_ORDER_RECEIPT.AMOUNT THEN -- 应收全部核销
                UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS H
                       SET H.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, H.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                       ,UPDATED_DATE = SYSDATE
                WHERE H.CASH_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.SO_HEAD_ID;
              ELSE
                UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS H
                       SET H.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, H.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
                       ,UPDATED_DATE = SYSDATE
                WHERE H.CASH_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.SO_HEAD_ID;
              END IF;
            ELSE --应收为销售单
              SELECT ABS(ROUND(H.SETTLE_AMOUNT, 2)) INTO V_ORDER_AMOUNT_RED
              FROM CIMS.T_SO_HEADER H
              WHERE H.SO_HEADER_ID = CUR_SO_ORDER_RECEIPT.SO_HEAD_ID;
              -- 修改与之核销的单据为回款单据核销状态
              IF V_ORDER_AMOUNT_RED > CUR_SO_ORDER_RECEIPT.AMOUNT THEN -- 应收部分核销
              	UPDATE CIMS.T_SO_HEADER H
                       SET H.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, H.APPLIED_DATE = SYSDATE
                        ,LAST_UPDATE_DATE =SYSDATE
                WHERE H.SO_HEADER_ID = CUR_SO_ORDER_RECEIPT.SO_HEAD_ID;
              ELSIF V_ORDER_AMOUNT_RED = CUR_SO_ORDER_RECEIPT.AMOUNT THEN -- 应收全部核销
                UPDATE CIMS.T_SO_HEADER H
                       SET H.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, H.APPLIED_DATE = SYSDATE
                        ,LAST_UPDATE_DATE =SYSDATE
                WHERE H.SO_HEADER_ID = CUR_SO_ORDER_RECEIPT.SO_HEAD_ID;
              ELSE  -- 防止与之核销的销售单同时做修改折扣率的情况
                UPDATE CIMS.T_SO_HEADER H
                       SET H.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, H.APPLIED_DATE = SYSDATE
                        ,LAST_UPDATE_DATE =SYSDATE
                WHERE H.SO_HEADER_ID = CUR_SO_ORDER_RECEIPT.SO_HEAD_ID;
              END IF;
            END IF;
            -- 2、解除核销关系
--            DELETE FROM CIMS.T_SO_ORDER_RECEIPT R WHERE R.ORDER_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
            UPDATE CIMS.T_SO_ORDER_RECEIPT R
                   SET R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_D
                       ,LAST_UPDATE_DATE = SYSDATE
                       ,R.REMARK = SUBSTRB(R.REMARK||NVL(P_REMARK, '')||'#解除核销关系', 1, 1000)
            WHERE R.ORDER_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
            IF P_CANCEL_ERP_YES_OR_NO = PKG_AR_WRITE_OFF.V_YES THEN -- 取消ERP核销关系
              UPDATE CIMS.INTF_AR_WRITEOFF I SET I.CANCEL_FLAG = PKG_AR_WRITE_OFF.V_YES, I.HANDLE_FLAG = PKG_AR_WRITE_OFF.V_NO WHERE I.ORDER_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
              UPDATE CIMS.INTF_AR_WRITEOFF_INV I SET I.CANCEL_FLAG = PKG_AR_WRITE_OFF.V_YES, I.HANDLE_FLAG = PKG_AR_WRITE_OFF.V_NO WHERE I.ORDER_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
            ELSE
              UPDATE CIMS.INTF_AR_WRITEOFF I SET I.CANCEL_FLAG = PKG_AR_WRITE_OFF.V_YES, I.HANDLE_FLAG = PKG_AR_WRITE_OFF.V_YES WHERE I.ORDER_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
              UPDATE CIMS.INTF_AR_WRITEOFF_INV I SET I.CANCEL_FLAG = PKG_AR_WRITE_OFF.V_YES, I.HANDLE_FLAG = PKG_AR_WRITE_OFF.V_YES WHERE I.ORDER_RECEIPT_ID = CUR_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
            END IF;
          END LOOP;
        END IF;
      END IF;
    EXCEPTION WHEN OTHERS THEN
      P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
      P_RESULT := '解除核销关系出错！单据号：'||P_ORDER_NUMBER||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM;
      RETURN;
    END;
    P_RESULT := '解除核销关系成功！';
  EXCEPTION WHEN OTHERS THEN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := '解除核销关系出错！单据号：'||P_ORDER_NUMBER||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM;
    RETURN ;
  END;

  -- 生成原单和冲销单的核销关系
  PROCEDURE P_CREATE_ORDER_RECEIPT
  (
      P_ORDER_NUMBER IN VARCHAR2,--单据号
      P_ORDER_TYPE IN VARCHAR2,-- 单据类型。ORDER_TYPE = 1，收款单；ORDER_TYPE in (1001,1002,1003,1004,1005,1006,1007,1008)销售单
      P_ORDER_NUMBER_RED IN VARCHAR2, --冲销单单据号
      P_MATCH_DATE       IN DATE, -- 核销日期。为空默认为sysdate-1
      P_TO_ERP_FLAG      IN VARCHAR2, --新生成核销关系引ERP方式。Y已引入，N未引入，C不引入
      P_REMARK     IN VARCHAR2, -- 备注
      P_RESULT  OUT VARCHAR2,-- 失败时返回异常消息
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  ) IS
  V_ORDER_MATCH_TYPE         NUMBER;--单据核销类型；1表示应收；-1表示回款
  V_ORDER_ID                 NUMBER;--单据ID
  V_ORDER_AMOUNT             NUMBER;--单据金额
  V_WRITE_OFF_ATTRIBUTE      VARCHAR2(1);--原单核销状态
  ROW_SO_ORDER_RECEIPT       T_SO_ORDER_RECEIPT%ROWTYPE;
  V_AR_POSITIVE_NEGATIVE_COUNT NUMBER;--是否存在既有正数、又有负数的收款单行
  V_ENTITY_ID                  NUMBER;-- 主体
  V_AR_SALE_MAIN_TYPE               PKG_AR_WRITE_OFF.AR_SALE_MAIN_TYPE;--是否区分营销大类。Y：区分；N：不区分
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    IF P_ORDER_TYPE = '1' THEN -- 单据为收款单
    	SELECT H.CASH_RECEIPT_ID, H.AMOUNT, (CASE WHEN H.AMOUNT > 0 THEN -1 ELSE 1 END), H.ENTITY_ID
             INTO V_ORDER_ID, V_ORDER_AMOUNT, V_ORDER_MATCH_TYPE, V_ENTITY_ID
      FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
      WHERE H.CASH_RECEIPT_CODE = P_ORDER_NUMBER;
      SELECT (CASE WHEN ABS(SUM(L.AMOUNT)) = SUM(ABS(L.AMOUNT)) THEN 0 ELSE 1 END) INTO V_AR_POSITIVE_NEGATIVE_COUNT
      FROM CIMS.T_AR_CASH_RECEIPT_LINES L WHERE L.CASH_RECEIPT_ID = V_ORDER_ID;
    ELSE -- 单据为销售单
      SELECT S.SO_HEADER_ID, ROUND(NVL(S.SETTLE_AMOUNT, 0), 2), S.APPLIED_PLUS_MINUS_FLAG, S.ENTITY_ID
             INTO V_ORDER_ID, V_ORDER_AMOUNT, V_ORDER_MATCH_TYPE, V_ENTITY_ID
      FROM CIMS.V_AR_SO_HERDER_WRITE_OFF S
      WHERE S.SO_NUM = P_ORDER_NUMBER;
    END IF;

    -- 1、插入原单和冲销单的核销关系
    -- 2、更新原单和冲销单的核销状态为完全核销
    IF P_ORDER_TYPE = '1' THEN -- 原单和冲销单为到款单
      -- 根据主体判断是否区分营销大类核销
      V_AR_SALE_MAIN_TYPE := PKG_AR_WRITE_OFF.F_AR_DEFAULT_SALE_MAIN_TYPE(V_ENTITY_ID);
      IF V_AR_POSITIVE_NEGATIVE_COUNT <> 0 OR UPPER(V_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF) = PKG_AR_WRITE_OFF.V_NO THEN -- 存在既有正数、又有负数的收款单行;不区分营销大类。按照单据头写入核销关系
        IF V_AR_POSITIVE_NEGATIVE_COUNT <> 0 THEN
          P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_CREATE_ORDER_RECEIPT', SQLCODE,
                '单据收款行存在同时为正数、负数的收款明细！原单单据号：'||P_ORDER_NUMBER||
                '，冲销单单据号：'||P_ORDER_NUMBER_RED||
                '。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
        END IF;
      	IF V_ORDER_MATCH_TYPE = 1 THEN -- 原单为应收，冲销单为回款
          SELECT H.ENTITY_ID, H.CUSTOMER_CODE, H.CUSTOMER_NAME,
                 V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_ID, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_NAME,
                 H.CASH_RECEIPT_ID, NULL AS CASH_RECEIPT_LINES_ID, H.CASH_RECEIPT_CODE,
                 '1' AS ORDER_TYPE, H.REVIEWED_DATE AS ORDER_DATE, H.ERP_OU_ID
          INTO ROW_SO_ORDER_RECEIPT.ENTITY_ID, ROW_SO_ORDER_RECEIPT.CUSROMER_CODE, ROW_SO_ORDER_RECEIPT.CUSROMER_NAME,
                 ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_ID, ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_CODE, ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_NAME,
                 ROW_SO_ORDER_RECEIPT.SO_HEAD_ID, ROW_SO_ORDER_RECEIPT.SO_HEAD_LINES_ID, ROW_SO_ORDER_RECEIPT.ORDER_NUMBER,
                 ROW_SO_ORDER_RECEIPT.ORDER_TYPE, ROW_SO_ORDER_RECEIPT.ORDER_DATE, ROW_SO_ORDER_RECEIPT.ORDER_ERP_OU_ID
          FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
          WHERE H.CASH_RECEIPT_CODE = P_ORDER_NUMBER;
          -- 查询冲销单的核销信息
          SELECT H.CASH_RECEIPT_ID, NULL AS CASH_RECEIPT_LINES_ID, H.CASH_RECEIPT_CODE,
                 '1' AS RECEIPT_TYPE, H.REVIEWED_DATE AS RECEIPT_DATE, ABS(H.AMOUNT), H.ERP_OU_ID
          INTO ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_ID, ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_LINES_ID, ROW_SO_ORDER_RECEIPT.RECEIPT_NUMBER,
                 ROW_SO_ORDER_RECEIPT.RECEIPT_TYPE, ROW_SO_ORDER_RECEIPT.RECEIPT_DATE, ROW_SO_ORDER_RECEIPT.AMOUNT, ROW_SO_ORDER_RECEIPT.RECEIPT_ERP_OU_ID
          FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
          WHERE H.CASH_RECEIPT_CODE = P_ORDER_NUMBER_RED;
        ELSE -- 原单回款，冲销单为应收
          SELECT H.ENTITY_ID, H.CUSTOMER_CODE, H.CUSTOMER_NAME,
                 V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_ID, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE, V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_NAME,
                 H.CASH_RECEIPT_ID, NULL AS CASH_RECEIPT_LINES_ID, H.CASH_RECEIPT_CODE,
                 '1' AS ORDER_TYPE, H.REVIEWED_DATE AS RECEIPT_DATE, H.ERP_OU_ID
          INTO ROW_SO_ORDER_RECEIPT.ENTITY_ID, ROW_SO_ORDER_RECEIPT.CUSROMER_CODE, ROW_SO_ORDER_RECEIPT.CUSROMER_NAME,
                 ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_ID, ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_CODE, ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_NAME,
                 ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_ID, ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_LINES_ID, ROW_SO_ORDER_RECEIPT.RECEIPT_NUMBER,
                 ROW_SO_ORDER_RECEIPT.RECEIPT_TYPE, ROW_SO_ORDER_RECEIPT.RECEIPT_DATE, ROW_SO_ORDER_RECEIPT.RECEIPT_ERP_OU_ID
          FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
          WHERE H.CASH_RECEIPT_CODE = P_ORDER_NUMBER;
          -- 查询冲销单的核销信息
          SELECT H.CASH_RECEIPT_ID, NULL AS CASH_RECEIPT_LINES_ID, H.CASH_RECEIPT_CODE,
                 '1' AS RECEIPT_TYPE, H.REVIEWED_DATE AS ORDER_DATE, ABS(H.AMOUNT), H.ERP_OU_ID
          INTO ROW_SO_ORDER_RECEIPT.SO_HEAD_ID, ROW_SO_ORDER_RECEIPT.SO_HEAD_LINES_ID, ROW_SO_ORDER_RECEIPT.ORDER_NUMBER,
                 ROW_SO_ORDER_RECEIPT.ORDER_TYPE, ROW_SO_ORDER_RECEIPT.ORDER_DATE, ROW_SO_ORDER_RECEIPT.AMOUNT, ROW_SO_ORDER_RECEIPT.ORDER_ERP_OU_ID
          FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
          WHERE H.CASH_RECEIPT_CODE = P_ORDER_NUMBER_RED;
        END IF;
        ROW_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID := S_SO_ORDER_RECEIPT.NEXTVAL;
        ROW_SO_ORDER_RECEIPT.MATCH_DATE := NVL(P_MATCH_DATE, TRUNC(SYSDATE - 1, 'DD')); -- 核销日期取前一天
        ROW_SO_ORDER_RECEIPT.TO_ERP_FLAG := NVL(P_TO_ERP_FLAG, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N);
        ROW_SO_ORDER_RECEIPT.REMARK := SUBSTRB(NVL(P_REMARK, '')||'#蓝单和红冲单不区分营销大类核销'||(CASE WHEN V_AR_POSITIVE_NEGATIVE_COUNT <> 0 THEN '#单据行警告' ELSE '' END), 1, 1000);
        ROW_SO_ORDER_RECEIPT.LAST_UPDATE_DATE := SYSDATE;
        -- 插入核销关系
        INSERT INTO T_SO_ORDER_RECEIPT VALUES ROW_SO_ORDER_RECEIPT;
      ELSE -- 按照单据行写入核销关系
      	FOR ROW_CASH_RECEIPT_LINE IN (SELECT * FROM CIMS.V_AR_CASH_RECEIPT_HEADER_LINES HL
                                     WHERE HL.CASH_RECEIPT_CODE = P_ORDER_NUMBER) LOOP
            IF V_ORDER_MATCH_TYPE = 1 THEN -- 原单为应收，冲销单为回款
              SELECT H.ENTITY_ID, H.CUSTOMER_CODE, H.CUSTOMER_NAME,
                     H.SALES_MAIN_TYPE_ID, H.SALES_MAIN_TYPE_CODE, H.SALES_MAIN_TYPE_NAME,
                     H.CASH_RECEIPT_ID, H.CASH_RECEIPT_LINES_ID, H.CASH_RECEIPT_CODE,
                     '1' AS ORDER_TYPE, H.REVIEWED_DATE AS ORDER_DATE, H.ERP_OU_ID
              INTO ROW_SO_ORDER_RECEIPT.ENTITY_ID, ROW_SO_ORDER_RECEIPT.CUSROMER_CODE, ROW_SO_ORDER_RECEIPT.CUSROMER_NAME,
                     ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_ID, ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_CODE, ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_NAME,
                     ROW_SO_ORDER_RECEIPT.SO_HEAD_ID, ROW_SO_ORDER_RECEIPT.SO_HEAD_LINES_ID, ROW_SO_ORDER_RECEIPT.ORDER_NUMBER,
                     ROW_SO_ORDER_RECEIPT.ORDER_TYPE, ROW_SO_ORDER_RECEIPT.ORDER_DATE, ROW_SO_ORDER_RECEIPT.ORDER_ERP_OU_ID
              FROM CIMS.V_AR_CASH_RECEIPT_HEADER_LINES H
              WHERE H.CASH_RECEIPT_LINES_ID = ROW_CASH_RECEIPT_LINE.CASH_RECEIPT_LINES_ID;
              -- 查询冲销单的核销信息
              SELECT H.CASH_RECEIPT_ID, H.CASH_RECEIPT_LINES_ID, H.CASH_RECEIPT_CODE,
                     '1' AS RECEIPT_TYPE, H.REVIEWED_DATE AS RECEIPT_DATE, ABS(H.AMOUNT), H.ERP_OU_ID
              INTO ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_ID, ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_LINES_ID, ROW_SO_ORDER_RECEIPT.RECEIPT_NUMBER,
                     ROW_SO_ORDER_RECEIPT.RECEIPT_TYPE, ROW_SO_ORDER_RECEIPT.RECEIPT_DATE, ROW_SO_ORDER_RECEIPT.AMOUNT, ROW_SO_ORDER_RECEIPT.RECEIPT_ERP_OU_ID
              FROM CIMS.V_AR_CASH_RECEIPT_HEADER_LINES H
              WHERE H.CASH_RECEIPT_CODE = P_ORDER_NUMBER_RED
                    AND H.SALES_MAIN_TYPE_CODE = ROW_CASH_RECEIPT_LINE.SALES_MAIN_TYPE_CODE;
            ELSE -- 原单回款，冲销单为应收
              SELECT H.ENTITY_ID, H.CUSTOMER_CODE, H.CUSTOMER_NAME,
                     H.SALES_MAIN_TYPE_ID, H.SALES_MAIN_TYPE_CODE, H.SALES_MAIN_TYPE_NAME,
                     H.CASH_RECEIPT_ID, H.CASH_RECEIPT_LINES_ID, H.CASH_RECEIPT_CODE,
                     '1' AS ORDER_TYPE, H.REVIEWED_DATE AS RECEIPT_DATE, H.ERP_OU_ID
              INTO ROW_SO_ORDER_RECEIPT.ENTITY_ID, ROW_SO_ORDER_RECEIPT.CUSROMER_CODE, ROW_SO_ORDER_RECEIPT.CUSROMER_NAME,
                     ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_ID, ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_CODE, ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_NAME,
                     ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_ID, ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_LINES_ID, ROW_SO_ORDER_RECEIPT.RECEIPT_NUMBER,
                     ROW_SO_ORDER_RECEIPT.RECEIPT_TYPE, ROW_SO_ORDER_RECEIPT.RECEIPT_DATE, ROW_SO_ORDER_RECEIPT.RECEIPT_ERP_OU_ID
              FROM CIMS.V_AR_CASH_RECEIPT_HEADER_LINES H
              WHERE H.CASH_RECEIPT_LINES_ID = ROW_CASH_RECEIPT_LINE.CASH_RECEIPT_LINES_ID;
              -- 查询冲销单的核销信息
              SELECT H.CASH_RECEIPT_ID, H.CASH_RECEIPT_LINES_ID, H.CASH_RECEIPT_CODE,
                     '1' AS RECEIPT_TYPE, H.REVIEWED_DATE AS ORDER_DATE, ABS(H.AMOUNT), H.ERP_OU_ID
              INTO ROW_SO_ORDER_RECEIPT.SO_HEAD_ID, ROW_SO_ORDER_RECEIPT.SO_HEAD_LINES_ID, ROW_SO_ORDER_RECEIPT.ORDER_NUMBER,
                     ROW_SO_ORDER_RECEIPT.ORDER_TYPE, ROW_SO_ORDER_RECEIPT.ORDER_DATE, ROW_SO_ORDER_RECEIPT.AMOUNT, ROW_SO_ORDER_RECEIPT.ORDER_ERP_OU_ID
              FROM CIMS.V_AR_CASH_RECEIPT_HEADER_LINES H
              WHERE H.CASH_RECEIPT_CODE = P_ORDER_NUMBER_RED
                    AND H.SALES_MAIN_TYPE_CODE = ROW_CASH_RECEIPT_LINE.SALES_MAIN_TYPE_CODE;
            END IF;
            ROW_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID := S_SO_ORDER_RECEIPT.NEXTVAL;
            ROW_SO_ORDER_RECEIPT.MATCH_DATE := NVL(P_MATCH_DATE, TRUNC(SYSDATE - 1, 'DD')); -- 核销日期取前一天
            ROW_SO_ORDER_RECEIPT.TO_ERP_FLAG := NVL(P_TO_ERP_FLAG, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N);
            ROW_SO_ORDER_RECEIPT.REMARK := SUBSTRB(NVL(P_REMARK, '')||'#蓝单和红冲单区分营销大类核销', 1, 1000);
            ROW_SO_ORDER_RECEIPT.LAST_UPDATE_DATE := SYSDATE;
            -- 插入核销关系
            INSERT INTO T_SO_ORDER_RECEIPT VALUES ROW_SO_ORDER_RECEIPT;
        END LOOP;
      END IF;
    ELSE  -- 原单和冲销单为销售单
      IF V_ORDER_MATCH_TYPE = 1 THEN -- 原单为应收，冲销单为回款
        SELECT H.ENTITY_ID, H.CUSTOMER_CODE, H.CUSTOMER_NAME,
               NULL AS SALES_MAIN_TYPE_ID, H.SALES_MAIN_TYPE, H.SALES_MAIN_TYPE_NAME,
               H.SO_HEADER_ID, NULL AS SO_HEAD_LINES_ID, H.SO_NUM,
               H.BIZ_SRC_BILL_TYPE_CODE AS ORDER_TYPE, H.SO_DATE AS ORDER_DATE, H.ERP_OU_ID
        INTO ROW_SO_ORDER_RECEIPT.ENTITY_ID, ROW_SO_ORDER_RECEIPT.CUSROMER_CODE, ROW_SO_ORDER_RECEIPT.CUSROMER_NAME,
               ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_ID, ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_CODE, ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_NAME,
               ROW_SO_ORDER_RECEIPT.SO_HEAD_ID, ROW_SO_ORDER_RECEIPT.SO_HEAD_LINES_ID, ROW_SO_ORDER_RECEIPT.ORDER_NUMBER,
               ROW_SO_ORDER_RECEIPT.ORDER_TYPE, ROW_SO_ORDER_RECEIPT.ORDER_DATE, ROW_SO_ORDER_RECEIPT.ORDER_ERP_OU_ID
        FROM CIMS.T_SO_HEADER H
        WHERE H.SO_NUM = P_ORDER_NUMBER;
        -- 查询冲销单信息
        SELECT H.SO_HEADER_ID, NULL AS CASH_RECEIPT_LINES_ID, H.SO_NUM,
               H.BIZ_SRC_BILL_TYPE_CODE AS RECEIPT_TYPE, H.SO_DATE AS RECEIPT_DATE, ABS(H.SETTLE_AMOUNT), H.ERP_OU_ID
        INTO ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_ID, ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_LINES_ID, ROW_SO_ORDER_RECEIPT.RECEIPT_NUMBER,
               ROW_SO_ORDER_RECEIPT.RECEIPT_TYPE, ROW_SO_ORDER_RECEIPT.RECEIPT_DATE, ROW_SO_ORDER_RECEIPT.AMOUNT, ROW_SO_ORDER_RECEIPT.RECEIPT_ERP_OU_ID
        FROM CIMS.T_SO_HEADER H
        WHERE H.SO_NUM = P_ORDER_NUMBER_RED;
      ELSE -- 原单为回款，冲销单为应收
        SELECT H.ENTITY_ID, H.CUSTOMER_CODE, H.CUSTOMER_NAME,
               NULL AS SALES_MAIN_TYPE_ID, H.SALES_MAIN_TYPE, H.SALES_MAIN_TYPE_NAME,
               H.SO_HEADER_ID, NULL AS SO_HEAD_LINES_ID, H.SO_NUM,
               H.BIZ_SRC_BILL_TYPE_CODE AS RECEIPT_TYPE, H.SO_DATE AS RECEIPT_DATE, H.ERP_OU_ID
        INTO ROW_SO_ORDER_RECEIPT.ENTITY_ID, ROW_SO_ORDER_RECEIPT.CUSROMER_CODE, ROW_SO_ORDER_RECEIPT.CUSROMER_NAME,
               ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_ID, ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_CODE, ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_NAME,
               ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_ID, ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_LINES_ID, ROW_SO_ORDER_RECEIPT.RECEIPT_NUMBER,
               ROW_SO_ORDER_RECEIPT.RECEIPT_TYPE, ROW_SO_ORDER_RECEIPT.RECEIPT_DATE, ROW_SO_ORDER_RECEIPT.RECEIPT_ERP_OU_ID
        FROM CIMS.T_SO_HEADER H
        WHERE H.SO_NUM = P_ORDER_NUMBER;
        -- 查询冲销单信息
        SELECT H.SO_HEADER_ID, NULL AS CASH_RECEIPT_LINES_ID, H.SO_NUM,
               H.BIZ_SRC_BILL_TYPE_CODE AS RECEIPT_TYPE, H.SO_DATE AS RECEIPT_DATE, ABS(H.SETTLE_AMOUNT), H.ERP_OU_ID
        INTO ROW_SO_ORDER_RECEIPT.SO_HEAD_ID, ROW_SO_ORDER_RECEIPT.SO_HEAD_LINES_ID, ROW_SO_ORDER_RECEIPT.ORDER_NUMBER,
               ROW_SO_ORDER_RECEIPT.ORDER_TYPE, ROW_SO_ORDER_RECEIPT.ORDER_DATE, ROW_SO_ORDER_RECEIPT.AMOUNT, ROW_SO_ORDER_RECEIPT.ORDER_ERP_OU_ID
        FROM CIMS.T_SO_HEADER H
        WHERE H.SO_NUM = P_ORDER_NUMBER_RED;
      END IF;
      ROW_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID := S_SO_ORDER_RECEIPT.NEXTVAL;
      ROW_SO_ORDER_RECEIPT.MATCH_DATE := NVL(P_MATCH_DATE, TRUNC(SYSDATE - 1, 'DD')); -- 核销日期取前一天
      ROW_SO_ORDER_RECEIPT.TO_ERP_FLAG := NVL(P_TO_ERP_FLAG, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N);
      ROW_SO_ORDER_RECEIPT.REMARK := SUBSTRB(NVL(P_REMARK, '')||'#蓝单和红冲单核销', 1, 1000);
      ROW_SO_ORDER_RECEIPT.LAST_UPDATE_DATE := SYSDATE;
      -- 插入核销关系
      INSERT INTO T_SO_ORDER_RECEIPT VALUES ROW_SO_ORDER_RECEIPT;
    END IF;
    -- 更新原单和冲销单核销状态为完全核销
    IF P_ORDER_TYPE = '1' THEN -- 原单和冲销单为到款单
      SELECT (CASE WHEN ABS(V_ORDER_AMOUNT) > ABS(H.AMOUNT) THEN PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART
                   WHEN ABS(V_ORDER_AMOUNT) = ABS(H.AMOUNT) THEN PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL END)
             INTO V_WRITE_OFF_ATTRIBUTE
      FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
      WHERE H.CASH_RECEIPT_CODE = P_ORDER_NUMBER_RED;

      -- 更新原单的核销状态
      UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS H
             SET H.ATTRIBUTE5 = V_WRITE_OFF_ATTRIBUTE, H.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
      WHERE H.CASH_RECEIPT_CODE = P_ORDER_NUMBER;
      -- 更新冲销单的核销状态
      UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS H
             SET H.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, H.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
      WHERE H.CASH_RECEIPT_CODE = P_ORDER_NUMBER_RED;
    ELSE  -- 原单和冲销单为销售单
      SELECT (CASE WHEN ABS(V_ORDER_AMOUNT) > ABS(ROUND(NVL(H.SETTLE_AMOUNT, 0), 2)) THEN PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART
                   WHEN ABS(V_ORDER_AMOUNT) = ABS(ROUND(NVL(H.SETTLE_AMOUNT, 0), 2)) THEN PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL END)
             INTO V_WRITE_OFF_ATTRIBUTE
      FROM CIMS.T_SO_HEADER H
      WHERE H.SO_NUM = P_ORDER_NUMBER_RED;
      -- 更新原单的核销状态
      UPDATE CIMS.T_SO_HEADER H
            SET H.APPLIED_FLAG = V_WRITE_OFF_ATTRIBUTE, H.APPLIED_DATE = SYSDATE
      WHERE H.SO_NUM = P_ORDER_NUMBER;
      -- 更新冲销单的核销状态
      UPDATE CIMS.T_SO_HEADER H
            SET H.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, H.APPLIED_DATE = SYSDATE
      WHERE H.SO_NUM = P_ORDER_NUMBER_RED;
    END IF;
  EXCEPTION WHEN OTHERS THEN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := '生成原单和冲销单的核销关系出错！蓝单单据号：'||P_ORDER_NUMBER||'，冲销单单据号：'||P_ORDER_NUMBER_RED||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM;
    RETURN ;
  END;

  -- 生成跨主体单据（制单状态）
  PROCEDURE P_AR_CASH_TURNFEE_NEW(
    IN_ENTITY_ID IN  NUMBER,  --主体 
       P_RESULT OUT VARCHAR2,
       P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
  ROW_AR_CASH_TURNFEE_HEADER        T_AR_CASH_TURNFEE_HEADER%ROWTYPE;
  ROW_AR_CASH_TURNFEE_LINE          T_AR_CASH_TURNFEE_LINE%ROWTYPE;
  V_CASH_TURNFEE_CODE               T_AR_CASH_TURNFEE_HEADER.CASH_TURNFEE_CODE%TYPE;
  V_CASH_TURNFEE_ID                 T_AR_CASH_TURNFEE_HEADER.CASH_TURNFEE_ID%TYPE;
  V_AR_SALE_MAIN_TYPE               PKG_AR_WRITE_OFF.AR_SALE_MAIN_TYPE;--是否区分营销大类。Y：区分；N：不区分
  V_ENTITY                          UP_ORG_UNIT.UNIT_ID%TYPE;
  --区分营销大类(回款转出，应收转入)
  CURSOR CUR_SO_DIFF_SALE_MAIN_TYPE IS
         SELECT ORCO.* FROM CIMS.V_AR_ORDER_RECEIPT_CROSS_OU ORCO
           WHERE ORCO.ENTITY_ID = V_ENTITY;

  --不区分营销大类(回款转出，应收转入)
  CURSOR CUR_SO_NO_DIFF_SALE_MAIN_TYPE IS
        SELECT
                SUM(ORCO.AMOUNT) AS AMOUNT
                ,ORCO.ENTITY_ID                             --主体ID
                ,ORCO.CUSTOMER_ID                           --客户ID
               -- ,ORCO.CUSTOMER_CODE                         --客户编码
               -- ,ORCO.CUSTOMER_NAME                         --客户名称
                ,ORCO.ACCOUNT_ID                            --账户ID
                ,ORCO.ACCOUNT_CODE                          --账户编码
              --  ,ORCO.ACCOUNT_NAME                          --账户名称
                ,ORCO.OUT_ERP_OU_ID                         --转出ERP_OU_ID
              --  ,ORCO.OUT_ERP_OU_NAME                       --转出ERP_OU_NAME
                ,ORCO.IN_ERP_OU_ID                          --转入ERP_OU_ID
              --  ,ORCO.IN_ERP_OU_NAME                        --转入ERP_OU_NAME
                ,ORCO.OUT_SALES_CENTER_ID
              --  ,ORCO.OUT_SALES_CENTER_CODE
              --  ,ORCO.OUT_SALES_CENTER_NAME
                ,ORCO.IN_SALES_CENTER_ID
             --   ,ORCO.IN_SALES_CENTER_CODE
             --   ,ORCO.IN_SALES_CENTER_NAME
         FROM V_AR_ORDER_RECEIPT_CROSS_OU ORCO
         WHERE ORCO.ENTITY_ID = V_ENTITY
       GROUP BY ORCO.ENTITY_ID, ORCO.CUSTOMER_ID
            --   ,ORCO.CUSTOMER_CODE
           --    ,ORCO.CUSTOMER_NAME
               ,ORCO.ACCOUNT_ID
               ,ORCO.ACCOUNT_CODE
           --    ,ORCO.ACCOUNT_NAME
               ,ORCO.OUT_ERP_OU_ID
           --    ,ORCO.OUT_ERP_OU_NAME
               ,ORCO.IN_ERP_OU_ID
           --    ,ORCO.IN_ERP_OU_NAME
               ,ORCO.OUT_SALES_CENTER_ID
            --   ,ORCO.OUT_SALES_CENTER_CODE
            --   ,ORCO.OUT_SALES_CENTER_NAME
               ,ORCO.IN_SALES_CENTER_ID
             --  ,ORCO.IN_SALES_CENTER_CODE
               --,ORCO.IN_SALES_CENTER_NAME
               ;
      V_CUSTOMER_CODE  T_CUSTOMER_HEADER.CUSTOMER_CODE%TYPE;  
      V_CUSTOMER_NAME  T_CUSTOMER_HEADER.CUSTOMER_NAME%TYPE;  
      V_IN_SALES_CENTER_CODE  UP_ORG_UNIT.CODE%TYPE;
      V_IN_SALES_CENTER_NAME  UP_ORG_UNIT.NAME%TYPE;   
      V_OUT_SALES_CENTER_CODE UP_ORG_UNIT.CODE%TYPE;
      V_OUT_SALES_CENTER_NAME UP_ORG_UNIT.NAME%TYPE;  
      
      V_IN_ERP_OU_NAME  VARCHAR2(400);
      V_OUT_ERP_OU_NAME  VARCHAR2(400);
      P_LOG_RESULT VARCHAR2(400);
  BEGIN
    P_MESSAGE  := PKG_AR_WRITE_OFF.V_SUCCESS;
  --  FOR ROW_ENTITY IN (SELECT T.* FROM CIMS.V_BD_ENTITY T) LOOP
      V_ENTITY := IN_ENTITY_ID;
      
      P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_CASH_TURNFEE_NEW', '-1','记录次数'||V_ENTITY);
      
    	V_AR_SALE_MAIN_TYPE := PKG_AR_WRITE_OFF.F_AR_DEFAULT_SALE_MAIN_TYPE(V_ENTITY);
      IF UPPER(V_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF) = PKG_AR_WRITE_OFF.V_YES THEN -- 区分营销大类
        FOR ROW_SO_DIFF_SALE_MAIN_TYPE IN CUR_SO_DIFF_SALE_MAIN_TYPE LOOP
        	BEGIN 
            -- 获取转款单编号
            SELECT S_AR_CASH_TURNFEE_HEADER.NEXTVAL INTO V_CASH_TURNFEE_ID FROM DUAL;
            PKG_BD.P_GET_BILL_NO('ARTFCODE', NULL, ROW_SO_DIFF_SALE_MAIN_TYPE.ENTITY_ID, NULL, V_CASH_TURNFEE_CODE);
            ROW_AR_CASH_TURNFEE_HEADER.CASH_TURNFEE_ID := V_CASH_TURNFEE_ID;
            ROW_AR_CASH_TURNFEE_HEADER.CASH_TURNFEE_CODE := V_CASH_TURNFEE_CODE;
            -- 主体
            ROW_AR_CASH_TURNFEE_HEADER.ENTITY_ID := ROW_SO_DIFF_SALE_MAIN_TYPE.ENTITY_ID;
            ROW_AR_CASH_TURNFEE_HEADER.IN_ENTITY_ID := ROW_SO_DIFF_SALE_MAIN_TYPE.ENTITY_ID;
            -- 客户
            ROW_AR_CASH_TURNFEE_HEADER.OUT_CUSTOMER_ID := ROW_SO_DIFF_SALE_MAIN_TYPE.CUSTOMER_ID;
            ROW_AR_CASH_TURNFEE_HEADER.OUT_CUSTOMER_CODE := ROW_SO_DIFF_SALE_MAIN_TYPE.CUSTOMER_CODE;
            ROW_AR_CASH_TURNFEE_HEADER.OUT_CUSTOMER_NAME := ROW_SO_DIFF_SALE_MAIN_TYPE.CUSTOMER_NAME;
            ROW_AR_CASH_TURNFEE_HEADER.IN_CUSTOMER_ID := ROW_SO_DIFF_SALE_MAIN_TYPE.CUSTOMER_ID;
            ROW_AR_CASH_TURNFEE_HEADER.IN_CUSTOMER_CODE := ROW_SO_DIFF_SALE_MAIN_TYPE.CUSTOMER_CODE;
            ROW_AR_CASH_TURNFEE_HEADER.IN_CUSTOMER_NAME := ROW_SO_DIFF_SALE_MAIN_TYPE.CUSTOMER_NAME;
            -- 账户
            ROW_AR_CASH_TURNFEE_HEADER.OUT_ACCOUNT_ID := ROW_SO_DIFF_SALE_MAIN_TYPE.ACCOUNT_ID;
            ROW_AR_CASH_TURNFEE_HEADER.OUT_ACCOUNT_CODE := ROW_SO_DIFF_SALE_MAIN_TYPE.ACCOUNT_CODE;
            ROW_AR_CASH_TURNFEE_HEADER.OUT_ACCOUNT_NAME := ROW_SO_DIFF_SALE_MAIN_TYPE.ACCOUNT_NAME;
            ROW_AR_CASH_TURNFEE_HEADER.IN_ACCOUNT_ID := ROW_SO_DIFF_SALE_MAIN_TYPE.ACCOUNT_ID;
            ROW_AR_CASH_TURNFEE_HEADER.IN_ACCOUNT_CODE := ROW_SO_DIFF_SALE_MAIN_TYPE.ACCOUNT_CODE;
            ROW_AR_CASH_TURNFEE_HEADER.IN_ACCOUNT_NAME := ROW_SO_DIFF_SALE_MAIN_TYPE.ACCOUNT_NAME;
            -- OU
            ROW_AR_CASH_TURNFEE_HEADER.OUT_ERP_OU_ID := ROW_SO_DIFF_SALE_MAIN_TYPE.OUT_ERP_OU_ID;
            ROW_AR_CASH_TURNFEE_HEADER.OUT_ERP_OU_NAME := ROW_SO_DIFF_SALE_MAIN_TYPE.OUT_ERP_OU_NAME;
            ROW_AR_CASH_TURNFEE_HEADER.IN_ERP_OU_ID := ROW_SO_DIFF_SALE_MAIN_TYPE.IN_ERP_OU_ID;
            ROW_AR_CASH_TURNFEE_HEADER.IN_ERP_OU_NAME := ROW_SO_DIFF_SALE_MAIN_TYPE.IN_ERP_OU_NAME;
            -- 状态
            ROW_AR_CASH_TURNFEE_HEADER.STATUS := '1';
            ROW_AR_CASH_TURNFEE_HEADER.CASH_RECEIPT_DATE := TRUNC(SYSDATE);
            ROW_AR_CASH_TURNFEE_HEADER.GL_DATE := TRUNC(SYSDATE);
            ROW_AR_CASH_TURNFEE_HEADER.AMOUNT := ROW_SO_DIFF_SALE_MAIN_TYPE.AMOUNT;
            ROW_AR_CASH_TURNFEE_HEADER.CURRENCY_CODE := 'CNY';
            ROW_AR_CASH_TURNFEE_HEADER.CASH_RECEIPT_CREATED_BY := 'SYSTEM';
            ROW_AR_CASH_TURNFEE_HEADER.CASH_RECEIPT_CREATION_BY_TIME := TRUNC(SYSDATE);
--            ROW_AR_CASH_TURNFEE_HEADER.REVIEWED_BY := 'SYSTEM';
--            ROW_AR_CASH_TURNFEE_HEADER.REVIEWED_BY_TIME := TRUNC(SYSDATE);
            ROW_AR_CASH_TURNFEE_HEADER.UPDATED_BY := 'SYSTEM';
            ROW_AR_CASH_TURNFEE_HEADER.UPDATED_DATE := TRUNC(SYSDATE);
            ROW_AR_CASH_TURNFEE_HEADER.IS_PRINT_LOCK := 'Y';
            ROW_AR_CASH_TURNFEE_HEADER.REMARK := '区分营销大类跨主体转款。核销关系：'||ROW_SO_DIFF_SALE_MAIN_TYPE.ORDER_RECEIPT_ID||'。';
            ROW_AR_CASH_TURNFEE_HEADER.VERSION_NUM := 0;
            -- 中转关联号
            ROW_AR_CASH_TURNFEE_HEADER.ATTRIBUTE3 := V_CASH_TURNFEE_CODE;

            -- 收款方法
            SELECT T.RECEIPT_METHOD_ID
                   INTO ROW_AR_CASH_TURNFEE_HEADER.RECEIPT_METHOD_ID
            FROM T_AR_RECEIPT_METHODS  T
            WHERE T.RECEIPT_METHOD_NAME = PKG_AR_WRITE_OFF.V_CROSS_OU_METHOD_NAME
                  AND T.ENTITY_ID = ROW_SO_DIFF_SALE_MAIN_TYPE.ENTITY_ID;
            -- 转入转出营销中心
            ROW_AR_CASH_TURNFEE_HEADER.OUT_SALES_CENTER_ID := ROW_SO_DIFF_SALE_MAIN_TYPE.OUT_SALES_CENTER_ID;
            ROW_AR_CASH_TURNFEE_HEADER.OUT_SALES_CENTER_CODE := ROW_SO_DIFF_SALE_MAIN_TYPE.OUT_SALES_CENTER_CODE;
            ROW_AR_CASH_TURNFEE_HEADER.OUT_SALES_CENTER_NAME := ROW_SO_DIFF_SALE_MAIN_TYPE.OUT_SALES_CENTER_NAME;
            ROW_AR_CASH_TURNFEE_HEADER.IN_SALES_CENTER_ID := ROW_SO_DIFF_SALE_MAIN_TYPE.IN_SALES_CENTER_ID;
            ROW_AR_CASH_TURNFEE_HEADER.IN_SALES_CENTER_CODE := ROW_SO_DIFF_SALE_MAIN_TYPE.IN_SALES_CENTER_CODE;
            ROW_AR_CASH_TURNFEE_HEADER.IN_SALES_CENTER_NAME := ROW_SO_DIFF_SALE_MAIN_TYPE.IN_SALES_CENTER_NAME;
            /**SELECT DISTINCT T.SALES_CENTER_ID, T.SALES_CENTER_CODE, T.SALES_CENTER_NAME,
                   T.SALES_CENTER_ID, T.SALES_CENTER_CODE, T.SALES_CENTER_NAME
            INTO ROW_AR_CASH_TURNFEE_HEADER.IN_SALES_CENTER_ID, ROW_AR_CASH_TURNFEE_HEADER.IN_SALES_CENTER_CODE, ROW_AR_CASH_TURNFEE_HEADER.IN_SALES_CENTER_NAME
                  ,ROW_AR_CASH_TURNFEE_HEADER.OUT_SALES_CENTER_ID, ROW_AR_CASH_TURNFEE_HEADER.OUT_SALES_CENTER_CODE, ROW_AR_CASH_TURNFEE_HEADER.OUT_SALES_CENTER_NAME
            FROM V_CUST_ACCOUNT_CROSSOUTURNFEE T
            WHERE T.CUSTOMER_ID = ROW_SO_DIFF_SALE_MAIN_TYPE.CUSTOMER_ID
                  AND T.ACCOUNT_ID = ROW_SO_DIFF_SALE_MAIN_TYPE.ACCOUNT_ID
                  AND T.ENTITY_ID = ROW_SO_DIFF_SALE_MAIN_TYPE.ENTITY_ID;**/
            -- 插入转款头
            INSERT INTO CIMS.T_AR_CASH_TURNFEE_HEADER VALUES ROW_AR_CASH_TURNFEE_HEADER;

            -- 转款行
            ROW_AR_CASH_TURNFEE_LINE.CASH_TURNFEE_LINE_ID := S_AR_CASH_TURNFEE_LINE.NEXTVAL;
            ROW_AR_CASH_TURNFEE_LINE.CASH_TURNFEE_ID := V_CASH_TURNFEE_ID;
            ROW_AR_CASH_TURNFEE_LINE.AMOUNT := ROW_SO_DIFF_SALE_MAIN_TYPE.AMOUNT;
            ROW_AR_CASH_TURNFEE_LINE.ENTITY_ID := ROW_SO_DIFF_SALE_MAIN_TYPE.ENTITY_ID;
            ROW_AR_CASH_TURNFEE_LINE.OUT_SALES_MAIN_TYPE_ID := ROW_SO_DIFF_SALE_MAIN_TYPE.OUT_SALES_MAIN_TYPE_ID;
            ROW_AR_CASH_TURNFEE_LINE.OUT_SALES_MAIN_TYPE_CODE := ROW_SO_DIFF_SALE_MAIN_TYPE.OUT_SALES_MAIN_TYPE_CODE;
            ROW_AR_CASH_TURNFEE_LINE.OUT_SALES_MAIN_TYPE_NAME := ROW_SO_DIFF_SALE_MAIN_TYPE.OUT_SALES_MAIN_TYPE_NAME;
            ROW_AR_CASH_TURNFEE_LINE.IN_SALES_MAIN_TYPE_ID := ROW_SO_DIFF_SALE_MAIN_TYPE.IN_SALES_MAIN_TYPE_ID;
            ROW_AR_CASH_TURNFEE_LINE.IN_SALES_MAIN_TYPE_CODE := ROW_SO_DIFF_SALE_MAIN_TYPE.IN_SALES_MAIN_TYPE_CODE;
            ROW_AR_CASH_TURNFEE_LINE.IN_SALES_MAIN_TYPE_NAME := ROW_SO_DIFF_SALE_MAIN_TYPE.IN_SALES_MAIN_TYPE_NAME;
            -- 插入转款行
            INSERT INTO CIMS.T_AR_CASH_TURNFEE_LINE VALUES ROW_AR_CASH_TURNFEE_LINE;
            -- 回写转款头ID至核销关系表
            UPDATE CIMS.T_SO_ORDER_RECEIPT R SET R.TMP_CASH_TURNFEE_ID = V_CASH_TURNFEE_ID
             ,LAST_UPDATE_DATE = SYSDATE
            WHERE R.ORDER_RECEIPT_ID = ROW_SO_DIFF_SALE_MAIN_TYPE.ORDER_RECEIPT_ID;
            COMMIT;
          EXCEPTION WHEN OTHERS THEN
            ROLLBACK;
            P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
            P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_CASH_TURNFEE_NEW', SQLCODE,
                    '区分营销大类生成生成跨主体单据（制单状态）出错！主体：'||ROW_SO_DIFF_SALE_MAIN_TYPE.ENTITY_ID||
                    '、客户：'||ROW_SO_DIFF_SALE_MAIN_TYPE.CUSTOMER_ID||
                    '、账户：'||ROW_SO_DIFF_SALE_MAIN_TYPE.ACCOUNT_ID||
                    '、转出OU：'||ROW_SO_DIFF_SALE_MAIN_TYPE.OUT_ERP_OU_ID||
                    '、转入OU：'||ROW_SO_DIFF_SALE_MAIN_TYPE.IN_ERP_OU_ID||
                    '、转出品类：'||ROW_SO_DIFF_SALE_MAIN_TYPE.OUT_SALES_MAIN_TYPE_CODE||
                    '、转入品类：'||ROW_SO_DIFF_SALE_MAIN_TYPE.IN_SALES_MAIN_TYPE_CODE||
                    '。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
          END;
        END LOOP;
      ELSE -- 不区分营销大类
        FOR ROW_SO_NO_DIFF_SALE_MAIN_TYPE IN CUR_SO_NO_DIFF_SALE_MAIN_TYPE LOOP
        	BEGIN
            
            SELECT CUSTOMER_CODE,CUSTOMER_NAME INTO V_CUSTOMER_CODE,V_CUSTOMER_NAME FROM T_CUSTOMER_HEADER WHERE CUSTOMER_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.CUSTOMER_ID;
            SELECT CODE,NAME INTO V_IN_SALES_CENTER_CODE,V_IN_SALES_CENTER_NAME FROM UP_ORG_UNIT WHERE UNIT_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.IN_SALES_CENTER_ID;
            SELECT CODE,NAME INTO V_OUT_SALES_CENTER_CODE,V_OUT_SALES_CENTER_NAME FROM UP_ORG_UNIT WHERE UNIT_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.OUT_SALES_CENTER_ID;
            
            SELECT CODE_NAME INTO V_IN_ERP_OU_NAME FROM V_UP_CODELIST WHERE CODETYPE='ar_ou_id'   AND CODE_VALUE=ROW_SO_NO_DIFF_SALE_MAIN_TYPE.IN_ERP_OU_ID;
            SELECT CODE_NAME INTO V_OUT_ERP_OU_NAME FROM V_UP_CODELIST WHERE CODETYPE='ar_ou_id'  AND CODE_VALUE=ROW_SO_NO_DIFF_SALE_MAIN_TYPE.OUT_ERP_OU_ID;
            
            -- 获取转款单编号
            SELECT S_AR_CASH_TURNFEE_HEADER.NEXTVAL INTO V_CASH_TURNFEE_ID FROM DUAL;
            PKG_BD.P_GET_BILL_NO('ARTFCODE', NULL, ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ENTITY_ID, NULL, V_CASH_TURNFEE_CODE);
            ROW_AR_CASH_TURNFEE_HEADER.CASH_TURNFEE_ID := V_CASH_TURNFEE_ID;
            ROW_AR_CASH_TURNFEE_HEADER.CASH_TURNFEE_CODE := V_CASH_TURNFEE_CODE;
            -- 主体
            ROW_AR_CASH_TURNFEE_HEADER.ENTITY_ID := ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ENTITY_ID;
            ROW_AR_CASH_TURNFEE_HEADER.IN_ENTITY_ID := ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ENTITY_ID;
            -- 客户
            ROW_AR_CASH_TURNFEE_HEADER.OUT_CUSTOMER_ID := ROW_SO_NO_DIFF_SALE_MAIN_TYPE.CUSTOMER_ID;
            ROW_AR_CASH_TURNFEE_HEADER.OUT_CUSTOMER_CODE := V_CUSTOMER_CODE;
            ROW_AR_CASH_TURNFEE_HEADER.OUT_CUSTOMER_NAME := V_CUSTOMER_NAME;
            ROW_AR_CASH_TURNFEE_HEADER.IN_CUSTOMER_ID := ROW_SO_NO_DIFF_SALE_MAIN_TYPE.CUSTOMER_ID;
            ROW_AR_CASH_TURNFEE_HEADER.IN_CUSTOMER_CODE := V_CUSTOMER_CODE;
            ROW_AR_CASH_TURNFEE_HEADER.IN_CUSTOMER_NAME := V_CUSTOMER_NAME;
            -- 账户
            ROW_AR_CASH_TURNFEE_HEADER.OUT_ACCOUNT_ID := ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ACCOUNT_ID;
            ROW_AR_CASH_TURNFEE_HEADER.OUT_ACCOUNT_CODE := ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ACCOUNT_CODE;
            ROW_AR_CASH_TURNFEE_HEADER.OUT_ACCOUNT_NAME := null;
            ROW_AR_CASH_TURNFEE_HEADER.IN_ACCOUNT_ID := ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ACCOUNT_ID;
            ROW_AR_CASH_TURNFEE_HEADER.IN_ACCOUNT_CODE := ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ACCOUNT_CODE;
            ROW_AR_CASH_TURNFEE_HEADER.IN_ACCOUNT_NAME := null;
            -- OU
            ROW_AR_CASH_TURNFEE_HEADER.OUT_ERP_OU_ID := ROW_SO_NO_DIFF_SALE_MAIN_TYPE.OUT_ERP_OU_ID;
            ROW_AR_CASH_TURNFEE_HEADER.OUT_ERP_OU_NAME := V_OUT_ERP_OU_NAME;
            ROW_AR_CASH_TURNFEE_HEADER.IN_ERP_OU_ID := ROW_SO_NO_DIFF_SALE_MAIN_TYPE.IN_ERP_OU_ID;
            ROW_AR_CASH_TURNFEE_HEADER.IN_ERP_OU_NAME := V_IN_ERP_OU_NAME;
            -- 状态
            ROW_AR_CASH_TURNFEE_HEADER.STATUS := '1';
            ROW_AR_CASH_TURNFEE_HEADER.CASH_RECEIPT_DATE := TRUNC(SYSDATE);
            ROW_AR_CASH_TURNFEE_HEADER.GL_DATE := TRUNC(SYSDATE);
            ROW_AR_CASH_TURNFEE_HEADER.AMOUNT := ROW_SO_NO_DIFF_SALE_MAIN_TYPE.AMOUNT;
            ROW_AR_CASH_TURNFEE_HEADER.CURRENCY_CODE := 'CNY';
            ROW_AR_CASH_TURNFEE_HEADER.CASH_RECEIPT_CREATED_BY := 'SYSTEM';
            ROW_AR_CASH_TURNFEE_HEADER.CASH_RECEIPT_CREATION_BY_TIME := TRUNC(SYSDATE);
--            ROW_AR_CASH_TURNFEE_HEADER.REVIEWED_BY := 'SYSTEM';
--            ROW_AR_CASH_TURNFEE_HEADER.REVIEWED_BY_TIME := TRUNC(SYSDATE);
            ROW_AR_CASH_TURNFEE_HEADER.UPDATED_BY := 'SYSTEM';
            ROW_AR_CASH_TURNFEE_HEADER.UPDATED_DATE := TRUNC(SYSDATE);
            ROW_AR_CASH_TURNFEE_HEADER.IS_PRINT_LOCK := 'Y';
            ROW_AR_CASH_TURNFEE_HEADER.REMARK := '不区分营销大类跨主体转款。';
            ROW_AR_CASH_TURNFEE_HEADER.VERSION_NUM := 0;
            -- 中转关联号
            ROW_AR_CASH_TURNFEE_HEADER.ATTRIBUTE3 := V_CASH_TURNFEE_CODE;

            -- 收款方法
            SELECT T.RECEIPT_METHOD_ID
                   INTO ROW_AR_CASH_TURNFEE_HEADER.RECEIPT_METHOD_ID
            FROM T_AR_RECEIPT_METHODS  T
            WHERE T.RECEIPT_METHOD_NAME = PKG_AR_WRITE_OFF.V_CROSS_OU_METHOD_NAME
                  AND T.ENTITY_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ENTITY_ID;
            -- 转入转出营销中心
            ROW_AR_CASH_TURNFEE_HEADER.OUT_SALES_CENTER_ID := ROW_SO_NO_DIFF_SALE_MAIN_TYPE.OUT_SALES_CENTER_ID;
            ROW_AR_CASH_TURNFEE_HEADER.OUT_SALES_CENTER_CODE := V_OUT_SALES_CENTER_CODE;
            ROW_AR_CASH_TURNFEE_HEADER.OUT_SALES_CENTER_NAME := V_OUT_SALES_CENTER_NAME;
            ROW_AR_CASH_TURNFEE_HEADER.IN_SALES_CENTER_ID := ROW_SO_NO_DIFF_SALE_MAIN_TYPE.IN_SALES_CENTER_ID;
            ROW_AR_CASH_TURNFEE_HEADER.IN_SALES_CENTER_CODE := V_IN_SALES_CENTER_CODE;
            ROW_AR_CASH_TURNFEE_HEADER.IN_SALES_CENTER_NAME := V_IN_SALES_CENTER_NAME;
            /**SELECT DISTINCT T.SALES_CENTER_ID, T.SALES_CENTER_CODE, T.SALES_CENTER_NAME,
                   T.SALES_CENTER_ID, T.SALES_CENTER_CODE, T.SALES_CENTER_NAME
            INTO ROW_AR_CASH_TURNFEE_HEADER.IN_SALES_CENTER_ID, ROW_AR_CASH_TURNFEE_HEADER.IN_SALES_CENTER_CODE, ROW_AR_CASH_TURNFEE_HEADER.IN_SALES_CENTER_NAME
                 ,ROW_AR_CASH_TURNFEE_HEADER.OUT_SALES_CENTER_ID, ROW_AR_CASH_TURNFEE_HEADER.OUT_SALES_CENTER_CODE, ROW_AR_CASH_TURNFEE_HEADER.OUT_SALES_CENTER_NAME
            FROM V_CUST_ACCOUNT_CROSSOUTURNFEE T
            WHERE T.CUSTOMER_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.CUSTOMER_ID
                  AND T.ACCOUNT_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ACCOUNT_ID
                  AND T.ENTITY_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ENTITY_ID;**/
            -- 插入转款头
            INSERT INTO CIMS.T_AR_CASH_TURNFEE_HEADER VALUES ROW_AR_CASH_TURNFEE_HEADER;

            -- 转款行(马工方案：转款明细采用默认营销大类)
            ROW_AR_CASH_TURNFEE_LINE.CASH_TURNFEE_LINE_ID := S_AR_CASH_TURNFEE_LINE.NEXTVAL;
            ROW_AR_CASH_TURNFEE_LINE.CASH_TURNFEE_ID := V_CASH_TURNFEE_ID;
            ROW_AR_CASH_TURNFEE_LINE.AMOUNT := ROW_SO_NO_DIFF_SALE_MAIN_TYPE.AMOUNT;
            ROW_AR_CASH_TURNFEE_LINE.ENTITY_ID := ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ENTITY_ID;
            ROW_AR_CASH_TURNFEE_LINE.OUT_SALES_MAIN_TYPE_ID := V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_ID;
            ROW_AR_CASH_TURNFEE_LINE.OUT_SALES_MAIN_TYPE_CODE := V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE;
            ROW_AR_CASH_TURNFEE_LINE.OUT_SALES_MAIN_TYPE_NAME := V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_NAME;
            ROW_AR_CASH_TURNFEE_LINE.IN_SALES_MAIN_TYPE_ID := V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_ID;
            ROW_AR_CASH_TURNFEE_LINE.IN_SALES_MAIN_TYPE_CODE := V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE;
            ROW_AR_CASH_TURNFEE_LINE.IN_SALES_MAIN_TYPE_NAME := V_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_NAME;
            -- 插入转款行
            INSERT INTO CIMS.T_AR_CASH_TURNFEE_LINE VALUES ROW_AR_CASH_TURNFEE_LINE;

            /**FOR ROW_SO_NO_DIFF_SALE_MAIN_LINE IN (SELECT ORCO.IN_SALES_MAIN_TYPE_ID, ORCO.IN_SALES_MAIN_TYPE_CODE, ORCO.IN_SALES_MAIN_TYPE_NAME,
                                                    ORCO.OUT_SALES_MAIN_TYPE_ID, ORCO.OUT_SALES_MAIN_TYPE_CODE, ORCO.OUT_SALES_MAIN_TYPE_NAME, SUM(ORCO.AMOUNT) AS AMOUNT
                                              FROM CIMS.V_ORDER_RECEIPT_CROSS_OU ORCO
                                              WHERE ORCO.ENTITY_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ENTITY_ID
                                                    AND ORCO.CUSTOMER_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.CUSTOMER_ID
                                                    AND ORCO.ACCOUNT_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ACCOUNT_ID
                                                    AND ORCO.OUT_ERP_OU_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.OUT_ERP_OU_ID
                                                    AND ORCO.IN_ERP_OU_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.IN_ERP_OU_ID
                                              GROUP BY ORCO.IN_SALES_MAIN_TYPE_ID, ORCO.IN_SALES_MAIN_TYPE_CODE, ORCO.IN_SALES_MAIN_TYPE_NAME,
                                                    ORCO.OUT_SALES_MAIN_TYPE_ID, ORCO.OUT_SALES_MAIN_TYPE_CODE, ORCO.OUT_SALES_MAIN_TYPE_NAME) LOOP
              -- 转款行
              ROW_AR_CASH_TURNFEE_LINE.CASH_TURNFEE_LINE_ID := S_AR_CASH_TURNFEE_LINE.NEXTVAL;
              ROW_AR_CASH_TURNFEE_LINE.CASH_TURNFEE_ID := V_CASH_TURNFEE_ID;
              ROW_AR_CASH_TURNFEE_LINE.AMOUNT := ROW_SO_NO_DIFF_SALE_MAIN_LINE.AMOUNT;
              ROW_AR_CASH_TURNFEE_LINE.ENTITY_ID := ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ENTITY_ID;
              ROW_AR_CASH_TURNFEE_LINE.OUT_SALES_MAIN_TYPE_ID := ROW_SO_NO_DIFF_SALE_MAIN_LINE.OUT_SALES_MAIN_TYPE_ID;
              ROW_AR_CASH_TURNFEE_LINE.OUT_SALES_MAIN_TYPE_CODE := ROW_SO_NO_DIFF_SALE_MAIN_LINE.OUT_SALES_MAIN_TYPE_CODE;
              ROW_AR_CASH_TURNFEE_LINE.OUT_SALES_MAIN_TYPE_NAME := ROW_SO_NO_DIFF_SALE_MAIN_LINE.OUT_SALES_MAIN_TYPE_NAME;
              ROW_AR_CASH_TURNFEE_LINE.IN_SALES_MAIN_TYPE_ID := ROW_SO_NO_DIFF_SALE_MAIN_LINE.IN_SALES_MAIN_TYPE_ID;
              ROW_AR_CASH_TURNFEE_LINE.IN_SALES_MAIN_TYPE_CODE := ROW_SO_NO_DIFF_SALE_MAIN_LINE.IN_SALES_MAIN_TYPE_CODE;
              ROW_AR_CASH_TURNFEE_LINE.IN_SALES_MAIN_TYPE_NAME := ROW_SO_NO_DIFF_SALE_MAIN_LINE.IN_SALES_MAIN_TYPE_NAME;
              -- 插入转款行
              INSERT INTO CIMS.T_AR_CASH_TURNFEE_LINE VALUES ROW_AR_CASH_TURNFEE_LINE;
            END LOOP;**/

            -- 回写转款头ID至核销关系表
            UPDATE CIMS.T_SO_ORDER_RECEIPT R SET R.TMP_CASH_TURNFEE_ID = V_CASH_TURNFEE_ID
             ,LAST_UPDATE_DATE = SYSDATE
            WHERE EXISTS (SELECT ORCO.ORDER_RECEIPT_ID
                  FROM CIMS.V_AR_ORDER_RECEIPT_CROSS_OU ORCO
                  WHERE R.ORDER_RECEIPT_ID = ORCO.ORDER_RECEIPT_ID
                        AND ORCO.ENTITY_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ENTITY_ID
                        AND ORCO.CUSTOMER_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.CUSTOMER_ID
                        AND ORCO.ACCOUNT_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ACCOUNT_ID
                        AND ORCO.ACCOUNT_CODE = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ACCOUNT_CODE
                        AND ORCO.OUT_ERP_OU_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.OUT_ERP_OU_ID
                        AND ORCO.IN_ERP_OU_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.IN_ERP_OU_ID
                        AND ORCO.OUT_SALES_CENTER_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.OUT_SALES_CENTER_ID
                        AND ORCO.IN_SALES_CENTER_ID = ROW_SO_NO_DIFF_SALE_MAIN_TYPE.IN_SALES_CENTER_ID);
            COMMIT;
          EXCEPTION WHEN OTHERS THEN
            ROLLBACK;
            P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
            P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_CASH_TURNFEE_NEW', SQLCODE,
                    '不区分营销大类生成生成跨主体单据（制单状态）出错！主体：'||ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ENTITY_ID||
                    '、客户：'||ROW_SO_NO_DIFF_SALE_MAIN_TYPE.CUSTOMER_ID||
                    '、账户：'||ROW_SO_NO_DIFF_SALE_MAIN_TYPE.ACCOUNT_ID||
                    '、转出OU：'||ROW_SO_NO_DIFF_SALE_MAIN_TYPE.OUT_ERP_OU_ID||
                    '、转入OU：'||ROW_SO_NO_DIFF_SALE_MAIN_TYPE.IN_ERP_OU_ID||
                    '、转出营销中心ID：'||ROW_SO_NO_DIFF_SALE_MAIN_TYPE.OUT_SALES_CENTER_ID||
                    '、转入营销中心ID：'||ROW_SO_NO_DIFF_SALE_MAIN_TYPE.IN_SALES_CENTER_ID||
                    '。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
          END;
        END LOOP;
      END IF;
   -- END LOOP;
    P_RESULT := '生成生成跨主体单据（制单状态）成功！';
  EXCEPTION WHEN OTHERS THEN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_CASH_TURNFEE_NEW', SQLCODE,
            '生成生成跨主体单据（制单状态）出错！异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    RETURN ;
  END;

  /**
  ** 1、确认跨主体单据，
  ** 2、引关联交易
  ** 3、生成正负数收款
  ** 4、正数收款引ERP收款、负数收款引ERP发票
  ** 5、正负数收款分别原核销关系的应收、回款单据进行核销
  **/
  PROCEDURE P_AR_CASH_TURNFEE_COMMIT(
   IN_ENTITY_ID IN  NUMBER,  --主体 
       P_RESULT OUT VARCHAR2,
       P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息息
  ) IS
  V_OUT_CASH_RECEIPT_CODE             T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_CODE%TYPE;--转出收款单号（客户间）
  V_IN_CASH_RECEIPT_CODE              T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_CODE%TYPE;--转入收款单号（客户间）
  V_CASH_RECEIPT_CODE                 T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_CODE%TYPE;--收款单号（客户内）
  V_REL_INV_APPLY_HEADERS_TRX_NO      VARCHAR(32); --交易流水号：统一调用单位规则号”BDESBSERIALNO “进行生成
  V_TURNFEE_HEADER_AMOUNT             NUMBER;
  V_SO_ORDER_RECEIPT_AMOUNT           NUMBER;
--  V_AR_SALE_MAIN_TYPE               PKG_AR_WRITE_OFF.AR_SALE_MAIN_TYPE;--是否区分营销大类。Y：区分；N：不区分
   P_LOG_RESULT VARCHAR2(400);
   V_PARAM_ENTITY_ID NUMBER;

   V_LOG_MSG VARCHAR2(1000);  
  BEGIN
    P_MESSAGE  := PKG_AR_WRITE_OFF.V_SUCCESS;
    
    V_PARAM_ENTITY_ID := IN_ENTITY_ID;
    P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_CASH_TURNFEE_COMMIT', '-1','记录次数'||V_PARAM_ENTITY_ID);
    
    FOR ROW_CASH_TURNFEE_HEADER IN (
        -- 制单状态跨主体单据
       SELECT * FROM T_AR_CASH_TURNFEE_HEADER TH
        WHERE TH.ENTITY_ID = V_PARAM_ENTITY_ID 
          AND TH.STATUS = '1'
          AND EXISTS (SELECT * FROM CIMS.T_AR_RECEIPT_METHODS M
                    WHERE M.RECEIPT_METHOD_NAME = PKG_AR_WRITE_OFF.V_CROSS_OU_METHOD_NAME
                      AND TH.RECEIPT_METHOD_ID = M.RECEIPT_METHOD_ID)
      ) LOOP
      BEGIN
        -- 跨主体转款确认
        PKG_AR_BOND.P_TURNFEE_CONFIRM_WRITE_OFF(ROW_CASH_TURNFEE_HEADER.CASH_TURNFEE_ID, 'SYSTEM', P_MESSAGE,
                                      V_CASH_RECEIPT_CODE, V_OUT_CASH_RECEIPT_CODE, V_IN_CASH_RECEIPT_CODE);
        IF P_MESSAGE <> PKG_AR_WRITE_OFF.V_SUCCESS THEN
          RAISE PKG_AR_WRITE_OFF.V_BIZ_EXCEPTION;
        END IF;
        -- 跨主体转款引关联交易
        PKG_AR_BOND.P_CROSS_OU_CONNECT_TARNSACTION(ROW_CASH_TURNFEE_HEADER.CASH_TURNFEE_ID,
                                      P_MESSAGE, V_REL_INV_APPLY_HEADERS_TRX_NO);
        IF P_MESSAGE <> PKG_AR_WRITE_OFF.V_SUCCESS THEN
             RAISE PKG_AR_WRITE_OFF.V_BIZ_EXCEPTION;
        END IF;
        SELECT H.AMOUNT INTO V_TURNFEE_HEADER_AMOUNT FROM CIMS.T_AR_CASH_TURNFEE_HEADER H WHERE H.CASH_TURNFEE_ID = ROW_CASH_TURNFEE_HEADER.CASH_TURNFEE_ID;
        SELECT SUM(H.AMOUNT) INTO V_SO_ORDER_RECEIPT_AMOUNT FROM CIMS.T_SO_ORDER_RECEIPT H WHERE H.TMP_CASH_TURNFEE_ID = ROW_CASH_TURNFEE_HEADER.CASH_TURNFEE_ID;
        IF V_TURNFEE_HEADER_AMOUNT <> V_SO_ORDER_RECEIPT_AMOUNT THEN
        	P_MESSAGE := '生成的转款单金额与跨主体单据金额不相等。CASH_TURNFEE_ID：'||ROW_CASH_TURNFEE_HEADER.CASH_TURNFEE_ID;
          RAISE PKG_AR_WRITE_OFF.V_BIZ_EXCEPTION;
        END IF;
        -- 获取是否区分营销大类
--        V_AR_SALE_MAIN_TYPE := PKG_AR_WRITE_OFF.F_AR_DEFAULT_SALE_MAIN_TYPE(ROW_CASH_TURNFEE_HEADER.ENTITY_ID);
        -- 跨主体单据转出收款单与回款进行核销
        FOR ROW_SO_ORDER_RECEIPT IN (SELECT * FROM T_SO_ORDER_RECEIPT T WHERE T.TMP_CASH_TURNFEE_ID = ROW_CASH_TURNFEE_HEADER.CASH_TURNFEE_ID)
        LOOP
          -- 插入核销关系
          INSERT INTO T_SO_ORDER_RECEIPT
               (
                 ORDER_RECEIPT_ID                                      --核销id
                ,CASH_RECEIPT_ID                                       --收款单据id
                ,CASH_RECEIPT_LINES_ID                                 --收款单据行id
                ,RECEIPT_NUMBER
                ,ORDER_NUMBER
                ,SO_HEAD_ID                                            --财务单据id
                ,SO_HEAD_LINES_ID                                      --财务单行ID
                ,RECEIPT_TYPE                                          --回款单据类型
                ,ORDER_TYPE                                            --应收单据类型
                ,AMOUNT                                                --金额
                ,MATCH_DATE                                            --核销日期
                ,ORDER_DATE                                            --应收单据日期
                ,RECEIPT_DATE                                          --回款单据日期
                ,CUSROMER_CODE                                         --客户编码
                ,CUSROMER_NAME                                         --客户名称
                ,ENTITY_ID                                             --主体ID
                ,TO_ERP_FLAG                                           --是否引入ERP
                ,ACTIVE_FLAG                                           --是否有效(Y/N)
                ,SALES_MAIN_TYPE_ID
                ,SALES_MAIN_TYPE_CODE
                ,SALES_MAIN_TYPE_NAME
                ,REMARK
                ,ORDER_ERP_OU_ID                 --应收ERP OU ID
                ,RECEIPT_ERP_OU_ID               --回款ERP OU ID
                ,LAST_UPDATE_DATE
               )
               VALUES
               (
                  S_SO_ORDER_RECEIPT.NEXTVAL
                 ,ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_ID
                 ,ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_LINES_ID
                 ,ROW_SO_ORDER_RECEIPT.RECEIPT_NUMBER
                 ,V_OUT_CASH_RECEIPT_CODE
                 ,(SELECT H.CASH_RECEIPT_ID FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H WHERE H.CASH_RECEIPT_CODE = V_OUT_CASH_RECEIPT_CODE)
                 ,(SELECT DISTINCT HL.CASH_RECEIPT_LINES_ID FROM CIMS.V_AR_CASH_RECEIPT_HEADER_LINES HL WHERE HL.CASH_RECEIPT_CODE = V_OUT_CASH_RECEIPT_CODE AND HL.SALES_MAIN_TYPE_CODE = ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_CODE)
                 ,ROW_SO_ORDER_RECEIPT.RECEIPT_TYPE
                 ,'1'
                 ,ROW_SO_ORDER_RECEIPT.AMOUNT
                 ,TRUNC(SYSDATE,'DD')
                 ,TRUNC(SYSDATE,'DD')
                 ,TRUNC(SYSDATE,'DD')
                 ,ROW_SO_ORDER_RECEIPT.CUSROMER_CODE
                 ,ROW_SO_ORDER_RECEIPT.CUSROMER_NAME
                 ,ROW_SO_ORDER_RECEIPT.ENTITY_ID
                 ,PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N
                 ,PKG_AR_WRITE_OFF.V_YES
                 ,ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_ID
                 ,ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_CODE
                 ,ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_NAME
                 ,'跨主体转款单据('||ROW_CASH_TURNFEE_HEADER.CASH_TURNFEE_ID||')转出收款单与回款进行核销'
                 ,(SELECT H.ERP_OU_ID FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H WHERE H.CASH_RECEIPT_CODE = V_OUT_CASH_RECEIPT_CODE)
                 ,ROW_SO_ORDER_RECEIPT.RECEIPT_ERP_OU_ID
                 ,SYSDATE
               );
          -- 更新应收、回款单据核销状态
          UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS H SET H.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, H.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),UPDATED_DATE= SYSDATE
          WHERE H.CASH_RECEIPT_CODE = V_OUT_CASH_RECEIPT_CODE;
          UPDATE CIMS.T_SO_ORDER_RECEIPT R SET R.CASH_TURNFEE_ID = R.TMP_CASH_TURNFEE_ID ,LAST_UPDATE_DATE = SYSDATE WHERE R.ORDER_RECEIPT_ID = ROW_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
          IF ROW_SO_ORDER_RECEIPT.RECEIPT_TYPE = '1' THEN
          	UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS H SET H.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, H.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),UPDATED_DATE= SYSDATE
            WHERE H.CASH_RECEIPT_ID = ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_ID;
          ELSE
            UPDATE CIMS.T_SO_HEADER H SET H.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, H.APPLIED_DATE = SYSDATE,H.LAST_UPDATE_DATE=SYSDATE
            WHERE H.SO_HEADER_ID = ROW_SO_ORDER_RECEIPT.CASH_RECEIPT_ID;
          END IF;
        END LOOP;

        -- 跨主体单据转入收款单与应收进行核销
        FOR ROW_SO_ORDER_RECEIPT IN (SELECT * FROM T_SO_ORDER_RECEIPT T WHERE T.TMP_CASH_TURNFEE_ID = ROW_CASH_TURNFEE_HEADER.CASH_TURNFEE_ID)
        LOOP
          -- 插入核销关系
          INSERT INTO T_SO_ORDER_RECEIPT
               (
                 ORDER_RECEIPT_ID                                      --核销id
                ,CASH_RECEIPT_ID                                       --收款单据id
                ,CASH_RECEIPT_LINES_ID                                 --收款单据行id
                ,RECEIPT_NUMBER
                ,ORDER_NUMBER
                ,SO_HEAD_ID                                            --财务单据id
                ,SO_HEAD_LINES_ID                                      --财务单行ID
                ,RECEIPT_TYPE                                          --回款单据类型
                ,ORDER_TYPE                                            --应收单据类型
                ,AMOUNT                                                --金额
                ,MATCH_DATE                                            --核销日期
                ,ORDER_DATE                                            --应收单据日期
                ,RECEIPT_DATE                                          --回款单据日期
                ,CUSROMER_CODE                                         --客户编码
                ,CUSROMER_NAME                                         --客户名称
                ,ENTITY_ID                                             --主体ID
                ,TO_ERP_FLAG                                           --是否引入ERP
                ,ACTIVE_FLAG                                           --是否有效(Y/N)
                ,SALES_MAIN_TYPE_ID
                ,SALES_MAIN_TYPE_CODE
                ,SALES_MAIN_TYPE_NAME
                ,REMARK
                ,ORDER_ERP_OU_ID                 --应收ERP OU ID
                ,RECEIPT_ERP_OU_ID               --回款ERP OU ID
                ,LAST_UPDATE_DATE
               )
               VALUES
               (
                S_SO_ORDER_RECEIPT.NEXTVAL
               ,(SELECT H.CASH_RECEIPT_ID FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H WHERE H.CASH_RECEIPT_CODE = V_IN_CASH_RECEIPT_CODE)
               ,(SELECT DISTINCT HL.CASH_RECEIPT_LINES_ID FROM CIMS.V_AR_CASH_RECEIPT_HEADER_LINES HL WHERE HL.CASH_RECEIPT_CODE = V_IN_CASH_RECEIPT_CODE AND HL.SALES_MAIN_TYPE_CODE = ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_CODE)
               ,V_IN_CASH_RECEIPT_CODE
               ,ROW_SO_ORDER_RECEIPT.ORDER_NUMBER
               ,ROW_SO_ORDER_RECEIPT.SO_HEAD_ID
               ,ROW_SO_ORDER_RECEIPT.SO_HEAD_LINES_ID
               ,'1'
               ,ROW_SO_ORDER_RECEIPT.ORDER_TYPE
               ,ROW_SO_ORDER_RECEIPT.AMOUNT
               ,TRUNC(SYSDATE,'DD')
               ,TRUNC(SYSDATE,'DD')
               ,TRUNC(SYSDATE,'DD')
               ,ROW_SO_ORDER_RECEIPT.CUSROMER_CODE
               ,ROW_SO_ORDER_RECEIPT.CUSROMER_NAME
               ,ROW_SO_ORDER_RECEIPT.ENTITY_ID
               ,PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N
               ,PKG_AR_WRITE_OFF.V_YES
               ,ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_ID
               ,ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_CODE
               ,ROW_SO_ORDER_RECEIPT.SALES_MAIN_TYPE_NAME
               ,'跨主体转款单据('||ROW_CASH_TURNFEE_HEADER.CASH_TURNFEE_ID||')转入收款单与应收进行核销'
               ,ROW_SO_ORDER_RECEIPT.ORDER_ERP_OU_ID
               ,(SELECT H.ERP_OU_ID FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H WHERE H.CASH_RECEIPT_CODE = V_IN_CASH_RECEIPT_CODE)
               ,SYSDATE
           );
          -- 更新应收、回款单据核销状态
          UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS H SET H.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, H.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),UPDATED_DATE= SYSDATE
          WHERE H.CASH_RECEIPT_CODE = V_IN_CASH_RECEIPT_CODE;
          UPDATE CIMS.T_SO_ORDER_RECEIPT R SET R.CASH_TURNFEE_ID = R.TMP_CASH_TURNFEE_ID ,LAST_UPDATE_DATE = SYSDATE WHERE R.ORDER_RECEIPT_ID = ROW_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
          IF ROW_SO_ORDER_RECEIPT.RECEIPT_TYPE = '1' THEN
          	UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS H SET H.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, H.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),UPDATED_DATE= SYSDATE
            WHERE H.CASH_RECEIPT_ID = ROW_SO_ORDER_RECEIPT.SO_HEAD_ID;
          ELSE
            UPDATE CIMS.T_SO_HEADER H SET H.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, H.APPLIED_DATE = SYSDATE,H.LAST_UPDATE_DATE=SYSDATE
            WHERE H.SO_HEADER_ID = ROW_SO_ORDER_RECEIPT.SO_HEAD_ID;
          END IF;
        END LOOP;
        COMMIT;
      EXCEPTION
        WHEN PKG_AR_WRITE_OFF.V_BIZ_EXCEPTION THEN
          ROLLBACK;
          P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_CASH_TURNFEE_COMMIT', SQLCODE,
                  V_PARAM_ENTITY_ID||'确认跨主体单据出错！转款单据号：'||ROW_CASH_TURNFEE_HEADER.CASH_TURNFEE_CODE||'。异常消息：'||P_MESSAGE|| substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
          P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
            
          V_LOG_MSG := '单据主体:'||ROW_CASH_TURNFEE_HEADER.ENTITY_ID
                       ||'单据ID:'||ROW_CASH_TURNFEE_HEADER.CASH_TURNFEE_ID
                       ||'error记录次数'||V_PARAM_ENTITY_ID;
          --记录临时日志
          P_LOG_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_CASH_TURNFEE_COMMIT', '-1',V_LOG_MSG);
          
        WHEN OTHERS THEN
          ROLLBACK;
          P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
          P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_CASH_TURNFEE_COMMIT', SQLCODE,
                  V_PARAM_ENTITY_ID||'确认跨主体单据出错！转款单据号：'||ROW_CASH_TURNFEE_HEADER.CASH_TURNFEE_CODE||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
      END;
    END LOOP;
    P_RESULT := '确认跨主体单据并引关联交易成功！';
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_CASH_TURNFEE_COMMIT', SQLCODE,
            '确认跨主体单据出错！异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    RETURN ;
  END;

  --核销接口表插入【erp】
  PROCEDURE P_SO_ORDER_RECEIPT_TO_ERP
  (
     IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
  V_IN_TRX_NO                VARCHAR2(32);--核销接口表(交易流水号)
  V_TRX_ID                   NUMBER;
  ROW_AR_WRITEOFF            INTF_AR_WRITEOFF%ROWTYPE;
  ROW_AR_WRITEOFF_INV        INTF_AR_WRITEOFF_INV%ROWTYPE;
  
       V_PARAM_ENTITY_ID NUMBER;
  
  -- 收款核销发票 INTF_AR_WRITEOFF
  CURSOR CUR_ORDER_RECEIPT_WO IS
       SELECT RH.AR_RECEIPT_CODE AS WRITEOFF_CASH_RECEIPT_ID,
             RH.CASH_RECEIPT_CODE AS WRITEOFF_RECEIPT_NUMBER,
             RH.ERP_OU_ID AS WRITEOFF_ORG_ID,
             RH.AMOUNT AS WRITEOFF_AMOUNT,
             OH.INVOICE_HEADER_ID AS WRITEOFF_CUSTOMER_TRX_ID,
             OH.CASH_RECEIPT_CODE AS WRITEOFF_TRX_NUMBER,
             GREATEST(RH.REVIEWED_DATE, OH.REVIEWED_DATE) AS WRITEOFF_APPLIED_DATE,
             R.*
      FROM CIMS.T_SO_ORDER_RECEIPT R
      LEFT JOIN CIMS.T_AR_CASH_RECEIPT_HEADERS RH ON R.CASH_RECEIPT_ID = RH.CASH_RECEIPT_ID
      LEFT JOIN CIMS.T_AR_CASH_RECEIPT_HEADERS OH ON R.SO_HEAD_ID = OH.CASH_RECEIPT_ID
      WHERE R.RECEIPT_TYPE = '1' AND R.ORDER_TYPE = '1' AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_NO
            AND RH.AR_RECEIPT_CODE IS NOT NULL
            AND OH.INVOICE_HEADER_ID IS NOT NULL
            AND R.ENTITY_ID = V_PARAM_ENTITY_ID
      UNION
      SELECT  RH.AR_RECEIPT_CODE AS WRITEOFF_CASH_RECEIPT_ID,
             RH.CASH_RECEIPT_CODE AS WRITEOFF_RECEIPT_NUMBER,
             RH.ERP_OU_ID AS WRITEOFF_ORG_ID,
             RH.AMOUNT AS WRITEOFF_AMOUNT,
             OH.ERP_ARINVOICE_ID AS WRITEOFF_CUSTOMER_TRX_ID,
             OH.ERP_ARINVOICE_CODE AS WRITEOFF_TRX_NUMBER,
             GREATEST(RH.REVIEWED_DATE, OH.SETTLE_DATE) AS WRITEOFF_APPLIED_DATE,
            R.*
      FROM CIMS.T_SO_ORDER_RECEIPT R
      LEFT JOIN CIMS.T_AR_CASH_RECEIPT_HEADERS RH ON R.CASH_RECEIPT_ID = RH.CASH_RECEIPT_ID
      LEFT JOIN CIMS.T_SO_HEADER OH ON R.SO_HEAD_ID = OH.SO_HEADER_ID
      WHERE R.RECEIPT_TYPE = '1' AND R.ORDER_TYPE <> '1' AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_NO
            AND RH.AR_RECEIPT_CODE IS NOT NULL
            AND OH.ERP_ARINVOICE_ID IS NOT NULL
            AND R.ENTITY_ID = V_PARAM_ENTITY_ID;
            
  -- 发票核销发票 INTF_AR_WRITEOFF_INV
  CURSOR CUR_ORDER_RECEIPT_WO_INV IS
      SELECT RH.ERP_ARINVOICE_ID AS WRITEOFF_INV_CASH_ID,
             RH.ERP_ARINVOICE_CODE AS WRITEOFF_INV_CM_TRX_NUMBER,
             RH.ERP_OU_ID AS WRITEOFF_INV_ORG_ID,
             OH.ERP_ARINVOICE_ID AS WRITEOFF_INV_AR_ID,
             OH.ERP_ARINVOICE_CODE AS WRITEOFF_INV_TRX_NUMBER,
             GREATEST(RH.SETTLE_DATE, OH.SETTLE_DATE) AS WRITEOFF_INV_APPLIED_DATE,
             R.*
      FROM CIMS.T_SO_ORDER_RECEIPT R
      LEFT JOIN CIMS.T_SO_HEADER RH ON R.CASH_RECEIPT_ID = RH.SO_HEADER_ID
      LEFT JOIN CIMS.T_SO_HEADER OH ON R.SO_HEAD_ID = OH.SO_HEADER_ID
      WHERE R.RECEIPT_TYPE <> '1' AND R.ORDER_TYPE <> '1' AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_NO
            AND RH.ERP_ARINVOICE_ID IS NOT NULL
            AND OH.ERP_ARINVOICE_ID IS NOT NULL
            AND R.ENTITY_ID = V_PARAM_ENTITY_ID
      UNION
      SELECT RH.ERP_ARINVOICE_ID AS WRITEOFF_INV_CASH_ID,
             RH.ERP_ARINVOICE_CODE AS WRITEOFF_INV_CM_TRX_NUMBER,
             RH.ERP_OU_ID AS WRITEOFF_INV_ORG_ID,
             OH.INVOICE_HEADER_ID AS WRITEOFF_INV_AR_ID,
             OH.CASH_RECEIPT_CODE AS WRITEOFF_INV_TRX_NUMBER,
             GREATEST(RH.SETTLE_DATE, OH.REVIEWED_DATE) AS WRITEOFF_INV_APPLIED_DATE,
             R.*
      FROM CIMS.T_SO_ORDER_RECEIPT R
      LEFT JOIN CIMS.T_SO_HEADER RH ON R.CASH_RECEIPT_ID = RH.SO_HEADER_ID
      LEFT JOIN CIMS.T_AR_CASH_RECEIPT_HEADERS OH ON R.SO_HEAD_ID = OH.CASH_RECEIPT_ID
      WHERE R.RECEIPT_TYPE <> '1' AND R.ORDER_TYPE = '1' AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_NO
            AND RH.ERP_ARINVOICE_ID IS NOT NULL
            AND OH.INVOICE_HEADER_ID IS NOT NULL
            AND R.ENTITY_ID = V_PARAM_ENTITY_ID
      UNION
      SELECT RH.INVOICE_HEADER_ID AS WRITEOFF_INV_CASH_ID,
                 RH.CASH_RECEIPT_CODE AS WRITEOFF_INV_CM_TRX_NUMBER,
                 RH.ERP_OU_ID AS WRITEOFF_INV_ORG_ID,
                 OH.INVOICE_HEADER_ID AS WRITEOFF_INV_AR_ID,
                 OH.CASH_RECEIPT_CODE AS WRITEOFF_INV_TRX_NUMBER,
                 GREATEST(RH.REVIEWED_DATE, OH.REVIEWED_DATE) AS WRITEOFF_INV_APPLIED_DATE,
                 R.*
         FROM CIMS.T_SO_ORDER_RECEIPT R
         LEFT JOIN CIMS.T_AR_CASH_RECEIPT_HEADERS RH ON R.CASH_RECEIPT_ID = RH.CASH_RECEIPT_ID
         LEFT JOIN CIMS.T_AR_CASH_RECEIPT_HEADERS OH ON R.SO_HEAD_ID = OH.CASH_RECEIPT_ID
         WHERE R.RECEIPT_TYPE = '1' AND R.ORDER_TYPE = '1' AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_NO
                AND RH.INVOICE_HEADER_ID IS NOT NULL
                AND OH.INVOICE_HEADER_ID IS NOT NULL
                AND R.ENTITY_ID = V_PARAM_ENTITY_ID        
       UNION
       SELECT  RH.INVOICE_HEADER_ID AS WRITEOFF_INV_CASH_ID,
               RH.CASH_RECEIPT_CODE AS WRITEOFF_INV_CM_TRX_NUMBER,
               RH.ERP_OU_ID AS WRITEOFF_INV_ORG_ID,
               OH.ERP_ARINVOICE_ID AS WRITEOFF_INV_AR_ID,
               OH.ERP_ARINVOICE_CODE AS WRITEOFF_INV_TRX_NUMBER,
               GREATEST(RH.REVIEWED_DATE, OH.SETTLE_DATE) AS WRITEOFF_INV_APPLIED_DATE,
              R.*
        FROM CIMS.T_SO_ORDER_RECEIPT R
        LEFT JOIN CIMS.T_AR_CASH_RECEIPT_HEADERS RH ON R.CASH_RECEIPT_ID = RH.CASH_RECEIPT_ID
        LEFT JOIN CIMS.T_SO_HEADER OH ON R.SO_HEAD_ID = OH.SO_HEADER_ID
        WHERE R.RECEIPT_TYPE = '1' AND R.ORDER_TYPE <> '1' AND R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_NO
              AND RH.INVOICE_HEADER_ID IS NOT NULL
              AND OH.ERP_ARINVOICE_ID IS NOT NULL
              AND R.ENTITY_ID = V_PARAM_ENTITY_ID;        
            
             
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    V_PARAM_ENTITY_ID := IN_ENTITY_ID;
    -- RECEIPT_TYPE = 1 【收款核销发票 INTF_AR_WRITEOFF】
    FOR ROW_SO_ORDER_RECEIPT IN CUR_ORDER_RECEIPT_WO LOOP
    	BEGIN
        SELECT S_INTF_AR_WRITEOFF.NEXTVAL INTO V_TRX_ID FROM DUAL ;
        ROW_AR_WRITEOFF.CASH_RECEIPT_ID := ROW_SO_ORDER_RECEIPT.WRITEOFF_CASH_RECEIPT_ID;
        ROW_AR_WRITEOFF.RECEIPT_NUMBER := ROW_SO_ORDER_RECEIPT.WRITEOFF_RECEIPT_NUMBER;
        ROW_AR_WRITEOFF.CUSTOMER_TRX_ID := ROW_SO_ORDER_RECEIPT.WRITEOFF_CUSTOMER_TRX_ID;
        ROW_AR_WRITEOFF.TRX_NUMBER := ROW_SO_ORDER_RECEIPT.WRITEOFF_TRX_NUMBER;
        ROW_AR_WRITEOFF.ORG_ID := ROW_SO_ORDER_RECEIPT.WRITEOFF_ORG_ID;
        ROW_AR_WRITEOFF.AMOUNT := ROW_SO_ORDER_RECEIPT.WRITEOFF_AMOUNT;
        ROW_AR_WRITEOFF.APPLIED_AMOUNT := ROW_SO_ORDER_RECEIPT.AMOUNT;
        ROW_AR_WRITEOFF.APPLIED_GL_DATE := TRUNC(SYSDATE-1, 'DD');
        ROW_AR_WRITEOFF.APPLIED_DATE := ROW_SO_ORDER_RECEIPT.WRITEOFF_APPLIED_DATE;
        -- 交易流水号
        PKG_BD.P_GET_BILL_NO('BdEsbSerialNo', NULL, ROW_SO_ORDER_RECEIPT.ENTITY_ID, NULL, V_IN_TRX_NO);
        ROW_AR_WRITEOFF.TRX_NO := V_IN_TRX_NO;
        ROW_AR_WRITEOFF.INTF_STATUS := PKG_AR_WRITE_OFF.V_NO;
        ROW_AR_WRITEOFF.CURRENCY_CODE := 'CNY';
        ROW_AR_WRITEOFF.TRX_CURRENCY_CODE := 'CNY';
        ROW_AR_WRITEOFF.CUSTOMER_NUMBER := ROW_SO_ORDER_RECEIPT.CUSROMER_CODE;
        ROW_AR_WRITEOFF.CUSTOMER_NAME := ROW_SO_ORDER_RECEIPT.CUSROMER_NAME;
        ROW_AR_WRITEOFF.CUSTOMER_ID := ROW_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
        ROW_AR_WRITEOFF.CREATED_BY := 'SYSTEM';
        ROW_AR_WRITEOFF.CREATION_DATE := TRUNC(SYSDATE, 'DD');
        ROW_AR_WRITEOFF.LAST_UPDATED_BY := 'SYSTEM';
        ROW_AR_WRITEOFF.LAST_UPDATE_DATE := TRUNC(SYSDATE, 'DD');
        ROW_AR_WRITEOFF.TRX_ID := V_TRX_ID;
        ROW_AR_WRITEOFF.SOURCE_NUM := V_TRX_ID;
        ROW_AR_WRITEOFF.ORDER_RECEIPT_ID := ROW_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
        ROW_AR_WRITEOFF.START_PUSH_TO_ERP := PKG_AR_WRITE_OFF.V_NO;
        ROW_AR_WRITEOFF.CANCEL_FLAG := PKG_AR_WRITE_OFF.V_NO;
        ROW_AR_WRITEOFF.HANDLE_FLAG := PKG_AR_WRITE_OFF.V_NO;
        INSERT INTO INTF_AR_WRITEOFF VALUES ROW_AR_WRITEOFF;
        -- 修改核销关系引入ERP状态
        UPDATE T_SO_ORDER_RECEIPT T SET T.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y
        WHERE T.ORDER_RECEIPT_ID = ROW_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
        COMMIT;
      EXCEPTION WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
        P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_ORDER_RECEIPT_TO_ERP', SQLCODE,
                '收款核销发票(INTF_AR_WRITEOFF)引ERP出错！核销关系ID：'||ROW_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
      END;
    END LOOP;

    --RECEIPT_TYPE<>1 【发票核销发票】【INTF_AR_WRITEOFF_INV】
    FOR ROW_SO_ORDER_RECEIPT IN CUR_ORDER_RECEIPT_WO_INV LOOP
    	BEGIN
        SELECT S_INTF_AR_WRITEOFF_INV.NEXTVAL INTO V_TRX_ID FROM DUAL ;
        ROW_AR_WRITEOFF_INV.CM_TRX_NUMBER := ROW_SO_ORDER_RECEIPT.WRITEOFF_INV_CM_TRX_NUMBER;
        ROW_AR_WRITEOFF_INV.INVOICE_TRX_NUMBER := ROW_SO_ORDER_RECEIPT.WRITEOFF_INV_TRX_NUMBER;
        ROW_AR_WRITEOFF_INV.ORG_ID := ROW_SO_ORDER_RECEIPT.WRITEOFF_INV_ORG_ID;
        ROW_AR_WRITEOFF_INV.APPLIED_AMOUNT := ROW_SO_ORDER_RECEIPT.AMOUNT;
        ROW_AR_WRITEOFF_INV.GL_DATE := TO_CHAR(TRUNC(SYSDATE-1, 'DD'), 'YYYY-MM-DD');
        ROW_AR_WRITEOFF_INV.APPLY_DATE := TO_CHAR(ROW_SO_ORDER_RECEIPT.WRITEOFF_INV_APPLIED_DATE, 'YYYY-MM-DD');
        -- 交易流水号
        PKG_BD.P_GET_BILL_NO('BdEsbSerialNo', NULL, ROW_SO_ORDER_RECEIPT.ENTITY_ID, NULL, V_IN_TRX_NO);
        ROW_AR_WRITEOFF_INV.TRX_NO := V_IN_TRX_NO;
        ROW_AR_WRITEOFF_INV.INTF_STATUS := PKG_AR_WRITE_OFF.V_NO;
        ROW_AR_WRITEOFF_INV.CUSTOMER_NUMBER := ROW_SO_ORDER_RECEIPT.CUSROMER_CODE;
        ROW_AR_WRITEOFF_INV.CUSTOMER_NAME := ROW_SO_ORDER_RECEIPT.CUSROMER_NAME;
        ROW_AR_WRITEOFF_INV.CUSTOMER_ID := ROW_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
        ROW_AR_WRITEOFF_INV.CREATED_BY := 'SYSTEM';
        ROW_AR_WRITEOFF_INV.CREATION_DATE := TRUNC(SYSDATE, 'DD');
        ROW_AR_WRITEOFF_INV.LAST_UPDATED_BY := 'SYSTEM';
        ROW_AR_WRITEOFF_INV.LAST_UPDATE_DATE := TRUNC(SYSDATE, 'DD');
        ROW_AR_WRITEOFF_INV.TRX_ID := V_TRX_ID;
        ROW_AR_WRITEOFF_INV.SOURCE_NUM := V_TRX_ID;
        ROW_AR_WRITEOFF_INV.ORDER_RECEIPT_ID := ROW_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
        ROW_AR_WRITEOFF_INV.START_PUSH_TO_ERP := PKG_AR_WRITE_OFF.V_NO;
        ROW_AR_WRITEOFF_INV.CANCEL_FLAG := PKG_AR_WRITE_OFF.V_NO;
        ROW_AR_WRITEOFF_INV.HANDLE_FLAG := PKG_AR_WRITE_OFF.V_NO;
        INSERT INTO INTF_AR_WRITEOFF_INV VALUES ROW_AR_WRITEOFF_INV;
        -- 修改核销关系引入ERP状态
        UPDATE T_SO_ORDER_RECEIPT T SET T.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y
        WHERE T.ORDER_RECEIPT_ID = ROW_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID;
        COMMIT;
      EXCEPTION WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
        P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_ORDER_RECEIPT_TO_ERP', SQLCODE,
                '发票核销发票(INTF_AR_WRITEOFF_INV)引ERP出错！核销关系ID：'||ROW_SO_ORDER_RECEIPT.ORDER_RECEIPT_ID||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
      END;
    END LOOP;
    P_RESULT := '核销引ERP成功！';
  EXCEPTION WHEN OTHERS THEN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_ORDER_RECEIPT_TO_ERP', SQLCODE,
            '核销引ERP出错！异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    RETURN ;
  END;

  -- 核销关系推送ERP校验。一张收款单和一张财务单只能核销一次
  PROCEDURE P_SO_ORDER_RECEIPT_ERP_CHECK
  (
     IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
  ROW_AR_WRITEOFF                INTF_AR_WRITEOFF%ROWTYPE;
  ROW_AR_WRITEOFF_INV            INTF_AR_WRITEOFF_INV%ROWTYPE;
  V_BDESBSERIALNO                VARCHAR2(32);
  V_ENTITY                       NUMBER;
  V_COUNT                        NUMBER;
  V_ID                           NUMBER;
     V_PARAM_ENTITY_ID NUMBER;
  BEGIN
   P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
   V_PARAM_ENTITY_ID :=IN_ENTITY_ID;
   
    -- 收款到发票推送ERP校验(INTF_AR_WRITEOFF)
    FOR ROW_AR_WRITEOFF_NUMBER IN (SELECT I.ORG_ID, I.RECEIPT_NUMBER, I.TRX_NUMBER, SUM(APPLIED_AMOUNT) AS TOTAL_MATCH_AMOUNT, COUNT(*)
                           FROM CIMS.INTF_AR_WRITEOFF I,CIMS.T_SO_ORDER_RECEIPT R
                           WHERE  I.ORDER_RECEIPT_ID = R.ORDER_RECEIPT_ID
                                 AND I.ORDER_RECEIPT_ID IS NOT NULL -- 新生成汇总的核销关系没有ORDER_RECEIPT_ID
                                 AND R.TO_ERP_FLAG='Y'
                                 AND R.ENTITY_ID = V_PARAM_ENTITY_ID
                                 AND EXISTS (SELECT 1 FROM CIMS.INTF_AR_WRITEOFF IW
                                            WHERE I.ORG_ID = IW.ORG_ID AND I.RECEIPT_NUMBER = IW.RECEIPT_NUMBER
                                                  AND I.TRX_NUMBER = IW.TRX_NUMBER AND IW.INTF_STATUS = 'N')
                           GROUP BY I.ORG_ID, I.RECEIPT_NUMBER, I.TRX_NUMBER
                           HAVING COUNT(*) > 1) LOOP
      BEGIN
        SELECT COUNT(*) INTO V_COUNT FROM CIMS.INTF_AR_WRITEOFF I
        WHERE I.ORDER_RECEIPT_ID IS NOT NULL
              AND I.INTF_STATUS <> 'S'
              AND I.ORG_ID = ROW_AR_WRITEOFF_NUMBER.ORG_ID
              AND I.RECEIPT_NUMBER = ROW_AR_WRITEOFF_NUMBER.RECEIPT_NUMBER
              AND I.TRX_NUMBER = ROW_AR_WRITEOFF_NUMBER.TRX_NUMBER;
        IF V_COUNT > 0 THEN
          SELECT S_AR_WRITE_OFF.NEXTVAL INTO V_ID FROM DUAL;
          -- 原核销关系已经发送ERP需取消推送ERP
          UPDATE CIMS.INTF_AR_WRITEOFF I
          SET I.AFTER_CANCEL_TRX_ID = V_ID
             ,I.CANCEL_FLAG = 'Y'
             ,I.HANDLE_FLAG = 'N'
             ,I.INTF_STATUS = 'S' -- 需取消的核销关系接口状态设置为S
             ,I.COMMENTS = I.COMMENTS||'#核销关系取消，新核销关系：'||V_ID
          WHERE I.RECEIPT_NUMBER = ROW_AR_WRITEOFF_NUMBER.RECEIPT_NUMBER
                AND I.TRX_NUMBER = ROW_AR_WRITEOFF_NUMBER.TRX_NUMBER
                AND I.ORG_ID = ROW_AR_WRITEOFF_NUMBER.ORG_ID;
          -- 获取主体
          SELECT DISTINCT H.ENTITY_ID INTO V_ENTITY
          FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
          WHERE H.CASH_RECEIPT_CODE = ROW_AR_WRITEOFF_NUMBER.RECEIPT_NUMBER
                AND H.ERP_OU_ID = ROW_AR_WRITEOFF_NUMBER.ORG_ID;
          -- 生成ESB交易流水号
          PKG_BD.P_GET_BILL_NO('BdEsbSerialNo', NULL, V_ENTITY, NULL, V_BDESBSERIALNO);
          -- 生成新的核销关系
          SELECT V_ID
                ,V_ID
                ,V_BDESBSERIALNO            --交易流水号：统一调用单位规则号”BDESBSERIALNO 进行生成
                ,'Q'                        --接口处理状态(固定值'N')
                ,ORG_ID                     --取OU_ID
                ,RECEIPT_NUMBER             --收款编号
                ,'CNY'                      --币种(固定值'CNY')
                ,AMOUNT                     --收款金额
                ,CUSTOMER_TRX_ID            --AR发票头ID '+'转入【财务单据ERP_ARINVOICE_ID  ERP(AR)发票头ID】)
                ,'CNY'                      --发票核销币种(固定值'CNY')
                ,ROW_AR_WRITEOFF_NUMBER.TOTAL_MATCH_AMOUNT         --本次核销金额
                ,APPLIED_GL_DATE            --核销总账日期
                ,APPLIED_DATE               --核销日期
                ,CUSTOMER_NUMBER            --客户编码
                ,CUSTOMER_NAME              --客户名称
                ,TRX_NUMBER                 --发票编号'+’转入【财务单据ERP_ARINVOICE_CODE   ERP应收(AR)发票号】)
                ,CASH_RECEIPT_ID            --收款表ID
                ,'SYSTEM'                   --创建人
                ,TRUNC(SYSDATE,'DD')        --创建时间
                ,'SYSTEM'                   --最后修改人
                ,TRUNC(SYSDATE,'DD')        --最后修改时间
               ,'Y'                         --是否开始推送ERP。Y：开始推送，N暂不推送
               ,'N'                         --是否取消推送ERP。Y：取消推送，N不取消推送
               ,'Y'
          INTO ROW_AR_WRITEOFF.TRX_ID
               ,ROW_AR_WRITEOFF.SOURCE_NUM
               ,ROW_AR_WRITEOFF.TRX_NO
               ,ROW_AR_WRITEOFF.INTF_STATUS
               ,ROW_AR_WRITEOFF.ORG_ID
               ,ROW_AR_WRITEOFF.RECEIPT_NUMBER
               ,ROW_AR_WRITEOFF.CURRENCY_CODE
               ,ROW_AR_WRITEOFF.AMOUNT
               ,ROW_AR_WRITEOFF.CUSTOMER_TRX_ID
               ,ROW_AR_WRITEOFF.TRX_CURRENCY_CODE
               ,ROW_AR_WRITEOFF.APPLIED_AMOUNT
               ,ROW_AR_WRITEOFF.APPLIED_GL_DATE
               ,ROW_AR_WRITEOFF.APPLIED_DATE
               ,ROW_AR_WRITEOFF.CUSTOMER_NUMBER
               ,ROW_AR_WRITEOFF.CUSTOMER_NAME
               ,ROW_AR_WRITEOFF.TRX_NUMBER
               ,ROW_AR_WRITEOFF.CASH_RECEIPT_ID
               ,ROW_AR_WRITEOFF.CREATED_BY
               ,ROW_AR_WRITEOFF.CREATION_DATE
               ,ROW_AR_WRITEOFF.LAST_UPDATED_BY
               ,ROW_AR_WRITEOFF.LAST_UPDATE_DATE
               ,ROW_AR_WRITEOFF.START_PUSH_TO_ERP
               ,ROW_AR_WRITEOFF.CANCEL_FLAG
               ,ROW_AR_WRITEOFF.HANDLE_FLAG
          FROM (SELECT * FROM CIMS.INTF_AR_WRITEOFF IAW
                WHERE IAW.RECEIPT_NUMBER = ROW_AR_WRITEOFF_NUMBER.RECEIPT_NUMBER
                      AND IAW.TRX_NUMBER = ROW_AR_WRITEOFF_NUMBER.TRX_NUMBER
                      AND IAW.ORG_ID = ROW_AR_WRITEOFF_NUMBER.ORG_ID
                      AND IAW.ORDER_RECEIPT_ID IS NOT NULL -- 新生成汇总的核销关系没有ORDER_RECEIPT_ID
                ORDER BY IAW.CREATION_DATE DESC
                ) I
          WHERE ROWNUM = 1;
          -- 插入新的汇总核销关系
          INSERT INTO INTF_AR_WRITEOFF VALUES ROW_AR_WRITEOFF;
          COMMIT;
        END IF;
      EXCEPTION WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
        P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_ORDER_RECEIPT_ERP_CHECK',
          SQLCODE,
          '生成汇总核销关系失败！ORG_ID：'||ROW_AR_WRITEOFF_NUMBER.ORG_ID||'，RECEIPT_NUMBER：'||ROW_AR_WRITEOFF_NUMBER.RECEIPT_NUMBER||'，TRX_NUMBER：'||ROW_AR_WRITEOFF_NUMBER.TRX_NUMBER||
          '。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
      END;
    END LOOP;

    -- 发票到发票推送ERP校验(INTF_AR_WRITEOFF_INV)
    FOR ROW_AR_WRITEOFF_INV_NUMBER IN (SELECT I.ORG_ID, I.CM_TRX_NUMBER, I.INVOICE_TRX_NUMBER, SUM(APPLIED_AMOUNT) AS TOTAL_MATCH_AMOUNT, COUNT(*)
                           FROM CIMS.INTF_AR_WRITEOFF_INV I,CIMS.T_SO_ORDER_RECEIPT R
                           WHERE I.ORDER_RECEIPT_ID = R.ORDER_RECEIPT_ID
                                 AND R.TO_ERP_FLAG='Y'
                                 AND R.ENTITY_ID = V_PARAM_ENTITY_ID
                                 AND I.ORDER_RECEIPT_ID IS NOT NULL -- 新生成汇总的核销关系没有ORDER_RECEIPT_ID
                                 AND EXISTS (SELECT * FROM CIMS.INTF_AR_WRITEOFF_INV IW
                                            WHERE I.ORG_ID = IW.ORG_ID AND I.CM_TRX_NUMBER = IW.CM_TRX_NUMBER
                                                  AND I.INVOICE_TRX_NUMBER = IW.INVOICE_TRX_NUMBER AND IW.INTF_STATUS = 'N')
                           GROUP BY I.ORG_ID, I.CM_TRX_NUMBER, I.INVOICE_TRX_NUMBER
                           HAVING COUNT(*) > 1) LOOP
      BEGIN
        SELECT COUNT(*) INTO V_COUNT FROM CIMS.INTF_AR_WRITEOFF_INV I
        WHERE I.ORDER_RECEIPT_ID IS NOT NULL
              AND I.INTF_STATUS <> 'S'
              AND I.ORG_ID = ROW_AR_WRITEOFF_INV_NUMBER.ORG_ID
              AND I.CM_TRX_NUMBER = ROW_AR_WRITEOFF_INV_NUMBER.CM_TRX_NUMBER
              AND I.INVOICE_TRX_NUMBER = ROW_AR_WRITEOFF_INV_NUMBER.INVOICE_TRX_NUMBER;
        IF V_COUNT > 0 THEN
          SELECT S_INTF_AR_WRITEOFF_INV.NEXTVAL INTO V_ID FROM DUAL;
          -- 原核销关系已经发送ERP需取消推送ERP
          UPDATE CIMS.INTF_AR_WRITEOFF_INV I SET I.AFTER_CANCEL_TRX_ID = V_ID, I.CANCEL_FLAG = 'Y',
                 I.INTF_STATUS = 'S', -- 需取消的核销关系接口状态设置为S
                 I.HANDLE_FLAG = 'N',
                 I.COMMENTS = I.COMMENTS||'#核销关系取消，新核销关系：'||V_ID
          WHERE I.CM_TRX_NUMBER = ROW_AR_WRITEOFF_INV_NUMBER.CM_TRX_NUMBER
                AND I.INVOICE_TRX_NUMBER = ROW_AR_WRITEOFF_INV_NUMBER.INVOICE_TRX_NUMBER
                AND I.ORG_ID = ROW_AR_WRITEOFF_INV_NUMBER.ORG_ID;
          -- 获取主体
          SELECT DISTINCT H.ENTITY_ID INTO V_ENTITY
          FROM CIMS.T_SO_HEADER H
          WHERE H.ERP_ARINVOICE_CODE = ROW_AR_WRITEOFF_INV_NUMBER.CM_TRX_NUMBER
                AND H.ERP_OU_ID = ROW_AR_WRITEOFF_INV_NUMBER.ORG_ID;
          -- 生成ESB交易流水号
          PKG_BD.P_GET_BILL_NO('BdEsbSerialNo', NULL, V_ENTITY, NULL, V_BDESBSERIALNO);
          SELECT ORG_ID                         --业务ou
                 ,'Q'                    --接口处理状态：N 新建；P 已提；S 返回成功；E 返回失败
                 ,V_ID
                 ,V_ID
                 ,V_BDESBSERIALNO                --交易流水号：统一调用单位规则号”BdEsbSerialNo 进行生成
                 ,CUSTOMER_NUMBER                --客户编码
                 ,CUSTOMER_NAME                  --客户名称
                 ,CM_TRX_NUMBER                  --贷项发票编号
                 ,INVOICE_TRX_NUMBER             --借项发票编号
                 ,ROW_AR_WRITEOFF_INV_NUMBER.TOTAL_MATCH_AMOUNT                 --本次核销金额
                 ,APPLY_DATE                     --核销日期
                 ,GL_DATE                        --核销总账日期
                 ,'SYSTEM'                     --创建人
                 ,TRUNC(SYSDATE, 'DD')                  --创建时间
                 ,'SYSTEM'                --最后修改人
                 ,TRUNC(SYSDATE, 'DD')               --最后修改时间
                 ,'Y'              --是否开始推送ERP。Y：开始推送，N暂不推送
                 ,'N'                    --是否取消推送ERP。Y：取消推送，N不取消推送
                 ,'Y'
          INTO ROW_AR_WRITEOFF_INV.ORG_ID        --业务ou
                 ,ROW_AR_WRITEOFF_INV.INTF_STATUS--接口处理状态：N 新建；P 已提；S 返回成功；E 返回失败
                 ,ROW_AR_WRITEOFF_INV.TRX_ID
                 ,ROW_AR_WRITEOFF_INV.SOURCE_NUM
                 ,ROW_AR_WRITEOFF_INV.TRX_NO     --交易流水号：统一调用单位规则号”BdEsbSerialNo 进行生成
                 ,ROW_AR_WRITEOFF_INV.CUSTOMER_NUMBER                --客户编码
                 ,ROW_AR_WRITEOFF_INV.CUSTOMER_NAME                  --客户名称
                 ,ROW_AR_WRITEOFF_INV.CM_TRX_NUMBER                  --贷项发票编号
                 ,ROW_AR_WRITEOFF_INV.INVOICE_TRX_NUMBER             --借项发票编号
                 ,ROW_AR_WRITEOFF_INV.APPLIED_AMOUNT                 --本次核销金额
                 ,ROW_AR_WRITEOFF_INV.APPLY_DATE                     --核销日期
                 ,ROW_AR_WRITEOFF_INV.GL_DATE                        --核销总账日期
                 ,ROW_AR_WRITEOFF_INV.CREATED_BY                     --创建人
                 ,ROW_AR_WRITEOFF_INV.CREATION_DATE                  --创建时间
                 ,ROW_AR_WRITEOFF_INV.LAST_UPDATED_BY                --最后修改人
                 ,ROW_AR_WRITEOFF_INV.LAST_UPDATE_DATE               --最后修改时间
                 ,ROW_AR_WRITEOFF_INV.START_PUSH_TO_ERP              --是否开始推送ERP。Y：开始推送，N暂不推送
                 ,ROW_AR_WRITEOFF_INV.CANCEL_FLAG                    --是否取消推送ERP。Y：取消推送，N不取消推送
                 ,ROW_AR_WRITEOFF_INV.HANDLE_FLAG
          FROM (SELECT * FROM CIMS.INTF_AR_WRITEOFF_INV IAW
                  WHERE IAW.CM_TRX_NUMBER = ROW_AR_WRITEOFF_INV_NUMBER.CM_TRX_NUMBER
                        AND IAW.INVOICE_TRX_NUMBER = ROW_AR_WRITEOFF_INV_NUMBER.INVOICE_TRX_NUMBER
                        AND IAW.ORG_ID = ROW_AR_WRITEOFF_INV_NUMBER.ORG_ID
                        AND IAW.ORDER_RECEIPT_ID IS NOT NULL -- 新生成汇总的核销关系没有ORDER_RECEIPT_ID
                  ORDER BY IAW.CREATION_DATE DESC
                  ) I
          WHERE ROWNUM = 1;
          -- 插入新的汇总核销关系
          INSERT INTO INTF_AR_WRITEOFF_INV VALUES ROW_AR_WRITEOFF_INV;
          COMMIT;
        END IF;
      EXCEPTION WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
        P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_ORDER_RECEIPT_ERP_CHECK',
          SQLCODE,
          '生成汇总核销关系失败！ORG_ID：'||ROW_AR_WRITEOFF_INV_NUMBER.ORG_ID||'，CM_TRX_NUMBER：'||ROW_AR_WRITEOFF_INV_NUMBER.CM_TRX_NUMBER||'，INVOICE_TRX_NUMBER：'||ROW_AR_WRITEOFF_INV_NUMBER.INVOICE_TRX_NUMBER||
          '。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
      END;
    END LOOP;

    BEGIN
      -- 核销正常的单据设置开始推送ERP
      UPDATE CIMS.INTF_AR_WRITEOFF IW SET IW.START_PUSH_TO_ERP = 'Y'
      WHERE ORG_ID IN (SELECT CODE_VALUE FROM V_UP_CODELIST WHERE ENTITY_ID =V_PARAM_ENTITY_ID AND CODETYPE='ar_ou_id')
        AND  EXISTS (SELECT *
                   FROM (SELECT I.ORG_ID, I.RECEIPT_NUMBER, I.TRX_NUMBER, COUNT(*)
                             FROM CIMS.INTF_AR_WRITEOFF I WHERE CANCEL_FLAG ='N' GROUP BY I.ORG_ID, I.RECEIPT_NUMBER, I.TRX_NUMBER
                             HAVING COUNT(*) <= 1) TMP
                    WHERE TMP.RECEIPT_NUMBER = IW.RECEIPT_NUMBER AND TMP.TRX_NUMBER = IW.TRX_NUMBER AND TMP.ORG_ID = IW.ORG_ID)
             AND IW.START_PUSH_TO_ERP <> 'Y';
      -- 核销正常的单据设置开始推送ERP
      UPDATE CIMS.INTF_AR_WRITEOFF_INV IW SET IW.START_PUSH_TO_ERP = 'Y'
      WHERE ORG_ID IN (SELECT CODE_VALUE FROM V_UP_CODELIST WHERE ENTITY_ID =V_PARAM_ENTITY_ID AND CODETYPE='ar_ou_id') 
         and  EXISTS (SELECT *
                   FROM (SELECT I.ORG_ID, I.CM_TRX_NUMBER, I.INVOICE_TRX_NUMBER, COUNT(*)
                             FROM CIMS.INTF_AR_WRITEOFF_INV I WHERE CANCEL_FLAG ='N'  GROUP BY I.ORG_ID, I.CM_TRX_NUMBER, I.INVOICE_TRX_NUMBER
                             HAVING COUNT(*) <= 1) TMP
                    WHERE TMP.CM_TRX_NUMBER = IW.CM_TRX_NUMBER AND TMP.INVOICE_TRX_NUMBER = IW.INVOICE_TRX_NUMBER AND TMP.ORG_ID = IW.ORG_ID)
             AND IW.START_PUSH_TO_ERP <> 'Y';
       COMMIT;
     EXCEPTION WHEN OTHERS THEN
       P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
       P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_ORDER_RECEIPT_ERP_CHECK',
                SQLCODE,
                '核销正常的单据设置开始推送START_PUSH_TO_ERP失败！错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
     END;
  EXCEPTION WHEN OTHERS THEN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_ORDER_RECEIPT_ERP_CHECK',
      SQLCODE,
      '核销关系推送ERP校验执行失败！错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    RETURN ;
  END;

  -- 取消核销关系推送ERP
  PROCEDURE P_SO_ORDER_RECEIPT_ERP_CANCEL
  (
     IN_ENTITY_ID IN  NUMBER,  --主体 
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
     V_PARAM_ENTITY_ID NUMBER;
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    V_PARAM_ENTITY_ID := IN_ENTITY_ID;
    -- 取消收款核销发票
    INSERT INTO INTF_AR_WRITEOFF_UN(
        BILL_TO,  --客户收单方
        CREATED_BY,  --创建人
        CREATION_DATE,  --创建日期
        CUSTOMER_NAME,  --客户名称
        CUSTOMER_NUMBER,  --客户编码
        ERROR_FLAG,  --错误标志
        ERR_MESSAGE,  --错误信息
        ESB_DATA_SOURCE,  --ESB数据来源
        ESB_SERIAL_NUM,  --ESB流水号
        INTF_STATUS,  --接口处理状态：N 新建；P 已提；S 返回成功；E 返回失败
        LAST_UPDATED_BY,  --修改人
        LAST_UPDATE_DATE,  --修改日期
        OPERSTATUS,  --更新业务表的处理状态  0：成功，1：失败 2：处理中
        ORG_ID,  --业务实体ID
        ORIGINAL_TRX_ID,  --原单ID
        POST_DATE,  --提交时间
        RECEIPT_NUMBER,  --收款编号
        RESPNOSECODE,  --提供方填写，返回的状态代码。错误码规范见文档《美的财务_新一代企业服务总线_ESB接入错误码》
        RESPONSEMESSAGE,  --提供方填写，返回的状态信息
        RESPONSETYPE,  --提供方填写：N-成功，E-失败，W-警告，A-授权
        RETURN_DATE,  --返回时间
        REVERSAL_DATE,  --冲销日期
        REVERSAL_GL_DATE,  --冲销总帐日期
        SOURCE_CODE,  --来源系统代码
        SOURCE_LINE_NUM,  --来源行编号
        SOURCE_NUM,  --来源编号
        TRX_ID,  --主键ID
        TRX_NUMBER  --发票编号
        )
     SELECT
        NULL
        ,'SYSTEM'
        ,TRUNC(SYSDATE, 'DD')
        ,IAW.CUSTOMER_NAME
        ,IAW.CUSTOMER_NUMBER
        ,NULL
        ,NULL
        ,NULL
        ,NULL
        ,'N'
        ,'SYSTEM'
        ,TRUNC(SYSDATE, 'DD')
        ,NULL
        ,IAW.ORG_ID
        ,IAW.TRX_ID
        ,NULL
        ,IAW.RECEIPT_NUMBER
        ,NULL
        ,NULL
        ,NULL
        ,NULL
        ,TO_CHAR(SYSDATE, 'yyyy-MM-dd')
        ,TO_CHAR(SYSDATE, 'yyyy-MM-dd')
        ,'CIMS'
        ,NULL
        ,NULL
        ,S_INTF_AR_WRITEOFF_UN.NEXTVAL
        ,IAW.TRX_NUMBER
      FROM CIMS.INTF_AR_WRITEOFF IAW
      WHERE ORG_ID IN (SELECT CODE_VALUE FROM V_UP_CODELIST WHERE ENTITY_ID =V_PARAM_ENTITY_ID AND CODETYPE='ar_ou_id')
         AND IAW.TRX_ID IN
              (SELECT TMP.MAX_TRX_ID FROM (
                  SELECT IAWI_.ORG_ID, IAWI_.RECEIPT_NUMBER, IAWI_.TRX_NUMBER, MAX(IAWI_.TRX_ID) AS MAX_TRX_ID
                  FROM CIMS.INTF_AR_WRITEOFF IAWI_
                  WHERE IAWI_.CANCEL_FLAG = 'Y' AND IAWI_.HANDLE_FLAG = 'N'
                  GROUP BY IAWI_.ORG_ID, IAWI_.RECEIPT_NUMBER, IAWI_.TRX_NUMBER
              ) TMP
            )
            AND IAW.CANCEL_FLAG = 'Y'
            AND IAW.HANDLE_FLAG = 'N';

    -- 取消发票核销发票
    INSERT INTO INTF_AR_WRITEOFF_INV_UN(
      BILL_TO,  --客户收单方
      CM_TRX_NUMBER,  --贷项通知单编号
      CREATED_BY,  --创建人
      CREATION_DATE,  --创建日期
      CUSTOMER_NAME,  --客户名称
      CUSTOMER_NUMBER,  --客户编码
      ERROR_FLAG,  --错误标志
      ERR_MESSAGE,  --错误信息
      ESB_DATA_SOURCE,  --ESB数据来源
      ESB_SERIAL_NUM,  --ESB流水号
      INTF_STATUS,  --接口处理状态：N 新建；P 已提；S 返回成功；E 返回失败
      LAST_UPDATED_BY,  --修改人
      LAST_UPDATE_DATE,  --修改日期
      OPERSTATUS,  --更新业务表的处理状态  0：成功，1：失败 2：处理中
      ORG_ID,  --业务实体ID
      ORIGINAL_TRX_ID,  --原单ID
      POST_DATE,  --提交时间
      RESPNOSECODE,  --提供方填写，返回的状态代码。错误码规范见文档《美的财务_新一代企业服务总线_ESB接入错误码》
      RESPONSEMESSAGE,  --提供方填写，返回的状态信息
      RESPONSETYPE,  --提供方填写：N-成功，E-失败，W-警告，A-授权
      RETURN_DATE,  --返回时间
      REVERSAL_DATE,  --冲销日期
      REVERSAL_GL_DATE,  --冲销总帐日期
      SOURCE_CODE,  --来源系统代码
      SOURCE_LINE_NUM,  --来源行编号
      SOURCE_NUM,  --来源编号
      TRX_ID,  --主键ID
      TRX_NUMBER  --发票编号
      )
    SELECT
      NULL        --客户收单方
      ,IAWI.CM_TRX_NUMBER  --贷项通知单编号
      ,'SYSTEM'--创建人
      ,TRUNC(SYSDATE, 'DD') --创建日期
      ,IAWI.CUSTOMER_NAME--客户名称
      ,IAWI.CUSTOMER_NUMBER--客户编码
      ,NULL--错误标志
      ,NULL--错误信息
      ,NULL--ESB数据来源
      ,NULL--ESB流水号
      ,'N'--接口处理状态：N 新建；P 已提；S 返回成功；E 返回失败
      ,'SYSTEM'--修改人
      ,TRUNC(SYSDATE, 'DD') --修改日期
      ,NULL--更新业务表的处理状态  0：成功，1：失败 2：处理中
      ,IAWI.ORG_ID--业务实体ID
      ,IAWI.TRX_ID--原单ID
      ,NULL--提交时间
      ,NULL--提供方填写，返回的状态代码。错误码规范见文档《美的财务_新一代企业服务总线_ESB接入错误码》
      ,NULL--提供方填写，返回的状态信息
      ,NULL--提供方填写：N-成功，E-失败，W-警告，A-授权
      ,NULL--返回时间
      ,TO_CHAR(SYSDATE, 'yyyy-MM-dd') --冲销日期
      ,TO_CHAR(SYSDATE, 'yyyy-MM-dd') --冲销总帐日期
      ,'CIMS'--来源系统代码
      ,NULL--来源行编号
      ,NULL--来源编号
      ,S_INTF_AR_WRITEOFF_INV_UN.NEXTVAL--主键ID
      ,IAWI.INVOICE_TRX_NUMBER--发票编号
    FROM CIMS.INTF_AR_WRITEOFF_INV IAWI
    WHERE ORG_ID IN (SELECT CODE_VALUE FROM V_UP_CODELIST WHERE ENTITY_ID =V_PARAM_ENTITY_ID AND CODETYPE='ar_ou_id')
      AND IAWI.TRX_ID IN
            (SELECT TMP.MAX_TRX_ID FROM (
                SELECT IAWI_.ORG_ID, IAWI_.INVOICE_TRX_NUMBER, IAWI_.CM_TRX_NUMBER, MAX(IAWI_.TRX_ID) AS MAX_TRX_ID
                FROM CIMS.INTF_AR_WRITEOFF_INV IAWI_
                WHERE IAWI_.CANCEL_FLAG = 'Y' AND IAWI_.HANDLE_FLAG = 'N'
                GROUP BY IAWI_.ORG_ID, IAWI_.INVOICE_TRX_NUMBER, IAWI_.CM_TRX_NUMBER
            ) TMP
          )
          AND IAWI.CANCEL_FLAG = 'Y'
          AND IAWI.HANDLE_FLAG = 'N'
--          AND NOT EXISTS (SELECT * FROM cims.INTF_AR_WRITEOFF_INV_UN IAWU WHERE IAWU.TRX_NUMBER = IAWI.INVOICE_TRX_NUMBER AND IAWU.CM_TRX_NUMBER = IAWI.CM_TRX_NUMBER)
          ;

    UPDATE CIMS.INTF_AR_WRITEOFF I SET I.HANDLE_FLAG = 'Y' WHERE 
        ORG_ID IN (SELECT CODE_VALUE FROM V_UP_CODELIST WHERE ENTITY_ID =V_PARAM_ENTITY_ID AND CODETYPE='ar_ou_id')
    AND  I.CANCEL_FLAG = 'Y' AND I.HANDLE_FLAG = 'N';
    UPDATE CIMS.INTF_AR_WRITEOFF_INV I SET I.HANDLE_FLAG = 'Y' WHERE 
        ORG_ID IN (SELECT CODE_VALUE FROM V_UP_CODELIST WHERE ENTITY_ID =V_PARAM_ENTITY_ID AND CODETYPE='ar_ou_id')
    AND I.CANCEL_FLAG = 'Y' AND I.HANDLE_FLAG = 'N';

    UPDATE CIMS.INTF_AR_WRITEOFF_UN U SET U.SOURCE_NUM = U.TRX_ID WHERE
       ORG_ID IN (SELECT CODE_VALUE FROM V_UP_CODELIST WHERE ENTITY_ID =V_PARAM_ENTITY_ID AND CODETYPE='ar_ou_id')
    AND U.SOURCE_NUM IS NULL;
    UPDATE CIMS.INTF_AR_WRITEOFF_INV_UN U SET U.SOURCE_NUM = U.TRX_ID WHERE 
       ORG_ID IN (SELECT CODE_VALUE FROM V_UP_CODELIST WHERE ENTITY_ID =V_PARAM_ENTITY_ID AND CODETYPE='ar_ou_id')
    AND U.SOURCE_NUM IS NULL;
    COMMIT;
    P_RESULT := '取消核销关系推送ERP执行成功！';
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_ORDER_RECEIPT_ERP_CANCEL',
      SQLCODE,
      '取消核销关系推送ERP执行失败！错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    RETURN ;
  END;

  --核销对账检查
  PROCEDURE P_AR_WRITE_OFF_CHECK
  (
      P_CHECK_YES_OR_NO                    IN VARCHAR2,
      P_RESULT                             OUT VARCHAR2,
      P_MESSAGE                            OUT VARCHAR2
  ) IS
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    IF PKG_AR_WRITE_OFF.V_YES = P_CHECK_YES_OR_NO THEN
      FOR ROW_AR_WRITE_OFF_CHECK_REPORT IN (SELECT CR.* FROM CIMS.T_AR_WRITE_OFF_CHECK CR WHERE CR.ERROR_CASH <> 0 AND CR.SHOULD_WRITE_OFF_FLAG = PKG_AR_WRITE_OFF.V_YES) LOOP
        BEGIN
          IF ROW_AR_WRITE_OFF_CHECK_REPORT.SO_OR_RECEIPT = 1 THEN -- 应收
            -- 更新收款到发票接口表状态
            UPDATE INTF_AR_WRITEOFF OFF SET OFF.PROCESS_STATUS = 'E'
            WHERE OFF.PROCESS_STATUS IS NULL
                  AND EXISTS (SELECT * FROM CIMS.T_SO_ORDER_RECEIPT R WHERE R.ORDER_RECEIPT_ID = OFF.ORDER_RECEIPT_ID AND R.SO_HEAD_ID = ROW_AR_WRITE_OFF_CHECK_REPORT.HEADER_ID);
            -- 更新发票到发票接口表状态
            UPDATE INTF_AR_WRITEOFF_INV INV SET INV.PROCESS_STATUS = 'E'
            WHERE INV.PROCESS_STATUS IS NULL
                  AND EXISTS (SELECT * FROM CIMS.T_SO_ORDER_RECEIPT R WHERE R.ORDER_RECEIPT_ID = INV.ORDER_RECEIPT_ID AND R.SO_HEAD_ID = ROW_AR_WRITE_OFF_CHECK_REPORT.HEADER_ID);
          ELSIF ROW_AR_WRITE_OFF_CHECK_REPORT.SO_OR_RECEIPT = -1 THEN -- 回款
            -- 更新收款到发票接口表状态
            UPDATE INTF_AR_WRITEOFF OFF SET OFF.PROCESS_STATUS = 'E'
            WHERE OFF.PROCESS_STATUS IS NULL
                  AND EXISTS (SELECT * FROM CIMS.T_SO_ORDER_RECEIPT R WHERE R.ORDER_RECEIPT_ID = OFF.ORDER_RECEIPT_ID AND R.CASH_RECEIPT_ID = ROW_AR_WRITE_OFF_CHECK_REPORT.HEADER_ID);
            -- 更新发票到发票接口表状态
            UPDATE INTF_AR_WRITEOFF_INV INV SET INV.PROCESS_STATUS = 'E'
            WHERE INV.PROCESS_STATUS IS NULL
                  AND EXISTS (SELECT * FROM CIMS.T_SO_ORDER_RECEIPT R WHERE R.ORDER_RECEIPT_ID = INV.ORDER_RECEIPT_ID AND R.CASH_RECEIPT_ID = ROW_AR_WRITE_OFF_CHECK_REPORT.HEADER_ID);
          END IF;
          COMMIT;
        EXCEPTION WHEN OTHERS THEN
          ROLLBACK;
          P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
          P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFF_CHECK',
                        SQLCODE,
                        '核销校验重置核销关系状态出错！单据号：'||ROW_AR_WRITE_OFF_CHECK_REPORT.SO_NUM||'。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
        END;
      END LOOP;
    END IF;
    BEGIN
      -- 将接口状态值不为E的全部置为S
      UPDATE INTF_AR_WRITEOFF OFF SET OFF.PROCESS_STATUS = 'S' WHERE NVL(OFF.PROCESS_STATUS, 'N') <> 'E';
      UPDATE INTF_AR_WRITEOFF_INV INV SET INV.PROCESS_STATUS = 'S' WHERE NVL(INV.PROCESS_STATUS, 'N') <> 'E';
      COMMIT;
    EXCEPTION WHEN OTHERS THEN
      ROLLBACK;
      P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
      P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFF_CHECK',
                    SQLCODE,
                    '将接口状态值不为E的全部置为S出错！错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    END;
    P_RESULT := '核销对账检查执行成功！';
  EXCEPTION WHEN OTHERS THEN
    --记录出错信息
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITE_OFF_CHECK',
              SQLCODE,
              '核销对账检查出错！错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
  END;

  /**
     自动坏账准备计提

  业务逻辑：1、  系统根据坏账准备计提标准、逾期明细每日进行触发计算；计提结果存储在坏账准备计提表中；
            2、 逾期分段坏账计提=逾期应收账龄分段金额*逾期应收账龄分段所对应的坏账准备计提比例；
  */
  PROCEDURE P_SO_BAD_BILL_PROVISION_REPROT(
     IN_ENTITY_ID IN  NUMBER  --主体 
    ,P_DATE                                    IN DATE
    ,P_RESULT                                  OUT VARCHAR2
    ,P_MESSAGE                                 OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
    ) IS
  P_DAYNUMBER                                 INT;--得到天数差
  P_PMT_AGE                                   INT;--账龄分段天数
  P_ACCOUNT_AGE_ID                            NUMBER(10,0);--主键变量
  P_BAD_BILL_ID                               NUMBER(10,0);--坏账准备计提序列
  P_ORDER_MAIN_TYPE                           VARCHAR2(2); --单据主类型（收款单/财务单）
  P_AR_TYPE                                   VARCHAR2(2); --应收类型（应收款/回款）
  P_SO_ORDER_TYPE                             VARCHAR2(20); --财务单据类型
  P_ORDER_ID                                  NUMBER;--单据ID
  P_ORDER_LINES_ID                            NUMBER;--单据行ID
  P_ORDER_NUMBER                              VARCHAR2(32);--单据号
  P_ORDER_DATE                                DATE;        --单据日期
  P_MATCH_DATE                                DATE;        --核销日期
  P_AGE_DATE                                  DATE;        --账龄日期
  P_ORDER_AMOUNT                              NUMBER;--单据金额
  P_WRITE_OFF_AMOUNT                          NUMBER;--核销金额
  P_USED_FLAG                                 VARCHAR2(2); --核销标志
  P_SETTLED_FLAG                              VARCHAR2(2); --结算标志
  P_ENTITY_ID                                 NUMBER(10,0);--主体
  P_ERP_OU_ID                                 NUMBER;      --ERP_OU_ID
  P_ERP_OU_NAME                               VARCHAR(100);--ERP_OU_NAME
  P_SALES_MAIN_TYPE_ID                        NUMBER;--营销大类ID

  P_ACCOUNT_AGE_ID_COUNT                      NUMBER;
  
         V_PARAM_ENTITY_ID NUMBER;
  --游标定义
  CURSOR MY_BADBILLREPROT IS
    SELECT
            T1.ACCOUNT_AGE_ID
           ,T1.CUSTOMER_ID
           ,T1.CUSTOMER_CODE
           ,T1.CUSTOMER_NAME
           ,T1.SALES_MAIN_TYPE_ID
           ,T1.SALES_MAIN_TYPE_CODE
           ,T1.SALES_MAIN_TYPE_NAME
           ,T3.PMT_AGE
           ,T1.SALES_CENTER_ID
           ,T1.SALES_CENTER_CODE
           ,T1.SALES_CENTER_NAME
           ,SUM(T1.WRITE_OFF_AMOUNT2) AS OVERDUE_AMOUNT --未核销金额
     FROM T_SO_ACCOUNT_AGE                                 T1--客户账龄表
          ,T_CUSTOMER_CHANNEL_TYPE                         T2--客户和业态类型对应表
          ,T_AR_PMT_ACCOUNT_AGE_CONF                       T3--未到期分段设置表
     WHERE T1.CUSTOMER_ID = T2.CUSTOMER_ID
       AND T1.ENTITY_ID = T2.ENTITY_ID
       AND T1.ENTITY_ID = T3.ENTITY_ID             --by anht
       AND T2.INDUSTRY_TYPE = T3.CUSTOMER_ATTRIBUE
       AND T1.AR_TYPE = '1' --应收款
       AND T1.MATCH_DATE = TRUNC(P_DATE,'DD')
       AND T1.Entity_Id = V_PARAM_ENTITY_ID
     GROUP BY
            T1.ACCOUNT_AGE_ID
           ,T1.CUSTOMER_ID
           ,T1.CUSTOMER_CODE
           ,T1.CUSTOMER_NAME
           ,T1.SALES_MAIN_TYPE_ID
           ,T1.SALES_MAIN_TYPE_CODE
           ,T1.SALES_MAIN_TYPE_NAME
           ,T3.PMT_AGE
           ,T1.SALES_CENTER_ID
           ,T1.SALES_CENTER_CODE
           ,T1.SALES_CENTER_NAME;

   --游标结果返回
    CUR_BADBILLRESULT                 MY_BADBILLREPROT%ROWTYPE;

   BEGIN
          P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
          V_PARAM_ENTITY_ID := IN_ENTITY_ID;
          IF(P_MESSAGE = PKG_AR_WRITE_OFF.V_SUCCESS) THEN
               BEGIN
                   OPEN MY_BADBILLREPROT;
                   LOOP
                       FETCH MY_BADBILLREPROT INTO CUR_BADBILLRESULT;
                       EXIT WHEN MY_BADBILLREPROT%NOTFOUND;
                       --数据赋值
                       BEGIN
                            --账龄段天数
                            P_PMT_AGE := CUR_BADBILLRESULT.PMT_AGE;
                            --主键ID
                            P_ACCOUNT_AGE_ID := CUR_BADBILLRESULT.ACCOUNT_AGE_ID;
                             --计算当前记录的天数差（核销日期-账龄日期）
                            SELECT ROUND(TO_NUMBER(T.MATCH_DATE - T.AGE_DATE))
                             INTO P_DAYNUMBER
                             FROM T_SO_ACCOUNT_AGE T
                            WHERE T.ACCOUNT_AGE_ID = P_ACCOUNT_AGE_ID;
                       END;
                       --数据准备
                       BEGIN
                            SELECT
                                 T.ORDER_MAIN_TYPE
                                 ,T.AR_TYPE
                                 ,T.SO_ORDER_TYPE
                                 ,T.ORDER_ID
                                 ,T.ORDER_LINES_ID
                                 ,T.ORDER_NUMBER
                                 ,T.ORDER_DATE
                                 ,T.MATCH_DATE
                                 ,T.AGE_DATE
                                 ,T.ORDER_AMOUNT
                                 ,T.WRITE_OFF_AMOUNT
                                 ,T.USED_FLAG
                                 ,T.SETTLED_FLAG
                                 ,T.ENTITY_ID
                                 ,T.ERP_OU_ID
                                 ,T.ERP_OU_NAME
                            INTO
                                  P_ORDER_MAIN_TYPE
                                 ,P_AR_TYPE
                                 ,P_SO_ORDER_TYPE
                                 ,P_ORDER_ID
                                 ,P_ORDER_LINES_ID
                                 ,P_ORDER_NUMBER
                                 ,P_ORDER_DATE
                                 ,P_MATCH_DATE
                                 ,P_AGE_DATE
                                 ,P_ORDER_AMOUNT
                                 ,P_WRITE_OFF_AMOUNT
                                 ,P_USED_FLAG
                                 ,P_SETTLED_FLAG
                                 ,P_ENTITY_ID
                                 ,P_ERP_OU_ID
                                 ,P_ERP_OU_NAME
                          FROM T_SO_ACCOUNT_AGE T
                         WHERE T.ACCOUNT_AGE_ID = P_ACCOUNT_AGE_ID;
                       EXCEPTION WHEN  OTHERS THEN
                            ROLLBACK ;
                             P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                             P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_BAD_BILL_PROVISION_REPROT',
                                SQLCODE,
                                '数据准备出错！ACCOUNT_AGE_ID：'||P_ACCOUNT_AGE_ID||'。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                            RETURN ;
                       END;

                       IF P_DAYNUMBER> 0 THEN
                           --判断是否逾期
                         IF P_DAYNUMBER>=P_PMT_AGE THEN
                             --获取坏账准备计提序列
                             BEGIN
                                 SELECT S_SO_BAD_BILL_PROVISION_OLD.NEXTVAL INTO P_BAD_BILL_ID FROM DUAL ;
                             EXCEPTION WHEN  OTHERS THEN
                                  ROLLBACK ;
                                   P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                                   P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_BAD_BILL_PROVISION_REPROT',
                                      SQLCODE,
                                      '获取坏账准备计提序列出错！错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                                  RETURN ;
                             END;
                             --营销大类ID数据准备
                             BEGIN
                                SELECT BI.ITEM_CLASS_ID INTO P_SALES_MAIN_TYPE_ID
                                  FROM T_BD_ITEM_CLASS BI
                                 WHERE BI.CLASS_TYPE = 'M'
                                       AND BI.ACTIVE_FLAG = 'Y'
                                       AND BI.CLASS_CODE = CUR_BADBILLRESULT.SALES_MAIN_TYPE_CODE
                                       AND BI.ENTITY_ID = P_ENTITY_ID
                                       AND ROWNUM < 2;
                             EXCEPTION WHEN  OTHERS THEN
                                  ROLLBACK ;
                                  P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                                  P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_BAD_BILL_PROVISION_REPROT',
                                           SQLCODE,
                                           '营销大类ID数据准备出错！账龄ACCOUNT_AGE_ID：'||P_ACCOUNT_AGE_ID||'。ENTITY_ID：'||P_ENTITY_ID||'。CLASS_CODE：'||CUR_BADBILLRESULT.SALES_MAIN_TYPE_CODE||'。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                                  RETURN ;
                             END;
                             --坏账准备计提原始表插入
                             BEGIN
                               SELECT count(*) INTO P_ACCOUNT_AGE_ID_COUNT FROM CIMS.T_SO_BAD_BILL_PROVISION_OLD BBPO
                               WHERE BBPO.ACCOUNT_AGE_ID = CUR_BADBILLRESULT.ACCOUNT_AGE_ID;
                               IF P_ACCOUNT_AGE_ID_COUNT <= 0 THEN
                                	INSERT INTO T_SO_BAD_BILL_PROVISION_OLD
                                 (
                                  BAD_BILL_ID                                                  --坏账ID
                                  ,ACCOUNT_AGE_ID                                              --财龄ID
                                  ,CUSTOMER_ID                                                 --客户ID
                                  ,ORDER_MAIN_TYPE                                             --单据主类型（收款单/财务单）
                                  ,AR_TYPE                                                     --应收类型（应收款/回款）
                                  ,SO_ORDER_TYPE                                               --财务单据类型
                                  ,ORDER_ID                                                    --单据ID
                                  ,ORDER_LINES_ID                                              --单据行ID
                                  ,ORDER_NUMBER                                                --单据号
                                  ,ORDER_                                                      --单据日期
                                  ,TIMING_DATE                                                 --定时日期
                                  ,MATCH_DATE                                                  --核销日期
                                  ,AGE_DATE                                                    --账龄日期
                                  ,ORDER_AMOUNT                                                --单据金额
                                  ,WRITE_OFF_AMOUNT                                            --核销金额
                                  ,OVERDUE_AMOUNT                                              --逾期金额
                                  ,USED_FLAG                                                   --核销标志（0:全部核销；1:部分核销；2:未核销）
                                  ,SETTLED_FLAG                                               --结算标志(0:已结算；1:未结算)
                                  ,CUSTOMER_CODE                                               --客户编码
                                  ,CUSTOMER_NAME                                               --客户名称
                                  ,ENTITY_ID                                                   --主体
                                  ,SALES_MAIN_TYPE_ID                                          --营销大类ID
                                  ,SALES_MAIN_TYPE_CODE                                        --营销大类编码
                                  ,SALES_MAIN_TYPE_NAME                                        --营销大类名称
                                  ,CREATED_BY                                                  --创建人
                                  ,CREATION_DATE                                               --创建时间
                                  ,LAST_UPDATE_BY                                              --最后修改人
                                  ,LAST_UPDATE_DATE                                            --最后修改时间
                                  ,ERP_OU_ID                                                   --ERP_OU_ID
                                  ,ERP_OU_NAME                                                 --ERP_OU_NAME
                                  ,BAD_BILL_STATUS
                                  ,SALES_CENTER_ID
                                  ,SALES_CENTER_CODE
                                  ,SALES_CENTER_NAME
                                 )
                                 VALUES
                                 (
                                   P_BAD_BILL_ID
                                   ,CUR_BADBILLRESULT.ACCOUNT_AGE_ID
                                   ,CUR_BADBILLRESULT.CUSTOMER_ID
                                   ,P_ORDER_MAIN_TYPE
                                   ,P_AR_TYPE
                                   ,P_SO_ORDER_TYPE
                                   ,P_ORDER_ID
                                   ,P_ORDER_LINES_ID
                                   ,P_ORDER_NUMBER
                                   ,P_ORDER_DATE
                                   ,''
                                   ,P_MATCH_DATE
                                   ,P_AGE_DATE
                                   ,P_ORDER_AMOUNT
                                   ,P_WRITE_OFF_AMOUNT
                                   ,CUR_BADBILLRESULT.OVERDUE_AMOUNT
                                   ,P_USED_FLAG
                                   ,P_SETTLED_FLAG
                                   ,CUR_BADBILLRESULT.CUSTOMER_CODE
                                   ,CUR_BADBILLRESULT.CUSTOMER_NAME
                                   ,P_ENTITY_ID
                                   ,P_SALES_MAIN_TYPE_ID
                                   ,CUR_BADBILLRESULT.SALES_MAIN_TYPE_CODE
                                   ,CUR_BADBILLRESULT.SALES_MAIN_TYPE_NAME
                                   ,'SYSTEM'
                                   --,trunc(SYSDATE,'dd')
                                   ,trunc(P_DATE+1,'dd')   --by anht
                                   ,'SYSTEM'
                                   --,trunc(SYSDATE,'dd')
                                    ,trunc(P_DATE+1,'dd')  --by anht
                                   ,P_ERP_OU_ID
                                   ,P_ERP_OU_NAME
                                   ,'0'
                                   ,CUR_BADBILLRESULT.SALES_CENTER_ID
                                   ,CUR_BADBILLRESULT.SALES_CENTER_CODE
                                   ,CUR_BADBILLRESULT.SALES_CENTER_NAME
                                 );
                               END IF;
                             EXCEPTION WHEN  OTHERS THEN
                                  ROLLBACK ;
                                  P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                                  P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_BAD_BILL_PROVISION_REPROT',
                                           SQLCODE,
                                           '坏账准备计提原始表插入出错！BAD_BILL_ID：'||P_BAD_BILL_ID||'。ACCOUNT_AGE_ID：'||CUR_BADBILLRESULT.ACCOUNT_AGE_ID||'。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                                  RETURN ;
                             END ;
                         END IF;
                       END IF;
                   END LOOP;
                   COMMIT;
                   CLOSE  MY_BADBILLREPROT;
               END ;
          END IF;
          P_RESULT := '过程执行成功！';
   EXCEPTION WHEN  OTHERS THEN
        ROLLBACK ;
        P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
        P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_BAD_BILL_PROVISION_REPROT',
                 SQLCODE,
                 '坏账准备计提过程出错！错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
        RETURN ;
   END;

  /**
    坏账准备计提沉淀报表
  **/
  PROCEDURE P_SO_BAD_BILL_PROVISION_PREC_R(
                              IN_ENTITY_ID IN  NUMBER  --主体 
                              ,P_DATE                                IN DATE
                              ,P_RESULT                              OUT VARCHAR2
                              ,P_MESSAGE                             OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
  P_DAY                                                               NUMBER(10,0); --逾期分段天数
  P_COUNT                                                            NUMBER(10,0); --记录数据
  P_BAD_PREC_BILL_ID                                                 NUMBER(10,0); --坏账沉淀序列
  K                                                                  NUMBER;
  H                                                                  NUMBER;

  V_SQL_UPDATE                                                       VARCHAR2(4000);
  V_UPDATE_TABLE                                                     VARCHAR2(4000) ;
  V_UPDATE_COLS                                                      VARCHAR2(4000) ;
  V_UPDATE_WHERE                                                     VARCHAR2(4000) ;

  V_SQL_INSERT                                                       VARCHAR2(20000) ;
  V_INSERT_TABLE                                                     VARCHAR2(4000) ;
  V_INSERT_COLS                                                      VARCHAR2(4000) ;
  V_INSERT_VALUES                                                    VARCHAR2(4000) ;
  P_DATEAD                                                           DATE;
  
        V_PARAM_ENTITY_ID NUMBER;

  --游标定义
  CURSOR MY_CUR IS
     SELECT SUM(T.OVERDUE_AMOUNT) AMOUNT
           ,T.AGE_DATE
           ,T.MATCH_DATE
           ,T.CUSTOMER_ID
           ,T.CUSTOMER_CODE
           ,T.CUSTOMER_NAME
           ,T.BAD_BILL_ID
           ,T.SALES_MAIN_TYPE_ID
           ,T.SALES_MAIN_TYPE_CODE
           ,T.SALES_MAIN_TYPE_NAME
           ,T.SALES_CENTER_ID
           ,T.SALES_CENTER_CODE
           ,T.SALES_CENTER_NAME
           ,T.ENTITY_ID
       FROM T_SO_BAD_BILL_PROVISION_OLD T
      WHERE T.CREATION_DATE >= TRUNC(P_DATE,'DD')
        AND T.CREATION_DATE < TRUNC(P_DATE,'DD')+1
        AND T.ENTITY_ID = V_PARAM_ENTITY_ID
      GROUP BY T.AGE_DATE
              ,T.MATCH_DATE
              ,T.CUSTOMER_ID
              ,T.BAD_BILL_ID
              ,T.CUSTOMER_CODE
              ,T.CUSTOMER_NAME
              ,T.SALES_MAIN_TYPE_ID
              ,T.SALES_MAIN_TYPE_CODE
              ,T.SALES_MAIN_TYPE_NAME
              ,T.SALES_CENTER_ID
              ,T.SALES_CENTER_CODE
              ,T.SALES_CENTER_NAME
              ,T.ENTITY_ID;

   --游标结果返回
    CUR_RESULT                 MY_CUR%ROWTYPE;

  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    V_PARAM_ENTITY_ID := IN_ENTITY_ID;
    
    V_UPDATE_TABLE := 'UPDATE T_SO_BAD_BILL_PROVISION_PREC_R T SET ' ;
    V_INSERT_TABLE := 'INSERT INTO T_SO_BAD_BILL_PROVISION_PREC_R ';
    P_DATEAD := P_DATE+1;
    IF(P_MESSAGE = PKG_AR_WRITE_OFF.V_SUCCESS) THEN
      OPEN MY_CUR;--打开游标
      --MY_CUR循环开始
      LOOP
      FETCH MY_CUR INTO CUR_RESULT;
      EXIT WHEN MY_CUR%NOTFOUND;
      --获取天数差
      BEGIN
          SELECT ROUND(TO_NUMBER(T.MATCH_DATE - T.AGE_DATE))
            INTO P_DAY
            FROM T_SO_BAD_BILL_PROVISION_OLD T
           WHERE T.BAD_BILL_ID = CUR_RESULT.BAD_BILL_ID
             AND T.ENTITY_ID = CUR_RESULT.ENTITY_ID;
      EXCEPTION WHEN OTHERS THEN
            ROLLBACK;
            P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
            P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_BAD_BILL_PROVISION_PREC_R',
                     SQLCODE,
                     '获取天数差出错！ENTITY_ID：'||CUR_RESULT.ENTITY_ID||'。BAD_BILL_ID：'||CUR_RESULT.BAD_BILL_ID||'。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
            RETURN;
      END;

      --记录数据
      BEGIN
          SELECT COUNT(0)
            INTO P_COUNT
            FROM T_SO_BAD_BILL_PROVISION_PREC_R T
           WHERE T.CUSTOMER_ID = CUR_RESULT.CUSTOMER_ID
             AND TRUNC(T.CREATION_DATE,'DD') = TRUNC(P_DATEAD,'DD')
             AND T.SALES_MAIN_TYPE_CODE = CUR_RESULT.SALES_MAIN_TYPE_CODE
             AND T.ENTITY_ID = CUR_RESULT.ENTITY_ID
             -- add by tangfeng 20150728
             AND T.SALES_CENTER_CODE = CUR_RESULT.SALES_CENTER_CODE;
      EXCEPTION WHEN OTHERS THEN
              ROLLBACK;
              P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
              P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_BAD_BILL_PROVISION_PREC_R',
                       SQLCODE,
                       '记录数据查询出错！ENTITY_ID：'||CUR_RESULT.ENTITY_ID||'。CUSTOMER_ID：'||CUR_RESULT.CUSTOMER_ID||'。SALES_MAIN_TYPE_CODE：'||CUR_RESULT.SALES_MAIN_TYPE_CODE||'。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
              RETURN;
      END;

       K :=0;
       H :=13;
      --循环逾期分段应收
      FOR CUR1 IN (SELECT * FROM T_AR_OD_ACCOUNT_AGE_CONF T WHERE T.ENTITY_ID = CUR_RESULT.ENTITY_ID ORDER BY T.OD_START)  --by anht
      --CUR1循环开始
      LOOP
          --有记录修改
          IF (P_COUNT>0) THEN
              K :=K + 1;
              H :=H + 1;
              --逾期分段应收
              IF (P_DAY >= CUR1.OD_START) AND (P_DAY <= CUR1.OD_FINAL) THEN
                BEGIN
                  --修改逾期分段应收金额
                  V_UPDATE_COLS := ' T.OVERDUE_AMOUNT = NVL(T.OVERDUE_AMOUNT, 0) + ' || 'NVL(' || CUR_RESULT.AMOUNT || ', 0)'
                               ||  ',T.ATTRIBUTE'||K||'= NVL(T.ATTRIBUTE'||K||',0) + NVL(' || CUR_RESULT.AMOUNT || ',0)' ;
                  V_UPDATE_WHERE := ' WHERE T.CUSTOMER_ID = ' || CUR_RESULT.CUSTOMER_ID || ' AND T.ENTITY_ID = ' || CUR_RESULT.ENTITY_ID || ' AND T.SALES_MAIN_TYPE_CODE = '''||CUR_RESULT.SALES_MAIN_TYPE_CODE||'''';
                  V_UPDATE_WHERE := V_UPDATE_WHERE || ' AND T.SALES_CENTER_CODE = '''|| CUR_RESULT.SALES_CENTER_CODE || '''' || ' AND TO_CHAR(T.CREATION_DATE, ''yyyy-MM-dd'') = ''' || TO_CHAR(P_DATEAD, 'yyyy-MM-dd')||'''';
                  V_SQL_UPDATE := V_UPDATE_TABLE || V_UPDATE_COLS || V_UPDATE_WHERE ;
                  --dbms_output.put_line('A:'||V_SQL_UPDATE);
                  --执行修改
                  EXECUTE IMMEDIATE V_SQL_UPDATE ;
               EXCEPTION WHEN  OTHERS THEN
                  ROLLBACK;
                  P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                  P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_BAD_BILL_PROVISION_PREC_R',
                           SQLCODE,
                           '修改逾期分段应收金额出错！V_SQL_UPDATE：'||V_SQL_UPDATE||'。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                  RETURN;
                END;

                  IF (CUR1.STATUS = 'Y') THEN
                    BEGIN
                        --修改逾期分段坏账计提金额(增加四舍五入, by tangfeng)
                        V_UPDATE_COLS := ' T.ATTRIBUTE'||H||'= ROUND((NVL(T.OVERDUE_AMOUNT,0) +' || 'NVL(' || CUR_RESULT.AMOUNT || ', 0)) * '
                                     ||  CUR1.PROVISION_STANDARDS/100 ||', 2)';
  --                      V_UPDATE_COLS := ' T.OVERDUE_AMOUNT = NVL(T.OVERDUE_AMOUNT, 0) + ' || 'NVL(' || CUR_RESULT.AMOUNT || ', 0)'
  --                                   ||  ',T.ATTRIBUTE'||H||'= ROUND((NVL(T.OVERDUE_AMOUNT,0) +' || 'NVL(' || CUR_RESULT.AMOUNT || ', 0)) * '
  --                                   ||  CUR1.PROVISION_STANDARDS/100 ||', 2)';
                        V_UPDATE_WHERE := ' WHERE T.CUSTOMER_ID = ' || CUR_RESULT.CUSTOMER_ID || ' AND T.ENTITY_ID = ' || CUR_RESULT.ENTITY_ID || ' AND T.SALES_MAIN_TYPE_CODE = '''||CUR_RESULT.SALES_MAIN_TYPE_CODE||'''';
                        V_UPDATE_WHERE := V_UPDATE_WHERE || ' AND T.SALES_CENTER_CODE = '''|| CUR_RESULT.SALES_CENTER_CODE || '''' || ' AND TO_CHAR(T.CREATION_DATE, ''yyyy-MM-dd'') = ''' || TO_CHAR(P_DATEAD, 'yyyy-MM-dd')||'''';
                        V_SQL_UPDATE := V_UPDATE_TABLE || V_UPDATE_COLS || V_UPDATE_WHERE ;
                       --dbms_output.put_line('B:'||V_SQL_UPDATE);
                        --执行修改
                        EXECUTE IMMEDIATE V_SQL_UPDATE ;
                    EXCEPTION WHEN  OTHERS THEN
                        ROLLBACK;
                        P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                        P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_BAD_BILL_PROVISION_PREC_R',
                                 SQLCODE,
                                 '修改逾期分段坏账计提金额出错！V_SQL_UPDATE：'||V_SQL_UPDATE||'。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                        RETURN;
                    END;
                  END IF;

                --回写坏账沉淀ID  --by anht
                /*BEGIN
                  UPDATE T_SO_BAD_BILL_PROVISION_OLD T
                     SET T.BAD_PREC_BILL_ID =
                         (SELECT DISTINCT T.BAD_PREC_BILL_ID
                            FROM T_SO_BAD_BILL_PROVISION_PREC_R T
                           WHERE T.CUSTOMER_ID = CUR_RESULT.CUSTOMER_ID
                             AND T.ENTITY_ID = CUR_RESULT.ENTITY_ID
                             AND T.SALES_MAIN_TYPE_CODE =
                                 CUR_RESULT.SALES_MAIN_TYPE_CODE)
                   WHERE T.BAD_BILL_ID = CUR_RESULT.BAD_BILL_ID;
                EXCEPTION WHEN  OTHERS THEN
                    ROLLBACK;
                    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_BAD_BILL_PROVISION_PREC_R',
                             SQLCODE,
                             '回写坏账沉淀ID出错！ENTITY_ID：'||CUR_RESULT.ENTITY_ID||'。SALES_CENTER_ID：'||CUR_RESULT.SALES_CENTER_ID||'。CUSTOMER_ID：'||CUR_RESULT.CUSTOMER_ID||'。SALES_MAIN_TYPE_CODE：'||CUR_RESULT.SALES_MAIN_TYPE_CODE||'。BAD_BILL_ID：'||CUR_RESULT.BAD_BILL_ID||'。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                    RETURN;
                END;*/
              END IF;
          END IF;
          --无记录插入
          IF (P_COUNT=0) THEN
              K :=K + 1;
              H :=H + 1;
              --获取坏账沉淀序列
              BEGIN
                   SELECT S_SO_BAD_BILL_PROVISION_PREC_R.NEXTVAL INTO P_BAD_PREC_BILL_ID FROM DUAL;
              EXCEPTION WHEN  OTHERS THEN
                      ROLLBACK ;
                      P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                      P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_BAD_BILL_PROVISION_PREC_R',
                               SQLCODE,
                               '获取坏账沉淀序列出错！错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                      RETURN;
              END;

             --逾期分段应收插入
             IF (P_DAY >= CUR1.OD_START) AND (P_DAY <= CUR1.OD_FINAL) THEN
                BEGIN
                  V_INSERT_COLS :=
                 '(BAD_PREC_BILL_ID
                  ,CUSTOMER_ID
                  ,OVERDUE_AMOUNT
                  ,CUSTOMER_CODE
                  ,CUSTOMER_NAME
                  ,ENTITY_ID
                  ,SALES_MAIN_TYPE_ID
                  ,SALES_MAIN_TYPE_CODE
                  ,SALES_MAIN_TYPE_NAME
                  ,SALES_CENTER_ID
                  ,SALES_CENTER_CODE
                  ,SALES_CENTER_NAME
                  ,CREATED_BY
                  ,CREATION_DATE
                  ,LAST_UPDATE_BY
                  ,LAST_UPDATE_DATE
                  ,BAD_STATUS
                  ,ATTRIBUTE'||K||')';

                  V_INSERT_VALUES :=' VALUES ('
                  ||P_BAD_PREC_BILL_ID||','
                  ||CUR_RESULT.CUSTOMER_ID||','
                  ||CUR_RESULT.AMOUNT||','''
                  ||CUR_RESULT.CUSTOMER_CODE||''','''
                  ||CUR_RESULT.CUSTOMER_NAME||''','
                  ||CUR_RESULT.ENTITY_ID||','''

                  ||CUR_RESULT.SALES_MAIN_TYPE_ID||''','''
                  ||CUR_RESULT.SALES_MAIN_TYPE_CODE||''','''
                  ||CUR_RESULT.SALES_MAIN_TYPE_NAME||''','''

                  ||CUR_RESULT.SALES_CENTER_ID||''','''
                  ||CUR_RESULT.SALES_CENTER_CODE||''','''
                  ||CUR_RESULT.SALES_CENTER_NAME||''','
                  ||'''SYSTEM''' || ','''
                  ||P_DATEAD||''','
                  ||'''SYSTEM''' || ','''
                  ||P_DATEAD||''','
                  ||'''0'''||','
                  ||CUR_RESULT.AMOUNT||')';

                V_SQL_INSERT := V_INSERT_TABLE || V_INSERT_COLS || V_INSERT_VALUES ;
                 -- dbms_output.put_line('C:'||V_SQL_INSERT);
                --执行插入
                EXECUTE IMMEDIATE V_SQL_INSERT ;
                COMMIT;
                EXCEPTION WHEN  OTHERS THEN
                        ROLLBACK ;
                        P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                        P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_BAD_BILL_PROVISION_PREC_R',
                                 SQLCODE,
                                 '逾期分段应收插入出错！K:'||K||'。V_INSERT_VALUES：'||V_INSERT_VALUES||'。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                        RETURN;
                END;

                BEGIN
                  IF (CUR1.STATUS = 'Y' ) THEN
                    --修改逾期分段坏账计提金额(增加四舍五入, by tangfeng)
                    V_UPDATE_COLS :=  'T.ATTRIBUTE'||H||'= ROUND(NVL(' || CUR_RESULT.AMOUNT || ', 0) * '||  CUR1.PROVISION_STANDARDS/100||', 2)';
                    V_UPDATE_WHERE := ' WHERE T.BAD_PREC_BILL_ID = ' ||P_BAD_PREC_BILL_ID ;

                    V_SQL_UPDATE := V_UPDATE_TABLE || V_UPDATE_COLS || V_UPDATE_WHERE ;
                    --dbms_output.put_line('D:'||V_SQL_UPDATE);
                    --执行修改
                    EXECUTE IMMEDIATE V_SQL_UPDATE ;
                  END IF;
                EXCEPTION WHEN  OTHERS THEN
                  ROLLBACK ;
                  P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                  P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_BAD_BILL_PROVISION_PREC_R',
                           SQLCODE,
                           '修改逾期分段坏账计提金额出错！V_SQL_UPDATE：'||V_SQL_UPDATE||'。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
                  RETURN;
                END;
             END IF;

          END IF;
      END LOOP;--CUR1循环结束
      END LOOP;--MY_CUR循环结束
      COMMIT;
      CLOSE MY_CUR;
    END IF;
    P_RESULT := '坏账准备计提沉淀过程执行成功！';
  EXCEPTION WHEN  OTHERS THEN
      ROLLBACK ;
      P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
      P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_SO_BAD_BILL_PROVISION_PREC_R',
               SQLCODE,
               '坏账准备计提沉淀过程出错！错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
      RETURN ;
  END;

  -- 重置核销状态
  PROCEDURE P_RESET_WRITE_OFF_STATUS
  (
    IN_ENTITY_ID IN NUMBER,  --主体
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
           V_PARAM_ENTITY_ID NUMBER;
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    V_PARAM_ENTITY_ID :=IN_ENTITY_ID;
    -- 未核销
    UPDATE CIMS.T_SO_HEADER H SET H.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, H.APPLIED_DATE = SYSDATE,H.LAST_UPDATE_DATE = SYSDATE
    WHERE H.ENTITY_ID = V_PARAM_ENTITY_ID AND EXISTS (SELECT 1 FROM CIMS.T_AR_WRITE_OFF_CHECK T WHERE H.SO_NUM = T.SO_NUM AND T.WRITE_OFF_CASH = 0 /**AND T.ORDER_TYPE IN ('1', '-1')**/)
          AND H.APPLIED_FLAG <> PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE;
    
    UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS H SET H.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, H.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),UPDATED_DATE= SYSDATE
    WHERE H.ENTITY_ID = V_PARAM_ENTITY_ID AND EXISTS (SELECT 1 FROM CIMS.T_AR_WRITE_OFF_CHECK T WHERE H.CASH_RECEIPT_CODE = T.SO_NUM AND T.WRITE_OFF_CASH = 0 /**AND T.ORDER_TYPE NOT IN ('1', '-1')**/)
          AND H.ATTRIBUTE5 <> PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE;
    -- 部分核销
    UPDATE CIMS.T_SO_HEADER H SET H.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, H.APPLIED_DATE = SYSDATE,H.LAST_UPDATE_DATE = SYSDATE
    WHERE H.ENTITY_ID = V_PARAM_ENTITY_ID AND EXISTS (SELECT 1 FROM CIMS.T_AR_WRITE_OFF_CHECK T WHERE H.SO_NUM = T.SO_NUM AND T.WRITE_OFF_CASH > 0 AND ABS(ROUND(T.ORDER_CASH, 2)) > T.WRITE_OFF_CASH /**AND T.ORDER_TYPE IN ('1', '-1')**/)
          AND H.APPLIED_FLAG <> PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART;
  
    UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS H SET H.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART, H.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),UPDATED_DATE= SYSDATE
    WHERE H.ENTITY_ID = V_PARAM_ENTITY_ID AND EXISTS (SELECT 1 FROM CIMS.T_AR_WRITE_OFF_CHECK T WHERE H.CASH_RECEIPT_CODE = T.SO_NUM AND T.WRITE_OFF_CASH > 0 AND ABS(ROUND(T.ORDER_CASH, 2)) > T.WRITE_OFF_CASH /**AND T.ORDER_TYPE NOT IN ('1', '-1')**/)
          AND H.ATTRIBUTE5 <> PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART;
    -- 全部核销
    UPDATE CIMS.T_SO_HEADER H SET H.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, H.APPLIED_DATE = SYSDATE,H.LAST_UPDATE_DATE = SYSDATE
    WHERE H.ENTITY_ID = V_PARAM_ENTITY_ID AND EXISTS (SELECT 1 FROM CIMS.T_AR_WRITE_OFF_CHECK T WHERE H.SO_NUM = T.SO_NUM AND T.WRITE_OFF_CASH > 0 AND ABS(ROUND(T.ORDER_CASH, 2)) = T.WRITE_OFF_CASH /**AND T.ORDER_TYPE IN ('1', '-1')**/)
          AND H.APPLIED_FLAG <> PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL;
   
   UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS H SET H.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL, H.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),UPDATED_DATE= SYSDATE
    WHERE H.ENTITY_ID = V_PARAM_ENTITY_ID AND EXISTS (SELECT 1 FROM CIMS.T_AR_WRITE_OFF_CHECK T WHERE H.CASH_RECEIPT_CODE = T.SO_NUM AND T.WRITE_OFF_CASH > 0 AND ABS(ROUND(T.ORDER_CASH, 2)) = T.WRITE_OFF_CASH /**AND T.ORDER_TYPE NOT IN ('1', '-1')**/)
          AND H.ATTRIBUTE5 <> PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL;
    COMMIT;
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_RESET_WRITE_OFF_STATUS',
                  SQLCODE,
                  '重置销售单、到款单核销状态出错！错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
  END;

  -- 刷新物化视图
  PROCEDURE P_REFRESH_MATERIALIZED_VIEW
  (
      P_MATERIALIZED_VIEW_NAME IN VARCHAR2, -- 物化视图名称
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
  BEGIN
    DBMS_MVIEW.REFRESH(P_MATERIALIZED_VIEW_NAME);
--    DBMS_MVIEW.REFRESH('MV_AR_WRITE_OFF_CHECK');
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    P_RESULT := '物化视图刷新成功！';
  EXCEPTION WHEN OTHERS THEN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_REFRESH_MATERIALIZED_VIEW',
                  SQLCODE,
                  '物化视图('||P_MATERIALIZED_VIEW_NAME||')刷新出错！错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
  END;
  
  
  
-- 比较更新核销校正表
PROCEDURE P_ALL_FREEZE_WRITE_OFF(
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
) IS
   N_COUNT NUMBER;
begin
  P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
  FOR FREEZE_WRITE_ROW in (  
        SELECT ENTITY_ID
              ,CUSTOMER_ID
              ,ACCOUNT_ID
              ,HEADER_ID
              ,SO_NUM
              ,ORDER_TYPE
              ,ORDER_STATUS
              ,ERP_OU_ID
              ,ERROR_CASH
              ,ORDER_CASH
              ,WRITE_OFF_CASH
              ,AGE_CASH
              ,SO_OR_RECEIPT
              ,ERP_ARINVOICE_CODE
              ,AR_RECEIPT_CODE
              ,ERP_APPLIED_AMOUNT
              ,(CASE WHEN AW.ERROR_CASH = 0 THEN 'N' ELSE 'Y' END) AS ERROR_FLAG
         FROM CIMS.V_AR_WRITE_OFF_CHECK_REP_NEW AW
         minus
         select ENTITY_ID
              ,CUSTOMER_ID
              ,ACCOUNT_ID
              ,HEADER_ID
              ,SO_NUM
              ,ORDER_TYPE
              ,ORDER_STATUS
              ,ERP_OU_ID
              ,ERROR_CASH
              ,ORDER_CASH
              ,WRITE_OFF_CASH
              ,AGE_CASH
              ,SO_OR_RECEIPT
              ,ERP_ARINVOICE_CODE
              ,AR_RECEIPT_CODE
              ,ERP_APPLIED_AMOUNT
              ,ERROR_FLAG
             from cims.T_AR_WRITE_OFF_CHECK
         )loop
             
            FOR AR_WRITE_OFF IN (
              SELECT ENTITY_ID
                      ,CUSTOMER_ID
                      ,CUSTOMER_CODE
                      ,CUSTOMER_NAME
                      ,CUSTOMER_FLAG
                      ,ACCOUNT_ID
                      ,ACCOUNT_CODE
                      ,ACCOUNT_STATUS
                      ,SALES_CENTER_ID
                      ,SALES_CENTER_CODE
                      ,SALES_CENTER_NAME
                      ,HEADER_ID
                      ,SO_NUM
                      ,ORDER_TYPE
                      ,ORDER_STATUS
                      ,ORDER_STATUS_NAME
                      ,ERP_OU_ID
                      ,ERROR_CASH
                      ,ORDER_CASH
                      ,WRITE_OFF_CASH
                      ,AGE_CASH
                      ,SHOULD_WRITE_OFF_FLAG
                      ,SHOULD_WRITE_OFF_DATE
                      ,AR_CONF_WRITE_OFF_DATE
                      ,WRITE_OFF_FLAG
                      ,WRITE_OFF_DATE
                      ,DISCOUNT_RATE
                      ,SO_OR_RECEIPT
                      ,MAX_MATCH_DATE
                      ,LAST_UPDATE_DATE
                      ,ERP_ARINVOICE_CODE
                      ,AR_RECEIPT_CODE
                      ,ERP_APPLIED_AMOUNT
                      ,(CASE WHEN AW.ERROR_CASH = 0 THEN 'N' ELSE 'Y' END) AS ERROR_FLAG
                 FROM CIMS.V_AR_WRITE_OFF_CHECK_REP_NEW AW
                 WHERE AW.SO_NUM= FREEZE_WRITE_ROW.SO_NUM
            )LOOP
               BEGIN
                     SELECT 
                       COUNT(SO_NUM) 
                     INTO 
                        N_COUNT 
                     FROM 
                        T_AR_WRITE_OFF_CHECK OC
                     WHERE
                        OC.SO_NUM = AR_WRITE_OFF.SO_NUM;
                     IF N_COUNT>0 THEN
                          UPDATE T_AR_WRITE_OFF_CHECK O
                             SET O.CUSTOMER_FLAG = AR_WRITE_OFF.CUSTOMER_FLAG
                                ,O.ACCOUNT_STATUS = AR_WRITE_OFF.ACCOUNT_STATUS
                                ,O.ORDER_STATUS =AR_WRITE_OFF.ORDER_STATUS
                                ,O.ORDER_STATUS_NAME =AR_WRITE_OFF.ORDER_STATUS_NAME
                                ,O.ERROR_CASH =AR_WRITE_OFF.ERROR_CASH
                                ,O.ORDER_CASH =AR_WRITE_OFF.ORDER_CASH
                                ,O.WRITE_OFF_CASH =AR_WRITE_OFF.WRITE_OFF_CASH
                                ,O.AGE_CASH =AR_WRITE_OFF.AGE_CASH
                                ,O.SHOULD_WRITE_OFF_FLAG =AR_WRITE_OFF.SHOULD_WRITE_OFF_FLAG
                                ,O.SHOULD_WRITE_OFF_DATE =AR_WRITE_OFF.SHOULD_WRITE_OFF_DATE
                                ,O.AR_CONF_WRITE_OFF_DATE =AR_WRITE_OFF.AR_CONF_WRITE_OFF_DATE
                                ,O.WRITE_OFF_FLAG =AR_WRITE_OFF.WRITE_OFF_FLAG
                                ,O.WRITE_OFF_DATE =AR_WRITE_OFF.WRITE_OFF_DATE
                                ,O.DISCOUNT_RATE =AR_WRITE_OFF.DISCOUNT_RATE
                                ,O.SO_OR_RECEIPT =AR_WRITE_OFF.SO_OR_RECEIPT
                                ,O.MAX_MATCH_DATE =AR_WRITE_OFF.MAX_MATCH_DATE
                                ,O.LAST_UPDATE_DATE = SYSDATE
                                ,O.ERP_ARINVOICE_CODE =AR_WRITE_OFF.ERP_ARINVOICE_CODE
                                ,O.AR_RECEIPT_CODE =AR_WRITE_OFF.AR_RECEIPT_CODE
                                ,O.ERP_APPLIED_AMOUNT =AR_WRITE_OFF.ERP_APPLIED_AMOUNT
                                ,O.ERROR_FLAG =AR_WRITE_OFF.ERROR_FLAG
                             where O.SO_NUM = AR_WRITE_OFF.SO_NUM;   
                     ELSE
                          INSERT INTO T_AR_WRITE_OFF_CHECK(ENTITY_ID,CUSTOMER_ID,CUSTOMER_CODE,CUSTOMER_NAME,CUSTOMER_FLAG,ACCOUNT_ID,ACCOUNT_CODE,ACCOUNT_STATUS,SALES_CENTER_ID,SALES_CENTER_CODE,SALES_CENTER_NAME,HEADER_ID,SO_NUM,ORDER_TYPE,ORDER_STATUS,ORDER_STATUS_NAME,ERP_OU_ID,ERROR_CASH,ORDER_CASH,WRITE_OFF_CASH,AGE_CASH,SHOULD_WRITE_OFF_FLAG,SHOULD_WRITE_OFF_DATE,AR_CONF_WRITE_OFF_DATE,WRITE_OFF_FLAG,WRITE_OFF_DATE,DISCOUNT_RATE,SO_OR_RECEIPT,MAX_MATCH_DATE,LAST_UPDATE_DATE,ERP_ARINVOICE_CODE,AR_RECEIPT_CODE,ERP_APPLIED_AMOUNT,ERROR_FLAG)
                          VALUES (AR_WRITE_OFF.ENTITY_ID,AR_WRITE_OFF.CUSTOMER_ID,AR_WRITE_OFF.CUSTOMER_CODE,AR_WRITE_OFF.CUSTOMER_NAME,AR_WRITE_OFF.CUSTOMER_FLAG,AR_WRITE_OFF.ACCOUNT_ID,AR_WRITE_OFF.ACCOUNT_CODE,AR_WRITE_OFF.ACCOUNT_STATUS,AR_WRITE_OFF.SALES_CENTER_ID,AR_WRITE_OFF.SALES_CENTER_CODE,AR_WRITE_OFF.SALES_CENTER_NAME,AR_WRITE_OFF.HEADER_ID,AR_WRITE_OFF.SO_NUM,AR_WRITE_OFF.ORDER_TYPE,AR_WRITE_OFF.ORDER_STATUS,AR_WRITE_OFF.ORDER_STATUS_NAME,AR_WRITE_OFF.ERP_OU_ID,AR_WRITE_OFF.ERROR_CASH,AR_WRITE_OFF.ORDER_CASH,AR_WRITE_OFF.WRITE_OFF_CASH,AR_WRITE_OFF.AGE_CASH,AR_WRITE_OFF.SHOULD_WRITE_OFF_FLAG,AR_WRITE_OFF.SHOULD_WRITE_OFF_DATE,AR_WRITE_OFF.AR_CONF_WRITE_OFF_DATE,AR_WRITE_OFF.WRITE_OFF_FLAG,AR_WRITE_OFF.WRITE_OFF_DATE,AR_WRITE_OFF.DISCOUNT_RATE,AR_WRITE_OFF.SO_OR_RECEIPT,AR_WRITE_OFF.MAX_MATCH_DATE,SYSDATE,AR_WRITE_OFF.ERP_ARINVOICE_CODE,AR_WRITE_OFF.AR_RECEIPT_CODE,AR_WRITE_OFF.ERP_APPLIED_AMOUNT,AR_WRITE_OFF.ERROR_FLAG);
                     END IF;   
                     COMMIT;   
               EXCEPTION WHEN OTHERS THEN
                   null;
               END;
             END LOOP;  
   end loop ;
end P_ALL_FREEZE_WRITE_OFF;
  
  
-- 增量更新核销校正表
  PROCEDURE P_INCREMENTAL_FREEZE_WRITE_OFF
  (
      ID_CURRENT_DATE   IN   DATE,      --当前日期
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
     D_CUR_DATE DATE;
     N_COUNT NUMBER;
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    D_CUR_DATE := trunc(ID_CURRENT_DATE)-1;
    
    FOR AR_WRITE_OFF IN (
        SELECT ENTITY_ID
                ,CUSTOMER_ID
                ,CUSTOMER_CODE
                ,CUSTOMER_NAME
                ,CUSTOMER_FLAG
                ,ACCOUNT_ID
                ,ACCOUNT_CODE
                ,ACCOUNT_STATUS
                ,SALES_CENTER_ID
                ,SALES_CENTER_CODE
                ,SALES_CENTER_NAME
                ,HEADER_ID
                ,SO_NUM
                ,ORDER_TYPE
                ,ORDER_STATUS
                ,ORDER_STATUS_NAME
                ,ERP_OU_ID
                ,ERROR_CASH
                ,ORDER_CASH
                ,WRITE_OFF_CASH
                ,AGE_CASH
                ,SHOULD_WRITE_OFF_FLAG
                ,SHOULD_WRITE_OFF_DATE
                ,AR_CONF_WRITE_OFF_DATE
                ,WRITE_OFF_FLAG
                ,WRITE_OFF_DATE
                ,DISCOUNT_RATE
                ,SO_OR_RECEIPT
                ,MAX_MATCH_DATE
                ,LAST_UPDATE_DATE
                ,ERP_ARINVOICE_CODE
                ,AR_RECEIPT_CODE
                ,ERP_APPLIED_AMOUNT
                ,(CASE WHEN AW.ERROR_CASH = 0 THEN 'N' ELSE 'Y' END) AS ERROR_FLAG
           FROM CIMS.V_AR_WRITE_OFF_CHECK_REP_NEW AW
           WHERE AW.LAST_UPDATE_DATE >= D_CUR_DATE
      )LOOP
         BEGIN
               SELECT 
                 COUNT(SO_NUM) 
               INTO 
                  N_COUNT 
               FROM 
                  T_AR_WRITE_OFF_CHECK OC
               WHERE
                  OC.SO_NUM = AR_WRITE_OFF.SO_NUM;
               IF N_COUNT>0 THEN
                    UPDATE T_AR_WRITE_OFF_CHECK O
                       SET O.CUSTOMER_FLAG = AR_WRITE_OFF.CUSTOMER_FLAG
                          ,O.ACCOUNT_STATUS = AR_WRITE_OFF.ACCOUNT_STATUS
                          ,O.ORDER_STATUS =AR_WRITE_OFF.ORDER_STATUS
                          ,O.ORDER_STATUS_NAME =AR_WRITE_OFF.ORDER_STATUS_NAME
                          ,O.ERROR_CASH =AR_WRITE_OFF.ERROR_CASH
                          ,O.ORDER_CASH =AR_WRITE_OFF.ORDER_CASH
                          ,O.WRITE_OFF_CASH =AR_WRITE_OFF.WRITE_OFF_CASH
                          ,O.AGE_CASH =AR_WRITE_OFF.AGE_CASH
                          ,O.SHOULD_WRITE_OFF_FLAG =AR_WRITE_OFF.SHOULD_WRITE_OFF_FLAG
                          ,O.SHOULD_WRITE_OFF_DATE =AR_WRITE_OFF.SHOULD_WRITE_OFF_DATE
                          ,O.AR_CONF_WRITE_OFF_DATE =AR_WRITE_OFF.AR_CONF_WRITE_OFF_DATE
                          ,O.WRITE_OFF_FLAG =AR_WRITE_OFF.WRITE_OFF_FLAG
                          ,O.WRITE_OFF_DATE =AR_WRITE_OFF.WRITE_OFF_DATE
                          ,O.DISCOUNT_RATE =AR_WRITE_OFF.DISCOUNT_RATE
                          ,O.SO_OR_RECEIPT =AR_WRITE_OFF.SO_OR_RECEIPT
                          ,O.MAX_MATCH_DATE =AR_WRITE_OFF.MAX_MATCH_DATE
                          ,O.LAST_UPDATE_DATE = SYSDATE
                          ,O.ERP_ARINVOICE_CODE =AR_WRITE_OFF.ERP_ARINVOICE_CODE
                          ,O.AR_RECEIPT_CODE =AR_WRITE_OFF.AR_RECEIPT_CODE
                          ,O.ERP_APPLIED_AMOUNT =AR_WRITE_OFF.ERP_APPLIED_AMOUNT
                          ,O.ERROR_FLAG =AR_WRITE_OFF.ERROR_FLAG
                       where O.SO_NUM = AR_WRITE_OFF.SO_NUM;   
               ELSE
                    INSERT INTO T_AR_WRITE_OFF_CHECK(ENTITY_ID,CUSTOMER_ID,CUSTOMER_CODE,CUSTOMER_NAME,CUSTOMER_FLAG,ACCOUNT_ID,ACCOUNT_CODE,ACCOUNT_STATUS,SALES_CENTER_ID,SALES_CENTER_CODE,SALES_CENTER_NAME,HEADER_ID,SO_NUM,ORDER_TYPE,ORDER_STATUS,ORDER_STATUS_NAME,ERP_OU_ID,ERROR_CASH,ORDER_CASH,WRITE_OFF_CASH,AGE_CASH,SHOULD_WRITE_OFF_FLAG,SHOULD_WRITE_OFF_DATE,AR_CONF_WRITE_OFF_DATE,WRITE_OFF_FLAG,WRITE_OFF_DATE,DISCOUNT_RATE,SO_OR_RECEIPT,MAX_MATCH_DATE,LAST_UPDATE_DATE,ERP_ARINVOICE_CODE,AR_RECEIPT_CODE,ERP_APPLIED_AMOUNT,ERROR_FLAG)
                    VALUES (AR_WRITE_OFF.ENTITY_ID,AR_WRITE_OFF.CUSTOMER_ID,AR_WRITE_OFF.CUSTOMER_CODE,AR_WRITE_OFF.CUSTOMER_NAME,AR_WRITE_OFF.CUSTOMER_FLAG,AR_WRITE_OFF.ACCOUNT_ID,AR_WRITE_OFF.ACCOUNT_CODE,AR_WRITE_OFF.ACCOUNT_STATUS,AR_WRITE_OFF.SALES_CENTER_ID,AR_WRITE_OFF.SALES_CENTER_CODE,AR_WRITE_OFF.SALES_CENTER_NAME,AR_WRITE_OFF.HEADER_ID,AR_WRITE_OFF.SO_NUM,AR_WRITE_OFF.ORDER_TYPE,AR_WRITE_OFF.ORDER_STATUS,AR_WRITE_OFF.ORDER_STATUS_NAME,AR_WRITE_OFF.ERP_OU_ID,AR_WRITE_OFF.ERROR_CASH,AR_WRITE_OFF.ORDER_CASH,AR_WRITE_OFF.WRITE_OFF_CASH,AR_WRITE_OFF.AGE_CASH,AR_WRITE_OFF.SHOULD_WRITE_OFF_FLAG,AR_WRITE_OFF.SHOULD_WRITE_OFF_DATE,AR_WRITE_OFF.AR_CONF_WRITE_OFF_DATE,AR_WRITE_OFF.WRITE_OFF_FLAG,AR_WRITE_OFF.WRITE_OFF_DATE,AR_WRITE_OFF.DISCOUNT_RATE,AR_WRITE_OFF.SO_OR_RECEIPT,AR_WRITE_OFF.MAX_MATCH_DATE,SYSDATE,AR_WRITE_OFF.ERP_ARINVOICE_CODE,AR_WRITE_OFF.AR_RECEIPT_CODE,AR_WRITE_OFF.ERP_APPLIED_AMOUNT,AR_WRITE_OFF.ERROR_FLAG);
               END IF;   
               COMMIT;   
         EXCEPTION WHEN OTHERS THEN
                ROLLBACK;
                P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
                P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_INCREMENTAL_FREEZE_WRITE_OFF', SQLCODE,
                        '增量更新核销校正表出错！单据号：'||AR_WRITE_OFF.SO_NUM||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
         END;
       END LOOP;  
         
    
    /*
    MERGE INTO T_AR_WRITE_OFF_CHECK O
    USING(
          SELECT ENTITY_ID
                ,CUSTOMER_ID
                ,CUSTOMER_CODE
                ,CUSTOMER_NAME
                ,CUSTOMER_FLAG
                ,ACCOUNT_ID
                ,ACCOUNT_CODE
                ,ACCOUNT_STATUS
                ,SALES_CENTER_ID
                ,SALES_CENTER_CODE
                ,SALES_CENTER_NAME
                ,HEADER_ID
                ,SO_NUM
                ,ORDER_TYPE
                ,ORDER_STATUS
                ,ORDER_STATUS_NAME
                ,ERP_OU_ID
                ,ERROR_CASH
                ,ORDER_CASH
                ,WRITE_OFF_CASH
                ,AGE_CASH
                ,SHOULD_WRITE_OFF_FLAG
                ,SHOULD_WRITE_OFF_DATE
                ,AR_CONF_WRITE_OFF_DATE
                ,WRITE_OFF_FLAG
                ,WRITE_OFF_DATE
                ,DISCOUNT_RATE
                ,SO_OR_RECEIPT
                ,MAX_MATCH_DATE
                ,LAST_UPDATE_DATE
                ,ERP_ARINVOICE_CODE
                ,AR_RECEIPT_CODE
                ,ERP_APPLIED_AMOUNT
                ,(CASE WHEN AWOCEN.ERROR_CASH = 0 THEN 'N' ELSE 'Y' END) AS ERROR_FLAG
           FROM CIMS.V_AR_WRITE_OFF_CHECK_REP_NEW AWOCEN
      ) B ON (B.SO_NUM = O.SO_NUM)
      WHEN MATCHED THEN
               UPDATE SET 
                  O.CUSTOMER_FLAG = B.CUSTOMER_FLAG
                  ,O.ACCOUNT_STATUS = B.ACCOUNT_STATUS
                  ,O.ORDER_STATUS =B.ORDER_STATUS
                  ,O.ORDER_STATUS_NAME =B.ORDER_STATUS_NAME
                  ,O.ERROR_CASH =B.ERROR_CASH
                  ,O.ORDER_CASH =B.ORDER_CASH
                  ,O.WRITE_OFF_CASH =B.WRITE_OFF_CASH
                  ,O.AGE_CASH =B.AGE_CASH
                  ,O.SHOULD_WRITE_OFF_FLAG =B.SHOULD_WRITE_OFF_FLAG
                  ,O.SHOULD_WRITE_OFF_DATE =B.SHOULD_WRITE_OFF_DATE
                  ,O.AR_CONF_WRITE_OFF_DATE =B.AR_CONF_WRITE_OFF_DATE
                  ,O.WRITE_OFF_FLAG =B.WRITE_OFF_FLAG
                  ,O.WRITE_OFF_DATE =B.WRITE_OFF_DATE
                  ,O.DISCOUNT_RATE =B.DISCOUNT_RATE
                  ,O.SO_OR_RECEIPT =B.SO_OR_RECEIPT
                  ,O.MAX_MATCH_DATE =B.MAX_MATCH_DATE
                  ,O.LAST_UPDATE_DATE = SYSDATE
                  ,O.ERP_ARINVOICE_CODE =B.ERP_ARINVOICE_CODE
                  ,O.AR_RECEIPT_CODE =B.AR_RECEIPT_CODE
                  ,O.ERP_APPLIED_AMOUNT =B.ERP_APPLIED_AMOUNT
                  ,O.ERROR_FLAG =B.ERROR_FLAG
      WHEN NOT MATCHED THEN
               INSERT (ENTITY_ID,CUSTOMER_ID,CUSTOMER_CODE,CUSTOMER_NAME,CUSTOMER_FLAG,ACCOUNT_ID,ACCOUNT_CODE,ACCOUNT_STATUS,SALES_CENTER_ID,SALES_CENTER_CODE,SALES_CENTER_NAME,HEADER_ID,SO_NUM,ORDER_TYPE,ORDER_STATUS,ORDER_STATUS_NAME,ERP_OU_ID,ERROR_CASH,ORDER_CASH,WRITE_OFF_CASH,AGE_CASH,SHOULD_WRITE_OFF_FLAG,SHOULD_WRITE_OFF_DATE,AR_CONF_WRITE_OFF_DATE,WRITE_OFF_FLAG,WRITE_OFF_DATE,DISCOUNT_RATE,SO_OR_RECEIPT,MAX_MATCH_DATE,LAST_UPDATE_DATE,ERP_ARINVOICE_CODE,AR_RECEIPT_CODE,ERP_APPLIED_AMOUNT,ERROR_FLAG)
               VALUES (B.ENTITY_ID,B.CUSTOMER_ID,B.CUSTOMER_CODE,B.CUSTOMER_NAME,B.CUSTOMER_FLAG,B.ACCOUNT_ID,B.ACCOUNT_CODE,B.ACCOUNT_STATUS,B.SALES_CENTER_ID,B.SALES_CENTER_CODE,B.SALES_CENTER_NAME,B.HEADER_ID,B.SO_NUM,B.ORDER_TYPE,B.ORDER_STATUS,B.ORDER_STATUS_NAME,B.ERP_OU_ID,B.ERROR_CASH,B.ORDER_CASH,B.WRITE_OFF_CASH,B.AGE_CASH,B.SHOULD_WRITE_OFF_FLAG,B.SHOULD_WRITE_OFF_DATE,B.AR_CONF_WRITE_OFF_DATE,B.WRITE_OFF_FLAG,B.WRITE_OFF_DATE,B.DISCOUNT_RATE,B.SO_OR_RECEIPT,B.MAX_MATCH_DATE,SYSDATE,B.ERP_ARINVOICE_CODE,B.AR_RECEIPT_CODE,B.ERP_APPLIED_AMOUNT,B.ERROR_FLAG);
    */
    P_RESULT := '增量更新核销校正表成功！';
  EXCEPTION WHEN OTHERS THEN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_INCREMENTAL_FREEZE_WRITE_OFF',
                  SQLCODE,
                  '增量更新核销校正表出错！错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
  END;

  -- 核销金额大于单据金额数据自动修复
  PROCEDURE P_AUTO_REPAIR_ORDER_RECEIPT
  (    IN_ENTITY_ID IN NUMBER,  --主体
      P_AUTO_REPAIR_YES_OR_NO   IN VARCHAR2,
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
  V_ORDER_TYPE  VARCHAR2(10);
     V_PARAM_ENTITY_ID NUMBER;
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    V_PARAM_ENTITY_ID:=IN_ENTITY_ID;
    IF P_AUTO_REPAIR_YES_OR_NO = PKG_AR_WRITE_OFF.V_YES THEN
    	-- 刷新物化视图
   --   PKG_AR_WRITE_OFF.P_REFRESH_MATERIALIZED_VIEW(PKG_AR_WRITE_OFF.MV_AR_WRITE_OFF_CHECK_REP_NEW, P_RESULT, P_MESSAGE);
      -- 重置核销状态
    --  PKG_AR_WRITE_OFF.P_RESET_WRITE_OFF_STATUS(P_RESULT, P_MESSAGE);
      -- 2:作废 或 10：GTMS-已驳回 需解除核销关系 12:CIMS-撤销作废
      FOR ROW_ERROR_DATA IN (SELECT T.* FROM CIMS.T_AR_WRITE_OFF_CHECK T
                         WHERE  T.ENTITY_ID= V_PARAM_ENTITY_ID AND T.ORDER_STATUS IN ('2', '10','12') AND T.ORDER_TYPE IN ('1', '-1') AND T.WRITE_OFF_CASH > 0)
                         /**WHERE EXISTS (SELECT 1 FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H WHERE T.SO_NUM = H.CASH_RECEIPT_CODE AND H.RECEIPT_STATUS_ID IN (2, 10))) **/
      LOOP
        BEGIN
          SELECT (CASE WHEN ROW_ERROR_DATA.ORDER_TYPE IN (PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_RED, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_RETURN, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_RETURN_RED,
                                            PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT_RED, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_DISCOUNT, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_DISCOUNT_RED, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_RATE, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_RATE_RED)
                 THEN ROW_ERROR_DATA.ORDER_TYPE ELSE '1' END) INTO V_ORDER_TYPE FROM DUAL ;
          PKG_AR_WRITE_OFF.P_CANCEL_ORDER_RECEIPT(ROW_ERROR_DATA.SO_NUM, V_ORDER_TYPE,'ALL','#单据参与核销后'||ROW_ERROR_DATA.ORDER_STATUS_NAME, PKG_AR_WRITE_OFF.V_YES, P_RESULT, P_MESSAGE);
          IF P_MESSAGE <> PKG_AR_WRITE_OFF.V_SUCCESS THEN
            RAISE V_BIZ_EXCEPTION;
          END IF;
          COMMIT;
        EXCEPTION
          WHEN V_BIZ_EXCEPTION THEN
            ROLLBACK;
            P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
            P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AUTO_REPAIR_ORDER_RECEIPT', SQLCODE,
                  '#单据参与核销后('||ROW_ERROR_DATA.ORDER_STATUS_NAME||')解除核销出错！单据号：'||ROW_ERROR_DATA.SO_NUM||'。错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
          WHEN OTHERS THEN
            ROLLBACK;
            P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
            P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AUTO_REPAIR_ORDER_RECEIPT', SQLCODE,
                    '#单据参与核销后('||ROW_ERROR_DATA.ORDER_STATUS_NAME||')解除核销出错！单据号：'||ROW_ERROR_DATA.SO_NUM||'。错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
        END;
      END LOOP;
      FOR ROW_ERROR_DATA IN (SELECT T.* FROM T_AR_WRITE_OFF_CHECK T
                         WHERE T.ENTITY_ID= V_PARAM_ENTITY_ID AND NOT EXISTS (SELECT 1 FROM CIMS.T_AR_SETTLED_WRITE_OFF SWO WHERE SWO.ORDER_CODE = T.SO_NUM AND SWO.SETTLED_FLAG = PKG_AR_WRITE_OFF.V_NO)
                               AND ABS(ROUND(NVL(T.ORDER_CASH, 0), 2)) < T.WRITE_OFF_CASH AND T.ERROR_CASH > 0)
      LOOP
        BEGIN
          SELECT (CASE WHEN ROW_ERROR_DATA.ORDER_TYPE IN (PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_RED, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_RETURN, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_RETURN_RED,
                                            PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_SO_DISCOUNT_RED, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_DISCOUNT, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_DISCOUNT_RED, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_RATE, PKG_AR_WRITE_OFF.V_BIZ_SRC_BILL_RATE_RED)
                 THEN ROW_ERROR_DATA.ORDER_TYPE ELSE '1' END) INTO V_ORDER_TYPE FROM DUAL ;
          PKG_AR_WRITE_OFF.P_CANCEL_ORDER_RECEIPT(ROW_ERROR_DATA.SO_NUM, V_ORDER_TYPE,'ALL', '#核销金额大于单据金额', PKG_AR_WRITE_OFF.V_YES, P_RESULT, P_MESSAGE);
          IF P_MESSAGE <> PKG_AR_WRITE_OFF.V_SUCCESS THEN
            RAISE V_BIZ_EXCEPTION;
          END IF;
          COMMIT;
        EXCEPTION
          WHEN V_BIZ_EXCEPTION THEN
            ROLLBACK;
            P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
            P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AUTO_REPAIR_ORDER_RECEIPT', SQLCODE,
                  '核销金额大于单据金额解除核销出错！单据号：'||ROW_ERROR_DATA.SO_NUM||'，单据金额：'||ROUND(ROW_ERROR_DATA.SO_NUM, 2)||'，核销金额：'||ROW_ERROR_DATA.WRITE_OFF_CASH||'。错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
          WHEN OTHERS THEN
            ROLLBACK;
            P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
            P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AUTO_REPAIR_ORDER_RECEIPT', SQLCODE,
                    '核销金额大于单据金额解除核销出错！单据号：'||ROW_ERROR_DATA.SO_NUM||'，单据金额：'||ROUND(ROW_ERROR_DATA.SO_NUM, 2)||'，核销金额：'||ROW_ERROR_DATA.WRITE_OFF_CASH||'。错误日志：'||P_RESULT||'。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
        END;
      END LOOP;
    END IF;
    P_RESULT := '自动修复核销关系成功！';
  EXCEPTION WHEN OTHERS THEN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AUTO_REPAIR_ORDER_RECEIPT',
                  SQLCODE,
                  '自动修复核销关系出错！错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
  END;

  -- 修复为空的核销状态
  PROCEDURE P_AUTO_REPAIR_MATCH_STATUS
  ( IN_ENTITY_ID IN NUMBER,  --主体
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
       V_PARAM_ENTITY_ID NUMBER;
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    V_PARAM_ENTITY_ID := IN_ENTITY_ID;
    -- 修复未赋值的核销状态
    UPDATE CIMS.T_SO_HEADER H SET H.APPLIED_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, H.APPLIED_DATE = SYSDATE
    WHERE H.APPLIED_FLAG IS NULL AND H.ENTITY_ID = V_PARAM_ENTITY_ID;
    UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS H SET H.ATTRIBUTE5 = PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE, H.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
    WHERE H.ATTRIBUTE5 IS NULL  AND H.ENTITY_ID = V_PARAM_ENTITY_ID;
    COMMIT;
    P_RESULT := '修复为空的核销状态成功！';
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
    P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AUTO_REPAIR_MATCH_STATUS',
                  SQLCODE,
                  '修复为空的核销状态出错！错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
  END;

  FUNCTION F_AR_DEFAULT_SALE_MAIN_TYPE(
  --------------------   根据主体判断是否区分营销大类核销  -----------------
  ---------------------------   获取默认的营销大类  -----------------------
          ENTITY_ID                        IN NUMBER --主体ID
  ) RETURN PKG_AR_WRITE_OFF.AR_SALE_MAIN_TYPE AS

  P_AR_SALE_MAIN_TYPE PKG_AR_WRITE_OFF.AR_SALE_MAIN_TYPE;
  BEGIN
    -- 默认区分营销大类
    P_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF := PKG_AR_WRITE_OFF.V_YES;
    P_AR_SALE_MAIN_TYPE.DEFAULT_SALE_MAIN_TYPE_ID := 1;
    P_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF := PKG_BD.F_GET_PARAMETER_VALUE(PKG_AR_WRITE_OFF.V_AR_SALE_MAIN_TYPE_WRITE_OFF, ENTITY_ID, NULL, NULL);
    IF UPPER(P_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF) = PKG_AR_WRITE_OFF.V_NO THEN
      -- 不区分营销大类进行核销.系统参数定义的是默认营销大类编码
      P_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE := PKG_BD.F_GET_PARAMETER_VALUE(PKG_AR_WRITE_OFF.V_AR_SALE_MAIN_DEF_WRITE_OFF, ENTITY_ID, NULL, NULL);
      IF P_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE IS NULL THEN
        P_AR_SALE_MAIN_TYPE.P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.F_AR_DEFAULT_SALE_MAIN_TYPE',
                  SQLCODE,
                  '不区分营销大类查询默认营销大类为空！主体ID：'||ENTITY_ID||'。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
        P_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF := PKG_AR_WRITE_OFF.V_YES;
      ELSE
        -- 查询默认的营销大类
        SELECT DISTINCT T.ITEM_CLASS_ID, T.CLASS_NAME
               INTO P_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_ID, P_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_NAME
        FROM T_BD_ITEM_CLASS T
        WHERE T.CLASS_TYPE = 'M' AND T.ACTIVE_FLAG = 'Y'
             AND T.CLASS_CODE = P_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE AND T.ENTITY_ID = ENTITY_ID AND ROWNUM = 1;
      END IF;
    END IF;
    IF UPPER(P_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF) NOT IN (PKG_AR_WRITE_OFF.V_YES, PKG_AR_WRITE_OFF.V_NO)
          OR P_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE IS NULL OR P_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_ID IS NULL THEN
      P_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF := PKG_AR_WRITE_OFF.V_YES;
    END IF;

    P_AR_SALE_MAIN_TYPE.P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    P_AR_SALE_MAIN_TYPE.P_RESULT := '根据主体查询是否区分营销大类成功！';
    --DBMS_OUTPUT.PUT_LINE(ENTITY_ID||'-'||P_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF||'-'||P_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_ID||'-'||P_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_CODE||'-'||P_AR_SALE_MAIN_TYPE.SALE_MAIN_TYPE_NAME);
    RETURN P_AR_SALE_MAIN_TYPE;
  EXCEPTION
    WHEN OTHERS THEN
        --记录出错信息
        P_AR_SALE_MAIN_TYPE.P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
        P_AR_SALE_MAIN_TYPE.P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.F_AR_DEFAULT_SALE_MAIN_TYPE',
                  SQLCODE,
                  '根据主体查询是否区分营销大类失败！主体ID：'||ENTITY_ID||'。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
        P_AR_SALE_MAIN_TYPE.IS_SALE_MAIN_WRITEOFF := PKG_AR_WRITE_OFF.V_YES;
    RETURN P_AR_SALE_MAIN_TYPE;
  END;

  FUNCTION F_AR_IS_CROSS_OU_BILL
  --------------------   根据单据号判断是否为跨主体单据  -----------------
  (
    P_ORDER_NUMBER                        IN VARCHAR2 --单据号
  ) RETURN VARCHAR2 AS
  V_COUNT           NUMBER;
  V_RESULT          VARCHAR2(4000);
  BEGIN
    SELECT COUNT(*) INTO V_COUNT FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H
    WHERE EXISTS (SELECT 1 FROM CIMS.T_AR_RECEIPT_METHODS S WHERE S.IN_TURNFEE = H.RECEIPT_METHOD_ID AND S.RECEIPT_METHOD_NAME = PKG_AR_WRITE_OFF.V_CROSS_OU_METHOD_NAME) -- 非跨主体转入单据
          AND EXISTS (SELECT 1 FROM CIMS.T_AR_RECEIPT_METHODS S WHERE S.OUT_TURNFEE = H.RECEIPT_METHOD_ID AND S.RECEIPT_METHOD_NAME = PKG_AR_WRITE_OFF.V_CROSS_OU_METHOD_NAME) -- 非跨主体转出单据
          AND H.CASH_RECEIPT_CODE = P_ORDER_NUMBER;
    IF V_COUNT > 0 THEN
    	RETURN PKG_AR_WRITE_OFF.V_YES;
    ELSE
    	RETURN PKG_AR_WRITE_OFF.V_NO;
    END IF;
  EXCEPTION WHEN OTHERS THEN
    V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.F_AR_IS_CROSS_OU_BILL',
                SQLCODE,
                '根据单据号判断是否为跨主体单据失败！单据号：'||P_ORDER_NUMBER||'。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    DBMS_OUTPUT.PUT_LINE(V_RESULT);
    RETURN PKG_AR_WRITE_OFF.V_NO;
  END;

  FUNCTION F_AR_HAS_ORDER_RECIPET
  --------------------   根据单据ID判断核销关系状态  -----------------
  (
    P_ORDER_ID                        IN NUMBER, --单据ID
    P_ORDER_TYPE                      IN VARCHAR2 --单据类型。P_ORDER_TYPE = 1收款单；P_ORDER_TYPE IN (1001,1002,1003,1004,1005,1006,1007,1008)销售单
  ) RETURN VARCHAR2 AS
  V_ORDER_TYPE               VARCHAR2(30);
  V_ORDER_MATCH_TYPE         NUMBER;--单据核销类型；1表示应收；-1表示回款
  V_ORDER_AMOUNT             NUMBER := 0;-- 单据金额
  V_MATCH_AMOUNT             NUMBER := 0;-- 核销金额
  V_RESULT          VARCHAR2(4000);
  BEGIN
  	IF P_ORDER_TYPE = '1' THEN -- 到款单
    	SELECT '1', (CASE WHEN H.AMOUNT > 0 THEN -1 WHEN H.AMOUNT < 0 THEN 1 ELSE 0 END), ABS(H.AMOUNT)
             INTO V_ORDER_TYPE, V_ORDER_MATCH_TYPE, V_ORDER_AMOUNT
      FROM CIMS.T_AR_CASH_RECEIPT_HEADERS H WHERE H.CASH_RECEIPT_ID = P_ORDER_ID;
    ELSE -- 销售单
      SELECT H.BIZ_SRC_BILL_TYPE_CODE, H.APPLIED_PLUS_MINUS_FLAG, ABS(ROUND(H.SETTLE_AMOUNT, 2))
             INTO V_ORDER_TYPE, V_ORDER_MATCH_TYPE, V_ORDER_AMOUNT
      FROM CIMS.V_AR_SO_HERDER_WRITE_OFF H WHERE H.SO_HEADER_ID =  P_ORDER_ID;
    END IF;
    IF V_ORDER_MATCH_TYPE = 1 THEN -- 应收
    	SELECT NVL(SUM(R.AMOUNT), 0) INTO V_MATCH_AMOUNT FROM CIMS.T_SO_ORDER_RECEIPT R
      WHERE ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N))
            AND R.ORDER_TYPE = V_ORDER_TYPE AND R.SO_HEAD_ID = P_ORDER_ID;
    ELSIF V_ORDER_MATCH_TYPE = -1 THEN -- 回款
    	SELECT NVL(SUM(R.AMOUNT), 0) INTO V_MATCH_AMOUNT FROM CIMS.T_SO_ORDER_RECEIPT R
      WHERE ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N))
            AND R.RECEIPT_TYPE = V_ORDER_TYPE AND R.CASH_RECEIPT_ID = P_ORDER_ID;
    END IF;
    IF V_MATCH_AMOUNT = 0 THEN
    	RETURN PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_NONE;
    ELSIF V_MATCH_AMOUNT < V_ORDER_AMOUNT THEN
    	RETURN PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_PART;
    ELSE
    	RETURN PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL;
    END IF;
  EXCEPTION WHEN OTHERS THEN
    V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.F_AR_HAS_ORDER_RECIPET',
                SQLCODE,
                '根据单据ID判断是否存在核销关系失败！单据ID：'||P_ORDER_ID||',单据类型：'||P_ORDER_TYPE||'。错误消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    DBMS_OUTPUT.PUT_LINE(V_RESULT);
    RETURN PKG_AR_WRITE_OFF.V_WRITE_OFF_STATUS_ALL;
  END;

  FUNCTION F_GET_MATCH_AMOUNT
  --------------------   查询核销金额  -----------------
  (
    P_ORDER_ID                        IN NUMBER, --单据ID
    P_SO_OR_RECEIPT                   IN NUMBER, -- 应收或回款。1：应收；-1：回款
    P_ORDER_TYPE                      IN VARCHAR2 --单据类型。P_ORDER_TYPE IN (1)收款单；P_ORDER_TYPE IN (1001,1002,1003,1004,1005,1006,1007,1008)销售单
  ) RETURN NUMBER AS
  V_MATCH_AMOUNT                      NUMBER;
  BEGIN
    IF P_SO_OR_RECEIPT = 1 THEN -- 应收
    	SELECT NVL(SUM(R.AMOUNT), 0) INTO V_MATCH_AMOUNT FROM CIMS.T_SO_ORDER_RECEIPT R
      WHERE ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N))
            AND R.ORDER_TYPE = P_ORDER_TYPE AND R.SO_HEAD_ID = P_ORDER_ID;
    ELSE -- 回款
      SELECT NVL(SUM(R.AMOUNT), 0) INTO V_MATCH_AMOUNT FROM CIMS.T_SO_ORDER_RECEIPT R
      WHERE ((R.TO_ERP_FLAG = PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_C AND R.CASH_TURNFEE_ID IS NULL)
                                OR R.TO_ERP_FLAG IN (PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_Y, PKG_AR_WRITE_OFF.V_WRITE_OFF_ERP_FLAG_N))
            AND R.RECEIPT_TYPE = P_ORDER_TYPE AND R.CASH_RECEIPT_ID = P_ORDER_ID;
    END IF;
    RETURN V_MATCH_AMOUNT;
  END;

  FUNCTION F_GET_AGE_AMOUNT
  --------------------   查询账龄金额  -----------------
  (
    P_ORDER_ID                        IN NUMBER, --单据ID
    P_ORDER_MAIN_TYPE                 IN VARCHAR2, --单据主类型（收款单/财务单）1代表收款单、2代表财务单
    P_AR_TYPE                         IN VARCHAR2, --应收类型（应收款/回款）1代表应收款，2代表回款
    P_MATCH_DATE                      IN DATE --核销日期。默认取TRUNC(SYSDATE - 1,'DD')
  ) RETURN NUMBER AS
  V_AGE_AMOUNT                      NUMBER;
  BEGIN
    SELECT NVL(SUM(A.WRITE_OFF_AMOUNT2), 0) INTO V_AGE_AMOUNT FROM CIMS.T_SO_ACCOUNT_AGE_REPORT A
    WHERE A.AR_TYPE = P_AR_TYPE AND A.ORDER_MAIN_TYPE = P_ORDER_MAIN_TYPE
          AND A.MATCH_DATE = NVL(P_MATCH_DATE, TRUNC(SYSDATE - 1,'DD'))
          AND A.ORDER_ID = P_ORDER_ID;
    RETURN V_AGE_AMOUNT;
  END;
  
  --冻结账龄日报表
  PROCEDURE P_AR_AGE_FREEZE
  (
      P_MATCH_DATE IN VARCHAR2, --核销日期。默认取TRUNC(SYSDATE - 1,'DD')
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )AS
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    
    delete from T_SO_ACCOUNT_DISCOUNT where FREEZE_DATE = P_MATCH_DATE;
    delete from T_SO_ACCOUNT_AGE_FREEZE where FREEZE_DATE =  P_MATCH_DATE;
    
    INSERT INTO T_SO_ACCOUNT_DISCOUNT(
       SALES_CENTER_ID
      ,SALES_CENTER_CODE
      ,SALES_CENTER_NAME
      ,ACCOUNT_CODE
      ,CUSTOMER_ID
      ,CUSTOMER_CODE
      ,CUSTOMER_NAME
      ,DISCOUNT_FREEZE_ID
      ,CREATED_BY
      ,CREATION_DATE
      ,LAST_UPDATED_BY
      ,LAST_UPDATE_DATE
      ,FREEZE_DATE
      ,ENTITY_ID
      ,SALES_MAIN_TYPE_CODE
      ,SETTLE_AMOUNT
      ,SO_NUM
      ,BIZ_SRC_BILL_TYPE_CODE
      ,ACCOUNT_ID
      ,PROTO_QUOTA
      )
      SELECT 
             SH.SALES_CENTER_ID
            ,SH.SALES_CENTER_CODE
            ,SH.SALES_CENTER_NAME
            ,SH.ACCOUNT_CODE
            ,SH.CUSTOMER_ID
            ,SH.CUSTOMER_CODE
            ,SH.CUSTOMER_NAME
            ,S_SO_ACCOUNT_DISCOUNT.NEXTVAL
            ,'SYSTEM'
            ,SYSDATE
            ,'SYSTEM'
            ,SYSDATE
            ,P_MATCH_DATE
            ,SH.ENTITY_ID
            ,SH.SALES_MAIN_TYPE
            ,SH.SETTLE_AMOUNT * TE.APPLIED_PLUS_MINUS_FLAG SETTLE_AMOUNT
             ,SH.SO_NUM
             ,SH.BIZ_SRC_BILL_TYPE_CODE
             ,SH.ACCOUNT_ID
             ,(SELECT Q.PROTO_QUOTA 
                             FROM T_AR_PROTO_QUOTA Q
                             WHERE Q.ENTITY_ID = SH.ENTITY_ID
                                AND Q.CUSTOMER_CODE = SH.CUSTOMER_CODE
                                AND Q.ACCOUNT_CODE = SH.ACCOUNT_CODE
                                AND Q.ACTIVE_FLAG='Y'
                                AND ROWNUM=1)
             FROM CIMS.T_SO_HEADER SH
             ,CIMS.T_SO_TYPE_EXTEND TE
      WHERE SH.BIZ_SRC_BILL_TYPE_CODE IN ('1003','1004','1007', '1008')
            AND NVL(SH.SETTLE_FLAG, 'N') <> 'Y'
            AND SH.BILL_TYPE_ID = TE.BILL_TYPE_ID
            AND SH.SO_DATE <= TO_DATE(P_MATCH_DATE, 'YYYY-MM-DD'); --未结算的
            
   INSERT INTO T_SO_ACCOUNT_DISCOUNT(
      SALES_CENTER_ID
      ,SALES_CENTER_CODE
      ,SALES_CENTER_NAME
      ,ACCOUNT_CODE
      ,CUSTOMER_ID
      ,CUSTOMER_CODE
      ,CUSTOMER_NAME
      ,DISCOUNT_FREEZE_ID
      ,CREATED_BY
      ,CREATION_DATE
      ,LAST_UPDATED_BY
      ,LAST_UPDATE_DATE
      ,FREEZE_DATE
      ,ENTITY_ID
      ,SALES_MAIN_TYPE_CODE
      ,SETTLE_AMOUNT
      ,SO_NUM
      ,BIZ_SRC_BILL_TYPE_CODE
      ,ACCOUNT_ID
       ,PROTO_QUOTA
      )
      SELECT 
            SH.SALES_CENTER_ID
            ,SH.SALES_CENTER_CODE
            ,SH.SALES_CENTER_NAME
            ,SH.ACCOUNT_CODE
            ,SH.CUSTOMER_ID
            ,SH.CUSTOMER_CODE
            ,SH.CUSTOMER_NAME
            ,S_SO_ACCOUNT_DISCOUNT.NEXTVAL
            ,'SYSTEM'
            ,SYSDATE
            ,'SYSTEM'
            ,SYSDATE
            ,P_MATCH_DATE
            ,SH.ENTITY_ID
            ,SH.SALES_MAIN_TYPE
            ,SH.SETTLE_AMOUNT * TE.APPLIED_PLUS_MINUS_FLAG SETTLE_AMOUNT
             ,SH.SO_NUM
             ,SH.BIZ_SRC_BILL_TYPE_CODE
             ,SH.ACCOUNT_ID
             ,(SELECT Q.PROTO_QUOTA 
                             FROM T_AR_PROTO_QUOTA Q
                             WHERE Q.ENTITY_ID = SH.ENTITY_ID
                                AND Q.CUSTOMER_CODE = SH.CUSTOMER_CODE
                                AND Q.ACCOUNT_CODE = SH.ACCOUNT_CODE
                                AND Q.ACTIVE_FLAG='Y'
                                AND ROWNUM=1)
             FROM CIMS.T_SO_HEADER SH
             ,CIMS.T_SO_TYPE_EXTEND TE
      WHERE SH.BIZ_SRC_BILL_TYPE_CODE IN ('1003', '1004','1007', '1008')
            AND NVL(SH.SETTLE_FLAG, 'N') = 'Y'
            AND SH.BILL_TYPE_ID = TE.BILL_TYPE_ID
            AND SH.Settle_Date >= TO_DATE(P_MATCH_DATE, 'YYYY-MM-DD')+1 --已结算大于核销日期的单据   
            AND SH.SO_DATE <= TO_DATE(P_MATCH_DATE, 'YYYY-MM-DD'); --单据日期小于核销日期

  INSERT INTO T_SO_ACCOUNT_AGE_FREEZE(
       FREEZE_DATE
       ,FREEZE_TYPE
       ,ENTITY_ID
       ,SALES_MAIN_TYPE_CODE
       ,SALES_REGION_NAME
       ,SALES_CENTER_CODE
       ,SALES_CENTER_NAME
       ,ACCOUNT_CODE
       ,CUSTOMER_CODE
       ,CUSTOMER_NAME
       ,CLASS_NAME
       ,CUSTOMER_STATUS
       ,MONTH1
       ,MONTH15
       ,MONTH2
       ,MONTH25
       ,MONTH3
       ,MONTH4
       ,MONTH5
       ,MONTH6
       ,MONTH7
       ,MONTH8
       ,MONTH9
       ,MONTH10
       ,MONTH11
       ,MONTH12
       ,MONTH13
       ,SETTLE_AMOUNT
       ,RETURN_SETTLE_AMOUNT
       ,DISCOUNT_SETTLE_AMOUNT
       ,CUSTOMER_ARREARS
       ,ENTITY_NAME
       ,FREEZE_ID
       ,CREATED_BY
       ,CREATION_DATE
       ,LAST_UPDATED_BY
       ,LAST_UPDATE_DATE
       ,MONTH07
       ,ACCOUNT_ID
       )   
    SELECT
       P_MATCH_DATE
      ,'NO_MAIN_TYPE'
      ,A.ENTITY_ID
      ,NULL
      ,SC.SALES_REGION_NAME 
      ,SC.SALES_CENTER_CODE
      ,SC.SALES_CENTER_NAME
      ,CA.ACCOUNT_CODE
      ,H.CUSTOMER_CODE
      ,H.CUSTOMER_NAME
      ,NULL
      ,DECODE(H.CUSTOMER_STATUS, 'Active', '否', '是') CUSTOMER_STATUS
      ,A.MONTH1
      ,A.MONTH15
      ,A.MONTH2
      ,A.MONTH25
      ,A.MONTH3
      ,A.MONTH4
      ,A.MONTH5
      ,A.MONTH6
      ,A.MONTH7
      ,A.MONTH8
      ,A.MONTH9
      ,A.MONTH10
      ,A.MONTH11
      ,A.MONTH12
      ,A.MONTH13
      ,A.SETTLE_AMOUNT
      ,A.RETURN_SETTLE_AMOUNT
      ,A.DISCOUNT_SETTLE_AMOUNT
      ,(A.SETTLE_AMOUNT + A.RETURN_SETTLE_AMOUNT + A.DISCOUNT_SETTLE_AMOUNT) BUSINESS_AMOUNT
      ,OG.NAME
      ,S_SO_ACCOUNT_AGE_FREEZE.NEXTVAL
      ,'SYSTEM'
      ,SYSDATE
      ,'SYSTEM'
      ,SYSDATE
      ,A.MONTH07 MONTH07
      ,A.ACCOUNT_ID
    FROM (
        SELECT 
            ENTITY_ID
           ,CUSTOMER_ID
           ,ACCOUNT_ID
           ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=7 THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) MONTH07
           ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=30 THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) MONTH1
           ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>30 AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=45 THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) MONTH15
           ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>45 AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=60 THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) MONTH2
           ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>60 AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=75 THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) MONTH25
           ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>75 AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=90 THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) MONTH3
           ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>90 AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=120 THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) MONTH4
           ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>120 AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=150 THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) MONTH5
           ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>150 AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=180 THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) MONTH6
           ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>180 AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=210 THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) MONTH7
           ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>210 AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=240 THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) MONTH8
           ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>240 AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=270 THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) MONTH9
           ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>270 AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=300 THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) MONTH10
           ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>300 AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=330 THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) MONTH11
           ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>330 AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=360 THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) MONTH12
           ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>360  THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) MONTH13   
           ,SUM(CASE WHEN T.BILL_CODE='0' THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END) SETTLE_AMOUNT
           ,SUM(CASE WHEN T.BILL_CODE IN ('1003', '1004') THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) RETURN_SETTLE_AMOUNT
           ,SUM(CASE WHEN T.BILL_CODE IN ('1005', '1006', '1007', '1008') THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) DISCOUNT_SETTLE_AMOUNT      
         FROM 
            (SELECT '0' BILL_CODE,AR_TYPE,ENTITY_ID,CUSTOMER_ID,ACCOUNT_ID,AGE_DATE,MATCH_DATE,NVL(DECODE(AR_TYPE,'1', WRITE_OFF_AMOUNT2, '2',  0 - WRITE_OFF_AMOUNT2, 0), 0) WRITE_OFF_AMOUNT2 FROM CIMS.T_SO_ACCOUNT_AGE_REPORT 
                WHERE MATCH_DATE=TO_DATE(P_MATCH_DATE,'YYYY-MM-DD')
            UNION ALL
            SELECT BIZ_SRC_BILL_TYPE_CODE BILL_CODE,'1' AR_TYPE,ENTITY_ID,CUSTOMER_ID,ACCOUNT_ID,NULL AGE_DATE,NULL MATCH_DATE,NVL(SETTLE_AMOUNT,0) WRITE_OFF_AMOUNT2 FROM T_SO_ACCOUNT_DISCOUNT
                WHERE FREEZE_DATE=P_MATCH_DATE ) T
        GROUP BY 
            ENTITY_ID
           ,CUSTOMER_ID
           ,ACCOUNT_ID ) A
       LEFT JOIN T_CUSTOMER_HEADER H ON A.CUSTOMER_ID = H.CUSTOMER_ID
       LEFT JOIN T_CUSTOMER_ACCOUNT CA ON CA.ENTITY_ID = A.ENTITY_ID AND CA.ACCOUNT_ID = A.ACCOUNT_ID
       LEFT JOIN UP_ORG_UNIT OG ON OG.TYPE_CODE = 'BU' AND OG.UNIT_ID = A.ENTITY_ID
       LEFT JOIN V_BD_SALES_CENTER SC ON SC.ENTITY_ID = A.ENTITY_ID AND SC.SALES_CENTER_ID = CA.SALES_CENTER_ID;  

       UPDATE T_SO_ACCOUNT_AGE_FREEZE F
            SET F.PROTO_QUOTA = (SELECT Q.PROTO_QUOTA 
                                 FROM T_AR_PROTO_QUOTA Q
                                 WHERE Q.ENTITY_ID = F.ENTITY_ID
                                    AND Q.CUSTOMER_CODE = F.CUSTOMER_CODE
                                    AND Q.ACCOUNT_CODE = F.ACCOUNT_CODE
                                    AND Q.ACTIVE_FLAG='Y'
                                    AND ROWNUM=1)
       WHERE F.FREEZE_DATE = P_MATCH_DATE;
       
       --将设置了客户逾期控制的允许预期天数记录到核销表T_SO_ACCOUNT_AGE_FREEZE
         UPDATE T_SO_ACCOUNT_AGE_REPORT R
             SET (R.FREEZE_CEIL,R.FREEZE_CONTROL,R.DEAD_LINE) = 
                  (SELECT max(CR.FREEZE_CEIL) FREEZE_CEIL,max(CR.FREEZE_CONTROL)FREEZE_CONTROL,MAX(CR.DEADLINE) DEADLINE
                                  FROM CIMS.T_CUSTOMER_COOPERATE_MODEL CM
                                       ,CIMS.T_CREDIT_RATING_CUSTOMER CR 
                                  WHERE CM.ENTITY_ID = CR.ENTITY_ID
                                  AND CM.COOPERATION_MODEL = CR.MIDEA_MARKET_MODE
                                  AND CM.ENTITY_ID = R.ENTITY_ID
                                  AND CM.CUSTOMER_CODE = R.CUSTOMER_CODE
                                  --AND V.account_id = R.ACCOUNT_ID
                                  AND CM.SALES_CENTER_ID = R.SALES_CENTER_ID
                                  AND CR.OVER_CONTROL = 'Y'
                                  AND NOT EXISTS (SELECT 1
                                                    FROM CIMS.T_CREDIT_CUST_CONTROL_CONFIG CC
                                                    WHERE CC.CUSTOMER_CODE = R.CUSTOMER_CODE
                                                    AND CC.ENTITY_ID = R.ENTITY_ID
                                                    AND CC.ACCOUNT_ID = R.ACCOUNT_ID
                                                    AND CC.SALES_CENTER_ID = R.SALES_CENTER_ID
                                                    AND CC.TYPE = 'OVER_CONTROL'
                                                    AND CC.IS_ACTIVE = 'Y')
                                  group by CM.entity_id,CM.customer_id,CM.sales_center_id
                                UNION
                                  SELECT CC.FREEZE_CEIL,CC.FREEZE_CONTROL,TO_NUMBER(CC.VALUE) DEADLINE
                                    FROM CIMS.T_CREDIT_CUST_CONTROL_CONFIG CC
                                    WHERE CC.CUSTOMER_CODE = R.CUSTOMER_CODE
                                    AND CC.ENTITY_ID = R.ENTITY_ID
                                    AND CC.ACCOUNT_ID = R.ACCOUNT_ID
                                    AND CC.SALES_CENTER_ID = R.SALES_CENTER_ID
                                    AND CC.TYPE = 'OVER_CONTROL'
                                    AND CC.IS_ACTIVE = 'Y')                    
           WHERE R.MATCH_DATE = TO_DATE(P_MATCH_DATE,'YYYY-MM-DD');
           
           --计算逾期金额，记录到账龄冻结表
           MERGE INTO T_SO_ACCOUNT_AGE_FREEZE F
             USING(SELECT T.ENTITY_ID ,T.CUSTOMER_CODE ,T.ACCOUNT_ID,MAX(T.FREEZE_CEIL) FREEZE_CEIL,MAX(T.FREEZE_CONTROL) FREEZE_CONTROL,MAX(T.DEAD_LINE) DEAD_LINE,MAX(T.ADVANCE_DATES) ADVANCE_DATES,P_MATCH_DATE MATCH_DATE
                         ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)> (T.DEAD_LINE - T.ADVANCE_DATES)  THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) ADVANCE_OVERDUE_AMOUNT                   --提前提醒逾期总金额
                         ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)> T.DEAD_LINE  THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) OVERDUE_AMOUNT   
                         ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>T.DEAD_LINE AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=(T.DEAD_LINE + 30) THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) OVERDUE_MONTH1
                         ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>(T.DEAD_LINE + 30) AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=(T.DEAD_LINE + 45) THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) OVERDUE_MONTH15
                         ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>(T.DEAD_LINE + 45) AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=(T.DEAD_LINE + 60) THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) OVERDUE_MONTH2
                         ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>(T.DEAD_LINE + 60) AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=(T.DEAD_LINE + 75) THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) OVERDUE_MONTH25
                         ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>(T.DEAD_LINE + 75) AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=(T.DEAD_LINE + 90) THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) OVERDUE_MONTH3
                         ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>(T.DEAD_LINE + 90) AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=(T.DEAD_LINE + 120) THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) OVERDUE_MONTH4
                         ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>(T.DEAD_LINE + 120) AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=(T.DEAD_LINE + 150) THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) OVERDUE_MONTH5
                         ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>(T.DEAD_LINE + 150) AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=(T.DEAD_LINE + 180) THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) OVERDUE_MONTH6
                         ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>(T.DEAD_LINE + 180) AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=(T.DEAD_LINE + 210) THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) OVERDUE_MONTH7
                         ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>(T.DEAD_LINE + 210) AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=(T.DEAD_LINE + 240) THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) OVERDUE_MONTH8
                         ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>(T.DEAD_LINE + 240) AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=(T.DEAD_LINE + 270) THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) OVERDUE_MONTH9
                         ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>(T.DEAD_LINE + 270) AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=(T.DEAD_LINE + 300) THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) OVERDUE_MONTH10
                         ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>(T.DEAD_LINE + 300) AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=(T.DEAD_LINE + 330) THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) OVERDUE_MONTH11
                         ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>(T.DEAD_LINE + 330) AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)<=(T.DEAD_LINE + 360) THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) OVERDUE_MONTH12
                         ,SUM(CASE WHEN T.BILL_CODE='0' AND ROUND((T.MATCH_DATE - T.AGE_DATE), 0)>(T.DEAD_LINE + 360)  THEN T.WRITE_OFF_AMOUNT2 ELSE 0 END  ) OVERDUE_MONTH13
                     FROM (SELECT '0' BILL_CODE,R.FREEZE_CEIL,R.FREEZE_CONTROL,
                                  R.DEAD_LINE,(NVL(Pkg_Bd.f_Get_Parameter_Value('AR_OVERDUE_ADVANCE',r.entity_id),0)) ADVANCE_DATES,
                                  R.AR_TYPE,R.ENTITY_ID,R.CUSTOMER_CODE,R.ACCOUNT_ID,R.AGE_DATE,R.MATCH_DATE,
                                  NVL(DECODE(R.AR_TYPE,'1', R.WRITE_OFF_AMOUNT2, '2',  0 - R.WRITE_OFF_AMOUNT2, 0), 0) WRITE_OFF_AMOUNT2 
                            FROM CIMS.T_SO_ACCOUNT_AGE_REPORT R
                            WHERE R.MATCH_DATE=TO_DATE(P_MATCH_DATE,'YYYY-MM-DD')
                            AND R.DEAD_LINE IS NOT NULL  --只计算设置了逾期日期的那些数据
                            --AND R.AR_TYPE = '1'  --逾期的只计算1-应收  不计算2-回款 
                            ) T
                    GROUP BY T.ENTITY_ID ,T.CUSTOMER_CODE ,T.ACCOUNT_ID) UA 
              ON (UA.ENTITY_ID = F.ENTITY_ID AND F.CUSTOMER_CODE= UA.CUSTOMER_CODE AND F.ACCOUNT_ID = TO_CHAR(UA.ACCOUNT_ID) AND F.FREEZE_DATE = UA.MATCH_DATE)
             WHEN MATCHED THEN
               UPDATE 
                 SET F.OVERDUE_AMOUNT = UA.OVERDUE_AMOUNT 
                     ,F.OVERDUE_MONTH1 = UA.OVERDUE_MONTH1
                     ,F.OVERDUE_MONTH15 = UA.OVERDUE_MONTH15
                     ,F.OVERDUE_MONTH2 = UA.OVERDUE_MONTH2
                     ,F.OVERDUE_MONTH25 = UA.OVERDUE_MONTH25
                     ,F.OVERDUE_MONTH3 = UA.OVERDUE_MONTH3
                     ,F.OVERDUE_MONTH4 = UA.OVERDUE_MONTH4
                     ,F.OVERDUE_MONTH5 = UA.OVERDUE_MONTH5
                     ,F.OVERDUE_MONTH6 = UA.OVERDUE_MONTH6
                     ,F.OVERDUE_MONTH7 = UA.OVERDUE_MONTH7
                     ,F.OVERDUE_MONTH8 = UA.OVERDUE_MONTH8
                     ,F.OVERDUE_MONTH9 = UA.OVERDUE_MONTH9
                     ,F.OVERDUE_MONTH10 = UA.OVERDUE_MONTH10
                     ,F.OVERDUE_MONTH11 = UA.OVERDUE_MONTH11
                     ,F.OVERDUE_MONTH12 = UA.OVERDUE_MONTH12
                     ,F.OVERDUE_MONTH13 = UA.OVERDUE_MONTH13
                     ,F.FREEZE_CEIL = UA.FREEZE_CEIL
                     ,F.FREEZE_CONTROL =  UA.FREEZE_CONTROL
                     ,F.DEAD_LINE = UA.DEAD_LINE
                     ,F.ADVANCE_DATES = UA.ADVANCE_DATES
                     ,F.ADVANCE_OVERDUE_AMOUNT = UA.ADVANCE_OVERDUE_AMOUNT
                  WHERE F.FREEZE_DATE = P_MATCH_DATE;

 EXCEPTION WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
        P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_AGE_FREEZE', SQLCODE,
                '冻结日账龄报表出错！异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    
   
  END;
  
  
          --清空核销应收、回款临时表
  PROCEDURE P_AR_WRITEOFF_DELETE
  (
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )AS
  
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
       -- 清空核销应收、回款临时表
    EXECUTE IMMEDIATE 'TRUNCATE TABLE CIMS.T_AR_REDIRECT_WRITE_OFF';
    EXECUTE IMMEDIATE 'TRUNCATE TABLE CIMS.T_AR_RECIEPT_WRITE_OFF';
  END;
        --处理核销接口数据
  PROCEDURE P_AR_WRITEOFF_RESET
  (
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )AS
    V_TRX_AMOUNT             NUMBER;-- 发票金额
  
  BEGIN
       P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;  
  
       UPDATE INTF_AR_WRITEOFF SET REMARK='取消核销关系',INTF_STATUS='S' WHERE INTF_STATUS in('E','N') AND CANCEL_FLAG='Y';
       UPDATE INTF_AR_WRITEOFF_INV SET REMARK='取消核销关系',INTF_STATUS='S' WHERE INTF_STATUS in('E','N') AND CANCEL_FLAG='Y';
      
       FOR WRITEOFF_BATCH_ROW IN (
            SELECT 
             G.APPLIED_AMOUNT 
            ,G.TRX_ID
            ,G.ORG_ID
            ,G.TRX_NUMBER
            ,TH.SO_NUM
            ,TH.SETTLE_AMOUNT
            FROM INTF_AR_WRITEOFF G
            INNER JOIN CIMS.T_SO_HEADER TH ON TH.ERP_ARINVOICE_CODE = G.TRX_NUMBER AND TH.ERP_OU_ID =G.ORG_ID
            WHERE INTF_STATUS='E' AND CANCEL_FLAG='N'
       )LOOP
          SELECT 
             SUM(NVL(AMOUNT,0)) AMOUNT 
          INTO
             V_TRX_AMOUNT 
          from APPS.CUX_IMS_AR_INVOICE_V@MDIMS2MDERP INC
          where INC.REFERENCE = WRITEOFF_BATCH_ROW.SO_NUM 
          and INC.TRX_NUMBER = WRITEOFF_BATCH_ROW.TRX_NUMBER
          AND INC.ORG_ID = WRITEOFF_BATCH_ROW.ORG_ID ;
          
          IF ABS(NVL(WRITEOFF_BATCH_ROW.APPLIED_AMOUNT,0) - NVL(V_TRX_AMOUNT,0)) < 0.02 
             and ABS(NVL(WRITEOFF_BATCH_ROW.APPLIED_AMOUNT,0) - NVL(WRITEOFF_BATCH_ROW.SETTLE_AMOUNT,0)) < 0.02
             and NVL(WRITEOFF_BATCH_ROW.SETTLE_AMOUNT,0) <> NVL(V_TRX_AMOUNT,0)
         THEN
              UPDATE INTF_AR_WRITEOFF SET REMARK=APPLIED_AMOUNT,APPLIED_AMOUNT = V_TRX_AMOUNT WHERE TRX_ID = WRITEOFF_BATCH_ROW.TRX_ID;
          END IF;
       END LOOP;
       
       
      FOR WRITEOFF_BATCH_ROW IN (
            SELECT 
             G.APPLIED_AMOUNT 
            ,G.TRX_ID
            ,G.ORG_ID
            ,G.INVOICE_TRX_NUMBER
            ,TH.SO_NUM
            ,TH.SETTLE_AMOUNT
            FROM INTF_AR_WRITEOFF_INV G
            INNER JOIN CIMS.T_SO_HEADER TH ON TH.ERP_ARINVOICE_CODE = G.INVOICE_TRX_NUMBER AND TH.ERP_OU_ID =G.ORG_ID
            WHERE INTF_STATUS='E' AND CANCEL_FLAG='N'
       )LOOP
          SELECT 
             SUM(NVL(AMOUNT,0)) AMOUNT 
          INTO
             V_TRX_AMOUNT 
          from APPS.CUX_IMS_AR_INVOICE_V@MDIMS2MDERP INC
          where INC.REFERENCE = WRITEOFF_BATCH_ROW.SO_NUM 
          and INC.TRX_NUMBER = WRITEOFF_BATCH_ROW.INVOICE_TRX_NUMBER
          AND INC.ORG_ID = WRITEOFF_BATCH_ROW.ORG_ID ;
          
          IF    ABS(NVL(WRITEOFF_BATCH_ROW.APPLIED_AMOUNT,0) - NVL(V_TRX_AMOUNT,0)) < 0.02 
            and ABS(NVL(WRITEOFF_BATCH_ROW.APPLIED_AMOUNT,0) - NVL(WRITEOFF_BATCH_ROW.SETTLE_AMOUNT,0)) < 0.02
            and NVL(WRITEOFF_BATCH_ROW.SETTLE_AMOUNT,0) <> NVL(V_TRX_AMOUNT,0)
          THEN
              UPDATE INTF_AR_WRITEOFF_INV SET REMARK=APPLIED_AMOUNT,APPLIED_AMOUNT = V_TRX_AMOUNT WHERE TRX_ID = WRITEOFF_BATCH_ROW.TRX_ID;
          END IF;
       END LOOP;
       
      
  EXCEPTION WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
        P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITEOFF_RESET', SQLCODE,
                '处理核销接口数据失败：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    
  END;
  
  
  --处理核销对账接口
  PROCEDURE P_AR_WRITEOFF_ACCOUNT
  (
      P_ENTITY_ID IN NUMBER, --主体
      P_MAX_NUM IN NUMBER, --主体
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )AS
       V_SUM_AMOUNT     NUMBER;-- CIMS总核销金额
       V_ERP_SUM_AMOUNT NUMBER;-- ERP总核销金额
  BEGIN
       P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;  
  
       FOR ORDER_RECEIPT_ROW IN (
           SELECT 
               SR.ORDER_RECEIPT_ID
              ,SR.RECEIPT_TYPE
              ,SR.ORDER_TYPE
              ,(CASE WHEN SR.RECEIPT_TYPE = '1' THEN SR.RECEIPT_NUMBER ELSE RC.ERP_ARINVOICE_CODE END) ERP_RECEIPT_NUMBER
              ,(CASE WHEN SR.ORDER_TYPE = '1' THEN SR.ORDER_NUMBER ELSE OC.ERP_ARINVOICE_CODE END) ERP_ORDER_NUMBER
              ,SR.RECEIPT_ERP_OU_ID
              ,SR.ORDER_ERP_OU_ID
              ,SR.AMOUNT
              ,SR.RECEIPT_NUMBER
              ,SR.ORDER_NUMBER
         FROM 
                CIMS.T_SO_ORDER_RECEIPT SR
          LEFT JOIN CIMS.T_AR_WRITE_OFF_CHECK OC ON SR.ORDER_NUMBER = OC.SO_NUM  AND OC.ENTITY_ID = P_ENTITY_ID
          LEFT JOIN CIMS.T_AR_WRITE_OFF_CHECK RC ON SR.RECEIPT_NUMBER = RC.SO_NUM  AND RC.ENTITY_ID = P_ENTITY_ID
          WHERE 
               SR.ENTITY_ID = P_ENTITY_ID
           AND SR.TO_ERP_FLAG='Y'
           AND SR.LAST_UPDATE_DATE>=SYSDATE-2
          -- AND SR.ERP_ACCOUNT_FLAG IS NULL
           --AND ROWNUM < P_MAX_NUM
       )LOOP      
             SELECT SUM(SR.AMOUNT) INTO V_SUM_AMOUNT FROM CIMS.T_SO_ORDER_RECEIPT SR
              WHERE SR.ENTITY_ID =P_ENTITY_ID AND SR.RECEIPT_NUMBER = ORDER_RECEIPT_ROW.RECEIPT_NUMBER 
               AND  SR.ORDER_NUMBER = ORDER_RECEIPT_ROW.ORDER_NUMBER AND SR.TO_ERP_FLAG = 'Y';
               
               V_SUM_AMOUNT := NVL(V_SUM_AMOUNT,0);
           
              IF ORDER_RECEIPT_ROW.RECEIPT_TYPE='1' THEN
                   SELECT SUM(ARA.AMOUNT_APPLIED)
                       INTO
                          V_ERP_SUM_AMOUNT
                    FROM   APPS.AR_RECEIVABLE_APPLICATIONS_ALL@MDIMS2MDERP  ARA
                          ,APPS.RA_CUSTOMER_TRX_ALL@MDIMS2MDERP             RCT
                          ,APPS.AR_CASH_RECEIPTS_ALL@MDIMS2MDERP            ACR
                    WHERE  ACR.CASH_RECEIPT_ID = ARA.CASH_RECEIPT_ID
                    AND    RCT.CUSTOMER_TRX_ID = ARA.APPLIED_CUSTOMER_TRX_ID
                    AND    ACR.RECEIPT_NUMBER = ORDER_RECEIPT_ROW.ERP_RECEIPT_NUMBER
                    AND    RCT.TRX_NUMBER = ORDER_RECEIPT_ROW.ERP_ORDER_NUMBER
                    AND    ARA.ORG_ID  = ORDER_RECEIPT_ROW.RECEIPT_ERP_OU_ID;
                    
                   V_ERP_SUM_AMOUNT := NVL(V_ERP_SUM_AMOUNT,0);  
                
                   IF  V_ERP_SUM_AMOUNT =  V_SUM_AMOUNT THEN
                      UPDATE CIMS.T_SO_ORDER_RECEIPT SR SET SR.ERP_ACCOUNT_FLAG='Y',SR.ERP_WRITE_AMOUNT = V_ERP_SUM_AMOUNT 
                      WHERE  SR.ENTITY_ID =  P_ENTITY_ID AND SR.RECEIPT_NUMBER = ORDER_RECEIPT_ROW.RECEIPT_NUMBER 
                       AND   SR.ORDER_NUMBER = ORDER_RECEIPT_ROW.ORDER_NUMBER AND SR.TO_ERP_FLAG = 'Y';
                   ELSE
                      UPDATE CIMS.T_SO_ORDER_RECEIPT SR SET SR.ERP_ACCOUNT_FLAG='E',SR.ERP_WRITE_AMOUNT = V_ERP_SUM_AMOUNT 
                      WHERE  SR.ENTITY_ID =  P_ENTITY_ID AND SR.RECEIPT_NUMBER = ORDER_RECEIPT_ROW.RECEIPT_NUMBER 
                       AND   SR.ORDER_NUMBER = ORDER_RECEIPT_ROW.ORDER_NUMBER AND SR.TO_ERP_FLAG = 'Y';
                   END IF;
              ELSE
                    SELECT 
                          SUM(ARA.AMOUNT_APPLIED)
                      INTO
                           V_ERP_SUM_AMOUNT    
                    FROM   APPS.AR_RECEIVABLE_APPLICATIONS_ALL@MDIMS2MDERP  ARA
                          ,APPS.RA_CUSTOMER_TRX_ALL@MDIMS2MDERP             RCT
                          ,APPS.RA_CUSTOMER_TRX_ALL@MDIMS2MDERP             RCT1
                    WHERE  RCT1.CUSTOMER_TRX_ID = ARA.CUSTOMER_TRX_ID
                    AND    RCT.CUSTOMER_TRX_ID = ARA.APPLIED_CUSTOMER_TRX_ID
                    AND    RCT1.TRX_NUMBER = ORDER_RECEIPT_ROW.ERP_RECEIPT_NUMBER
                    AND    RCT.TRX_NUMBER = ORDER_RECEIPT_ROW.ERP_ORDER_NUMBER
                    AND    ARA.ORG_ID =  ORDER_RECEIPT_ROW.RECEIPT_ERP_OU_ID;
                    
                    V_ERP_SUM_AMOUNT := NVL(V_ERP_SUM_AMOUNT,0);  
                    IF  V_ERP_SUM_AMOUNT =  V_SUM_AMOUNT THEN
                      UPDATE CIMS.T_SO_ORDER_RECEIPT SR SET SR.ERP_ACCOUNT_FLAG='Y',SR.ERP_WRITE_AMOUNT = V_ERP_SUM_AMOUNT 
                      WHERE  SR.ENTITY_ID =  P_ENTITY_ID AND SR.RECEIPT_NUMBER = ORDER_RECEIPT_ROW.RECEIPT_NUMBER 
                       AND   SR.ORDER_NUMBER = ORDER_RECEIPT_ROW.ORDER_NUMBER AND SR.TO_ERP_FLAG = 'Y';
                    ELSE
                      UPDATE CIMS.T_SO_ORDER_RECEIPT SR SET SR.ERP_ACCOUNT_FLAG='E',SR.ERP_WRITE_AMOUNT = V_ERP_SUM_AMOUNT 
                      WHERE  SR.ENTITY_ID =  P_ENTITY_ID AND SR.RECEIPT_NUMBER = ORDER_RECEIPT_ROW.RECEIPT_NUMBER 
                       AND   SR.ORDER_NUMBER = ORDER_RECEIPT_ROW.ORDER_NUMBER AND SR.TO_ERP_FLAG = 'Y';
                    END IF;
              END IF;
               COMMIT;
       END LOOP;
  EXCEPTION WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
        P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_WRITEOFF_ACCOUNT', SQLCODE,
                '核销对账失败：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    
  END;
  
  
  --处理ERP发票金额核对
  PROCEDURE P_AR_SO_HEADER_ACCOUNT
  (
      P_ENTITY_ID IN NUMBER, --主体
      P_MAX_NUM IN NUMBER, --主体
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )AS
       V_SUM_AMOUNT     NUMBER;-- CIMS总金额
       V_ERP_SUM_AMOUNT     NUMBER;-- ERP核销总金额
       V_ERP_OFF_FLAG VARCHAR(32);
       V_ERP_TEM_AMOUNT     NUMBER;-- ERP核销金额
  BEGIN
       P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;  
  
       FOR SO_RECEIPT_ROW IN (
            SELECT 
               OC.SO_NUM
              ,OC.ORDER_CASH  
              ,OC.ERP_OU_ID
              ,OC.ERP_ARINVOICE_CODE
              ,OC.ORDER_TYPE
            FROM 
               CIMS.T_AR_WRITE_OFF_CHECK OC
            WHERE 
              OC.ENTITY_ID = P_ENTITY_ID
            AND OC.LAST_UPDATE_DATE >=sysdate-2 
           -- AND OC.ERP_WRITE_OFF_FLAG IS NULL  
          --  AND OC.ORDER_TYPE NOT IN('1','-1') 
           -- AND ROWNUM < P_MAX_NUM
        UNION ALL    
           SELECT 
               OC.SO_NUM
              ,OC.ORDER_CASH  
              ,OC.ERP_OU_ID
              ,OC.ERP_ARINVOICE_CODE
              ,OC.ORDER_TYPE
            FROM 
               CIMS.T_AR_WRITE_OFF_CHECK OC
            WHERE 
              OC.ENTITY_ID = P_ENTITY_ID
            AND  OC.ORDER_CASH <> OC.ERP_ACTUAL_OFF_AMOUNT   
       )LOOP      
             IF SO_RECEIPT_ROW.ORDER_TYPE NOT IN ('1','-1') THEN 
                  SELECT 
                     SUM(NVL(AMOUNT,0)) AMOUNT 
                  INTO
                     V_SUM_AMOUNT 
                  from APPS.CUX_IMS_AR_INVOICE_V@MDIMS2MDERP INC
                  where INC.REFERENCE = SO_RECEIPT_ROW.SO_NUM 
                  and INC.TRX_NUMBER = SO_RECEIPT_ROW.ERP_ARINVOICE_CODE
                  AND INC.ORG_ID = SO_RECEIPT_ROW.ERP_OU_ID ; 
                  
                  V_SUM_AMOUNT := NVL(V_SUM_AMOUNT,0);
                  
                  V_SUM_AMOUNT := ABS(V_SUM_AMOUNT);
                  
                  IF V_SUM_AMOUNT = SO_RECEIPT_ROW.ORDER_CASH THEN
                      UPDATE CIMS.T_AR_WRITE_OFF_CHECK OC SET OC.ERP_ACCOUNT_FLAG='Y',OC.ERP_AMOUNT = V_SUM_AMOUNT 
                      WHERE OC.SO_NUM = SO_RECEIPT_ROW.SO_NUM;
                  ELSE 
                      UPDATE CIMS.T_AR_WRITE_OFF_CHECK OC SET OC.ERP_ACCOUNT_FLAG='E',OC.ERP_AMOUNT = V_SUM_AMOUNT 
                      WHERE OC.SO_NUM = SO_RECEIPT_ROW.SO_NUM;
                  END IF;
                  COMMIT;
           END IF;  
           
           IF SO_RECEIPT_ROW.ORDER_TYPE ='1' THEN 
	        
                   SELECT SUM(ARA.AMOUNT_APPLIED)
                       INTO
                          V_ERP_SUM_AMOUNT
                    FROM   APPS.AR_RECEIVABLE_APPLICATIONS_ALL@MDIMS2MDERP  ARA
                          ,APPS.RA_CUSTOMER_TRX_ALL@MDIMS2MDERP             RCT
                          ,APPS.AR_CASH_RECEIPTS_ALL@MDIMS2MDERP            ACR
                    WHERE  ACR.CASH_RECEIPT_ID = ARA.CASH_RECEIPT_ID
                    AND    RCT.CUSTOMER_TRX_ID = ARA.APPLIED_CUSTOMER_TRX_ID
                    AND    ACR.RECEIPT_NUMBER = SO_RECEIPT_ROW.SO_NUM
                    AND    ARA.ORG_ID  = SO_RECEIPT_ROW.ERP_OU_ID;
		                V_ERP_SUM_AMOUNT := NVL(V_ERP_SUM_AMOUNT,0);
                  
                    IF V_ERP_SUM_AMOUNT = SO_RECEIPT_ROW.ORDER_CASH THEN
                          V_ERP_OFF_FLAG := 'Y';
                    ELSE
                         V_ERP_OFF_FLAG := 'N';
                    END IF;
                    
                    UPDATE CIMS.T_AR_WRITE_OFF_CHECK OC SET OC.ERP_WRITE_OFF_FLAG=V_ERP_OFF_FLAG,OC.ERP_AMOUNT = SO_RECEIPT_ROW.ORDER_CASH,OC.ERP_ACTUAL_OFF_AMOUNT=V_ERP_SUM_AMOUNT
                     WHERE OC.SO_NUM = SO_RECEIPT_ROW.SO_NUM;       
           END IF;
           
	         IF SO_RECEIPT_ROW.ORDER_TYPE ='-1' THEN 
	                 V_ERP_SUM_AMOUNT :=0;
                   SELECT SUM(ARA.AMOUNT_APPLIED)
                       INTO
                          V_ERP_TEM_AMOUNT
                    FROM   APPS.AR_RECEIVABLE_APPLICATIONS_ALL@MDIMS2MDERP  ARA
                          ,APPS.RA_CUSTOMER_TRX_ALL@MDIMS2MDERP             RCT
                          ,APPS.AR_CASH_RECEIPTS_ALL@MDIMS2MDERP            ACR
                    WHERE  ACR.CASH_RECEIPT_ID = ARA.CASH_RECEIPT_ID
                    AND    RCT.CUSTOMER_TRX_ID = ARA.APPLIED_CUSTOMER_TRX_ID
                    AND    RCT.TRX_NUMBER = SO_RECEIPT_ROW.SO_NUM
                    AND    ARA.ORG_ID  = SO_RECEIPT_ROW.ERP_OU_ID;

                    V_ERP_TEM_AMOUNT := NVL(V_ERP_TEM_AMOUNT,0);
		                V_ERP_SUM_AMOUNT := V_ERP_SUM_AMOUNT+V_ERP_TEM_AMOUNT;

                   SELECT 
                          SUM(ARA.AMOUNT_APPLIED)
                      INTO
                           V_ERP_TEM_AMOUNT    
                    FROM   APPS.AR_RECEIVABLE_APPLICATIONS_ALL@MDIMS2MDERP  ARA
                          ,APPS.RA_CUSTOMER_TRX_ALL@MDIMS2MDERP             RCT
                          ,APPS.RA_CUSTOMER_TRX_ALL@MDIMS2MDERP             RCT1
                    WHERE  RCT1.CUSTOMER_TRX_ID = ARA.CUSTOMER_TRX_ID
                    AND    RCT.CUSTOMER_TRX_ID = ARA.APPLIED_CUSTOMER_TRX_ID
                    AND    RCT.TRX_NUMBER = SO_RECEIPT_ROW.SO_NUM
                    AND    ARA.ORG_ID =  SO_RECEIPT_ROW.ERP_OU_ID;

                    V_ERP_TEM_AMOUNT := NVL(V_ERP_TEM_AMOUNT,0);
                    V_ERP_SUM_AMOUNT := V_ERP_SUM_AMOUNT+V_ERP_TEM_AMOUNT;
                              

                    IF V_ERP_SUM_AMOUNT = SO_RECEIPT_ROW.ORDER_CASH THEN
                          V_ERP_OFF_FLAG := 'Y';
                    ELSE
                         V_ERP_OFF_FLAG := 'N';
                    END IF;
                    
                    UPDATE CIMS.T_AR_WRITE_OFF_CHECK OC SET OC.ERP_WRITE_OFF_FLAG=V_ERP_OFF_FLAG,OC.ERP_AMOUNT = ABS(SO_RECEIPT_ROW.ORDER_CASH),OC.ERP_ACTUAL_OFF_AMOUNT=V_ERP_SUM_AMOUNT
                     WHERE OC.SO_NUM = SO_RECEIPT_ROW.SO_NUM; 

	   END IF;

	    IF SO_RECEIPT_ROW.ORDER_TYPE IN('1001','1004','1006','1008')THEN 
	           V_ERP_SUM_AMOUNT :=0;
                  
                    SELECT SUM(ARA.AMOUNT_APPLIED)
                        INTO
                          V_ERP_TEM_AMOUNT
                    FROM   APPS.AR_RECEIVABLE_APPLICATIONS_ALL@MDIMS2MDERP  ARA
                          ,APPS.RA_CUSTOMER_TRX_ALL@MDIMS2MDERP             RCT
                          ,APPS.AR_CASH_RECEIPTS_ALL@MDIMS2MDERP            ACR
                    WHERE  ACR.CASH_RECEIPT_ID = ARA.CASH_RECEIPT_ID
                    AND    RCT.CUSTOMER_TRX_ID = ARA.APPLIED_CUSTOMER_TRX_ID
                    AND    RCT.TRX_NUMBER = SO_RECEIPT_ROW.ERP_ARINVOICE_CODE
                    AND    ARA.ORG_ID  = SO_RECEIPT_ROW.ERP_OU_ID;

                   V_ERP_TEM_AMOUNT := NVL(V_ERP_TEM_AMOUNT,0);
		               V_ERP_SUM_AMOUNT := V_ERP_SUM_AMOUNT+V_ERP_TEM_AMOUNT;

                   SELECT 
                          SUM(ARA.AMOUNT_APPLIED)
                      INTO
                           V_ERP_TEM_AMOUNT    
                    FROM   APPS.AR_RECEIVABLE_APPLICATIONS_ALL@MDIMS2MDERP  ARA
                          ,APPS.RA_CUSTOMER_TRX_ALL@MDIMS2MDERP             RCT
                          ,APPS.RA_CUSTOMER_TRX_ALL@MDIMS2MDERP             RCT1
                    WHERE  RCT1.CUSTOMER_TRX_ID = ARA.CUSTOMER_TRX_ID
                    AND    RCT.CUSTOMER_TRX_ID = ARA.APPLIED_CUSTOMER_TRX_ID
                    AND    RCT.TRX_NUMBER = SO_RECEIPT_ROW.ERP_ARINVOICE_CODE
                    AND    ARA.ORG_ID =  SO_RECEIPT_ROW.ERP_OU_ID;

                    V_ERP_TEM_AMOUNT := NVL(V_ERP_TEM_AMOUNT,0);
                    V_ERP_SUM_AMOUNT := V_ERP_SUM_AMOUNT+V_ERP_TEM_AMOUNT;
                              

                    IF V_ERP_SUM_AMOUNT = SO_RECEIPT_ROW.ORDER_CASH THEN
                           V_ERP_OFF_FLAG := 'Y';
                    ELSE
                           V_ERP_OFF_FLAG := 'N';
                    END IF;
                    UPDATE CIMS.T_AR_WRITE_OFF_CHECK OC SET OC.ERP_WRITE_OFF_FLAG=V_ERP_OFF_FLAG,OC.ERP_ACTUAL_OFF_AMOUNT=V_ERP_SUM_AMOUNT
                     WHERE OC.SO_NUM = SO_RECEIPT_ROW.SO_NUM; 

	   END IF;

	   IF SO_RECEIPT_ROW.ORDER_TYPE IN('1002','1003','1005','1007')THEN 
	           V_ERP_SUM_AMOUNT :=0;
                   
                   SELECT 
                          SUM(ARA.AMOUNT_APPLIED)
                      INTO
                           V_ERP_TEM_AMOUNT    
                    FROM   APPS.AR_RECEIVABLE_APPLICATIONS_ALL@MDIMS2MDERP  ARA
                          ,APPS.RA_CUSTOMER_TRX_ALL@MDIMS2MDERP             RCT
                          ,APPS.RA_CUSTOMER_TRX_ALL@MDIMS2MDERP             RCT1
                    WHERE  RCT1.CUSTOMER_TRX_ID = ARA.CUSTOMER_TRX_ID
                    AND    RCT.CUSTOMER_TRX_ID = ARA.APPLIED_CUSTOMER_TRX_ID
                    AND    RCT1.TRX_NUMBER = SO_RECEIPT_ROW.ERP_ARINVOICE_CODE
                    AND    ARA.ORG_ID =  SO_RECEIPT_ROW.ERP_OU_ID;

                    V_ERP_TEM_AMOUNT := NVL(V_ERP_TEM_AMOUNT,0);
                    V_ERP_SUM_AMOUNT := V_ERP_SUM_AMOUNT+V_ERP_TEM_AMOUNT;
                              

                   IF V_ERP_SUM_AMOUNT = SO_RECEIPT_ROW.ORDER_CASH THEN
                           V_ERP_OFF_FLAG := 'Y';
                    ELSE
                           V_ERP_OFF_FLAG := 'N';
                    END IF;
                    
                    UPDATE CIMS.T_AR_WRITE_OFF_CHECK OC SET OC.ERP_WRITE_OFF_FLAG=V_ERP_OFF_FLAG,OC.ERP_ACTUAL_OFF_AMOUNT=V_ERP_SUM_AMOUNT
                     WHERE OC.SO_NUM = SO_RECEIPT_ROW.SO_NUM; 
	        END IF;
                  
                  
       END LOOP;
  EXCEPTION WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
        P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_SO_HEADER_ACCOUNT', SQLCODE,
                '核销对账失败：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    
  END;
  
  
    --核销对账冻结
  PROCEDURE P_AR_ACCOUNT_FREEZE
  (
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )AS
  BEGIN
       P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
       EXECUTE IMMEDIATE 'TRUNCATE TABLE CIMS.T_AR_WRITE_OFF_ACCOUNT';
       INSERT INTO 
       T_AR_WRITE_OFF_ACCOUNT(
         ID
        ,ENTITY_ID
        ,ERP_OU_ID
        ,CUSTOMER_CODE
        ,CUSTOMER_NAME
        ,SALES_CENTER_CODE
        ,SALES_CENTER_NAME
        ,ACCOUNT_ID
        ,ACCOUNT_CODE
        ,SO_NUM
        ,ORDER_TYPE
        ,WRITE_OFF_FLAG
        ,ORDER_STATUS_NAME
        ,ORDER_CASH
        ,WRITE_OFF_CASH
        ,AGE_CASH
        ,ERP_APPLIED_AMOUNT
        ,ERP_AMOUNT
        ,ERP_ACTUAL_OFF_AMOUNT
        ,ERP_ARINVOICE_CODE
        ,AR_RECEIPT_CODE
        ,AR_TYPE
        ,RECEIPT_ERP_OU_ID
        ,ORDER_ERP_OU_ID
        ,RECEIPT_NUMBER
        ,ORDER_NUMBER
        ,RECEIPT_TYPE
        ,SO_TYPE
        ,AMOUNT
        ,RECEIPT_STATUS
        ,ORDER_STATUS
        ,ERP_RECEIPT_CODE
        ,ERP_ORDER_CODE
        ,AGE_DATE
        ,ORDER_DATE
        ,RECEIPT_DATE
        )
        SELECT 
            OC.ENTITY_ID||OC.SO_NUM ID
           ,OC.ENTITY_ID
           ,OC.ERP_OU_ID
           ,OC.CUSTOMER_CODE
           ,CH.CUSTOMER_NAME
           ,OC.SALES_CENTER_CODE
           ,OU.NAME SALES_CENTER_NAME
           ,OC.ACCOUNT_ID
           ,OC.ACCOUNT_CODE
           ,OC.SO_NUM
           ,OC.ORDER_TYPE
           ,OC.WRITE_OFF_FLAG
           ,OC.Order_Status
           ,OC.ORDER_CASH
           ,OC.WRITE_OFF_CASH
           ,OC.AGE_CASH
           ,OC.ERP_APPLIED_AMOUNT
           ,OC.ERP_AMOUNT
           ,OC.ERP_ACTUAL_OFF_AMOUNT
           ,OC.ERP_ARINVOICE_CODE
           ,OC.AR_RECEIPT_CODE
           ,'ERP未核销单据' AR_TYPE
           ,NULL RECEIPT_ERP_OU_ID
           ,NULL ORDER_ERP_OU_ID
           ,NULL RECEIPT_NUMBER
           ,NULL ORDER_NUMBER
           ,NULL RECEIPT_TYPE
           ,NULL SO_TYPE
           ,NULL AMOUNT
           ,NULL RECEIPT_STATUS
           ,NULL ORDER_STATUS
           ,NULL ERP_RECEIPT_CODE
           ,NULL ERP_ORDER_CODE
           ,OC.SHOULD_WRITE_OFF_DATE
           ,null
           ,null
          FROM 
            CIMS.T_AR_WRITE_OFF_CHECK OC 
          LEFT JOIN CIMS.T_CUSTOMER_HEADER CH ON OC.CUSTOMER_ID =  CH.CUSTOMER_ID
          LEFT JOIN CIMS.UP_ORG_UNIT OU ON OU.UNIT_ID = OC.SALES_CENTER_ID
          WHERE ABS(OC.ERP_AMOUNT) <> OC.ERP_ACTUAL_OFF_AMOUNT
            AND OC.ORDER_STATUS NOT IN('2','16')
            AND OC.ERP_AMOUNT<>0
          UNION ALL
             SELECT
                 OD.ORDER_RECEIPT_ID||OD.RECEIPT_NUMBER||OD.ORDER_NUMBER ID
               ,OD.ENTITY_ID
               ,OD.RECEIPT_ERP_OU_ID ERP_OU_ID
               ,OD.CUSROMER_CODE
               ,OD.CUSROMER_NAME
               ,OP.SALES_CENTER_CODE
               ,OU.NAME SALES_CENTER_NAME
               ,OP.ACCOUNT_ID
               ,OP.ACCOUNT_CODE
               ,NULL SO_NUM
               ,NULL ORDER_TYPE
               ,NULL WRITE_OFF_FLAG
               ,NULL ORDER_STATUS_NAME
               ,NULL ORDER_CASH
               ,NULL WRITE_OFF_CASH
               ,NULL AGE_CASH
               ,NULL ERP_APPLIED_AMOUNT
               ,NULL ERP_AMOUNT
               ,NULL ERP_ACTUAL_OFF_AMOUNT
               ,NULL ERP_ARINVOICE_CODE
               ,NULL AR_RECEIPT_CODE
               ,'未推送ERP核销关系' AR_TYPE
               ,OD.RECEIPT_ERP_OU_ID
               ,OD.ORDER_ERP_OU_ID
               ,OD.RECEIPT_NUMBER
               ,OD.ORDER_NUMBER
               ,OD.RECEIPT_TYPE
               ,OD.ORDER_TYPE SO_TYPE
               ,OD.AMOUNT
               ,OP.ORDER_STATUS RECEIPT_STATUS
               ,OH.ORDER_STATUS ORDER_STATUS
               ,(CASE WHEN OD.RECEIPT_TYPE ='1' THEN OP.AR_RECEIPT_CODE ELSE OP.ERP_ARINVOICE_CODE END) ERP_RECEIPT_CODE
               ,(CASE WHEN OD.ORDER_TYPE ='1' THEN OH.AR_RECEIPT_CODE ELSE OH.ERP_ARINVOICE_CODE END)  ERP_ORDER_CODE
               ,null
               ,OD.ORDER_DATE
               ,OD.RECEIPT_DATE
              FROM 
               CIMS.T_SO_ORDER_RECEIPT OD
              LEFT JOIN CIMS.T_AR_WRITE_OFF_CHECK OP ON OD.RECEIPT_NUMBER = OP.SO_NUM 
              LEFT JOIN CIMS.T_AR_WRITE_OFF_CHECK OH ON OH.SO_NUM = OD.ORDER_NUMBER
              LEFT JOIN CIMS.UP_ORG_UNIT OU ON OU.UNIT_ID = OP.SALES_CENTER_ID 
              WHERE OD.TO_ERP_FLAG='N'
          UNION ALL
              SELECT 
                OD.ORDER_RECEIPT_ID||OD.RECEIPT_NUMBER||OD.ORDER_NUMBER ID
               ,OD.ENTITY_ID
               ,OD.RECEIPT_ERP_OU_ID ERP_OU_ID
               ,OD.CUSROMER_CODE
               ,OD.CUSROMER_NAME
               ,OP.SALES_CENTER_CODE
               ,OU.NAME SALES_CENTER_NAME
               ,OP.ACCOUNT_ID
               ,OP.ACCOUNT_CODE
               ,NULL SO_NUM
               ,NULL ORDER_TYPE
               ,NULL WRITE_OFF_FLAG
               ,NULL ORDER_STATUS_NAME
               ,NULL ORDER_CASH
               ,NULL WRITE_OFF_CASH
               ,NULL AGE_CASH
               ,NULL ERP_APPLIED_AMOUNT
               ,NULL ERP_AMOUNT
               ,NULL ERP_ACTUAL_OFF_AMOUNT
               ,NULL ERP_ARINVOICE_CODE
               ,NULL AR_RECEIPT_CODE
               ,'未推送ERP核销关系' AR_TYPE
               ,OD.RECEIPT_ERP_OU_ID
               ,OD.ORDER_ERP_OU_ID
               ,OD.RECEIPT_NUMBER
               ,OD.ORDER_NUMBER
               ,OD.RECEIPT_TYPE
               ,OD.ORDER_TYPE SO_TYPE
               ,OD.AMOUNT
               ,OP.ORDER_STATUS RECEIPT_STATUS
               ,OH.ORDER_STATUS ORDER_STATUS
               ,(CASE WHEN OD.RECEIPT_TYPE ='1' THEN OP.AR_RECEIPT_CODE ELSE OP.ERP_ARINVOICE_CODE END) ERP_RECEIPT_CODE
               ,(CASE WHEN OD.ORDER_TYPE ='1' THEN OH.AR_RECEIPT_CODE ELSE OH.ERP_ARINVOICE_CODE END)  ERP_ORDER_CODE
               ,null
               ,OD.ORDER_DATE
               ,OD.RECEIPT_DATE
              FROM 
                CIMS.T_SO_ORDER_RECEIPT OD
               LEFT JOIN CIMS.T_AR_WRITE_OFF_CHECK OP ON OD.RECEIPT_NUMBER = OP.SO_NUM 
               LEFT JOIN CIMS.T_AR_WRITE_OFF_CHECK OH ON OH.SO_NUM = OD.ORDER_NUMBER 
               LEFT JOIN CIMS.UP_ORG_UNIT OU ON OU.UNIT_ID = OP.SALES_CENTER_ID 
              WHERE  OD.TO_ERP_FLAG='C' 
                 AND OD.TMP_CASH_TURNFEE_ID IS NULL 
                 AND OD.RECEIPT_ERP_OU_ID<>OD.ORDER_ERP_OU_ID;
   EXCEPTION WHEN OTHERS THEN
      ROLLBACK;
      P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
      P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_ACCOUNT_FREEZE', SQLCODE,
              '核销对账失败：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    
   END ;
   
 --解冻逾期的账户
  PROCEDURE P_AR_UNLOCK_OVERDUE_ACCOUNT
  (
      P_MATCH_DATE IN VARCHAR2, --核销日期。默认取TRUNC(SYSDATE - 1,'DD')
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )AS
  
  v_AR_CUSTOMER_CREDIT_RATE number; --每次解冻递减的客户信用额度系数
  V_CONTROL_SCOPE VARCHAR2(32);
  V_SETTLE_AMOUNT NUMBER; --销售单结算金额
  V_CUR_MOUTH_FIRST_DAY     DATE;--本月1号
  V_BEFORE3_MOUTH_FIRST_DAY DATE;--三个月之前的1号
  V_MAX_CURRENT_OVERDUE_COUNT NUMBER; --当前客户下所有账户最大逾期次数
  
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    --本月的第一天
    SELECT TRUNC(ADD_MONTHS(SYSDATE,0),'MM') INTO V_CUR_MOUTH_FIRST_DAY FROM DUAL;
    --三个月前的第一天
    SELECT TRUNC(ADD_MONTHS(SYSDATE,-3),'MM') INTO V_BEFORE3_MOUTH_FIRST_DAY FROM DUAL;
    
    --获取信用额度系数
    Begin
      V_AR_CUSTOMER_CREDIT_RATE := Pkg_Bd.f_Get_Parameter_Value(p_Config_Code => 'AR_CUSTOMER_CREDIT_RATE',
                                                                  p_Entity_Id   => null);
    Exception
      When Others Then
        p_Result := '获取系统参数失败，系统参数编码：AR_CUSTOMER_CREDIT_RATE ' ||Sqlerrm;
        Raise V_BIZ_EXCEPTION;
    End;
    --获取指定账户中，逾期金额小于等于0的账户
    FOR ROW_SO_ACCOUNT_AGE_FREEZE IN (
      SELECT F.*
        FROM CIMS.T_SO_ACCOUNT_AGE_FREEZE F
        WHERE F.FREEZE_DATE =  P_MATCH_DATE
        --AND (NVL(F.OVERDUE_AMOUNT,0)-NVL(F.PROTO_QUOTA,0)) <= 0 
     ) LOOP 
     
       --获取客户管控层级  GROUP-集团层级管控  ENTITY-事业部层级管控
       SELECT NVL(C.CONTROL_SCOPE,'GROUP') INTO V_CONTROL_SCOPE
         FROM CIMS.T_CREDIT_CUST_CONTROL_CONFIG C
         WHERE C.ENTITY_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ENTITY_ID
         AND C.CUSTOMER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.CUSTOMER_CODE
         AND C.SALES_CENTER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.SALES_CENTER_CODE
         AND C.ACCOUNT_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ACCOUNT_ID;
         
        --事业部管控 
        IF 'ENTITY' = V_CONTROL_SCOPE THEN
          --获取指定账户，前三个月平均销售总金额的50%
           SELECT (SUM(NVL(SL.ITEM_SETTLE_AMOUNT, 0) * NVL(SC.APPLIED_PLUS_MINUS_FLAG, 0))/3)*0.5 
            INTO V_SETTLE_AMOUNT
            FROM T_SO_HEADER SH, T_SO_LINE SL, T_SO_TYPE_EXTEND SC
           WHERE SH.SO_HEADER_ID = SL.SO_HEADER_ID
             AND SH.BILL_TYPE_ID = SC.BILL_TYPE_ID
             AND SH.ENTITY_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ENTITY_ID
             AND SH.ENTITY_ID = SC.ENTITY_ID
             AND SH.BIZ_SRC_BILL_TYPE_CODE IN ('1001', '1002', '1003', '1004')
             AND SH.ACCOUNT_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ACCOUNT_ID
             AND SH.SO_DATE >= V_BEFORE3_MOUTH_FIRST_DAY
             AND SH.SO_DATE < V_CUR_MOUTH_FIRST_DAY
             GROUP BY SH.ACCOUNT_ID;
           --如果前三个月平均销售小于0，则取0
           IF V_SETTLE_AMOUNT < 0 THEN
             V_SETTLE_AMOUNT := 0;
           END IF;
           --逾期金额<=0且客户逾期金额小于等于前三月月均销售50%
           IF (NVL(ROW_SO_ACCOUNT_AGE_FREEZE.OVERDUE_AMOUNT,0)-NVL(ROW_SO_ACCOUNT_AGE_FREEZE.PROTO_QUOTA,0)) <= V_SETTLE_AMOUNT THEN
              --更新账户上的当前逾期次数到0次
              UPDATE T_CUSTOMER_ACCOUNT A
                SET A.Current_Overdue_Count = 0
                ,A.LAST_UPDATE_DATE = SYSDATE
                WHERE A.ACCOUNT_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ACCOUNT_ID
                AND A.ENTITY_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ENTITY_ID
                AND A.Customer_Code = ROW_SO_ACCOUNT_AGE_FREEZE.Customer_Code
                AND A.SALES_CENTER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.SALES_CENTER_CODE;
              
              --本事业部客户下所有账户最大逾期次数
              SELECT MAX(CA.CURRENT_OVERDUE_COUNT) INTO V_MAX_CURRENT_OVERDUE_COUNT
                FROM T_CUSTOMER_ACCOUNT CA
                WHERE CA.CUSTOMER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.CUSTOMER_CODE
                AND CA.ENTITY_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ENTITY_ID;
                
              --如果客户下账户的最大逾期次数小于等于0
              IF V_MAX_CURRENT_OVERDUE_COUNT <= 0 THEN
                --更新不良记录表中的还钱时间,还钱之前，还钱时间是空的  设置为无效
                UPDATE cims.t_credit_Bad_Record  r
                  SET R.PAY_DATE = SYSDATE
                  ,R.ACTIVE_FLAG = '2'
                  ,R.LAST_UPDATE_DATE = SYSDATE
                  WHERE R.BAD_RECORD_TYPE = '4' --应收逾期
                  AND R.Customer_Code = ROW_SO_ACCOUNT_AGE_FREEZE.Customer_Code
                  AND R.ACTIVE_FLAG = '1'  --1-有效 2-无效
                  AND R.ENTITY_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ENTITY_ID
                  AND R.PAY_DATE IS NULL;
                  
                  --解锁客户表上的客户
                  UPDATE T_CUSTOMER_DEPT H
                    SET H.CURRENT_OVERDUE_COUNT = 0
                    ,H.CREDIT_RATE = (CASE WHEN (H.CREDIT_RATE - v_AR_CUSTOMER_CREDIT_RATE)> 0 THEN (H.CREDIT_RATE - v_AR_CUSTOMER_CREDIT_RATE) ELSE 0 END)
                    ,H.IS_LOCKED = 'N'
                    ,H.UNLOCKED_COUNT = H.UNLOCKED_COUNT + 1
                    ,H.UNLOCK_DATE = SYSDATE
                    ,H.LAST_UPDATE_DATE = SYSDATE
                    WHERE H.IS_LOCKED = 'Y'
                    AND H.DEPT_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ENTITY_ID
                    AND H.CUSTOMER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.Customer_Code;
              END IF;
           END IF;
        --集团管控   
        ELSE
          IF (NVL(ROW_SO_ACCOUNT_AGE_FREEZE.OVERDUE_AMOUNT,0)-NVL(ROW_SO_ACCOUNT_AGE_FREEZE.PROTO_QUOTA,0)) <= 0 THEN
            --更新账户上的当前逾期次数到0次
            UPDATE T_CUSTOMER_ACCOUNT A
              SET A.Current_Overdue_Count = 0
              ,A.LAST_UPDATE_DATE = SYSDATE
              WHERE A.ACCOUNT_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ACCOUNT_ID
              AND A.ENTITY_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ENTITY_ID
              AND A.Customer_Code = ROW_SO_ACCOUNT_AGE_FREEZE.Customer_Code
              AND A.SALES_CENTER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.SALES_CENTER_CODE;
              
             --本客户下所有账户最大逾期次数
            SELECT MAX(CA.CURRENT_OVERDUE_COUNT) INTO V_MAX_CURRENT_OVERDUE_COUNT
              FROM T_CUSTOMER_ACCOUNT CA
              WHERE CA.CUSTOMER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.CUSTOMER_CODE;
                
            --如果客户下账户的最大逾期次数小于等于0
            IF V_MAX_CURRENT_OVERDUE_COUNT <= 0 THEN  
              --更新不良记录表中的还钱时间,还钱之前，还钱时间是空的  设置为无效
              UPDATE cims.t_credit_Bad_Record  r
                SET R.PAY_DATE = SYSDATE
                ,R.ACTIVE_FLAG = '2'
                ,R.LAST_UPDATE_DATE = SYSDATE
                WHERE R.BAD_RECORD_TYPE = '4' --应收逾期
                AND R.CUSTOMER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.CUSTOMER_CODE
                AND R.ACTIVE_FLAG = '1'  --1-有效 2-无效
                AND R.PAY_DATE IS NULL;
                --解锁客户表上的客户
                UPDATE T_CUSTOMER_HEADER H
                  SET H.CURRENT_OVERDUE_COUNT = 0
                  ,H.CREDIT_RATE = (CASE WHEN (H.CREDIT_RATE - v_AR_CUSTOMER_CREDIT_RATE)> 0 THEN (H.CREDIT_RATE - v_AR_CUSTOMER_CREDIT_RATE) ELSE 0 END)
                  ,H.IS_LOCKED = 'N'
                  ,H.UNLOCKED_COUNT = H.UNLOCKED_COUNT + 1
                  ,H.UNLOCK_DATE = SYSDATE
                  ,H.LAST_UPDATE_DATE = SYSDATE
                  WHERE H.IS_LOCKED = 'Y'
                  AND H.CUSTOMER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.CUSTOMER_CODE;
            END IF;
          END IF;
        END IF; 
    END LOOP;

   EXCEPTION WHEN OTHERS THEN
      ROLLBACK;
      P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
      P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_UNLOCK_OVERDUE_ACCOUNT', SQLCODE,
              '逾期账户解冻失败：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    
   END ; 
 --冻结逾期的账户
  PROCEDURE P_AR_LOCK_OVERDUE_ACCOUNT
  (
      P_MATCH_DATE IN VARCHAR2, --核销日期。默认取TRUNC(SYSDATE - 1,'DD')
      P_RESULT  OUT VARCHAR2,
      P_MESSAGE OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )AS
  
  V_CONTROL_SCOPE VARCHAR2(32);
  V_SETTLE_AMOUNT NUMBER; --销售单结算金额
  V_CUR_MOUTH_FIRST_DAY     DATE;--本月1号
  V_BEFORE3_MOUTH_FIRST_DAY DATE;--三个月之前的1号
  
  BEGIN
    P_MESSAGE := PKG_AR_WRITE_OFF.V_SUCCESS;
    --本月的第一天
    SELECT TRUNC(ADD_MONTHS(SYSDATE,0),'MM') INTO V_CUR_MOUTH_FIRST_DAY FROM DUAL;
    --三个月前的第一天
    SELECT TRUNC(ADD_MONTHS(SYSDATE,-3),'MM') INTO V_BEFORE3_MOUTH_FIRST_DAY FROM DUAL;
    
    --获取指定账户中，逾期金额大于0.05的账户
    FOR ROW_SO_ACCOUNT_AGE_FREEZE IN (
      SELECT F.*
        FROM CIMS.T_SO_ACCOUNT_AGE_FREEZE F
        WHERE F.FREEZE_DATE =  P_MATCH_DATE
        AND (NVL(F.OVERDUE_AMOUNT,0)-NVL(F.PROTO_QUOTA,0)) > 0.05 
     ) LOOP 
       --获取客户管控层级  GROUP-集团层级管控  ENTITY-事业部层级管控
       SELECT NVL(C.CONTROL_SCOPE,'GROUP') INTO V_CONTROL_SCOPE
         FROM CIMS.T_CREDIT_CUST_CONTROL_CONFIG C
         WHERE C.ENTITY_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ENTITY_ID
         AND C.CUSTOMER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.CUSTOMER_CODE
         AND C.SALES_CENTER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.SALES_CENTER_CODE
         AND C.ACCOUNT_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ACCOUNT_ID;
       
       IF 'ENTITY' = V_CONTROL_SCOPE THEN
         --获取指定账户，前三个月平均销售总金额的50%
         SELECT (SUM(NVL(SL.ITEM_SETTLE_AMOUNT, 0) * NVL(SC.APPLIED_PLUS_MINUS_FLAG, 0))/3)*0.5 
          INTO V_SETTLE_AMOUNT
          FROM T_SO_HEADER SH, T_SO_LINE SL, T_SO_TYPE_EXTEND SC
         WHERE SH.SO_HEADER_ID = SL.SO_HEADER_ID
           AND SH.BILL_TYPE_ID = SC.BILL_TYPE_ID
           AND SH.ENTITY_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ENTITY_ID
           AND SH.ENTITY_ID = SC.ENTITY_ID
           AND SH.BIZ_SRC_BILL_TYPE_CODE IN ('1001', '1002', '1003', '1004')
           AND SH.ACCOUNT_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ACCOUNT_ID
           AND SH.SO_DATE >= V_BEFORE3_MOUTH_FIRST_DAY
           AND SH.SO_DATE < V_CUR_MOUTH_FIRST_DAY
           GROUP BY SH.ACCOUNT_ID;
         
         --如果前三个月平均销售小于0，则取0
           IF V_SETTLE_AMOUNT < 0 THEN
             V_SETTLE_AMOUNT := 0;
           END IF;
         --逾期金额>0且客户逾期金额超前三月月均销售50%计为1次
         IF (NVL(ROW_SO_ACCOUNT_AGE_FREEZE.OVERDUE_AMOUNT,0)-NVL(ROW_SO_ACCOUNT_AGE_FREEZE.PROTO_QUOTA,0)) > V_SETTLE_AMOUNT THEN

           --更新账户上的当前逾期次数 累加1
          UPDATE T_CUSTOMER_ACCOUNT A
            SET A.Current_Overdue_Count = A.Current_Overdue_Count + 1
                ,A.TOTAL_OVERDUE_COUNT = A.TOTAL_OVERDUE_COUNT + 1
                ,A.LAST_UPDATE_DATE = SYSDATE
            WHERE A.ACCOUNT_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ACCOUNT_ID
            AND A.ENTITY_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ENTITY_ID
            AND A.Customer_Code = ROW_SO_ACCOUNT_AGE_FREEZE.Customer_Code
            AND A.SALES_CENTER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.SALES_CENTER_CODE;
          
          --客户表上的逾期信息也累加1
          UPDATE T_CUSTOMER_DEPT H
            SET H.CURRENT_OVERDUE_COUNT = H.CURRENT_OVERDUE_COUNT + 1
                ,H.TOTAL_OVERDUE_COUNT = H.TOTAL_OVERDUE_COUNT + 1
                ,H.LAST_UPDATE_DATE = SYSDATE
            WHERE H.CUSTOMER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.Customer_Code;
          
          --是否冻结客户
          IF ROW_SO_ACCOUNT_AGE_FREEZE.FREEZE_CONTROL = 'Y' THEN
            UPDATE T_CUSTOMER_DEPT H
              SET H.IS_LOCKED = 'Y' 
                  ,H.LOCK_DATE = SYSDATE
                  ,H.LAST_UPDATE_DATE = SYSDATE
              WHERE H.CUSTOMER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.Customer_Code
              AND NVL(H.CURRENT_OVERDUE_COUNT,0) >= ROW_SO_ACCOUNT_AGE_FREEZE.FREEZE_CEIL
              AND H.DEPT_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ENTITY_ID
              AND NVL(H.IS_LOCKED,'N') = 'N';
          END IF;
          
          --插入一条坏账记录，还钱时间是空的
          insert into cims.t_credit_Bad_Record
            (BAD_RECORD_ID,
             ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             ACCOUNT_ID,
             ACCOUNT_CODE,
             ACCOUNT_NAME,
             SALES_REGION_ID,
             SALES_REGION_CODE,
             SALES_REGION_NAME,
             SALES_CENTER_ID,
             SALES_CENTER_CODE,
             SALES_CENTER_NAME,
             SALES_MAIN_TYPE,
             BAD_RECORD_TYPE,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             PAY_DATE,
             COUNTER, --当前逾期计数，
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06,
             BILL_ID)
          values
            (S_CREDIT_BAD_RECORD.NEXTVAL,
             ROW_SO_ACCOUNT_AGE_FREEZE.Entity_Id,
             (SELECT T.CUSTOMER_ID FROM CIMS.T_CUSTOMER_HEADER T WHERE T.CUSTOMER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.Customer_Code),
             ROW_SO_ACCOUNT_AGE_FREEZE.Customer_Code,
             ROW_SO_ACCOUNT_AGE_FREEZE.Customer_Name,
             ROW_SO_ACCOUNT_AGE_FREEZE.ACCOUNT_ID,
             ROW_SO_ACCOUNT_AGE_FREEZE.ACCOUNT_CODE,
             '',
             null,
             '',
             ROW_SO_ACCOUNT_AGE_FREEZE.Sales_Region_Name,
             null,
             ROW_SO_ACCOUNT_AGE_FREEZE.Sales_Center_Code,
             ROW_SO_ACCOUNT_AGE_FREEZE.Sales_Center_Name,
             ROW_SO_ACCOUNT_AGE_FREEZE.SALES_MAIN_TYPE_CODE,
             4,  --不良记录类型 4-应收逾期
             '1',--有效
             '应收逾期',
             TO_DATE(P_MATCH_DATE,'YYYY-MM-DD'),
             '应收逾期',
             SYSDATE,
             NULL,
             --获取账户的当前累计逾期次数
             1,
             ROW_SO_ACCOUNT_AGE_FREEZE.Overdue_Amount,---将账户总逾期金额记录到备用字段1上
             '',
             '',
             '',
             '',
             '',
             NULL); 
         END IF;
       --集团层级的管控
       ELSE  
           --更新账户上的当前逾期次数 累加1
          UPDATE T_CUSTOMER_ACCOUNT A
            SET A.Current_Overdue_Count = A.Current_Overdue_Count + 1
                ,A.TOTAL_OVERDUE_COUNT = A.TOTAL_OVERDUE_COUNT + 1
                ,A.LAST_UPDATE_DATE = SYSDATE
            WHERE A.ACCOUNT_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ACCOUNT_ID
            AND A.ENTITY_ID = ROW_SO_ACCOUNT_AGE_FREEZE.ENTITY_ID
            AND A.Customer_Code = ROW_SO_ACCOUNT_AGE_FREEZE.Customer_Code
            AND A.SALES_CENTER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.SALES_CENTER_CODE;
            
          --客户表上的逾期信息也累加1
          UPDATE T_CUSTOMER_HEADER H
            SET H.CURRENT_OVERDUE_COUNT = H.CURRENT_OVERDUE_COUNT + 1
                ,H.TOTAL_OVERDUE_COUNT = H.TOTAL_OVERDUE_COUNT + 1
                ,H.LAST_UPDATE_DATE = SYSDATE
            WHERE H.CUSTOMER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.Customer_Code;
            
          --是否冻结客户
          IF ROW_SO_ACCOUNT_AGE_FREEZE.FREEZE_CONTROL = 'Y' THEN
            UPDATE T_CUSTOMER_HEADER H
              SET H.IS_LOCKED = 'Y' 
                  ,H.LOCK_DATE = SYSDATE
                  ,H.LAST_UPDATE_DATE = SYSDATE
              WHERE H.CUSTOMER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.Customer_Code
              AND NVL(H.CURRENT_OVERDUE_COUNT,0) >= ROW_SO_ACCOUNT_AGE_FREEZE.FREEZE_CEIL
              AND NVL(H.IS_LOCKED,'N') = 'N';
          END IF;
          
          --插入一条坏账记录，还钱时间是空的
          insert into cims.t_credit_Bad_Record
            (BAD_RECORD_ID,
             ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             ACCOUNT_ID,
             ACCOUNT_CODE,
             ACCOUNT_NAME,
             SALES_REGION_ID,
             SALES_REGION_CODE,
             SALES_REGION_NAME,
             SALES_CENTER_ID,
             SALES_CENTER_CODE,
             SALES_CENTER_NAME,
             SALES_MAIN_TYPE,
             BAD_RECORD_TYPE,
             ACTIVE_FLAG,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             PAY_DATE,
             COUNTER, --当前逾期计数，
             PRE_FIELD_01,
             PRE_FIELD_02,
             PRE_FIELD_03,
             PRE_FIELD_04,
             PRE_FIELD_05,
             PRE_FIELD_06,
             BILL_ID)
          values
            (S_CREDIT_BAD_RECORD.NEXTVAL,
             ROW_SO_ACCOUNT_AGE_FREEZE.Entity_Id,
             (SELECT T.CUSTOMER_ID FROM CIMS.T_CUSTOMER_HEADER T WHERE T.CUSTOMER_CODE = ROW_SO_ACCOUNT_AGE_FREEZE.Customer_Code),
             ROW_SO_ACCOUNT_AGE_FREEZE.Customer_Code,
             ROW_SO_ACCOUNT_AGE_FREEZE.Customer_Name,
             ROW_SO_ACCOUNT_AGE_FREEZE.ACCOUNT_ID,
             ROW_SO_ACCOUNT_AGE_FREEZE.ACCOUNT_CODE,
             '',
             null,
             '',
             ROW_SO_ACCOUNT_AGE_FREEZE.Sales_Region_Name,
             null,
             ROW_SO_ACCOUNT_AGE_FREEZE.Sales_Center_Code,
             ROW_SO_ACCOUNT_AGE_FREEZE.Sales_Center_Name,
             ROW_SO_ACCOUNT_AGE_FREEZE.SALES_MAIN_TYPE_CODE,
             4,  --不良记录类型 4-应收逾期
             '1',--有效
             '应收逾期',
             TO_DATE(P_MATCH_DATE,'YYYY-MM-DD'),
             '应收逾期',
             SYSDATE,
             NULL,
             --获取账户的当前累计逾期次数
             1,
             ROW_SO_ACCOUNT_AGE_FREEZE.Overdue_Amount,---将账户总逾期金额记录到备用字段1上
             '',
             '',
             '',
             '',
             '',
             NULL);
                                                                       
       END IF;
        
            
    END LOOP;

   EXCEPTION WHEN OTHERS THEN
      ROLLBACK;
      P_MESSAGE := PKG_AR_WRITE_OFF.V_ERROR;
      P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_WRITE_OFF.P_AR_LOCK_OVERDUE_ACCOUNT', SQLCODE,
              '冻结逾期客户失败：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
    
   END ;   
END PKG_AR_WRITE_OFF;
/

