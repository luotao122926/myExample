create PACKAGE PKG_PMT_QUOTATION IS

  PMT_EXCEPTION EXCEPTION; --自定义异常

  V_RESULT VARCHAR2(20) := '1'; --成功标记

  V_RESULT_MSG VARCHAR2(1000) := 'success'; --成功返回信息

  /**
  *检查报价单预算
  */
  PROCEDURE P_QUOT_CHECK_BUDGET(P_ORDER_HEAD_ID         IN NUMBER,
                               P_BUDGET_AMOUNT         OUT NUMBER, --占用预算
                               P_BUDGET_AMOUNT_CAN_USE OUT NUMBER, --可用预算
                               P_BUDGET_AMOUNT_USING1  OUT NUMBER, --同节点制单占用预算
                               P_BUDGET_AMOUNT_USING2  OUT NUMBER, --同节点送审占用预算
                               P_MESSAGE               OUT VARCHAR2);

  /**
  *检查报价单预算
  */
  PROCEDURE P_QUOT_CHECK_BUDGET(P_ORDER_HEAD_ID         IN NUMBER,
                               I_BUDGET_AMOUNT         IN NUMBER, --预算
                               P_BUDGET_AMOUNT         OUT NUMBER, --占用预算
                               P_BUDGET_AMOUNT_CAN_USE OUT NUMBER, --可用预算
                               P_BUDGET_AMOUNT_USING1  OUT NUMBER, --同节点制单占用预算
                               P_BUDGET_AMOUNT_USING2  OUT NUMBER, --同节点送审占用预算
                               P_MESSAGE               OUT VARCHAR2);

  /*
  * 报价单占用预算
  */
  PROCEDURE P_QUOT_OCCUPY_BUDGET(HEADER_ID IN T_PMT_QUOTATION_HEAD.QUOTATION_ID%TYPE, --头表ID
                                  USER_ID   IN NUMBER, --用户ID
                                  FLAG      OUT VARCHAR2, --返回值
                                  FLAG_MSG  OUT VARCHAR2 --返回信息
                                  );

  /*
  * 报价单占用预算
  */
  PROCEDURE P_QUOT_OCCUPY_BUDGET(HEADER_ID       IN T_PMT_QUOTATION_HEAD.QUOTATION_ID%TYPE, --头表ID
                                  USER_ID         IN NUMBER, --用户ID
                                  I_BUDGET_AMOUNT IN NUMBER, --预算
                                  FLAG            OUT VARCHAR2, --返回值
                                  FLAG_MSG        OUT VARCHAR2 --返回信息
                                  );
  /**
  *  报价单红冲时释放预算
  */
  PROCEDURE P_QUOT_UNOCCUPY_BUDGET(HEADER_ID IN T_PMT_QUOTATION_HEAD.QUOTATION_ID%TYPE, --头表ID
                                    USER_ID   IN NUMBER, --用户ID
                                    FLAG      OUT VARCHAR2, --返回值
                                    FLAG_MSG  OUT VARCHAR2 --返回信息
                                    );
  /**
  *  报价单核销时释放预算
  *  lilh6  2018-7-26
  */
  Procedure p_Quot_Cancel_Budget(Header_Id          In t_Pmt_Quotation_Head.Quotation_Id%Type, --头表ID
                                   User_Id            In Number, --用户ID
                                   Flag               Out Varchar2, --返回值
                                   Flag_Msg           Out Varchar2 --返回信息
                                   );

END PKG_PMT_QUOTATION;
/

