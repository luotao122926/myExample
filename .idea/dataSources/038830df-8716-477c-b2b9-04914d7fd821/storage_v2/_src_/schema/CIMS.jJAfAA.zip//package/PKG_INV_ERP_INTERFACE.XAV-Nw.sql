create PACKAGE PKG_INV_ERP_INTERFACE AS
/******************************************************************************
   NAME:       PKG_INV_ERP_INTERFACE
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014/11/19             1. Created this package.
******************************************************************************/

  PROCEDURE P_INV_UPDATE_ORG_ENTITY;

  PROCEDURE P_INV_UPDATE_BILLCONFIG_ENTITY;

  PROCEDURE P_BD_INV_PRODUCTFINANCIALCLS(P_ITEM_ID In T_BD_ITEM.ITEM_ID%Type,
                                          P_RESULT In Out Number ,
                                          P_ERR_MSG In Out Varchar2);

END PKG_INV_ERP_INTERFACE;
/

