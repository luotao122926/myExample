create package body      PKG_PROTO_PUB
    is

  ----------------------------------------
  /*样机模块， add by lixiuhan*/
  /*

  */
  ----------------------------------------
  -- 定义全局异常变量
   error  exception;

  -- 判断门店最大上样量，判断单品最大上样量
  procedure P_PROTO_IS_MAX
  (P_TERMINAL_ENTITY_ID           in V_PRO_TERMINAL.terminal_id%type, --门店ID
   P_ITEM_ID             in T_BD_ITEM.ITEM_ID%type, --产品ID
   P_MAXIMUM_SAMPLE        in V_PRO_TERMINAL.maximum_sample%type, --门店申请数量（当前订单所有行申请数总和）
   P_SINGLE_MAXIMUM_SAMPLE in V_PRO_TERMINAL.single_maximum_sample%type, --单品申请数量
   P_ENTITY_ID             in V_PRO_TERMINAL.entity_id%type,--主体ID
   P_RETURN_CODE           out varchar2, --返回码
   P_RETURN_MSG            out varchar2 --返回提示信息
   ) as

    LS_MAXIMUM_SAMPLE         V_PRO_TERMINAL.maximum_sample%type; --门店现有量
    LS_SINGLE_MAXIMUM_SAMPLE  V_PRO_TERMINAL.single_maximum_sample%type; --单品现有量
    ZT_MAXIMUM_SAMPLE         V_PRO_TERMINAL.maximum_sample%type; --门店在途量
    ZT_SINGLE_MAXIMUM_SAMPLE  V_PRO_TERMINAL.single_maximum_sample%type; --单品在途量
    MAX_MAXIMUM_SAMPLE        V_PRO_TERMINAL.maximum_sample%type; --门店总数
    MAX_SINGLE_MAXIMUM_SAMPLE V_PRO_TERMINAL.single_maximum_sample%type; --单品总数
    LL_MAXIMUM_SAMPLE         V_PRO_TERMINAL.maximum_sample%type; --门店最大上样量
    LL_SINGLE_MAXIMUM_SAMPLE  V_PRO_TERMINAL.single_maximum_sample%type; --单品最大上样量
    --LS_Item_Code              T_BD_ITEM.Item_Code%type;  --产品编码
    LS_TERMINAL_CODE          V_PRO_TERMINAL.terminal_code%Type;--门店编码

  begin
    --判断传入参数不能为空
    if (P_TERMINAL_ENTITY_ID is null or P_ITEM_ID is null or
       P_MAXIMUM_SAMPLE is null or P_SINGLE_MAXIMUM_SAMPLE is null or P_ENTITY_ID is null) then
      P_RETURN_CODE := 'N';
      P_RETURN_MSG  := '获取参数问题：门店ID' || P_TERMINAL_ENTITY_ID || '或产品：' || P_ITEM_ID ||
                       '；或门店申请数量：' || P_MAXIMUM_SAMPLE || '；或单品申请数量：' ||
                       P_SINGLE_MAXIMUM_SAMPLE || '；或主体：' ||P_ENTITY_ID || '。';
      raise error;
    end if;

    --从门店维护表获取到门店最大上样量、单品最大上样量
    begin
      select nvl(b.maximum_sample, 0), nvl(b.single_maximum_sample, 0),b.terminal_code
        into LL_MAXIMUM_SAMPLE, LL_SINGLE_MAXIMUM_SAMPLE,LS_TERMINAL_CODE
        from v_pro_terminal b
       where b.terminal_entity_id = P_TERMINAL_ENTITY_ID
            and b.entity_id = P_ENTITY_ID;

      if (LL_MAXIMUM_SAMPLE <= 0  or LL_SINGLE_MAXIMUM_SAMPLE <= 0) then
        P_RETURN_CODE := 'N';
        P_RETURN_MSG  := '门店' || LS_TERMINAL_CODE || '最大上样量或单品最大上样量没维护';
        raise error;
      end if;

    exception
      when no_data_found then
        P_RETURN_CODE := 'N';
        P_RETURN_MSG  := '获取门店' || LS_TERMINAL_CODE ||'失败';
        raise error;
    end;

    --从现有量表获取到门店现有量
    select nvl(sum(a.fact_qty), 0)
      into LS_MAXIMUM_SAMPLE
      from t_pro_onhand a
     where a.terminal_entity_id = P_TERMINAL_ENTITY_ID
     and a.entity_id = P_ENTITY_ID;

    --从现有量表获取到门店单品现有量
    select nvl(sum(a.fact_qty), 0)
      into LS_SINGLE_MAXIMUM_SAMPLE
      from t_pro_onhand a
     where a.terminal_entity_id = P_TERMINAL_ENTITY_ID
       and a.item_id = P_ITEM_ID
       and a.entity_id = P_ENTITY_ID;

    --从V_PRO_PROTOTYPE_TRANSIT获取到门店在途量
    select nvl(sum(a.QUANTITY), 0)
      into ZT_MAXIMUM_SAMPLE
      from V_PRO_PROTOTYPE_TRANSIT a
     where a.terminal_entity_id = P_TERMINAL_ENTITY_ID
        and a.entity_id = P_ENTITY_ID;

    --从V_PRO_PROTOTYPE_TRANSIT获取到门店单品在途量
    select nvl(sum(a.QUANTITY), 0)
      into ZT_SINGLE_MAXIMUM_SAMPLE
      from V_PRO_PROTOTYPE_TRANSIT a
     where a.terminal_entity_id = P_TERMINAL_ENTITY_ID
       and a.item_id = P_ITEM_ID
       and a.entity_id = P_ENTITY_ID;

    MAX_MAXIMUM_SAMPLE        := P_MAXIMUM_SAMPLE + LS_MAXIMUM_SAMPLE + ZT_MAXIMUM_SAMPLE;
    MAX_SINGLE_MAXIMUM_SAMPLE := P_SINGLE_MAXIMUM_SAMPLE + LS_SINGLE_MAXIMUM_SAMPLE + ZT_SINGLE_MAXIMUM_SAMPLE;

    if (MAX_MAXIMUM_SAMPLE <= LL_MAXIMUM_SAMPLE and MAX_SINGLE_MAXIMUM_SAMPLE <= LL_SINGLE_MAXIMUM_SAMPLE) then
       P_RETURN_CODE := 'Y';
       P_RETURN_MSG  := '符合判断条件';
    else

      if (MAX_MAXIMUM_SAMPLE > LL_MAXIMUM_SAMPLE and MAX_SINGLE_MAXIMUM_SAMPLE <= LL_SINGLE_MAXIMUM_SAMPLE) then
         P_RETURN_MSG  :=   '门店' || LS_TERMINAL_CODE || '超上限'||LL_MAXIMUM_SAMPLE||'。';

      elsif (MAX_MAXIMUM_SAMPLE <= LL_MAXIMUM_SAMPLE and MAX_SINGLE_MAXIMUM_SAMPLE > LL_SINGLE_MAXIMUM_SAMPLE) then

         P_RETURN_MSG  :=   '门店' || LS_TERMINAL_CODE||'申请产品'||P_ITEM_ID || '超上限'||LL_SINGLE_MAXIMUM_SAMPLE||'。';
      else
         P_RETURN_MSG  :=   '门店' || LS_TERMINAL_CODE || '最大上样量与单品最大上样量都超过限制。';
      end if;

      P_RETURN_CODE := 'N';
    end if;

  exception
    when error then
      P_RETURN_CODE := 'N';
      P_RETURN_MSG  := P_RETURN_MSG;
    when others then
      P_RETURN_CODE := 'N';
      P_RETURN_MSG  := '程序错误！！！' || sqlerrm;
  end P_PROTO_IS_MAX;

end PKG_PROTO_PUB;
/

