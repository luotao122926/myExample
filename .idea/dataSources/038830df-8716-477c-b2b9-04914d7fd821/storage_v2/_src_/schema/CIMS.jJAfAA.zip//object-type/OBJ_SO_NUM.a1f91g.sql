create TYPE "OBJ_SO_NUM" As Object
(
  SO_NUM           VARCHAR2(32),
  REMARK           VARCHAR2(4000)
)
/

