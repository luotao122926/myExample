create package PKG_CREDIT_CYCLE_DELAYPAY is

  -- Author  : TIANMENGZHU
  -- Created : 2016/7/27 14:05:49
  -- Purpose : 循环铺底自动生成

  V_ERROR_INFO VARCHAR2(1000); --异常错误信息
  TYPE P_CURSOR IS REF CURSOR; --营销大类游标

  --循环生成铺底头、行
  PROCEDURE P_CREDIT_CYCLE_DELAYPAY_CREATE(P_MESSAGE OUT VARCHAR2 --成功返回'SUCCESS'，否则返回出错信息
                                           );

  --获取营销大类编码（客户经营产品中第一个信用等级最高的营销大类）
  FUNCTION F_GET_SALES_MAIN_TYPE_BY_LEVEL(P_ENTITY_ID   NUMBER, --客户ID
                                          P_CUSTOMER_ID NUMBER --主体ID
                                          ) RETURN VARCHAR2;
                                          
  /*
  * 铺底单据生成（单张）
  */
  PROCEDURE P_CREDIT_DELAYPAY_CREATE(P_ENTITY_ID               IN NUMBER, --主体ID
                                     P_CUSTOMER_ID             IN NUMBER, --客户ID
                                     P_CUSTOMER_CODE           IN T_CREDIT_DELAYPAY_CYCLE_CONFIG.CUSTOMER_CODE%TYPE, --客户编码
                                     P_CUSTOMER_NAME           IN T_CREDIT_DELAYPAY_CYCLE_CONFIG.CUSTOMER_CODE%TYPE, --客户名称
                                     P_CENTER_ID               IN NUMBER, --中心ID
                                     P_CENTER_CODE             IN T_CREDIT_DELAYPAY_CYCLE_CONFIG.SALES_CENTER_CODE%TYPE, --中心编码
                                     P_CENTER_NAME             IN T_CREDIT_DELAYPAY_CYCLE_CONFIG.SALES_CENTER_NAME%TYPE, --中心名称
                                     P_ACCOUNT_ID              IN NUMBER, --账户ID
                                     P_ACCOUNT_CODE            IN V_CUSTOMER_ACCOUNT_SALECENTER.ACCOUNT_CODE%TYPE, --账户编码
                                     P_ITEM_CODE               IN T_CUSTOMER_SALES_MAIN_TYPE.SALES_MAIN_TYPE_CODE%TYPE, --大类编码
                                     P_USE_AMOUNT              IN NUMBER, --可用信用额度
                                     P_ACC_TOTAL_TWELVE_AMOUNT IN NUMBER, --客户对应账户前12个销售金额总和
                                     P_MESSAGE                 OUT VARCHAR2 --成功返回'SUCCESS'，否则返回出错信息
                                     );

end PKG_CREDIT_CYCLE_DELAYPAY;
/

