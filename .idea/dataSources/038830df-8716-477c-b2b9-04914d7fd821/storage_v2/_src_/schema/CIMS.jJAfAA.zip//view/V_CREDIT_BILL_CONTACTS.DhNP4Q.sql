create view V_CREDIT_BILL_CONTACTS as
select "DUMMY" --henhao
    from dual
/

