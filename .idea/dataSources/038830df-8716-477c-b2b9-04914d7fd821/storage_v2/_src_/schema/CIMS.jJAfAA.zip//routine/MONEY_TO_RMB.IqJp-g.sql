create FUNCTION MONEY_TO_RMB(JE NUMBER) RETURN VARCHAR2 IS
  I    PLS_INTEGER;
  SNUM VARCHAR2(20) := LTRIM(REPLACE(TO_CHAR(ABS(JE), '9999999999999990.99'),
                                     '.'));
  LEN  PLS_INTEGER := LENGTH(SNUM);
  SCH  VARCHAR2(40) := '零壹贰叁肆伍陆柒捌玖';
  SJIN VARCHAR2(150) := '分角圆拾佰仟万拾佰仟亿拾佰仟万拾佰仟';
  SRMB VARCHAR2(300) := '';
  NUM  PLS_INTEGER;
  S_NUM PLS_INTEGER := 0; --'0'起始位置
  E_NUM PLS_INTEGER := 0; --'0'结束位置
BEGIN
  IF JE IS NOT NULL THEN
    FOR I IN 1 .. LEN LOOP
      NUM := TO_NUMBER(SUBSTR(SNUM, I, 1));

      IF NUM <> 0 THEN
        --非'0'时处理：
        IF S_NUM = 0 THEN
          SRMB := SRMB || SUBSTR(SCH, NUM + 1, 1) ||
                  SUBSTR(SJIN, LEN - I + 1, 1); --前面字符非'0', 正常联接...
        ELSE
          SRMB := SRMB || --否则：
                  CASE
                    WHEN S_NUM = E_NUM THEN --前面只有一个'0'
                     CASE S_NUM
                       WHEN 7 THEN
                        '万' --只处理进位
                       WHEN 11 THEN
                        '亿'
                       WHEN 15 THEN
                        '万'
                     END
                    WHEN E_NUM < 12 THEN --否则(多个'0'处理)
                     CASE
                       WHEN S_NUM < 7 THEN
                        '' --万以内..
                       WHEN S_NUM < 11 THEN
                        CASE
                          WHEN E_NUM < 8 AND S_NUM < 10 THEN
                           '万'
                        END
                       WHEN S_NUM < 15 THEN
                        CASE
                          WHEN E_NUM < 12 THEN
                           '亿'
                        END
                       ELSE
                        '万亿'
                     END
                    WHEN E_NUM < 16 AND S_NUM > 14 THEN
                     '万'
                  END || CASE
                    WHEN S_NUM > 3 AND E_NUM < 3 THEN
                     '圆零'
                    WHEN E_NUM = 3 THEN
                     '圆'
                    WHEN E_NUM NOT IN (7, 11, 15) OR S_NUM - E_NUM > 2 THEN
                     '零'
                  END;
          SRMB := SRMB || SUBSTR(SCH, NUM + 1, 1) ||
                  SUBSTR(SJIN, LEN - I + 1, 1);
        END IF;

        S_NUM := 0;
        E_NUM := 0;
      ELSE
        IF S_NUM = 0 THEN
          --当S_NUM = 0时'0'串起始，
          S_NUM := LEN - I + 1; --记录开始
          E_NUM := S_NUM; --各结整位置。
        ELSE
          E_NUM := LEN - I + 1; --否则新的结整位置。
        END IF;
      END IF;
    END LOOP;

    IF S_NUM <> 0 THEN
      --此时以'0'结尾
      SRMB := SRMB || CASE
                WHEN S_NUM = LEN THEN
                 '零圆整' --全'0'串，加...
                WHEN S_NUM = 1 OR S_NUM = 2 THEN
                 '整' --分(1)，角(2)后加...
                WHEN S_NUM < 7 OR S_NUM = 10 THEN
                 '圆整'
                WHEN S_NUM < 11 THEN
                 '万圆整'
                WHEN S_NUM < 15 THEN
                 '亿圆整'
                ELSE
                 '万亿圆整'
              END;
    ELSE
      SRMB := SRMB || '整'; --不以'0'结尾，加...
    END IF;

    IF JE < 0 THEN
      SRMB := '负' || SRMB;
    END IF;
  ELSE
    SRMB := NULL;
  END IF;
  RETURN SRMB;
END MONEY_TO_RMB;
/

