create view V_CUSTOMER_BANK as
select BANK_ID,
       ENTITY_ID,
       CUSTOMER_ID,
       CUSTOMER_CODE,
       DEPT_ID,
       DEPT_CODE,
       BANK,
       BRANCH,
       ACCOUNTS_NAME,
       BANK_ACCOUNT,
       ACTIVE_FLAG,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATE_DATE,
       LAST_UPDATE_BY,
       LAST_INTERFACE_DATE,
       SIEBEL_BANK_ID,
       SIEBEL_CUSTOMER_ID,
       PRE_FIELD_01,
       PRE_FIELD_02,
       PRE_FIELD_03,
       PRE_FIELD_04,
       PRE_FIELD_05,
       PRE_FIELD_06
  from T_CUSTOMER_BANK with read only
/

comment on column V_CUSTOMER_BANK.BANK_ID is '银行ID'
/

comment on column V_CUSTOMER_BANK.ENTITY_ID is '主体ID'
/

comment on column V_CUSTOMER_BANK.CUSTOMER_ID is '客户ID'
/

comment on column V_CUSTOMER_BANK.CUSTOMER_CODE is '客户编码'
/

comment on column V_CUSTOMER_BANK.DEPT_ID is '事业部ID'
/

comment on column V_CUSTOMER_BANK.DEPT_CODE is '事业部编码'
/

comment on column V_CUSTOMER_BANK.BANK is '开户行'
/

comment on column V_CUSTOMER_BANK.BRANCH is '支行'
/

comment on column V_CUSTOMER_BANK.ACCOUNTS_NAME is '开户名'
/

comment on column V_CUSTOMER_BANK.BANK_ACCOUNT is '银行账号'
/

comment on column V_CUSTOMER_BANK.ACTIVE_FLAG is '是否有效(Y/N)'
/

comment on column V_CUSTOMER_BANK.CREATED_BY is '创建人'
/

comment on column V_CUSTOMER_BANK.CREATION_DATE is '创建日期'
/

comment on column V_CUSTOMER_BANK.LAST_UPDATE_DATE is '最后修改时间'
/

comment on column V_CUSTOMER_BANK.LAST_UPDATE_BY is '最后修改人'
/

comment on column V_CUSTOMER_BANK.LAST_INTERFACE_DATE is '最后同步时间'
/

comment on column V_CUSTOMER_BANK.SIEBEL_BANK_ID is '主数据银行ID'
/

comment on column V_CUSTOMER_BANK.SIEBEL_CUSTOMER_ID is '主数据客户ID'
/

comment on column V_CUSTOMER_BANK.PRE_FIELD_01 is '预留字段1'
/

comment on column V_CUSTOMER_BANK.PRE_FIELD_02 is '预留字段2'
/

comment on column V_CUSTOMER_BANK.PRE_FIELD_03 is '预留字段3'
/

comment on column V_CUSTOMER_BANK.PRE_FIELD_04 is '预留字段4'
/

comment on column V_CUSTOMER_BANK.PRE_FIELD_05 is '预留字段5'
/

comment on column V_CUSTOMER_BANK.PRE_FIELD_06 is '预留字段6'
/

