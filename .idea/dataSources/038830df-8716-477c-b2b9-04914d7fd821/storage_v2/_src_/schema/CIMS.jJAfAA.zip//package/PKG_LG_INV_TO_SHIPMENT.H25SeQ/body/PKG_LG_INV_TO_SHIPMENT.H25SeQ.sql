create PACKAGE BODY      PKG_LG_INV_TO_SHIPMENT AS

  -----------------------------------------------------------------------------
  --  销售单生成运输合同                        --
  -----------------------------------------------------------------------------
  PROCEDURE P_LG_CONTRACT_BY_INVNUM(INV_NUM IN VARCHAR2,
                                     INV_NUMS IN VARCHAR2,
                                     SHIP_WAY      IN VARCHAR2,
                                     SHIP_TYPE     IN VARCHAR2,
                                     LOAD_VEHICLE_TYPE IN VARCHAR2,
                                     VENDOR_CDE IN VARCHAR2,
                                     CONSIGNEE_LOCCDE IN VARCHAR2,--收货地址
                                     VEHICLE_NUM IN VARCHAR2,
                                     SHIP_DATE IN VARCHAR2,
                                     VEHICLE_BRAND_NUM IN VARCHAR2,
                                     CHAUFFEUR_TEL IN VARCHAR2,
                                     CHAUFFEUR_IDENTITY_NUM IN VARCHAR2,
                                     CHAUFFEUR IN VARCHAR2,
                                     CUSTOMER_CONTACTS IN VARCHAR2,--
                                     CUSTOMER_CONTACTS_PHONES IN Varchar2,--
                                     CONSIGNEE_COMPANY_ADDR IN VARCHAR2,--
                                     O_RESULT      OUT VARCHAR2,
                                     O_RESULT_MSG  OUT VARCHAR2) IS

    V_LG_VEHICLE_INFO_ROW      T_LG_VEHICLE_INFO%ROWTYPE;
    V_LG_CONTRACT_ROW          T_LG_CONTRACT%ROWTYPE;
    V_LG_CONTRACT_LINE_ROW     T_LG_CONTRACT_LINE%ROWTYPE;
    --TYPE TYPE_LG_CONTRACT IS TABLE OF T_LG_CONTRACT%ROWTYPE INDEX BY BINARY_INTEGER;
    --V_LG_CONTRACT TYPE_LG_CONTRACT;
    TYPE TYPE_LG_CONTRACT_LINE IS TABLE OF T_LG_CONTRACT_LINE%ROWTYPE INDEX BY BINARY_INTEGER;
    V_LG_CONTRACT_LINE TYPE_LG_CONTRACT_LINE;

    V_SO_HEAHER                T_SO_HEADER%ROWTYPE;--销头
    V_LG_VENDOR_INFO           T_LG_VENDOR_INFO_HEAD%ROWTYPE;--承运商
    V_LG_TRANSPORT_LINE        T_LG_TRANSPORT_LINE%ROWTYPE;--运输线路

    V_SHIP_TO_LOCATION_ID      T_BD_DISTRICT.ROW_ID%TYPE;--发货地点：行政区域
    CONSIGNEE_LOCATION_ID      T_BD_DISTRICT.ROW_ID%TYPE;--收货货地点：行政区域

    V_LG_LINE_FREIGHT_STANDARD T_LG_LINE_FREIGHT_STANDARD%ROWTYPE;--线路运费标准
    V_LG_INSURANCE_ROW         T_LG_INSURANCE%ROWTYPE;
    V_LIST_PRICE               T_BD_PRICE_LINE.LIST_PRICE%TYPE;
    V_TAX_RATE                 T_LG_CONTRACT.TAX_RATE%TYPE; --税率
    V_TRANSPORT_LINE_ID        T_LG_TRANSPORT_LINE.TRANSPORT_LINE_ID%TYPE; --运输线路ID
    SHIPTO_LOCCDE              T_LG_TRANSPORT_LINE.Ship_To_Location_Code%TYPE;

    FREIGHT                    T_LG_CONTRACT_LINE.Freight%TYPE;--运费
    INSURANCE                  T_LG_CONTRACT_LINE.Insurance%TYPE;--保险费
    TOTAL_VOLUME               T_LG_CONTRACT_LINE.UNIT_VOLUME%TYPE;--总体积
    TOTAL_WEIGHT               T_LG_CONTRACT_LINE.Unit_Weight%TYPE;--总重量
    AMOUNT                     T_LG_CONTRACT_LINE.Amount%TYPE;--金额

    var_tmp VARCHAR2(500) := INV_NUMS;
    var_split VARCHAR2(10) := ',';
    var_element varchar2(40) := '';

  BEGIN
    O_RESULT     := '1';
    O_RESULT_MSG := '生成成功';
    SAVEPOINT SAVEPOINT_KXMX ;

    /*初始化信息*/
    SELECT * INTO V_SO_HEAHER FROM T_SO_HEADER WHERE SO_NUM = INV_NUM;
    select * INTO V_LG_VENDOR_INFO from T_LG_VENDOR_INFO_HEAD WHERE VENDOR_CODE = VENDOR_CDE and rownum = 1;
    --获取线路/地点信息
    select t.district_code into SHIPTO_LOCCDE from t_inv_inventories r,t_bd_district t  where r.inventory_id = V_SO_HEAHER.Ship_Inv_Id and r.district_id = t.row_id and rownum=1;
    V_TRANSPORT_LINE_ID := PKG_LG_SHIP.F_GET_TRANSPORT_LINE_NEW(V_SO_HEAHER.ENTITY_ID,SHIPTO_LOCCDE,CONSIGNEE_LOCCDE,SHIP_WAY,SHIP_TYPE,LOAD_VEHICLE_TYPE);
    if V_TRANSPORT_LINE_ID = 0 then
       O_RESULT     := '0';
       O_RESULT_MSG := '生成运输合同失败:不存在运输线路！';
       RETURN;
    end if;

    select * INTO V_LG_TRANSPORT_LINE from T_LG_TRANSPORT_LINE where TRANSPORT_LINE_ID = V_TRANSPORT_LINE_ID;
    select ROW_ID into V_SHIP_TO_LOCATION_ID from T_BD_DISTRICT where DISTRICT_CODE = V_LG_TRANSPORT_LINE.Ship_To_Location_Code and rownum=1;
    select ROW_ID into CONSIGNEE_LOCATION_ID from T_BD_DISTRICT where DISTRICT_CODE = V_LG_TRANSPORT_LINE.Consignee_Location_Code and rownum=1;

    BEGIN
      --查询保险费价格列表ID和税率
      SELECT *
        INTO V_LG_INSURANCE_ROW
        FROM T_LG_INSURANCE
       WHERE ENTITY_ID = V_SO_HEAHER.ENTITY_ID
         AND TRANSPORT_WAY = SHIP_WAY
         AND BEGIN_DATE <= SYSDATE
         AND (END_DATE IS NULL OR
             (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    BEGIN
      --获取附加运费和计价单位
      SELECT T.EXTRA_SHIP_CHARGES, T.PRICE_UNIT
        INTO V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES,
             V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT
        FROM T_LG_LINE_FREIGHT_STANDARD T
       WHERE T.TRANSPORT_LINE_ID = V_TRANSPORT_LINE_ID
         AND T.SHIP_WAY = SHIP_WAY
         AND T.SHIP_TYPE = SHIP_TYPE
         AND T.LOAD_VEHICLE_TYPE = LOAD_VEHICLE_TYPE
         AND T.VENDOR_ID = V_LG_VENDOR_INFO.VENDOR_ID
         AND BEGIN_DATE <= SYSDATE
         AND (END_DATE IS NULL OR
             (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    --按照客户、营销中心、发运方式、收货地址、发货仓库

    --构建排车信息
    V_LG_VEHICLE_INFO_ROW.VEHICLE_INFO_ID        := S_LG_VEHICLE_INFO.NEXTVAL;
    V_LG_VEHICLE_INFO_ROW.ENTITY_ID              := V_SO_HEAHER.ENTITY_ID;
    V_LG_VEHICLE_INFO_ROW.VEHICLE_NUM            := VEHICLE_NUM;
    V_LG_VEHICLE_INFO_ROW.SHIP_DATE              := to_date(SHIP_DATE,'yyyy-MM-dd');
    V_LG_VEHICLE_INFO_ROW.VEHICLE_BRAND_NUM      := VEHICLE_BRAND_NUM;
    V_LG_VEHICLE_INFO_ROW.CHAUFFEUR_TEL          := CHAUFFEUR_TEL;
    V_LG_VEHICLE_INFO_ROW.CHAUFFEUR_IDENTITY_NUM := CHAUFFEUR_IDENTITY_NUM;
    V_LG_VEHICLE_INFO_ROW.CHAUFFEUR              := CHAUFFEUR;
    V_LG_VEHICLE_INFO_ROW.SEAL_NUM               := '';
    V_LG_VEHICLE_INFO_ROW.SEAL_DATE              := '';
    V_LG_VEHICLE_INFO_ROW.SEAL_BY                := '';
    V_LG_VEHICLE_INFO_ROW.SIGN_SEAL_NUM          := '';
    V_LG_VEHICLE_INFO_ROW.SIGN_SEAL_DATE         := '';
    V_LG_VEHICLE_INFO_ROW.SIGN_SEAL_BY           := '';
    V_LG_VEHICLE_INFO_ROW.SEAL_STATUS            := '';
    V_LG_VEHICLE_INFO_ROW.VENDOR_ID              := V_LG_VENDOR_INFO.VENDOR_ID;
    V_LG_VEHICLE_INFO_ROW.VENDOR_CODE            := V_LG_VENDOR_INFO.VENDOR_CODE;
    V_LG_VEHICLE_INFO_ROW.VENDOR_NAME            := V_LG_VENDOR_INFO.VENDOR_NAME;
    V_LG_VEHICLE_INFO_ROW.VENDOR_CONTACT         := '';
    V_LG_VEHICLE_INFO_ROW.VENDOR_TEL             := '';
    V_LG_VEHICLE_INFO_ROW.CREATED_BY             := 'LG';
    V_LG_VEHICLE_INFO_ROW.CREATION_DATE          := SYSDATE;
    V_LG_VEHICLE_INFO_ROW.LAST_UPDATED_BY        := 'LG';
    V_LG_VEHICLE_INFO_ROW.LAST_UPDATE_DATE       := SYSDATE;


    --构建运输合同头
    V_LG_CONTRACT_ROW.CONTRACT_ID                  := S_LG_CONTRACT.NEXTVAL;
    V_LG_CONTRACT_ROW.ENTITY_ID                    := V_SO_HEAHER.ENTITY_ID;
    V_LG_CONTRACT_ROW.CONTRACT_CODE                := PKG_BD.F_GET_BILL_NO(P_BILL_TYPE  => 'lgContractNo',
                                                                           P_PREFIX_ADD => NULL,
                                                                           P_ENTITY_ID  => V_SO_HEAHER.ENTITY_ID,
                                                                           P_USER_ID    => NULL);
    V_LG_CONTRACT_ROW.BILLS_STATUS                 := '00';
    V_LG_CONTRACT_ROW.VEHICLE_INFO_ID              := V_LG_VEHICLE_INFO_ROW.VEHICLE_INFO_ID;
    V_LG_CONTRACT_ROW.SALES_CENTER_ID              := V_SO_HEAHER.SALES_CENTER_ID;
    V_LG_CONTRACT_ROW.SHIP_WAY                     := SHIP_WAY;
    V_LG_CONTRACT_ROW.LOAD_VEHICLE_TYPE            := LOAD_VEHICLE_TYPE;
    V_LG_CONTRACT_ROW.SHIP_TYPE                    := SHIP_TYPE;
    V_LG_CONTRACT_ROW.CUSTOMER_ID                  := V_SO_HEAHER.CUSTOMER_ID;
    V_LG_CONTRACT_ROW.CUSTOMER_CODE                := V_SO_HEAHER.CUSTOMER_CODE;
    V_LG_CONTRACT_ROW.CUSTOMER_NAME                := V_SO_HEAHER.CUSTOMER_NAME;
    V_LG_CONTRACT_ROW.ACCOUNT_CODE                 := V_SO_HEAHER.ACCOUNT_CODE;
    V_LG_CONTRACT_ROW.CUSTOMER_CONTACTS            := CUSTOMER_CONTACTS;
    V_LG_CONTRACT_ROW.CUSTOMER_CONTACTS_PHONES     := CUSTOMER_CONTACTS_PHONES;

    V_LG_CONTRACT_ROW.SHIP_TO_LOCATION_ID          := V_SHIP_TO_LOCATION_ID;
    V_LG_CONTRACT_ROW.SHIP_TO_LOCATION_CODE        := V_LG_TRANSPORT_LINE.SHIP_TO_LOCATION_CODE;
    V_LG_CONTRACT_ROW.SHIP_TO_LOCATION             := V_LG_TRANSPORT_LINE.Ship_To_Location_Name;
    V_LG_CONTRACT_ROW.SHIP_INVENTORY_ID            := V_SO_HEAHER.SHIP_INV_ID;
    V_LG_CONTRACT_ROW.SHIP_INVENTORY_CODE          := V_SO_HEAHER.SHIP_INV_CODE;
    V_LG_CONTRACT_ROW.SHIP_INVENTORY_NAME          := V_SO_HEAHER.SHIP_INV_NAME;
    V_LG_CONTRACT_ROW.CONSIGNEE_INVENTORY_ID       := V_SO_HEAHER.CONSIGNEE_INV_ID;
    V_LG_CONTRACT_ROW.CONSIGNEE_INVENTORY_CODE     := V_SO_HEAHER.CONSIGNEE_INV_CODE;
    V_LG_CONTRACT_ROW.CONSIGNEE_INVENTORY_NAME     := V_SO_HEAHER.CONSIGNEE_INV_NAME;
    V_LG_CONTRACT_ROW.CONSIGNEE_ADDR               := V_SO_HEAHER.CONSIGNEE_ADDRESS;
    V_LG_CONTRACT_ROW.CONSIGNEE_LOCATION_ID        := CONSIGNEE_LOCATION_ID;
    V_LG_CONTRACT_ROW.CONSIGNEE_LOCATION_CODE      := V_LG_TRANSPORT_LINE.Consignee_Location_Code;
    V_LG_CONTRACT_ROW.CONSIGNEE_LOCATION           := V_LG_TRANSPORT_LINE.Consignee_Location_Name;

    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_ID         := V_SO_HEAHER.CUSTOMER_ID;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_CODE       := V_SO_HEAHER.CUSTOMER_CODE;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_NAME       := V_SO_HEAHER.CUSTOMER_NAME;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_ADDR       := CONSIGNEE_COMPANY_ADDR;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_CONTACT_ID := '';
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_CONTRACT   := CUSTOMER_CONTACTS;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_TEL        := CUSTOMER_CONTACTS_PHONES;
    V_LG_CONTRACT_ROW.IS_CUSG_FLAG                 := V_SO_HEAHER.DIRECT_SHIP_FLAG; --是否直发
    --获取经营单位名称
    BEGIN
      --update tusj 2015.9.25
      SELECT A.OPERATING_UNIT_NAME, A.OPERATING_UNIT
       INTO V_LG_CONTRACT_ROW.SHIP_COMPANY,V_LG_CONTRACT_ROW.OPERATING_UNIT
       FROM T_INV_ORGANIZATION A, T_INV_INVENTORIES B
      WHERE A.ORGANIZATION_ID = B.ORGANIZATION_ID
        AND A.ENTITY_ID = B.ENTITY_ID
        AND B.INVENTORY_ID = V_LG_CONTRACT_ROW.SHIP_INVENTORY_ID;

    /*      SELECT OPERATING_UNIT_NAME, OPERATING_UNIT
        INTO V_LG_CONTRACT_ROW.SHIP_COMPANY,V_LG_CONTRACT_ROW.OPERATING_UNIT
        FROM T_INV_ORGANIZATION
       WHERE ORGANIZATION_ID =
             (SELECT ORGANIZATION_ID
                FROM T_INV_INVENTORIES
               WHERE INVENTORY_ID = V_LG_CONTRACT_ROW.SHIP_INVENTORY_ID);*/
       --end tusj 2015.9.25
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '2001';
        O_RESULT_MSG := '经营单位信息不存在！';
        RETURN;
    END;
    V_LG_CONTRACT_ROW.REQUIRE_SHIP_DATE   := to_date(SHIP_DATE,'yyyy-MM-dd');
    V_LG_CONTRACT_ROW.FACT_SHIP_DATE      := to_date(SHIP_DATE,'yyyy-MM-dd');
    V_LG_CONTRACT_ROW.REQUIRE_ARRIVE_DATE := to_date(SHIP_DATE,'yyyy-MM-dd');
    V_LG_CONTRACT_ROW.FACT_ARRIVE_DATE    := NULL;
    V_LG_CONTRACT_ROW.DROP_SHIP_FLAG      := NULL;
    V_LG_CONTRACT_ROW.DISTANCE            := V_LG_TRANSPORT_LINE.DISTANCE;
    V_LG_CONTRACT_ROW.FREIGHT             := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.TAX_AMOUNT          := 0; --后面汇总计算

    --获取运费税率
    BEGIN
      SELECT TAX_RATE
        INTO V_TAX_RATE
        FROM T_LG_TAX_RATE_CONF
       WHERE CHARGES_TYPE_CODE = '00'
         AND DEFAULT_FLAG = 'Y';
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    V_LG_CONTRACT_ROW.TAX_RATE              := NVL(V_TAX_RATE, 0); --运费税率
    V_LG_CONTRACT_ROW.FREIGHT_NO_TAX        := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.ORIGIN_SHIP_CHARGES   := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.ADJUST_SHIP_CHARGES   := 0; --重新计算时填写
    V_LG_CONTRACT_ROW.FREIGHT_ADJUST_REASON := NULL;
    V_LG_CONTRACT_ROW.PRICE_UNIT            := V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT;
    V_LG_CONTRACT_ROW.TOTAL_VOLUME          := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.TOTAL_WEIGHT          := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.TOTAL_AMOUNT          := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.WEIGHT_UNIT           := 'KG'; --系统默认
    V_LG_CONTRACT_ROW.VOL_UNIT              := '方'; --系统默认
    V_LG_CONTRACT_ROW.PRINT_FLAG            := 'N';
    V_LG_CONTRACT_ROW.PRINT_TIMES           := 0;
    V_LG_CONTRACT_ROW.PRINT_DATE            := NULL;
    V_LG_CONTRACT_ROW.RECEIVE_FLAG          := 'N';
    V_LG_CONTRACT_ROW.RECEIVE_DATE          := NULL;
    V_LG_CONTRACT_ROW.RECEIVE_BY_NAME       := NULL;
    V_LG_CONTRACT_ROW.BACK_FLAG             := 'N';
    V_LG_CONTRACT_ROW.BACK_DATE             := NULL;
    V_LG_CONTRACT_ROW.LOCK_FLAG             := 'N';
    V_LG_CONTRACT_ROW.JUDGEMAR_CODE         := NULL;
    V_LG_CONTRACT_ROW.INSURANCE_FLAG        := 'Y'; --默认购买保险
    V_LG_CONTRACT_ROW.INSURACE_ID           := V_LG_INSURANCE_ROW.INSURER_ID; --命名不一致
    --获取保险商CODE和NAME
    BEGIN
      SELECT VENDOR_CODE, VENDOR_NAME
        INTO V_LG_CONTRACT_ROW.INSURACE_CODE,
             V_LG_CONTRACT_ROW.INSURACE_NAME
        FROM T_LG_VENDOR_INFO_HEAD
       WHERE VENDOR_ID = V_LG_CONTRACT_ROW.INSURACE_ID;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    V_LG_CONTRACT_ROW.RISK_AMOUNT            := 0; --投保金额
    V_LG_CONTRACT_ROW.INSURANCE              := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.COMPENSATION_AMOUNT    := NULL;
    V_LG_CONTRACT_ROW.COMPENSATION_REASON    := NULL;
    V_LG_CONTRACT_ROW.COMPENSATION_DATE      := NULL;
    V_LG_CONTRACT_ROW.CLAIM_VENDOR_CODE      := NULL;
    V_LG_CONTRACT_ROW.CLAIM_VENDOR_NAME      := NULL;
    V_LG_CONTRACT_ROW.BREAK_CLAIMANT_AMOUNT  := NULL;
    V_LG_CONTRACT_ROW.BREAK_CLAIMANT_REASON  := NULL;
    V_LG_CONTRACT_ROW.BREAK_CLAIMANT_DATE    := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_CLAIMANT_AMOUNT := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_CLAIMANT_REASON := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_CLAIMANT_DATE   := NULL;
    V_LG_CONTRACT_ROW.BREAK_CLAIM_DATE       := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_CLAIM_DATE      := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_INC_DEC_CODE    := NULL;
    V_LG_CONTRACT_ROW.BREAK_INC_DEC_CODE     := NULL;
    V_LG_CONTRACT_ROW.CONTRACT_TYPE          := '00';
    V_LG_CONTRACT_ROW.ORIGIN_CONTRACT_CODE   := NULL;
    V_LG_CONTRACT_ROW.FREIGHT_BATCH_FLAG     := NULL;
    V_LG_CONTRACT_ROW.INSUANCE_BATCH_FLAG    := NULL;
    V_LG_CONTRACT_ROW.FREIGHT_BATCH_NUM      := NULL;
    V_LG_CONTRACT_ROW.INSURANCE_BATCH_NUM    := NULL;
    V_LG_CONTRACT_ROW.SEND_FLAG              := NULL;
    V_LG_CONTRACT_ROW.VENDOR_FLAG            := NULL;
    V_LG_CONTRACT_ROW.VENDOR_ERROR_MESSAGE   := NULL;
    V_LG_CONTRACT_ROW.IMPORT_VENDOR_TIME     := NULL;
    V_LG_CONTRACT_ROW.CONTRACT_DATE          := SYSDATE;
    V_LG_CONTRACT_ROW.REG_CARRIAGE_FLAG      := 'N';
    V_LG_CONTRACT_ROW.REG_INSURANCE_FLAG     := 'N';
    V_LG_CONTRACT_ROW.PROMOTION_PRODUCT_VOL  := NULL; --暂时保留
    V_LG_CONTRACT_ROW.CREATED_BY             := 'LG';
    V_LG_CONTRACT_ROW.CREATION_DATE          := SYSDATE;
    V_LG_CONTRACT_ROW.LAST_UPDATED_BY        := 'LG';
    V_LG_CONTRACT_ROW.LAST_UPDATE_DATE       := SYSDATE;
    V_LG_CONTRACT_ROW.REMARK                 := NULL;

    --V_LG_CONTRACT(V_LG_CONTRACT.COUNT + 1) := V_LG_CONTRACT_ROW;

    --END IF;
    --遍历头表
    FREIGHT := 0;
    INSURANCE :=0;
    TOTAL_VOLUME :=0;
    TOTAL_WEIGHT :=0;
    AMOUNT :=0;

    while instr(var_tmp, var_split)>0 loop
       var_element := substr(var_tmp, 1, instr(var_tmp, var_split) - 1);
       var_tmp     := substr(var_tmp, instr(var_tmp, var_split) + length(var_split), length(var_tmp));
       --DBMS_OUTPUT.PUT_LINE(var_element);

      FOR C_SO_HEADER IN (SELECT * FROM T_SO_HEADER WHERE SO_NUM = var_element) LOOP
        --遍历行明细表
        FOR C_SO_LINE IN (SELECT * FROM T_SO_LINE L WHERE L.SO_HEADER_ID = C_SO_HEADER.SO_HEADER_ID) LOOP

          IF C_SO_LINE.ITEM_IS_SET = 'Y' THEN --1 套件
            --拆分套件到散件
            FOR C_SO_LINE_DETAIL IN (SELECT * FROM T_SO_LINE_DETAIL WHERE SO_LINE_ID = C_SO_LINE.SO_LINE_ID) LOOP
              --构建运输合同行
              V_LG_CONTRACT_LINE_ROW.CONTRACT_LINE_ID    := S_LG_CONTRACT_LINE.NEXTVAL;
              V_LG_CONTRACT_LINE_ROW.CONTRACT_ID         := V_LG_CONTRACT_ROW.CONTRACT_ID;
              V_LG_CONTRACT_LINE_ROW.SALES_MAIN_TYPE     := C_SO_HEADER.SALES_MAIN_TYPE;
              V_LG_CONTRACT_LINE_ROW.SALES_ORDER_TYPE_ID := C_SO_HEADER.Bill_Type_Id;
              V_LG_CONTRACT_LINE_ROW.SO_DOC_ID           := C_SO_HEADER.SO_HEADER_ID;
              V_LG_CONTRACT_LINE_ROW.SO_DOC_NUM          := C_SO_HEADER.SO_NUM;
              V_LG_CONTRACT_LINE_ROW.ITEM_CODE           := C_SO_LINE_DETAIL.Component_Code;
              V_LG_CONTRACT_LINE_ROW.ITEM_NAME           := C_SO_LINE_DETAIL.Component_Name;
              --查询产品单位、重量、体积
              SELECT DEFAULTUNIT, GROSSWEIGHT, PACKINGSIZE
                INTO V_LG_CONTRACT_LINE_ROW.ITEM_UOM,
                     V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT,
                     V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME
                FROM T_BD_ITEM
               WHERE ITEM_CODE = C_SO_LINE_DETAIL.Component_Code;
              V_LG_CONTRACT_LINE_ROW.ITEM_PRICE := C_SO_LINE.ITEM_PRICE; --在基础模块获取（熊培良确认）
              --实发数量 = 散件数量 * 产品数量
              V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY := C_SO_LINE_DETAIL.Component_Qty;
              V_LG_CONTRACT_LINE_ROW.AMOUNT        := V_LG_CONTRACT_LINE_ROW.ITEM_PRICE *
                                                      V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
              V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME  := V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME *
                                                      V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
              V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT  := V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT *
                                                      V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
              V_LG_CONTRACT_LINE_ROW.SET_FLAG      := C_SO_LINE.Item_Is_Set;
              V_LG_CONTRACT_LINE_ROW.SET_CODE      := C_SO_LINE.Item_Code;
              --大电模式 只考虑整车情况
              IF (LOAD_VEHICLE_TYPE = '01') THEN
                BEGIN
                  SELECT ROUND((CASE
                                 WHEN PRICE_UNIT = '00' THEN --按照体积计算
                                  UNIT_PRICE_OF_FREIGHT *
                                  V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME
                                 WHEN PRICE_UNIT = '01' THEN --按照重量计算
                                  UNIT_PRICE_OF_FREIGHT *
                                  V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT
                                 ELSE
                                  0
                               END),
                               2) +
                         V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES
                    INTO V_LG_CONTRACT_LINE_ROW.FREIGHT
                    FROM T_LG_LINE_FREIGHT_STANDARD T
                   WHERE T.TRANSPORT_LINE_ID = V_TRANSPORT_LINE_ID
                     AND T.SHIP_WAY = SHIP_WAY
                     AND T.SHIP_TYPE = SHIP_TYPE
                     AND T.LOAD_VEHICLE_TYPE = LOAD_VEHICLE_TYPE
                     AND T.VENDOR_ID = V_LG_VENDOR_INFO.VENDOR_ID
                     AND BEGIN_DATE <= SYSDATE
                     AND (END_DATE IS NULL OR
                         (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
                EXCEPTION
                  WHEN OTHERS THEN
                    NULL;
                END;
              ELSE
                V_LG_CONTRACT_LINE_ROW.FREIGHT := 0; --零担方式需要补充
              END IF;
              BEGIN
                --查询列表价格
                SELECT LIST_PRICE
                  INTO V_LIST_PRICE
                  FROM T_BD_PRICE_LINE
                 WHERE ITEM_CODE = V_LG_CONTRACT_LINE_ROW.ITEM_CODE
                   AND PRICE_LIST_ID = V_LG_INSURANCE_ROW.PRICE_LIST_ID;
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
              --计算保费 实发数量*列表价格*税率
              V_LG_CONTRACT_LINE_ROW.INSURANCE := ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                        V_LIST_PRICE *
                                                        V_LG_INSURANCE_ROW.INSURANCE_RATE / 100,
                                                        2);
              --计算投保金额（累加）
              V_LG_CONTRACT_ROW.RISK_AMOUNT                 := V_LG_CONTRACT_ROW.RISK_AMOUNT +
                                                               ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                                     V_LIST_PRICE,
                                                                     2);
              V_LG_CONTRACT_LINE_ROW.FACT_RECEIVE_QTY       := NULL;
              V_LG_CONTRACT_LINE_ROW.AFFIRM_QTY             := NULL;
              V_LG_CONTRACT_LINE_ROW.SHATTER_QTY            := 0;
              V_LG_CONTRACT_LINE_ROW.DIFF_QTY               := 0;
              V_LG_CONTRACT_LINE_ROW.MOULD_QTY              := 0;
              V_LG_CONTRACT_LINE_ROW.OUT_LINE_QTY           := 0;
              V_LG_CONTRACT_LINE_ROW.PACK_SHATTER_QTY       := 0;
              V_LG_CONTRACT_LINE_ROW.DIFF_REASON            := NULL;
              V_LG_CONTRACT_LINE_ROW.DAMAGE_CLAIMANT_AMOUNT := 0;
              V_LG_CONTRACT_LINE_ROW.BREAK_CLAIMANT_AMOUNT  := 0;

              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_TYPE     := C_SO_HEADER.Raw_Src_Type;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_DOC_CODE := C_SO_HEADER.Raw_Src_Bill_Type_Code;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_HEAD_ID  := C_SO_HEADER.Raw_Src_Bill_Id;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_LINE_ID  := C_SO_LINE.Raw_Src_Line_Id;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_TYPE            := nvl(C_SO_HEADER.Src_Type,C_SO_HEADER.Bill_Type_Code);
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_ID        := nvl(C_SO_HEADER.Src_Bill_Id,C_SO_HEADER.SO_HEADER_ID);
              V_LG_CONTRACT_LINE_ROW.ORIGIN_LINE_ID         := nvl(C_SO_LINE.Src_Line_Id,C_SO_LINE.SO_LINE_ID);
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_NUM       := nvl(C_SO_HEADER.SRC_BILL_NUM,C_SO_HEADER.So_Num);
              V_LG_CONTRACT_LINE_ROW.INVENTORY_CODE         := ''; --暂时保留
              V_LG_CONTRACT_LINE_ROW.INVENTORY_NAME         := ''; --暂时保留
              V_LG_CONTRACT_LINE_ROW.CREATED_BY             := 'LG';
              V_LG_CONTRACT_LINE_ROW.CREATION_DATE          := SYSDATE;
              V_LG_CONTRACT_LINE_ROW.LAST_UPDATED_BY        := 'LG';
              V_LG_CONTRACT_LINE_ROW.LAST_UPDATE_DATE       := SYSDATE;
              V_LG_CONTRACT_LINE_ROW.REMARK                 := NULL;

              FREIGHT := FREIGHT + V_LG_CONTRACT_LINE_ROW.Freight;
              INSURANCE := INSURANCE + V_LG_CONTRACT_LINE_ROW.INSURANCE;
              TOTAL_VOLUME := TOTAL_VOLUME + V_LG_CONTRACT_LINE_ROW.Unit_Volume;
              TOTAL_WEIGHT := TOTAL_WEIGHT + V_LG_CONTRACT_LINE_ROW.Unit_Weight;
              AMOUNT := AMOUNT + V_LG_CONTRACT_LINE_ROW.AMOUNT;

              V_LG_CONTRACT_LINE(V_LG_CONTRACT_LINE.COUNT + 1) := V_LG_CONTRACT_LINE_ROW;
            END LOOP;
          ELSE --2 散件
            --构建运输合同行
            V_LG_CONTRACT_LINE_ROW.CONTRACT_LINE_ID    := S_LG_CONTRACT_LINE.NEXTVAL;
            V_LG_CONTRACT_LINE_ROW.CONTRACT_ID         := V_LG_CONTRACT_ROW.CONTRACT_ID;
            V_LG_CONTRACT_LINE_ROW.SALES_MAIN_TYPE     := C_SO_HEADER.SALES_MAIN_TYPE;
            V_LG_CONTRACT_LINE_ROW.SALES_ORDER_TYPE_ID := C_SO_HEADER.Bill_Type_Id;
            V_LG_CONTRACT_LINE_ROW.SO_DOC_ID           := C_SO_HEADER.SO_HEADER_ID;
            V_LG_CONTRACT_LINE_ROW.SO_DOC_NUM          := C_SO_HEADER.SO_NUM;
            V_LG_CONTRACT_LINE_ROW.ITEM_CODE           := C_SO_LINE.Item_Code;
            V_LG_CONTRACT_LINE_ROW.ITEM_NAME           := C_SO_LINE.Item_Name;
            V_LG_CONTRACT_LINE_ROW.ITEM_UOM            := C_SO_LINE.Item_Uom;
            V_LG_CONTRACT_LINE_ROW.ITEM_PRICE          := C_SO_LINE.Item_Price;
            V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY       := C_SO_LINE.Item_Qty;

            V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME         := C_SO_LINE.ITEM_VOLUME;
            V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT         := C_SO_LINE.Item_Weight;
            V_LG_CONTRACT_LINE_ROW.AMOUNT              := V_LG_CONTRACT_LINE_ROW.ITEM_PRICE *
                                                          V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
            V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME        := V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME *
                                                          V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
            V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT        := V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT *
                                                          V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
            V_LG_CONTRACT_LINE_ROW.SET_FLAG            := C_SO_LINE.Item_Is_Set;
            V_LG_CONTRACT_LINE_ROW.SET_CODE            := NULL;
            --大电模式 只考虑整车情况
            IF (LOAD_VEHICLE_TYPE = '01') THEN
              BEGIN
                SELECT ROUND((CASE
                               WHEN PRICE_UNIT = '00' THEN --按照体积计算
                                UNIT_PRICE_OF_FREIGHT *
                                V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME
                               WHEN PRICE_UNIT = '01' THEN --按照重量计算
                                UNIT_PRICE_OF_FREIGHT *
                                V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT
                               ELSE
                                0
                             END),
                             2) +
                       V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES
                  INTO V_LG_CONTRACT_LINE_ROW.FREIGHT
                  FROM T_LG_LINE_FREIGHT_STANDARD T
                 WHERE T.TRANSPORT_LINE_ID = V_TRANSPORT_LINE_ID
                   AND T.SHIP_WAY = SHIP_WAY
                   AND T.SHIP_TYPE = SHIP_TYPE
                   AND T.LOAD_VEHICLE_TYPE = LOAD_VEHICLE_TYPE
                   AND T.VENDOR_ID = V_LG_VENDOR_INFO.VENDOR_ID
                   AND BEGIN_DATE <= SYSDATE
                   AND (END_DATE IS NULL OR
                       (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
            ELSE
              V_LG_CONTRACT_LINE_ROW.FREIGHT := 0; --零担方式需要补充
            END IF;
            BEGIN
              --查询列表价格
              SELECT LIST_PRICE
                INTO V_LIST_PRICE
                FROM T_BD_PRICE_LINE
               WHERE ITEM_CODE = V_LG_CONTRACT_LINE_ROW.ITEM_CODE
                 AND PRICE_LIST_ID = V_LG_INSURANCE_ROW.PRICE_LIST_ID;
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;
            --计算保费 列表价格*税率
            V_LG_CONTRACT_LINE_ROW.INSURANCE := ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                      V_LIST_PRICE *
                                                      V_LG_INSURANCE_ROW.INSURANCE_RATE / 100,
                                                      2);
            --计算投保金额（累加）
            V_LG_CONTRACT_ROW.RISK_AMOUNT                 := V_LG_CONTRACT_ROW.RISK_AMOUNT +
                                                             ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                                   V_LIST_PRICE,
                                                                   2);
            V_LG_CONTRACT_LINE_ROW.FACT_RECEIVE_QTY       := NULL;
            V_LG_CONTRACT_LINE_ROW.AFFIRM_QTY             := NULL;
            V_LG_CONTRACT_LINE_ROW.SHATTER_QTY            := 0;
            V_LG_CONTRACT_LINE_ROW.DIFF_QTY               := 0;
            V_LG_CONTRACT_LINE_ROW.MOULD_QTY              := 0;
            V_LG_CONTRACT_LINE_ROW.OUT_LINE_QTY           := 0;
            V_LG_CONTRACT_LINE_ROW.PACK_SHATTER_QTY       := 0;
            V_LG_CONTRACT_LINE_ROW.DIFF_REASON            := NULL;
            V_LG_CONTRACT_LINE_ROW.DAMAGE_CLAIMANT_AMOUNT := 0;
            V_LG_CONTRACT_LINE_ROW.BREAK_CLAIMANT_AMOUNT  := 0;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_TYPE     := C_SO_HEADER.Raw_Src_Type;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_DOC_CODE := C_SO_HEADER.Raw_Src_Bill_Type_Code;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_HEAD_ID  := C_SO_HEADER.Raw_Src_Bill_Id;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_LINE_ID  := C_SO_LINE.Raw_Src_Line_Id;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_TYPE            := nvl(C_SO_HEADER.Src_Type,C_SO_HEADER.Bill_Type_Code);
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_ID        := C_SO_HEADER.Src_Bill_Id;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_LINE_ID         := C_SO_LINE.Src_Line_Id;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_NUM       := nvl(C_SO_HEADER.SRC_BILL_NUM,C_SO_HEADER.So_Num);
            V_LG_CONTRACT_LINE_ROW.INVENTORY_CODE         := ''; --暂时保留
            V_LG_CONTRACT_LINE_ROW.INVENTORY_NAME         := ''; --暂时保留
            V_LG_CONTRACT_LINE_ROW.CREATED_BY             := 'LG';
            V_LG_CONTRACT_LINE_ROW.CREATION_DATE          := SYSDATE;
            V_LG_CONTRACT_LINE_ROW.LAST_UPDATED_BY        := 'LG';
            V_LG_CONTRACT_LINE_ROW.LAST_UPDATE_DATE       := SYSDATE;
            V_LG_CONTRACT_LINE_ROW.REMARK                 := NULL;

            FREIGHT := FREIGHT + V_LG_CONTRACT_LINE_ROW.Freight;
            INSURANCE := INSURANCE + V_LG_CONTRACT_LINE_ROW.INSURANCE;
            TOTAL_VOLUME := TOTAL_VOLUME + V_LG_CONTRACT_LINE_ROW.Unit_Volume;
            TOTAL_WEIGHT := TOTAL_WEIGHT + V_LG_CONTRACT_LINE_ROW.Unit_Weight;
            AMOUNT := AMOUNT + V_LG_CONTRACT_LINE_ROW.AMOUNT;

            V_LG_CONTRACT_LINE(V_LG_CONTRACT_LINE.COUNT + 1) := V_LG_CONTRACT_LINE_ROW;

          END IF;

        END LOOP;

      END LOOP;
    end loop;
    --更新合同头表费用信息
    V_LG_CONTRACT_ROW.FREIGHT := FREIGHT;
    V_LG_CONTRACT_ROW.ORIGIN_SHIP_CHARGES := FREIGHT;
    V_LG_CONTRACT_ROW.FREIGHT_NO_TAX := ROUND(V_LG_CONTRACT_ROW.FREIGHT / (1 + V_LG_CONTRACT_ROW.TAX_RATE / 100), 2);
    V_LG_CONTRACT_ROW.TAX_AMOUNT := V_LG_CONTRACT_ROW.FREIGHT - ROUND(V_LG_CONTRACT_ROW.FREIGHT / (1 + V_LG_CONTRACT_ROW.TAX_RATE / 100), 2);
    V_LG_CONTRACT_ROW.INSURANCE := INSURANCE;
    V_LG_CONTRACT_ROW.TOTAL_VOLUME := TOTAL_VOLUME;
    V_LG_CONTRACT_ROW.TOTAL_WEIGHT := TOTAL_WEIGHT;
    V_LG_CONTRACT_ROW.REG_CARRIAGE_FLAG := 'Y';
    V_LG_CONTRACT_ROW.REG_INSURANCE_FLAG := 'Y';

    BEGIN
      --插入排车信息表
      INSERT INTO T_LG_VEHICLE_INFO VALUES V_LG_VEHICLE_INFO_ROW;
      --插入运输合同头表
      INSERT INTO T_LG_CONTRACT VALUES V_LG_CONTRACT_ROW;
      --插入运输合同行表
      FOR I IN V_LG_CONTRACT_LINE.FIRST .. V_LG_CONTRACT_LINE.LAST LOOP
        INSERT INTO T_LG_CONTRACT_LINE VALUES V_LG_CONTRACT_LINE (I);
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '1007-1009-1010';
        O_RESULT_MSG := '生成排车信息-运输合同头-运输合同行失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
        ROLLBACK TO SAVEPOINT_KXMX ;
        RETURN;
    END;

    O_RESULT_MSG := O_RESULT_MSG || ',合同号：' || V_LG_CONTRACT_ROW.CONTRACT_CODE;
    --生成完运输合同提交，防止发送给A3取不到数据
    --COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '生成运输合同失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;





  -----------------------------------------------------------------------------
  --      调拨单生成运输合同                                             --
  -----------------------------------------------------------------------------
  PROCEDURE P_LG_CONTRACT_BY_TRSFNUM(TRSF_NUM IN VARCHAR2,
                                     TRSF_NUMS IN VARCHAR2,
                                     SHIP_WAY      IN VARCHAR2,
                                     SHIP_TYPE     IN VARCHAR2,
                                     LOAD_VEHICLE_TYPE IN VARCHAR2,
                                     VENDOR_CDE IN VARCHAR2,
                                     CONSIGNEE_LOCCDE IN VARCHAR2,--收货地址
                                     VEHICLE_NUM IN VARCHAR2,
                                     SHIP_DATE IN VARCHAR2,
                                     VEHICLE_BRAND_NUM IN VARCHAR2,
                                     CHAUFFEUR_TEL IN VARCHAR2,
                                     CHAUFFEUR_IDENTITY_NUM IN VARCHAR2,
                                     CHAUFFEUR IN VARCHAR2,
                                     CUSTOMER_CONTACTS IN VARCHAR2,
                                     CUSTOMER_CONTACTS_PHONES IN Varchar2,
                                     CONSIGNEE_COMPANY_ADDR IN VARCHAR2,
                                     O_RESULT      OUT VARCHAR2,
                                     O_RESULT_MSG  OUT VARCHAR2) IS

    V_LG_VEHICLE_INFO_ROW      T_LG_VEHICLE_INFO%ROWTYPE;
    V_LG_CONTRACT_ROW          T_LG_CONTRACT%ROWTYPE;
    V_LG_CONTRACT_LINE_ROW     T_LG_CONTRACT_LINE%ROWTYPE;
    --TYPE TYPE_LG_CONTRACT IS TABLE OF T_LG_CONTRACT%ROWTYPE INDEX BY BINARY_INTEGER;
    --V_LG_CONTRACT TYPE_LG_CONTRACT;
    TYPE TYPE_LG_CONTRACT_LINE IS TABLE OF T_LG_CONTRACT_LINE%ROWTYPE INDEX BY BINARY_INTEGER;
    V_LG_CONTRACT_LINE TYPE_LG_CONTRACT_LINE;

    V_INV_TRSF_ORDER           t_inv_trsf_order%ROWTYPE;--调拨头
    V_LG_VENDOR_INFO           T_LG_VENDOR_INFO_HEAD%ROWTYPE;--承运商
    V_LG_TRANSPORT_LINE        T_LG_TRANSPORT_LINE%ROWTYPE;--运输线路

    V_SHIP_TO_LOCATION_ID      T_BD_DISTRICT.ROW_ID%TYPE;--发货地点：行政区域
    CONSIGNEE_LOCATION_ID      T_BD_DISTRICT.ROW_ID%TYPE;--收货货地点：行政区域
    V_INV_ADD                  t_inv_inventories.inventory_address%TYPE;

    V_LG_LINE_FREIGHT_STANDARD T_LG_LINE_FREIGHT_STANDARD%ROWTYPE;--线路运费标准
    V_LG_INSURANCE_ROW         T_LG_INSURANCE%ROWTYPE;
    V_LIST_PRICE               T_BD_PRICE_LINE.LIST_PRICE%TYPE;
    V_TAX_RATE                 T_LG_CONTRACT.TAX_RATE%TYPE; --税率
    V_TRANSPORT_LINE_ID        T_LG_TRANSPORT_LINE.TRANSPORT_LINE_ID%TYPE; --运输线路ID
    SHIPTO_LOCCDE              T_LG_TRANSPORT_LINE.Ship_To_Location_Code%TYPE;

    FREIGHT                    T_LG_CONTRACT_LINE.Freight%TYPE;--运费
    INSURANCE                  T_LG_CONTRACT_LINE.Insurance%TYPE;--保险费
    TOTAL_VOLUME               T_LG_CONTRACT_LINE.UNIT_VOLUME%TYPE;--总体积
    TOTAL_WEIGHT               T_LG_CONTRACT_LINE.Unit_Weight%TYPE;--总重量
    AMOUNT                     T_LG_CONTRACT_LINE.Amount%TYPE;--金额

    var_tmp VARCHAR2(500) := TRSF_NUMS;
    var_split VARCHAR2(10) := ',';
    var_element varchar2(40) := '';
    var_count number := 0;

  BEGIN
    O_RESULT     := '1';
    O_RESULT_MSG := '生成成功';
    SAVEPOINT SAVEPOINT_KXMX ;

    /*初始化信息*/
    SELECT * INTO V_INV_TRSF_ORDER FROM T_INV_TRSF_ORDER WHERE TRSF_ORDER_NUM = TRSF_NUM;
    select * INTO V_LG_VENDOR_INFO from T_LG_VENDOR_INFO_HEAD WHERE VENDOR_CODE = VENDOR_CDE and rownum = 1;
    select inventory_address into V_INV_ADD from t_inv_inventories where inventory_code = V_INV_TRSF_ORDER.Consignee_Inv_Code and rownum=1;
    --获取线路/地点信息
    select t.district_code into SHIPTO_LOCCDE from t_inv_inventories r,t_bd_district t  where r.inventory_id = V_INV_TRSF_ORDER.Ship_Inv_Id and r.district_id = t.row_id and rownum=1;
    V_TRANSPORT_LINE_ID := PKG_LG_SHIP.F_GET_TRANSPORT_LINE_NEW(V_INV_TRSF_ORDER.ENTITY_ID,SHIPTO_LOCCDE,CONSIGNEE_LOCCDE,SHIP_WAY,SHIP_TYPE,LOAD_VEHICLE_TYPE);
    if V_TRANSPORT_LINE_ID = 0 then
       O_RESULT     := '0';
       O_RESULT_MSG := '生成运输合同失败:不存在运输线路！';
       RETURN;
    end if;

    select * INTO V_LG_TRANSPORT_LINE from T_LG_TRANSPORT_LINE where TRANSPORT_LINE_ID = V_TRANSPORT_LINE_ID;
    select ROW_ID into V_SHIP_TO_LOCATION_ID from T_BD_DISTRICT where DISTRICT_CODE = V_LG_TRANSPORT_LINE.Ship_To_Location_Code and rownum=1;
    select ROW_ID into CONSIGNEE_LOCATION_ID from T_BD_DISTRICT where DISTRICT_CODE = V_LG_TRANSPORT_LINE.Consignee_Location_Code and rownum=1;

    BEGIN
      --查询保险费价格列表ID和税率
      SELECT *
        INTO V_LG_INSURANCE_ROW
        FROM T_LG_INSURANCE
       WHERE ENTITY_ID = V_INV_TRSF_ORDER.ENTITY_ID
         AND TRANSPORT_WAY = SHIP_WAY
         AND BEGIN_DATE <= SYSDATE
         AND (END_DATE IS NULL OR
             (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    BEGIN
      --获取附加运费和计价单位
      SELECT T.EXTRA_SHIP_CHARGES, T.PRICE_UNIT
        INTO V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES,
             V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT
        FROM T_LG_LINE_FREIGHT_STANDARD T
       WHERE T.TRANSPORT_LINE_ID = V_TRANSPORT_LINE_ID
         AND T.SHIP_WAY = SHIP_WAY
         AND T.SHIP_TYPE = SHIP_TYPE
         AND T.LOAD_VEHICLE_TYPE = LOAD_VEHICLE_TYPE
         AND T.VENDOR_ID = V_LG_VENDOR_INFO.VENDOR_ID
         AND BEGIN_DATE <= SYSDATE
         AND (END_DATE IS NULL OR
             (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    --按照客户、营销中心、发运方式、收货地址、发货仓库

    --构建排车信息
    V_LG_VEHICLE_INFO_ROW.VEHICLE_INFO_ID        := S_LG_VEHICLE_INFO.NEXTVAL;
    V_LG_VEHICLE_INFO_ROW.ENTITY_ID              := V_INV_TRSF_ORDER.ENTITY_ID;
    V_LG_VEHICLE_INFO_ROW.VEHICLE_NUM            := VEHICLE_NUM;
    V_LG_VEHICLE_INFO_ROW.SHIP_DATE              := to_date(SHIP_DATE,'yyyy-MM-dd');
    V_LG_VEHICLE_INFO_ROW.VEHICLE_BRAND_NUM      := VEHICLE_BRAND_NUM;
    V_LG_VEHICLE_INFO_ROW.CHAUFFEUR_TEL          := CHAUFFEUR_TEL;
    V_LG_VEHICLE_INFO_ROW.CHAUFFEUR_IDENTITY_NUM := CHAUFFEUR_IDENTITY_NUM;
    V_LG_VEHICLE_INFO_ROW.CHAUFFEUR              := CHAUFFEUR;
    V_LG_VEHICLE_INFO_ROW.SEAL_NUM               := '';
    V_LG_VEHICLE_INFO_ROW.SEAL_DATE              := '';
    V_LG_VEHICLE_INFO_ROW.SEAL_BY                := '';
    V_LG_VEHICLE_INFO_ROW.SIGN_SEAL_NUM          := '';
    V_LG_VEHICLE_INFO_ROW.SIGN_SEAL_DATE         := '';
    V_LG_VEHICLE_INFO_ROW.SIGN_SEAL_BY           := '';
    V_LG_VEHICLE_INFO_ROW.SEAL_STATUS            := '';
    V_LG_VEHICLE_INFO_ROW.VENDOR_ID              := V_LG_VENDOR_INFO.VENDOR_ID;
    V_LG_VEHICLE_INFO_ROW.VENDOR_CODE            := V_LG_VENDOR_INFO.VENDOR_CODE;
    V_LG_VEHICLE_INFO_ROW.VENDOR_NAME            := V_LG_VENDOR_INFO.VENDOR_NAME;
    V_LG_VEHICLE_INFO_ROW.VENDOR_CONTACT         := '';
    V_LG_VEHICLE_INFO_ROW.VENDOR_TEL             := '';
    V_LG_VEHICLE_INFO_ROW.CREATED_BY             := 'LG';
    V_LG_VEHICLE_INFO_ROW.CREATION_DATE          := SYSDATE;
    V_LG_VEHICLE_INFO_ROW.LAST_UPDATED_BY        := 'LG';
    V_LG_VEHICLE_INFO_ROW.LAST_UPDATE_DATE       := SYSDATE;


    --构建运输合同头
    V_LG_CONTRACT_ROW.CONTRACT_ID                  := S_LG_CONTRACT.NEXTVAL;
    V_LG_CONTRACT_ROW.ENTITY_ID                    := V_INV_TRSF_ORDER.ENTITY_ID;
    V_LG_CONTRACT_ROW.CONTRACT_CODE                := PKG_BD.F_GET_BILL_NO(P_BILL_TYPE  => 'lgContractNo',
                                                                           P_PREFIX_ADD => NULL,
                                                                           P_ENTITY_ID  => V_INV_TRSF_ORDER.ENTITY_ID,
                                                                           P_USER_ID    => NULL);
    V_LG_CONTRACT_ROW.BILLS_STATUS                 := '00';
    V_LG_CONTRACT_ROW.VEHICLE_INFO_ID              := V_LG_VEHICLE_INFO_ROW.VEHICLE_INFO_ID;
    V_LG_CONTRACT_ROW.SALES_CENTER_ID              := V_INV_TRSF_ORDER.SALES_CENTER_ID;
    V_LG_CONTRACT_ROW.SHIP_WAY                     := SHIP_WAY;
    V_LG_CONTRACT_ROW.LOAD_VEHICLE_TYPE            := LOAD_VEHICLE_TYPE;
    V_LG_CONTRACT_ROW.SHIP_TYPE                    := SHIP_TYPE;
    V_LG_CONTRACT_ROW.CUSTOMER_ID                  := '';
    V_LG_CONTRACT_ROW.CUSTOMER_CODE                := '';
    V_LG_CONTRACT_ROW.CUSTOMER_NAME                := '';
    V_LG_CONTRACT_ROW.ACCOUNT_CODE                 := '';
    V_LG_CONTRACT_ROW.CUSTOMER_CONTACTS            := CUSTOMER_CONTACTS;
    V_LG_CONTRACT_ROW.CUSTOMER_CONTACTS_PHONES     := CUSTOMER_CONTACTS_PHONES;

    V_LG_CONTRACT_ROW.SHIP_TO_LOCATION_ID          := V_SHIP_TO_LOCATION_ID;
    V_LG_CONTRACT_ROW.SHIP_TO_LOCATION_CODE        := V_LG_TRANSPORT_LINE.SHIP_TO_LOCATION_CODE;
    V_LG_CONTRACT_ROW.SHIP_TO_LOCATION             := V_LG_TRANSPORT_LINE.Ship_To_Location_Name;
    V_LG_CONTRACT_ROW.SHIP_INVENTORY_ID            := V_INV_TRSF_ORDER.SHIP_INV_ID;
    V_LG_CONTRACT_ROW.SHIP_INVENTORY_CODE          := V_INV_TRSF_ORDER.SHIP_INV_CODE;
    V_LG_CONTRACT_ROW.SHIP_INVENTORY_NAME          := V_INV_TRSF_ORDER.SHIP_INV_NAME;
    V_LG_CONTRACT_ROW.CONSIGNEE_INVENTORY_ID       := V_INV_TRSF_ORDER.CONSIGNEE_INV_ID;
    V_LG_CONTRACT_ROW.CONSIGNEE_INVENTORY_CODE     := V_INV_TRSF_ORDER.CONSIGNEE_INV_CODE;
    V_LG_CONTRACT_ROW.CONSIGNEE_INVENTORY_NAME     := V_INV_TRSF_ORDER.CONSIGNEE_INV_NAME;
    V_LG_CONTRACT_ROW.CONSIGNEE_ADDR               := V_INV_ADD;
    V_LG_CONTRACT_ROW.CONSIGNEE_LOCATION_ID        := CONSIGNEE_LOCATION_ID;
    V_LG_CONTRACT_ROW.CONSIGNEE_LOCATION_CODE      := V_LG_TRANSPORT_LINE.Consignee_Location_Code;
    V_LG_CONTRACT_ROW.CONSIGNEE_LOCATION           := V_LG_TRANSPORT_LINE.Consignee_Location_Name;

    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_ID         := '';
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_CODE       := '';
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_NAME       := '';
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_ADDR       := CONSIGNEE_COMPANY_ADDR;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_CONTACT_ID := '';
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_CONTRACT   := CUSTOMER_CONTACTS;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_TEL        := CUSTOMER_CONTACTS_PHONES;
    V_LG_CONTRACT_ROW.IS_CUSG_FLAG                 := ''; --是否直发
    --获取经营单位名称
    BEGIN
/*      SELECT OPERATING_UNIT_NAME, OPERATING_UNIT
        INTO V_LG_CONTRACT_ROW.SHIP_COMPANY,V_LG_CONTRACT_ROW.OPERATING_UNIT
        FROM T_INV_ORGANIZATION
       WHERE ORGANIZATION_ID =
             (SELECT ORGANIZATION_ID
                FROM T_INV_INVENTORIES
               WHERE INVENTORY_ID = V_LG_CONTRACT_ROW.SHIP_INVENTORY_ID);*/
        --upate tusj 2015.9.25
     SELECT A.OPERATING_UNIT_NAME, A.OPERATING_UNIT
       INTO V_LG_CONTRACT_ROW.SHIP_COMPANY,V_LG_CONTRACT_ROW.OPERATING_UNIT
       FROM T_INV_ORGANIZATION A, T_INV_INVENTORIES B
      WHERE A.ORGANIZATION_ID = B.ORGANIZATION_ID
        AND A.ENTITY_ID = B.ENTITY_ID
        AND B.INVENTORY_ID = V_LG_CONTRACT_ROW.SHIP_INVENTORY_ID;
          --end tusj 2015.9.25
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '2001';
        O_RESULT_MSG := '经营单位信息不存在！';
        RETURN;
    END;
    V_LG_CONTRACT_ROW.REQUIRE_SHIP_DATE   := to_date(SHIP_DATE,'yyyy-MM-dd');
    V_LG_CONTRACT_ROW.FACT_SHIP_DATE      := to_date(SHIP_DATE,'yyyy-MM-dd');
    V_LG_CONTRACT_ROW.REQUIRE_ARRIVE_DATE := to_date(SHIP_DATE,'yyyy-MM-dd');
    V_LG_CONTRACT_ROW.FACT_ARRIVE_DATE    := NULL;
    V_LG_CONTRACT_ROW.DROP_SHIP_FLAG      := NULL;
    V_LG_CONTRACT_ROW.DISTANCE            := V_LG_TRANSPORT_LINE.DISTANCE;
    V_LG_CONTRACT_ROW.FREIGHT             := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.TAX_AMOUNT          := 0; --后面汇总计算

    --获取运费税率
    BEGIN
      SELECT TAX_RATE
        INTO V_TAX_RATE
        FROM T_LG_TAX_RATE_CONF
       WHERE CHARGES_TYPE_CODE = '00'
         AND DEFAULT_FLAG = 'Y';
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    V_LG_CONTRACT_ROW.TAX_RATE              := NVL(V_TAX_RATE, 0); --运费税率
    V_LG_CONTRACT_ROW.FREIGHT_NO_TAX        := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.ORIGIN_SHIP_CHARGES   := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.ADJUST_SHIP_CHARGES   := 0; --重新计算时填写
    V_LG_CONTRACT_ROW.FREIGHT_ADJUST_REASON := NULL;
    V_LG_CONTRACT_ROW.PRICE_UNIT            := V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT;
    V_LG_CONTRACT_ROW.TOTAL_VOLUME          := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.TOTAL_WEIGHT          := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.TOTAL_AMOUNT          := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.WEIGHT_UNIT           := 'KG'; --系统默认
    V_LG_CONTRACT_ROW.VOL_UNIT              := '方'; --系统默认
    V_LG_CONTRACT_ROW.PRINT_FLAG            := 'N';
    V_LG_CONTRACT_ROW.PRINT_TIMES           := 0;
    V_LG_CONTRACT_ROW.PRINT_DATE            := NULL;
    V_LG_CONTRACT_ROW.RECEIVE_FLAG          := 'N';
    V_LG_CONTRACT_ROW.RECEIVE_DATE          := NULL;
    V_LG_CONTRACT_ROW.RECEIVE_BY_NAME       := NULL;
    V_LG_CONTRACT_ROW.BACK_FLAG             := 'N';
    V_LG_CONTRACT_ROW.BACK_DATE             := NULL;
    V_LG_CONTRACT_ROW.LOCK_FLAG             := 'N';
    V_LG_CONTRACT_ROW.JUDGEMAR_CODE         := NULL;
    V_LG_CONTRACT_ROW.INSURANCE_FLAG        := 'Y'; --默认购买保险
    V_LG_CONTRACT_ROW.INSURACE_ID           := V_LG_INSURANCE_ROW.INSURER_ID; --命名不一致
    --获取保险商CODE和NAME
    BEGIN
      SELECT VENDOR_CODE, VENDOR_NAME
        INTO V_LG_CONTRACT_ROW.INSURACE_CODE,
             V_LG_CONTRACT_ROW.INSURACE_NAME
        FROM T_LG_VENDOR_INFO_HEAD
       WHERE VENDOR_ID = V_LG_CONTRACT_ROW.INSURACE_ID;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    V_LG_CONTRACT_ROW.RISK_AMOUNT            := 0; --投保金额
    V_LG_CONTRACT_ROW.INSURANCE              := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.COMPENSATION_AMOUNT    := NULL;
    V_LG_CONTRACT_ROW.COMPENSATION_REASON    := NULL;
    V_LG_CONTRACT_ROW.COMPENSATION_DATE      := NULL;
    V_LG_CONTRACT_ROW.CLAIM_VENDOR_CODE      := NULL;
    V_LG_CONTRACT_ROW.CLAIM_VENDOR_NAME      := NULL;
    V_LG_CONTRACT_ROW.BREAK_CLAIMANT_AMOUNT  := NULL;
    V_LG_CONTRACT_ROW.BREAK_CLAIMANT_REASON  := NULL;
    V_LG_CONTRACT_ROW.BREAK_CLAIMANT_DATE    := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_CLAIMANT_AMOUNT := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_CLAIMANT_REASON := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_CLAIMANT_DATE   := NULL;
    V_LG_CONTRACT_ROW.BREAK_CLAIM_DATE       := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_CLAIM_DATE      := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_INC_DEC_CODE    := NULL;
    V_LG_CONTRACT_ROW.BREAK_INC_DEC_CODE     := NULL;
    V_LG_CONTRACT_ROW.CONTRACT_TYPE          := '00';
    V_LG_CONTRACT_ROW.ORIGIN_CONTRACT_CODE   := NULL;
    V_LG_CONTRACT_ROW.FREIGHT_BATCH_FLAG     := NULL;
    V_LG_CONTRACT_ROW.INSUANCE_BATCH_FLAG    := NULL;
    V_LG_CONTRACT_ROW.FREIGHT_BATCH_NUM      := NULL;
    V_LG_CONTRACT_ROW.INSURANCE_BATCH_NUM    := NULL;
    V_LG_CONTRACT_ROW.SEND_FLAG              := NULL;
    V_LG_CONTRACT_ROW.VENDOR_FLAG            := NULL;
    V_LG_CONTRACT_ROW.VENDOR_ERROR_MESSAGE   := NULL;
    V_LG_CONTRACT_ROW.IMPORT_VENDOR_TIME     := NULL;
    V_LG_CONTRACT_ROW.CONTRACT_DATE          := SYSDATE;
    V_LG_CONTRACT_ROW.REG_CARRIAGE_FLAG      := 'N';
    V_LG_CONTRACT_ROW.REG_INSURANCE_FLAG     := 'N';
    V_LG_CONTRACT_ROW.PROMOTION_PRODUCT_VOL  := NULL; --暂时保留
    V_LG_CONTRACT_ROW.CREATED_BY             := 'LG';
    V_LG_CONTRACT_ROW.CREATION_DATE          := SYSDATE;
    V_LG_CONTRACT_ROW.LAST_UPDATED_BY        := 'LG';
    V_LG_CONTRACT_ROW.LAST_UPDATE_DATE       := SYSDATE;
    V_LG_CONTRACT_ROW.REMARK                 := NULL;

    --V_LG_CONTRACT(V_LG_CONTRACT.COUNT + 1) := V_LG_CONTRACT_ROW;

    --END IF;
    --遍历头表
    FREIGHT := 0;
    INSURANCE :=0;
    TOTAL_VOLUME :=0;
    TOTAL_WEIGHT :=0;
    AMOUNT :=0;

    while instr(var_tmp, var_split)>0 loop
       var_element := substr(var_tmp, 1, instr(var_tmp, var_split) - 1);
       var_tmp     := substr(var_tmp, instr(var_tmp, var_split) + length(var_split), length(var_tmp));
       --DBMS_OUTPUT.PUT_LINE(var_element);

      FOR C_INV_TRSF_ORDER IN (SELECT * FROM T_INV_TRSF_ORDER WHERE TRSF_ORDER_NUM = var_element) LOOP
        --遍历行明细表
        FOR C_INV_TRSF_ORDER_LINE IN (SELECT * FROM T_INV_TRSF_ORDER_LINE L WHERE L.TRSF_ORDER_ID = C_INV_TRSF_ORDER.TRSF_ORDER_ID) LOOP
          SELECT count(*) into var_count FROM T_INV_TRSF_ORDER_LINE_DETAIL WHERE trsf_order_line_id = C_INV_TRSF_ORDER_LINE.trsf_order_line_id;
          IF var_count > 1 THEN --1 套件
            --拆分套件到散件
            FOR C_INV_TRSF_ORDER_LINE_DETAIL IN (SELECT * FROM T_INV_TRSF_ORDER_LINE_DETAIL WHERE trsf_order_line_id = C_INV_TRSF_ORDER_LINE.trsf_order_line_id) LOOP
              --构建运输合同行
              V_LG_CONTRACT_LINE_ROW.CONTRACT_LINE_ID    := S_LG_CONTRACT_LINE.NEXTVAL;
              V_LG_CONTRACT_LINE_ROW.CONTRACT_ID         := V_LG_CONTRACT_ROW.CONTRACT_ID;
              V_LG_CONTRACT_LINE_ROW.SALES_MAIN_TYPE     := C_INV_TRSF_ORDER.SALES_MAIN_TYPE;
              V_LG_CONTRACT_LINE_ROW.SALES_ORDER_TYPE_ID := C_INV_TRSF_ORDER.Bill_Type_Id;
              V_LG_CONTRACT_LINE_ROW.SO_DOC_ID           := C_INV_TRSF_ORDER.TRSF_ORDER_ID;
              V_LG_CONTRACT_LINE_ROW.SO_DOC_NUM          := C_INV_TRSF_ORDER.Trsf_Order_Num;
              V_LG_CONTRACT_LINE_ROW.ITEM_CODE           := C_INV_TRSF_ORDER_LINE_DETAIL.Item_Code;
              V_LG_CONTRACT_LINE_ROW.ITEM_NAME           := C_INV_TRSF_ORDER_LINE_DETAIL.Item_Name;
              --查询产品单位、重量、体积
              SELECT DEFAULTUNIT, GROSSWEIGHT, PACKINGSIZE
                INTO V_LG_CONTRACT_LINE_ROW.ITEM_UOM,
                     V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT,
                     V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME
                FROM T_BD_ITEM
               WHERE ITEM_CODE = C_INV_TRSF_ORDER_LINE_DETAIL.Item_Code;
              V_LG_CONTRACT_LINE_ROW.ITEM_PRICE := 0;
              --实发数量 = 散件数量 * 产品数量
              V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY := C_INV_TRSF_ORDER_LINE_DETAIL.Billed_Qty;
              V_LG_CONTRACT_LINE_ROW.AMOUNT        := V_LG_CONTRACT_LINE_ROW.ITEM_PRICE *
                                                      V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
              V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME  := V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME *
                                                      V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
              V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT  := V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT *
                                                      V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
              V_LG_CONTRACT_LINE_ROW.SET_FLAG      := 'Y';
              V_LG_CONTRACT_LINE_ROW.SET_CODE      := C_INV_TRSF_ORDER_LINE.Item_Code;
              --大电模式 只考虑整车情况
              IF (LOAD_VEHICLE_TYPE = '01') THEN
                BEGIN
                  SELECT ROUND((CASE
                                 WHEN PRICE_UNIT = '00' THEN --按照体积计算
                                  UNIT_PRICE_OF_FREIGHT *
                                  V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME
                                 WHEN PRICE_UNIT = '01' THEN --按照重量计算
                                  UNIT_PRICE_OF_FREIGHT *
                                  V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT
                                 ELSE
                                  0
                               END),
                               2) +
                         V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES
                    INTO V_LG_CONTRACT_LINE_ROW.FREIGHT
                    FROM T_LG_LINE_FREIGHT_STANDARD T
                   WHERE T.TRANSPORT_LINE_ID = V_TRANSPORT_LINE_ID
                     AND T.SHIP_WAY = SHIP_WAY
                     AND T.SHIP_TYPE = SHIP_TYPE
                     AND T.LOAD_VEHICLE_TYPE = LOAD_VEHICLE_TYPE
                     AND T.VENDOR_ID = V_LG_VENDOR_INFO.VENDOR_ID
                     AND BEGIN_DATE <= SYSDATE
                     AND (END_DATE IS NULL OR
                         (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
                EXCEPTION
                  WHEN OTHERS THEN
                    NULL;
                END;
              ELSE
                V_LG_CONTRACT_LINE_ROW.FREIGHT := 0; --零担方式需要补充
              END IF;
              BEGIN
                --查询列表价格
                SELECT LIST_PRICE
                  INTO V_LIST_PRICE
                  FROM T_BD_PRICE_LINE
                 WHERE ITEM_CODE = V_LG_CONTRACT_LINE_ROW.ITEM_CODE
                   AND PRICE_LIST_ID = V_LG_INSURANCE_ROW.PRICE_LIST_ID;
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
              --计算保费 实发数量*列表价格*税率
              V_LG_CONTRACT_LINE_ROW.INSURANCE := ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                        V_LIST_PRICE *
                                                        V_LG_INSURANCE_ROW.INSURANCE_RATE / 100,
                                                        2);
              --计算投保金额（累加）
              V_LG_CONTRACT_ROW.RISK_AMOUNT                 := V_LG_CONTRACT_ROW.RISK_AMOUNT +
                                                               ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                                     V_LIST_PRICE,
                                                                     2);
              V_LG_CONTRACT_LINE_ROW.FACT_RECEIVE_QTY       := NULL;
              V_LG_CONTRACT_LINE_ROW.AFFIRM_QTY             := NULL;
              V_LG_CONTRACT_LINE_ROW.SHATTER_QTY            := 0;
              V_LG_CONTRACT_LINE_ROW.DIFF_QTY               := 0;
              V_LG_CONTRACT_LINE_ROW.MOULD_QTY              := 0;
              V_LG_CONTRACT_LINE_ROW.OUT_LINE_QTY           := 0;
              V_LG_CONTRACT_LINE_ROW.PACK_SHATTER_QTY       := 0;
              V_LG_CONTRACT_LINE_ROW.DIFF_REASON            := NULL;
              V_LG_CONTRACT_LINE_ROW.DAMAGE_CLAIMANT_AMOUNT := 0;
              V_LG_CONTRACT_LINE_ROW.BREAK_CLAIMANT_AMOUNT  := 0;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_TYPE     := '';
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_DOC_CODE := '';
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_HEAD_ID  := '';
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_LINE_ID  := '';
              V_LG_CONTRACT_LINE_ROW.ORIGIN_TYPE            := nvl(C_INV_TRSF_ORDER.Orig_Order_Type,C_INV_TRSF_ORDER.BILL_TYPE_ID);
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_ID        := nvl(C_INV_TRSF_ORDER.Orig_Order_Id,C_INV_TRSF_ORDER.trsf_order_id);
              V_LG_CONTRACT_LINE_ROW.ORIGIN_LINE_ID         := C_INV_TRSF_ORDER_LINE.Order_Line_Id_Orig;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_NUM       := nvl(C_INV_TRSF_ORDER.Orig_Order_Num,C_INV_TRSF_ORDER.Trsf_Order_Num);
              V_LG_CONTRACT_LINE_ROW.INVENTORY_CODE         := ''; --暂时保留
              V_LG_CONTRACT_LINE_ROW.INVENTORY_NAME         := ''; --暂时保留
              V_LG_CONTRACT_LINE_ROW.CREATED_BY             := 'LG';
              V_LG_CONTRACT_LINE_ROW.CREATION_DATE          := SYSDATE;
              V_LG_CONTRACT_LINE_ROW.LAST_UPDATED_BY        := 'LG';
              V_LG_CONTRACT_LINE_ROW.LAST_UPDATE_DATE       := SYSDATE;
              V_LG_CONTRACT_LINE_ROW.REMARK                 := NULL;

              FREIGHT := FREIGHT + V_LG_CONTRACT_LINE_ROW.Freight;
              INSURANCE := INSURANCE + V_LG_CONTRACT_LINE_ROW.INSURANCE;
              TOTAL_VOLUME := TOTAL_VOLUME + V_LG_CONTRACT_LINE_ROW.Unit_Volume;
              TOTAL_WEIGHT := TOTAL_WEIGHT + V_LG_CONTRACT_LINE_ROW.Unit_Weight;
              AMOUNT := AMOUNT + V_LG_CONTRACT_LINE_ROW.AMOUNT;

              V_LG_CONTRACT_LINE(V_LG_CONTRACT_LINE.COUNT + 1) := V_LG_CONTRACT_LINE_ROW;
            END LOOP;
          ELSE --2 散件
            --构建运输合同行
            V_LG_CONTRACT_LINE_ROW.CONTRACT_LINE_ID    := S_LG_CONTRACT_LINE.NEXTVAL;
            V_LG_CONTRACT_LINE_ROW.CONTRACT_ID         := V_LG_CONTRACT_ROW.CONTRACT_ID;
            V_LG_CONTRACT_LINE_ROW.SALES_MAIN_TYPE     := C_INV_TRSF_ORDER.SALES_MAIN_TYPE;
            V_LG_CONTRACT_LINE_ROW.SALES_ORDER_TYPE_ID := C_INV_TRSF_ORDER.Bill_Type_Id;
            V_LG_CONTRACT_LINE_ROW.SO_DOC_ID           := C_INV_TRSF_ORDER.Trsf_Order_Id;
            V_LG_CONTRACT_LINE_ROW.SO_DOC_NUM          := C_INV_TRSF_ORDER.Trsf_Order_Num;
            V_LG_CONTRACT_LINE_ROW.ITEM_CODE           := C_INV_TRSF_ORDER_LINE.Item_Code;
            V_LG_CONTRACT_LINE_ROW.ITEM_NAME           := C_INV_TRSF_ORDER_LINE.Item_Name;
            V_LG_CONTRACT_LINE_ROW.ITEM_UOM            := C_INV_TRSF_ORDER_LINE.Uom;
            V_LG_CONTRACT_LINE_ROW.ITEM_PRICE          := 0;
            V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY       := C_INV_TRSF_ORDER_LINE.Billed_Qty;

            --查询产品单位、重量、体积
            SELECT DEFAULTUNIT, GROSSWEIGHT, PACKINGSIZE
              INTO V_LG_CONTRACT_LINE_ROW.ITEM_UOM,
                   V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT,
                   V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME
              FROM T_BD_ITEM
             WHERE ITEM_CODE = V_LG_CONTRACT_LINE_ROW.Item_Code;

            V_LG_CONTRACT_LINE_ROW.AMOUNT              := V_LG_CONTRACT_LINE_ROW.ITEM_PRICE *
                                                          V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
            V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME        := V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME *
                                                          V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
            V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT        := V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT *
                                                          V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
            V_LG_CONTRACT_LINE_ROW.SET_FLAG            := '';
            V_LG_CONTRACT_LINE_ROW.SET_CODE            := NULL;
            --大电模式 只考虑整车情况
            IF (LOAD_VEHICLE_TYPE = '01') THEN
              BEGIN
                SELECT ROUND((CASE
                               WHEN PRICE_UNIT = '00' THEN --按照体积计算
                                UNIT_PRICE_OF_FREIGHT *
                                V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME
                               WHEN PRICE_UNIT = '01' THEN --按照重量计算
                                UNIT_PRICE_OF_FREIGHT *
                                V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT
                               ELSE
                                0
                             END),
                             2) +
                       V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES
                  INTO V_LG_CONTRACT_LINE_ROW.FREIGHT
                  FROM T_LG_LINE_FREIGHT_STANDARD T
                 WHERE T.TRANSPORT_LINE_ID = V_TRANSPORT_LINE_ID
                   AND T.SHIP_WAY = SHIP_WAY
                   AND T.SHIP_TYPE = SHIP_TYPE
                   AND T.LOAD_VEHICLE_TYPE = LOAD_VEHICLE_TYPE
                   AND T.VENDOR_ID = V_LG_VENDOR_INFO.VENDOR_ID
                   AND BEGIN_DATE <= SYSDATE
                   AND (END_DATE IS NULL OR
                       (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
            ELSE
              V_LG_CONTRACT_LINE_ROW.FREIGHT := 0; --零担方式需要补充
            END IF;
            BEGIN
              --查询列表价格
              SELECT LIST_PRICE
                INTO V_LIST_PRICE
                FROM T_BD_PRICE_LINE
               WHERE ITEM_CODE = V_LG_CONTRACT_LINE_ROW.ITEM_CODE
                 AND PRICE_LIST_ID = V_LG_INSURANCE_ROW.PRICE_LIST_ID;
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;
            --计算保费 列表价格*税率
            V_LG_CONTRACT_LINE_ROW.INSURANCE := ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                      V_LIST_PRICE *
                                                      V_LG_INSURANCE_ROW.INSURANCE_RATE / 100,
                                                      2);
            --计算投保金额（累加）
            V_LG_CONTRACT_ROW.RISK_AMOUNT                 := V_LG_CONTRACT_ROW.RISK_AMOUNT +
                                                             ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                                   V_LIST_PRICE,
                                                                   2);
            V_LG_CONTRACT_LINE_ROW.FACT_RECEIVE_QTY       := NULL;
            V_LG_CONTRACT_LINE_ROW.AFFIRM_QTY             := NULL;
            V_LG_CONTRACT_LINE_ROW.SHATTER_QTY            := 0;
            V_LG_CONTRACT_LINE_ROW.DIFF_QTY               := 0;
            V_LG_CONTRACT_LINE_ROW.MOULD_QTY              := 0;
            V_LG_CONTRACT_LINE_ROW.OUT_LINE_QTY           := 0;
            V_LG_CONTRACT_LINE_ROW.PACK_SHATTER_QTY       := 0;
            V_LG_CONTRACT_LINE_ROW.DIFF_REASON            := NULL;
            V_LG_CONTRACT_LINE_ROW.DAMAGE_CLAIMANT_AMOUNT := 0;
            V_LG_CONTRACT_LINE_ROW.BREAK_CLAIMANT_AMOUNT  := 0;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_TYPE     := '';
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_DOC_CODE := '';
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_HEAD_ID  := '';
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_LINE_ID  := '';
            V_LG_CONTRACT_LINE_ROW.ORIGIN_TYPE            := nvl(C_INV_TRSF_ORDER.Orig_Order_Type,C_INV_TRSF_ORDER.BILL_TYPE_ID);
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_ID        := nvl(C_INV_TRSF_ORDER.Orig_Order_Id,C_INV_TRSF_ORDER.trsf_order_id);
            V_LG_CONTRACT_LINE_ROW.ORIGIN_LINE_ID         := C_INV_TRSF_ORDER_LINE.Order_Line_Id_Orig;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_NUM       := nvl(C_INV_TRSF_ORDER.Orig_Order_Num,C_INV_TRSF_ORDER.Trsf_Order_Num);
            V_LG_CONTRACT_LINE_ROW.INVENTORY_CODE         := ''; --暂时保留
            V_LG_CONTRACT_LINE_ROW.INVENTORY_NAME         := ''; --暂时保留
            V_LG_CONTRACT_LINE_ROW.CREATED_BY             := 'LG';
            V_LG_CONTRACT_LINE_ROW.CREATION_DATE          := SYSDATE;
            V_LG_CONTRACT_LINE_ROW.LAST_UPDATED_BY        := 'LG';
            V_LG_CONTRACT_LINE_ROW.LAST_UPDATE_DATE       := SYSDATE;
            V_LG_CONTRACT_LINE_ROW.REMARK                 := NULL;

            FREIGHT := FREIGHT + V_LG_CONTRACT_LINE_ROW.Freight;
            INSURANCE := INSURANCE + V_LG_CONTRACT_LINE_ROW.INSURANCE;
            TOTAL_VOLUME := TOTAL_VOLUME + V_LG_CONTRACT_LINE_ROW.Unit_Volume;
            TOTAL_WEIGHT := TOTAL_WEIGHT + V_LG_CONTRACT_LINE_ROW.Unit_Weight;
            AMOUNT := AMOUNT + V_LG_CONTRACT_LINE_ROW.AMOUNT;

            V_LG_CONTRACT_LINE(V_LG_CONTRACT_LINE.COUNT + 1) := V_LG_CONTRACT_LINE_ROW;

          END IF;

        END LOOP;

      END LOOP;
    end loop;
    --更新合同头表费用信息
    V_LG_CONTRACT_ROW.FREIGHT := FREIGHT;
    V_LG_CONTRACT_ROW.ORIGIN_SHIP_CHARGES := FREIGHT;
    V_LG_CONTRACT_ROW.FREIGHT_NO_TAX := ROUND(V_LG_CONTRACT_ROW.FREIGHT / (1 + V_LG_CONTRACT_ROW.TAX_RATE / 100), 2);
    V_LG_CONTRACT_ROW.TAX_AMOUNT := V_LG_CONTRACT_ROW.FREIGHT - ROUND(V_LG_CONTRACT_ROW.FREIGHT / (1 + V_LG_CONTRACT_ROW.TAX_RATE / 100), 2);
    V_LG_CONTRACT_ROW.INSURANCE := INSURANCE;
    V_LG_CONTRACT_ROW.TOTAL_VOLUME := TOTAL_VOLUME;
    V_LG_CONTRACT_ROW.TOTAL_WEIGHT := TOTAL_WEIGHT;
    V_LG_CONTRACT_ROW.REG_CARRIAGE_FLAG := 'Y';
    V_LG_CONTRACT_ROW.REG_INSURANCE_FLAG := 'Y';

    BEGIN
      --插入排车信息表
      INSERT INTO T_LG_VEHICLE_INFO VALUES V_LG_VEHICLE_INFO_ROW;
      --插入运输合同头表
      INSERT INTO T_LG_CONTRACT VALUES V_LG_CONTRACT_ROW;
      --插入运输合同行表
      FOR I IN V_LG_CONTRACT_LINE.FIRST .. V_LG_CONTRACT_LINE.LAST LOOP
        INSERT INTO T_LG_CONTRACT_LINE VALUES V_LG_CONTRACT_LINE (I);
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '1007-1009-1010';
        O_RESULT_MSG := '生成排车信息-运输合同头-运输合同行失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
        ROLLBACK TO SAVEPOINT_KXMX ;
        RETURN;
    END;

    O_RESULT_MSG := O_RESULT_MSG || ',合同号：' || V_LG_CONTRACT_ROW.CONTRACT_CODE;

    --生成完运输合同提交，防止发送给A3取不到数据
    --COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '生成运输合同失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;


  -----------------------------------------------------------------------------
  --      获取线路的承运商                                             --
  -----------------------------------------------------------------------------
  PROCEDURE P_LG_CONTRACT_GET_VENDOR(NUM                      IN VARCHAR2,
                                     TYP                      IN VARCHAR2,
                                     CONSIGNEE_LOCCDE         IN VARCHAR2,
                                     O_RESULT                 OUT VARCHAR2,
                                     O_RESULT_MSG             OUT VARCHAR2) IS

   V_TRANSPORT_LINE_ID        T_LG_TRANSPORT_LINE.TRANSPORT_LINE_ID%TYPE; --运输线路ID
   SHIPTO_LOCCDE              T_LG_TRANSPORT_LINE.Ship_To_Location_Code%TYPE;
   ENTITY                     T_INV_TRSF_ORDER.Entity_Id%TYPE;
   SHIPINV_ID                 T_INV_TRSF_ORDER.Ship_Inv_Id%TYPE;

  BEGIN
    O_RESULT     := '1';
    O_RESULT_MSG := 'OK';

    --销售单
    IF TYP = 0 THEN
      SELECT ENTITY_ID,SHIP_INV_ID INTO ENTITY,SHIPINV_ID FROM T_SO_HEADER WHERE SO_NUM = NUM;
    ELSE
      SELECT ENTITY_ID,SHIP_INV_ID INTO ENTITY,SHIPINV_ID FROM T_INV_TRSF_ORDER WHERE TRSF_ORDER_NUM = NUM;
    END IF;

    SELECT t.district_code into SHIPTO_LOCCDE FROM t_inv_inventories r,t_bd_district t WHERE r.inventory_id = SHIPINV_ID and r.district_id = t.row_id and rownum=1;
    V_TRANSPORT_LINE_ID := PKG_LG_SHIP.F_GET_TRANSPORT_LINE(ENTITY,SHIPTO_LOCCDE,CONSIGNEE_LOCCDE);

    --根据线路获取承运商信息
    SELECT T2.VENDOR_CODE||'-_-'||T2.VENDOR_NAME into O_RESULT_MSG FROM T_LG_LINE_FREIGHT_STANDARD T1,T_LG_VENDOR_INFO_HEAD T2 WHERE t1.transport_line_id = V_TRANSPORT_LINE_ID and T1.VENDOR_ID = T2.VENDOR_ID(+) and rownum=1;

  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '获取失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;

  -----------------------------------------------------------------------------
  --      销售单生成运输合同2                                             --
  -----------------------------------------------------------------------------
  PROCEDURE P_LG_CONTRACT_BY_INVNUM2(INV_NUM                  IN VARCHAR2,
                                     INV_NUMS                 IN VARCHAR2,
                                     VENDOR_CDE               IN VARCHAR2,
                                     VEHICLE_NUM              IN VARCHAR2,
                                     VEHICLE_BRAND_NUM        IN VARCHAR2,
                                     CHAUFFEUR_TEL            IN VARCHAR2,
                                     CHAUFFEUR_IDENTITY_NUM   IN VARCHAR2,
                                     CHAUFFEUR                IN VARCHAR2,
                                     O_RESULT                 OUT VARCHAR2,
                                     O_RESULT_MSG             OUT VARCHAR2) IS

    V_LG_VEHICLE_INFO_ROW      T_LG_VEHICLE_INFO%ROWTYPE;
    V_LG_CONTRACT_ROW          T_LG_CONTRACT%ROWTYPE;
    V_LG_CONTRACT_LINE_ROW     T_LG_CONTRACT_LINE%ROWTYPE;
    TYPE TYPE_LG_CONTRACT_LINE IS TABLE OF T_LG_CONTRACT_LINE%ROWTYPE INDEX BY BINARY_INTEGER;
    V_LG_CONTRACT_LINE TYPE_LG_CONTRACT_LINE;

    V_SO_HEAHER                T_SO_HEADER%ROWTYPE;--销头
    V_LG_SHIP_DOC              T_LG_SHIP_DOC%ROWTYPE;--发货通知单
    V_LG_VENDOR_INFO           T_LG_VENDOR_INFO_HEAD%ROWTYPE;--承运商

    V_LG_LINE_FREIGHT_STANDARD T_LG_LINE_FREIGHT_STANDARD%ROWTYPE;--线路运费标准
    V_LG_INSURANCE_ROW         T_LG_INSURANCE%ROWTYPE;
    V_LIST_PRICE               T_BD_PRICE_LINE.LIST_PRICE%TYPE;
    V_TAX_RATE                 T_LG_CONTRACT.TAX_RATE%TYPE; --税率
    V_TRANSPORT_LINE_ID        T_LG_TRANSPORT_LINE.TRANSPORT_LINE_ID%TYPE; --运输线路ID

    FREIGHT                    T_LG_CONTRACT_LINE.Freight%TYPE;--运费
    INSURANCE                  T_LG_CONTRACT_LINE.Insurance%TYPE;--保险费
    TOTAL_VOLUME               T_LG_CONTRACT_LINE.UNIT_VOLUME%TYPE;--总体积
    TOTAL_WEIGHT               T_LG_CONTRACT_LINE.Unit_Weight%TYPE;--总重量
    AMOUNT                     T_LG_CONTRACT_LINE.Amount%TYPE;--金额

    var_tmp VARCHAR2(500) := INV_NUMS;
    var_split VARCHAR2(10) := ',';
    var_element varchar2(40) := '';

  BEGIN
    O_RESULT     := '1';
    O_RESULT_MSG := '生成成功';
    SAVEPOINT SAVEPOINT_KXMX ;

    /*初始化信息*/
    SELECT * INTO V_SO_HEAHER FROM T_SO_HEADER WHERE SO_NUM = INV_NUM;
    SELECT * INTO V_LG_SHIP_DOC FROM T_LG_SHIP_DOC T WHERE T.SHIP_DOC_ID = V_SO_HEAHER.Ship_Doc_Id;
    select * INTO V_LG_VENDOR_INFO from T_LG_VENDOR_INFO_HEAD WHERE ENTITY_ID = V_LG_SHIP_DOC.ENTITY_ID and VENDOR_CODE = VENDOR_CDE and rownum = 1;
    --获取线路/地点信息
    V_TRANSPORT_LINE_ID := PKG_LG_SHIP.F_GET_TRANSPORT_LINE_NEW(V_LG_SHIP_DOC.ENTITY_ID,V_LG_SHIP_DOC.SHIP_TO_LOCATION_CODE,V_LG_SHIP_DOC.CONSIGNEE_LOCATION_CODE,V_LG_SHIP_DOC.SHIP_WAY,V_LG_SHIP_DOC.SHIP_TYPE,V_LG_SHIP_DOC.LOAD_VEHICLE_TYPE);

    BEGIN
      --查询保险费价格列表ID和税率
      SELECT *
        INTO V_LG_INSURANCE_ROW
        FROM T_LG_INSURANCE
       WHERE ENTITY_ID = V_LG_SHIP_DOC.ENTITY_ID
         AND TRANSPORT_WAY = V_LG_SHIP_DOC.SHIP_WAY
         AND BEGIN_DATE <= SYSDATE
         AND (END_DATE IS NULL OR
             (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    BEGIN
      --获取附加运费和计价单位
      SELECT T.EXTRA_SHIP_CHARGES, T.PRICE_UNIT
        INTO V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES,
             V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT
        FROM T_LG_LINE_FREIGHT_STANDARD T
       WHERE T.TRANSPORT_LINE_ID = V_TRANSPORT_LINE_ID
         AND T.SHIP_WAY = V_LG_SHIP_DOC.SHIP_WAY
         AND T.SHIP_TYPE = V_LG_SHIP_DOC.SHIP_TYPE
         AND T.LOAD_VEHICLE_TYPE = V_LG_SHIP_DOC.LOAD_VEHICLE_TYPE
         AND T.VENDOR_ID =V_LG_VENDOR_INFO.VENDOR_ID
         AND BEGIN_DATE <= SYSDATE
         AND (END_DATE IS NULL OR
             (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
    EXCEPTION
      WHEN OTHERS THEN
        SELECT 0, 0
        INTO V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES,
             V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT
        FROM dual T;
    END;

    --按照客户、营销中心、发运方式、收货地址、发货仓库

    --构建排车信息
    V_LG_VEHICLE_INFO_ROW.VEHICLE_INFO_ID        := S_LG_VEHICLE_INFO.NEXTVAL;
    V_LG_VEHICLE_INFO_ROW.ENTITY_ID              := V_LG_SHIP_DOC.ENTITY_ID;
    V_LG_VEHICLE_INFO_ROW.VEHICLE_NUM            := VEHICLE_NUM;
    V_LG_VEHICLE_INFO_ROW.SHIP_DATE              := V_LG_SHIP_DOC.DOC_DATE;
    V_LG_VEHICLE_INFO_ROW.VEHICLE_BRAND_NUM      := VEHICLE_BRAND_NUM;
    V_LG_VEHICLE_INFO_ROW.CHAUFFEUR_TEL          := CHAUFFEUR_TEL;
    V_LG_VEHICLE_INFO_ROW.CHAUFFEUR_IDENTITY_NUM := CHAUFFEUR_IDENTITY_NUM;
    V_LG_VEHICLE_INFO_ROW.CHAUFFEUR              := CHAUFFEUR;
    V_LG_VEHICLE_INFO_ROW.SEAL_NUM               := '';
    V_LG_VEHICLE_INFO_ROW.SEAL_DATE              := '';
    V_LG_VEHICLE_INFO_ROW.SEAL_BY                := '';
    V_LG_VEHICLE_INFO_ROW.SIGN_SEAL_NUM          := '';
    V_LG_VEHICLE_INFO_ROW.SIGN_SEAL_DATE         := '';
    V_LG_VEHICLE_INFO_ROW.SIGN_SEAL_BY           := '';
    V_LG_VEHICLE_INFO_ROW.SEAL_STATUS            := '';
    V_LG_VEHICLE_INFO_ROW.VENDOR_ID              := V_LG_VENDOR_INFO.VENDOR_ID;
    V_LG_VEHICLE_INFO_ROW.VENDOR_CODE            := V_LG_VENDOR_INFO.VENDOR_CODE;
    V_LG_VEHICLE_INFO_ROW.VENDOR_NAME            := V_LG_VENDOR_INFO.VENDOR_NAME;
    V_LG_VEHICLE_INFO_ROW.VENDOR_CONTACT         := '';
    V_LG_VEHICLE_INFO_ROW.VENDOR_TEL             := '';
    V_LG_VEHICLE_INFO_ROW.CREATED_BY             := 'LG';
    V_LG_VEHICLE_INFO_ROW.CREATION_DATE          := SYSDATE;
    V_LG_VEHICLE_INFO_ROW.LAST_UPDATED_BY        := 'LG';
    V_LG_VEHICLE_INFO_ROW.LAST_UPDATE_DATE       := SYSDATE;


    --构建运输合同头
    V_LG_CONTRACT_ROW.CONTRACT_ID                  := S_LG_CONTRACT.NEXTVAL;
    V_LG_CONTRACT_ROW.ENTITY_ID                    := V_SO_HEAHER.ENTITY_ID;
    V_LG_CONTRACT_ROW.CONTRACT_CODE                := PKG_BD.F_GET_BILL_NO(P_BILL_TYPE  => 'lgContractNo',
                                                                           P_PREFIX_ADD => NULL,
                                                                           P_ENTITY_ID  => V_SO_HEAHER.ENTITY_ID,
                                                                           P_USER_ID    => NULL);
    V_LG_CONTRACT_ROW.BILLS_STATUS                 := '00';
    V_LG_CONTRACT_ROW.VEHICLE_INFO_ID              := V_LG_VEHICLE_INFO_ROW.VEHICLE_INFO_ID;
    V_LG_CONTRACT_ROW.SALES_CENTER_ID              := V_SO_HEAHER.SALES_CENTER_ID;
    V_LG_CONTRACT_ROW.SHIP_WAY                     := V_LG_SHIP_DOC.SHIP_WAY;
    V_LG_CONTRACT_ROW.LOAD_VEHICLE_TYPE            := V_LG_SHIP_DOC.LOAD_VEHICLE_TYPE;
    V_LG_CONTRACT_ROW.SHIP_TYPE                    := V_LG_SHIP_DOC.SHIP_TYPE;
    V_LG_CONTRACT_ROW.CUSTOMER_ID                  := V_LG_SHIP_DOC.CUSTOMER_ID;
    V_LG_CONTRACT_ROW.CUSTOMER_CODE                := V_LG_SHIP_DOC.CUSTOMER_CODE;
    V_LG_CONTRACT_ROW.CUSTOMER_NAME                := V_LG_SHIP_DOC.CUSTOMER_NAME;
    V_LG_CONTRACT_ROW.ACCOUNT_CODE                 := V_LG_SHIP_DOC.ACCOUNT_CODE;
    V_LG_CONTRACT_ROW.CUSTOMER_CONTACTS            := V_LG_SHIP_DOC.Customer_Contacts;
    V_LG_CONTRACT_ROW.CUSTOMER_CONTACTS_PHONES     := V_LG_SHIP_DOC.Customer_Contacts_Phones;

    V_LG_CONTRACT_ROW.SHIP_TO_LOCATION_ID          := V_LG_SHIP_DOC.Ship_To_Location_Id;
    V_LG_CONTRACT_ROW.SHIP_TO_LOCATION_CODE        := V_LG_SHIP_DOC.SHIP_TO_LOCATION_CODE;
    V_LG_CONTRACT_ROW.SHIP_TO_LOCATION             := V_LG_SHIP_DOC.Ship_To_Location;
    V_LG_CONTRACT_ROW.SHIP_INVENTORY_ID            := V_LG_SHIP_DOC.Ship_Inventory_Id;
    V_LG_CONTRACT_ROW.SHIP_INVENTORY_CODE          := V_LG_SHIP_DOC.SHIP_Inventory_CODE;
    V_LG_CONTRACT_ROW.SHIP_INVENTORY_NAME          := V_LG_SHIP_DOC.SHIP_Inventory_NAME;
    V_LG_CONTRACT_ROW.CONSIGNEE_INVENTORY_ID       := V_LG_SHIP_DOC.CONSIGNEE_Inventory_ID;
    V_LG_CONTRACT_ROW.CONSIGNEE_INVENTORY_CODE     := V_LG_SHIP_DOC.CONSIGNEE_Inventory_CODE;
    V_LG_CONTRACT_ROW.CONSIGNEE_INVENTORY_NAME     := V_LG_SHIP_DOC.CONSIGNEE_Inventory_NAME;
    V_LG_CONTRACT_ROW.CONSIGNEE_ADDR               := V_LG_SHIP_DOC.CONSIGNEE_ADDR;
    V_LG_CONTRACT_ROW.CONSIGNEE_LOCATION_ID        := V_LG_SHIP_DOC.Consignee_Location_Id;
    V_LG_CONTRACT_ROW.CONSIGNEE_LOCATION_CODE      := V_LG_SHIP_DOC.Consignee_Location_Code;
    V_LG_CONTRACT_ROW.CONSIGNEE_LOCATION           := V_LG_SHIP_DOC.Consignee_Location;

    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_ID         := V_LG_SHIP_DOC.CUSTOMER_ID;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_CODE       := V_LG_SHIP_DOC.CUSTOMER_CODE;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_NAME       := V_LG_SHIP_DOC.CUSTOMER_NAME;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_ADDR       := V_LG_SHIP_DOC.Consignee_Addr;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_CONTACT_ID := V_LG_SHIP_DOC.Consignee_Company_Id;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_CONTRACT   := V_LG_SHIP_DOC.Consignee_Company_Contract;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_TEL        := V_LG_SHIP_DOC.Consignee_Company_Tel;
    V_LG_CONTRACT_ROW.IS_CUSG_FLAG                 := V_LG_SHIP_DOC.Is_Cusg_Flag; --是否直发
    --获取经营单位名称
    BEGIN
      SELECT A.OPERATING_UNIT_NAME, A.OPERATING_UNIT
       INTO V_LG_CONTRACT_ROW.SHIP_COMPANY,V_LG_CONTRACT_ROW.OPERATING_UNIT
       FROM T_INV_ORGANIZATION A, T_INV_INVENTORIES B
      WHERE A.ORGANIZATION_ID = B.ORGANIZATION_ID
        AND A.ENTITY_ID = B.ENTITY_ID
        AND B.INVENTORY_ID = V_LG_CONTRACT_ROW.SHIP_INVENTORY_ID;
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '2001';
        O_RESULT_MSG := '经营单位信息不存在！';
        RETURN;
    END;
    V_LG_CONTRACT_ROW.REQUIRE_SHIP_DATE   := V_LG_SHIP_DOC.Require_Ship_Date;
    V_LG_CONTRACT_ROW.FACT_SHIP_DATE      := V_LG_SHIP_DOC.Doc_Date;
    V_LG_CONTRACT_ROW.REQUIRE_ARRIVE_DATE := V_LG_SHIP_DOC.Require_Arrive_Date;
    V_LG_CONTRACT_ROW.FACT_ARRIVE_DATE    := NULL;
    V_LG_CONTRACT_ROW.DROP_SHIP_FLAG      := NULL;
    V_LG_CONTRACT_ROW.DISTANCE            := V_LG_SHIP_DOC.Distance;
    V_LG_CONTRACT_ROW.FREIGHT             := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.TAX_AMOUNT          := 0; --后面汇总计算

    --获取运费税率
    BEGIN
      SELECT TAX_RATE
        INTO V_TAX_RATE
        FROM T_LG_TAX_RATE_CONF
       WHERE CHARGES_TYPE_CODE = '00'
         AND DEFAULT_FLAG = 'Y';
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    V_LG_CONTRACT_ROW.TAX_RATE              := NVL(V_TAX_RATE, 0); --运费税率
    V_LG_CONTRACT_ROW.FREIGHT_NO_TAX        := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.ORIGIN_SHIP_CHARGES   := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.ADJUST_SHIP_CHARGES   := 0; --重新计算时填写
    V_LG_CONTRACT_ROW.FREIGHT_ADJUST_REASON := NULL;
    V_LG_CONTRACT_ROW.PRICE_UNIT            := V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT;
    V_LG_CONTRACT_ROW.TOTAL_VOLUME          := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.TOTAL_WEIGHT          := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.TOTAL_AMOUNT          := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.WEIGHT_UNIT           := 'KG'; --系统默认
    V_LG_CONTRACT_ROW.VOL_UNIT              := '方'; --系统默认
    V_LG_CONTRACT_ROW.PRINT_FLAG            := 'N';
    V_LG_CONTRACT_ROW.PRINT_TIMES           := 0;
    V_LG_CONTRACT_ROW.PRINT_DATE            := NULL;
    V_LG_CONTRACT_ROW.RECEIVE_FLAG          := 'N';
    V_LG_CONTRACT_ROW.RECEIVE_DATE          := NULL;
    V_LG_CONTRACT_ROW.RECEIVE_BY_NAME       := NULL;
    V_LG_CONTRACT_ROW.BACK_FLAG             := 'N';
    V_LG_CONTRACT_ROW.BACK_DATE             := NULL;
    V_LG_CONTRACT_ROW.LOCK_FLAG             := 'N';
    V_LG_CONTRACT_ROW.JUDGEMAR_CODE         := NULL;
    V_LG_CONTRACT_ROW.INSURANCE_FLAG        := 'Y'; --默认购买保险
    V_LG_CONTRACT_ROW.INSURACE_ID           := V_LG_INSURANCE_ROW.INSURER_ID; --命名不一致
    --获取保险商CODE和NAME
    BEGIN
      SELECT VENDOR_CODE, VENDOR_NAME
        INTO V_LG_CONTRACT_ROW.INSURACE_CODE,
             V_LG_CONTRACT_ROW.INSURACE_NAME
        FROM T_LG_VENDOR_INFO_HEAD
       WHERE VENDOR_ID = V_LG_CONTRACT_ROW.INSURACE_ID;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    V_LG_CONTRACT_ROW.RISK_AMOUNT            := 0; --投保金额
    V_LG_CONTRACT_ROW.INSURANCE              := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.COMPENSATION_AMOUNT    := NULL;
    V_LG_CONTRACT_ROW.COMPENSATION_REASON    := NULL;
    V_LG_CONTRACT_ROW.COMPENSATION_DATE      := NULL;
    V_LG_CONTRACT_ROW.CLAIM_VENDOR_CODE      := NULL;
    V_LG_CONTRACT_ROW.CLAIM_VENDOR_NAME      := NULL;
    V_LG_CONTRACT_ROW.BREAK_CLAIMANT_AMOUNT  := NULL;
    V_LG_CONTRACT_ROW.BREAK_CLAIMANT_REASON  := NULL;
    V_LG_CONTRACT_ROW.BREAK_CLAIMANT_DATE    := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_CLAIMANT_AMOUNT := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_CLAIMANT_REASON := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_CLAIMANT_DATE   := NULL;
    V_LG_CONTRACT_ROW.BREAK_CLAIM_DATE       := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_CLAIM_DATE      := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_INC_DEC_CODE    := NULL;
    V_LG_CONTRACT_ROW.BREAK_INC_DEC_CODE     := NULL;
    V_LG_CONTRACT_ROW.CONTRACT_TYPE          := '00';
    V_LG_CONTRACT_ROW.ORIGIN_CONTRACT_CODE   := NULL;
    V_LG_CONTRACT_ROW.FREIGHT_BATCH_FLAG     := NULL;
    V_LG_CONTRACT_ROW.INSUANCE_BATCH_FLAG    := NULL;
    V_LG_CONTRACT_ROW.FREIGHT_BATCH_NUM      := NULL;
    V_LG_CONTRACT_ROW.INSURANCE_BATCH_NUM    := NULL;
    V_LG_CONTRACT_ROW.SEND_FLAG              := NULL;
    V_LG_CONTRACT_ROW.VENDOR_FLAG            := NULL;
    V_LG_CONTRACT_ROW.VENDOR_ERROR_MESSAGE   := NULL;
    V_LG_CONTRACT_ROW.IMPORT_VENDOR_TIME     := NULL;
    V_LG_CONTRACT_ROW.CONTRACT_DATE          := SYSDATE;
    V_LG_CONTRACT_ROW.REG_CARRIAGE_FLAG      := 'N';
    V_LG_CONTRACT_ROW.REG_INSURANCE_FLAG     := 'N';
    V_LG_CONTRACT_ROW.PROMOTION_PRODUCT_VOL  := NULL; --暂时保留
    V_LG_CONTRACT_ROW.CREATED_BY             := 'LG';
    V_LG_CONTRACT_ROW.CREATION_DATE          := SYSDATE;
    V_LG_CONTRACT_ROW.LAST_UPDATED_BY        := 'LG';
    V_LG_CONTRACT_ROW.LAST_UPDATE_DATE       := SYSDATE;
    V_LG_CONTRACT_ROW.REMARK                 := NULL;

    --V_LG_CONTRACT(V_LG_CONTRACT.COUNT + 1) := V_LG_CONTRACT_ROW;

    --END IF;
    --遍历头表
    FREIGHT := 0;
    INSURANCE :=0;
    TOTAL_VOLUME :=0;
    TOTAL_WEIGHT :=0;
    AMOUNT :=0;

    while instr(var_tmp, var_split)>0 loop
       var_element := substr(var_tmp, 1, instr(var_tmp, var_split) - 1);
       var_tmp     := substr(var_tmp, instr(var_tmp, var_split) + length(var_split), length(var_tmp));
       --DBMS_OUTPUT.PUT_LINE(var_element);

      FOR C_SO_HEADER IN (SELECT * FROM T_SO_HEADER WHERE SO_NUM = var_element) LOOP
        --遍历行明细表
        FOR C_SO_LINE IN (SELECT * FROM T_SO_LINE L WHERE L.SO_HEADER_ID = C_SO_HEADER.SO_HEADER_ID) LOOP

          IF C_SO_LINE.ITEM_IS_SET = 'Y' THEN --1 套件
            --拆分套件到散件
            FOR C_SO_LINE_DETAIL IN (SELECT * FROM T_SO_LINE_DETAIL WHERE SO_LINE_ID = C_SO_LINE.SO_LINE_ID) LOOP
              --构建运输合同行
              V_LG_CONTRACT_LINE_ROW.CONTRACT_LINE_ID    := S_LG_CONTRACT_LINE.NEXTVAL;
              V_LG_CONTRACT_LINE_ROW.CONTRACT_ID         := V_LG_CONTRACT_ROW.CONTRACT_ID;
              V_LG_CONTRACT_LINE_ROW.SALES_MAIN_TYPE     := C_SO_HEADER.SALES_MAIN_TYPE;
              V_LG_CONTRACT_LINE_ROW.SALES_ORDER_TYPE_ID := C_SO_HEADER.Bill_Type_Id;
              V_LG_CONTRACT_LINE_ROW.SO_DOC_ID           := C_SO_HEADER.SO_HEADER_ID;
              V_LG_CONTRACT_LINE_ROW.SO_DOC_NUM          := C_SO_HEADER.SO_NUM;
              V_LG_CONTRACT_LINE_ROW.ITEM_CODE           := C_SO_LINE_DETAIL.Component_Code;
              V_LG_CONTRACT_LINE_ROW.ITEM_NAME           := C_SO_LINE_DETAIL.Component_Name;
              --查询产品单位、重量、体积
              SELECT DEFAULTUNIT, GROSSWEIGHT, PACKINGSIZE
                INTO V_LG_CONTRACT_LINE_ROW.ITEM_UOM,
                     V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT,
                     V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME
                FROM T_BD_ITEM
               WHERE ITEM_CODE = C_SO_LINE_DETAIL.Component_Code;
              V_LG_CONTRACT_LINE_ROW.ITEM_PRICE := C_SO_LINE.ITEM_PRICE; --在基础模块获取（熊培良确认）
              --实发数量 = 散件数量 * 产品数量
              V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY := C_SO_LINE_DETAIL.Component_Qty;
              V_LG_CONTRACT_LINE_ROW.AMOUNT        := V_LG_CONTRACT_LINE_ROW.ITEM_PRICE *
                                                      V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
              V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME  := V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME *
                                                      V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
              V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT  := V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT *
                                                      V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
              V_LG_CONTRACT_LINE_ROW.SET_FLAG      := C_SO_LINE.Item_Is_Set;
              V_LG_CONTRACT_LINE_ROW.SET_CODE      := C_SO_LINE.Item_Code;
              --大电模式 只考虑整车情况
              IF (V_LG_SHIP_DOC.LOAD_VEHICLE_TYPE = '01') THEN
                BEGIN
                  SELECT ROUND((CASE
                                 WHEN PRICE_UNIT = '00' THEN --按照体积计算
                                  UNIT_PRICE_OF_FREIGHT *
                                  V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME
                                 WHEN PRICE_UNIT = '01' THEN --按照重量计算
                                  UNIT_PRICE_OF_FREIGHT *
                                  V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT
                                 ELSE
                                  0
                               END),
                               2) +
                         V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES
                    INTO V_LG_CONTRACT_LINE_ROW.FREIGHT
                    FROM T_LG_LINE_FREIGHT_STANDARD T
                   WHERE T.TRANSPORT_LINE_ID = V_TRANSPORT_LINE_ID
                     AND T.SHIP_WAY = V_LG_SHIP_DOC.SHIP_WAY
                     AND T.SHIP_TYPE = V_LG_SHIP_DOC.SHIP_TYPE
                     AND T.LOAD_VEHICLE_TYPE = V_LG_SHIP_DOC.LOAD_VEHICLE_TYPE
                     AND T.VENDOR_ID = V_LG_VENDOR_INFO.VENDOR_ID
                     AND BEGIN_DATE <= SYSDATE
                     AND (END_DATE IS NULL OR
                         (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
                EXCEPTION
                  WHEN OTHERS THEN
                    NULL;
                END;
              ELSE
                V_LG_CONTRACT_LINE_ROW.FREIGHT := 0; --零担方式需要补充
              END IF;
              BEGIN
                --查询列表价格
                SELECT LIST_PRICE
                  INTO V_LIST_PRICE
                  FROM T_BD_PRICE_LINE
                 WHERE ITEM_CODE = V_LG_CONTRACT_LINE_ROW.ITEM_CODE
                   AND PRICE_LIST_ID = V_LG_INSURANCE_ROW.PRICE_LIST_ID;
              EXCEPTION
                WHEN OTHERS THEN
                  V_LIST_PRICE := 0;
                  NULL;
              END;
              --计算保费 实发数量*列表价格*税率
              V_LG_CONTRACT_LINE_ROW.INSURANCE := ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                        V_LIST_PRICE *
                                                        V_LG_INSURANCE_ROW.INSURANCE_RATE / 100,
                                                        2);
              --计算投保金额（累加）
              V_LG_CONTRACT_ROW.RISK_AMOUNT                 := V_LG_CONTRACT_ROW.RISK_AMOUNT +
                                                               ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                                     V_LIST_PRICE,
                                                                     2);
              V_LG_CONTRACT_LINE_ROW.FACT_RECEIVE_QTY       := NULL;
              V_LG_CONTRACT_LINE_ROW.AFFIRM_QTY             := NULL;
              V_LG_CONTRACT_LINE_ROW.SHATTER_QTY            := 0;
              V_LG_CONTRACT_LINE_ROW.DIFF_QTY               := 0;
              V_LG_CONTRACT_LINE_ROW.MOULD_QTY              := 0;
              V_LG_CONTRACT_LINE_ROW.OUT_LINE_QTY           := 0;
              V_LG_CONTRACT_LINE_ROW.PACK_SHATTER_QTY       := 0;
              V_LG_CONTRACT_LINE_ROW.DIFF_REASON            := NULL;
              V_LG_CONTRACT_LINE_ROW.DAMAGE_CLAIMANT_AMOUNT := 0;
              V_LG_CONTRACT_LINE_ROW.BREAK_CLAIMANT_AMOUNT  := 0;

              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_TYPE     := C_SO_HEADER.Raw_Src_Type;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_DOC_CODE := C_SO_HEADER.Raw_Src_Bill_Type_Code;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_HEAD_ID  := C_SO_HEADER.Raw_Src_Bill_Id;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_LINE_ID  := C_SO_LINE.Raw_Src_Line_Id;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_TYPE            := nvl(C_SO_HEADER.Src_Type,C_SO_HEADER.Bill_Type_Code);
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_ID        := nvl(C_SO_HEADER.Src_Bill_Id,C_SO_HEADER.SO_HEADER_ID);
              V_LG_CONTRACT_LINE_ROW.ORIGIN_LINE_ID         := nvl(C_SO_LINE.Src_Line_Id,C_SO_LINE.SO_LINE_ID);
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_NUM       := nvl(C_SO_HEADER.SRC_BILL_NUM,C_SO_HEADER.So_Num);
              V_LG_CONTRACT_LINE_ROW.INVENTORY_CODE         := ''; --暂时保留
              V_LG_CONTRACT_LINE_ROW.INVENTORY_NAME         := ''; --暂时保留
              V_LG_CONTRACT_LINE_ROW.CREATED_BY             := 'LG';
              V_LG_CONTRACT_LINE_ROW.CREATION_DATE          := SYSDATE;
              V_LG_CONTRACT_LINE_ROW.LAST_UPDATED_BY        := 'LG';
              V_LG_CONTRACT_LINE_ROW.LAST_UPDATE_DATE       := SYSDATE;
              V_LG_CONTRACT_LINE_ROW.REMARK                 := NULL;

              FREIGHT := FREIGHT + V_LG_CONTRACT_LINE_ROW.Freight;
              INSURANCE := INSURANCE + V_LG_CONTRACT_LINE_ROW.INSURANCE;
              TOTAL_VOLUME := TOTAL_VOLUME + V_LG_CONTRACT_LINE_ROW.Unit_Volume;
              TOTAL_WEIGHT := TOTAL_WEIGHT + V_LG_CONTRACT_LINE_ROW.Unit_Weight;
              AMOUNT := AMOUNT + V_LG_CONTRACT_LINE_ROW.AMOUNT;

              V_LG_CONTRACT_LINE(V_LG_CONTRACT_LINE.COUNT + 1) := V_LG_CONTRACT_LINE_ROW;
            END LOOP;
          ELSE --2 散件
            --构建运输合同行
            V_LG_CONTRACT_LINE_ROW.CONTRACT_LINE_ID    := S_LG_CONTRACT_LINE.NEXTVAL;
            V_LG_CONTRACT_LINE_ROW.CONTRACT_ID         := V_LG_CONTRACT_ROW.CONTRACT_ID;
            V_LG_CONTRACT_LINE_ROW.SALES_MAIN_TYPE     := C_SO_HEADER.SALES_MAIN_TYPE;
            V_LG_CONTRACT_LINE_ROW.SALES_ORDER_TYPE_ID := C_SO_HEADER.Bill_Type_Id;
            V_LG_CONTRACT_LINE_ROW.SO_DOC_ID           := C_SO_HEADER.SO_HEADER_ID;
            V_LG_CONTRACT_LINE_ROW.SO_DOC_NUM          := C_SO_HEADER.SO_NUM;
            V_LG_CONTRACT_LINE_ROW.ITEM_CODE           := C_SO_LINE.Item_Code;
            V_LG_CONTRACT_LINE_ROW.ITEM_NAME           := C_SO_LINE.Item_Name;
            V_LG_CONTRACT_LINE_ROW.ITEM_UOM            := C_SO_LINE.Item_Uom;
            V_LG_CONTRACT_LINE_ROW.ITEM_PRICE          := C_SO_LINE.Item_Price;
            V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY       := C_SO_LINE.Item_Qty;

            V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME         := C_SO_LINE.ITEM_VOLUME;
            V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT         := C_SO_LINE.Item_Weight;
            V_LG_CONTRACT_LINE_ROW.AMOUNT              := V_LG_CONTRACT_LINE_ROW.ITEM_PRICE *
                                                          V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
            V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME        := V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME *
                                                          V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
            V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT        := V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT *
                                                          V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
            V_LG_CONTRACT_LINE_ROW.SET_FLAG            := C_SO_LINE.Item_Is_Set;
            V_LG_CONTRACT_LINE_ROW.SET_CODE            := NULL;
            --大电模式 只考虑整车情况
            IF (V_LG_SHIP_DOC.LOAD_VEHICLE_TYPE = '01') THEN
              BEGIN
                SELECT ROUND((CASE
                               WHEN PRICE_UNIT = '00' THEN --按照体积计算
                                UNIT_PRICE_OF_FREIGHT *
                                V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME
                               WHEN PRICE_UNIT = '01' THEN --按照重量计算
                                UNIT_PRICE_OF_FREIGHT *
                                V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT
                               ELSE
                                0
                             END),
                             2) +
                       V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES
                  INTO V_LG_CONTRACT_LINE_ROW.FREIGHT
                  FROM T_LG_LINE_FREIGHT_STANDARD T
                 WHERE T.TRANSPORT_LINE_ID = V_TRANSPORT_LINE_ID
                   AND T.SHIP_WAY = V_LG_SHIP_DOC.SHIP_WAY
                   AND T.SHIP_TYPE = V_LG_SHIP_DOC.SHIP_TYPE
                   AND T.LOAD_VEHICLE_TYPE = V_LG_SHIP_DOC.LOAD_VEHICLE_TYPE
                   AND T.VENDOR_ID = V_LG_VENDOR_INFO.VENDOR_ID
                   AND BEGIN_DATE <= SYSDATE
                   AND (END_DATE IS NULL OR
                       (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
            ELSE
              V_LG_CONTRACT_LINE_ROW.FREIGHT := 0; --零担方式需要补充
            END IF;
            BEGIN
              --查询列表价格
              SELECT LIST_PRICE
                INTO V_LIST_PRICE
                FROM T_BD_PRICE_LINE
               WHERE ITEM_CODE = V_LG_CONTRACT_LINE_ROW.ITEM_CODE
                 AND PRICE_LIST_ID = V_LG_INSURANCE_ROW.PRICE_LIST_ID;
            EXCEPTION
              WHEN OTHERS THEN
                V_LIST_PRICE := 0;
                --O_RESULT     := '2001';
                --O_RESULT_MSG := '获取产品价格列表信息不存在！';
                --RETURN;
            END;
            --计算保费 列表价格*税率
            V_LG_CONTRACT_LINE_ROW.INSURANCE := ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                      V_LIST_PRICE *
                                                      V_LG_INSURANCE_ROW.INSURANCE_RATE / 100,
                                                      2);
            --计算投保金额（累加）
            V_LG_CONTRACT_ROW.RISK_AMOUNT                 := V_LG_CONTRACT_ROW.RISK_AMOUNT +
                                                             ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                                   V_LIST_PRICE,
                                                                   2);
            V_LG_CONTRACT_LINE_ROW.FACT_RECEIVE_QTY       := NULL;
            V_LG_CONTRACT_LINE_ROW.AFFIRM_QTY             := NULL;
            V_LG_CONTRACT_LINE_ROW.SHATTER_QTY            := 0;
            V_LG_CONTRACT_LINE_ROW.DIFF_QTY               := 0;
            V_LG_CONTRACT_LINE_ROW.MOULD_QTY              := 0;
            V_LG_CONTRACT_LINE_ROW.OUT_LINE_QTY           := 0;
            V_LG_CONTRACT_LINE_ROW.PACK_SHATTER_QTY       := 0;
            V_LG_CONTRACT_LINE_ROW.DIFF_REASON            := NULL;
            V_LG_CONTRACT_LINE_ROW.DAMAGE_CLAIMANT_AMOUNT := 0;
            V_LG_CONTRACT_LINE_ROW.BREAK_CLAIMANT_AMOUNT  := 0;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_TYPE     := C_SO_HEADER.Raw_Src_Type;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_DOC_CODE := C_SO_HEADER.Raw_Src_Bill_Type_Code;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_HEAD_ID  := C_SO_HEADER.Raw_Src_Bill_Id;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_LINE_ID  := C_SO_LINE.Raw_Src_Line_Id;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_TYPE            := nvl(C_SO_HEADER.Src_Type,C_SO_HEADER.Bill_Type_Code);
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_ID        := C_SO_HEADER.Src_Bill_Id;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_LINE_ID         := C_SO_LINE.Src_Line_Id;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_NUM       := nvl(C_SO_HEADER.SRC_BILL_NUM,C_SO_HEADER.So_Num);
            V_LG_CONTRACT_LINE_ROW.INVENTORY_CODE         := ''; --暂时保留
            V_LG_CONTRACT_LINE_ROW.INVENTORY_NAME         := ''; --暂时保留
            V_LG_CONTRACT_LINE_ROW.CREATED_BY             := 'LG';
            V_LG_CONTRACT_LINE_ROW.CREATION_DATE          := SYSDATE;
            V_LG_CONTRACT_LINE_ROW.LAST_UPDATED_BY        := 'LG';
            V_LG_CONTRACT_LINE_ROW.LAST_UPDATE_DATE       := SYSDATE;
            V_LG_CONTRACT_LINE_ROW.REMARK                 := NULL;

            FREIGHT := FREIGHT + V_LG_CONTRACT_LINE_ROW.Freight;
            INSURANCE := INSURANCE + V_LG_CONTRACT_LINE_ROW.INSURANCE;
            TOTAL_VOLUME := TOTAL_VOLUME + V_LG_CONTRACT_LINE_ROW.Unit_Volume;
            TOTAL_WEIGHT := TOTAL_WEIGHT + V_LG_CONTRACT_LINE_ROW.Unit_Weight;
            AMOUNT := AMOUNT + V_LG_CONTRACT_LINE_ROW.AMOUNT;

            V_LG_CONTRACT_LINE(V_LG_CONTRACT_LINE.COUNT + 1) := V_LG_CONTRACT_LINE_ROW;

          END IF;

        END LOOP;

      END LOOP;
    end loop;
    --更新合同头表费用信息
    V_LG_CONTRACT_ROW.FREIGHT := FREIGHT;
    V_LG_CONTRACT_ROW.ORIGIN_SHIP_CHARGES := FREIGHT;
    V_LG_CONTRACT_ROW.FREIGHT_NO_TAX := ROUND(V_LG_CONTRACT_ROW.FREIGHT / (1 + V_LG_CONTRACT_ROW.TAX_RATE / 100), 2);
    V_LG_CONTRACT_ROW.TAX_AMOUNT := V_LG_CONTRACT_ROW.FREIGHT - ROUND(V_LG_CONTRACT_ROW.FREIGHT / (1 + V_LG_CONTRACT_ROW.TAX_RATE / 100), 2);
    V_LG_CONTRACT_ROW.INSURANCE := INSURANCE;
    V_LG_CONTRACT_ROW.TOTAL_VOLUME := TOTAL_VOLUME;
    V_LG_CONTRACT_ROW.TOTAL_WEIGHT := TOTAL_WEIGHT;
    V_LG_CONTRACT_ROW.REG_CARRIAGE_FLAG := 'Y';
    V_LG_CONTRACT_ROW.REG_INSURANCE_FLAG := 'Y';

    BEGIN
      --插入排车信息表
      INSERT INTO T_LG_VEHICLE_INFO VALUES V_LG_VEHICLE_INFO_ROW;
      --插入运输合同头表
      INSERT INTO T_LG_CONTRACT VALUES V_LG_CONTRACT_ROW;
      --插入运输合同行表
      FOR I IN V_LG_CONTRACT_LINE.FIRST .. V_LG_CONTRACT_LINE.LAST LOOP
        INSERT INTO T_LG_CONTRACT_LINE VALUES V_LG_CONTRACT_LINE (I);
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '1007-1009-1010';
        O_RESULT_MSG := '生成排车信息-运输合同头-运输合同行失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
        ROLLBACK TO SAVEPOINT_KXMX ;
        RETURN;
    END;

    O_RESULT_MSG := O_RESULT_MSG || ',合同号：' || V_LG_CONTRACT_ROW.CONTRACT_CODE;
    --生成完运输合同提交，防止发送给A3取不到数据
    --COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '生成运输合同失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;

   -----------------------------------------------------------------------------
  --      调拨单生成运输合同                                             --
  -----------------------------------------------------------------------------
  PROCEDURE P_LG_CONTRACT_BY_TRSFNUM2(TRSF_NUM                 IN VARCHAR2,
                                      TRSF_NUMS                IN VARCHAR2,
                                      VENDOR_CDE               IN VARCHAR2,
                                      VEHICLE_NUM              IN VARCHAR2,
                                      VEHICLE_BRAND_NUM        IN VARCHAR2,
                                      CHAUFFEUR_TEL            IN VARCHAR2,
                                      CHAUFFEUR_IDENTITY_NUM   IN VARCHAR2,
                                      CHAUFFEUR                IN VARCHAR2,
                                      O_RESULT                 OUT VARCHAR2,
                                      O_RESULT_MSG             OUT VARCHAR2) IS

    V_LG_VEHICLE_INFO_ROW      T_LG_VEHICLE_INFO%ROWTYPE;
    V_LG_CONTRACT_ROW          T_LG_CONTRACT%ROWTYPE;
    V_LG_CONTRACT_LINE_ROW     T_LG_CONTRACT_LINE%ROWTYPE;

    TYPE TYPE_LG_CONTRACT_LINE IS TABLE OF T_LG_CONTRACT_LINE%ROWTYPE INDEX BY BINARY_INTEGER;
    V_LG_CONTRACT_LINE TYPE_LG_CONTRACT_LINE;

    V_INV_TRSF_ORDER           t_inv_trsf_order%ROWTYPE;--调拨头
    V_LG_SHIP_DOC              T_LG_SHIP_DOC%ROWTYPE;--发货通知单
    V_LG_VENDOR_INFO           T_LG_VENDOR_INFO_HEAD%ROWTYPE;--承运商

    V_LG_LINE_FREIGHT_STANDARD T_LG_LINE_FREIGHT_STANDARD%ROWTYPE;--线路运费标准
    V_LG_INSURANCE_ROW         T_LG_INSURANCE%ROWTYPE;
    V_LIST_PRICE               T_BD_PRICE_LINE.LIST_PRICE%TYPE;
    V_TAX_RATE                 T_LG_CONTRACT.TAX_RATE%TYPE; --税率
    V_TRANSPORT_LINE_ID        T_LG_TRANSPORT_LINE.TRANSPORT_LINE_ID%TYPE; --运输线路ID

    FREIGHT                    T_LG_CONTRACT_LINE.Freight%TYPE;--运费
    INSURANCE                  T_LG_CONTRACT_LINE.Insurance%TYPE;--保险费
    TOTAL_VOLUME               T_LG_CONTRACT_LINE.UNIT_VOLUME%TYPE;--总体积
    TOTAL_WEIGHT               T_LG_CONTRACT_LINE.Unit_Weight%TYPE;--总重量
    AMOUNT                     T_LG_CONTRACT_LINE.Amount%TYPE;--金额

    var_tmp VARCHAR2(500) := TRSF_NUMS;
    var_split VARCHAR2(10) := ',';
    var_element varchar2(40) := '';
    var_count number := 0;

  BEGIN
    O_RESULT     := '1';
    O_RESULT_MSG := '生成成功';
    SAVEPOINT SAVEPOINT_KXMX ;

    /*初始化信息*/
    SELECT * INTO V_INV_TRSF_ORDER FROM T_INV_TRSF_ORDER WHERE TRSF_ORDER_NUM = TRSF_NUM;
    select * INTO V_LG_SHIP_DOC from T_LG_SHIP_DOC t where t.vehicle_num = V_INV_TRSF_ORDER.Vehicle_Num;
    select * INTO V_LG_VENDOR_INFO from T_LG_VENDOR_INFO_HEAD WHERE ENTITY_ID = V_LG_SHIP_DOC.ENTITY_ID and VENDOR_CODE = VENDOR_CDE and rownum = 1;

    --获取线路/地点信息
    V_TRANSPORT_LINE_ID := PKG_LG_SHIP.F_GET_TRANSPORT_LINE_NEW(V_LG_SHIP_DOC.ENTITY_ID,V_LG_SHIP_DOC.SHIP_TO_LOCATION_CODE,V_LG_SHIP_DOC.CONSIGNEE_LOCATION_CODE,V_LG_SHIP_DOC.SHIP_WAY,V_LG_SHIP_DOC.SHIP_TYPE,V_LG_SHIP_DOC.LOAD_VEHICLE_TYPE);

    BEGIN
      --查询保险费价格列表ID和税率
      SELECT *
        INTO V_LG_INSURANCE_ROW
        FROM T_LG_INSURANCE
       WHERE ENTITY_ID = V_INV_TRSF_ORDER.ENTITY_ID
         AND TRANSPORT_WAY = V_LG_SHIP_DOC.SHIP_WAY
         AND BEGIN_DATE <= SYSDATE
         AND (END_DATE IS NULL OR
             (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    BEGIN
      --获取附加运费和计价单位
      SELECT T.EXTRA_SHIP_CHARGES, T.PRICE_UNIT
        INTO V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES,
             V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT
        FROM T_LG_LINE_FREIGHT_STANDARD T
       WHERE T.TRANSPORT_LINE_ID = V_TRANSPORT_LINE_ID
         AND T.SHIP_WAY = V_LG_SHIP_DOC.SHIP_WAY
         AND T.SHIP_TYPE = V_LG_SHIP_DOC.SHIP_TYPE
         AND T.LOAD_VEHICLE_TYPE = V_LG_SHIP_DOC.LOAD_VEHICLE_TYPE
         AND T.VENDOR_ID = V_LG_VENDOR_INFO.VENDOR_ID
         AND BEGIN_DATE <= SYSDATE
         AND (END_DATE IS NULL OR
             (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
    EXCEPTION
      WHEN OTHERS THEN
        SELECT 0, 0
        INTO V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES,
             V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT
        FROM dual T;
    END;

    --按照客户、营销中心、发运方式、收货地址、发货仓库

    --构建排车信息
    V_LG_VEHICLE_INFO_ROW.VEHICLE_INFO_ID        := S_LG_VEHICLE_INFO.NEXTVAL;
    V_LG_VEHICLE_INFO_ROW.ENTITY_ID              := V_LG_SHIP_DOC.ENTITY_ID;
    V_LG_VEHICLE_INFO_ROW.VEHICLE_NUM            := VEHICLE_NUM;
    V_LG_VEHICLE_INFO_ROW.SHIP_DATE              := V_LG_SHIP_DOC.Doc_Date;
    V_LG_VEHICLE_INFO_ROW.VEHICLE_BRAND_NUM      := VEHICLE_BRAND_NUM;
    V_LG_VEHICLE_INFO_ROW.CHAUFFEUR_TEL          := CHAUFFEUR_TEL;
    V_LG_VEHICLE_INFO_ROW.CHAUFFEUR_IDENTITY_NUM := CHAUFFEUR_IDENTITY_NUM;
    V_LG_VEHICLE_INFO_ROW.CHAUFFEUR              := CHAUFFEUR;
    V_LG_VEHICLE_INFO_ROW.SEAL_NUM               := '';
    V_LG_VEHICLE_INFO_ROW.SEAL_DATE              := '';
    V_LG_VEHICLE_INFO_ROW.SEAL_BY                := '';
    V_LG_VEHICLE_INFO_ROW.SIGN_SEAL_NUM          := '';
    V_LG_VEHICLE_INFO_ROW.SIGN_SEAL_DATE         := '';
    V_LG_VEHICLE_INFO_ROW.SIGN_SEAL_BY           := '';
    V_LG_VEHICLE_INFO_ROW.SEAL_STATUS            := '';
    V_LG_VEHICLE_INFO_ROW.VENDOR_ID              := V_LG_VENDOR_INFO.VENDOR_ID;
    V_LG_VEHICLE_INFO_ROW.VENDOR_CODE            := V_LG_VENDOR_INFO.VENDOR_CODE;
    V_LG_VEHICLE_INFO_ROW.VENDOR_NAME            := V_LG_VENDOR_INFO.VENDOR_NAME;
    V_LG_VEHICLE_INFO_ROW.VENDOR_CONTACT         := '';
    V_LG_VEHICLE_INFO_ROW.VENDOR_TEL             := '';
    V_LG_VEHICLE_INFO_ROW.CREATED_BY             := 'LG';
    V_LG_VEHICLE_INFO_ROW.CREATION_DATE          := SYSDATE;
    V_LG_VEHICLE_INFO_ROW.LAST_UPDATED_BY        := 'LG';
    V_LG_VEHICLE_INFO_ROW.LAST_UPDATE_DATE       := SYSDATE;


    --构建运输合同头
    V_LG_CONTRACT_ROW.CONTRACT_ID                  := S_LG_CONTRACT.NEXTVAL;
    V_LG_CONTRACT_ROW.ENTITY_ID                    := V_LG_SHIP_DOC.ENTITY_ID;
    V_LG_CONTRACT_ROW.CONTRACT_CODE                := PKG_BD.F_GET_BILL_NO(P_BILL_TYPE  => 'lgContractNo',
                                                                           P_PREFIX_ADD => NULL,
                                                                           P_ENTITY_ID  => V_LG_SHIP_DOC.ENTITY_ID,
                                                                           P_USER_ID    => NULL);
    V_LG_CONTRACT_ROW.BILLS_STATUS                 := '00';
    V_LG_CONTRACT_ROW.VEHICLE_INFO_ID              := V_LG_VEHICLE_INFO_ROW.VEHICLE_INFO_ID;
    V_LG_CONTRACT_ROW.SALES_CENTER_ID              := V_INV_TRSF_ORDER.SALES_CENTER_ID;
    V_LG_CONTRACT_ROW.SHIP_WAY                     := V_LG_SHIP_DOC.SHIP_WAY;
    V_LG_CONTRACT_ROW.LOAD_VEHICLE_TYPE            := V_LG_SHIP_DOC.LOAD_VEHICLE_TYPE;
    V_LG_CONTRACT_ROW.SHIP_TYPE                    := V_LG_SHIP_DOC.SHIP_TYPE;
    V_LG_CONTRACT_ROW.CUSTOMER_ID                  := '';
    V_LG_CONTRACT_ROW.CUSTOMER_CODE                := '';
    V_LG_CONTRACT_ROW.CUSTOMER_NAME                := '';
    V_LG_CONTRACT_ROW.ACCOUNT_CODE                 := '';
    V_LG_CONTRACT_ROW.CUSTOMER_CONTACTS            := V_LG_SHIP_DOC.CUSTOMER_CONTACTS;
    V_LG_CONTRACT_ROW.CUSTOMER_CONTACTS_PHONES     := V_LG_SHIP_DOC.CUSTOMER_CONTACTS_PHONES;

    V_LG_CONTRACT_ROW.SHIP_TO_LOCATION_ID          := V_LG_SHIP_DOC.SHIP_TO_LOCATION_ID;
    V_LG_CONTRACT_ROW.SHIP_TO_LOCATION_CODE        := V_LG_SHIP_DOC.SHIP_TO_LOCATION_CODE;
    V_LG_CONTRACT_ROW.SHIP_TO_LOCATION             := V_LG_SHIP_DOC.Ship_To_Location;
    V_LG_CONTRACT_ROW.SHIP_INVENTORY_ID            := V_INV_TRSF_ORDER.SHIP_INV_ID;
    V_LG_CONTRACT_ROW.SHIP_INVENTORY_CODE          := V_INV_TRSF_ORDER.SHIP_INV_CODE;
    V_LG_CONTRACT_ROW.SHIP_INVENTORY_NAME          := V_INV_TRSF_ORDER.SHIP_INV_NAME;
    V_LG_CONTRACT_ROW.CONSIGNEE_INVENTORY_ID       := V_INV_TRSF_ORDER.CONSIGNEE_INV_ID;
    V_LG_CONTRACT_ROW.CONSIGNEE_INVENTORY_CODE     := V_INV_TRSF_ORDER.CONSIGNEE_INV_CODE;
    V_LG_CONTRACT_ROW.CONSIGNEE_INVENTORY_NAME     := V_INV_TRSF_ORDER.CONSIGNEE_INV_NAME;
    V_LG_CONTRACT_ROW.CONSIGNEE_ADDR               := V_LG_SHIP_DOC.Consignee_Addr;
    V_LG_CONTRACT_ROW.CONSIGNEE_LOCATION_ID        := V_LG_SHIP_DOC.CONSIGNEE_LOCATION_ID;
    V_LG_CONTRACT_ROW.CONSIGNEE_LOCATION_CODE      := V_LG_SHIP_DOC.Consignee_Location_Code;
    V_LG_CONTRACT_ROW.CONSIGNEE_LOCATION           := V_LG_SHIP_DOC.Consignee_Location;

    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_ID         := V_LG_SHIP_DOC.Consignee_Company_Id;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_CODE       := V_LG_SHIP_DOC.Consignee_Company_Code;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_NAME       := V_LG_SHIP_DOC.Consignee_Company_Name;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_ADDR       := V_LG_SHIP_DOC.CONSIGNEE_COMPANY_ADDR;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_CONTACT_ID := V_LG_SHIP_DOC.CONSIGNEE_COMPANY_CONTACT_ID;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_CONTRACT   := V_LG_SHIP_DOC.Consignee_Company_Contract;
    V_LG_CONTRACT_ROW.CONSIGNEE_COMPANY_TEL        := V_LG_SHIP_DOC.Consignee_Company_Tel;
    V_LG_CONTRACT_ROW.IS_CUSG_FLAG                 := V_LG_SHIP_DOC.Is_Cusg_Flag; --是否直发
    --获取经营单位名称
    BEGIN

     SELECT A.OPERATING_UNIT_NAME, A.OPERATING_UNIT
       INTO V_LG_CONTRACT_ROW.SHIP_COMPANY,V_LG_CONTRACT_ROW.OPERATING_UNIT
       FROM T_INV_ORGANIZATION A, T_INV_INVENTORIES B
      WHERE A.ORGANIZATION_ID = B.ORGANIZATION_ID
        AND A.ENTITY_ID = B.ENTITY_ID
        AND B.INVENTORY_ID = V_LG_CONTRACT_ROW.SHIP_INVENTORY_ID;
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '2001';
        O_RESULT_MSG := '经营单位信息不存在！';
        RETURN;
    END;
    V_LG_CONTRACT_ROW.REQUIRE_SHIP_DATE   := V_LG_SHIP_DOC.Require_Ship_Date;
    V_LG_CONTRACT_ROW.FACT_SHIP_DATE      := V_LG_SHIP_DOC.Doc_Date;
    V_LG_CONTRACT_ROW.REQUIRE_ARRIVE_DATE := V_LG_SHIP_DOC.Require_Arrive_Date;
    V_LG_CONTRACT_ROW.FACT_ARRIVE_DATE    := NULL;
    V_LG_CONTRACT_ROW.DROP_SHIP_FLAG      := NULL;
    V_LG_CONTRACT_ROW.DISTANCE            := V_LG_SHIP_DOC.DISTANCE;
    V_LG_CONTRACT_ROW.FREIGHT             := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.TAX_AMOUNT          := 0; --后面汇总计算

    --获取运费税率
    BEGIN
      SELECT TAX_RATE
        INTO V_TAX_RATE
        FROM T_LG_TAX_RATE_CONF
       WHERE CHARGES_TYPE_CODE = '00'
         AND DEFAULT_FLAG = 'Y';
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    V_LG_CONTRACT_ROW.TAX_RATE              := NVL(V_TAX_RATE, 0); --运费税率
    V_LG_CONTRACT_ROW.FREIGHT_NO_TAX        := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.ORIGIN_SHIP_CHARGES   := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.ADJUST_SHIP_CHARGES   := 0; --重新计算时填写
    V_LG_CONTRACT_ROW.FREIGHT_ADJUST_REASON := NULL;
    V_LG_CONTRACT_ROW.PRICE_UNIT            := V_LG_LINE_FREIGHT_STANDARD.PRICE_UNIT;
    V_LG_CONTRACT_ROW.TOTAL_VOLUME          := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.TOTAL_WEIGHT          := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.TOTAL_AMOUNT          := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.WEIGHT_UNIT           := 'KG'; --系统默认
    V_LG_CONTRACT_ROW.VOL_UNIT              := '方'; --系统默认
    V_LG_CONTRACT_ROW.PRINT_FLAG            := 'N';
    V_LG_CONTRACT_ROW.PRINT_TIMES           := 0;
    V_LG_CONTRACT_ROW.PRINT_DATE            := NULL;
    V_LG_CONTRACT_ROW.RECEIVE_FLAG          := 'N';
    V_LG_CONTRACT_ROW.RECEIVE_DATE          := NULL;
    V_LG_CONTRACT_ROW.RECEIVE_BY_NAME       := NULL;
    V_LG_CONTRACT_ROW.BACK_FLAG             := 'N';
    V_LG_CONTRACT_ROW.BACK_DATE             := NULL;
    V_LG_CONTRACT_ROW.LOCK_FLAG             := 'N';
    V_LG_CONTRACT_ROW.JUDGEMAR_CODE         := NULL;
    V_LG_CONTRACT_ROW.INSURANCE_FLAG        := 'Y'; --默认购买保险
    V_LG_CONTRACT_ROW.INSURACE_ID           := V_LG_INSURANCE_ROW.INSURER_ID; --命名不一致
    --获取保险商CODE和NAME
    BEGIN
      SELECT VENDOR_CODE, VENDOR_NAME
        INTO V_LG_CONTRACT_ROW.INSURACE_CODE,
             V_LG_CONTRACT_ROW.INSURACE_NAME
        FROM T_LG_VENDOR_INFO_HEAD
       WHERE VENDOR_ID = V_LG_CONTRACT_ROW.INSURACE_ID;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    V_LG_CONTRACT_ROW.RISK_AMOUNT            := 0; --投保金额
    V_LG_CONTRACT_ROW.INSURANCE              := 0; --后面汇总计算
    V_LG_CONTRACT_ROW.COMPENSATION_AMOUNT    := NULL;
    V_LG_CONTRACT_ROW.COMPENSATION_REASON    := NULL;
    V_LG_CONTRACT_ROW.COMPENSATION_DATE      := NULL;
    V_LG_CONTRACT_ROW.CLAIM_VENDOR_CODE      := NULL;
    V_LG_CONTRACT_ROW.CLAIM_VENDOR_NAME      := NULL;
    V_LG_CONTRACT_ROW.BREAK_CLAIMANT_AMOUNT  := NULL;
    V_LG_CONTRACT_ROW.BREAK_CLAIMANT_REASON  := NULL;
    V_LG_CONTRACT_ROW.BREAK_CLAIMANT_DATE    := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_CLAIMANT_AMOUNT := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_CLAIMANT_REASON := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_CLAIMANT_DATE   := NULL;
    V_LG_CONTRACT_ROW.BREAK_CLAIM_DATE       := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_CLAIM_DATE      := NULL;
    V_LG_CONTRACT_ROW.DAMAGE_INC_DEC_CODE    := NULL;
    V_LG_CONTRACT_ROW.BREAK_INC_DEC_CODE     := NULL;
    V_LG_CONTRACT_ROW.CONTRACT_TYPE          := '00';
    V_LG_CONTRACT_ROW.ORIGIN_CONTRACT_CODE   := NULL;
    V_LG_CONTRACT_ROW.FREIGHT_BATCH_FLAG     := NULL;
    V_LG_CONTRACT_ROW.INSUANCE_BATCH_FLAG    := NULL;
    V_LG_CONTRACT_ROW.FREIGHT_BATCH_NUM      := NULL;
    V_LG_CONTRACT_ROW.INSURANCE_BATCH_NUM    := NULL;
    V_LG_CONTRACT_ROW.SEND_FLAG              := NULL;
    V_LG_CONTRACT_ROW.VENDOR_FLAG            := NULL;
    V_LG_CONTRACT_ROW.VENDOR_ERROR_MESSAGE   := NULL;
    V_LG_CONTRACT_ROW.IMPORT_VENDOR_TIME     := NULL;
    V_LG_CONTRACT_ROW.CONTRACT_DATE          := SYSDATE;
    V_LG_CONTRACT_ROW.REG_CARRIAGE_FLAG      := 'N';
    V_LG_CONTRACT_ROW.REG_INSURANCE_FLAG     := 'N';
    V_LG_CONTRACT_ROW.PROMOTION_PRODUCT_VOL  := NULL; --暂时保留
    V_LG_CONTRACT_ROW.CREATED_BY             := 'LG';
    V_LG_CONTRACT_ROW.CREATION_DATE          := SYSDATE;
    V_LG_CONTRACT_ROW.LAST_UPDATED_BY        := 'LG';
    V_LG_CONTRACT_ROW.LAST_UPDATE_DATE       := SYSDATE;
    V_LG_CONTRACT_ROW.REMARK                 := NULL;

    --V_LG_CONTRACT(V_LG_CONTRACT.COUNT + 1) := V_LG_CONTRACT_ROW;

    --END IF;
    --遍历头表
    FREIGHT := 0;
    INSURANCE :=0;
    TOTAL_VOLUME :=0;
    TOTAL_WEIGHT :=0;
    AMOUNT :=0;

    while instr(var_tmp, var_split)>0 loop
       var_element := substr(var_tmp, 1, instr(var_tmp, var_split) - 1);
       var_tmp     := substr(var_tmp, instr(var_tmp, var_split) + length(var_split), length(var_tmp));
       --DBMS_OUTPUT.PUT_LINE(var_element);

      FOR C_INV_TRSF_ORDER IN (SELECT * FROM T_INV_TRSF_ORDER WHERE TRSF_ORDER_NUM = var_element) LOOP
        --遍历行明细表
        FOR C_INV_TRSF_ORDER_LINE IN (SELECT * FROM T_INV_TRSF_ORDER_LINE L WHERE L.TRSF_ORDER_ID = C_INV_TRSF_ORDER.TRSF_ORDER_ID) LOOP
          SELECT count(*) into var_count FROM T_INV_TRSF_ORDER_LINE_DETAIL WHERE trsf_order_line_id = C_INV_TRSF_ORDER_LINE.trsf_order_line_id;
          IF var_count > 1 THEN --1 套件
            --拆分套件到散件
            FOR C_INV_TRSF_ORDER_LINE_DETAIL IN (SELECT * FROM T_INV_TRSF_ORDER_LINE_DETAIL WHERE trsf_order_line_id = C_INV_TRSF_ORDER_LINE.trsf_order_line_id) LOOP
              --构建运输合同行
              V_LG_CONTRACT_LINE_ROW.CONTRACT_LINE_ID    := S_LG_CONTRACT_LINE.NEXTVAL;
              V_LG_CONTRACT_LINE_ROW.CONTRACT_ID         := V_LG_CONTRACT_ROW.CONTRACT_ID;
              V_LG_CONTRACT_LINE_ROW.SALES_MAIN_TYPE     := C_INV_TRSF_ORDER.SALES_MAIN_TYPE;
              V_LG_CONTRACT_LINE_ROW.SALES_ORDER_TYPE_ID := C_INV_TRSF_ORDER.Bill_Type_Id;
              V_LG_CONTRACT_LINE_ROW.SO_DOC_ID           := C_INV_TRSF_ORDER.TRSF_ORDER_ID;
              V_LG_CONTRACT_LINE_ROW.SO_DOC_NUM          := C_INV_TRSF_ORDER.Trsf_Order_Num;
              V_LG_CONTRACT_LINE_ROW.ITEM_CODE           := C_INV_TRSF_ORDER_LINE_DETAIL.Item_Code;
              V_LG_CONTRACT_LINE_ROW.ITEM_NAME           := C_INV_TRSF_ORDER_LINE_DETAIL.Item_Name;
              --查询产品单位、重量、体积
              SELECT DEFAULTUNIT, GROSSWEIGHT, PACKINGSIZE
                INTO V_LG_CONTRACT_LINE_ROW.ITEM_UOM,
                     V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT,
                     V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME
                FROM T_BD_ITEM
               WHERE ITEM_CODE = C_INV_TRSF_ORDER_LINE_DETAIL.Item_Code;
              V_LG_CONTRACT_LINE_ROW.ITEM_PRICE := 0;
              --实发数量 = 散件数量 * 产品数量
              V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY := C_INV_TRSF_ORDER_LINE_DETAIL.Billed_Qty;
              V_LG_CONTRACT_LINE_ROW.AMOUNT        := V_LG_CONTRACT_LINE_ROW.ITEM_PRICE *
                                                      V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
              V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME  := V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME *
                                                      V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
              V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT  := V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT *
                                                      V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
              V_LG_CONTRACT_LINE_ROW.SET_FLAG      := 'Y';
              V_LG_CONTRACT_LINE_ROW.SET_CODE      := C_INV_TRSF_ORDER_LINE.Item_Code;
              --大电模式 只考虑整车情况
              IF (V_LG_SHIP_DOC.LOAD_VEHICLE_TYPE = '01') THEN
                BEGIN
                  SELECT ROUND((CASE
                                 WHEN PRICE_UNIT = '00' THEN --按照体积计算
                                  UNIT_PRICE_OF_FREIGHT *
                                  V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME
                                 WHEN PRICE_UNIT = '01' THEN --按照重量计算
                                  UNIT_PRICE_OF_FREIGHT *
                                  V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT
                                 ELSE
                                  0
                               END),
                               2) +
                         V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES
                    INTO V_LG_CONTRACT_LINE_ROW.FREIGHT
                    FROM T_LG_LINE_FREIGHT_STANDARD T
                   WHERE T.TRANSPORT_LINE_ID = V_TRANSPORT_LINE_ID
                     AND T.SHIP_WAY = V_LG_SHIP_DOC.SHIP_WAY
                     AND T.SHIP_TYPE = V_LG_SHIP_DOC.SHIP_TYPE
                     AND T.LOAD_VEHICLE_TYPE = V_LG_SHIP_DOC.LOAD_VEHICLE_TYPE
                     AND T.VENDOR_ID = V_LG_VENDOR_INFO.VENDOR_ID
                     AND BEGIN_DATE <= SYSDATE
                     AND (END_DATE IS NULL OR
                         (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
                EXCEPTION
                  WHEN OTHERS THEN
                    NULL;
                END;
              ELSE
                V_LG_CONTRACT_LINE_ROW.FREIGHT := 0; --零担方式需要补充
              END IF;
              BEGIN
                --查询列表价格
                SELECT LIST_PRICE
                  INTO V_LIST_PRICE
                  FROM T_BD_PRICE_LINE
                 WHERE ITEM_CODE = V_LG_CONTRACT_LINE_ROW.ITEM_CODE
                   AND PRICE_LIST_ID = V_LG_INSURANCE_ROW.PRICE_LIST_ID;
              EXCEPTION
                WHEN OTHERS THEN
                  V_LIST_PRICE := 0;
                  NULL;
              END;
              --计算保费 实发数量*列表价格*税率
              V_LG_CONTRACT_LINE_ROW.INSURANCE := ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                        V_LIST_PRICE *
                                                        V_LG_INSURANCE_ROW.INSURANCE_RATE / 100,
                                                        2);
              --计算投保金额（累加）
              V_LG_CONTRACT_ROW.RISK_AMOUNT                 := V_LG_CONTRACT_ROW.RISK_AMOUNT +
                                                               ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                                     V_LIST_PRICE,
                                                                     2);
              V_LG_CONTRACT_LINE_ROW.FACT_RECEIVE_QTY       := NULL;
              V_LG_CONTRACT_LINE_ROW.AFFIRM_QTY             := NULL;
              V_LG_CONTRACT_LINE_ROW.SHATTER_QTY            := 0;
              V_LG_CONTRACT_LINE_ROW.DIFF_QTY               := 0;
              V_LG_CONTRACT_LINE_ROW.MOULD_QTY              := 0;
              V_LG_CONTRACT_LINE_ROW.OUT_LINE_QTY           := 0;
              V_LG_CONTRACT_LINE_ROW.PACK_SHATTER_QTY       := 0;
              V_LG_CONTRACT_LINE_ROW.DIFF_REASON            := NULL;
              V_LG_CONTRACT_LINE_ROW.DAMAGE_CLAIMANT_AMOUNT := 0;
              V_LG_CONTRACT_LINE_ROW.BREAK_CLAIMANT_AMOUNT  := 0;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_TYPE     := '';
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_DOC_CODE := '';
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_HEAD_ID  := '';
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_LINE_ID  := '';
              V_LG_CONTRACT_LINE_ROW.ORIGIN_TYPE            := nvl(C_INV_TRSF_ORDER.Orig_Order_Type,C_INV_TRSF_ORDER.BILL_TYPE_ID);
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_ID        := nvl(C_INV_TRSF_ORDER.Orig_Order_Id,C_INV_TRSF_ORDER.trsf_order_id);
              V_LG_CONTRACT_LINE_ROW.ORIGIN_LINE_ID         := C_INV_TRSF_ORDER_LINE.Order_Line_Id_Orig;
              V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_NUM       := nvl(C_INV_TRSF_ORDER.Orig_Order_Num,C_INV_TRSF_ORDER.Trsf_Order_Num);
              V_LG_CONTRACT_LINE_ROW.INVENTORY_CODE         := ''; --暂时保留
              V_LG_CONTRACT_LINE_ROW.INVENTORY_NAME         := ''; --暂时保留
              V_LG_CONTRACT_LINE_ROW.CREATED_BY             := 'LG';
              V_LG_CONTRACT_LINE_ROW.CREATION_DATE          := SYSDATE;
              V_LG_CONTRACT_LINE_ROW.LAST_UPDATED_BY        := 'LG';
              V_LG_CONTRACT_LINE_ROW.LAST_UPDATE_DATE       := SYSDATE;
              V_LG_CONTRACT_LINE_ROW.REMARK                 := NULL;

              FREIGHT := FREIGHT + V_LG_CONTRACT_LINE_ROW.Freight;
              INSURANCE := INSURANCE + V_LG_CONTRACT_LINE_ROW.INSURANCE;
              TOTAL_VOLUME := TOTAL_VOLUME + V_LG_CONTRACT_LINE_ROW.Unit_Volume;
              TOTAL_WEIGHT := TOTAL_WEIGHT + V_LG_CONTRACT_LINE_ROW.Unit_Weight;
              AMOUNT := AMOUNT + V_LG_CONTRACT_LINE_ROW.AMOUNT;

              V_LG_CONTRACT_LINE(V_LG_CONTRACT_LINE.COUNT + 1) := V_LG_CONTRACT_LINE_ROW;
            END LOOP;
          ELSE --2 散件
            --构建运输合同行
            V_LG_CONTRACT_LINE_ROW.CONTRACT_LINE_ID    := S_LG_CONTRACT_LINE.NEXTVAL;
            V_LG_CONTRACT_LINE_ROW.CONTRACT_ID         := V_LG_CONTRACT_ROW.CONTRACT_ID;
            V_LG_CONTRACT_LINE_ROW.SALES_MAIN_TYPE     := C_INV_TRSF_ORDER.SALES_MAIN_TYPE;
            V_LG_CONTRACT_LINE_ROW.SALES_ORDER_TYPE_ID := C_INV_TRSF_ORDER.Bill_Type_Id;
            V_LG_CONTRACT_LINE_ROW.SO_DOC_ID           := C_INV_TRSF_ORDER.Trsf_Order_Id;
            V_LG_CONTRACT_LINE_ROW.SO_DOC_NUM          := C_INV_TRSF_ORDER.Trsf_Order_Num;
            V_LG_CONTRACT_LINE_ROW.ITEM_CODE           := C_INV_TRSF_ORDER_LINE.Item_Code;
            V_LG_CONTRACT_LINE_ROW.ITEM_NAME           := C_INV_TRSF_ORDER_LINE.Item_Name;
            V_LG_CONTRACT_LINE_ROW.ITEM_UOM            := C_INV_TRSF_ORDER_LINE.Uom;
            V_LG_CONTRACT_LINE_ROW.ITEM_PRICE          := 0;
            V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY       := C_INV_TRSF_ORDER_LINE.Billed_Qty;

            --查询产品单位、重量、体积
            SELECT DEFAULTUNIT, GROSSWEIGHT, PACKINGSIZE
              INTO V_LG_CONTRACT_LINE_ROW.ITEM_UOM,
                   V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT,
                   V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME
              FROM T_BD_ITEM
             WHERE ITEM_CODE = V_LG_CONTRACT_LINE_ROW.Item_Code;

            V_LG_CONTRACT_LINE_ROW.AMOUNT              := V_LG_CONTRACT_LINE_ROW.ITEM_PRICE *
                                                          V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
            V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME        := V_LG_CONTRACT_LINE_ROW.UNIT_VOLUME *
                                                          V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
            V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT        := V_LG_CONTRACT_LINE_ROW.UNIT_WEIGHT *
                                                          V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY;
            V_LG_CONTRACT_LINE_ROW.SET_FLAG            := '';
            V_LG_CONTRACT_LINE_ROW.SET_CODE            := NULL;
            --大电模式 只考虑整车情况
            IF (V_LG_SHIP_DOC.LOAD_VEHICLE_TYPE = '01') THEN
              BEGIN
                SELECT ROUND((CASE
                               WHEN PRICE_UNIT = '00' THEN --按照体积计算
                                UNIT_PRICE_OF_FREIGHT *
                                V_LG_CONTRACT_LINE_ROW.TOTAL_VOLUME
                               WHEN PRICE_UNIT = '01' THEN --按照重量计算
                                UNIT_PRICE_OF_FREIGHT *
                                V_LG_CONTRACT_LINE_ROW.TOTAL_WEIGHT
                               ELSE
                                0
                             END),
                             2) +
                       V_LG_LINE_FREIGHT_STANDARD.EXTRA_SHIP_CHARGES
                  INTO V_LG_CONTRACT_LINE_ROW.FREIGHT
                  FROM T_LG_LINE_FREIGHT_STANDARD T
                 WHERE T.TRANSPORT_LINE_ID = V_TRANSPORT_LINE_ID
                   AND T.SHIP_WAY = V_LG_SHIP_DOC.SHIP_WAY
                   AND T.SHIP_TYPE = V_LG_SHIP_DOC.SHIP_TYPE
                   AND T.LOAD_VEHICLE_TYPE = V_LG_SHIP_DOC.LOAD_VEHICLE_TYPE
                   AND T.VENDOR_ID =V_LG_VENDOR_INFO.VENDOR_ID
                   AND BEGIN_DATE <= SYSDATE
                   AND (END_DATE IS NULL OR
                       (END_DATE IS NOT NULL AND END_DATE >= SYSDATE));
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
            ELSE
              V_LG_CONTRACT_LINE_ROW.FREIGHT := 0; --零担方式需要补充
            END IF;
            BEGIN
              --查询列表价格
              SELECT LIST_PRICE
                INTO V_LIST_PRICE
                FROM T_BD_PRICE_LINE
               WHERE ITEM_CODE = V_LG_CONTRACT_LINE_ROW.ITEM_CODE
                 AND PRICE_LIST_ID = V_LG_INSURANCE_ROW.PRICE_LIST_ID;
            EXCEPTION
              WHEN OTHERS THEN
                V_LIST_PRICE :=0;
                NULL;
            END;
            --计算保费 列表价格*税率
            V_LG_CONTRACT_LINE_ROW.INSURANCE := ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                      V_LIST_PRICE *
                                                      V_LG_INSURANCE_ROW.INSURANCE_RATE / 100,
                                                      2);
            --计算投保金额（累加）
            V_LG_CONTRACT_ROW.RISK_AMOUNT                 := V_LG_CONTRACT_ROW.RISK_AMOUNT +
                                                             ROUND(V_LG_CONTRACT_LINE_ROW.FACT_SHIP_QTY *
                                                                   V_LIST_PRICE,
                                                                   2);
            V_LG_CONTRACT_LINE_ROW.FACT_RECEIVE_QTY       := NULL;
            V_LG_CONTRACT_LINE_ROW.AFFIRM_QTY             := NULL;
            V_LG_CONTRACT_LINE_ROW.SHATTER_QTY            := 0;
            V_LG_CONTRACT_LINE_ROW.DIFF_QTY               := 0;
            V_LG_CONTRACT_LINE_ROW.MOULD_QTY              := 0;
            V_LG_CONTRACT_LINE_ROW.OUT_LINE_QTY           := 0;
            V_LG_CONTRACT_LINE_ROW.PACK_SHATTER_QTY       := 0;
            V_LG_CONTRACT_LINE_ROW.DIFF_REASON            := NULL;
            V_LG_CONTRACT_LINE_ROW.DAMAGE_CLAIMANT_AMOUNT := 0;
            V_LG_CONTRACT_LINE_ROW.BREAK_CLAIMANT_AMOUNT  := 0;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_TYPE     := '';
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_DOC_CODE := '';
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_HEAD_ID  := '';
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORIGIN_LINE_ID  := '';
            V_LG_CONTRACT_LINE_ROW.ORIGIN_TYPE            := nvl(C_INV_TRSF_ORDER.Orig_Order_Type,C_INV_TRSF_ORDER.BILL_TYPE_ID);
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_ID        := nvl(C_INV_TRSF_ORDER.Orig_Order_Id,C_INV_TRSF_ORDER.trsf_order_id);
            V_LG_CONTRACT_LINE_ROW.ORIGIN_LINE_ID         := C_INV_TRSF_ORDER_LINE.Order_Line_Id_Orig;
            V_LG_CONTRACT_LINE_ROW.ORIGIN_ORDER_NUM       := nvl(C_INV_TRSF_ORDER.Orig_Order_Num,C_INV_TRSF_ORDER.Trsf_Order_Num);
            V_LG_CONTRACT_LINE_ROW.INVENTORY_CODE         := ''; --暂时保留
            V_LG_CONTRACT_LINE_ROW.INVENTORY_NAME         := ''; --暂时保留
            V_LG_CONTRACT_LINE_ROW.CREATED_BY             := 'LG';
            V_LG_CONTRACT_LINE_ROW.CREATION_DATE          := SYSDATE;
            V_LG_CONTRACT_LINE_ROW.LAST_UPDATED_BY        := 'LG';
            V_LG_CONTRACT_LINE_ROW.LAST_UPDATE_DATE       := SYSDATE;
            V_LG_CONTRACT_LINE_ROW.REMARK                 := NULL;

            FREIGHT := FREIGHT + V_LG_CONTRACT_LINE_ROW.Freight;
            INSURANCE := INSURANCE + V_LG_CONTRACT_LINE_ROW.INSURANCE;
            TOTAL_VOLUME := TOTAL_VOLUME + V_LG_CONTRACT_LINE_ROW.Unit_Volume;
            TOTAL_WEIGHT := TOTAL_WEIGHT + V_LG_CONTRACT_LINE_ROW.Unit_Weight;
            AMOUNT := AMOUNT + V_LG_CONTRACT_LINE_ROW.AMOUNT;

            V_LG_CONTRACT_LINE(V_LG_CONTRACT_LINE.COUNT + 1) := V_LG_CONTRACT_LINE_ROW;

          END IF;

        END LOOP;

      END LOOP;
    end loop;
    --更新合同头表费用信息
    V_LG_CONTRACT_ROW.FREIGHT := FREIGHT;
    V_LG_CONTRACT_ROW.ORIGIN_SHIP_CHARGES := FREIGHT;
    V_LG_CONTRACT_ROW.FREIGHT_NO_TAX := ROUND(V_LG_CONTRACT_ROW.FREIGHT / (1 + V_LG_CONTRACT_ROW.TAX_RATE / 100), 2);
    V_LG_CONTRACT_ROW.TAX_AMOUNT := V_LG_CONTRACT_ROW.FREIGHT - ROUND(V_LG_CONTRACT_ROW.FREIGHT / (1 + V_LG_CONTRACT_ROW.TAX_RATE / 100), 2);
    V_LG_CONTRACT_ROW.INSURANCE := INSURANCE;
    V_LG_CONTRACT_ROW.TOTAL_VOLUME := TOTAL_VOLUME;
    V_LG_CONTRACT_ROW.TOTAL_WEIGHT := TOTAL_WEIGHT;
    V_LG_CONTRACT_ROW.REG_CARRIAGE_FLAG := 'Y';
    V_LG_CONTRACT_ROW.REG_INSURANCE_FLAG := 'Y';

    BEGIN
      --插入排车信息表
      INSERT INTO T_LG_VEHICLE_INFO VALUES V_LG_VEHICLE_INFO_ROW;
      --插入运输合同头表
      INSERT INTO T_LG_CONTRACT VALUES V_LG_CONTRACT_ROW;
      --插入运输合同行表
      FOR I IN V_LG_CONTRACT_LINE.FIRST .. V_LG_CONTRACT_LINE.LAST LOOP
        INSERT INTO T_LG_CONTRACT_LINE VALUES V_LG_CONTRACT_LINE (I);
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT     := '1007-1009-1010';
        O_RESULT_MSG := '生成排车信息-运输合同头-运输合同行失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
        ROLLBACK TO SAVEPOINT_KXMX ;
        RETURN;
    END;

    O_RESULT_MSG := O_RESULT_MSG || ',合同号：' || V_LG_CONTRACT_ROW.CONTRACT_CODE;

    --生成完运输合同提交，防止发送给A3取不到数据
    --COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      O_RESULT     := '0';
      O_RESULT_MSG := '生成运输合同失败！' || SUBSTR(SQLERRM(SQLCODE), 1, 256);
      RETURN;
  END;


END PKG_LG_INV_TO_SHIPMENT;
/

