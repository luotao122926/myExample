create function FUN_GET_CREDITGROUPID(P_ENTITY_ID Number,
                                 P_CUSTOMER_ID     NUMBER,
                                 P_SALES_MAIN_TYPE Varchar2,
                                 IN_ACCOUNT_ID     NUMBER DEFAULT NULL) return Number is
  Result Number;
begin
  Result := PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(P_ENTITY_ID,P_CUSTOMER_ID,P_SALES_MAIN_TYPE,IN_ACCOUNT_ID);
  return(Result);
end FUN_GET_CREDITGROUPID;
/

