create PACKAGE BODY PKG_LG_DOC_SHIP AS

  -----------------------------------------------------------------------------
  --  更新发货通知单的发货状态
  --没有发货已取消: 更新为已取消；
  --全部发货: 更新为已发货
  --部分发货: 需发货
  -----------------------------------------------------------------------------
  PROCEDURE P_REFRESH_SHIP_STATUS(
    IN_SHIP_DOC_ID            IN  NUMBER  --发货通知单ID
    ,IS_USER_ID               IN  VARCHAR2 --用户ID
    ,OS_STATUS                OUT VARCHAR2 --更新后的状态，空值为没有更新
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    N_CNT              NUMBER;
    S_STEP             VARCHAR2(40);
  BEGIN
    OS_MESSAGE := 'OK';
    --检查是否没有可发货数量
    S_STEP := '检查可发货数';
    SELECT
      COUNT(*)
    INTO
      N_CNT
    FROM
      T_LG_SHIP_DOC_LINE
    WHERE
      SHIP_DOC_ID = IN_SHIP_DOC_ID
      AND ITEM_QTY - NVL(FACT_SHIP_QTY,0) - NVL(CANCEL_QTY,0) <> 0
      AND ROWNUM = 1;
    
    IF N_CNT = 0 THEN
      --检查是否全部取消
      S_STEP := '检查取消数';
      SELECT
        COUNT(*)
      INTO
        N_CNT
      FROM
        T_LG_SHIP_DOC_LINE
      WHERE
        SHIP_DOC_ID = IN_SHIP_DOC_ID
        AND ITEM_QTY <> NVL(CANCEL_QTY,0)
        AND ROWNUM = 1;
      
      IF N_CNT = 0 THEN
        OS_STATUS := 'CANCELED';
      ELSE
        OS_STATUS := 'SHIPED';
      END IF;
      
      --已全部发货则更新发货通知单的发货状态为已发货
      S_STEP := '更新发货状态';
      UPDATE
        T_LG_SHIP_DOC
      SET
        SHIP_STATUS = OS_STATUS
        ,LAST_UPDATED_BY = IS_USER_ID
        ,LAST_UPDATE_DATE = SYSDATE
      WHERE
        SHIP_DOC_ID = IN_SHIP_DOC_ID;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '更新发货通知单状态(通知单ID:' || TO_CHAR(IN_SHIP_DOC_ID) || ')' || S_STEP ||':' || SQLERRM;
  END P_REFRESH_SHIP_STATUS;
  
  -----------------------------------------------------------------------------
  --  将实发数量记录到实际发货信息表中（用于生成销售单、调拨单）             --
  -----------------------------------------------------------------------------
  PROCEDURE P_TO_ACTUAL_SHIP(
    IN_SHIP_BATCH_ID          IN  NUMBER   --发货批次ID
    ,IN_SHIP_DOC_ID           IN  NUMBER   --发货通知单ID
    ,IS_VEHICLE_NUM           IN  VARCHAR2 --排车编号
    ,IS_USER_ID               IN  VARCHAR2 --用户ID
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    N_ACTUAL_SHIP_ID   NUMBER;
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;
    
    --写发货信息
    IF OS_MESSAGE = 'OK' THEN
      --按发货通知单对应的来源单据号分组，循环生成发货信息
      FOR R_BILL IN
      (
        SELECT DISTINCT
          SDL.SALES_MAIN_TYPE
          ,SDL.ORIGIN_TYPE
          ,SDL.ORIGIN_ORDER_NUM
          ,SDL.ORIGIN_ORDER_ID
          ,SDL.SALES_ORDER_TYPE_ID
          ,NVL(SDL.DISCOUNT_TYPE, 'COMMON') DISCOUNT_TYPE
        FROM
          T_LG_SHIP_DOC_SHIP_LINE SDSL
          ,T_LG_SHIP_DOC_LINE SDL
        WHERE
          SDSL.SHIP_DOC_LINE_ID = SDL.SHIP_DOC_LINE_ID
          AND SDSL.SHIP_BATCH_ID = IN_SHIP_BATCH_ID
      )
      LOOP
        --获取发货信息头ID
        SELECT
          S_LG_ACTUAL_SHIP.NEXTVAL
        INTO
          N_ACTUAL_SHIP_ID
        FROM
          DUAL;

        --写发货信息头表
        INSERT INTO T_LG_ACTUAL_SHIP
        (
          ACTUAL_SHIP_ID
          ,ENTITY_ID
          ,SALES_MAIN_TYPE
          ,VEHICLE_NUM
          ,SALES_ORDER_TYPE_ID
          ,VENDOR_ID
          ,VENDOR_CODE
          ,VENDOR_NAME
          ,SHIP_INVENTORY_ID
          ,CONSIGNEE_INVENTORY_ID
          ,CONSIGNEE_LOCATION_CODE
          ,CONSIGNEE_ADDR
          ,SHIP_WAY
          ,ORIGIN_TYPE
          ,ORIGIN_ORDER_NUM
          ,ORIGIN_ORDER_ID
          ,CUSTOMER_ID
          ,CUSTOMER_CODE
          ,CUSTOMER_NAME
          ,ACCOUNT_CODE
          ,SHIP_DATE
          ,SOURCE_TYPE
          ,SOURCE_BILL_ID
          ,SOURCE_BILL_NUM
          ,CREATED_BY
          ,CREATION_DATE
          ,LAST_UPDATED_BY
          ,LAST_UPDATE_DATE
          ,SHIP_TERMINAL_ENTITY_ID
          ,SHIP_TERMINAL_CODE
          ,SHIP_TERMINAL_NAME
          ,CONSIGNEE_TERMINAL_ENTITY_ID
          ,CONSIGNEE_TERMINAL_CODE
          ,CONSIGNEE_TERMINAL_NAME
          ,WHETHER_A3
          ,DISCOUNT_TYPE
        )
        SELECT
          N_ACTUAL_SHIP_ID ACTUAL_SHIP_ID
          ,SD.ENTITY_ID
          ,R_BILL.SALES_MAIN_TYPE
          ,IS_VEHICLE_NUM VEHICLE_NUM
          ,R_BILL.SALES_ORDER_TYPE_ID
          ,SD.VENDOR_ID
          ,SD.VENDOR_CODE
          ,SD.VENDOR_NAME
          ,SD.SHIP_INVENTORY_ID
          ,SD.CONSIGNEE_INVENTORY_ID
          ,SD.CONSIGNEE_LOCATION_CODE
          ,SD.CONSIGNEE_ADDR
          ,SD.SHIP_WAY
          ,R_BILL.ORIGIN_TYPE
          ,R_BILL.ORIGIN_ORDER_NUM
          ,R_BILL.ORIGIN_ORDER_ID
          ,SD.CUSTOMER_ID
          ,SD.CUSTOMER_CODE
          ,SD.CUSTOMER_NAME
          ,SD.ACCOUNT_CODE
          ,TRUNC(SYSDATE) SHIP_DATE
          ,NULL SOURCE_TYPE --'SHIP_BATCH' SOURCE_TYPE  由于销售模块将非空的来源均认为是库位单，故暂时先用空值
          ,IN_SHIP_BATCH_ID SOURCE_BILL_ID
          ,TO_CHAR(IN_SHIP_BATCH_ID) SOURCE_BILL_NUM
          ,IS_USER_ID CREATED_BY
          ,SYSDATE CREATION_DATE
          ,IS_USER_ID LAST_UPDATED_BY
          ,SYSDATE LAST_UPDATE_DATE
          ,SD.SHIP_TERMINAL_ENTITY_ID
          ,SD.SHIP_TERMINAL_CODE
          ,SD.SHIP_TERMINAL_NAME
          ,SD.CONSIGNEE_TERMINAL_ENTITY_ID
          ,SD.CONSIGNEE_TERMINAL_CODE
          ,SD.CONSIGNEE_TERMINAL_NAME
          ,SD.WHETHER_A3
          ,R_BILL.DISCOUNT_TYPE
        FROM
          T_LG_SHIP_DOC SD
        WHERE
          SD.SHIP_DOC_ID = IN_SHIP_DOC_ID;

        --写发货信息行表(将最小的库位单行ID带到发货信息表中)，为了简化逻辑，暂不处理配套关系
        INSERT INTO T_LG_ACTUAL_SHIP_LINE
        (
          SOURCE_BILL_LINE_ID
          ,ORIGIN_SHIP_PLAN_ID
          ,ACTUAL_SHIP_LINE_ID
          ,SHIP_INFO_ID
          ,SHIP_DOC_LINE_ID
          ,ORIGIN_LINE_ID
          ,ITEM_CODE
          ,ITEM_NAME
          ,ITEM_QTY
          ,CREATED_BY
          ,CREATION_DATE
          ,LAST_UPDATED_BY
          ,LAST_UPDATE_DATE
        )
        SELECT
          SDL.SHIP_DOC_LINE_ID SOURCE_BILL_LINE_ID
          ,SDL.ORIGIN_SHIP_PLAN_ID
          ,S_LG_ACTUAL_SHIP_LINE.NEXTVAL ACTUAL_SHIP_LINE_ID
          ,N_ACTUAL_SHIP_ID SHIP_INFO_ID
          ,SDL.SHIP_DOC_LINE_ID
          ,SDL.ORIGIN_LINE_ID
          ,SDL.ITEM_CODE
          ,SDL.ITEM_DESC ITEM_NAME
          ,SDSL.QUANTITY ITEM_QTY
          ,IS_USER_ID CREATED_BY
          ,SYSDATE CREATION_DATE
          ,IS_USER_ID LAST_UPDATED_BY
          ,SYSDATE LAST_UPDATE_DATE
        FROM
          T_LG_SHIP_DOC_SHIP_LINE SDSL
          ,T_LG_SHIP_DOC_LINE SDL
        WHERE
          SDSL.SHIP_DOC_LINE_ID = SDL.SHIP_DOC_LINE_ID
          AND SDSL.SHIP_BATCH_ID = IN_SHIP_BATCH_ID
          AND SDL.ORIGIN_TYPE = R_BILL.ORIGIN_TYPE
          AND SDL.ORIGIN_ORDER_ID = R_BILL.ORIGIN_ORDER_ID
          AND SDL.SALES_MAIN_TYPE = R_BILL.SALES_MAIN_TYPE
          AND SDL.SALES_ORDER_TYPE_ID = R_BILL.SALES_ORDER_TYPE_ID
          AND SDL.ORIGIN_ORDER_NUM = R_BILL.ORIGIN_ORDER_NUM
          AND NVL(SDL.DISCOUNT_TYPE, 'COMMON') = R_BILL.DISCOUNT_TYPE;

      END LOOP;
    END IF;

    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      OS_MESSAGE := '写实际发货信息(批次ID:' || TO_CHAR(IN_SHIP_BATCH_ID) || '):' || SQLERRM;
  END P_TO_ACTUAL_SHIP;

  -----------------------------------------------------------------------------
  --  生成销售单，调拨单使用JAVA程序来写，故没有对应的生成处理                                                     --
  -----------------------------------------------------------------------------
  PROCEDURE P_CREATE_BILL(
    IN_SHIP_BATCH_ID          IN  NUMBER   --发货批次ID
    ,IN_SHIP_DOC_ID           IN  NUMBER   --发货通知单ID
    ,IS_VEHICLE_NUM           IN  VARCHAR2 --排车编号
    ,IS_USER_ID               IN  VARCHAR2 --用户ID
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  ) IS
    S_STEP             VARCHAR2(40);
    N_REV_INVENTORY_ID NUMBER;
    N_RESULT           NUMBER;
    S_MESSAGE          VARCHAR2(1000);
    B_CREATEED_BILL    BOOLEAN := FALSE;
    N_CNT              NUMBER;
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;
    
    --根据接收仓判断是否调拨(有接收仓则为调拨，否则销售)
    S_STEP := '获取接收仓';
    SELECT
      CONSIGNEE_INVENTORY_ID
    INTO
      N_REV_INVENTORY_ID
    FROM
      T_LG_SHIP_DOC
    WHERE
      SHIP_DOC_ID = IN_SHIP_DOC_ID;

    --调拨单使用JAVA程序来处理，此处只处理销售单的生成
    IF N_REV_INVENTORY_ID IS NULL THEN
      S_STEP := '生成销售单';
      --循环获取发货信息，生成销售单，由于销售模块将非空来源认为是库位单，故使用排车编号来处理
      FOR R_ACTUAL IN
      (
			  SELECT
          ACTUAL_SHIP_ID 
			  FROM
          T_LG_ACTUAL_SHIP 
        WHERE
          --SOURCE_TYPE = 'SHIP_BATCH' 
          VEHICLE_NUM = IS_VEHICLE_NUM
			    AND SOURCE_BILL_ID = IN_SHIP_BATCH_ID
      )
			LOOP
        --调用销售
        PKG_SO_BIZ.P_SO_ENTRY_SHIP(R_ACTUAL.ACTUAL_SHIP_ID,IS_USER_ID,N_RESULT,S_MESSAGE);
        IF N_RESULT < 0 THEN
          OS_MESSAGE := S_MESSAGE;
          EXIT;
        END IF; 
        --更新所生成财务单的签收信息,增加创建日期的条件以优化性能
        UPDATE
          T_SO_HEADER
        SET
          RECEIVE_FLAG = 'Y'
          ,RECEIVE_DATE = SYSDATE
          ,LAST_UPDATE_DATE = SYSDATE
        WHERE
          SHIP_INFO_ID = R_ACTUAL.ACTUAL_SHIP_ID
          AND CREATION_DATE >= SYSDATE-0.005;
        
        UPDATE T_SO_LINE L
           SET L.RECEIVED_QTY     = L.ITEM_QTY,
               L.RECEIVED_DATE    = SYSDATE,
               L.LAST_UPDATE_DATE = SYSDATE
         WHERE EXISTS (SELECT 1
                  FROM T_SO_HEADER H
                 WHERE H.SO_HEADER_ID = L.SO_HEADER_ID
                   AND H.SHIP_INFO_ID = R_ACTUAL.ACTUAL_SHIP_ID
                   AND H.CREATION_DATE >= SYSDATE - 0.005);
                   
        --回写数量,统一在P_UPDATE_SHIP_DOC中回写，这里不需要
        --PKG_LG_CONTRACT.P_SHIP_CONFIRM(R_ACTUAL.ACTUAL_SHIP_ID,IS_USER_ID,S_RESULT_STATE,S_MESSAGE);
        --IF S_RESULT_STATE = '0' THEN
        --  OS_MESSAGE := S_MESSAGE;
        --  EXIT;
        --END IF; 
        B_CREATEED_BILL := TRUE; 
      END LOOP;
      
      IF OS_MESSAGE = 'OK' AND NOT B_CREATEED_BILL THEN
        --检查是否已全部取消，未取消则要报错
        SELECT
          COUNT(*)
        INTO
          N_CNT
        FROM
          T_LG_SHIP_DOC_LINE
        WHERE
          SHIP_DOC_ID = IN_SHIP_DOC_ID
          AND ITEM_QTY - NVL(FACT_SHIP_QTY,0) - NVL(CANCEL_QTY,0) <> 0
          AND ROWNUM = 1;
        IF N_CNT > 0 THEN
          OS_MESSAGE := '没有要生成销售单的内容';
        END IF;
      END IF;
    END IF;
    
    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      OS_MESSAGE := '生成单据(批次ID:' || TO_CHAR(IN_SHIP_BATCH_ID) || ')-'|| S_STEP || ':' || SQLERRM;
  END P_CREATE_BILL;

  -----------------------------------------------------------------------------
  --  发货确认，将发货批次内容生成对应的财务单
  --  由于需通过JAVA生成调拨单，故使用独立的过程处理回写                     --
  -----------------------------------------------------------------------------
  PROCEDURE P_SHIP_AFFIRM(
    IN_SHIP_BATCH_ID          IN  NUMBER   --发货批次ID
    ,IS_USER_ID               IN  VARCHAR2 --用户ID
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )
  IS
    S_STEP             VARCHAR2(40);
    N_SHIP_DOC_ID      NUMBER;
    S_VEHICLE_NUM      VARCHAR2(100);
    S_SHIP_STATUS      VARCHAR2(32);
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;
    
    --取出对应的发货通知单ID
    S_STEP := '取发货通知单';
    SELECT
      SHIP_DOC_ID
    INTO
      N_SHIP_DOC_ID
    FROM
      T_LG_SHIP_DOC_SHIP_LINE
    WHERE
      SHIP_BATCH_ID = IN_SHIP_BATCH_ID
      AND ROWNUM = 1;

    --获取排车编号
    S_STEP := '取排车编号';
    SELECT
      VEHICLE_NUM
    INTO
      S_VEHICLE_NUM
    FROM
      T_LG_SHIP_DOC_SHIP_BATCH
    WHERE
      SHIP_BATCH_ID = IN_SHIP_BATCH_ID;

    --锁定发货通知单表
    S_STEP := '锁定发货通知单';
    BEGIN
      SELECT
        SHIP_STATUS
      INTO
        S_SHIP_STATUS
      FROM
        T_LG_SHIP_DOC
      WHERE
        SHIP_DOC_ID = N_SHIP_DOC_ID
      FOR UPDATE NOWAIT;
      IF S_SHIP_STATUS <> 'NEED_SHIP' THEN
        OS_MESSAGE := '只有需发货状态的发货通知单才能写实际发货信息。';
      END IF;
    EXCEPTION
      WHEN TIMEOUT_ON_RESOURCE THEN
        OS_MESSAGE := '锁定发货通知单不成功！请稍后再试。';
    END;

    --检查发货数量是否大于可发货数量
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '检查是否大于可发货数';
      BEGIN
        SELECT
          '发货数量(' || TO_CHAR(SDSL.QUANTITY) || ')不能大于可发货数量('
            || TO_CHAR(SDL.ITEM_QTY) || '-' || TO_CHAR(NVL(SDL.FACT_SHIP_QTY,0)) || '-'
            || NVL(SDL.CANCEL_QTY,0) || '),来源单号：' || SDL.ORIGIN_ORDER_NUM
        INTO
          OS_MESSAGE
        FROM
          T_LG_SHIP_DOC_LINE SDL
          ,T_LG_SHIP_DOC_SHIP_LINE SDSL
        WHERE
          SDL.SHIP_DOC_LINE_ID = SDSL.SHIP_DOC_LINE_ID
          AND SDSL.SHIP_BATCH_ID = IN_SHIP_BATCH_ID
          AND SDSL.QUANTITY > SDL.ITEM_QTY - NVL(SDL.FACT_SHIP_QTY,0) - NVL(SDL.CANCEL_QTY,0)
          AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    END IF;

    --写发货信息
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '写发货信息';
      P_TO_ACTUAL_SHIP(IN_SHIP_BATCH_ID, N_SHIP_DOC_ID, S_VEHICLE_NUM, IS_USER_ID, OS_MESSAGE);
    END IF;
    
    --生成财务单
    IF OS_MESSAGE = 'OK' THEN
      S_STEP := '生成财务单';
      P_CREATE_BILL(IN_SHIP_BATCH_ID, N_SHIP_DOC_ID, S_VEHICLE_NUM, IS_USER_ID, OS_MESSAGE);
    END IF;
    
    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      OS_MESSAGE := '发货确认(批次ID:' || TO_CHAR(IN_SHIP_BATCH_ID) || ')-'|| S_STEP || ':' || SQLERRM;
  END P_SHIP_AFFIRM;

  -----------------------------------------------------------------------------
  --  更新发货通知单，由于调拨单生成使用JAVA处理，故独立调用回写发货通知单处理                     --
  -----------------------------------------------------------------------------
  PROCEDURE P_UPDATE_SHIP_DOC(
    IN_SHIP_BATCH_ID          IN  NUMBER   --发货批次ID
    ,IS_USER_ID               IN  VARCHAR2 --用户ID
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )
  IS
    S_STEP             VARCHAR2(40);
    N_SHIP_DOC_ID      NUMBER;
    N_REV_INVENTORY_ID NUMBER;
    N_CNT              NUMBER;
    S_VEHICLE_NUM      VARCHAR2(100);
    S_RESULT_STATE     VARCHAR2(200);
    S_MESSAGE          VARCHAR2(2000);
    S_SO_NUMS          VARCHAR2(100);
  BEGIN
    OS_MESSAGE := 'OK';
    SAVEPOINT SP;

    --取出对应的发货通知单ID
    S_STEP := '获取发货通知单';
    SELECT
      SHIP_DOC_ID
    INTO
      N_SHIP_DOC_ID
    FROM
      T_LG_SHIP_DOC_SHIP_LINE
    WHERE
      SHIP_BATCH_ID = IN_SHIP_BATCH_ID
      AND ROWNUM = 1;
    
    --获取排车编号
    S_STEP := '获取排车编号';
    SELECT
      VEHICLE_NUM
    INTO
      S_VEHICLE_NUM
    FROM
      T_LG_SHIP_DOC_SHIP_BATCH
    WHERE
      SHIP_BATCH_ID = IN_SHIP_BATCH_ID;
      
    --根据接收仓判断是否调拨(有接收仓则为调拨，否则销售)
    SELECT
      CONSIGNEE_INVENTORY_ID
    INTO
      N_REV_INVENTORY_ID
    FROM
      T_LG_SHIP_DOC
    WHERE
      SHIP_DOC_ID = N_SHIP_DOC_ID;
    
    --根据发货信息回写发货通知单,由于销售模块对于非空的SOURCE_TYPE认为是库位单，故只能使用排车编号来处理
    S_STEP := '更新已发货信息';
    FOR R_ACTUAL IN
    (
      SELECT
        ACTUAL_SHIP_ID 
      FROM
        T_LG_ACTUAL_SHIP 
      WHERE
        --SOURCE_TYPE = 'SHIP_BATCH' 
        VEHICLE_NUM = S_VEHICLE_NUM
        AND SOURCE_BILL_ID = IN_SHIP_BATCH_ID
    )
    LOOP
      --回写数量
      PKG_LG_CONTRACT.P_SHIP_CONFIRM(R_ACTUAL.ACTUAL_SHIP_ID,IS_USER_ID,S_RESULT_STATE,S_MESSAGE);
      IF S_RESULT_STATE = '0' THEN
        OS_MESSAGE := S_MESSAGE;
        EXIT;
      END IF;  
    END LOOP;
    
    --对于销售单，则获取所生成的单据号，更新到发货批次；调拨单需于JAVA中处理
    IF N_REV_INVENTORY_ID IS NULL THEN
      S_STEP := '更新所生成的单据号';
      --获取所生成的单据号，由于销售模块将空值来源认为是库位单，故不能使用所提供的方法来获取销售单号
      --S_SO_NUMS := PKG_SO_BIZ.F_GET_SO_NUM_BY_SRCTYPE('SHIP_BATCH',TO_CHAR(IN_SHIP_BATCH_ID));
      --取取排车编号对应的财务单号
      FOR R_SO IN
      (
        SELECT
          SO_NUM
        FROM
          T_SO_HEADER
        WHERE
          VEHICLE_NUM = S_VEHICLE_NUM
      )
      LOOP
        IF S_SO_NUMS IS NULL THEN
          S_SO_NUMS := R_SO.SO_NUM;
        ELSE
          S_SO_NUMS := S_SO_NUMS || ',' || R_SO.SO_NUM;
        END IF;
      END LOOP;
    ELSE
      --处理调拨单回写
      --取取排车编号对应的调拨单号
      FOR R_SO IN
      (
        SELECT
          TRSF_ORDER_NUM
        FROM
          T_INV_TRSF_ORDER
        WHERE
          VEHICLE_NUM = S_VEHICLE_NUM
      )
      LOOP
        IF S_SO_NUMS IS NULL THEN
          S_SO_NUMS := R_SO.TRSF_ORDER_NUM;
        ELSE
          S_SO_NUMS := S_SO_NUMS || ',' || R_SO.TRSF_ORDER_NUM;
        END IF;
      END LOOP;
    END IF;
    
    IF S_SO_NUMS IS NOT NULL THEN
      --将所生成的单据号更新到发货批次中
      UPDATE
        T_LG_SHIP_DOC_SHIP_BATCH
      SET
        BILL_NUMS = S_SO_NUMS
        ,LAST_UPDATED_BY = IS_USER_ID
        ,LAST_UPDATE_DATE = SYSDATE
      WHERE
        SHIP_BATCH_ID = IN_SHIP_BATCH_ID;
    END IF;
    
    --根据发货通知单行信息，更新发货通知单头的发货状态
    SELECT
      COUNT(*)
    INTO
      N_CNT
    FROM
      T_LG_SHIP_DOC_LINE
    WHERE
      SHIP_DOC_ID = N_SHIP_DOC_ID
      AND ITEM_QTY - NVL(FACT_SHIP_QTY,0) - NVL(CANCEL_QTY,0) <> 0
      AND ROWNUM = 1;
    
    IF N_CNT = 0 THEN
      --已全部发货则更新发货通知单的发货状态为已发货
      S_STEP := '更新发货状态';
      UPDATE
        T_LG_SHIP_DOC
      SET
        SHIP_STATUS = 'SHIPED'
        ,LAST_UPDATED_BY = IS_USER_ID
        ,LAST_UPDATE_DATE = SYSDATE
      WHERE
        SHIP_DOC_ID = N_SHIP_DOC_ID;
    END IF;

    IF OS_MESSAGE <> 'OK' THEN
      ROLLBACK TO SAVEPOINT SP;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP;
      OS_MESSAGE := '发货确认(批次ID:' || TO_CHAR(IN_SHIP_BATCH_ID) || ')-'|| S_STEP || ':' || SQLERRM;
  END P_UPDATE_SHIP_DOC;

END PKG_LG_DOC_SHIP;
/

