create package body      PKG_PLN_SC_INV_DETAIL is

  PROCEDURE P_GET_SC_INV_DETAIL(P_DATE      IN DATE,
                                P_ENTITY_ID IN NUMBER) IS
    V_MSG VARCHAR2(4000);
    V_PRICE_LIST_ID NUMBER;
    V_ENTITY_ID NUMBER;
    V_DATE DATE;
  BEGIN
    IF P_DATE IS NULL THEN
      V_DATE := SYSDATE;
    ELSE
      V_DATE := P_DATE;
    END IF;
    --有则获取总部主体id
    BEGIN
      SELECT DISTINCT TR.TRANSFER_ENTITY_ID
        INTO V_ENTITY_ID
        FROM T_PLN_ORDER_TYPE_RELA TR
       WHERE TR.SOURCE_ENTITY_ID = P_ENTITY_ID
         AND TR.RELATION_TYPE = 'LG_ORDER';
    EXCEPTION
      WHEN OTHERS THEN
        V_ENTITY_ID := P_ENTITY_ID;
    END;
    IF V_ENTITY_ID IS NULL THEN
      V_ENTITY_ID := P_ENTITY_ID;
    END IF;
    
    --先删除数据
    DELETE FROM T_PLN_SC_INV_DETAIL D WHERE D.ENTITY_ID = V_ENTITY_ID;

    INSERT INTO T_PLN_SC_INV_DETAIL
      (ENTITY_ID,
       SC_INV_DETAIL_ID,
       SALES_CENTER_ID,
       SALES_CENTER_CODE,
       SALES_CENTER_NAME,
       ITEM_ID,
       ITEM_CODE,
       ITEM_NAME,
       FINAL_QTY,
       LIST_PRICE,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATE_BY,
       LAST_UPDATE_DATE)
      SELECT V_ENTITY_ID ENTITY_ID,
             S_PLN_SC_INV_DETAIL.NEXTVAL,
             SALES_CENTER_ID,
             SALES_CENTER_CODE,
             SALES_CENTER_NAME,
             ITEM_ID,
             ITEM_CODE,
             ITEM_NAME,
             FINAL_QTY,
             NULL,
             'P_GET_SC_INV_DETAIL' CREATED_BY,
             SYSDATE CREATION_DATE,
             'P_GET_SC_INV_DETAIL' LAST_UPDATE_BY,
             SYSDATE LAST_UPDATE_DATE
        FROM (SELECT R.HQ_SALES_CENTER_ID SALES_CENTER_ID,
                     R.HQ_SALES_CENTER_CODE SALES_CENTER_CODE,
                     R.HQ_SALES_CENTER_NAME SALES_CENTER_NAME,
                     Q.ITEM_ID ITEM_ID,
                     Q.ITEM_CODE ITEM_CODE,
                     Q.ITEM_NAME ITEM_NAME,
                     NULL,
                     SUM(Q.QUANTITY) FINAL_QTY
                FROM T_INV_ALL_INV_DAY_QTY  Q,
                     T_BD_CENTER_RELATION R/*,
                     UP_ORG_UNIT                 U*//*,
                     T_BD_ITEM                   I*/
               WHERE Q.SALES_CENTER_CODE = R.SC_SALES_CENTER_CODE
                 AND q.entity_id = r.sc_entity_id
                 AND r.is_default_customer = 'Y'
                 AND R.HQ_ENTITY_ID = V_ENTITY_ID
                 /*AND U.ENTITY_ID = I.ENTITY_ID(+)
                 AND Q.MATERIAL_CODE = I.ITEM_CODE(+)*/
                 AND Q.INVENTORY_TYPE IN ('01', '07')
                 AND Q.ITEM_CODE NOT LIKE 'T%'
                 AND Q.DEFAULTUNIT = 'Set'
               GROUP BY R.HQ_SALES_CENTER_ID,
                        R.HQ_SALES_CENTER_CODE,
                        R.HQ_SALES_CENTER_NAME,
                        Q.ITEM_ID,
                        Q.ITEM_CODE,
                        Q.ITEM_NAME);

    --取价格列表
    BEGIN
      SELECT NVL(E.CODE_VALUE, C.CODE_VALUE) INTO V_PRICE_LIST_ID
        FROM UP_CODELIST C, UP_CODELIST_ENTITY E
       WHERE C.ID = E.CODELIST_ID(+)
         AND E.ENTITY_ID(+) = V_ENTITY_ID
         AND C.CODETYPE = 'PLN_SC_INV_MD_PRICE_ID';
    EXCEPTION
      WHEN OTHERS THEN
        V_PRICE_LIST_ID := 11;
    END;

    UPDATE T_PLN_SC_INV_DETAIL D
       SET D.LIST_PRICE =
           (SELECT AVG(L.LIST_PRICE)
              FROM T_BD_PRICE_LINE L
             WHERE L.PRICE_LIST_ID = V_PRICE_LIST_ID
               AND L.ITEM_CODE = D.ITEM_CODE
               AND V_DATE BETWEEN L.BEGIN_DATE AND NVL(L.END_DATE, SYSDATE + 1))
     WHERE D.ENTITY_ID = V_ENTITY_ID
       AND D.LIST_PRICE IS NULL;

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      V_MSG := SUBSTRB(SQLERRM, 1, 4000);
      INSERT INTO T_PLN_JOB_ERROR_LOG
        (JOB_DATE, MODULE_CODE, PROCEDURE_NAME, ERROR_MSG)
      VALUES
        (SYSDATE, 'PLN', 'P_GET_SC_INV_DETAIL', V_MSG);
      COMMIT;
  END P_GET_SC_INV_DETAIL;
end PKG_PLN_SC_INV_DETAIL;
/

