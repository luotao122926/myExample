create view V_CUSTOMER_ORG as
select o.CUSTOMER_ORG_ID,
       o.ENTITY_ID,
       o.CUSTOMER_ID,
       o.CUSTOMER_CODE,
       o.SALES_CENTER_ID,
       o.SALES_CENTER_CODE,
       o.SALES_REGION_ID,
       o.SALES_REGION_CODE,
       o.DEPT_ID,
       o.DEPT_CODE,
       o.CREATED_BY,
       o.CREATION_DATE,
       o.LAST_UPDATE_DATE,
       o.LAST_UPDATE_BY,
       o.LAST_INTERFACE_DATE,
       o.SIEBEL_ORG_ID,
       o.SIEBEL_CUSTOMER_ID,
       o.ACTIVE_FLAG,
       o.PRE_FIELD_01,
       o.PRE_FIELD_02,
       o.PRE_FIELD_03,
       o.PRE_FIELD_04,
       o.PRE_FIELD_05,
       o.PRE_FIELD_06,
       o.SALES_CENTER_NAME,
       u.unit_type
  from T_CUSTOMER_ORG o,UP_ORG_UNIT u
 WHERE o.sales_center_id = u.unit_id
   AND o.entity_id = u.entity_id with read only
/

comment on column V_CUSTOMER_ORG.CUSTOMER_ORG_ID is '客户组织ID'
/

comment on column V_CUSTOMER_ORG.ENTITY_ID is '主体ID'
/

comment on column V_CUSTOMER_ORG.CUSTOMER_ID is '客户ID'
/

comment on column V_CUSTOMER_ORG.CUSTOMER_CODE is '客户编码'
/

comment on column V_CUSTOMER_ORG.SALES_CENTER_ID is '中心ID'
/

comment on column V_CUSTOMER_ORG.SALES_CENTER_CODE is '中心编码'
/

comment on column V_CUSTOMER_ORG.SALES_REGION_ID is '大区ID'
/

comment on column V_CUSTOMER_ORG.SALES_REGION_CODE is '大区编码'
/

comment on column V_CUSTOMER_ORG.DEPT_ID is '事业部ID'
/

comment on column V_CUSTOMER_ORG.DEPT_CODE is '事业部编码'
/

comment on column V_CUSTOMER_ORG.CREATED_BY is '创建人'
/

comment on column V_CUSTOMER_ORG.CREATION_DATE is '创建日期'
/

comment on column V_CUSTOMER_ORG.LAST_UPDATE_DATE is '最后修改时间'
/

comment on column V_CUSTOMER_ORG.LAST_UPDATE_BY is '最后修改人'
/

comment on column V_CUSTOMER_ORG.LAST_INTERFACE_DATE is '最后同步时间'
/

comment on column V_CUSTOMER_ORG.SIEBEL_ORG_ID is '主数据客户组织ID'
/

comment on column V_CUSTOMER_ORG.SIEBEL_CUSTOMER_ID is '主数据客户ID'
/

comment on column V_CUSTOMER_ORG.ACTIVE_FLAG is '是否有效(Y/N)'
/

comment on column V_CUSTOMER_ORG.PRE_FIELD_01 is '预留字段1'
/

comment on column V_CUSTOMER_ORG.PRE_FIELD_02 is '预留字段2'
/

comment on column V_CUSTOMER_ORG.PRE_FIELD_03 is '预留字段3'
/

comment on column V_CUSTOMER_ORG.PRE_FIELD_04 is '预留字段4'
/

comment on column V_CUSTOMER_ORG.PRE_FIELD_05 is '预留字段5'
/

comment on column V_CUSTOMER_ORG.PRE_FIELD_06 is '预留字段6'
/

comment on column V_CUSTOMER_ORG.SALES_CENTER_NAME is '中心名称'
/

comment on column V_CUSTOMER_ORG.UNIT_TYPE is '组织单元类型'
/

