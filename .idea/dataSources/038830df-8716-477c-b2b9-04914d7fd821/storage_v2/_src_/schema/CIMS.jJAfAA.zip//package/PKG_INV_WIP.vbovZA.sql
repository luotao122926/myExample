create Package      Pkg_Inv_Wip Is

  -- Author  : 苏姝
  -- Created : 2014-07-25 11:12:33
  -- Purpose :

  Procedure p_Inv_Wip;
  ----------------------------------------------------------------------
  -- AUTHOR  : liugsh
  -- CREATED : 2014-08-08
  -- PURPOSE : 工单信息
  ----------------------------------------------------------------------
  Procedure p_Inv_Wip_Erp(p_Org_Id    In Number,
                          p_User_Code In Varchar2,
                          p_Result    Out Varchar2);

  ----------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2014-07-29 08:55:53
  -- Purpose : 工单与订单匹配关系接口数据写入正式表
  ----------------------------------------------------------------------
  Procedure p_Create_Wip_Order_Relation(p_Entity_Id       In Number, --主体ID
                                        p_Organization_Id In Number, --组织ID
                                        p_User_Code       In Varchar2,
                                        p_Result          Out Varchar2,
                                        p_Wip_entity_id   In Number Default Null --工单ID
                                        );

  ----------------------------------------------------------------------
  ---- AUTHOR  : Nicro.Li
  -- CREATED : 2014-08-08
  -- PURPOSE : 生成采购单
  ----------------------------------------------------------------------
  Procedure p_Create_Wip_To_Po_Order(p_Trace_Trans_Id  In Number, --
                                     p_Entity_Id       In Number,
                                     p_User_Code       In Varchar2,
                                     p_Result          Out Varchar2,
                                     p_Po_Order_Number Out Varchar2);

  --------------------------------------------------------------------------
  --Author: Nicro.li
  --Purpose:中转单执行，进行工单与订单匹配入库
  --------------------------------------------------------------------------
  Procedure p_Execute_Po_Match(p_Po_Head_Id In Number, --中转单头ID
                               p_Entity_Id  In Number, --主体ID
                               p_User_Code  In Varchar2, --用户ID
                               p_Result     Out Varchar2);

  --------------------------------------------------------------------------
  --Author: Nicro.li
  --Purpose:进行工单与订单匹配入库
  --------------------------------------------------------------------------
  Procedure p_Execute_Wip_Ord_Match(p_Po_Line_Id    In Number, --中转单行ID
                                    p_Tran_Quantity In Number, --事务数量带正负号
                                    p_Entity_Id     In Number, --主体ID
                                    p_User_Code     In Varchar2, --用户ID
                                    p_Result        Out Varchar2);
                                    
                                    
  --------------------------------------------------------------------------
  --Author: sushu  2016-07-11
  --Purpose:工单入库红冲单发货状态关闭时，更新原中转单明细行以及订单行、明细信息
  --------------------------------------------------------------------------
  Procedure p_update_wip_red(p_Po_Id     In Number,    --红冲单单头Id
                             p_Old_Po_Id In Number,    --红冲单对应的原单头Id
                             p_Result    Out Varchar2);--返回信息 

End Pkg_Inv_Wip;
/

