create view V_BD_ITEM_ASSEMBLIES_CSS as
select a.item_code product_assembly_code,
       a.item_name product_assembly_name,
       b.item_code product_sub_code,
       b.item_name product_sub_name,
       b.quantity,
       a.last_updated_by,
       a.last_update_date,
       a.entity_id
  from T_BD_ITEM_ASSEMBLIES a, t_Bd_Item_Assemblies_Sub b
 where a.item_assembly_id = b.item_assembly_id
/

