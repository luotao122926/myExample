create Package Pkg_Pln_Lg_Collect Is

  -- Author  : NICRO.LI
  -- Created : 2017-10-23 17:14:01
  -- Purpose : 

  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-10-24
  -- PURPOSE : T提货订单汇总预约结转
  -----------------------------------------------------------------------------   
  Procedure p_Reservation_Collect(In_Entity_Id        In Number, --订单ID
                                  In_Check_Begin_Date In Date, --送审开始日期
                                  In_Check_End_Date   In Date, --送审结束日期
                                  In_User_Code        In Varchar2, --用户编码
                                  Out_Result          Out Varchar2 --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                  );
                                  
  -----------------------------------------------------------------------------
  -- AUTHOR  : Nicro.Li
  -- CREATED : 2017-11-03
  -- PURPOSE : 提货订单预约汇总数据转T+3订单,多主体处理
  -----------------------------------------------------------------------------
  Procedure p_LgRc_To_Plnorder_All(In_Reservation_Head_Id In Number, --提货汇总订单头ID
                                   In_Order_Type_Id   In Number, --计划订单类型ID
                                   In_User_Code       In Varchar2, --用户编码
                                   Out_Result          In Out Varchar2 --返回结果：SUCCESS——>过程执行完成；FAILURE——>中途抛错
                                   );
                                   
  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2018-9-21
  -- PURPOSE : 提货订单预约汇总基数拆单处理 SINGLE
  -----------------------------------------------------------------------------
  PROCEDURE P_LG_COLLECT_SPLIT(IN_ENTITY_ID          IN NUMBER, --主体ID
                               IN_PERIOD_CODE        IN VARCHAR2, --周期
                               IN_COLLECT_MODE       IN VARCHAR2, --汇总模式
                               IN_USER_CODE          IN VARCHAR2, --操作用户
                               OUT_RESULT            OUT VARCHAR2 --返回结果：SUCCESS,成功；
    );
End Pkg_Pln_Lg_Collect;
/

