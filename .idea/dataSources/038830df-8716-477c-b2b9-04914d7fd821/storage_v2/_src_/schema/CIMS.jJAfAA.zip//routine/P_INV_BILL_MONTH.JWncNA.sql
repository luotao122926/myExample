create PROCEDURE P_INV_BILL_MONTH (
    in_entity_id        IN  NUMBER,        --经营主体ID
    in_operator_id        IN  NUMBER,        --操作人员ID
    in_bill_flag        IN  NUMBER,        --结账标识  1:结账  0:反结账
    in_period_id        IN  NUMBER,        --会计期间(当in_bill_flag=1时，表示结账会计期间)
    on_err_code            OUT NUMBER,     --错误码  default:0
    os_err_desc         OUT VARCHAR2    --错误描述 default:空
)
IS
    vn_count    number;
    vn_ubill_period_id  T_INV_INVENTORY_PERIODS.PERIOD_ID%TYPE; --反结账会计期间ID
    vn_next_period_id   T_INV_INVENTORY_PERIODS.PERIOD_ID%TYPE; --下一个会计期间ID
    vn_period_name      T_INV_INVENTORY_PERIODS.PERIOD_NAME%TYPE; --会计期间名称
    vd_begin_date       T_INV_INVENTORY_PERIODS.BEGIN_DATE%TYPE;
    vd_end_date         T_INV_INVENTORY_PERIODS.END_DATE%TYPE;
    vs_status           T_INV_INVENTORY_PERIODS.STATUS%TYPE;
    vs_is_checkout      T_INV_INVENTORY_PERIODS.CHECKOUT_FLAG%TYPE;

    Cursor c_bill
    IS
    SELECT PERIOD_ID,PERIOD_NAME,BEGIN_DATE,END_DATE
    FROM T_INV_INVENTORY_PERIODS
    WHERE BEGIN_DATE <= vd_begin_date AND STATUS = '01' AND CHECKOUT_FLAG = '00'  AND ENTITY_ID=in_entity_id
    ORDER BY BEGIN_DATE ASC;

    c_bill_row c_bill%rowtype;

BEGIN

    --初始化返回值
    on_err_code := 0;
    os_err_desc := '';

    --校验是否有正在结账的会计期间
    SELECT COUNT(PERIOD_ID) INTO vn_count
    FROM T_INV_INVENTORY_PERIODS
    WHERE CHECKOUT_FLAG = '02' AND ENTITY_ID=in_entity_id;

    IF vn_count > 0 THEN
        on_err_code := -1;
        os_err_desc := '存在正在结账的会计期间!';
        RETURN;
    END IF;

    --校验是否有未结账，但是已关闭的会计期间
    SELECT COUNT(PERIOD_ID) INTO vn_count
    FROM T_INV_INVENTORY_PERIODS
    WHERE CHECKOUT_FLAG = '00' AND STATUS='00' AND ENTITY_ID=in_entity_id;

    IF vn_count > 0 THEN
        on_err_code := -1;
        os_err_desc := '存在未结账，但是已关闭的会计期间!';
        RETURN;
    END IF;

    --校验是否有已结账，但是未关闭的会计期间
    SELECT COUNT(PERIOD_ID) INTO vn_count
    FROM T_INV_INVENTORY_PERIODS
    WHERE CHECKOUT_FLAG = '01' AND STATUS='01' AND ENTITY_ID=in_entity_id;

    IF vn_count > 0 THEN
        on_err_code := -1;
        os_err_desc := '存在已结账，但是未关闭的会计期间!';
        RETURN;
    END IF;

    --校验结账标识
    IF in_bill_flag = 0 THEN --反结账

        --查找最近一次已结账会计期间，作为反结账的会计期间
        SELECT PERIOD_ID INTO vn_ubill_period_id
        FROM T_INV_INVENTORY_PERIODS
        WHERE BEGIN_DATE =
        (SELECT MAX(BEGIN_DATE)
        FROM T_INV_INVENTORY_PERIODS
        WHERE STATUS='00' AND CHECKOUT_FLAG='01' AND ENTITY_ID=in_entity_id);

        --更新反结账会计期间状态为，未结账，未关闭。
        UPDATE T_INV_INVENTORY_PERIODS
        SET STATUS='01',CHECKOUT_FLAG='00',LAST_UPDATED_BY=in_operator_id,LAST_UPDATE_DATE=SYSDATE
        WHERE PERIOD_ID=vn_ubill_period_id AND ENTITY_ID=in_entity_id;

        --提交
        COMMIT;
        RETURN;
    ELSIF in_bill_flag = 1 THEN   --结账
        NULL;
    ELSE
        on_err_code := -1;
        os_err_desc := '结账标识无效!';
        RETURN;
    END IF;

    --结账
    --校验结账会计期间状态
    SELECT COUNT(PERIOD_ID) INTO vn_count
    FROM T_INV_INVENTORY_PERIODS
    WHERE PERIOD_ID=in_period_id AND ENTITY_ID=in_entity_id;

    IF vn_count = 0 THEN
        on_err_code := -1;
        os_err_desc := '会计期间不存在!';
        RETURN;
    END IF;

    --校验结账会计期间状态
    SELECT BEGIN_DATE,END_DATE,STATUS,CHECKOUT_FLAG
    INTO vd_begin_date,vd_end_date,vs_status,vs_is_checkout
    FROM T_INV_INVENTORY_PERIODS
    WHERE PERIOD_iD=in_period_id AND ENTITY_ID=in_entity_id;

    IF vs_is_checkout = '01' and vs_status = '00' THEN
        on_err_code := -1;
        os_err_desc := '会计期间已结账!';
        RETURN;
    END IF;

    SELECT COUNT(PERIOD_ID) INTO vn_count
    FROM T_INV_INVENTORY_PERIODS
    WHERE BEGIN_DATE=vd_end_date+1 AND ENTITY_ID=in_entity_id;

    --获取下一个会计期间
    IF vn_count = 0 THEN
        on_err_code := -1;
        os_err_desc := '不存在下一个会计期间!';
        RETURN;
    END IF;

    SELECT PERIOD_ID INTO vn_next_period_id
    FROM T_INV_INVENTORY_PERIODS
    WHERE BEGIN_DATE=vd_end_date+1 AND ENTITY_ID=in_entity_id;

    --更新要结账的会计期间状态为结账中
    FOR c_bill_row IN c_bill
    LOOP
        UPDATE T_INV_INVENTORY_PERIODS
        SET CHECKOUT_FLAG='02',LAST_UPDATED_BY=in_operator_id,LAST_UPDATE_DATE=SYSDATE
        WHERE PERIOD_ID=c_bill_row.PERIOD_ID AND ENTITY_ID=in_entity_id;
    END LOOP;

    --提交
    COMMIT;

    FOR c_bill_row IN c_bill
    LOOP

        /*


        --调用库存现有量重算过程


        */

        --对物料事务历史记录表按照经营主体ID+会计期间ID+仓库ID+产品ID，求入库数/出库数
        --并将结果集插入或更新到对应的月度收发存表中。
        MERGE INTO T_INV_MONTHSUM A
         USING (
                SELECT   INVENTORY_ID, ITEM_ID,
                    SUM(DECODE(ACTION_TYPE,'入库',TRANSACTION_QUANTITY,'转移',DECODE(FROM_INVENTORY_ID,NULL,0,TRANSACTION_QUANTITY),0)) QTY_IN,
                 -1*SUM(DECODE(ACTION_TYPE,'出库',TRANSACTION_QUANTITY,'转移',DECODE(TO_INVENTORY_ID,NULL,0,TRANSACTION_QUANTITY),0)) QTY_OUT
                FROM T_INV_TRANSACTION_HISTORY
                WHERE PERIOD_ID = c_bill_row.PERIOD_ID AND ENTITY_ID=in_entity_id
                GROUP BY INVENTORY_ID, ITEM_ID
                ) B
         ON ( A.PERIOD_ID = c_bill_row.PERIOD_ID
             AND A.ENTITY_ID = in_entity_id
             AND A.INVENTORY_ID = B.INVENTORY_ID
             AND A.ITEM_ID = B.ITEM_ID)
         WHEN MATCHED THEN
            UPDATE
               SET A.QTY_IN = B.QTY_IN, A.QTY_OUT = B.QTY_OUT,
                   A.QTY_BLNC = A.QTY_LM + B.QTY_IN + B.QTY_OUT,
                   A.LAST_UPDATED_BY = in_operator_id,
                   A.LAST_UPDATE_DATE = SYSDATE
         WHEN NOT MATCHED THEN
            INSERT (ENTITY_ID, INVENTORY_ID, PERIOD_ID,
                    PERIOD_NAME, ITEM_ID,  QTY_LM, QTY_IN,
                    QTY_OUT, QTY_BLNC, CREATED_BY, CREATION_DATE,
                    LAST_UPDATED_BY, LAST_UPDATE_DATE)
            VALUES (in_entity_id, B.INVENTORY_ID, c_bill_row.PERIOD_ID,
                    c_bill_row.PERIOD_NAME, B.ITEM_ID, 0,
                    B.QTY_IN, B.QTY_OUT, B.QTY_IN + B.QTY_OUT, in_operator_id,
                    SYSDATE, NULL, NULL);

        SELECT PERIOD_ID,PERIOD_NAME INTO vn_next_period_id,vn_period_name
        FROM T_INV_INVENTORY_PERIODS
        WHERE END_DATE=c_bill_row.END_DATE+1 AND ENTITY_ID=in_entity_id;

        --复制一条下一个存货会计期间的月度收发存数据记录
        MERGE INTO T_INV_MONTHSUM A
         USING (
                SELECT  INVENTORY_ID, ITEM_ID,QTY_LM,QTY_IN,QTY_OUT,QTY_BLNC,TRANSACTION_UOM
                 FROM T_INV_MONTHSUM
                 WHERE ENTITY_ID=in_entity_id AND PERIOD_ID = c_bill_row.PERIOD_ID
                ) B
         ON ( A.PERIOD_ID = vn_next_period_id
             AND A.ENTITY_ID = in_entity_id
             AND A.INVENTORY_ID = B.INVENTORY_ID
             AND A.ITEM_ID = B.ITEM_ID)
         WHEN MATCHED THEN
            UPDATE
               SET A.QTY_LM = B.QTY_BLNC, A.QTY_IN = 0,A.QTY_OUT = 0,
                   A.QTY_BLNC = B.QTY_BLNC,
                   A.LAST_UPDATED_BY = in_operator_id,
                   A.LAST_UPDATE_DATE = SYSDATE
         WHEN NOT MATCHED THEN
            INSERT (ENTITY_ID, INVENTORY_ID, PERIOD_ID,
                    PERIOD_NAME, ITEM_ID, TRANSACTION_UOM, QTY_LM, QTY_IN,
                    QTY_OUT, QTY_BLNC, CREATED_BY, CREATION_DATE,
                    LAST_UPDATED_BY, LAST_UPDATE_DATE)
            VALUES (in_entity_id, B.INVENTORY_ID, vn_next_period_id,
                    vn_period_name, B.ITEM_ID, B.TRANSACTION_UOM,B.QTY_BLNC,
                    0, 0, B.QTY_BLNC, in_operator_id,
                    SYSDATE, NULL, NULL);


        UPDATE T_INV_INVENTORY_PERIODS
        SET STATUS='00',CHECKOUT_FLAG='01',CLOSE_DATE=SYSDATE,
        LAST_UPDATED_BY=in_operator_id,LAST_UPDATE_DATE=SYSDATE
        WHERE PERIOD_ID=c_bill_row.PERIOD_ID AND ENTITY_ID=in_entity_id;


    END LOOP;

    --提交
    COMMIT;

EXCEPTION
   WHEN OTHERS
   THEN
      -- Consider logging the error and then re-raise
      on_err_code := SQLCODE;
      os_err_desc := SQLCODE || ':' || SQLERRM;
      ROLLBACK;
      RETURN;

END P_INV_BILL_MONTH;
/

