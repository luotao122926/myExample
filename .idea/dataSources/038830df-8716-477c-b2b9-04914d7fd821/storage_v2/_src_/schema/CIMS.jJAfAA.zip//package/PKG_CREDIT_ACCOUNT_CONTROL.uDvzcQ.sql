create package PKG_CREDIT_ACCOUNT_CONTROL is

  /*----------------------------------------------------------------
  *         包：PKG_CREDIT_ACCOUNT_CONTROL
  *   创建日期：2014-06-28
  *     创建者：苏冬渊
  *   功能说明：处理信用控制中的资金校验、账户款项变更、重新款项明细、重新账户款项、账户款项日冻结
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  *修改历史：
  *2016-2-19 梁学荣
  *修改PRC_CREDIT_FUND_RERUN、PRC_CREDIT_FUND_RERUN_IMPL，增加主体参数，以便于按主体重算客户款项
  *2016-2-29 梁学荣
  *修改PRC_CREDIT_VERIFICATION_IMPL，对于折让余额为负数，则作为到款金额来检查
  *2016-3-6 梁学荣
  *修改PRC_CREDIT_VERIFICATION_IMPL，增加主体参数，并按主体对应的参数控制是否使用负数折让余额作为到款金额控制
  */ ----------------------------------------------------------------

  TYPE CUR_SALES_ACCOUNT_AMOUNT IS TABLE OF T_SALES_ACCOUNT_AMOUNT%ROWTYPE INDEX BY BINARY_INTEGER;
  TYPE CUR_SALES_ACCOUNT_MX_AMOUNT IS TABLE OF T_SALES_ACCOUNT_MX_AMOUNT%ROWTYPE INDEX BY BINARY_INTEGER;
  TYPE CUR_CREDIT_DISCOUNT_AMOUNT IS TABLE OF T_CREDIT_DISCOUNT_AMOUNT%ROWTYPE INDEX BY BINARY_INTEGER;
  PROCEDURE 获取营销明细临时ID;
  FUNCTION FUN_GET_CONTROL_TEMP_ID RETURN NUMBER;
  PROCEDURE 以下为调用入口;
  /*PROCEDURE PRC_CREDIT_ORDER_BILL(P_ENTITY_ID               IN NUMBER, --主体ID
        P_ACTION_TYPE          IN NUMBER, --动作标示
        P_CONTROL_TEMP_ID       IN NUMBER, --单据临时ID
        P_ACCOUNT_ID           IN NUMBER, --账户ID
        P_CUSTOMER_ID          IN NUMBER, --客户ID
        P_PROJ_NUMBER          IN VARCHAR2, --项目号
        P_ORDER_ID             IN NUMBER,   --单据ID
        P_ORDER_TYPE           IN VARCHAR2, --单据类型
        P_USERNAME            IN VARCHAR2 ,
        P_RESULT            IN OUT NUMBER, --返回错误ID
        P_ERR_MSG           IN OUT VARCHAR2 --返回错误信息
  );*/
  /*PROCEDURE PRC_CREDIT_SALES_BILL(P_ENTITY_ID               IN NUMBER, --主体ID
        P_ACTION_TYPE          IN NUMBER, --动作标示
        P_CONTROL_TEMP_ID       IN NUMBER, --单据临时ID
        P_ACCOUNT_ID           IN NUMBER, --账户ID
        P_CUSTOMER_ID          IN NUMBER, --客户ID
        P_PROJ_NUMBER          IN VARCHAR2, --项目号
        P_CREATED_MODE         IN NUMBER,
        P_ORDER_ID             IN NUMBER,   --单据ID
        P_ORDER_TYPE           IN VARCHAR2, --单据类型
        P_USERNAME            IN VARCHAR2 ,
        P_RESULT            IN OUT NUMBER, --返回错误ID
        P_ERR_MSG           IN OUT VARCHAR2 --返回错误信息
  ) ;*/
  PROCEDURE PRC_CREDIT_RECEIVE_BILL(P_ENTITY_ID       IN NUMBER, --主体ID
                                    P_ACTION_TYPE     IN NUMBER, --动作标示
                                    P_CONTROL_TEMP_ID IN NUMBER, --单据临时ID
                                    P_ACCOUNT_ID      IN NUMBER, --账户ID
                                    P_CUSTOMER_ID     IN NUMBER, --客户ID
                                    P_PROJ_NUMBER     IN VARCHAR2, --项目号
                                    P_ORDER_ID        IN NUMBER, --单据ID
                                    P_ORDER_TYPE      IN VARCHAR2, --单据类型
                                    P_USERNAME        IN VARCHAR2, --用户名称
                                    P_RESULT          IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                                    );
  PROCEDURE PRC_CREDIT_THREE_PAY(P_ENTITY_ID       IN NUMBER, --主体ID
                                 P_ACTION_TYPE     IN NUMBER, --动作标示
                                 P_CONTROL_TEMP_ID IN NUMBER, --单据临时ID
                                 P_ACCOUNT_ID      IN NUMBER, --账户ID
                                 P_CUSTOMER_ID     IN NUMBER, --客户ID
                                 P_PROJ_NUMBER     IN VARCHAR2, --项目号
                                 P_ORDER_ID        IN NUMBER, --单据ID
                                 P_ORDER_TYPE      IN VARCHAR2, --单据类型
                                 P_USERNAME        IN VARCHAR2,
                                 P_RESULT          IN OUT NUMBER, --返回错误ID
                                 P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                                 );
  PROCEDURE PRC_CREDIT_ORDER_BILL(P_ENTITY_ID       IN NUMBER, --主体ID
                                  P_ACTION_TYPE     IN NUMBER, --动作标示
                                  P_Settlement_SUM  IN NUMBER, --结算金额
                                  P_Discount_SUM    IN NUMBER, --折让金额
                                  P_SALES_MAIN_TYPE IN VARCHAR2, --营销大类ID
                                  P_ACCOUNT_ID      IN NUMBER, --账户ID
                                  P_CUSTOMER_ID     IN NUMBER, --客户ID
                                  P_PROJ_NUMBER     IN VARCHAR2, --项目号
                                  P_ORDER_ID        IN NUMBER, --单据ID
                                  P_ORDER_TYPE      IN VARCHAR2, --单据类型
                                  P_USERNAME        IN VARCHAR2,
                                  P_RESULT          IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG         IN OUT VARCHAR2, --返回错误信息
                                  IS_DISCOUNT_TYPE    IN VARCHAR2 DEFAULT NULL
                                  );
  PROCEDURE PRC_CREDIT_SALES_BILL(P_ENTITY_ID      IN NUMBER, --主体ID
                                  P_ACTION_TYPE    IN NUMBER, --动作标示
                                  P_Settlement_SUM IN NUMBER, --结算金额
                                  P_Discount_SUM   IN NUMBER, --折让金额
                                  --P_THREE_NO_PAY_SUM       IN NUMBER, --三方承兑锁定金额
                                  P_SALES_MAIN_TYPE IN VARCHAR2, --营销大类ID
                                  P_ACCOUNT_ID      IN NUMBER, --账户ID
                                  P_CUSTOMER_ID     IN NUMBER, --客户ID
                                  P_PROJ_NUMBER     IN VARCHAR2, --项目号
                                  P_CREATED_MODE    IN NUMBER, --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                                  --P_CREDIT_GROUP_ID           OUT NUMBER,  --额度组ID(传出给款项变更用，不用重复查询)
                                  P_ORDER_ID   IN NUMBER, --单据ID
                                  P_ORDER_TYPE IN VARCHAR2, --单据类型
                                  P_USERNAME   IN VARCHAR2,
                                  P_RESULT     IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG    IN OUT VARCHAR2 --返回错误信息
                                  );
                                                               
 PROCEDURE PRC_CREDIT_BATCH_SALES_BILL(P_ENTITY_ID   IN NUMBER, --主体ID
                                       P_RESULT      OUT NUMBER, --返回错误ID
                                       P_ERR_MSG     OUT VARCHAR2 --返回错误信息
                                  );                                  
                                  
  /*PROCEDURE PRC_CREDIT_RECEIVE_BILL(P_ENTITY_ID               IN NUMBER, --主体ID
                                  P_ACTION_TYPE          IN NUMBER, --动作标示
                                  P_Settlement_SUM       IN NUMBER, --结算金额
                                  --P_Discount_SUM         IN NUMBER, --折让金额
                                  --P_THREE_NO_PAY_SUM       IN NUMBER, --三方承兑锁定金额
                                  P_SALES_MAIN_TYPE   IN VARCHAR2, --营销大类ID
                                  P_ACCOUNT_ID           IN NUMBER, --账户ID
                                  P_CUSTOMER_ID          IN NUMBER, --客户ID
                                  P_PROJ_NUMBER          IN VARCHAR2, --项目号
                                  --P_CREATED_MODE             IN NUMBER,  --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                                  --P_CREDIT_GROUP_ID           OUT NUMBER,  --额度组ID(传出给款项变更用，不用重复查询)
                                  P_ORDER_ID             IN NUMBER,   --单据ID
                                  P_ORDER_TYPE           IN VARCHAR2, --单据类型
                                  P_USERNAME            IN VARCHAR2 ,
                                  P_RESULT            IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG           IN OUT VARCHAR2 --返回错误信息
                            );
  PROCEDURE PRC_CREDIT_THREE_PAY(P_ENTITY_ID               IN NUMBER, --主体ID
                                  P_ACTION_TYPE          IN NUMBER, --动作标示
                                  P_Settlement_SUM       IN NUMBER, --结算金额
                                  --P_Discount_SUM         IN NUMBER, --折让金额
                                  P_THREE_NO_PAY_SUM     IN NUMBER, --三方承兑锁定金额
                                  P_SALES_MAIN_TYPE      IN VARCHAR2, --营销大类ID
                                  P_ACCOUNT_ID           IN NUMBER, --账户ID
                                  P_CUSTOMER_ID          IN NUMBER, --客户ID
                                  P_PROJ_NUMBER          IN VARCHAR2, --项目号
                                  --P_CREATED_MODE           IN NUMBER,  --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                                  --P_CREDIT_GROUP_ID          OUT NUMBER,  --额度组ID(传出给款项变更用，不用重复查询)
                                  P_ORDER_ID             IN NUMBER,   --单据ID
                                  P_ORDER_TYPE           IN VARCHAR2, --单据类型
                                  P_USERNAME            IN VARCHAR2 ,
                                  P_RESULT            IN OUT NUMBER, --返回错误ID
                                  P_ERR_MSG           IN OUT VARCHAR2 --返回错误信息
                            ); */
  PROCEDURE 以下为资金校验的过程;
  PROCEDURE PRC_CREDIT_ACC_AMOUNT_INIT(P_ENTITY_ID       IN NUMBER,
                                           P_CUSTOMER_ID     IN NUMBER,
                                           P_ACCOUNT_ID      IN NUMBER,
                                           P_PROJ_NUMBER     IN VARCHAR2,
                                           P_SALES_MAIN_TYPE IN VARCHAR2,
                                           P_USERNAME        IN VARCHAR2,
                                           P_RESULT          IN OUT NUMBER,
                                           P_ERR_MSG         IN OUT VARCHAR2,
                                           P_ATT_IN          IN VARCHAR2 DEFAULT NULL);
  PROCEDURE PRC_CREDIT_AMOUNT_CONTORL_INIT(P_ENTITY_ID       IN NUMBER,
                                           P_CUSTOMER_ID     IN NUMBER,
                                           P_ACCOUNT_ID      IN NUMBER,
                                           P_PROJ_NUMBER     IN VARCHAR2,
                                           P_SALES_MAIN_TYPE IN VARCHAR2,
                                           P_USERNAME        IN VARCHAR2,
                                           P_RESULT          IN OUT NUMBER,
                                           P_ERR_MSG         IN OUT VARCHAR2,
                                           P_ATT_IN          IN VARCHAR2 DEFAULT NULL);
  PROCEDURE PRC_CREDIT_VERIFICATION(P_ENTITY_ID       IN NUMBER, --主体ID
                                    P_ACTION_TYPE     IN NUMBER, --动作标示
                                    P_Settlement_SUM  IN NUMBER, --结算金额
                                    P_Discount_SUM    IN NUMBER, --折扣金额
                                    P_ORDER_ID        IN NUMBER, --单据ID
                                    P_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                    P_ACCOUNT_ID      IN NUMBER, --账户ID
                                    P_CUSTOMER_ID     IN NUMBER, --客户ID
                                    P_PROJ_NUMBER     IN VARCHAR2, --项目号
                                    P_CREATED_MODE    IN NUMBER, --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                                    P_RESULT          IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG         IN OUT VARCHAR2, --返回错误信息
                                    P_ORDER_TYPE      IN VARCHAR2 DEFAULT NULL, --订单类型
                                    IS_DISCOUNT_TYPE    IN VARCHAR2 DEFAULT NULL,--折让方式
                                    IS_PLN_SRC_ORDER_TYPE IN VARCHAR2 DEFAULT NULL--订单源类型 1提货订单
                                    );
  PROCEDURE PRC_CREDIT_VERIFICATION_IMPL(P_ENTITY_ID            IN NUMBER, --主体ID
                                         P_ACTION_TYPE          IN NUMBER, --动作标示
                                         P_Settlement_SUM       IN NUMBER, --结算金额
                                         P_Discount_SUM         IN NUMBER, --折扣金额
                                         P_ORDER_ID             IN NUMBER, --单据ID
                                         P_SALES_MAIN_TYPE      IN VARCHAR2, --营销大类
                                         P_SALES_ACCOUNT_AMOUNT IN CUR_SALES_ACCOUNT_AMOUNT,
                                         IC_CREDIT_DISCOUNT_AMOUNT IN CUR_CREDIT_DISCOUNT_AMOUNT,--add by liangym2 2017-8-5
                                         P_AMOUNT_CRTL_FLAG     IN VARCHAR2, --金额控制方式
                                         P_DISCONT_CRTL_FLAG    IN VARCHAR2, --折扣控制方式
                                         P_CREATED_MODE         IN NUMBER, --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                                         P_RESULT               IN OUT NUMBER, --返回错误ID
                                         P_ERR_MSG              IN OUT VARCHAR2, --返回错误信息
                                         IS_RECEIVABLE_CRTL_FLAG    IN VARCHAR2, --应收控制标识
                                         P_ORDER_TYPE           IN VARCHAR2 DEFAULT NULL, --订单类型
                                         IS_DISCOUNT_TYPE    IN VARCHAR2 DEFAULT NULL,--折让方式
                                         IS_PLN_SRC_ORDER_TYPE IN VARCHAR2 DEFAULT NULL,--订单源类型 1提货订单
                                         IS_RE_VERIFIED_CREDIT IN VARCHAR2 DEFAULT NULL,--退款是否检查信用
                                         IS_TU_VERIFIED_CREDIT IN VARCHAR2 DEFAULT NULL--转款是否检查信用
                                         );
  PROCEDURE 以下为款项变更的过程;
  PROCEDURE PRC_CREDIT_FUND_UPDATE(P_ENTITY_ID       IN NUMBER, --主体ID
                                   P_ACTION_TYPE     IN NUMBER, --动作标示
                                   P_Settlement_SUM  IN NUMBER, --结算金额
                                   P_Discount_SUM    IN NUMBER, --折扣金额
                                   P_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                   P_ACCOUNT_ID      IN NUMBER, --账户ID
                                   P_CUSTOMER_ID     IN NUMBER, --客户ID
                                   P_PROJ_NUMBER     IN VARCHAR2, --项目号
                                   P_CREATED_MODE    IN NUMBER, --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                                   --P_CREDIT_GROUP_ID    IN NUMBER ,--(直接根据资金校验结果传入，不用重复查询)
                                   P_ORDER_ID   IN NUMBER, --单据ID
                                   P_ORDER_TYPE IN VARCHAR2, --单据类型
                                   P_USERNAME   IN VARCHAR2,
                                   P_RESULT     IN OUT NUMBER, --返回错误ID
                                   P_ERR_MSG    IN OUT VARCHAR2 --返回错误信息
                                   );
  PROCEDURE 以下为款项重算的过程;
  FUNCTION FUN_GET_ITEM_QTY(P_Ship_Doc_Line_Id Number) RETURN NUMBER;
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-10-12
  *     创建者：苏冬渊
  *   功能说明：客户锁款金额重算，凌晨时点跑，冻结的是前一天的客户款项
                冻结时点不一定是0点，可能是2点，那么0点到2点之间是会有业务进行的。
                这时候使用客户账户的金额来进行冻结的话，那么冻结金额就有偏差。跟ERP等的金额就会有误差
            本函数是用来计算这部分金额的
  */
  -------------------------------------------------------------------------------
  FUNCTION FUN_GET_THIS_AMOUNT(P_ENTITY_ID       T_SALES_ACCOUNT_MX_AMOUNT.Entity_Id%Type,
                               P_CUSTOMER_ID     T_SALES_ACCOUNT_MX_AMOUNT.CUSTOMER_ID%Type,
                               P_ACCOUNT_ID      T_SALES_ACCOUNT_MX_AMOUNT.ACCOUNT_ID%Type,
                               P_SALES_MAIN_TYPE T_SALES_ACCOUNT_MX_AMOUNT.SALES_MAIN_TYPE%Type,
                               P_AMOUNT          T_SALES_ACCOUNT_MX_AMOUNT.RECEIVED_AMOUNT%Type,
                               P_FLAG            Varchar2) RETURN Number;

  -------------------------------------------------------------------------------
  /*
  处理信用模块中的款项重算，重算的来源包括销售单、订单、铺底、收款
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_CREDIT_FUND_RERUN(IN_ENTITY_ID IN NUMBER, --主体ID
    IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
    IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
    IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
    IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
    IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
    IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
  --  P_ERR_MSG OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
                                  );
                                  
     --款项初始化
  PROCEDURE PRC_CREDIT_FUND_INIT(
      IN_ENTITY_ID   IN  NUMBER,    --主体ID
      IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
      IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
      IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
      IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
      IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
      IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
   -- P_ERR_MSG OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  );
  
  
  --客户往来冻结
  PROCEDURE PRC_CREDIT_FUND_CONTACT(
      IN_ENTITY_ID   IN  NUMBER,    --主体ID
      IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
      IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
      IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
      IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
      IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
      IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
   -- P_ERR_MSG OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  ) ;
  
  
  PROCEDURE PRC_CREDIT_FUND_SA_RETURN(
      IN_ENTITY_ID   IN  NUMBER,    --主体ID
      IN_MOD IN  NUMBER,--MOD模式
      IN_MOD_REN IN  NUMBER,--MOD余数
      IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
      IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
      IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
      IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
      IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
      IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
  );
  
  
    --款型锁定明细重算
  PROCEDURE PRC_CREDIT_FUND_MX_RETURN(
      IN_ENTITY_ID   IN  NUMBER,    --主体ID
      IN_MOD IN  NUMBER,--MOD模式
      IN_MOD_REN IN  NUMBER,--MOD余数
      IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
      IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
      IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
      IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
      IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
      IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
   -- P_ERR_MSG OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  );
  
  
    --款项冻结
  PROCEDURE PRC_CREDIT_FUND_FREEZE(
      IN_ENTITY_ID   IN  NUMBER,    --主体ID
      IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
      IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
      IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
      IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
      IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
      IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
   -- P_ERR_MSG OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  );
  
    --重算款项  折扣类款项
  PROCEDURE PRC_CREDIT_FUND_DIS_RETURN(
      IN_ENTITY_ID   IN  NUMBER,    --主体ID
      IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
      IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
      IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
      IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
      IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
      IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
   -- P_ERR_MSG OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
  );
                               
                                  

  -------------------------------------------------------------------------------
  /*
  处理信用模块中的款项重算，根据重算之后的款项明细信息重算款项信息
  */
  PROCEDURE PRC_CREDIT_FUND_RERUN_IMPL(IN_ENTITY_ID IN NUMBER, --主体ID
    IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
    IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
    IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
    IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
    IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
    IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
  --  P_ERR_MSG OUT VARCHAR2 --成功则返回“OK”，失败返回“ERROR”
                                       );

  /**
  *ADD BY LIANGYM2 2017-8-25 临时修复锁款标识
  */
  PROCEDURE PRC_LG_SHIP_DOCL_RERUN
  (
    IN_ENTITY_ID   IN  NUMBER,    --主体ID
    IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
    IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL,--账户ID，可以为空
    IS_ORDER_TYPE  IN  VARCHAR2,--订单类型
    IS_USER_CODE   IN  VARCHAR2 DEFAULT NULL,--更新人，可以为空
    IS_REASON      IN  VARCHAR2 DEFAULT NULL,--更新原因，可以为空
    IS_PRE_ARG     IN  VARCHAR2 DEFAULT 'FREEZE',--预留参数，FREEZE 重算后进行冻结，可以为空（空暂定默认为FREEZE）
    IS_FREEZE_DATE IN  VARCHAR2 DEFAULT NULL--冻结日期 格式YYYYMMDD
  );
  
  /*PROCEDURE 以下为铺底核销的过程;
  PROCEDURE PRC_CREDIT_DELAYPAY_MAIN ;
  PROCEDURE PRC_CREDIT_DELAYPAY_DUE_DATE ;
  PROCEDURE PRC_CREDIT_DELAYPAY_APPLIED;
  PROCEDURE PRC_CREDIT_DELAYPAY_APPLIED_AT(P_ACTION_TYPE NUMBER, --动作标识
                                           P_SETTLE_AMOUNT NUMBER, --结算金额
                                           P_ENTITY_ID NUMBER, --主体ID
                                           P_CUSTOMER_ID NUMBER, --客户ID
                                           P_ACCOUNT_ID NUMBER , --账户ID
                                           P_SALES_MAIN_TYPE VARCHAR2, --营销大类
                                           P_CASH_RECEIPT_ID NUMBER , --收款单据ID
                                           P_THREE_PAY_ID NUMBER, --三方承兑ID
                                           P_USERNAME VARCHAR2,
                                           P_RESULT   IN OUT NUMBER, --返回错误ID
                                           P_ERR_MSG  IN OUT VARCHAR2 --返回错误信息
                                           );
  PROCEDURE 以下铺底利息的计算 ;
  PROCEDURE PRC_CREDIT_DELAYPAY_ACCRUAL(P_BILL_ID T_CREDIT_DELAYPAY.BILL_ID%TYPE,
                                        P_BRING_ACCRUAL_DAYS OUT NUMBER,
                                        P_BRING_ACCRUAL_AMOUNT OUT NUMBER,
                                        P_ACCRUAL_AMOUNT OUT NUMBER,
                                        P_RESULT IN OUT NUMBER,
                                        P_ERR_MSG IN OUT VARCHAR2);*/

  PROCEDURE 订单检查不锁款调用;

  Procedure PRC_CREDIT_ORDER_CHECK(P_ENTITY_ID       IN NUMBER, --主体ID
                                   P_ACTION_TYPE     IN NUMBER, --动作标示
                                   P_Settlement_SUM  IN NUMBER, --结算金额
                                   P_Discount_SUM    IN NUMBER, --折让金额
                                   P_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                   P_ACCOUNT_ID      IN NUMBER, --账户ID
                                   P_CUSTOMER_ID     IN NUMBER, --客户ID
                                   P_PROJ_NUMBER     IN VARCHAR2, --项目号
                                   P_ORDER_ID        IN NUMBER, --单据ID
                                   P_RESULT          IN OUT NUMBER, --返回错误ID
                                   P_ERR_MSG         IN OUT VARCHAR2 --返回错误信息
                                   );
  PROCEDURE PRC_UPD_ACCOUNT_AMOUNT_FLAG(P_ACCOUNT_ID IN NUMBER,
                                        P_CREDIT_GROUP_ID IN NUMBER,
                                        P_USER_CODE         IN VARCHAR2,
                                        P_AMOUNT_CRTL_FLAG  IN VARCHAR2,
                                        P_DISCONT_CRTL_FLAG IN VARCHAR2,
                                        P_REMARK            IN VARCHAR2
                                        );
                                        
  PROCEDURE P_CREDIT_LOCK_HAND(IN_ENTITY_ID       IN NUMBER, --主体ID
                               IN_CUSTOMER_ID     IN NUMBER, --客户ID
                               IN_ACCOUNT_ID      IN NUMBER, --账户ID
                               IN_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                               IN_PROJ_NUMBER     IN VARCHAR2, --项目号
                               IN_AMOUNT_SUM      IN NUMBER, --结算金额(需传正负号)
                               IN_DISAMOUNT_SUM   IN NUMBER, --折让金额(需传正负号)
                               IN_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 COMMON/DISCOUNT
                               IN_ORDER_ID        IN NUMBER, --单据ID
                               IN_ORDER_NUMBER    IN VARCHAR2, --单据号
                               IN_DOWNPAY_RATE    IN NUMBER, --订金比例
                               IN_SRC_TYPE        IN VARCHAR2, --来源类型
                               IN_USER_ACCOUNT    IN VARCHAR2, --操作用户
                               OUT_RESULT         IN OUT NUMBER, --返回错误ID
                               OUT_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                               );
                               
  PROCEDURE P_CREDIT_CHECK_AMOUNT(IN_ENTITY_ID       IN NUMBER, --主体ID
                                  IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                  IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                  IN_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                  IN_PROJ_NUMBER     IN VARCHAR2, --项目号
                                  IN_AMOUNT_SUM      IN NUMBER, --结算金额(需传正负号)
                                  IN_DISAMOUNT_SUM   IN NUMBER, --折让金额(需传正负号)
                                  IN_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 COMMON/DISCOUNT
                                  IN_USER_ACCOUNT    IN VARCHAR2, --操作用户
                                  OUT_RESULT         IN OUT NUMBER, --返回错误ID
                                  OUT_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                  );
                                  
  PROCEDURE P_CREDIT_LOCK_DETAIL_HAND(IN_ENTITY_ID       IN NUMBER, --主体ID
                                      IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                      IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                      IN_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                      IN_PROJ_NUMBER     IN VARCHAR2, --项目号
                                      IN_AMOUNT_SUM      IN NUMBER, --结算金额(需传正负号)
                                      IN_DISAMOUNT_SUM   IN NUMBER, --折让金额(需传正负号)
                                      IN_DP_AMOUNT_SUM   IN NUMBER, --订金金额(需传正负号)
                                      IN_DP_DISAMOUNT_SUM IN NUMBER, --折让订金金额(需传正负号)
                                      IN_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 COMMON/DISCOUNT
                                      IN_ORDER_ID        IN NUMBER, --单据ID
                                      IN_ORDER_NUMBER    IN VARCHAR2, --单据号
                                      IN_DOWNPAY_RATE    IN NUMBER, --订金比例（提货订单、计划订单使用）
                                      IN_SRC_TYPE        IN VARCHAR2, --来源类型
                                      IN_USER_ACCOUNT    IN VARCHAR2, --操作用户
                                      OUT_RESULT         IN OUT NUMBER, --返回错误ID
                                      OUT_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                      );
  
  PROCEDURE P_CREDIT_LOCK_TRANS_ADD(IN_ENTITY_ID       IN NUMBER, --主体ID
                                    IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                    IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                    IN_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                    IN_CREDIT_GROUP_ID IN NUMBER, --额度组ID
                                    IN_PROJ_NUMBER     IN VARCHAR2, --项目号
                                    IN_AMOUNT_SUM      IN NUMBER, --结算金额(需传正负号)
                                    IN_DISAMOUNT_SUM   IN NUMBER, --折让金额(需传正负号)
                                    IN_DP_AMOUNT_SUM   IN NUMBER, --订金金额(需传正负号)
                                    IN_DP_DISAMOUNT_SUM IN NUMBER, --折让订金金额(需传正负号)
                                    IN_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 COMMON/DISCOUNT
                                    IN_ORDER_ID        IN NUMBER, --单据ID
                                    IN_ORDER_NUMBER    IN VARCHAR2, --单据号
                                    IN_SRC_TYPE        IN VARCHAR2, --来源类型
                                    IN_USER_ACCOUNT    IN VARCHAR2, --操作用户
                                    OUT_RESULT         IN OUT NUMBER, --返回错误ID
                                    OUT_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                    );
                                    
  PROCEDURE P_CREDIT_LOCK_HAND_TCC(IN_ENTITY_ID       IN NUMBER, --主体ID
                               IN_CUSTOMER_ID     IN NUMBER, --客户ID
                               IN_ACCOUNT_ID      IN NUMBER, --账户ID
                               IN_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                               IN_PROJ_NUMBER     IN VARCHAR2, --项目号
                               IN_AMOUNT_SUM      IN NUMBER, --结算金额(需传正负号)
                               IN_DISAMOUNT_SUM   IN NUMBER, --折让金额(需传正负号)
                               IN_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 COMMON/DISCOUNT
                               IN_ORDER_ID        IN NUMBER, --单据ID
                               IN_ORDER_NUMBER    IN VARCHAR2, --单据号
                               IN_DOWNPAY_RATE    IN NUMBER, --订金比例
                               IN_SRC_TYPE        IN VARCHAR2, --来源类型
                               IN_USER_ACCOUNT    IN VARCHAR2, --操作用户
                               OUT_RESULT         IN OUT NUMBER, --返回错误ID
                               OUT_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                               ,IN_TCC_ID         IN VARCHAR2 --分布式事务ID
                               ,IN_TCC_IDEMPOTENT_ID  IN VARCHAR2 --分布式幂等性ID
                               );
                               
                                  
  PROCEDURE P_CREDIT_LOCK_DETAIL_HAND_TCC(IN_ENTITY_ID       IN NUMBER, --主体ID
                                      IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                      IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                      IN_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                      IN_PROJ_NUMBER     IN VARCHAR2, --项目号
                                      IN_AMOUNT_SUM      IN NUMBER, --结算金额(需传正负号)
                                      IN_DISAMOUNT_SUM   IN NUMBER, --折让金额(需传正负号)
                                      IN_DP_AMOUNT_SUM   IN NUMBER, --订金金额(需传正负号)
                                      IN_DP_DISAMOUNT_SUM IN NUMBER, --折让订金金额(需传正负号)
                                      IN_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 COMMON/DISCOUNT
                                      IN_ORDER_ID        IN NUMBER, --单据ID
                                      IN_ORDER_NUMBER    IN VARCHAR2, --单据号
                                      IN_DOWNPAY_RATE    IN NUMBER, --订金比例（提货订单、计划订单使用）
                                      IN_SRC_TYPE        IN VARCHAR2, --来源类型
                                      IN_USER_ACCOUNT    IN VARCHAR2, --操作用户
                                      OUT_RESULT         IN OUT NUMBER, --返回错误ID
                                      OUT_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                      ,IN_TCC_ID         IN VARCHAR2 --分布式事务ID
                                      ,IN_TCC_IDEMPOTENT_ID  IN VARCHAR2 --分布式幂等性ID
                                      );
  
  PROCEDURE P_CREDIT_LOCK_TRANS_ADD_TCC(IN_ENTITY_ID       IN NUMBER, --主体ID
                                    IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                    IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                    IN_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                    IN_CREDIT_GROUP_ID IN NUMBER, --额度组ID
                                    IN_PROJ_NUMBER     IN VARCHAR2, --项目号
                                    IN_AMOUNT_SUM      IN NUMBER, --结算金额(需传正负号)
                                    IN_DISAMOUNT_SUM   IN NUMBER, --折让金额(需传正负号)
                                    IN_DP_AMOUNT_SUM   IN NUMBER, --订金金额(需传正负号)
                                    IN_DP_DISAMOUNT_SUM IN NUMBER, --折让订金金额(需传正负号)
                                    IN_DISCOUNT_TYPE   IN VARCHAR2, --折扣类型 COMMON/DISCOUNT
                                    IN_ORDER_ID        IN NUMBER, --单据ID
                                    IN_ORDER_NUMBER    IN VARCHAR2, --单据号
                                    IN_SRC_TYPE        IN VARCHAR2, --来源类型
                                    IN_USER_ACCOUNT    IN VARCHAR2, --操作用户
                                    OUT_RESULT         IN OUT NUMBER, --返回错误ID
                                    OUT_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                    ,IN_TCC_ID         IN VARCHAR2 --分布式事务ID
                                    ,IN_TCC_IDEMPOTENT_ID  IN VARCHAR2 --分布式幂等性ID
                                    );
end;
/

