create package body PKG_CREDIT_INTF_CCS is
  /*----------------------------------------------------------------
  *         包：PKG_CREDIT_INTF_CCS
  *   创建日期：2015-08-01
  *     创建者：梁颜明
  *   功能说明：处理信用模块与CCS的接口同步，需部署后授权给CCS
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  */ ----------------------------------------------------------------

  --V_NL             CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
  V_SEC_RESULT CONSTANT NUMBER := 0; --成功返回
  V_ERR_RESULT CONSTANT NUMBER := -1; --失败
  V_SUCCESS    CONSTANT VARCHAR2(10) := 'SUCCESS';
  V_BASE_EXCEPTION EXCEPTION; --自定义异常
  --------------------------------------------------------------------------------
  /*
  *   创建日期：2015-08-01
  *     创建者：梁颜明
  *   功能说明：CSS调用小电铺底单据从接口表同步到业务表的处理
  *
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE PRC_INTF_CREDIT_DELAYPAY_BILL(P_SRC_BILL_ID IN NUMBER, --接口铺底单据ID
                                          P_BILL_ID     OUT NUMBER, --铺底单据ID
                                          P_RESULT      IN OUT NUMBER, --返回错误ID
                                          P_ERR_MSG     IN OUT VARCHAR2 --返回错误信息
                                          ) IS
    V_CUSTOMER_ID   T_CREDIT_DELAYPAY.CUSTOMER_ID%TYPE;
    v_T_CUSTOMER_HEADER T_CUSTOMER_HEADER%rowtype;
    V_ACCOUNT_ID    T_CREDIT_DELAYPAY.ACCOUNT_ID%TYPE;
    V_COUNT         NUMBER;
    V_BILL_ID       NUMBER;
    V_PLANPAY_DATE  T_CREDIT_DELAYPAY.PLANPAY_DATE%Type; --计划还款日期
    entityGroupCode Varchar2(100); --主体组
    V_BILL_NUM      T_CREDIT_DELAYPAY.BILL_NUM%Type;
    V_BILL_NUM_NEW  T_CREDIT_DELAYPAY.BILL_NUM%Type;
  
    V_INTF_CREDIT INTF_CREDIT_DELAYPAY%rowtype;
    --V_EXIST_CREDIT_DELAYPAY_PASS   clob; --审批通过的有效铺底
    --V_EXIST_CREDIT_DELAYPAY_ZHIDAN clob; --制单、送审、不包括驳回
    V_CASH_RECEIPT          T_AR_CASH_RECEIPT_HEADERS%RowType; --收款单据
    V_CASH_RECEIPT_LINES    T_AR_CASH_RECEIPT_LINES%RowType; --收款单据大类行
    V_solution_pay_amount   number; --已解付金额
    V_unsolution_pay_amount number; --未解付金额
    V_delaypay_config_info  number; --铺底配置跨月天数
  
    --tianmzh 2016-06-14增加
    V_ACCOUNT_STATUS T_CUSTOMER_ACCOUNT.ACCOUNT_STATUS%TYPE; --账户状态
    V_S_HEAD_ID      T_CREDIT_DELAYPAY_HEAD.BILL_HEAD_ID%TYPE; --头表主键序列
    V_CASH_RECEIPT_CODE T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_CODE%TYPE; --收款单号
    VR_BD_ITEM_CLASS_RL T_BD_ITEM_CLASS_RELATION%ROWTYPE;--add by liangym2 2017-6-3
    V_DELAY_TYPE_ENABLED                                       UP_CODELIST.ENABLED%TYPE;--
    V_DELAY_TYPE_NAME                                          UP_CODELIST.CODE_NAME%TYPE;--
    old_bill_head_id  t_credit_delaypay_head.bill_head_id%TYPE;--之前的头ID
    old_bill_head_status t_credit_delaypay_head.bill_status%TYPE; --之前的头状态
    V_CREDIT_CROSS_MONTH_CONTROL varchar2(200);--跨越铺底参数值
    v_over_amount number; --逾期金额
    v_overdue_reamrk varchar2(300);--逾期备注
    v_credit_overdue_control varchar2(20);--逾期参数控制
  BEGIN
  
    select count(0)
      into V_COUNT
      from INTF_CREDIT_DELAYPAY t
     where t.source_bill_id = P_SRC_BILL_ID and t.due_flag is null;
     --作废之前的接口数据
   update INTF_CREDIT_DELAYPAY t
      set t.active_flag = 'N' 
    where t.source_bill_id = P_SRC_BILL_ID 
      and t.due_flag is not null;
    if 0 = V_COUNT then
      P_RESULT  := -20000;
      P_ERR_MSG := 'CCS接口表INTF_CREDIT_DELAYPAY不存在该条铺底记录：' || P_SRC_BILL_ID;
      --P_BILL_ID := V_INTF_CREDIT.Bill_Id;
      return;
    end if;
  
    if 1 < V_COUNT then
      P_RESULT  := -20000;
      P_ERR_MSG := 'CCS接口表INTF_CREDIT_DELAYPAY存在多条铺底记录：' || P_SRC_BILL_ID;
      --P_BILL_ID := V_INTF_CREDIT.Bill_Id;
      return;
    end if;
    
    select *
      into V_INTF_CREDIT
      from INTF_CREDIT_DELAYPAY t
     where t.source_bill_id = P_SRC_BILL_ID  and t.due_flag is null;
  
    if 0 = V_INTF_CREDIT.Due_Flag then
      P_RESULT  := V_INTF_CREDIT.Due_Flag;
      P_ERR_MSG := V_INTF_CREDIT.Due_Result;
      P_BILL_ID := V_INTF_CREDIT.Bill_Id;
      return;
    end if;
    --检查是否是撤回后重新过来的，重新过来的作废之前的重新建一单
    old_bill_head_id:=null;
    old_bill_head_status:=null;
    V_COUNT:=null;
    --查询是否是有非作废的以前的单据
    select count(1) into V_COUNT from t_credit_delaypay_head a
     where a.source_code = V_INTF_CREDIT.Source_Bill_Num
       and a.bill_status <> '5'
       and a.bill_status <> '6'
       and rownum = 1;
    P_RESULT  := V_SEC_RESULT;
    P_ERR_MSG := V_SUCCESS;
       --存在的化看是不是符合状态
     if V_COUNT>0 then 
       select a.bill_head_id, a.bill_status
      into old_bill_head_id, old_bill_head_status
      from t_credit_delaypay_head a
     where a.source_code = V_INTF_CREDIT.Source_Bill_Num
       and a.bill_status <> '5'
       and a.bill_status <> '6'
       and rownum = 1;
    if old_bill_head_id is not null then
      if  old_bill_head_status <> '4' then
        --不是驳回的说明再处理不能再次操作
        P_ERR_MSG := 'CIMS非驳回状态单据不能更新处理,请驳回或撤回后处理'||old_bill_head_id ; 
        P_RESULT  :=-20000;
  
      end if;
    end if;
    end if;  
   v_credit_overdue_control:= PKG_BD.F_GET_PARAMETER_VALUE('CREDIT_CUSTOMER_OVERDUE_CONTROL', V_INTF_CREDIT.Entity_Id , NULL, NULL);
   if v_credit_overdue_control='Y' then  
   begin
     --获取逾期金额信息
     select nvl(sum(m.pre_field_01), 0)
       into v_over_amount
       from (select rec.customer_code,
                    nvl(rec.pre_field_01, 0) as pre_field_01,
                    rank() over(partition by rec.account_id order by rec.bad_record_id desc) as rk
               from t_credit_bad_record rec
              where 1 = 1
                and rec.customer_code = v_intf_credit.customer_code
                and rec.active_flag(+) = '1'
                and rec.bad_record_type = '4'
                and rec.pay_date is null) m
      where m.rk = 1
      group by m.customer_code;
   exception
     when others then
       v_over_amount := 0;
   end;
   end if;
    BEGIN
      if P_RESULT = -20000 then 
       GOTO HERE;
      end if;
      --获取客户信息
      BEGIN
        SELECT T.*
          INTO  v_T_CUSTOMER_HEADER
          FROM  T_CUSTOMER_HEADER T
         WHERE T.CUSTOMER_CODE = V_INTF_CREDIT.CUSTOMER_CODE;
       if v_credit_overdue_control='Y' then  
           if(v_T_CUSTOMER_HEADER.Is_Locked='Y') then
            P_RESULT  := -20000;
            P_ERR_MSG := '客户'||V_INTF_CREDIT.CUSTOMER_CODE||'当前逾期'||v_T_CUSTOMER_HEADER.Current_Overdue_Count||'次，逾期金额为'||v_over_amount||'，信用检查不通过，已被冻结！';
            GOTO HERE;
           elsif  (v_T_CUSTOMER_HEADER.Is_Locked='N' and v_T_CUSTOMER_HEADER.Current_Overdue_Count>0) then
             v_overdue_reamrk:='客户'||V_INTF_CREDIT.CUSTOMER_CODE||'当前逾期'||v_T_CUSTOMER_HEADER.Current_Overdue_Count||'次，逾期金额为'||v_over_amount||'，请谨慎铺底!';
           end if;
       end if ;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT  := -20000;
          P_ERR_MSG := SUBSTR('根据客户编码查不到相应客户信息！请检查！' || SQLERRM,
                              1,
                              240);
          GOTO HERE;
      END;
      V_CUSTOMER_ID:=v_T_CUSTOMER_HEADER.Customer_Id;
   
      
      --获取账户ID
      BEGIN
        SELECT T.ACCOUNT_ID
          INTO V_ACCOUNT_ID
          FROM T_CUSTOMER_ACCOUNT T
         WHERE t.entity_id = V_INTF_CREDIT.entity_id
           and T.CUSTOMER_CODE = V_INTF_CREDIT.CUSTOMER_CODE
           AND T.ACCOUNT_CODE = V_INTF_CREDIT.ACCOUNT_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT  := -20000;
          P_ERR_MSG := SUBSTR('根据客户编码和账户编码查不到相应账户信息！请检查！' || SQLERRM,
                              1,
                              240);
          GOTO HERE;
      END;
    
      --------------------------------- tianmzh 修改 start ---------------------------------------------------
      --增加校验，账户状态为有效时，校验通过，否则校验不通过（即账户状态为冻结、无效时，校验不通过）
      V_ACCOUNT_STATUS := PKG_CUSTOMER_PUB.F_CHECK_CUST_HAVE_FREEZING_MSG('01',
                                                                          V_CUSTOMER_ID,
                                                                          V_INTF_CREDIT.ENTITY_ID,
                                                                          null,
                                                                          V_ACCOUNT_ID);
      IF V_ACCOUNT_STATUS <> 'SUCCESS' THEN
        P_RESULT  := -20000;
        P_ERR_MSG := SUBSTR(V_ACCOUNT_STATUS, 1, 240);
        GOTO HERE;
      END IF;
      --------------------------------- tianmzh 修改 end ---------------------------------------------------
    
      --------------------------------- liangym2 修改 start ---------------------------------------------------
      --INTF_CREDIT_DELAYPAY销司品牌字段SC_ITEM_BRAND如果不为空
      --，取T_BD_ITEM_CLASS_RELATION配置转换成CIMS营销大类，VR_BD_ITEM_CLASS_RL
     
     SELECT COUNT(0),MAX(CL.ENABLED),MAX(CL.CODE_NAME) INTO V_COUNT,V_DELAY_TYPE_ENABLED,V_DELAY_TYPE_NAME FROM UP_CODELIST CL WHERE CL.CODETYPE = 'credit_delaypay_type'
     AND CL.CODE_VALUE = V_INTF_CREDIT.DELAYPAY_TYPE;
     
     IF 0 = V_COUNT THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '铺底类型不存在';
       GOTO HERE;
     END IF;
     
     IF 1 = V_COUNT AND 0 <> V_DELAY_TYPE_ENABLED THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '铺底类型' || V_DELAY_TYPE_NAME || '在CIMS已失效';
       GOTO HERE;
     END IF;
     
      IF V_INTF_CREDIT.SC_ITEM_BRAND IS NOT NULL THEN
        BEGIN
          SELECT * INTO VR_BD_ITEM_CLASS_RL
          FROM T_BD_ITEM_CLASS_RELATION CR
          WHERE CR.SC_ENTITY_ID = V_INTF_CREDIT.ENTITY_ID
          AND CR.SALE_TYPE = 'M'
          AND CR.HQ_ITEM_CLASS_CODE = V_INTF_CREDIT.SALES_MAIN_TYPE
          AND CR.HQ_ITEM_BRAND = V_INTF_CREDIT.SC_ITEM_BRAND
          --对接财务系统是NC
          AND 'NC' = PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS',V_INTF_CREDIT.ENTITY_ID, NULL, NULL)
          --时间范围有效
          AND SYSDATE >= CR.BEGIN_DATE AND (CR.END_DATE IS NULL OR SYSDATE <= CR.END_DATE)
          ;
        EXCEPTION WHEN NO_DATA_FOUND THEN
          NULL;
        END;
      END IF;
      
      --------------------------------- liangym2 修改 end ---------------------------------------------------
    
      if 3 = V_INTF_CREDIT.Delaypay_Type then
        if V_INTF_CREDIT.Moneyorder_Number is NULL then
          P_RESULT  := -20000;
          P_ERR_MSG := '三方铺底票据号不能为空';
          GOTO HERE;
        end if;
        begin
          select *
            into V_CASH_RECEIPT
            from (select t.*
                    from T_AR_CASH_RECEIPT_HEADERS t
                   where t.cash_code = V_INTF_CREDIT.Moneyorder_Number
                     and exists
                   (select 1
                            from t_Ar_Receipt_Methods m
                           where m.receipt_method_id = t.receipt_method_id
                             and m.receipt_type = '3')
                   order by (case
                              when t.receipt_status_id = 3 and
                                   trunc(t.due_date) >= trunc(sysdate) then
                               0
                              else
                               1
                            end)
                  --
                  ) a
           where rownum = 1;
           V_CASH_RECEIPT_CODE := V_CASH_RECEIPT.CASH_RECEIPT_CODE;
        Exception
          When Others Then
            P_RESULT  := -20000;
            P_ERR_MSG := '不存在三方收款票据号';
            GOTO HERE;
        End;
        IF V_CASH_RECEIPT.DISCOUNT_TYPE <> 'COMMON' THEN
          P_RESULT  := -20000;
          P_ERR_MSG := '三方收款票据的折让方式为' || V_CASH_RECEIPT.DISCOUNT_TYPE || '，只允许常规到款的三方承兑才能做铺底';
          GOTO HERE;
        END IF;
        if V_INTF_CREDIT.Account_Code <> V_CASH_RECEIPT.Account_Code then
          P_RESULT  := -20000;
          P_ERR_MSG := '三方收款票据所属中心的客户账户：' || V_CASH_RECEIPT.Account_Code ||
                       '与申请的铺底客户账户不一致';
          GOTO HERE;
        end if;
        if 3 <> V_CASH_RECEIPT.RECEIPT_STATUS_ID then
          P_RESULT  := -20000;
          P_ERR_MSG := '三方收款票据不是已确认状态';
          GOTO HERE;
        end if;
        if trunc(V_CASH_RECEIPT.due_date) < trunc(sysdate) then
          P_RESULT  := -20000;
          P_ERR_MSG := '三方收款票据已到期';
          GOTO HERE;
        end if;
        if V_INTF_CREDIT.End_Date > V_CASH_RECEIPT.Due_Date then
          P_RESULT  := -20000;
          P_ERR_MSG := '三方铺底终止日期不能超过三方票据到期日期';
          GOTO HERE;
        end if;
        begin
          select *
            into V_CASH_RECEIPT_LINES
            from T_AR_CASH_RECEIPT_LINES t
           where t.cash_receipt_id = V_CASH_RECEIPT.Cash_Receipt_Id
             and t.sales_main_type_code = DECODE(VR_BD_ITEM_CLASS_RL.ITEM_CLASS_RELATION_ID
             ,NULL,V_INTF_CREDIT.Sales_Main_Type,VR_BD_ITEM_CLASS_RL.SC_ITEM_CLASS_CODE);--add by liangym2 2017-6-3
        Exception
          When Others Then
            P_RESULT  := -20000;
            P_ERR_MSG := '三方票据不存在大类' || (CASE WHEN VR_BD_ITEM_CLASS_RL.ITEM_CLASS_RELATION_ID IS NULL THEN
            V_INTF_CREDIT.Sales_Main_Type ELSE VR_BD_ITEM_CLASS_RL.SC_ITEM_CLASS_CODE END)
            || (CASE WHEN VR_BD_ITEM_CLASS_RL.ITEM_CLASS_RELATION_ID IS NULL THEN
            '' ELSE '[CCS大类：' || VR_BD_ITEM_CLASS_RL.HQ_ITEM_CLASS_CODE || ']' END) ||--add by liangym2 2017-6-3
                         '的收款明细';
            GOTO HERE;
        End;
        select nvl(sum(nvl(p.solution_pay_amount, 0)), 0)
          into V_solution_pay_amount
          from t_ar_acce_solu_pay p
         where p.cash_receipt_lines_id =
               V_CASH_RECEIPT_LINES.Cash_Receipt_Lines_Id;
        V_unsolution_pay_amount := (V_CASH_RECEIPT_LINES.Amount -
                                   V_solution_pay_amount);
        if 0 >= V_unsolution_pay_amount then
          P_RESULT  := -20000;
          P_ERR_MSG := '三方收款未解付金额不足';
          GOTO HERE;
        end if;
        if V_INTF_CREDIT.Requis_Amount > V_unsolution_pay_amount then
          P_RESULT  := -20000;
          P_ERR_MSG := '申请金额不能超过三方收款未解付金额' || V_unsolution_pay_amount;
          GOTO HERE;
        end if;
       
      end if;
    
      V_delaypay_config_info := pkg_credit_tools.FUN_GET_CONFIG_INFO(P_ENTITY_ID     => V_INTF_CREDIT.Source_Entity_Id,
                                                                     P_BILL_TYPE_ID  => V_INTF_CREDIT.Bill_Type_Id,
                                                                     P_DELAYPAY_TYPE => V_INTF_CREDIT.Delaypay_Type,
                                                                     P_FLAG          => 1);
      if 0 < nvl(V_delaypay_config_info, 0) and
         V_delaypay_config_info <
         (trunc(V_INTF_CREDIT.End_Date) - trunc(V_INTF_CREDIT.Requis_Date)) then
        P_RESULT  := -20000;
        P_ERR_MSG := '铺底申请的间隔不能超过' || V_delaypay_config_info || '天';
        GOTO HERE;
      end if;
    
      --获取计划还款日期
      entityGroupCode := pkg_bd.F_GET_PARAMETER_VALUE('ar_entity_group',
                                                      V_INTF_CREDIT.Entity_Id,
                                                      null,
                                                      null);
       --获取系统参数
        V_CREDIT_CROSS_MONTH_CONTROL:='';
        V_CREDIT_CROSS_MONTH_CONTROL:= PKG_BD.F_GET_PARAMETER_VALUE('CREDIT_CROSS_MONTH_CONTROL', V_INTF_CREDIT.Entity_Id, NULL, NULL);                                               
        --校验铺底是否交叉
        If 3 <> V_INTF_CREDIT.Delaypay_Type Then
          --1：常规铺底
          Begin
            Select T.Bill_Num || ' ' || T.ACCOUNT_CODE
              Into V_Bill_Num
              From T_Credit_Delaypay t
             Where T.Entity_Id = V_INTF_CREDIT.Entity_Id
               And T.Customer_Code = V_INTF_CREDIT.Customer_Code
               And T.Sales_Main_Type = DECODE(VR_BD_ITEM_CLASS_RL.ITEM_CLASS_RELATION_ID
             ,NULL,V_INTF_CREDIT.Sales_Main_Type,VR_BD_ITEM_CLASS_RL.SC_ITEM_CLASS_CODE)--add by liangym2 2017-6-3
               And T.Account_Code = V_INTF_CREDIT.Account_Code
               And ((V_INTF_CREDIT.Requis_Date >= T.Requis_Date And
                   V_INTF_CREDIT.Requis_Date <= T.End_Date) Or
                   (V_INTF_CREDIT.End_Date >= T.Requis_Date And
                   V_INTF_CREDIT.End_Date <= T.End_Date))
               And T.Bill_Status <> '5'
               And T.Bill_Status <> '6' 
               And t.delaypay_type in (V_CREDIT_CROSS_MONTH_CONTROL)
               AND NOT EXISTS (
               SELECT 1 FROM V_UP_CODELIST CL WHERE CL.ENTITY_ID = V_INTF_CREDIT.ENTITY_ID
               AND (CL.CODE_VALUE = V_INTF_CREDIT.Delaypay_Type
               OR CL.CODE_VALUE = t.delaypay_type
               ) AND CL.CODETYPE = 'credit_cross_delaypay_type'
               )
               ; 
          Exception
            When Others Then
              Null;
          End;
          If V_Bill_Num Is Not Null Then
            P_RESULT  := -20000;
            P_ERR_MSG := SUBSTR('单据日期跟CIMS中单据日期交叉，对应单据号、账户编码：【' || V_Bill_Num || '】！',
                                1,
                                240);
            GOTO HERE;
          End If;
        End If;
        V_PLANPAY_DATE := last_day(V_INTF_CREDIT.end_date);
       
       
      
        --如果单据编号不为空，则说明有cims有日期交叉单据存在
        If V_Bill_Num Is Not Null Then
          P_RESULT  := -20000;
          P_ERR_MSG := SUBSTR('单据日期跟CIMS中单据日期交叉，对应单据号、账户编码：【' || V_Bill_Num || '】！',
                              1,
                              240);
          GOTO HERE;
        End If;
        V_PLANPAY_DATE := V_INTF_CREDIT.end_date;
   
    
     
    
      --获取铺底单据ID（C-IMS）
      BEGIN
         if old_bill_head_id is null then 
        SELECT s_credit_delaypay.nextval INTO V_BILL_ID FROM DUAL;
         --获取铺底单据编码（C-IMS） 
        V_BILL_NUM_NEW := pkg_bd.F_GET_BILL_NO(P_BILL_TYPE  => 'CreditDelayBillNum',
                                               P_PREFIX_ADD => Null,
                                               P_ENTITY_ID  => V_INTF_CREDIT.entity_id,
                                               P_USER_ID    => Null);
        else 
          --更新的化用之前的ID
           SELECT a.bill_id,a.bill_num into V_BILL_ID, V_BILL_NUM_NEW from t_credit_delaypay a where a.bill_head_id=old_bill_head_id and rownum=1; 
        end if;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT  := -20000;
          P_ERR_MSG := SUBSTRB('从序列获取铺底单据编码出错！请检查！' || SQLERRM,
                               1,
                               240);
          GOTO HERE;
      END;
     
      --插入铺底单据信息
      BEGIN
        --是新的单据则插入
  
         if old_bill_head_id is null then      
        INSERT INTO t_credit_delaypay --铺底单据信息表
          (bill_id, --单据ID
           entity_id, --业务主体
           bill_num, --铺底单据号
           bill_status, --单据状态（1：制单；2：送审；3：已审；4：驳回；5：作废；6：强制到期）
           create_by, --制单人
           creation_time, --制单时间
           bill_date, --单据日期
           bill_type_id, --单据类型（1：常规铺底单据；2：超额铺底单据；3：临时铺底单据）
           customer_id, --客户ID
           customer_code, --客户编码
           customer_name, --客户名称
           account_id, --账户ID
           account_code, --账户编码
           account_name, --账户名称
           sales_center_id, --营销中心ID
           sales_center_code, --营销中心编码
           sales_center_name, --营销中心名称
           sales_region_id, --销售区域ID
           sales_region_code, --销售区域编码
           sales_region_name, --销售区域名称
           sales_main_type, --营销大类
           sales_year_id, --销售年度ID
           delaypay_type, --铺底类型（1：铺底（跨月）；2：铺底（不跨月）；3：三方铺底；4：折让铺底）
           requis_date, --申请日期
           end_date, --终止日期
           planpay_date, --还款日期
           requis_amount, --申请金额
           approval_amount, --审批金额
           moneyorder_number, --三方承兑票号
           deposit_cash, --保证金
           actualpay_date, --实际还款日期
           pay_date, --还清日期
           payed_flag, --是否还清（1：是；0：否）
           cancel_by, --作废人
           cancel_time, --作废时间
           due_by, --到期操作员
           due_time, --到期时间
           remark, --备注
           delay_flag, --是否延期（1：是；0：否）
           delay_date, --延期日期
           delay_amount, --延期金额
           delay_reson, --延期原因
           transaction_amount, --未核销金额
           bring_accrual_amount, --产生利息金额
           bring_accrual_days, --产生利息天数
           accrual_amount, --利息金额
           overdue_flag, --是否逾期（1：是；0：否）
           last_updated_by, --最后修改人
           last_update_date, --最后修改日期
           last_approval_time, --最终审批时间
           cash_receipt_code   --收款单号
           
           )
        VALUES
          (V_BILL_ID, --单据ID
           V_INTF_CREDIT.ENTITY_ID, --业务主体
           --V_INTF_CREDIT.SOURCE_BILL_NUM,   --铺底单据号
           V_BILL_NUM_NEW, --铺底单据号
           V_INTF_CREDIT.BILL_STATUS, --单据状态（1：制单；2：送审；3：已审；4：驳回；5：作废；6：强制到期）
           V_INTF_CREDIT.CREATE_BY, --制单人
           V_INTF_CREDIT.CREATION_TIME, --制单时间
           V_INTF_CREDIT.BILL_DATE, --单据日期
           V_INTF_CREDIT.BILL_TYPE_ID, --单据类型（1：常规铺底单据；2：超额铺底单据；3：临时铺底单据）
           V_CUSTOMER_ID, --客户ID
           V_INTF_CREDIT.CUSTOMER_CODE, --客户编码
           V_INTF_CREDIT.CUSTOMER_NAME, --客户名称
           V_ACCOUNT_ID, --账户ID
           V_INTF_CREDIT.ACCOUNT_CODE, --账户编码
           V_INTF_CREDIT.ACCOUNT_NAME, --账户名称
           TO_NUMBER(PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID,
                                                                   V_CUSTOMER_ID,
                                                                   V_ACCOUNT_ID,
                                                                   1)), --营销中心ID
           PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID,
                                                         V_CUSTOMER_ID,
                                                         V_ACCOUNT_ID,
                                                         2), --营销中心编码
           PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID,
                                                         V_CUSTOMER_ID,
                                                         V_ACCOUNT_ID,
                                                         3), --营销中心名称
           TO_NUMBER(PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID,
                                                                   V_CUSTOMER_ID,
                                                                   V_ACCOUNT_ID,
                                                                   4)), --销售区域ID
           PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID,
                                                         V_CUSTOMER_ID,
                                                         V_ACCOUNT_ID,
                                                         5), --销售区域编码
           PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID,
                                                         V_CUSTOMER_ID,
                                                         V_ACCOUNT_ID,
                                                         6), --销售区域名称
           --add by liangym2 2017-6-3
           DECODE(VR_BD_ITEM_CLASS_RL.ITEM_CLASS_RELATION_ID
             ,NULL,V_INTF_CREDIT.SALES_MAIN_TYPE,VR_BD_ITEM_CLASS_RL.SC_ITEM_CLASS_CODE), --营销大类
           NULL, --销售年度ID
           V_INTF_CREDIT.delaypay_type, --铺底类型（1：铺底（跨月）；2：铺底（不跨月）；3：三方铺底；4：折让铺底）
           V_INTF_CREDIT.REQUIS_DATE, --申请日期
           V_INTF_CREDIT.END_DATE, --终止日期
           V_PLANPAY_DATE, --还款日期
           V_INTF_CREDIT.REQUIS_AMOUNT, --申请金额
           NULL, --审批金额
           V_INTF_CREDIT.MONEYORDER_NUMBER, --三方承兑票号
           V_INTF_CREDIT.DEPOSIT_CASH, --保证金
           NULL, --实际还款日期
           NULL, --还清日期
           '0', --是否还清（1：是；0：否）
           NULL, --作废人
           NULL, --作废时间
           NULL, --到期操作员
           NULL, --到期时间
           '来源CCS，来源单号:' || V_INTF_CREDIT.SOURCE_BILL_NUM||V_INTF_CREDIT.Remark, --备注
           '0', --是否延期（1：是；0：否）
           NULL, --延期日期
           NULL, --延期金额
           NULL, --延期原因
           NULL, --未核销金额
           NULL, --产生利息金额
           NULL, --产生利息天数
           NULL, --利息金额
           NULL, --是否逾期（1：是；0：否）
           V_INTF_CREDIT.CREATE_BY, --最后修改人
           V_INTF_CREDIT.CREATION_TIME, --最后修改日期
           NULL, --最终审批时间
           V_CASH_RECEIPT_CODE
         
           );
             else
              update t_credit_delaypay set 
              bill_status      =  V_INTF_CREDIT.BILL_STATUS                    , --单据状态（1：制单；2：送审；3：已审；4：驳回；5：作废；6：强制到期）
              create_by        =  V_INTF_CREDIT.CREATE_BY                    , --制单人
              creation_time    =  V_INTF_CREDIT.CREATION_TIME                    , --制单时间
              bill_date        =  V_INTF_CREDIT.BILL_DATE                    , --单据日期
              bill_type_id     =  V_INTF_CREDIT.BILL_TYPE_ID                    , --单据类型（1：常规铺底单据；2：超额铺底单据；3：临时铺底单据）
              customer_id      =  V_CUSTOMER_ID                                , --客户ID
              customer_code    =  V_INTF_CREDIT.CUSTOMER_CODE                    , --客户编码
              customer_name    =  V_INTF_CREDIT.CUSTOMER_NAME                    , --客户名称
              account_id       =  V_ACCOUNT_ID                                , --账户ID
              account_code     =  V_INTF_CREDIT.ACCOUNT_CODE                    , --账户编码
              account_name     =  V_INTF_CREDIT.ACCOUNT_NAME                    , --账户名称                                                                                                      
              sales_center_id     = TO_NUMBER(PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID, V_CUSTOMER_ID, V_ACCOUNT_ID, 1)),                                            
              sales_center_code   = PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID, V_CUSTOMER_ID,  V_ACCOUNT_ID, 2),                                                      
              sales_center_name   = PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID, V_CUSTOMER_ID,  V_ACCOUNT_ID, 3), --营销中心名称                                       
              sales_region_id     = TO_NUMBER(PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID, V_CUSTOMER_ID, V_ACCOUNT_ID,  4)), --销售区域ID                              
              sales_region_code   = PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID, V_CUSTOMER_ID, V_ACCOUNT_ID, 5), --销售区域编码                                        
              sales_region_name   = PKG_CREDIT_INTF_DUE.FUN_GET_SALES_CENTER_INTO(V_INTF_CREDIT.ENTITY_ID,  V_CUSTOMER_ID,  V_ACCOUNT_ID,  6), --销售区域名称                                     
              sales_main_type     = DECODE(VR_BD_ITEM_CLASS_RL.ITEM_CLASS_RELATION_ID ,NULL  ,V_INTF_CREDIT.SALES_MAIN_TYPE,VR_BD_ITEM_CLASS_RL.SC_ITEM_CLASS_CODE)   ,                            
              sales_year_id       = NULL  ,                                                        
              delaypay_type       = V_INTF_CREDIT.delaypay_type  ,                                
              requis_date         = V_INTF_CREDIT.REQUIS_DATE  , --申请日期                       
              end_date            = V_INTF_CREDIT.END_DATE  , --终止日期                          
              planpay_date        = V_PLANPAY_DATE , --还款日期                                   
              requis_amount       = V_INTF_CREDIT.REQUIS_AMOUNT , --申请金额                      
              approval_amount     = NULL , --审批金额                                             
              moneyorder_number   = V_INTF_CREDIT.MONEYORDER_NUMBER , --三方承兑票号              
              deposit_cash        = V_INTF_CREDIT.DEPOSIT_CASH , --保证金                         
              actualpay_date      = NULL , --实际还款日期                                         
              pay_date            = NULL , --还清日期                                             
              payed_flag          = '0' , --是否还清（1：是；0：否）                              
              cancel_by           = NULL , --作废人                                               
              cancel_time         = NULL , --作废时间                                             
              due_by              = NULL , --到期操作员                                           
              due_time            = NULL , --到期时间                                             
              remark              = '来源CCS，来源单号:' || V_INTF_CREDIT.SOURCE_BILL_NUM||nvl(V_INTF_CREDIT.Remark,'') , 
              delay_flag          = '0' , --是否延期（1：是；0：否）                                              
              delay_date          = NULL , --延期日期                               
              delay_amount        = NULL , --延期金额                               
              delay_reson         = NULL , --延期原因                               
              transaction_amount  = NULL , --未核销金额                             
              bring_accrual_amount= NULL , --产生利息金额                           
              bring_accrual_days  = NULL , --产生利息天数                           
              accrual_amount      = NULL , --利息金额                               
              overdue_flag        = NULL , --是否逾期（1：是；0：否）               
              last_updated_by     = V_INTF_CREDIT.CREATE_BY , --最后修改人          
              last_update_date    = V_INTF_CREDIT.CREATION_TIME , --最后修改日期    
              last_approval_time  = NULL , --最终审批时间                           
              cash_receipt_code 	= V_CASH_RECEIPT_CODE	
              where 		bill_head_id	=	 old_bill_head_id;
 
        end if;
       P_BILL_ID := V_BILL_ID;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT  := -20000;
          P_ERR_MSG := SUBSTR('向业务表插入铺底单据信息出错！请检查！' || SQLERRM,
                              1,
                              240);
          GOTO HERE;
      END;
    
      --检查是否有附件信息
      BEGIN
        SELECT COUNT(1)
          INTO V_COUNT
          FROM INTF_CREDIT_DELAYPAY_ATT T
         WHERE T.SOURCE_BILL_ID = V_INTF_CREDIT.SOURCE_BILL_ID and t.bill_id is null;
      EXCEPTION
        WHEN OTHERS THEN
          P_RESULT  := -20000;
          P_ERR_MSG := SUBSTRB('查询接口铺底单据是否存在附件信息出错！请检查！' || SQLERRM,
                               1,
                               240);
          GOTO HERE;
      END;
      if old_bill_head_id is not null then 
      --作废之前的附件
        delete from  mdp_business_file a  where  a.business_id='creditDP' || V_BILL_NUM_NEW;
        delete from  IMS_FILEINFO_INTERFACE a   where  a.business_id='creditDP' || V_BILL_NUM_NEW;
        delete from  mdp_business_ref a   where  a.business_id='creditDP' || V_BILL_NUM_NEW;
        --作废之前的附件
        update INTF_CREDIT_DELAYPAY_ATT a set a.active_flag='N' where a.bill_id is not null and a.source_bill_id=V_INTF_CREDIT.SOURCE_BILL_ID ;
     end if;  
      --插入附件信息
      IF V_COUNT > 0 THEN
 
        BEGIN
        
          INSERT INTO IMS_FILEINFO_INTERFACE -- 铺底附件信息表
            (id,
             business_id,
             business_type,
             file_path,
             file_name,
             created_date,
             exc_date,
             exc_finish,
             fcount,
             remark) --修改日期
            SELECT SEQ_IMS_FILEINFO.Nextval, --附件ID 
                   'creditDP' || V_BILL_NUM_NEW,
                   'creditDelayCode',
                   T.ATT_PATH, --附件路径
                   t.Att_Name, --附件名称
                   Sysdate, --创建日期
                   Null,
                   Null,
                   Null,
                   Null
              FROM INTF_CREDIT_DELAYPAY_ATT T
             WHERE T.SOURCE_BILL_ID = V_INTF_CREDIT.SOURCE_BILL_ID and t.bill_id is null;
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT  := -20000;
            P_ERR_MSG := SUBSTR('向业务表插入铺底单据附件信息出错！请检查！' || SQLERRM,
                                1,
                                240);
            GOTO HERE;
        END;
   END IF;
          /*
        *  1、行表数据转头表数据；2、更新行表单据头ID；
        */
        BEGIN
          if old_bill_head_id   is null then  
         --获取头表主键序列
          SELECT S_CREDIT_DELAYPAY_HEAD.NEXTVAL INTO V_S_HEAD_ID FROM DUAL;
          --查询行表，插入头表
           INSERT INTO CIMS.T_CREDIT_DELAYPAY_HEAD H
            (BILL_HEAD_ID,
             BILL_NUM,
             ENTITY_ID,
             BILL_STATUS,
             CREATE_BY,
             CREATION_TIME,
             BILL_DATE,
             BILL_TYPE_ID,
             DELAYPAY_TYPE,
             REQUIS_DATE,
             END_DATE,
             PLANPAY_DATE,
             LAST_APPROVAL_TIME,
             HEAD_REMARK,
             VERSION,
             UPDATED_BY,
             UPDATED_TIME,
             APPENDIX_ID,
             SOURCE_SYS,
             SOURCE_CODE )
            SELECT V_S_HEAD_ID,
                   T.BILL_NUM,
                   T.ENTITY_ID,
                   T.BILL_STATUS,
                   T.CREATE_BY,
                   T.CREATION_TIME,
                   T.BILL_DATE,
                   T.BILL_TYPE_ID,
                   T.DELAYPAY_TYPE,
                   T.REQUIS_DATE,
                   T.END_DATE,
                   T.PLANPAY_DATE,
                   T.LAST_APPROVAL_TIME,
                   T.REMARK||v_overdue_reamrk,
                   0,
                   T.LAST_UPDATED_BY,
                   T.LAST_UPDATE_DATE,
                   'creditDP' || T.BILL_NUM,
                   'CCS',
                   V_INTF_CREDIT.SOURCE_BILL_NUM 
              FROM CIMS.T_CREDIT_DELAYPAY T
             WHERE T.BILL_ID = V_BILL_ID;
               --更新行表数据
            UPDATE CIMS.T_CREDIT_DELAYPAY TL
               SET TL.BILL_HEAD_ID = V_S_HEAD_ID
             WHERE TL.BILL_ID = V_BILL_ID and tl.bill_head_id is null ;
           else 
             --驳回后再推送更新行表
           update  CIMS.T_CREDIT_DELAYPAY_HEAD H set
            ( 
             ENTITY_ID,
             BILL_STATUS,
             CREATE_BY,
             CREATION_TIME,
             BILL_DATE,
             BILL_TYPE_ID,
             DELAYPAY_TYPE,
             REQUIS_DATE,
             END_DATE,
             PLANPAY_DATE,
             LAST_APPROVAL_TIME,
             HEAD_REMARK,
             VERSION,
             UPDATED_BY,
             UPDATED_TIME,
             APPENDIX_ID,
             SOURCE_SYS,
             SOURCE_CODE )=
            (SELECT  
                   T.ENTITY_ID,
                   T.BILL_STATUS,
                   T.CREATE_BY,
                   T.CREATION_TIME,
                   T.BILL_DATE,
                   T.BILL_TYPE_ID,
                   T.DELAYPAY_TYPE,
                   T.REQUIS_DATE,
                   T.END_DATE,
                   T.PLANPAY_DATE,
                   T.LAST_APPROVAL_TIME,
                   T.REMARK||v_overdue_reamrk,
                   0,
                   T.LAST_UPDATED_BY,
                   T.LAST_UPDATE_DATE,
                   'creditDP' || T.BILL_NUM,
                   'CCS',
                   V_INTF_CREDIT.SOURCE_BILL_NUM 
              FROM CIMS.T_CREDIT_DELAYPAY T
             WHERE T.BILL_ID = V_BILL_ID)  where h.bill_head_id=old_bill_head_id ;
            end if;
          
        EXCEPTION
          WHEN OTHERS THEN
            P_RESULT  := -20000;
            P_ERR_MSG := SUBSTR('向业务头表插入铺底单据信息出错！请检查！' || SQLERRM,
                                1,
                                240);
            GOTO HERE;
        END;
      --更新单据信息读取状态
      <<HERE>>
      UPDATE INTF_CREDIT_DELAYPAY T
         SET T.BILL_ID    = DECODE(P_RESULT, V_SEC_RESULT, V_BILL_ID),
             T.DUE_FLAG   = DECODE(P_RESULT,
                                   V_SEC_RESULT,
                                   V_SEC_RESULT,
                                   V_ERR_RESULT),
             T.DUE_RESULT = P_ERR_MSG
       WHERE T.SOURCE_BILL_ID = V_INTF_CREDIT.SOURCE_BILL_ID and t.due_flag is null;
      UPDATE INTF_CREDIT_DELAYPAY_ATT T
         SET T.BILL_ID = decode(P_RESULT, V_SEC_RESULT, V_BILL_ID)
       WHERE T.SOURCE_BILL_ID = V_INTF_CREDIT.SOURCE_BILL_ID and t.bill_id is null;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        P_RESULT  := -20000;
        P_ERR_MSG := SUBSTR('读取铺底单据信息出错！请检查！' || SQLERRM,
                            1,
                            240);
        --更新单据信息读取状态
        UPDATE INTF_CREDIT_DELAYPAY T
           SET T.BILL_ID = NULL, 
                T.DUE_FLAG = V_ERR_RESULT,
               T.DUE_RESULT = P_ERR_MSG
         WHERE T.SOURCE_BILL_ID = V_INTF_CREDIT.SOURCE_BILL_ID;
    END;
  END; --
end PKG_CREDIT_INTF_CCS;
/

