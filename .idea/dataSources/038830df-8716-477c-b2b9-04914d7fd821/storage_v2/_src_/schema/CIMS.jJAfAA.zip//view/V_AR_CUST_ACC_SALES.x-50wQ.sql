create view V_AR_CUST_ACC_SALES as
select a.sales_main_type_id, d.class_name sales_main_type_name,
          a.sales_main_type_code, b.erp_ou_id, c.code_name erp_ou_name,
          v.customer_id, v.customer_code, v.customer_name,
          v.entity_id, v.account_id, v.account_code, v.account_name, v.account_status,
          v.sales_center_id, v.sales_center_code,
          v.sales_center_name
     from v_customer_account_salecenter v,
          t_customer_sales_main_type a,
          t_ar_ou_relation b,
          up_codelist c,
          t_bd_item_class d
    where a.entity_id = v.entity_id
      and a.custom_id = v.customer_id
      and v.entity_id = b.entity_id
      and v.sales_center_id = b.sales_center_id
      and v.entity_id = b.entity_id
      and c.codetype = 'ar_ou_id'
      and c.code_value = b.erp_ou_id
      and v.account_status = '1'
      and d.active_flag = 'Y'
      and d.class_code = a.sales_main_type_code
      and d.entity_id = a.entity_id
/

comment on column V_AR_CUST_ACC_SALES.SALES_MAIN_TYPE_ID is '营销大类Id'
/

comment on column V_AR_CUST_ACC_SALES.SALES_MAIN_TYPE_NAME is '营销大类名称'
/

comment on column V_AR_CUST_ACC_SALES.SALES_MAIN_TYPE_CODE is '营销大类编码'
/

comment on column V_AR_CUST_ACC_SALES.ERP_OU_ID is 'erpOuId'
/

comment on column V_AR_CUST_ACC_SALES.ERP_OU_NAME is 'erpOu名称'
/

comment on column V_AR_CUST_ACC_SALES.CUSTOMER_ID is '客户Id'
/

comment on column V_AR_CUST_ACC_SALES.CUSTOMER_CODE is '客户编码'
/

comment on column V_AR_CUST_ACC_SALES.CUSTOMER_NAME is '客户名称'
/

comment on column V_AR_CUST_ACC_SALES.ENTITY_ID is '主体id'
/

comment on column V_AR_CUST_ACC_SALES.ACCOUNT_ID is '账户id'
/

comment on column V_AR_CUST_ACC_SALES.ACCOUNT_CODE is '账户编码'
/

comment on column V_AR_CUST_ACC_SALES.ACCOUNT_NAME is '账户名称'
/

comment on column V_AR_CUST_ACC_SALES.SALES_CENTER_ID is '营销中心id'
/

comment on column V_AR_CUST_ACC_SALES.SALES_CENTER_CODE is '营销中心编码'
/

comment on column V_AR_CUST_ACC_SALES.SALES_CENTER_NAME is '营销中心名称'
/

