create PACKAGE PKG_PLN_PRODUCING_AREA_ALLOT IS

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-09-09 10:35:00
  -- Purpose : 初次产地分解
  ----------------------------------------------------------------------
  PROCEDURE P_PRODUCING_AREA_ALLOT_1ST(P_ORDER_TYPE_ID IN NUMBER, --订单类型ID
                                       P_PERIOD_ID     IN NUMBER, --订单周期ID
                                       P_BATCH_ID      IN NUMBER, --批次ID
                                       P_ENTITY_ID     IN NUMBER, --主体ID
                                       P_CREATED_BY    IN VARCHAR2, --创建人
                                       P_RESULT        OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-09-17 14:16:00
  -- Purpose : 二次产地分解
  ----------------------------------------------------------------------
  PROCEDURE P_PRODUCING_AREA_ALLOT_2ND(P_ORDER_TYPE_ID IN NUMBER, --订单类型ID
                                       P_PERIOD_ID     IN NUMBER, --订单周期ID
                                       P_BATCH_ID      IN NUMBER, --批次ID
                                       P_ENTITY_ID     IN NUMBER, --主体ID
                                       P_CREATED_BY    IN VARCHAR2, --创建人
                                       P_RESULT        OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-09-27 14:16:00
  -- Purpose : 三次产地分解
  ----------------------------------------------------------------------
  PROCEDURE P_PRODUCING_AREA_ALLOT_3RD(P_ORDER_TYPE_ID           IN NUMBER,   --订单类型ID
                                       P_PERIOD_ID               IN NUMBER,   --订单周期ID
                                       P_BATCH_ID                IN NUMBER,   --批次ID
                                       P_OLD_PRODUCING_AREA_CODE IN VARCHAR2, --原产地
                                       P_NEW_PRODUCING_AREA_CODE IN VARCHAR2, --目的产地
                                       P_ADJUST_QTY              IN NUMBER,   --调整数量
                                       P_ENTITY_ID               IN NUMBER,   --主体ID
                                       P_CREATED_BY              IN VARCHAR2, --创建人
                                       P_RESULT                  OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-11-13 14:26:00
  -- Purpose : 校验调整数量
  ----------------------------------------------------------------------
  PROCEDURE P_CHECK_ADJUST_QTY(P_ORDER_TYPE_ID           IN NUMBER,   --订单类型ID
                               P_PERIOD_ID               IN NUMBER,   --订单周期ID
                               P_BATCH_ID                IN NUMBER,   --批次ID
                               P_OLD_PRODUCING_AREA_CODE IN VARCHAR2, --原产地
                               P_NEW_PRODUCING_AREA_CODE IN VARCHAR2, --目的产地
                               P_ADJUST_QTY              IN NUMBER,   --调整数量
                               P_ENTITY_ID               IN NUMBER,   --主体ID
                               P_CREATED_BY              IN VARCHAR2, --创建人
                               P_RESULT                  OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : Lizhen
  -- Created : 2014-11-18 16:12:00
  -- Purpose : 根据汇总订单行，生成产品分解行信息
  --modi by lizhen 2017-06-27增加按中心进行产品分解批量数据调整
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_ITEM_ALLOT(P_COLL_ORD_HEAD_ID    IN NUMBER, --汇总头ID
                                P_COLL_ORD_LINE_ID    IN NUMBER, --汇总行ID
                                P_PRODUCING_AREA_LIST IN VARCHAR2, --产地ID更表，为NULL表示评审所有产地
                                P_ENTITY_ID           IN NUMBER, --主体ID
                                P_USER_CODE           IN VARCHAR2, --创建人
                                P_RESULT              OUT Varchar2
                                );

  ---------------------------------------------------------------------
  -- Author  : Lizhen
  -- Created : 2017-06-27 20:12:00
  -- Purpose : 根据汇总头ID、中心ID生成中心产品分解明细数据
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_CENTER_ITEM_ALLOT(IN_COLL_ORD_HEAD_ID    IN NUMBER, --汇总头ID
                                       IN_SALES_CENTER_ID     IN NUMBER, --汇总行ID
                                       IN_PRODUCING_AREA_LIST IN VARCHAR2, --产地列表
                                       IN_ENTITY_ID           IN NUMBER, --主体ID
                                       IN_USER_CODE           IN VARCHAR2, --创建人
                                       OUT_RESULT             OUT VARCHAR2,
                                       OUT_ROWCOUNT           OUT NUMBER    --返回处理成功行数
                                       );
                                       
  ----------------------------------------------------------------------
  -- Author  : Lizhen
  -- Created : 2014-11-18 16:12:00
  -- Purpose : 根据汇总订单行，更新订单行已评审数量，行无产地对应数据时生成新的订单行
  ----------------------------------------------------------------------
  Procedure P_UPD_ITEM_ALLOT(P_COLL_ORD_HEAD_ID     IN NUMBER,  --汇总头ID
                             P_COLL_ORD_LINE_ID     IN NUMBER,   --汇总行ID
                             P_ENTITY_ID            IN NUMBER,   --主体ID
                             P_USER_CODE            IN VARCHAR2, --创建人
                             P_RESULT               OUT VARCHAR2);
  ----------------------------------------------------------------------
  -- Author  : Lizhen
  -- Created : 2017-06-27 20:12:00
  -- Purpose : 根据汇总头ID、中心编码 更新中心产品分解明细数据
  ----------------------------------------------------------------------
  PROCEDURE P_UPD_CENTER_ITEM_ALLOT(IN_COLL_ORD_HEAD_ID    IN NUMBER, --汇总头ID
                                    IN_SALES_CENTER_CODE   IN Varchar2, --汇总行ID
                                    IN_ENTITY_ID           IN NUMBER, --主体ID
                                    IN_USER_CODE           IN VARCHAR2, --创建人
                                    OUT_RESULT             OUT Varchar2
                                    );                           
                                         
  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-11-18 16:12:00
  -- Purpose : 订单行转换销司产地信息
  ----------------------------------------------------------------------
  PROCEDURE P_ORDER_CHANGE_SALES_CENTER_PA(P_ORDER_TYPE_ID    IN NUMBER,   --订单类型ID
                                           P_PERIOD_ID        IN NUMBER,   --订单周期ID
                                           P_BATCH_ID         IN NUMBER,   --批次ID
                                           P_ITEM_CODE        IN VARCHAR2, --产品编码
                                           P_COLL_ORD_LINE_ID IN NUMBER,   --汇总订单行ID
                                           P_ENTITY_ID        IN NUMBER,   --主体ID
                                           P_CREATED_BY       IN VARCHAR2, --创建人
                                           P_PA_LIST          IN VARCHAR2, --产地信息
                                           P_RESULT           OUT VARCHAR2);
                                      
  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-11-19 16:31:00
  -- Purpose : 校验销司产地信息
  ----------------------------------------------------------------------
  PROCEDURE P_CHECK_SALES_CENTER_PA(P_ORDER_NUMBER        IN VARCHAR2, --订单号
                                    P_ORDER_TYPE_ID       IN NUMBER,   --订单类型ID
                                    P_PERIOD_ID           IN NUMBER,   --订单周期ID
                                    P_BATCH_ID            IN NUMBER,   --批次ID
                                    P_ITEM_CODE           IN VARCHAR2, --产品编码
                                    P_SALES_CENTER_CODE   IN VARCHAR2, --营销中心编码
                                    P_PRODUCING_AREA_CODE IN VARCHAR2, --产地编码
                                    P_PRODUCING_AREA_QTY  IN NUMBER,   --产地数量
                                    P_ENTITY_ID           IN NUMBER,   --主体ID
                                    P_CREATED_BY          IN VARCHAR2, --创建人
                                    P_RESULT              OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-11-29 10:23:00
  -- Purpose : 更新订单行
  ----------------------------------------------------------------------
  PROCEDURE P_UPDATE_ORDER_LINE(P_ORDER_TYPE_ID IN NUMBER,   --订单类型ID
                                P_PERIOD_ID     IN NUMBER,   --订单周期ID
                                P_BATCH_ID      IN NUMBER,   --批次ID
                                P_ENTITY_ID     IN NUMBER,   --主体ID
                                P_CREATED_BY    IN VARCHAR2, --创建人
                                P_RESULT        OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-12-16 15:53:00
  -- Purpose : 校验周排产订单销司产地排产量
  ----------------------------------------------------------------------
  PROCEDURE P_CHECK_WEEK_SC_PA_QTY(P_ORDER_NUMBER        IN VARCHAR2, --订单号
                                   P_ORDER_TYPE_ID       IN NUMBER,   --订单类型ID
                                   P_PERIOD_ID           IN NUMBER,   --订单周期ID
                                   P_BATCH_ID            IN NUMBER,   --批次ID
                                   P_ITEM_CODE           IN VARCHAR2, --产品编码
                                   P_SALES_CENTER_CODE   IN VARCHAR2, --营销中心编码
                                   P_PRODUCING_AREA_CODE IN VARCHAR2, --产地编码s
                                   P_PRODUCING_AREA_QTY  IN NUMBER,   --产地数量
                                   P_ENTITY_ID           IN NUMBER,   --主体ID
                                   P_CREATED_BY          IN VARCHAR2, --创建人
                                   P_RESULT              OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-12-17 14:57:00
  -- Purpose : 获取销司产品最优产地
  ----------------------------------------------------------------------
  PROCEDURE P_GET_SC_ITEM_OPTIMAL_PA(P_SALES_CENTER_ID   IN VARCHAR2, --营销中心ID
                                     P_ITEM_ID           IN VARCHAR2, --产品ID
                                     P_ENTITY_ID         IN NUMBER,   --主体ID
                                     P_RESULT            OUT VARCHAR2,
                                     P_PRODUCING_AREA_ID OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-12-19 16:48:00
  -- Purpose : 订单行转换区域辐射信息
  ----------------------------------------------------------------------
  PROCEDURE P_ORDER_CHANGE_AREA_INFO(P_ORDER_TYPE_ID IN NUMBER,   --订单类型ID
                                     P_PERIOD_ID     IN NUMBER,   --订单周期ID
                                     P_BATCH_ID      IN NUMBER,   --批次ID
                                     P_ENTITY_ID     IN NUMBER,   --主体ID
                                     P_CREATED_BY    IN VARCHAR2, --创建人
                                     P_RESULT        OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2015-03-12 10:17:00
  -- Purpose : 更新销售公司成本关系表
  ----------------------------------------------------------------------
  PROCEDURE P_UPDATE_CENTER_COST_RELATION(P_ENTITY_ID     IN NUMBER,   --主体ID
                                          P_CREATED_BY    IN VARCHAR2, --创建人
                                          P_RESULT        OUT VARCHAR2);
  
  ----------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2015-11-25
  -- Purpose : 提货订单调整后更新销司产地数据
  ----------------------------------------------------------------------
  PROCEDURE P_UPDATE_SALES_CENTER_PA(P_SALES_PA_ID   IN NUMBER, --销司产地ID
                                     P_ENTITY_ID     IN NUMBER,   --主体ID
                                     P_USER_CODE    IN VARCHAR2, --创建人
                                     P_RESULT        OUT VARCHAR2);
  
  ----------------------------------------------------------------------
  -- Author  : 何加源
  -- Created : 2015-11-25
  -- Purpose : 提货订单调整前更新相关数量
  ----------------------------------------------------------------------
  PROCEDURE P_UPD_PLN_LG_LINE_QTY(P_SALES_PA_ID   IN NUMBER, --销司产地ID
                                  P_ENTITY_ID     IN NUMBER,   --主体ID
                                  P_USER_CODE    IN VARCHAR2, --创建人
                                  P_RESULT        OUT VARCHAR2);

END PKG_PLN_PRODUCING_AREA_ALLOT;
/

