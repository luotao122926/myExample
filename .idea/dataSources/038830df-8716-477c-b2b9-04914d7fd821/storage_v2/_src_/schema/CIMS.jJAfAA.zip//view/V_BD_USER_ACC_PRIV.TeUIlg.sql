create view V_BD_USER_ACC_PRIV as
select distinct a."USER_ID",a."USER_CODE",a."USER_NAME",a."ACCOUNT_ID",a."ACCOUNT_CODE",a."ACCOUNT_NAME",a."ENTITY_ID"
  from (select *  from v_bd_user_acc_priv_default  --用户默认的账户权限
        union all
        --用户独立授权的账户权限
        select * from v_bd_user_acc_priv_add
        ) a

/

