create package PKG_INV_STOCKUP is

        Procedure PLN_LG(p_headId        in number,
                         p_entity_id       in number,
                         v_exception     out varchar2,
                         v_batch_num     out number
                        );    
        Procedure COUNT_QUOTA(p_headId   in number,
                              p_custCode in varchar2,
                              p_salesMainType in varchar2,
                              p_isCheckOrBack in varchar2,
                              v_exception out varchar2
                              );
        Procedure p_Upd_Lgorder_Affirm_Qty(p_Lgorder_Line_Id   In Number, --行ID     
                                     p_Send_Inventory_Id In Number, --发货仓库ID                                                                                                
                                     p_Trans_Order_Qty   In Number, --运力任务取消数量 
                                     p_Entity_Id         In Number, --主体ID
                                     p_User_Code         In Varchar2, --用户编码
                                     p_Result            Out Varchar2 --成功返回'SUCCESS' 否则返回错误信息
                                     ); 
end PKG_INV_STOCKUP;
/

