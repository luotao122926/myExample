create package      PKG_AR_COMMON is

  -- Author  : TIANMENGZHU
  -- Created : 2015/10/15 15:23:00
  -- Purpose : 将财务使用到的公共部门提出，以便重复利用

  V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常

  /*
  *校验出票人银行账户、第一收款人银行账户、票据号格式
  *暂不校验票据分号格式
  */
  FUNCTION F_VALIDATE_FORMAT(P_CASH_RECEIPT_CODE          T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_CODE%TYPE, --收款单号（收款）
                             P_FIRST_RECEIPT_BANK_ACCOUNT T_AR_CASH_RECEIPT_HEADERS.FIRST_RECEIPT_BANK_ACCOUNT%TYPE, --第一收款人银行账户（收款）
                             P_DRAWER_BANK_ACCOUNT        T_AR_CASH_RECEIPT_HEADERS.DRAWER_BANK_ACCOUNT%TYPE, --出票人银行账户（收款）
                             P_CASH_CODE                  T_AR_CASH_RECEIPT_HEADERS.CASH_CODE%TYPE --票据号（收款）
                             ) RETURN VARCHAR2;
  /*
  *校验票据号长度
  */
  FUNCTION F_VALIDATE_CODE_LEN(P_CASH_RECEIPT_CODE T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_CODE%TYPE, --收款单号（收款）
                               P_CODE_LEN          T_AR_RECEIPT_METHODS.CASH_CODE_LENGTH%TYPE, --票据号长度（收款方法）
                               P_CASH_CODE         T_AR_CASH_RECEIPT_HEADERS.CASH_CODE%TYPE --票据号（收款）
                               ) RETURN VARCHAR2;
  /*
  *校验票据期限
  */
  FUNCTION F_VALIDATE_CODE_DATE_TERM(P_CASH_RECEIPT_CODE T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_CODE%TYPE, --收款单号（收款）
                                     P_DUE_DATE          T_AR_CASH_RECEIPT_HEADERS.DUE_DATE%TYPE, --票据到期日（收款）
                                     P_CASH_DATE         T_AR_CASH_RECEIPT_HEADERS.CASH_DATE%TYPE, --出票日期（收款）
                                     P_DATE_TERM         T_AR_RECEIPT_METHODS.CASH_DATE_TERM%TYPE --票据期限（收款方法）
                                     ) RETURN VARCHAR2;
  /*
  *校验票据是否重复
  */
  FUNCTION F_VALIDATE_CODE_REPEAT(P_CASH_RECEIPT_CODE T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_CODE%TYPE, --收款单号（收款）
                                  P_CASH_CODE         T_AR_CASH_RECEIPT_HEADERS.CASH_CODE%TYPE, --票据号（收款）
                                  P_SUB_CASH_CODE     T_AR_CASH_RECEIPT_HEADERS.SUB_CASH_CODE%TYPE, --票据分号（收款）
                                  P_UNITE_FLAG        T_AR_CASH_RECEIPT_HEADERS.UNITE_FLAG%TYPE, --合并导入标志（收款）
                                  P_CASH_RECEIPT_ID   T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_ID%TYPE --收款单ID
                                  ) RETURN VARCHAR2;

  --获取客户下营销大类的到款余额
  PROCEDURE P_GET_CUST_AMOUT(P_ENTITY_ID            IN NUMBER, --主体ID
                             P_CUSTOMER_ID          IN NUMBER, --客户ID
                             P_ACCOUNT_ID           IN NUMBER, --账户ID
                             P_RECEIPT_METHOD_ID    IN NUMBER, --收款方法ID
                             P_SALES_MAIN_TYPE_CODE IN VARCHAR2, --营销大类编码
                             P_VERIFY_AMOUNT        OUT NUMBER, --客户到款余额
                             P_MESSAGE              OUT VARCHAR2);
  /*
  *校验客户-OU是否对应，且有效
  */
  FUNCTION F_VALIDATE_CUST_OU(P_CUSTOMER_ID NUMBER, --客户ID
                              P_ERP_OU_ID   NUMBER --账户ID
                              ) RETURN VARCHAR2;

  /*
  * 校验客户-账户-主体、客户-中心-主体，是否一一对应，且有效
  */
  FUNCTION F_VALIDATE_CUST_ACC(P_ENTITY_ID     NUMBER, --主体ID
                               P_CUSTOMER_CODE VARCHAR2, --客户编码
                               P_ACCOUNT_CODE  VARCHAR2 --账户编码
                               ) RETURN VARCHAR2; --成功则返回“SUCCESS”，否则返回出错信息
  /*
  * 校验客户-中心-主体，是否一一对应，且有效
  */
  FUNCTION F_VALIDATE_CUST_CENTER(P_ENTITY_ID         NUMBER, --主体ID
                                  P_CUSTOMER_CODE     VARCHAR2, --客户编码
                                  P_SALES_CENTER_CODE VARCHAR2 --营销中心编码
                                  ) RETURN VARCHAR2; --成功则返回“SUCCESS”，否则返回出错信息
  /*
  * 校验客户是否为提前开票客户（应收发票配置中，是否提前开票Y/N，Y-不引发票池；N-引发票池）
  */
  FUNCTION F_VALIDATE_IS_ADVANCE_CUSTOMER(P_ENTITY_ID       NUMBER, --主体ID
                                          P_CUSTOMER_ID     NUMBER, --客户ID
                                          P_SALES_CENTER_ID NUMBER --营销中心ID
                                          ) RETURN VARCHAR2; --成功则返回“SUCCESS”，否则返回出错信息

  /*
  * 校验营销大类是否有效，是否属于客户
  */
  FUNCTION F_VALIDATE_CUST_ITEM_CLASS(P_ENTITY_ID            NUMBER, --主体ID
                                      P_CUSTOMER_CODE        VARCHAR2, --客户编码
                                      P_SALES_MAIN_TYPE_CODE VARCHAR2 --营销大类编码
                                      ) RETURN VARCHAR2; --成功则返回“SUCCESS”，否则返回出错信息
  /*
  * 校验客户-中心-账户-主体是否一一对应，且有效
  */
  FUNCTION F_VALIDATE_CUST_CENTER_ACC(P_ENTITY_ID         NUMBER, --主体ID
                                      P_CUSTOMER_CODE     VARCHAR2, --客户编码
                                      P_SALES_CENTER_CODE VARCHAR2, --营销中心编码
                                      P_ACCOUNT_CODE      VARCHAR2 --账户编码
                                      ) RETURN VARCHAR2; --成功则返回“SUCCESS”，否则返回出错信息
  /*
  * 校验主体-OU是否一一对应
  */
  FUNCTION F_VALIDATE_ENTITY_OU(P_ENTITY_ID NUMBER, --主体ID
                                P_ERP_OU_ID NUMBER --ERP_OU_ID
                                ) RETURN VARCHAR2; --成功则返回“SUCCESS”，否则返回出错信息
  /*
  * 校验主体-收款方法/转款方法是否一一对应
  */
  FUNCTION F_VALIDATE_ENTITY_METHOD(P_ENTITY_ID     NUMBER, --主体ID
                                    P_METHOD_ID     NUMBER, --收款方法ID
                                    P_BUSINESS_TYPE VARCHAR2, --业务分类ID
                                    P_IN_ENTITY_ID  NUMBER --转款转入主体ID
                                    ) RETURN VARCHAR2; --成功则返回“SUCCESS”，否则返回出错信息
  /*
  * 校验附件是否上传
  */
  FUNCTION F_VALIDATE_APPENDIX(P_RECEIPT_METHOD_ID NUMBER, --收款方法ID
                               P_APPENDIX_ID       VARCHAR2 --附件ID
                               ) RETURN VARCHAR2; --成功则返回“SUCCESS”，否则返回出错信息
  /*
  * 校验ERP收款方银行账户
  */
  PROCEDURE P_VALIDATE_ERP_RECEIPT_BANK(P_ERP_OU_ID               IN NUMBER, --ERP_OU_ID
                                        P_ERP_RECEIPT_METHOD_NAME IN VARCHAR2, --ERP收款方法名称
                                        P_BANK_ACCOUNT_NAME       IN VARCHAR2, --attribute7
                                        P_BANK_ACCOUNT_CODE       IN VARCHAR2, --ATTRIBUTE13  账号
                                        P_CODE_LEN                IN VARCHAR2, --票据号长度
                                        P_RECEIPT_ENTRY_CODE      IN VARCHAR2, --是否可录入
                                        P_INTO_FLAG               IN VARCHAR2, --引入ERP/资金标志
                                        P_ERP_RECEIPT_METHOD_ID   OUT NUMBER, --ERP使用
                                        P_ERP_BANK_ACCT_USE_ID    OUT NUMBER, --ERP使用
                                        P_ERP_BANK_ACCTOUNT_ID    OUT NUMBER, --资金使用
                                        P_ERP_BANK_ACCTOUNT_NAME  OUT VARCHAR2, --资金使用
                                        P_MESSAGE                 OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                        );
  /*
  * 校验客户银行账户
  */
  PROCEDURE P_VALIDATE_CUSTOMER_BANK(P_ENTITY_ID         IN NUMBER, --主体ID
                                     P_CUSTOMER_ID       IN NUMBER, --客户ID
                                     P_CUST_BANK_ACCOUNT OUT VARCHAR2, --客户银行账户
                                     P_CUST_BANK         OUT VARCHAR2, --客户银行
                                     P_MESSAGE           OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                     );
  /*
  * 获取账套ID
  */
  PROCEDURE P_GET_SET_BOOK_ID(P_ERP_OU_ID IN NUMBER, --ERP_OU_ID
                              P_BOOK_ID   OUT NUMBER, --账套ID
                              P_MESSAGE   OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                              );
  /*
  * 收款确认校验（引接口校验：ERP收款方银行账户、客户银行、账套ID）
  */
  PROCEDURE P_VALIDATE_RECEIPT_CONFIRM(P_ENTITY_ID               IN T_AR_CASH_RECEIPT_HEADERS.ENTITY_ID%TYPE, --主体ID（收款单）
                                       P_CUSTOMER_ID             IN T_AR_CASH_RECEIPT_HEADERS.CUSTOMER_ID%TYPE, --客户ID（收款单）
                                       P_ERP_OU_ID               IN T_AR_CASH_RECEIPT_HEADERS.ERP_OU_ID%TYPE, --ERP_OU_ID
                                       P_CASH_CODE_LENGTH        IN T_AR_RECEIPT_METHODS.CASH_CODE_LENGTH%TYPE, --票据号长度（收款方法）
                                       P_RECEIPT_ENTRY_CODE      IN T_AR_RECEIPT_METHODS.RECEIPT_ENTRY_CODE%TYPE, --是否可录入（收款方法）
                                       P_INTO_ERP_FLAG           IN T_AR_RECEIPT_METHODS.INTO_ERP_FLAG%TYPE, --引入ERP标志（收款方法）
                                       P_INTO_BAN_FLAG           IN T_AR_RECEIPT_METHODS.INTO_BAN_FLAG%TYPE, --引入资金标志（收款方法）
                                       P_ERP_HANDLE              IN T_AR_RECEIPT_METHODS.ERP_HANDLE%TYPE, --引入ERP方式：发票、收款（收款方法）
                                       P_ERP_RECEIPT_METHOD_NAME IN T_AR_RECEIPT_METHODS.ERP_RECEIPT_METHOD_NAME%TYPE, --ERP收款方法名称（收款方法）
                                       P_ATTRIBUTE7              IN T_AR_CASH_RECEIPT_HEADERS.ATTRIBUTE7%TYPE, --ERP收款方银行账户名称（资金使用，对应收款单ATTRIBUTE7）
                                       P_BANK_ACCOUNT_CODE       IN VARCHAR2, --ATTRIBUTE13  账号
                                       P_REFUND_APPLY_ID         IN NUMBER,
                                       P_ERP_RECEIPT_METHOD_ID   OUT T_AR_RECEIPT_METHODS.ERP_RECEIPT_METHOD_ID%TYPE, --ERP收款方法ID（ERP使用）
                                       P_ERP_BANK_ACCT_USE_ID    OUT INTF_AR_RECEIPT_METHOD.REMIT_BANK_ACCT_USE_ID%TYPE, --ERP收款方银行账户ID（ERP使用）
                                       P_ERP_BANK_ACCOUNT_ID     OUT INTF_AR_RECEIPT_METHOD.BANK_ACCOUNT_ID%TYPE, --收款方银行账户ID（资金使用）
                                       P_ERP_BANK_ACCOUNT_NAME   OUT INTF_AR_RECEIPT_METHOD.BANK_ACCOUNT_NAME%TYPE, --ERP收款方银行账户名称（资金使用，对应收款单ATTRIBUTE7）
                                       P_CUST_BANK_ACCOUNT       OUT T_CUSTOMER_BANK.BANK_ACCOUNT%TYPE, --客户银行账户（资金使用）
                                       P_CUST_BANK               OUT T_CUSTOMER_BANK.BANK%TYPE, --客户银行名称  （资金使用）
                                       P_SET_OUT_ID              OUT T_INV_ORGANIZATION.SET_OF_BOOKS_ID%TYPE, --账套ID   （ERP发票使用）
                                       P_MESSAGE                 OUT VARCHAR2);
  /*
  * 收款单引入ERP收款接口表
  */
  PROCEDURE P_INSERT_ERP_RECEIPT(P_CASH_RECEIPT_ID       IN NUMBER, --收款头ID
                                 P_ERP_RECEIPT_METHOD_ID IN NUMBER, --ERP收款方法ID
                                 P_ERP_BANK_ACCT_USE_ID  IN NUMBER, --ERP收款方银行账户ID
                                 P_MESSAGE               OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                 );
  /*
  * 收款单引入AR发票接口表
  */
  PROCEDURE P_INSERT_AR_INVOICE(P_CASH_RECEIPT_ID IN NUMBER, --收款头ID
                                P_SET_OF_BOOKS_ID IN NUMBER, --账套ID
                                P_MESSAGE         OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                );

  /*
  * 收款单引入资金接口表，纸票在途登记
  */
  PROCEDURE P_INSERT_GTSP_RECEIPT(P_CASH_RECEIPT_ID       IN NUMBER, --收款头ID
                                  P_CUST_BANK_ACCOUNT     IN VARCHAR2, --客户银行账户
                                  P_CUST_BANK             IN VARCHAR2, --客户银行名称
                                  P_ERP_RECEIPT_METHOD_ID IN NUMBER, --ERP收款方法ID
                                  P_ERP_BANK_ACCOUNT_ID   IN NUMBER, --ERP收款方银行账户ID
                                  P_ERP_BANK_ACCOUNT_NAME IN VARCHAR2, --ERP收款方银行账户名称
                                  P_MESSAGE               OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                  );
                                  
  /*
  * 收款单冲销插入ERP冲销接口表
  */
  PROCEDURE P_INSERT_AR_REVERSE(P_CASH_RECEIPT_ID IN NUMBER, --收款头ID
                                P_MESSAGE         OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                );                                 
                                  
  /*
  * 校验收款单（三方）的分款是否已经完全解付，若完全解付，则返回“SUCCESS”，否则返回错误信息
  */
  PROCEDURE P_VALIDATE_RECEIPT_SOLUPAY(P_CASH_RECEIPT_CODE VARCHAR2, --收款单号
                                       P_SUPOR_SYSTEM      VARCHAR2, --发起冲销系统（C-IMS、GTSP、CCS）
                                       P_MESSAGE           OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                       );

  /*
  * 查询已汇状态的收款单重复票据数
  */
  PROCEDURE P_ERP_CASH_CODE_SUM(P_ENTITY_ID       NUMBER, --主体ID
                                P_CASH_CODE       VARCHAR2, --票据号
                                P_CASH_RECEIPT_ID NUMBER, --收款单ID
                                P_COUNT           OUT NUMBER, --返回重复记录数，0为没有
                                P_MESSAGE         OUT VARCHAR2 --查询异常返回错误信息，否则返回'SUCCESS'
                                );
                                
                                
  /*
  * 根据中心编码查询NC组织
  */
  PROCEDURE P_GET_NCORG_BY_CODE(P_ENTITY_ID          IN  NUMBER,   --主体ID
                                P_SALES_CENTER_CODE  IN  VARCHAR2, --营销中心编码
                                P_NC_ORG_CODE        OUT VARCHAR2, --返回NC组织编码
                                P_MESSAGE            OUT VARCHAR2 --查询异常返回错误信息，否则返回'SUCCESS'
                                );    
                                
  /*
  * 根据中心ID查询NC组织
  */
  PROCEDURE P_GET_NCORG_BY_ID(P_ENTITY_ID          IN  NUMBER,   --主体ID
                                P_SALES_CENTER_ID  IN  NUMBER,   --营销中心编码
                                P_NC_ORG_CODE        OUT VARCHAR2, --返回NC组织编码
                                P_MESSAGE            OUT VARCHAR2 --查询异常返回错误信息，否则返回'SUCCESS'
                                );                                                                 

end PKG_AR_COMMON;
/

