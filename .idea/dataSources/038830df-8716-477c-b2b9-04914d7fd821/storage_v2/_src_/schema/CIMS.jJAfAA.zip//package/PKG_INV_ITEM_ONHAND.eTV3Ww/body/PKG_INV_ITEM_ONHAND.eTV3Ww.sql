create PACKAGE BODY PKG_INV_ITEM_ONHAND IS

 
  ------------------------------------------------------------------------------------------------
  -- Author  : 黄洪彬 2019-12-3
  -- Purpose : 增量冻结仓库产品库存 for ccs。 
  ------------------------------------------------------------------------------------------------
  PROCEDURE P_INCREMENTAL_FREEZE_INV_ITEM(P_ENTITY_ID IN NUMBER,
                                          P_RESULT    OUT VARCHAR2) IS
                                          
  V_CURRENT_DATE DATE;
  N_COUNT NUMBER;
  N_COUNTER NUMBER;
  
  begin 
        P_RESULT := PKG_INV_ITEM_ONHAND.v_Success;
        V_CURRENT_DATE := SYSDATE;--获取当前时间
        N_COUNTER      := 0;
        --变更状态
        update cims.INTF_INV_ITEM_ONHAND_PQ q
          set q.is_updated = 'N';
        FOR INV_AREA_INVENTORY_ROW IN(
            select distinct r.inventory_id
               from cims.t_inv_area_inventory_relation r
               where r.entity_id = P_ENTITY_ID
               AND R.IS_ACTIVE = 'Y'
          )LOOP 
            FOR 
               ONHAND_PQ_ROW 
             IN( 
                 select v.entity_id, v.inventory_id,v.inventory_code, v.item_id,v.item_code, v.num3 onhand_num
                  from cims.v_inv_item_onhand_pq v
                 where v.entity_id = P_ENTITY_ID
                   AND V.inventory_id = INV_AREA_INVENTORY_ROW.INVENTORY_ID
                minus
                  select q.entity_id, q.inventory_id,q.inventory_code, q.item_id,q.item_code, q.onhand_num
                    from cims.INTF_INV_ITEM_ONHAND_PQ q
                    where q.entity_id = P_ENTITY_ID
                    AND Q.inventory_id = INV_AREA_INVENTORY_ROW.INVENTORY_ID
               )LOOP
                BEGIN
                   SELECT 
                     COUNT(Q.ID) 
                   INTO 
                      N_COUNT 
                   FROM  cims.INTF_INV_ITEM_ONHAND_PQ Q
                     WHERE Q.ENTITY_ID = ONHAND_PQ_ROW.entity_id
                     AND Q.INVENTORY_ID = ONHAND_PQ_ROW.INVENTORY_ID
                     AND Q.ITEM_ID = ONHAND_PQ_ROW.ITEM_ID;
                   IF N_COUNT>0 THEN
                        UPDATE INTF_INV_ITEM_ONHAND_PQ Q
                           SET Q.ONHAND_NUM = ONHAND_PQ_ROW.ONHAND_NUM
                           ,Q.IS_UPDATED = 'Y'
                           ,Q.LAST_UPDATED_BY = 'admin'
                           ,Q.LAST_UPDATE_DATE = V_CURRENT_DATE
                           WHERE Q.ENTITY_ID = ONHAND_PQ_ROW.entity_id
                           AND Q.INVENTORY_ID = ONHAND_PQ_ROW.INVENTORY_ID
                           AND Q.ITEM_ID = ONHAND_PQ_ROW.ITEM_ID;   
                   ELSE
                        INSERT INTO INTF_INV_ITEM_ONHAND_PQ(id,ENTITY_ID,INVENTORY_ID,INVENTORY_CODE,ITEM_ID,ITEM_CODE,ONHAND_NUM,IS_UPDATED,CREATED_BY,CREATION_DATE,LAST_UPDATED_BY,LAST_UPDATE_DATE)
                        VALUES (S_INV_ITEM_ONHAND_PQ.Nextval,ONHAND_PQ_ROW.entity_id,ONHAND_PQ_ROW.INVENTORY_ID,ONHAND_PQ_ROW.INVENTORY_CODE,ONHAND_PQ_ROW.ITEM_ID,ONHAND_PQ_ROW.ITEM_CODE,ONHAND_PQ_ROW.onhand_num,'Y','admin',V_CURRENT_DATE,'admin',V_CURRENT_DATE);
                   END IF;
                   N_COUNTER := N_COUNTER + 1;
                   --每5000 条提交一次
                   IF N_COUNTER = 5000 THEN
                     N_COUNTER := 0;
                     COMMIT;
                   END IF;   
                      
               EXCEPTION WHEN OTHERS THEN
                      ROLLBACK;
                      P_RESULT := PKG_INV_ITEM_ONHAND.v_Failure;
                      P_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_INV_ITEM_ONHAND.P_INCREMENTAL_FREEZE_INV_ITEM', SQLCODE,
                              '增量更新仓库产品库存表出错！仓库编码：['||ONHAND_PQ_ROW.INVENTORY_CODE||'],产品编码：['||ONHAND_PQ_ROW.ITEM_CODE||']。异常消息：' || substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
               END;
           END LOOP;                                                                                                                                                                                     
        END LOOP;  
        COMMIT; 
  end ;

END PKG_INV_ITEM_ONHAND;
/

