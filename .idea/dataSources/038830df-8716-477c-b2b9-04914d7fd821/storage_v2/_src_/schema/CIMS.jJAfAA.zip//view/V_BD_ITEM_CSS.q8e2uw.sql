create view V_BD_ITEM_CSS as
select item_code,
       item_name,
       productModel,   --产品型号
       productDesc,    --产品描述
       defaultunit,    --基本计量单位
       brandType,      --品牌类型
       brand,          --品牌
       productForm,    --产品形态
       productNumberingCls,   --产品编码分类
       commodityBarCode, --商品条形码
       commoditycode, --商品码 (大电销售码属性)
       barcode, --条码 (大电销售码属性)
       sales_main_type,   --营销大类
       sales_sub_type,    --营销小类
       created_by,
       creation_date,
       last_updated_by,
       last_update_date,
       entity_id
  from T_BD_ITEM
/

