create PACKAGE BODY      PKG_AR_BOND IS

  /*
  *转款保存校验
  */
  PROCEDURE P_VALIDATE_TURNFEE_SAVE(P_CASH_TURNFEE_ID IN NUMBER, --收款头接口表ID
                                    P_MESSAGE         OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                    ) IS
    --转款头
    CURSOR C_TURNFEE_HEAD IS
      SELECT H.*,
             M.RECEIPT_METHOD_NAME,
             NVL(M.RECEIPT_ENTRY_CODE, 'N') RECEIPT_ENTRY_CODE,
             NVL(M.RECEIPT_CLASS_CODE, 'N') RECEIPT_CLASS_CODE,
             NVL(M.INTO_ERP_FLAG, 'N') INTO_ERP_FLAG,
             NVL(M.INTO_BAN_FLAG, 'N') INTO_BAN_FLAG,
             M.TYPE METHOD_TYPE,
             NVL(M.IS_EFFECTIVE, 'N') IS_EFFECTIVE,
             M.RECEIPT_TYPE,
             M.BUSINESS_TYPE,
             M.ERP_RECEIPT_METHOD_ID,
             M.PAY_MENT_MODE,
             M.ERP_HANDLE,
             M.ERP_AR_ID,
             M.ERP_RECEIPT_METHOD_NAME,
             M.ERP_AR_NAME,
             M.IN_TURNFEE,
             M.IN_TURNFEE_NAME,
             M.OUT_TURNFEE
        FROM CIMS.T_AR_CASH_TURNFEE_HEADER H, CIMS.T_AR_RECEIPT_METHODS M
       WHERE H.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID
         AND H.RECEIPT_METHOD_ID = M.RECEIPT_METHOD_ID;
    HEAD_ROW C_TURNFEE_HEAD%ROWTYPE; --转款头游标行数据
    --转款行
    CURSOR C_TURNFEE_LINES IS
      SELECT *
        FROM CIMS.T_AR_CASH_TURNFEE_LINE L
       WHERE L.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID;
    LINE_ROW             C_TURNFEE_LINES%ROWTYPE; --转款行游标行数据
    V_HEAD_COUNT         NUMBER; --转款头数据总数
    V_LINE_COUNT         NUMBER; --转款行数据总数
    V_ENTITY_ID          NUMBER; --主体ID
    V_LINE_AMOUNT        NUMBER; --单张转款单的分款金额总和
    V_SALES_COUNT        NUMBER; --分款行重复记录数
    V_IN_OUT_SALES_COUNT NUMBER; --转入、转出营销大类相同记录数
    V_IN_ENTITY_ID       NUMBER; --转入主体

  BEGIN
    P_MESSAGE := 'SUCCESS';
    --收转款头数量
    SELECT COUNT(*)
      INTO V_HEAD_COUNT
      FROM CIMS.T_AR_CASH_TURNFEE_HEADER H
     WHERE H.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID;
    IF (V_HEAD_COUNT > 0) THEN
      FOR HEAD_ROW IN C_TURNFEE_HEAD LOOP
        V_ENTITY_ID := HEAD_ROW.ENTITY_ID;
        --转款头：
        IF HEAD_ROW.CASH_TURNFEE_ID IS NULL THEN
          P_MESSAGE := '转款单id为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CASH_TURNFEE_CODE IS NULL THEN
          P_MESSAGE := '转款单据编号为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.RECEIPT_METHOD_ID IS NULL THEN
          P_MESSAGE := '转款单的转款方法ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.STATUS IS NULL THEN
          P_MESSAGE := '转款单的状态ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.STATUS <> 1 THEN
          P_MESSAGE := '转款单的状态不是制单';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_CUSTOMER_ID IS NULL THEN
          P_MESSAGE := '转款单的转入客户ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_CUSTOMER_CODE IS NULL THEN
          P_MESSAGE := '转款单的转入客户编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_CUSTOMER_NAME IS NULL THEN
          P_MESSAGE := '转款单的转入客户名称为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_SALES_CENTER_ID IS NULL THEN
          P_MESSAGE := '转款单的转入营销中心ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_SALES_CENTER_CODE IS NULL THEN
          P_MESSAGE := '转款单的转入营销中心编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_SALES_CENTER_NAME IS NULL THEN
          P_MESSAGE := '转款单的转入营销中心名称为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_ACCOUNT_ID IS NULL THEN
          P_MESSAGE := '转款单的转入账户ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_ACCOUNT_CODE IS NULL THEN
          P_MESSAGE := '转款单的转入账户编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_CUSTOMER_ID IS NULL THEN
          P_MESSAGE := '转款单的转出客户ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_CUSTOMER_CODE IS NULL THEN
          P_MESSAGE := '转款单的转出客户编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_CUSTOMER_NAME IS NULL THEN
          P_MESSAGE := '转款单的转出客户名称为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_SALES_CENTER_ID IS NULL THEN
          P_MESSAGE := '转款单的转出营销中心ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_SALES_CENTER_CODE IS NULL THEN
          P_MESSAGE := '转款单的转出营销中心编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_SALES_CENTER_NAME IS NULL THEN
          P_MESSAGE := '转款单的转出营销中心名称为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_ACCOUNT_ID IS NULL THEN
          P_MESSAGE := '转款单的转出账户ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_ACCOUNT_CODE IS NULL THEN
          P_MESSAGE := '转款单的转出账户编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_ERP_OU_ID IS NULL THEN
          P_MESSAGE := '转款单的转入ERP_OU_ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_ERP_OU_NAME IS NULL THEN
          P_MESSAGE := '转款单的转入ERP_OU_NAME为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_ERP_OU_ID IS NULL THEN
          P_MESSAGE := '转款单的转出ERP_OU_ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_ERP_OU_NAME IS NULL THEN
          P_MESSAGE := '转款单的转出ERP_OU_NAME为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CASH_RECEIPT_DATE IS NULL THEN
          P_MESSAGE := '转款单的单据日期为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.INTO_ERP_FLAG = 'Y' AND HEAD_ROW.GL_DATE IS NULL THEN
          P_MESSAGE := '转款单的总账日期为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.AMOUNT IS NULL THEN
          P_MESSAGE := '转款单的金额为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CURRENCY_CODE IS NULL THEN
          P_MESSAGE := '转款单的币种为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CASH_RECEIPT_CREATED_BY IS NULL THEN
          P_MESSAGE := '转款单的制单人为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CASH_RECEIPT_CREATION_BY_TIME IS NULL THEN
          P_MESSAGE := '转款单的制单时间为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.BUSINESS_TYPE = '3' AND HEAD_ROW.ENTITY_ID IS NULL THEN
          P_MESSAGE := '转款单的主体ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.BUSINESS_TYPE = '6' AND
              HEAD_ROW.IN_ENTITY_ID IS NULL THEN
          P_MESSAGE := '转款单的转入主体ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.BUSINESS_TYPE = '6' AND HEAD_ROW.ENTITY_ID IS NULL THEN
          P_MESSAGE := '转款单的转出主体ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.REMARK IS NULL THEN
          P_MESSAGE := '转款单的备注为空';
          RAISE V_BIZ_EXCEPTION;
          --校验金额必须大于0
        ELSIF HEAD_ROW.AMOUNT <= 0 THEN
          P_MESSAGE := '转款单的金额必须大于0';
          RAISE V_BIZ_EXCEPTION;
        END IF;
        IF HEAD_ROW.BUSINESS_TYPE = '3' THEN
          V_IN_ENTITY_ID := HEAD_ROW.ENTITY_ID;
        ELSIF HEAD_ROW.BUSINESS_TYPE = '6' THEN
          V_IN_ENTITY_ID := HEAD_ROW.IN_ENTITY_ID;
        END IF;

        --转入OU与转出OU必须相同
        IF HEAD_ROW.BUSINESS_TYPE = '3' AND
           HEAD_ROW.IN_ERP_OU_ID <> HEAD_ROW.OUT_ERP_OU_ID THEN
          P_MESSAGE := '转款单的转入OU_ID与转出OU_ID不同';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.BUSINESS_TYPE = '6' AND
              HEAD_ROW.IN_ERP_OU_ID = HEAD_ROW.OUT_ERP_OU_ID THEN
          P_MESSAGE := '转款单的转入OU_ID与转出OU_ID相同';
          RAISE V_BIZ_EXCEPTION;
        END IF;
        --校验转款方法和主体是否对应
        P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_ENTITY_METHOD(V_ENTITY_ID,
                                                            HEAD_ROW.RECEIPT_METHOD_ID,
                                                            HEAD_ROW.BUSINESS_TYPE,
                                                            HEAD_ROW.IN_ENTITY_ID);
        IF P_MESSAGE <> 'SUCCESS' THEN
          RAISE V_BIZ_EXCEPTION;
        END IF;
        --校验转入OU和主体是否对应
        P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_ENTITY_OU(V_IN_ENTITY_ID,
                                                        HEAD_ROW.IN_ERP_OU_ID);
        IF P_MESSAGE <> 'SUCCESS' THEN
          P_MESSAGE := '转入：' || P_MESSAGE;
          RAISE V_BIZ_EXCEPTION;
        END IF;
        --校验转出OU和主体是否对应
        P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_ENTITY_OU(V_ENTITY_ID,
                                                        HEAD_ROW.OUT_ERP_OU_ID);
        IF P_MESSAGE <> 'SUCCESS' THEN
          P_MESSAGE := '转出：' || P_MESSAGE;
          RAISE V_BIZ_EXCEPTION;
        END IF;
        --校验转入客户、中心、账户、主体是否对应且有效
        P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_CENTER_ACC(V_IN_ENTITY_ID,
                                                              HEAD_ROW.IN_CUSTOMER_CODE,
                                                              HEAD_ROW.IN_SALES_CENTER_CODE,
                                                              HEAD_ROW.IN_ACCOUNT_CODE);
        IF P_MESSAGE <> 'SUCCESS' THEN
          P_MESSAGE := '转入：' || P_MESSAGE;
          RAISE V_BIZ_EXCEPTION;
        END IF;
        --校验转出客户、中心、账户、主体是否对应且有效
        P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_CENTER_ACC(V_ENTITY_ID,
                                                              HEAD_ROW.OUT_CUSTOMER_CODE,
                                                              HEAD_ROW.OUT_SALES_CENTER_CODE,
                                                              HEAD_ROW.OUT_ACCOUNT_CODE);
        IF P_MESSAGE <> 'SUCCESS' THEN
          P_MESSAGE := '转出：' || P_MESSAGE;
          RAISE V_BIZ_EXCEPTION;
        END IF;
        --校验转出客户与OU对应关系
        P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_OU(HEAD_ROW.OUT_CUSTOMER_ID,
                                                      HEAD_ROW.OUT_ERP_OU_ID);
        IF P_MESSAGE <> 'SUCCESS' THEN
          P_MESSAGE := '转出：' || P_MESSAGE;
          RAISE V_BIZ_EXCEPTION;
        END IF;
        --校验转入客户与OU对应关系
        P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_OU(HEAD_ROW.IN_CUSTOMER_ID,
                                                      HEAD_ROW.IN_ERP_OU_ID);
        IF P_MESSAGE <> 'SUCCESS' THEN
          P_MESSAGE := '转入：' || P_MESSAGE;
          RAISE V_BIZ_EXCEPTION;
        END IF;

        --校验附件是否上传,2015-09-12 tianmzh修改，若保函开立为空，则校验附件，否则不校验附件
        IF HEAD_ROW.BOND_DRAW_ID IS NULL THEN
          P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_APPENDIX(HEAD_ROW.RECEIPT_METHOD_ID,
                                                         HEAD_ROW.APPENDIX_ID);
          IF P_MESSAGE <> 'SUCCESS' THEN
            P_MESSAGE := P_MESSAGE;
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END IF;

        IF HEAD_ROW.BUSINESS_TYPE = '3' THEN
          --客户内产品转款：客户相同、中心相同
          IF HEAD_ROW.IN_TURNFEE IS NULL AND HEAD_ROW.OUT_TURNFEE IS NULL THEN
            IF HEAD_ROW.OUT_CUSTOMER_CODE <> HEAD_ROW.IN_CUSTOMER_CODE OR
               HEAD_ROW.OUT_SALES_CENTER_CODE <>
               HEAD_ROW.IN_SALES_CENTER_CODE THEN
              P_MESSAGE := '客户内产品转款：转入转出客户相同、转入转出中心必须相同';
              RAISE V_BIZ_EXCEPTION;
            END IF;
          END IF;
          --客户间转款：客户相同、中心不同；客户不同
          IF HEAD_ROW.IN_TURNFEE IS NOT NULL AND
             HEAD_ROW.OUT_TURNFEE IS NOT NULL THEN
            IF HEAD_ROW.OUT_CUSTOMER_CODE = HEAD_ROW.IN_CUSTOMER_CODE AND
               HEAD_ROW.OUT_SALES_CENTER_CODE =
               HEAD_ROW.IN_SALES_CENTER_CODE THEN
              P_MESSAGE := '客户间转款：转入转出客户相同时，转入转出中心必须不同';
              RAISE V_BIZ_EXCEPTION;
            END IF;
          END IF;
          -- ELSIF HEAD_ROW.BUSINESS_TYPE = '6' THEN
          --  IF HEAD_ROW.OUT_CUSTOMER_CODE <> HEAD_ROW.IN_CUSTOMER_CODE THEN
          --  P_MESSAGE := '跨主体转款：转入转出客户必须相同';
          --  RAISE V_BIZ_EXCEPTION;
          -- END IF;
        END IF;
        --转款行：
        BEGIN
          SELECT COUNT(*)
            INTO V_LINE_COUNT
            FROM CIMS.T_AR_CASH_TURNFEE_LINE L
           WHERE L.CASH_TURNFEE_ID = HEAD_ROW.CASH_TURNFEE_ID;
        END;
        IF V_LINE_COUNT > 0 THEN
          V_LINE_AMOUNT := 0.0;
          --校验分款明细
          FOR LINE_ROW IN C_TURNFEE_LINES LOOP
            IF LINE_ROW.AMOUNT IS NULL THEN
              P_MESSAGE := '转款单的分款明细中金额为空';
              RAISE V_BIZ_EXCEPTION;
            ELSIF LINE_ROW.AMOUNT IS NOT NULL AND LINE_ROW.AMOUNT <= 0 THEN
              P_MESSAGE := '转款单的分款明细中金额小于等于0';
              RAISE V_BIZ_EXCEPTION;
            ELSIF LINE_ROW.IN_SALES_MAIN_TYPE_ID IS NULL THEN
              P_MESSAGE := '转款单的分款明细中转入营销大类ID为空';
              RAISE V_BIZ_EXCEPTION;
            ELSIF LINE_ROW.OUT_SALES_MAIN_TYPE_ID IS NULL THEN
              P_MESSAGE := '转款单的分款明细中转出营销大类ID为空';
              RAISE V_BIZ_EXCEPTION;
            ELSIF LINE_ROW.IN_SALES_MAIN_TYPE_CODE IS NULL THEN
              P_MESSAGE := '转款单的分款明细中转入营销大类编码为空';
              RAISE V_BIZ_EXCEPTION;
            ELSIF LINE_ROW.OUT_SALES_MAIN_TYPE_CODE IS NULL THEN
              P_MESSAGE := '转款单的分款明细中转出营销大类编码为空';
              RAISE V_BIZ_EXCEPTION;
            ELSIF LINE_ROW.IN_SALES_MAIN_TYPE_NAME IS NULL THEN
              P_MESSAGE := '转款单的分款明细中转入营销大类名称为空';
              RAISE V_BIZ_EXCEPTION;
            ELSIF LINE_ROW.OUT_SALES_MAIN_TYPE_NAME IS NULL THEN
              P_MESSAGE := '转款单的分款明细中转出营销大类名称为空';
              RAISE V_BIZ_EXCEPTION;
            ELSE
              --客户内产品转款：转入营销大类与转出营销大类必须不同
              IF HEAD_ROW.IN_TURNFEE IS NULL AND
                 HEAD_ROW.OUT_TURNFEE IS NULL THEN
                --校验转入营销大类与转出营销大类是否相同，若相同则校验失败，否则校验通过
                SELECT COUNT(L.IN_SALES_MAIN_TYPE_CODE)
                  INTO V_IN_OUT_SALES_COUNT
                  FROM CIMS.T_AR_CASH_TURNFEE_LINE L
                 WHERE L.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID
                   AND L.IN_SALES_MAIN_TYPE_CODE =
                       L.OUT_SALES_MAIN_TYPE_CODE;
                IF V_IN_OUT_SALES_COUNT > 0 THEN
                  P_MESSAGE := '转款单的分款明细中转入营销大类和转出营销大类相同';
                  RAISE V_BIZ_EXCEPTION;
                END IF;
              END IF;
              --校验分款中的转入大类和转出大类是否重复，若重复则校验失败，否则校验通过
              SELECT COUNT(*)
                INTO V_SALES_COUNT
                FROM (SELECT L.IN_SALES_MAIN_TYPE_CODE ||
                             L.OUT_SALES_MAIN_TYPE_CODE,
                             COUNT(L.IN_SALES_MAIN_TYPE_CODE ||
                                   L.OUT_SALES_MAIN_TYPE_CODE) SALES_COUNT
                        FROM CIMS.T_AR_CASH_TURNFEE_LINE L
                       WHERE L.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID
                       GROUP BY L.IN_SALES_MAIN_TYPE_CODE ||
                                L.OUT_SALES_MAIN_TYPE_CODE
                      HAVING COUNT(L.IN_SALES_MAIN_TYPE_CODE || L.OUT_SALES_MAIN_TYPE_CODE) > 1);
              IF V_SALES_COUNT > 0 THEN
                P_MESSAGE := '转款单的分款明细中存在重复的分款行，即分款行1和分款行2中的转入营销大类相同，转出营销大类也相同';
                RAISE V_BIZ_EXCEPTION;
              END IF;
              --校验转款行转入营销大类是否有效
              P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_ITEM_CLASS(V_IN_ENTITY_ID,
                                                                    HEAD_ROW.IN_CUSTOMER_CODE,
                                                                    LINE_ROW.IN_SALES_MAIN_TYPE_CODE);
              IF P_MESSAGE <> 'SUCCESS' THEN
                P_MESSAGE := '转入：' || P_MESSAGE;
                RAISE V_BIZ_EXCEPTION;
              END IF;
              --校验转款行转出营销大类是否有效
              P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_ITEM_CLASS(V_ENTITY_ID,
                                                                    HEAD_ROW.OUT_CUSTOMER_CODE,
                                                                    LINE_ROW.OUT_SALES_MAIN_TYPE_CODE);
              IF P_MESSAGE <> 'SUCCESS' THEN
                P_MESSAGE := '转出：' || P_MESSAGE;
                RAISE V_BIZ_EXCEPTION;
              END IF;
            END IF;
            V_LINE_AMOUNT := V_LINE_AMOUNT + LINE_ROW.AMOUNT;
          END LOOP;
        ELSE
          P_MESSAGE := '转款单分款明细为空';
          RAISE V_BIZ_EXCEPTION;
        END IF;
        IF V_LINE_AMOUNT <> HEAD_ROW.AMOUNT THEN
          P_MESSAGE := '转款单的金额与分款明细中金额总和不等';
          RAISE V_BIZ_EXCEPTION;
        END IF;

      END LOOP;
    ELSE
      P_MESSAGE := '获取不到转款单数据，请联系管理员';
      RAISE V_BIZ_EXCEPTION;
    END IF;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_MESSAGE := '转款保存校验失败：' || P_MESSAGE;
    WHEN OTHERS THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_VALIDATE_TURNFEE_SAVE',
                                          SQLCODE,
                                          P_MESSAGE || SQLERRM);
  END;

  /*
  * 核销：转款保存校验
  */
  PROCEDURE P_VALI_TURNFEE_SAVE_WRITE_OFF(P_CASH_TURNFEE_ID IN NUMBER, --收款头接口表ID
                                              P_MESSAGE         OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                              ) IS
    --转款头
    CURSOR C_TURNFEE_HEAD IS
      SELECT H.*,
             M.RECEIPT_METHOD_NAME,
             NVL(M.RECEIPT_ENTRY_CODE, 'N') RECEIPT_ENTRY_CODE,
             NVL(M.RECEIPT_CLASS_CODE, 'N') RECEIPT_CLASS_CODE,
             NVL(M.INTO_ERP_FLAG, 'N') INTO_ERP_FLAG,
             NVL(M.INTO_BAN_FLAG, 'N') INTO_BAN_FLAG,
             M.TYPE METHOD_TYPE,
             NVL(M.IS_EFFECTIVE, 'N') IS_EFFECTIVE,
             M.RECEIPT_TYPE,
             M.BUSINESS_TYPE,
             M.ERP_RECEIPT_METHOD_ID,
             M.PAY_MENT_MODE,
             M.ERP_HANDLE,
             M.ERP_AR_ID,
             M.ERP_RECEIPT_METHOD_NAME,
             M.ERP_AR_NAME,
             M.IN_TURNFEE,
             M.IN_TURNFEE_NAME,
             M.OUT_TURNFEE
        FROM CIMS.T_AR_CASH_TURNFEE_HEADER H, CIMS.T_AR_RECEIPT_METHODS M
       WHERE H.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID
         AND H.RECEIPT_METHOD_ID = M.RECEIPT_METHOD_ID;
    HEAD_ROW C_TURNFEE_HEAD%ROWTYPE; --转款头游标行数据
    --转款行
    CURSOR C_TURNFEE_LINES IS
      SELECT *
        FROM CIMS.T_AR_CASH_TURNFEE_LINE L
       WHERE L.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID;
    LINE_ROW             C_TURNFEE_LINES%ROWTYPE; --转款行游标行数据
    V_HEAD_COUNT         NUMBER; --转款头数据总数
    V_LINE_COUNT         NUMBER; --转款行数据总数
    V_ENTITY_ID          NUMBER; --主体ID
    V_LINE_AMOUNT        NUMBER; --单张转款单的分款金额总和
    V_SALES_COUNT        NUMBER; --分款行重复记录数
    V_IN_OUT_SALES_COUNT NUMBER; --转入、转出营销大类相同记录数
    V_IN_ENTITY_ID       NUMBER; --转入主体

  BEGIN
    P_MESSAGE := 'SUCCESS';
    --收转款头数量
    SELECT COUNT(*)
      INTO V_HEAD_COUNT
      FROM CIMS.T_AR_CASH_TURNFEE_HEADER H
     WHERE H.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID;
    IF (V_HEAD_COUNT > 0) THEN
      FOR HEAD_ROW IN C_TURNFEE_HEAD LOOP
        V_ENTITY_ID := HEAD_ROW.ENTITY_ID;
        --转款头：
        IF HEAD_ROW.CASH_TURNFEE_ID IS NULL THEN
          P_MESSAGE := '转款单id为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CASH_TURNFEE_CODE IS NULL THEN
          P_MESSAGE := '转款单据编号为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.RECEIPT_METHOD_ID IS NULL THEN
          P_MESSAGE := '转款单的转款方法ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.STATUS IS NULL THEN
          P_MESSAGE := '转款单的状态ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.STATUS <> 1 THEN
          P_MESSAGE := '转款单的状态不是制单';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_CUSTOMER_ID IS NULL THEN
          P_MESSAGE := '转款单的转入客户ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_CUSTOMER_CODE IS NULL THEN
          P_MESSAGE := '转款单的转入客户编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_CUSTOMER_NAME IS NULL THEN
          P_MESSAGE := '转款单的转入客户名称为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_SALES_CENTER_ID IS NULL THEN
          P_MESSAGE := '转款单的转入营销中心ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_SALES_CENTER_CODE IS NULL THEN
          P_MESSAGE := '转款单的转入营销中心编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_SALES_CENTER_NAME IS NULL THEN
          P_MESSAGE := '转款单的转入营销中心名称为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_ACCOUNT_ID IS NULL THEN
          P_MESSAGE := '转款单的转入账户ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_ACCOUNT_CODE IS NULL THEN
          P_MESSAGE := '转款单的转入账户编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_CUSTOMER_ID IS NULL THEN
          P_MESSAGE := '转款单的转出客户ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_CUSTOMER_CODE IS NULL THEN
          P_MESSAGE := '转款单的转出客户编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_CUSTOMER_NAME IS NULL THEN
          P_MESSAGE := '转款单的转出客户名称为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_SALES_CENTER_ID IS NULL THEN
          P_MESSAGE := '转款单的转出营销中心ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_SALES_CENTER_CODE IS NULL THEN
          P_MESSAGE := '转款单的转出营销中心编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_SALES_CENTER_NAME IS NULL THEN
          P_MESSAGE := '转款单的转出营销中心名称为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_ACCOUNT_ID IS NULL THEN
          P_MESSAGE := '转款单的转出账户ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_ACCOUNT_CODE IS NULL THEN
          P_MESSAGE := '转款单的转出账户编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_ERP_OU_ID IS NULL THEN
          P_MESSAGE := '转款单的转入ERP_OU_ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_ERP_OU_NAME IS NULL THEN
          P_MESSAGE := '转款单的转入ERP_OU_NAME为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_ERP_OU_ID IS NULL THEN
          P_MESSAGE := '转款单的转出ERP_OU_ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_ERP_OU_NAME IS NULL THEN
          P_MESSAGE := '转款单的转出ERP_OU_NAME为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CASH_RECEIPT_DATE IS NULL THEN
          P_MESSAGE := '转款单的单据日期为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.INTO_ERP_FLAG = 'Y' AND HEAD_ROW.GL_DATE IS NULL THEN
          P_MESSAGE := '转款单的总账日期为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.AMOUNT IS NULL THEN
          P_MESSAGE := '转款单的金额为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CURRENCY_CODE IS NULL THEN
          P_MESSAGE := '转款单的币种为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CASH_RECEIPT_CREATED_BY IS NULL THEN
          P_MESSAGE := '转款单的制单人为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CASH_RECEIPT_CREATION_BY_TIME IS NULL THEN
          P_MESSAGE := '转款单的制单时间为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.BUSINESS_TYPE = '3' AND HEAD_ROW.ENTITY_ID IS NULL THEN
          P_MESSAGE := '转款单的主体ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.BUSINESS_TYPE = '6' AND
              HEAD_ROW.IN_ENTITY_ID IS NULL THEN
          P_MESSAGE := '转款单的转入主体ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.BUSINESS_TYPE = '6' AND HEAD_ROW.ENTITY_ID IS NULL THEN
          P_MESSAGE := '转款单的转出主体ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.REMARK IS NULL THEN
          P_MESSAGE := '转款单的备注为空';
          RAISE V_BIZ_EXCEPTION;
          --校验金额必须大于0
        ELSIF HEAD_ROW.AMOUNT <= 0 THEN
          P_MESSAGE := '转款单的金额必须大于0';
          RAISE V_BIZ_EXCEPTION;
        END IF;
        IF HEAD_ROW.BUSINESS_TYPE = '3' THEN
          V_IN_ENTITY_ID := HEAD_ROW.ENTITY_ID;
        ELSIF HEAD_ROW.BUSINESS_TYPE = '6' THEN
          V_IN_ENTITY_ID := HEAD_ROW.IN_ENTITY_ID;
        END IF;

        --转入OU与转出OU必须相同
        IF HEAD_ROW.BUSINESS_TYPE = '3' AND
           HEAD_ROW.IN_ERP_OU_ID <> HEAD_ROW.OUT_ERP_OU_ID THEN
          P_MESSAGE := '转款单的转入OU_ID与转出OU_ID不同';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.BUSINESS_TYPE = '6' AND
              HEAD_ROW.IN_ERP_OU_ID = HEAD_ROW.OUT_ERP_OU_ID THEN
          P_MESSAGE := '转款单的转入OU_ID与转出OU_ID相同';
          RAISE V_BIZ_EXCEPTION;
        END IF;
        --校验转款方法和主体是否对应
        P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_ENTITY_METHOD(V_ENTITY_ID,
                                                            HEAD_ROW.RECEIPT_METHOD_ID,
                                                            HEAD_ROW.BUSINESS_TYPE,
                                                            HEAD_ROW.IN_ENTITY_ID);
        IF P_MESSAGE <> 'SUCCESS' THEN
          RAISE V_BIZ_EXCEPTION;
        END IF;
        --校验转入OU和主体是否对应
        P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_ENTITY_OU(V_IN_ENTITY_ID,
                                                        HEAD_ROW.IN_ERP_OU_ID);
        IF P_MESSAGE <> 'SUCCESS' THEN
          P_MESSAGE := '转入：' || P_MESSAGE;
          RAISE V_BIZ_EXCEPTION;
        END IF;
        --校验转出OU和主体是否对应
        P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_ENTITY_OU(V_ENTITY_ID,
                                                        HEAD_ROW.OUT_ERP_OU_ID);
        IF P_MESSAGE <> 'SUCCESS' THEN
          P_MESSAGE := '转出：' || P_MESSAGE;
          RAISE V_BIZ_EXCEPTION;
        END IF;
        ----------------------------------------------------------------------------------
        --2015-12-15修改，核销生成的单据，不校验中心与账户是否对应
        --校验转入客户、账户、主体是否对应且有效
        P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_ACC(V_IN_ENTITY_ID,
                                                       HEAD_ROW.IN_CUSTOMER_CODE,
                                                       HEAD_ROW.IN_ACCOUNT_CODE);
        IF P_MESSAGE <> 'SUCCESS' THEN
          P_MESSAGE := '转入：' || P_MESSAGE;
          RAISE V_BIZ_EXCEPTION;
        END IF;
        --校验转出客户、账户、主体是否对应且有效
        P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_ACC(V_ENTITY_ID,
                                                       HEAD_ROW.OUT_CUSTOMER_CODE,
                                                       HEAD_ROW.OUT_ACCOUNT_CODE);
        IF P_MESSAGE <> 'SUCCESS' THEN
          P_MESSAGE := '转出：' || P_MESSAGE;
          RAISE V_BIZ_EXCEPTION;
        END IF;
        ----------------------------------------------------------------------------------
        --校验转出客户与OU对应关系
        P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_OU(HEAD_ROW.OUT_CUSTOMER_ID,
                                                      HEAD_ROW.OUT_ERP_OU_ID);
        IF P_MESSAGE <> 'SUCCESS' THEN
          P_MESSAGE := '转出：' || P_MESSAGE;
          RAISE V_BIZ_EXCEPTION;
        END IF;
        --校验转入客户与OU对应关系
        P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_OU(HEAD_ROW.IN_CUSTOMER_ID,
                                                      HEAD_ROW.IN_ERP_OU_ID);
        IF P_MESSAGE <> 'SUCCESS' THEN
          P_MESSAGE := '转入：' || P_MESSAGE;
          RAISE V_BIZ_EXCEPTION;
        END IF;

        --校验附件是否上传,2015-09-12 tianmzh修改，若保函开立为空，则校验附件，否则不校验附件
        IF HEAD_ROW.BOND_DRAW_ID IS NULL THEN
          P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_APPENDIX(HEAD_ROW.RECEIPT_METHOD_ID,
                                                         HEAD_ROW.APPENDIX_ID);
          IF P_MESSAGE <> 'SUCCESS' THEN
            P_MESSAGE := P_MESSAGE;
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END IF;

        IF HEAD_ROW.BUSINESS_TYPE = '3' THEN
          --客户内产品转款：客户相同、中心相同
          IF HEAD_ROW.IN_TURNFEE IS NULL AND HEAD_ROW.OUT_TURNFEE IS NULL THEN
            IF HEAD_ROW.OUT_CUSTOMER_CODE <> HEAD_ROW.IN_CUSTOMER_CODE OR
               HEAD_ROW.OUT_SALES_CENTER_CODE <>
               HEAD_ROW.IN_SALES_CENTER_CODE THEN
              P_MESSAGE := '客户内产品转款：转入转出客户相同、转入转出中心必须相同';
              RAISE V_BIZ_EXCEPTION;
            END IF;
          END IF;
          --客户间转款：客户相同、中心不同；客户不同
          IF HEAD_ROW.IN_TURNFEE IS NOT NULL AND
             HEAD_ROW.OUT_TURNFEE IS NOT NULL THEN
            IF HEAD_ROW.OUT_CUSTOMER_CODE = HEAD_ROW.IN_CUSTOMER_CODE AND
               HEAD_ROW.OUT_SALES_CENTER_CODE =
               HEAD_ROW.IN_SALES_CENTER_CODE THEN
              P_MESSAGE := '客户间转款：转入转出客户相同时，转入转出中心必须不同';
              RAISE V_BIZ_EXCEPTION;
            END IF;
          END IF;
          -- ELSIF HEAD_ROW.BUSINESS_TYPE = '6' THEN
          --  IF HEAD_ROW.OUT_CUSTOMER_CODE <> HEAD_ROW.IN_CUSTOMER_CODE THEN
          --  P_MESSAGE := '跨主体转款：转入转出客户必须相同';
          --  RAISE V_BIZ_EXCEPTION;
          -- END IF;
        END IF;
        --转款行：
        BEGIN
          SELECT COUNT(*)
            INTO V_LINE_COUNT
            FROM CIMS.T_AR_CASH_TURNFEE_LINE L
           WHERE L.CASH_TURNFEE_ID = HEAD_ROW.CASH_TURNFEE_ID;
        END;
        IF V_LINE_COUNT > 0 THEN
          V_LINE_AMOUNT := 0.0;
          --校验分款明细
          FOR LINE_ROW IN C_TURNFEE_LINES LOOP
            IF LINE_ROW.AMOUNT IS NULL THEN
              P_MESSAGE := '转款单的分款明细中金额为空';
              RAISE V_BIZ_EXCEPTION;
            ELSIF LINE_ROW.AMOUNT IS NOT NULL AND LINE_ROW.AMOUNT <= 0 THEN
              P_MESSAGE := '转款单的分款明细中金额小于等于0';
              RAISE V_BIZ_EXCEPTION;
            ELSIF LINE_ROW.IN_SALES_MAIN_TYPE_CODE IS NULL THEN
              P_MESSAGE := '转款单的分款明细中转入营销大类编码为空';
              RAISE V_BIZ_EXCEPTION;
            ELSIF LINE_ROW.OUT_SALES_MAIN_TYPE_CODE IS NULL THEN
              P_MESSAGE := '转款单的分款明细中转出营销大类编码为空';
              RAISE V_BIZ_EXCEPTION;
            ELSE
              --客户内产品转款：转入营销大类与转出营销大类必须不同
              IF HEAD_ROW.IN_TURNFEE IS NULL AND
                 HEAD_ROW.OUT_TURNFEE IS NULL THEN
                --校验转入营销大类与转出营销大类是否相同，若相同则校验失败，否则校验通过
                SELECT COUNT(L.IN_SALES_MAIN_TYPE_CODE)
                  INTO V_IN_OUT_SALES_COUNT
                  FROM CIMS.T_AR_CASH_TURNFEE_LINE L
                 WHERE L.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID
                   AND L.IN_SALES_MAIN_TYPE_CODE =
                       L.OUT_SALES_MAIN_TYPE_CODE;
                IF V_IN_OUT_SALES_COUNT > 0 THEN
                  P_MESSAGE := '转款单的分款明细中转入营销大类和转出营销大类相同';
                  RAISE V_BIZ_EXCEPTION;
                END IF;
              END IF;
              --校验分款中的转入大类和转出大类是否重复，若重复则校验失败，否则校验通过
              SELECT COUNT(*)
                INTO V_SALES_COUNT
                FROM (SELECT L.IN_SALES_MAIN_TYPE_CODE ||
                             L.OUT_SALES_MAIN_TYPE_CODE,
                             COUNT(L.IN_SALES_MAIN_TYPE_CODE ||
                                   L.OUT_SALES_MAIN_TYPE_CODE) SALES_COUNT
                        FROM CIMS.T_AR_CASH_TURNFEE_LINE L
                       WHERE L.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID
                       GROUP BY L.IN_SALES_MAIN_TYPE_CODE ||
                                L.OUT_SALES_MAIN_TYPE_CODE
                      HAVING COUNT(L.IN_SALES_MAIN_TYPE_CODE || L.OUT_SALES_MAIN_TYPE_CODE) > 1);
              IF V_SALES_COUNT > 0 THEN
                P_MESSAGE := '转款单的分款明细中存在重复的分款行，即分款行1和分款行2中的转入营销大类相同，转出营销大类也相同';
                RAISE V_BIZ_EXCEPTION;
              END IF;
              --校验转款行转入营销大类是否有效
              P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_ITEM_CLASS(V_IN_ENTITY_ID,
                                                                    HEAD_ROW.IN_CUSTOMER_CODE,
                                                                    LINE_ROW.IN_SALES_MAIN_TYPE_CODE);
              IF P_MESSAGE <> 'SUCCESS' THEN
                P_MESSAGE := '转入：' || P_MESSAGE;
                RAISE V_BIZ_EXCEPTION;
              END IF;
              --校验转款行转出营销大类是否有效
              P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_ITEM_CLASS(V_ENTITY_ID,
                                                                    HEAD_ROW.OUT_CUSTOMER_CODE,
                                                                    LINE_ROW.OUT_SALES_MAIN_TYPE_CODE);
              IF P_MESSAGE <> 'SUCCESS' THEN
                P_MESSAGE := '转出：' || P_MESSAGE;
                RAISE V_BIZ_EXCEPTION;
              END IF;
            END IF;
            V_LINE_AMOUNT := V_LINE_AMOUNT + LINE_ROW.AMOUNT;
          END LOOP;
        ELSE
          P_MESSAGE := '转款单分款明细为空';
          RAISE V_BIZ_EXCEPTION;
        END IF;
        IF V_LINE_AMOUNT <> HEAD_ROW.AMOUNT THEN
          P_MESSAGE := '转款单的金额与分款明细中金额总和不等';
          RAISE V_BIZ_EXCEPTION;
        END IF;

      END LOOP;
    ELSE
      P_MESSAGE := '获取不到转款单数据，请联系管理员';
      RAISE V_BIZ_EXCEPTION;
    END IF;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_MESSAGE := '转款保存校验失败：' || P_MESSAGE;
    WHEN OTHERS THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_VALIDATE_TURNFEE_SAVE',
                                          SQLCODE,
                                          P_MESSAGE || SQLERRM);
  END;

  /*
  * 转款单确认校验
  */
  PROCEDURE P_VALIDATE_TURNFEE_CONFIRM(P_CASH_TURNFEE_ID        IN NUMBER, --转款头ID
                                       P_ERP_RECEIPT_METHOD_ID  OUT NUMBER, --ERP收款方法ID
                                       P_ERP_BANK_ACCT_USE_ID   OUT NUMBER, --ERP收款方银行账户ID
                                       P_ERP_BANK_ACCTOUNT_ID   OUT NUMBER, --ERP收款银行账户ID
                                       P_ERP_BANK_ACCTOUNT_NAME OUT VARCHAR2, --ERP收款银行账户名称
                                       P_SET_BOOK_ID            OUT NUMBER, --账套ID
                                       P_MESSAGE                OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                       ) IS
    V_HEAD_COUNT NUMBER; --转款头数据总数
    --转款头
    CURSOR C_TURNFEE_HEAD IS
      SELECT H.*,
             M.RECEIPT_METHOD_NAME,
             M.IN_TURNFEE,
             M.OUT_TURNFEE,
             M1.RECEIPT_METHOD_NAME IN_RECEIPT_METHOD_NAME,
             NVL(M1.RECEIPT_ENTRY_CODE, 'N') IN_RECEIPT_ENTRY_CODE,
             NVL(M1.RECEIPT_CLASS_CODE, 'N') IN_RECEIPT_CLASS_CODE,
             NVL(M1.INTO_ERP_FLAG, 'N') IN_INTO_ERP_FLAG,
             NVL(M1.INTO_BAN_FLAG, 'N') IN_INTO_BAN_FLAG,
             M1.TYPE IN_METHOD_TYPE,
             NVL(M1.IS_EFFECTIVE, 'N') IN_IS_EFFECTIVE,
             M1.RECEIPT_TYPE IN_RECEIPT_TYPE,
             M1.BUSINESS_TYPE IN_BUSINESS_TYPE,
             M1.ERP_RECEIPT_METHOD_ID IN_ERP_RECEIPT_METHOD_ID,
             M1.PAY_MENT_MODE IN_PAY_MENT_MODEI,
             M1.ERP_HANDLE IN_ERP_HANDLE,
             M1.ERP_AR_ID IN_ERP_AR_ID,
             M1.ERP_RECEIPT_METHOD_NAME IN_ERP_RECEIPT_METHOD_NAME,
             M1.ERP_AR_NAME IN_ERP_AR_NAME,
             M2.RECEIPT_METHOD_ID OUT_RECEIPT_METHOD_ID,
             M2.RECEIPT_METHOD_NAME OUT_RECEIPT_METHOD_NAME,
             NVL(M2.RECEIPT_ENTRY_CODE, 'N') OUT_RECEIPT_ENTRY_CODE,
             NVL(M2.RECEIPT_CLASS_CODE, 'N') OUT_RECEIPT_CLASS_CODE,
             NVL(M2.INTO_ERP_FLAG, 'N') OUT_INTO_ERP_FLAG,
             NVL(M2.INTO_BAN_FLAG, 'N') OUT_INTO_BAN_FLAG,
             M2.TYPE OUT_METHOD_TYPE,
             NVL(M2.IS_EFFECTIVE, 'N') OUT_IS_EFFECTIVE,
             M2.RECEIPT_TYPE OUT_RECEIPT_TYPE,
             M2.BUSINESS_TYPE OUT_BUSINESS_TYPE,
             M2.ERP_RECEIPT_METHOD_ID OUT_ERP_RECEIPT_METHOD_ID,
             M2.PAY_MENT_MODE OUT_PAY_MENT_MODE,
             M2.ERP_HANDLE OUT_ERP_HANDLE,
             M2.ERP_AR_ID OUT_ERP_AR_ID,
             M2.ERP_RECEIPT_METHOD_NAME OUT_ERP_RECEIPT_METHOD_NAME,
             M2.ERP_AR_NAME OUT_ERP_AR_NAME
        FROM CIMS.T_AR_CASH_TURNFEE_HEADER H, CIMS.T_AR_RECEIPT_METHODS M
        LEFT JOIN CIMS.T_AR_RECEIPT_METHODS M1
          ON M1.RECEIPT_METHOD_ID = M.IN_TURNFEE
        LEFT JOIN CIMS.T_AR_RECEIPT_METHODS M2
          ON M2.RECEIPT_METHOD_ID = M.OUT_TURNFEE
       WHERE H.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID
         AND M.IS_EFFECTIVE = 'Y'
         AND H.RECEIPT_METHOD_ID = M.RECEIPT_METHOD_ID;
    HEAD_ROW C_TURNFEE_HEAD%ROWTYPE; --转款头游标行数据
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --收转款头数量
    SELECT COUNT(*)
      INTO V_HEAD_COUNT
      FROM CIMS.T_AR_CASH_TURNFEE_HEADER H
     WHERE H.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID;
    IF V_HEAD_COUNT > 0 THEN
      --注：转款不引资金
      FOR HEAD_ROW IN C_TURNFEE_HEAD LOOP
        --客户内产品转款确认时不需要校验
        IF HEAD_ROW.IN_TURNFEE IS NOT NULL AND
           HEAD_ROW.OUT_TURNFEE IS NOT NULL THEN
          --客户间转款-转入；引ERP收款
          IF HEAD_ROW.IN_INTO_ERP_FLAG = 'Y' AND
             HEAD_ROW.IN_INTO_BAN_FLAG <> 'Y' THEN
            PKG_AR_COMMON.P_VALIDATE_ERP_RECEIPT_BANK(HEAD_ROW.IN_ERP_OU_ID,
                                                      HEAD_ROW.IN_ERP_RECEIPT_METHOD_NAME,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      HEAD_ROW.IN_RECEIPT_ENTRY_CODE,
                                                      'erp',
                                                      P_ERP_RECEIPT_METHOD_ID,
                                                      P_ERP_BANK_ACCT_USE_ID,
                                                      P_ERP_BANK_ACCTOUNT_ID,
                                                      P_ERP_BANK_ACCTOUNT_NAME,
                                                      P_MESSAGE);
          END IF;
          IF P_MESSAGE <> 'SUCCESS' THEN
            RAISE V_BIZ_EXCEPTION;
          END IF;
          --客户间转款-转出；引ERP AR发票
          IF HEAD_ROW.OUT_INTO_ERP_FLAG = 'Y' AND
             HEAD_ROW.OUT_INTO_BAN_FLAG <> 'Y' THEN
            PKG_AR_COMMON.P_GET_SET_BOOK_ID(HEAD_ROW.OUT_ERP_OU_ID,
                                            P_SET_BOOK_ID,
                                            P_MESSAGE);
          END IF;
          IF P_MESSAGE <> 'SUCCESS' THEN
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END IF;
      END LOOP;
    ELSE
      P_MESSAGE := '获取不到转款单数据，请联系管理员';
    END IF;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_MESSAGE := '转款确认校验失败：' || P_MESSAGE;
    WHEN OTHERS THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_VALIDATE_TURNFEE_CONFIRM',
                                          SQLCODE,
                                          '转款确认校验失败！：' || P_MESSAGE ||
                                          SQLERRM);
  END;

  /*
  * 触发信控
  */
  PROCEDURE P_CREDIT_CONTRL(P_CASH_RECEIPT_ID IN NUMBER, --收款头ID
                            P_ENTITY_ID       IN NUMBER, --主体ID
                            P_ACCOUNT_ID      IN NUMBER, --账户ID
                            P_CUSTOMER_ID     IN NUMBER, --客户ID
                            P_CONTROL_FLAG    IN VARCHAR2, --触发信控方式：收款、退款、三方收款、收款冲销、三方冲销、退款撤销
                            P_USER_ACCOUNT    IN VARCHAR2,
                            P_MESSAGE         OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                            ) IS
    --收款行
    CURSOR C_RECEIPT_LINES IS
      SELECT L.*
        FROM CIMS.T_AR_CASH_RECEIPT_LINES L
       WHERE L.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID;

    LINE_ROW                C_RECEIPT_LINES%ROWTYPE; --收款行游标行数据
    V_TEMP_ID               NUMBER; --临时表ID
    V_CREDIT_RESULT_MESSAGE VARCHAR2(500); --触发信控返回的信息（成功则返回"SUCCESS")
    V_CREDIT_RESULT_NUM     NUMBER; --触发信控返回码
    V_TYPE                  NUMBER; --信控触发类型标志
    V_ACTION                NUMBER; --信控触发动作标志
  BEGIN
    --1、将营销大类的信息存到单据营销大类临时存放表
    FOR LINE_ROW IN C_RECEIPT_LINES LOOP
      --获取临时表ID
      SELECT PKG_CREDIT_ACCOUNT_CONTROL.FUN_GET_CONTROL_TEMP_ID
        INTO V_TEMP_ID
        FROM DUAL;
      --插入分款营销大类数据（行金额必须为正数）
      INSERT INTO T_CREDIT_CONTROL_TEMP
        (CONTROL_TEMP_ID, SALES_MAIN_TYPE, SETTLEMENT_SUM, THREENOPAY_SUM)
      VALUES
        (V_TEMP_ID,
         LINE_ROW.SALES_MAIN_TYPE_CODE,
         ABS(LINE_ROW.AMOUNT),
         NULL);
    END LOOP;
    --收款、退款撤销
    IF P_CONTROL_FLAG = V_CONTROL_RP OR P_CONTROL_FLAG = V_CONTROL_RFRK THEN
      V_TYPE   := 1;
      V_ACTION := 15;
      --退款
    ELSIF P_CONTROL_FLAG = V_CONTROL_RF THEN
      V_TYPE   := 2;
      V_ACTION := 21;
      --三方收款
    ELSIF P_CONTROL_FLAG = V_CONTROL_TP THEN
      V_TYPE   := 3;
      V_ACTION := 17;
      --收款冲销
    ELSIF P_CONTROL_FLAG = V_CONTROL_WO THEN
      V_TYPE   := 1;
      V_ACTION := 16;
      --三方收款冲销
    ELSIF P_CONTROL_FLAG = V_CONTROL_TPWO THEN
      V_TYPE   := 3;
      V_ACTION := 18;
    END IF;
    --2、触发信控，判断是否三方
    IF V_TYPE = 3 THEN
      --触发信控，三方承兑到款
      PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_THREE_PAY(P_ENTITY_ID,
                                                      V_ACTION,
                                                      V_TEMP_ID,
                                                      P_ACCOUNT_ID,
                                                      P_CUSTOMER_ID,
                                                      NULL,
                                                      P_CASH_RECEIPT_ID,
                                                      V_TYPE,
                                                      P_USER_ACCOUNT,
                                                      V_CREDIT_RESULT_NUM,
                                                      V_CREDIT_RESULT_MESSAGE);
    ELSE
      --触发信控，普通到款
      PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_RECEIVE_BILL(P_ENTITY_ID,
                                                         V_ACTION,
                                                         V_TEMP_ID,
                                                         P_ACCOUNT_ID,
                                                         P_CUSTOMER_ID,
                                                         NULL,
                                                         P_CASH_RECEIPT_ID,
                                                         V_TYPE,
                                                         P_USER_ACCOUNT,
                                                         V_CREDIT_RESULT_NUM,
                                                         V_CREDIT_RESULT_MESSAGE);
    END IF;
    P_MESSAGE := V_CREDIT_RESULT_MESSAGE;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_MESSAGE := '触发信控失败：' || P_MESSAGE;
    WHEN OTHERS THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_CREDIT_CONTRL',
                                          SQLCODE,
                                          P_MESSAGE || SQLERRM);
  END;

  /*
  * 转款确认，制单->确认，更改状态，确认人，确认日期
    */
  PROCEDURE P_UPDATE_TURNFEE_STATUS(P_CASH_TURNFEE_ID IN NUMBER, --转款头ID
                                    P_USER_ACCOUNT    IN VARCHAR2, --用户账户
                                    P_MESSAGE         OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                    ) IS
  BEGIN
    UPDATE CIMS.T_AR_CASH_TURNFEE_HEADER T
       SET T.REVIEWED_BY      = P_USER_ACCOUNT,
           T.REVIEWED_BY_TIME = TRUNC(SYSDATE),
           --3-确认
           T.STATUS = '3'
     WHERE T.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID;
    P_MESSAGE := 'SUCCESS';
  EXCEPTION
    WHEN OTHERS THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_UPDATE_TURNFEE_STATUS',
                                          SQLCODE,
                                          P_MESSAGE || SQLERRM);
  END;
  /*
  * 转款单生成收款单
  */
  PROCEDURE P_TURNFEE_TO_RECEIPT(P_CASH_TURNFEE_ID       IN NUMBER, --转款头ID
                                 P_MESSAGE               OUT VARCHAR2, --成功则返回“SUCCESS”，否则返回出错信息
                                 P_CASH_RECEIPT_ID       OUT NUMBER, --成功则返回收款单ID（客户内）
                                 P_OUT_CASH_RECEIPT_ID   OUT NUMBER, --成功则返回转出收款单ID（客户间）
                                 P_IN_CASH_RECEIPT_ID    OUT NUMBER, --成功则返回转入收款单ID（客户间）
                                 P_CASH_RECEIPT_CODE     OUT VARCHAR2, --成功则返回收款单号（客户内）
                                 P_OUT_CASH_RECEIPT_CODE OUT VARCHAR2, --成功则返回转出收款单号（客户间）
                                 P_IN_CASH_RECEIPT_CODE  OUT VARCHAR2 --成功则返回转入收款单号（客户间）
                                 ) IS
    --转款头
    CURSOR C_TURNFEE_HEAD IS
      SELECT H.*,
             M.RECEIPT_METHOD_NAME,
             M.IN_TURNFEE,
             M.OUT_TURNFEE,
             M.BUSINESS_TYPE,
             M1.RECEIPT_METHOD_ID IN_RECEIPT_METHOD_ID,
             M1.RECEIPT_METHOD_NAME IN_RECEIPT_METHOD_NAME,
             NVL(M1.RECEIPT_ENTRY_CODE, 'N') IN_RECEIPT_ENTRY_CODE,
             NVL(M1.RECEIPT_CLASS_CODE, 'N') IN_RECEIPT_CLASS_CODE,
             NVL(M1.INTO_ERP_FLAG, 'N') IN_INTO_ERP_FLAG,
             NVL(M1.INTO_BAN_FLAG, 'N') IN_INTO_BAN_FLAG,
             M1.TYPE IN_METHOD_TYPE,
             NVL(M1.IS_EFFECTIVE, 'N') IN_IS_EFFECTIVE,
             M1.RECEIPT_TYPE IN_RECEIPT_TYPE,
             M1.BUSINESS_TYPE IN_BUSINESS_TYPE,
             M1.ERP_RECEIPT_METHOD_ID IN_ERP_RECEIPT_METHOD_ID,
             M1.PAY_MENT_MODE IN_PAY_MENT_MODEI,
             M1.ERP_HANDLE IN_ERP_HANDLE,
             M1.ERP_AR_ID IN_ERP_AR_ID,
             M1.ERP_RECEIPT_METHOD_NAME IN_ERP_RECEIPT_METHOD_NAME,
             M1.ERP_AR_NAME IN_ERP_AR_NAME,
             M2.RECEIPT_METHOD_ID OUT_RECEIPT_METHOD_ID,
             M2.RECEIPT_METHOD_NAME OUT_RECEIPT_METHOD_NAME,
             NVL(M2.RECEIPT_ENTRY_CODE, 'N') OUT_RECEIPT_ENTRY_CODE,
             NVL(M2.RECEIPT_CLASS_CODE, 'N') OUT_RECEIPT_CLASS_CODE,
             NVL(M2.INTO_ERP_FLAG, 'N') OUT_INTO_ERP_FLAG,
             NVL(M2.INTO_BAN_FLAG, 'N') OUT_INTO_BAN_FLAG,
             M2.TYPE OUT_METHOD_TYPE,
             NVL(M2.IS_EFFECTIVE, 'N') OUT_IS_EFFECTIVE,
             M2.RECEIPT_TYPE OUT_RECEIPT_TYPE,
             M2.BUSINESS_TYPE OUT_BUSINESS_TYPE,
             M2.ERP_RECEIPT_METHOD_ID OUT_ERP_RECEIPT_METHOD_ID,
             M2.PAY_MENT_MODE OUT_PAY_MENT_MODE,
             M2.ERP_HANDLE OUT_ERP_HANDLE,
             M2.ERP_AR_ID OUT_ERP_AR_ID,
             M2.ERP_RECEIPT_METHOD_NAME OUT_ERP_RECEIPT_METHOD_NAME,
             M2.ERP_AR_NAME OUT_ERP_AR_NAME
        FROM CIMS.T_AR_CASH_TURNFEE_HEADER H, CIMS.T_AR_RECEIPT_METHODS M
        LEFT JOIN CIMS.T_AR_RECEIPT_METHODS M1
      --2015-10-12修改，由于跨主体转款转入生成的收款单方法与单据主体不同，导致页面显示报错，故根据转款方法名称获取方法ID，不用转款方法配置的转款-转入方法ID。
      --ON M1.RECEIPT_METHOD_ID = M.IN_TURNFEE
          ON M1.RECEIPT_METHOD_NAME = M.IN_TURNFEE_NAME
        LEFT JOIN CIMS.T_AR_RECEIPT_METHODS M2
          ON M2.RECEIPT_METHOD_ID = M.OUT_TURNFEE
       WHERE H.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID
         AND M.IS_EFFECTIVE = 'Y'
         AND H.RECEIPT_METHOD_ID = M.RECEIPT_METHOD_ID
         AND H.ENTITY_ID = M.ENTITY_ID
         AND NVL(H.IN_ENTITY_ID, H.ENTITY_ID) = M1.ENTITY_ID;

    HEAD_ROW C_TURNFEE_HEAD%ROWTYPE; --转款头游标行数据
    --转款行
    CURSOR C_TURNFEE_LINES IS
      SELECT *
        FROM CIMS.T_AR_CASH_TURNFEE_LINE L
       WHERE L.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID;

    LINE_ROW       C_TURNFEE_LINES%ROWTYPE; --转款行游标行数据
    V_IN_ENTITY_ID NUMBER; -- 转入主体ID
    V_COUNT        NUMBER;

  BEGIN
    P_MESSAGE := 'SUCCESS';
    V_COUNT   := 0;
    FOR HEAD_ROW IN C_TURNFEE_HEAD LOOP
      V_COUNT := V_COUNT + 1;
      --客户内产品转款
      IF HEAD_ROW.IN_TURNFEE IS NULL AND HEAD_ROW.OUT_TURNFEE IS NULL THEN
        BEGIN
          --生成收款单据号
          BEGIN
            P_CASH_RECEIPT_CODE := PKG_BD.F_GET_BILL_NO('ARARCODE',
                                                        NULL,
                                                        HEAD_ROW.ENTITY_ID,
                                                        NULL);
          EXCEPTION
            WHEN OTHERS THEN
              P_MESSAGE := '取收款单据号失败！';
              RAISE V_BIZ_EXCEPTION;
          END;
          --获取收款单据ID
          SELECT S_AR_CASH_RECEIPT_HEADERS.NEXTVAL
            INTO P_CASH_RECEIPT_ID
            FROM DUAL;
          --遍历收款接口表数据，插入收款头表
          INSERT INTO T_AR_CASH_RECEIPT_HEADERS
            (CASH_RECEIPT_ID,
             RECEIPT_METHOD_ID,
             RECEIPT_STATUS_ID,
             ACCOUNT_ID,
             CASH_RECEIPT_CODE,
             CASH_RECEIPT_DATE,
             GL_DATE,
             AMOUNT,
             CURRENCY_CODE,
             CREATED_BY,
             CREATION_DATE,
             REMAEK,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             ACCOUNT_CODE,
             SALES_CENTER_ID,
             ENTITY_ID,
             ERP_OU_NAME,
             ERP_OU_ID,
             UPPER_AMOUNT,
             APPENDIX_ID,
             BOND_DRAW_ID,
             CASH_TURNFEE_ID,
             REVIEWED_BY,
             REVIEWED_DATE,
             --2015-10-12修改，中转关联号
             ATTRIBUTE4,
             --2017-01-03 tianmzh新增修改时间、修改人 
             UPDATED_DATE,
             UPDATED_BY,
             VERSION_NUM)
          VALUES
            (P_CASH_RECEIPT_ID,
             HEAD_ROW.RECEIPT_METHOD_ID,
             '3',
             HEAD_ROW.IN_ACCOUNT_ID,
             P_CASH_RECEIPT_CODE,
             HEAD_ROW.CASH_RECEIPT_DATE,
             HEAD_ROW.GL_DATE,
             0,
             HEAD_ROW.CURRENCY_CODE,
             HEAD_ROW.CASH_RECEIPT_CREATED_BY,
             HEAD_ROW.CASH_RECEIPT_CREATION_BY_TIME,
             HEAD_ROW.REMARK,
             HEAD_ROW.IN_CUSTOMER_ID,
             HEAD_ROW.IN_CUSTOMER_CODE,
             HEAD_ROW.IN_CUSTOMER_NAME,
             HEAD_ROW.IN_ACCOUNT_CODE,
             HEAD_ROW.IN_SALES_CENTER_ID,
             HEAD_ROW.ENTITY_ID,
             HEAD_ROW.IN_ERP_OU_NAME,
             HEAD_ROW.IN_ERP_OU_ID,
             MONEY_TO_RMB(HEAD_ROW.AMOUNT),
             HEAD_ROW.APPENDIX_ID,
             HEAD_ROW.BOND_DRAW_ID,
             HEAD_ROW.CASH_TURNFEE_ID,
             HEAD_ROW.REVIEWED_BY,
             HEAD_ROW.REVIEWED_BY_TIME,
             HEAD_ROW.ATTRIBUTE3,
             --2017-01-03 tianmzh新增修改时间、修改人 
             SYSDATE,
             HEAD_ROW.REVIEWED_BY,
             '0');
          --插入收款行表
          FOR LINE_ROW IN C_TURNFEE_LINES LOOP
            BEGIN
              --正数行
              INSERT INTO T_AR_CASH_RECEIPT_LINES
                (CASH_RECEIPT_LINES_ID,
                 CASH_RECEIPT_ID,
                 AMOUNT,
                 REMARK,
                 SALES_MAIN_TYPE_ID,
                 SALES_MAIN_TYPE_CODE,
                 SALES_MAIN_TYPE_NAME,
                 ENTITY_ID)
              VALUES
                (S_AR_CASH_RECEIPT_LINES.NEXTVAL,
                 P_CASH_RECEIPT_ID,
                 LINE_ROW.AMOUNT,
                 LINE_ROW.REMARK,
                 LINE_ROW.IN_SALES_MAIN_TYPE_ID,
                 LINE_ROW.IN_SALES_MAIN_TYPE_CODE,
                 LINE_ROW.IN_SALES_MAIN_TYPE_NAME,
                 HEAD_ROW.ENTITY_ID);
              --负数行
              INSERT INTO T_AR_CASH_RECEIPT_LINES
                (CASH_RECEIPT_LINES_ID,
                 CASH_RECEIPT_ID,
                 AMOUNT,
                 REMARK,
                 SALES_MAIN_TYPE_ID,
                 SALES_MAIN_TYPE_CODE,
                 SALES_MAIN_TYPE_NAME,
                 ENTITY_ID)
              VALUES
                (S_AR_CASH_RECEIPT_LINES.NEXTVAL,
                 P_CASH_RECEIPT_ID,
                 0 - LINE_ROW.AMOUNT,
                 LINE_ROW.REMARK,
                 LINE_ROW.IN_SALES_MAIN_TYPE_ID,
                 LINE_ROW.IN_SALES_MAIN_TYPE_CODE,
                 LINE_ROW.IN_SALES_MAIN_TYPE_NAME,
                 HEAD_ROW.ENTITY_ID);
            END;
          END LOOP;
          --更新转款头表备注：收款单号
          BEGIN
            UPDATE CIMS.T_AR_CASH_TURNFEE_HEADER T
               SET T.REMARK      = T.REMARK || ' 收款单号' ||
                                   P_CASH_RECEIPT_CODE,
                   T.VERSION_NUM = T.VERSION_NUM + 1
             WHERE T.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID;
          EXCEPTION
            WHEN OTHERS THEN
              BEGIN
                P_MESSAGE := '更新转款单的备注（增加收款单号）异常，请联系管理员！';
                RAISE V_BIZ_EXCEPTION;
              END;
          END;
        END;
      ELSIF HEAD_ROW.IN_TURNFEE IS NOT NULL AND
            HEAD_ROW.OUT_TURNFEE IS NOT NULL THEN
        --客户间转款-转入
        BEGIN
          V_IN_ENTITY_ID := HEAD_ROW.ENTITY_ID;
          IF HEAD_ROW.BUSINESS_TYPE = '6' THEN
            V_IN_ENTITY_ID := HEAD_ROW.IN_ENTITY_ID;
          END IF;
          --生成收款单据号
          BEGIN
            P_IN_CASH_RECEIPT_CODE := PKG_BD.F_GET_BILL_NO('ARARCODE',
                                                           NULL,
                                                           V_IN_ENTITY_ID,
                                                           NULL);
          EXCEPTION
            WHEN OTHERS THEN
              P_MESSAGE := '取收款单据号失败！';
              RAISE V_BIZ_EXCEPTION;
          END;
          --获取收款单据ID
          SELECT S_AR_CASH_RECEIPT_HEADERS.NEXTVAL
            INTO P_IN_CASH_RECEIPT_ID
            FROM DUAL;
          INSERT INTO T_AR_CASH_RECEIPT_HEADERS
            (CASH_RECEIPT_ID,
             RECEIPT_METHOD_ID,
             RECEIPT_STATUS_ID,
             ACCOUNT_ID,
             CASH_RECEIPT_CODE,
             CASH_RECEIPT_DATE,
             GL_DATE,
             AMOUNT,
             CURRENCY_CODE,
             CREATED_BY,
             CREATION_DATE,
             REMAEK,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             ACCOUNT_CODE,
             SALES_CENTER_ID,
             ENTITY_ID,
             ERP_OU_NAME,
             ERP_OU_ID,
             UPPER_AMOUNT,
             APPENDIX_ID,
             BOND_DRAW_ID,
             CASH_TURNFEE_ID,
             REVIEWED_BY,
             REVIEWED_DATE,
             --中转关联号
             ATTRIBUTE4,
             --2017-01-03 tianmzh新增修改时间、修改人 
             UPDATED_DATE,
             UPDATED_BY,
             VERSION_NUM)
          VALUES
            (P_IN_CASH_RECEIPT_ID,
             HEAD_ROW.IN_RECEIPT_METHOD_ID,
             '3',
             HEAD_ROW.IN_ACCOUNT_ID,
             P_IN_CASH_RECEIPT_CODE,
             HEAD_ROW.CASH_RECEIPT_DATE,
             HEAD_ROW.GL_DATE,
             HEAD_ROW.AMOUNT,
             HEAD_ROW.CURRENCY_CODE,
             HEAD_ROW.CASH_RECEIPT_CREATED_BY,
             HEAD_ROW.CASH_RECEIPT_CREATION_BY_TIME,
             HEAD_ROW.REMARK,
             HEAD_ROW.IN_CUSTOMER_ID,
             HEAD_ROW.IN_CUSTOMER_CODE,
             HEAD_ROW.IN_CUSTOMER_NAME,
             HEAD_ROW.IN_ACCOUNT_CODE,
             HEAD_ROW.IN_SALES_CENTER_ID,
             V_IN_ENTITY_ID,
             HEAD_ROW.IN_ERP_OU_NAME,
             HEAD_ROW.IN_ERP_OU_ID,
             MONEY_TO_RMB(HEAD_ROW.AMOUNT),
             HEAD_ROW.APPENDIX_ID,
             HEAD_ROW.BOND_DRAW_ID,
             HEAD_ROW.CASH_TURNFEE_ID,
             HEAD_ROW.REVIEWED_BY,
             HEAD_ROW.REVIEWED_BY_TIME,
             --转款单号
             HEAD_ROW.ATTRIBUTE3,
             --2017-01-03 tianmzh新增修改时间、修改人 
             SYSDATE,
             HEAD_ROW.REVIEWED_BY,
             '0');
          --正数收款行表
          FOR LINE_ROW IN C_TURNFEE_LINES LOOP
            INSERT INTO T_AR_CASH_RECEIPT_LINES
              (CASH_RECEIPT_LINES_ID,
               CASH_RECEIPT_ID,
               AMOUNT,
               REMARK,
               SALES_MAIN_TYPE_ID,
               SALES_MAIN_TYPE_CODE,
               SALES_MAIN_TYPE_NAME,
               ENTITY_ID)
            VALUES
              (S_AR_CASH_RECEIPT_LINES.NEXTVAL,
               P_IN_CASH_RECEIPT_ID,
               LINE_ROW.AMOUNT,
               LINE_ROW.REMARK,
               LINE_ROW.IN_SALES_MAIN_TYPE_ID,
               LINE_ROW.IN_SALES_MAIN_TYPE_CODE,
               LINE_ROW.IN_SALES_MAIN_TYPE_NAME,
               V_IN_ENTITY_ID);
          END LOOP;
        END;
        --客户间转款-转出
        BEGIN
          --生成收款单据号
          BEGIN
            P_OUT_CASH_RECEIPT_CODE := PKG_BD.F_GET_BILL_NO('ARARCODE',
                                                            NULL,
                                                            HEAD_ROW.ENTITY_ID,
                                                            NULL);
          EXCEPTION
            WHEN OTHERS THEN
              P_MESSAGE := '取收款单据号失败！';
              RAISE V_BIZ_EXCEPTION;
          END;
          --获取收款单据ID
          SELECT S_AR_CASH_RECEIPT_HEADERS.NEXTVAL
            INTO P_OUT_CASH_RECEIPT_ID
            FROM DUAL;
          INSERT INTO T_AR_CASH_RECEIPT_HEADERS
            (CASH_RECEIPT_ID,
             RECEIPT_METHOD_ID,
             RECEIPT_STATUS_ID,
             ACCOUNT_ID,
             CASH_RECEIPT_CODE,
             CASH_RECEIPT_DATE,
             GL_DATE,
             AMOUNT,
             CURRENCY_CODE,
             CREATED_BY,
             CREATION_DATE,
             REMAEK,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             ACCOUNT_CODE,
             SALES_CENTER_ID,
             ENTITY_ID,
             ERP_OU_NAME,
             ERP_OU_ID,
             UPPER_AMOUNT,
             APPENDIX_ID,
             BOND_DRAW_ID,
             CASH_TURNFEE_ID,
             REVIEWED_BY,
             REVIEWED_DATE,
             ATTRIBUTE4,
             --2017-01-03 tianmzh新增修改时间、修改人 
             UPDATED_DATE,
             UPDATED_BY,
             VERSION_NUM)
          VALUES
            (P_OUT_CASH_RECEIPT_ID,
             HEAD_ROW.OUT_RECEIPT_METHOD_ID,
             '3',
             HEAD_ROW.OUT_ACCOUNT_ID,
             P_OUT_CASH_RECEIPT_CODE,
             HEAD_ROW.CASH_RECEIPT_DATE,
             HEAD_ROW.GL_DATE,
             0 - HEAD_ROW.AMOUNT,
             HEAD_ROW.CURRENCY_CODE,
             HEAD_ROW.CASH_RECEIPT_CREATED_BY,
             HEAD_ROW.CASH_RECEIPT_CREATION_BY_TIME,
             HEAD_ROW.REMARK,
             HEAD_ROW.OUT_CUSTOMER_ID,
             HEAD_ROW.OUT_CUSTOMER_CODE,
             HEAD_ROW.OUT_CUSTOMER_NAME,
             HEAD_ROW.OUT_ACCOUNT_CODE,
             HEAD_ROW.OUT_SALES_CENTER_ID,
             HEAD_ROW.ENTITY_ID,
             HEAD_ROW.OUT_ERP_OU_NAME,
             HEAD_ROW.OUT_ERP_OU_ID,
             '负' || MONEY_TO_RMB(HEAD_ROW.AMOUNT),
             HEAD_ROW.APPENDIX_ID,
             HEAD_ROW.BOND_DRAW_ID,
             HEAD_ROW.CASH_TURNFEE_ID,
             HEAD_ROW.REVIEWED_BY,
             HEAD_ROW.REVIEWED_BY_TIME,
             HEAD_ROW.ATTRIBUTE3,
             --2017-01-03 tianmzh新增修改时间、修改人 
             SYSDATE,
             HEAD_ROW.REVIEWED_BY,
             '0');
          --负数收款行表
          FOR LINE_ROW IN C_TURNFEE_LINES LOOP
            INSERT INTO T_AR_CASH_RECEIPT_LINES
              (CASH_RECEIPT_LINES_ID,
               CASH_RECEIPT_ID,
               AMOUNT,
               REMARK,
               SALES_MAIN_TYPE_ID,
               SALES_MAIN_TYPE_CODE,
               SALES_MAIN_TYPE_NAME,
               ENTITY_ID)
            VALUES
              (S_AR_CASH_RECEIPT_LINES.NEXTVAL,
               P_OUT_CASH_RECEIPT_ID,
               0 - LINE_ROW.AMOUNT,
               LINE_ROW.REMARK,
               LINE_ROW.OUT_SALES_MAIN_TYPE_ID,
               LINE_ROW.OUT_SALES_MAIN_TYPE_CODE,
               LINE_ROW.OUT_SALES_MAIN_TYPE_NAME,
               HEAD_ROW.ENTITY_ID);
          END LOOP;
        END;
        --更新转款头表备注：收款单号
        BEGIN
          UPDATE CIMS.T_AR_CASH_TURNFEE_HEADER T
             SET T.REMARK      = T.REMARK || ' 收款单号' ||
                                 P_IN_CASH_RECEIPT_CODE || '、' ||
                                 P_OUT_CASH_RECEIPT_CODE,
                 T.VERSION_NUM = T.VERSION_NUM + 1
           WHERE T.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID;
        EXCEPTION
          WHEN OTHERS THEN
            BEGIN
              P_MESSAGE := '更新转款单的备注（增加收款单号）异常，请联系管理员！';
              RAISE V_BIZ_EXCEPTION;
            END;
        END;
      END IF;
    END LOOP;
    IF V_COUNT < 1 THEN
      P_MESSAGE := '转款单生成收款单失败，根据转款单ID（' || P_CASH_TURNFEE_ID ||
                   '）获取数据异常，请联系管理员！';
    END IF;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_MESSAGE := '转款单头、行数据插入收款表失败！：' || P_MESSAGE;
    WHEN OTHERS THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_TURNFEE_TO_RECEIPT',
                                          SQLCODE,
                                          '转款单头、行数据插入收款表失败！：' || SQLERRM);
      RAISE V_BIZ_EXCEPTION;
  END;

  /*
  * 转款确认
  */
  PROCEDURE P_TURNFEE_CONFIRM(P_CASH_TURNFEE_ID       IN NUMBER, --转款头ID
                              P_USER_ACCOUNT          IN VARCHAR2, --用户账户
                              P_MESSAGE               OUT VARCHAR2, --成功则返回“SUCCESS”，否则返回出错信息
                              P_CASH_RECEIPT_CODE     OUT VARCHAR2, --成功则返回收款单号（客户内）
                              P_OUT_CASH_RECEIPT_CODE OUT VARCHAR2, --成功则返回转出收款单号（客户间）
                              P_IN_CASH_RECEIPT_CODE  OUT VARCHAR2 --成功则返回转入收款单号（客户间）
                              ) IS
    --转款头
    CURSOR C_TURNFEE_HEAD IS
      SELECT H.*,
             M.RECEIPT_METHOD_NAME,
             M.BUSINESS_TYPE,
             M.IN_TURNFEE,
             M.OUT_TURNFEE,
             M1.RECEIPT_METHOD_NAME IN_RECEIPT_METHOD_NAME,
             NVL(M1.RECEIPT_ENTRY_CODE, 'N') IN_RECEIPT_ENTRY_CODE,
             NVL(M1.RECEIPT_CLASS_CODE, 'N') IN_RECEIPT_CLASS_CODE,
             NVL(M1.INTO_ERP_FLAG, 'N') IN_INTO_ERP_FLAG,
             NVL(M1.INTO_BAN_FLAG, 'N') IN_INTO_BAN_FLAG,
             M1.TYPE IN_METHOD_TYPE,
             NVL(M1.IS_EFFECTIVE, 'N') IN_IS_EFFECTIVE,
             M1.RECEIPT_TYPE IN_RECEIPT_TYPE,
             M1.BUSINESS_TYPE IN_BUSINESS_TYPE,
             M1.ERP_RECEIPT_METHOD_ID IN_ERP_RECEIPT_METHOD_ID,
             M1.PAY_MENT_MODE IN_PAY_MENT_MODEI,
             M1.ERP_HANDLE IN_ERP_HANDLE,
             M1.ERP_AR_ID IN_ERP_AR_ID,
             M1.ERP_RECEIPT_METHOD_NAME IN_ERP_RECEIPT_METHOD_NAME,
             M1.ERP_AR_NAME IN_ERP_AR_NAME,
             M2.RECEIPT_METHOD_ID OUT_RECEIPT_METHOD_ID,
             M2.RECEIPT_METHOD_NAME OUT_RECEIPT_METHOD_NAME,
             NVL(M2.RECEIPT_ENTRY_CODE, 'N') OUT_RECEIPT_ENTRY_CODE,
             NVL(M2.RECEIPT_CLASS_CODE, 'N') OUT_RECEIPT_CLASS_CODE,
             NVL(M2.INTO_ERP_FLAG, 'N') OUT_INTO_ERP_FLAG,
             NVL(M2.INTO_BAN_FLAG, 'N') OUT_INTO_BAN_FLAG,
             M2.TYPE OUT_METHOD_TYPE,
             NVL(M2.IS_EFFECTIVE, 'N') OUT_IS_EFFECTIVE,
             M2.RECEIPT_TYPE OUT_RECEIPT_TYPE,
             M2.BUSINESS_TYPE OUT_BUSINESS_TYPE,
             M2.ERP_RECEIPT_METHOD_ID OUT_ERP_RECEIPT_METHOD_ID,
             M2.PAY_MENT_MODE OUT_PAY_MENT_MODE,
             M2.ERP_HANDLE OUT_ERP_HANDLE,
             M2.ERP_AR_ID OUT_ERP_AR_ID,
             M2.ERP_RECEIPT_METHOD_NAME OUT_ERP_RECEIPT_METHOD_NAME,
             M2.ERP_AR_NAME OUT_ERP_AR_NAME
        FROM CIMS.T_AR_CASH_TURNFEE_HEADER H, CIMS.T_AR_RECEIPT_METHODS M
        LEFT JOIN CIMS.T_AR_RECEIPT_METHODS M1
          ON M1.RECEIPT_METHOD_ID = M.IN_TURNFEE
        LEFT JOIN CIMS.T_AR_RECEIPT_METHODS M2
          ON M2.RECEIPT_METHOD_ID = M.OUT_TURNFEE
       WHERE H.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID
         AND M.IS_EFFECTIVE = 'Y'
         AND H.RECEIPT_METHOD_ID = M.RECEIPT_METHOD_ID;
    HEAD_ROW                 C_TURNFEE_HEAD%ROWTYPE; --转款头游标行数据
    V_HEAD_COUNT             NUMBER; --转款头总记录数
    V_CASH_RECEIPT_ID        NUMBER; --客户内产品转款生成的收款单ID
    V_OUT_CASH_RECEIPT_ID    NUMBER; --客户间转款-转出收款单ID
    V_IN_CASH_RECEIPT_ID     NUMBER; --客户间转款-转入收款单ID
    V_ERP_RECEIPT_METHOD_ID  NUMBER; --ERP收款方法ID
    V_ERP_BANK_ACCT_USE_ID   NUMBER; --ERP收款方银行账户ID
    V_ERP_BANK_ACCTOUNT_ID   NUMBER; --收款方银行账户ID
    V_ERP_BANK_ACCTOUNT_NAME VARCHAR2(100); --收款方银行账户名称
    V_SET_BOOK_ID            NUMBER; --账套ID
    V_IN_ENTITY_ID           NUMBER; --转入主体ID
  BEGIN
    V_HEAD_COUNT := 0;
    FOR HEAD_ROW IN C_TURNFEE_HEAD LOOP
      V_HEAD_COUNT := V_HEAD_COUNT + 1;
      --保存校验
      PKG_AR_BOND.P_VALIDATE_TURNFEE_SAVE(P_CASH_TURNFEE_ID, P_MESSAGE);
      IF P_MESSAGE <> 'SUCCESS' THEN
        RAISE V_BIZ_EXCEPTION;
      END IF;
      --确认校验
      PKG_AR_BOND.P_VALIDATE_TURNFEE_CONFIRM(P_CASH_TURNFEE_ID,
                                             V_ERP_RECEIPT_METHOD_ID,
                                             V_ERP_BANK_ACCT_USE_ID,
                                             V_ERP_BANK_ACCTOUNT_ID,
                                             V_ERP_BANK_ACCTOUNT_NAME,
                                             V_SET_BOOK_ID,
                                             P_MESSAGE);
      IF P_MESSAGE <> 'SUCCESS' THEN
        RAISE V_BIZ_EXCEPTION;
      END IF;
      --转款单状态：制单->确认
      PKG_AR_BOND.P_UPDATE_TURNFEE_STATUS(P_CASH_TURNFEE_ID,
                                          P_USER_ACCOUNT,
                                          P_MESSAGE);
      IF P_MESSAGE <> 'SUCCESS' THEN
        RAISE V_BIZ_EXCEPTION;
      END IF;
      --转款生成收款
      PKG_AR_BOND.P_TURNFEE_TO_RECEIPT(P_CASH_TURNFEE_ID,
                                       P_MESSAGE,
                                       V_CASH_RECEIPT_ID,
                                       V_OUT_CASH_RECEIPT_ID,
                                       V_IN_CASH_RECEIPT_ID,
                                       P_CASH_RECEIPT_CODE,
                                       P_OUT_CASH_RECEIPT_CODE,
                                       P_IN_CASH_RECEIPT_CODE);
      IF P_MESSAGE <> 'SUCCESS' THEN
        RAISE V_BIZ_EXCEPTION;
      END IF;
      --区分普通转款，跨主体转款
      IF HEAD_ROW.BUSINESS_TYPE = '6' THEN
        V_IN_ENTITY_ID := HEAD_ROW.IN_ENTITY_ID;
      ELSE
        V_IN_ENTITY_ID := HEAD_ROW.ENTITY_ID;
      END IF;
      --触发信控（客户内产品不触发，客户间转款-转出、客户间转款-转入触发，增加或减少客户款项）
      IF HEAD_ROW.IN_TURNFEE IS NOT NULL AND
         HEAD_ROW.OUT_TURNFEE IS NOT NULL THEN
        PKG_AR_BOND.P_CREDIT_CONTRL(V_OUT_CASH_RECEIPT_ID,
                                    HEAD_ROW.ENTITY_ID,
                                    HEAD_ROW.OUT_ACCOUNT_ID,
                                    HEAD_ROW.OUT_CUSTOMER_ID,
                                    V_CONTROL_RF,
                                    P_USER_ACCOUNT,
                                    P_MESSAGE);
        IF P_MESSAGE <> 'SUCCESS' THEN
          P_MESSAGE := '转出：' || P_MESSAGE;
          RAISE V_BIZ_EXCEPTION;
        END IF;
        PKG_AR_BOND.P_CREDIT_CONTRL(V_IN_CASH_RECEIPT_ID,
                                    V_IN_ENTITY_ID,
                                    HEAD_ROW.IN_ACCOUNT_ID,
                                    HEAD_ROW.IN_CUSTOMER_ID,
                                    V_CONTROL_RP,
                                    P_USER_ACCOUNT,
                                    P_MESSAGE);
        IF P_MESSAGE <> 'SUCCESS' THEN
          P_MESSAGE := '转入：' || P_MESSAGE;
          RAISE V_BIZ_EXCEPTION;
        END IF;
      END IF;
      IF HEAD_ROW.IN_TURNFEE IS NOT NULL AND
         HEAD_ROW.OUT_TURNFEE IS NOT NULL THEN
        --插入ERP收款接口表
        IF HEAD_ROW.IN_INTO_ERP_FLAG = 'Y' AND HEAD_ROW.IN_ERP_HANDLE = '1' THEN
          PKG_AR_COMMON.P_INSERT_ERP_RECEIPT(V_IN_CASH_RECEIPT_ID,
                                             V_ERP_RECEIPT_METHOD_ID,
                                             V_ERP_BANK_ACCT_USE_ID,
                                             P_MESSAGE);
          IF P_MESSAGE <> 'SUCCESS' THEN
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END IF;
        --插入ERPAR发票接口表
        IF HEAD_ROW.OUT_INTO_ERP_FLAG = 'Y' AND
           HEAD_ROW.OUT_ERP_HANDLE = '2' THEN
          PKG_AR_COMMON.P_INSERT_AR_INVOICE(V_OUT_CASH_RECEIPT_ID,
                                            V_SET_BOOK_ID,
                                            P_MESSAGE);
          IF P_MESSAGE <> 'SUCCESS' THEN
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END IF;
      END IF;
      P_MESSAGE := 'SUCCESS';
    END LOOP;
    IF V_HEAD_COUNT = 0 THEN
      P_MESSAGE := '获取不到转款单数据，请联系管理员';
      RAISE V_BIZ_EXCEPTION;
    END IF;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_MESSAGE := P_MESSAGE;
    WHEN OTHERS THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_TURNFEE_TO_RECEIPT',
                                          SQLCODE,
                                          P_MESSAGE ||
                                          substr(dbms_utility.format_error_backtrace,
                                                 1,
                                                 100) || SQLERRM);
  END;

  /*
  * 核销：转款确认
  */
  PROCEDURE P_TURNFEE_CONFIRM_WRITE_OFF(P_CASH_TURNFEE_ID       IN NUMBER, --转款头ID
                                        P_USER_ACCOUNT          IN VARCHAR2, --用户账户
                                        P_MESSAGE               OUT VARCHAR2, --成功则返回“SUCCESS”，否则返回出错信息
                                        P_CASH_RECEIPT_CODE     OUT VARCHAR2, --成功则返回收款单号（客户内）
                                        P_OUT_CASH_RECEIPT_CODE OUT VARCHAR2, --成功则返回转出收款单号（客户间）
                                        P_IN_CASH_RECEIPT_CODE  OUT VARCHAR2 --成功则返回转入收款单号（客户间）
                                        ) IS
    --转款头
    CURSOR C_TURNFEE_HEAD IS
      SELECT H.*,
             M.RECEIPT_METHOD_NAME,
             M.BUSINESS_TYPE,
             M.IN_TURNFEE,
             M.OUT_TURNFEE,
             M1.RECEIPT_METHOD_NAME IN_RECEIPT_METHOD_NAME,
             NVL(M1.RECEIPT_ENTRY_CODE, 'N') IN_RECEIPT_ENTRY_CODE,
             NVL(M1.RECEIPT_CLASS_CODE, 'N') IN_RECEIPT_CLASS_CODE,
             NVL(M1.INTO_ERP_FLAG, 'N') IN_INTO_ERP_FLAG,
             NVL(M1.INTO_BAN_FLAG, 'N') IN_INTO_BAN_FLAG,
             M1.TYPE IN_METHOD_TYPE,
             NVL(M1.IS_EFFECTIVE, 'N') IN_IS_EFFECTIVE,
             M1.RECEIPT_TYPE IN_RECEIPT_TYPE,
             M1.BUSINESS_TYPE IN_BUSINESS_TYPE,
             M1.ERP_RECEIPT_METHOD_ID IN_ERP_RECEIPT_METHOD_ID,
             M1.PAY_MENT_MODE IN_PAY_MENT_MODEI,
             M1.ERP_HANDLE IN_ERP_HANDLE,
             M1.ERP_AR_ID IN_ERP_AR_ID,
             M1.ERP_RECEIPT_METHOD_NAME IN_ERP_RECEIPT_METHOD_NAME,
             M1.ERP_AR_NAME IN_ERP_AR_NAME,
             M2.RECEIPT_METHOD_ID OUT_RECEIPT_METHOD_ID,
             M2.RECEIPT_METHOD_NAME OUT_RECEIPT_METHOD_NAME,
             NVL(M2.RECEIPT_ENTRY_CODE, 'N') OUT_RECEIPT_ENTRY_CODE,
             NVL(M2.RECEIPT_CLASS_CODE, 'N') OUT_RECEIPT_CLASS_CODE,
             NVL(M2.INTO_ERP_FLAG, 'N') OUT_INTO_ERP_FLAG,
             NVL(M2.INTO_BAN_FLAG, 'N') OUT_INTO_BAN_FLAG,
             M2.TYPE OUT_METHOD_TYPE,
             NVL(M2.IS_EFFECTIVE, 'N') OUT_IS_EFFECTIVE,
             M2.RECEIPT_TYPE OUT_RECEIPT_TYPE,
             M2.BUSINESS_TYPE OUT_BUSINESS_TYPE,
             M2.ERP_RECEIPT_METHOD_ID OUT_ERP_RECEIPT_METHOD_ID,
             M2.PAY_MENT_MODE OUT_PAY_MENT_MODE,
             M2.ERP_HANDLE OUT_ERP_HANDLE,
             M2.ERP_AR_ID OUT_ERP_AR_ID,
             M2.ERP_RECEIPT_METHOD_NAME OUT_ERP_RECEIPT_METHOD_NAME,
             M2.ERP_AR_NAME OUT_ERP_AR_NAME
        FROM CIMS.T_AR_CASH_TURNFEE_HEADER H, CIMS.T_AR_RECEIPT_METHODS M
        LEFT JOIN CIMS.T_AR_RECEIPT_METHODS M1
          ON M1.RECEIPT_METHOD_ID = M.IN_TURNFEE
        LEFT JOIN CIMS.T_AR_RECEIPT_METHODS M2
          ON M2.RECEIPT_METHOD_ID = M.OUT_TURNFEE
       WHERE H.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID
         AND M.IS_EFFECTIVE = 'Y'
         AND H.RECEIPT_METHOD_ID = M.RECEIPT_METHOD_ID;
    HEAD_ROW                 C_TURNFEE_HEAD%ROWTYPE; --转款头游标行数据
    V_HEAD_COUNT             NUMBER; --转款头总记录数
    V_CASH_RECEIPT_ID        NUMBER; --客户内产品转款生成的收款单ID
    V_OUT_CASH_RECEIPT_ID    NUMBER; --客户间转款-转出收款单ID
    V_IN_CASH_RECEIPT_ID     NUMBER; --客户间转款-转入收款单ID
    V_ERP_RECEIPT_METHOD_ID  NUMBER; --ERP收款方法ID
    V_ERP_BANK_ACCT_USE_ID   NUMBER; --ERP收款方银行账户ID
    V_ERP_BANK_ACCTOUNT_ID   NUMBER; --收款方银行账户ID
    V_ERP_BANK_ACCTOUNT_NAME VARCHAR2(100); --收款方银行账户名称
    V_SET_BOOK_ID            NUMBER; --账套ID
    V_IN_ENTITY_ID           NUMBER; --转入主体ID
  BEGIN
    V_HEAD_COUNT := 0;
    FOR HEAD_ROW IN C_TURNFEE_HEAD LOOP
      V_HEAD_COUNT := V_HEAD_COUNT + 1;
      --核销：保存校验
      PKG_AR_BOND.P_VALI_TURNFEE_SAVE_WRITE_OFF(P_CASH_TURNFEE_ID, P_MESSAGE);
      IF P_MESSAGE <> 'SUCCESS' THEN
        RAISE V_BIZ_EXCEPTION;
      END IF;
      --确认校验
      PKG_AR_BOND.P_VALIDATE_TURNFEE_CONFIRM(P_CASH_TURNFEE_ID,
                                             V_ERP_RECEIPT_METHOD_ID,
                                             V_ERP_BANK_ACCT_USE_ID,
                                             V_ERP_BANK_ACCTOUNT_ID,
                                             V_ERP_BANK_ACCTOUNT_NAME,
                                             V_SET_BOOK_ID,
                                             P_MESSAGE);
      IF P_MESSAGE <> 'SUCCESS' THEN
        RAISE V_BIZ_EXCEPTION;
      END IF;
      --转款单状态：制单->确认
      PKG_AR_BOND.P_UPDATE_TURNFEE_STATUS(P_CASH_TURNFEE_ID,
                                          P_USER_ACCOUNT,
                                          P_MESSAGE);
      IF P_MESSAGE <> 'SUCCESS' THEN
        RAISE V_BIZ_EXCEPTION;
      END IF;
      --转款生成收款
      PKG_AR_BOND.P_TURNFEE_TO_RECEIPT(P_CASH_TURNFEE_ID,
                                       P_MESSAGE,
                                       V_CASH_RECEIPT_ID,
                                       V_OUT_CASH_RECEIPT_ID,
                                       V_IN_CASH_RECEIPT_ID,
                                       P_CASH_RECEIPT_CODE,
                                       P_OUT_CASH_RECEIPT_CODE,
                                       P_IN_CASH_RECEIPT_CODE);
      IF P_MESSAGE <> 'SUCCESS' THEN
        RAISE V_BIZ_EXCEPTION;
      END IF;
      --区分普通转款，跨主体转款
      IF HEAD_ROW.BUSINESS_TYPE = '6' THEN
        V_IN_ENTITY_ID := HEAD_ROW.IN_ENTITY_ID;
      ELSE
        V_IN_ENTITY_ID := HEAD_ROW.ENTITY_ID;
      END IF;
      --触发信控（客户内产品不触发，客户间转款-转出、客户间转款-转入触发，增加或减少客户款项）
      IF HEAD_ROW.IN_TURNFEE IS NOT NULL AND
         HEAD_ROW.OUT_TURNFEE IS NOT NULL THEN
        PKG_AR_BOND.P_CREDIT_CONTRL(V_OUT_CASH_RECEIPT_ID,
                                    HEAD_ROW.ENTITY_ID,
                                    HEAD_ROW.OUT_ACCOUNT_ID,
                                    HEAD_ROW.OUT_CUSTOMER_ID,
                                    V_CONTROL_RF,
                                    P_USER_ACCOUNT,
                                    P_MESSAGE);
        IF P_MESSAGE <> 'SUCCESS' THEN
          P_MESSAGE := '转出：' || P_MESSAGE;
          RAISE V_BIZ_EXCEPTION;
        END IF;
        PKG_AR_BOND.P_CREDIT_CONTRL(V_IN_CASH_RECEIPT_ID,
                                    V_IN_ENTITY_ID,
                                    HEAD_ROW.IN_ACCOUNT_ID,
                                    HEAD_ROW.IN_CUSTOMER_ID,
                                    V_CONTROL_RP,
                                    P_USER_ACCOUNT,
                                    P_MESSAGE);
        IF P_MESSAGE <> 'SUCCESS' THEN
          P_MESSAGE := '转入：' || P_MESSAGE;
          RAISE V_BIZ_EXCEPTION;
        END IF;
      END IF;
      IF HEAD_ROW.IN_TURNFEE IS NOT NULL AND
         HEAD_ROW.OUT_TURNFEE IS NOT NULL THEN
        --插入ERP收款接口表
        IF HEAD_ROW.IN_INTO_ERP_FLAG = 'Y' AND HEAD_ROW.IN_ERP_HANDLE = '1' THEN
          PKG_AR_COMMON.P_INSERT_ERP_RECEIPT(V_IN_CASH_RECEIPT_ID,
                                             V_ERP_RECEIPT_METHOD_ID,
                                             V_ERP_BANK_ACCT_USE_ID,
                                             P_MESSAGE);
          IF P_MESSAGE <> 'SUCCESS' THEN
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END IF;
        --插入ERPAR发票接口表
        IF HEAD_ROW.OUT_INTO_ERP_FLAG = 'Y' AND
           HEAD_ROW.OUT_ERP_HANDLE = '2' THEN
          PKG_AR_COMMON.P_INSERT_AR_INVOICE(V_OUT_CASH_RECEIPT_ID,
                                            V_SET_BOOK_ID,
                                            P_MESSAGE);
          IF P_MESSAGE <> 'SUCCESS' THEN
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END IF;
      END IF;
      P_MESSAGE := 'SUCCESS';
    END LOOP;
    IF V_HEAD_COUNT = 0 THEN
      P_MESSAGE := '获取不到转款单数据，请联系管理员';
      RAISE V_BIZ_EXCEPTION;
    END IF;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_MESSAGE := P_MESSAGE;
    WHEN OTHERS THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_TURNFEE_TO_RECEIPT',
                                          SQLCODE,
                                          P_MESSAGE ||
                                          substr(dbms_utility.format_error_backtrace,
                                                 1,
                                                 100) || SQLERRM);
  END;

  /*
  * 跨OU转款引关联交易
  */
  PROCEDURE P_CROSS_OU_CONNECT_TARNSACTION(P_CASH_TURNFEE_ID              IN NUMBER, --转款头ID
                                           P_MESSAGE                      OUT VARCHAR2, --成功则返回“SUCCESS”，否则返回出错信息
                                           P_REL_INV_APPLY_HEADERS_TRX_NO OUT VARCHAR2 --成功则返回关联交易流水号
                                           ) IS
    P_APPLY_HEADER_ID       NUMBER; --关联交易开票申请接口头表ID
    P_AR_HEADER_TRX_NO      VARCHAR2(32); --交易流水号：统一调用单位规则号”BDESBSERIALNO “进行生成
    P_APPLY_PAY_LINE_TRX_NO VARCHAR(32); --交易流水号：统一调用单位规则号”BDESBSERIALNO “进行生成
    P_APPLY_REC_LINE_TRX_NO VARCHAR(32); --交易流水号：统一调用单位规则号”BDESBSERIALNO “进行生成
    P_IN_ENTITY_ID          T_AR_CASH_TURNFEE_HEADER.IN_ENTITY_ID%TYPE;
    P_OUT_ENTITY_ID         T_AR_CASH_TURNFEE_HEADER.ENTITY_ID%TYPE;
    P_IN_ERP_OU_ID          T_AR_CASH_TURNFEE_HEADER.IN_ERP_OU_ID%TYPE;
    P_IN_ERP_OU_NAME          T_AR_CASH_TURNFEE_HEADER.IN_ERP_OU_NAME%TYPE;
    P_OUT_ERP_OU_ID         T_AR_CASH_TURNFEE_HEADER.OUT_ERP_OU_ID%TYPE;
    P_OUT_ERP_OU_NAME         T_AR_CASH_TURNFEE_HEADER.OUT_ERP_OU_NAME%TYPE;
    P_AMOUNT                T_AR_CASH_TURNFEE_HEADER.AMOUNT%TYPE;
    P_CASH_TURNFEE_CODE     T_AR_CASH_TURNFEE_HEADER.CASH_TURNFEE_CODE%TYPE;

    P_R_VENDOR_SITE         VARCHAR2(500);
    P_GL_DATE   DATE;
    P_CLOSING_STATUS  VARCHAR2(100);
  BEGIN
    P_MESSAGE := 'SUCCESS';
    -- 获取跨OU转款的转出、转入主体，转出、转入ERP_OU_ID,转款金额，转款单据号
    SELECT h.IN_ENTITY_ID,
           h.ENTITY_ID,
           h.IN_ERP_OU_ID,
           h.IN_ERP_OU_NAME,
           h.OUT_ERP_OU_ID,
           h.OUT_ERP_OU_NAME,
           h.AMOUNT,
           h.CASH_TURNFEE_CODE,
           h.GL_DATE
      INTO P_IN_ENTITY_ID,
           P_OUT_ENTITY_ID,
           P_IN_ERP_OU_ID,
           P_IN_ERP_OU_NAME,
           P_OUT_ERP_OU_ID,
           P_OUT_ERP_OU_NAME,
           P_AMOUNT,
           P_CASH_TURNFEE_CODE,
           P_GL_DATE
      FROM cims.T_AR_CASH_TURNFEE_HEADER h
     where h.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID;
    -------------------------跨主体关联交易接口头表 【数据准备】 开始-----------------------------------
    --获取(跨主体关联交易接口头表)主键ID
    BEGIN
      SELECT S_AR_REL_INV_APPLY_HEADERS.NEXTVAL
        INTO P_APPLY_HEADER_ID
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_CROSS_OU_CONNECT_TARNSACTION',
                                            SQLCODE,
                                            '获取跨主体关联交易接口头表序列出错！错误消息：' ||
                                            substr(dbms_utility.format_error_backtrace, 1, 100) || SQLERRM);
        RETURN;
    END;

    BEGIN
    	SELECT DISTINCT r_vendor_site INTO P_R_VENDOR_SITE
      FROM apps.cux_icp_business_all@MDIMS2MDERP a
      WHERE supplier_system = 'GERP' --供方系统
            AND (s_org_id = P_OUT_ERP_OU_ID OR s_org_code = P_OUT_ERP_OU_NAME)--供方OU
            AND requirement_system = 'GERP' --需方系统
            AND (r_org_id = P_IN_ERP_OU_ID OR r_org_code = P_IN_ERP_OU_NAME) --需方OU
            AND nvl(disable_date, SYSDATE + 1) >= SYSDATE;
       IF P_R_VENDOR_SITE NOT IN (PKG_AR_BOND.V_R_VENDOR_SITE_INSIDE, V_R_VENDOR_SITE_NOT_TRADE) THEN
      	RAISE V_BIZ_EXCEPTION;
      END IF;
    EXCEPTION
      WHEN V_BIZ_EXCEPTION THEN
         P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_CROSS_OU_CONNECT_TARNSACTION',
                                            SQLCODE,
                                            '获取供应商地点('||P_R_VENDOR_SITE||')必须为：内部、非贸易型！转款ID：'||P_CASH_TURNFEE_ID||'。错误消息：' ||
                                            substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || SQLERRM);
         RETURN;
      WHEN OTHERS THEN
         P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_CROSS_OU_CONNECT_TARNSACTION',
                                            SQLCODE,
                                            '获取供应商地点出错！转款ID：'||P_CASH_TURNFEE_ID||'。错误消息：' ||
                                            substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || SQLERRM);
        RETURN;
    END;

    --(跨主体关联交易接口头表)交易流水号：统一调用单位规则号”BdEsbSerialNo “进行生成
    BEGIN
      PKG_BD.P_GET_BILL_NO('BdEsbSerialNo',
                           NULL,
                           P_OUT_ENTITY_ID,
                           NULL,
                           P_AR_HEADER_TRX_NO);
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_CROSS_OU_CONNECT_TARNSACTION',
                                            SQLCODE,
                                            '获取跨主体关联交易交易流水号出错！ENTITY_ID：' ||
                                            P_OUT_ENTITY_ID || '！错误消息：' ||
                                            substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || SQLERRM);
        RETURN;
    END;
    -------------------------跨主体关联交易接口头表 【数据准备】 结束-----------------------------------
    --（跨主体关联交易接口头表）【开始插入】
    BEGIN
      
     BEGIN
          select 
             CLOSING_STATUS
           INTO
             P_CLOSING_STATUS
         from 
            intf_erp_period 
         where org_id = P_IN_ERP_OU_ID 
            and APPLICATION_SHORT_NAME='AR' 
            and PERIOD_NAME=  to_char(P_GL_DATE, 'yyyy-mm')
            AND ROWNUM=1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
            P_CLOSING_STATUS:='C';
      END;
    
    
    
      INSERT INTO INTF_AR_REL_INV_APPLY_HEADERS
        (HEADER_ID --主键ID
        ,
         TRX_NO --交易流水号：统一调用单位规则号”BDESBSERIALNO “进行生成
        ,
         INTF_STATUS --接口处理状态：N 新建；P 已提；S 返回成功；E 返回失败
        ,
         NORELATE_TYPES_CODE --关联交易类型编码：必输，插入时调用关联交易程序API自动生成，默认为“ICP001”
        ,
         SOURCE_CODE --来源系统：必输，IMS
        ,
         SOURCE_ORDER_NUMBER --来源单据号：必输，来源系统单据号
        ,
         REQUIREMENT_SYSTEM --应收方系统：必输，AR发票写入的系统，G-ERP或C-ERP
        ,
         SUPPLIER_SYSTEM --应付方系统：必输，AP发票写入的系统，G-ERP或C-ERP
        ,
         SUPPLIER_ORG_ID --应收方OU：必输，转入方组织ID（转入）
        ,
         REQUIREMENT_ORG_ID --应付方OU：必输，转出方组织ID（转出）
        ,
         CURRENCY_CODE --默认“CNY”
        ,
         CONVERSION_TYPE --汇率类型：公司汇率
        ,
         CONVERSION_RATE --汇率：汇率，若为本币，则为1
        ,
         GL_DATE --GL日期：必输，入账日期
        ,
         S_AR_INVOICE_TYPE --事务处理类型：必输，指定为“组织间客户转款”
        ,
         DESCRIPTION --摘要：默认：组织间客户转款
         )
      VALUES
        (P_APPLY_HEADER_ID,
         P_AR_HEADER_TRX_NO,
         'N',
         'ICP001',
         'IMS',
         P_CASH_TURNFEE_CODE,
         'GERP',
         'GERP',
         P_IN_ERP_OU_ID,
         P_OUT_ERP_OU_ID,
         'CNY',
         '公司',
         '1',
         (case when P_CLOSING_STATUS='O' then P_GL_DATE else TRUNC(SYSDATE) end ),
         DECODE(P_R_VENDOR_SITE, V_R_VENDOR_SITE_INSIDE, 'ICP组织间转款', V_R_VENDOR_SITE_NOT_TRADE, 'ICP组织间转款Q'),
         DECODE(P_R_VENDOR_SITE, V_R_VENDOR_SITE_INSIDE, 'ICP组织间转款', V_R_VENDOR_SITE_NOT_TRADE, 'ICP组织间转款Q'));
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_CROSS_OU_CONNECT_TARNSACTION',
                                            SQLCODE,
                                            '跨主体关联交易接口头表插入出错！SOURCE_ORDER_NUMBER：' ||
                                            P_CASH_TURNFEE_CODE ||
                                            '。TRX_NO：' || P_AR_HEADER_TRX_NO ||
                                            '。错误消息：' ||
                                            substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || SQLERRM);
        RETURN;
    END;

    -------------------------跨主体关联交易开票申请应付方行接口 【数据准备】 开始(转出) 开始-----------------------------------
    --(跨主体关联交易开票申请应付方行接口)交易流水号：统一调用单位规则号”BdEsbSerialNo “进行生成
    BEGIN
      PKG_BD.P_GET_BILL_NO('BdEsbSerialNo',
                           NULL,
                           P_OUT_ENTITY_ID,
                           NULL,
                           P_APPLY_PAY_LINE_TRX_NO);
      P_REL_INV_APPLY_HEADERS_TRX_NO := P_APPLY_PAY_LINE_TRX_NO;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_CROSS_OU_CONNECT_TARNSACTION',
                                            SQLCODE,
                                            '获取跨主体关联交易开票申请【应付方】行接口表编码出错！ENTITY_ID：' ||
                                            P_OUT_ENTITY_ID || '。错误消息：' ||
                                            substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || SQLERRM);
        RETURN;
    END;
    -------------------------跨主体关联交易开票申请应付方行接口 【数据准备】 开始(转出) 结束-----------------------------------
    ----（跨主体关联交易开票申请应付方行接口）
    BEGIN
      INSERT INTO INTF_AR_REL_INV_PAY_LINES
        (ID --主键
        ,
         TRX_NO --交易流水号：统一调用单位规则号”BDESBSERIALNO “进行生成
        ,
         SOURCE_ORDER_NUM --应付单据号：必输，取收款的出纳流水号
        ,
         REQ_LINE_ID --行ID：按行号自动排序 默认：“1”
        ,
         REQ_LINE_NUM --行号：行号 默认：“1”
        ,
         AMOUNT --本位币金额：必输
        ,
         INTF_STATUS --接口处理状态：N 新建；P 已提；S 返回成功；E 返回失败
        ,
         HEADER_ID --头表主键
        ,
         BASE_AMOUNT,
         DESCRIPTION)
      VALUES
        (S_AR_REL_INV_PAY_LINES.NEXTVAL,
         P_APPLY_PAY_LINE_TRX_NO,
         P_CASH_TURNFEE_CODE,
         '1',
         '1',
         P_AMOUNT,
         'N',
         P_APPLY_HEADER_ID,
         P_AMOUNT,
         DECODE(P_R_VENDOR_SITE, V_R_VENDOR_SITE_INSIDE, 'ICP组织间转款', V_R_VENDOR_SITE_NOT_TRADE, 'ICP组织间转款Q'));
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_CROSS_OU_CONNECT_TARNSACTION',
                                            SQLCODE,
                                            '跨主体关联交易开票申请【应付方】行接口插入出错！SOURCE_ORDER_NUM：' ||
                                            P_CASH_TURNFEE_CODE || '。错误消息：' ||
                                            substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || SQLERRM);
        RETURN;
    END;

    -------------------------跨主体关联交易开票申请应收方行接口 【数据准备】 开始-----------------------------------

    --(跨主体关联交易开票申请应收方行接口)交易流水号：统一调用单位规则号”BdEsbSerialNo “进行生成
    BEGIN
      PKG_BD.P_GET_BILL_NO('BdEsbSerialNo',
                           NULL,
                           P_IN_ENTITY_ID,
                           NULL,
                           P_APPLY_REC_LINE_TRX_NO);
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_CROSS_OU_CONNECT_TARNSACTION',
                                            SQLCODE,
                                            '获取跨主体关联交易开票申请【应收方】行接口表编码出错！ENTITY_ID：' ||
                                            P_IN_ENTITY_ID || '。错误消息：' ||
                                            substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || SQLERRM);
        RETURN;
    END;
    -------------------------跨主体关联交易开票申请应收方行接口 【数据准备】 结束-----------------------------------

    ----（跨主体关联交易开票申请应收方行接口）
    BEGIN
      INSERT INTO INTF_AR_REL_INV_REC_LINES
        (ID --主键
        ,
         TRX_NO --交易流水号：统一调用单位规则号”BDESBSERIALNO “进行生成
        ,
         SOURCE_ORDER_NUM --应付单据号：必输，取收款的出纳流水号
        ,
         REQ_LINE_ID --行ID：按行号自动排序 默认：“1”
        ,
         REQ_LINE_NUM --行号：行号 默认：“1”
        ,
         AMOUNT --本位币金额：必输
        ,
         INTF_STATUS --接口处理状态：N 新建；P 已提；S 返回成功；E 返回失败
        ,
         HEADER_ID --头表主键
        ,
         REQUEST_QUANTITY --开票数量：默认1
        ,
         SETTLEMENT_PRICE,
         BASE_AMOUNT,
         DESCRIPTION)
      VALUES
        (S_AR_REL_INV_PAY_LINES.NEXTVAL,
         P_APPLY_REC_LINE_TRX_NO,
         P_CASH_TURNFEE_CODE,
         '1',
         '1',
         P_AMOUNT,
         'N',
         P_APPLY_HEADER_ID,
         '1',
         P_AMOUNT,
         P_AMOUNT,
         DECODE(P_R_VENDOR_SITE, V_R_VENDOR_SITE_INSIDE, 'ICP组织间转款', V_R_VENDOR_SITE_NOT_TRADE, 'ICP组织间转款Q'));
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_CROSS_OU_CONNECT_TARNSACTION',
                                            SQLCODE,
                                            '跨主体关联交易开票申请【应收方】行接口插入出错！SOURCE_ORDER_NUM：' ||
                                            P_CASH_TURNFEE_CODE || '。错误消息：' ||
                                            substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || SQLERRM);
        RETURN;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_CROSS_OU_CONNECT_TARNSACTION',
                                            SQLCODE,
                                            '跨主体关联交易开票申请出错。错误消息：' ||
                                            substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || SQLERRM);
      END;
  END;

  -------------------------------------------价差接口------------------------------------------------------------------------

  -- 收款方法校验 by wangyf
  FUNCTION F_RECEIPT_METHOD_VERIFY(P_HEAD_ID           NUMBER, --收款头接口表ID
                                   P_BUSINESS_TYPE     VARCHAR2, --业务分类
                                   P_RECEIPT_METHOD_ID NUMBER --收款方法ID
                                   ) RETURN VARCHAR2 AS

    V_ENTITY_ID    NUMBER; --收款头主体ID
    V_HEAD_COUNT   NUMBER; --收款头数据总数
    V_METHOD_COUNT NUMBER; --收款方法数据总数
    V_CODE_LEN     NUMBER; --票据号长度
    V_DATE_TERM    NUMBER; --票据期限
    V_CURRENT_DATE DATE; --当前系统日期（年月日）
    V_SOURCE_CODE  VARCHAR2(32); --来源单号
    V_MESSAGE      VARCHAR2(1000); --返回信息

    CURSOR C_INTF_RECEIPT_HEAD IS --收款头接口表数据
      SELECT *
        FROM CIMS.T_AR_RECEIPT_HEADER_INTF H
       WHERE H.CASH_RECEIPT_CODE IS NULL
         AND H.HEAD_ID = P_HEAD_ID;

    HEAD_ROW C_INTF_RECEIPT_HEAD%ROWTYPE; --接口表收款头游标行数据

    CURSOR C_RECEIPT_MEHTOD IS --收款头对应的方法
      SELECT *
        FROM CIMS.T_AR_RECEIPT_METHODS M
       WHERE M.RECEIPT_METHOD_ID = P_RECEIPT_METHOD_ID
         AND M.BUSINESS_TYPE = P_BUSINESS_TYPE
         AND M.ENTITY_ID = V_ENTITY_ID;

    METHOD_ROW C_RECEIPT_MEHTOD%ROWTYPE; --收款方法游标行数据

  BEGIN
    V_MESSAGE    := 'SUCCESS';
    V_HEAD_COUNT := 0;
    FOR HEAD_ROW IN C_INTF_RECEIPT_HEAD LOOP
      V_HEAD_COUNT  := V_HEAD_COUNT + 1;
      V_SOURCE_CODE := HEAD_ROW.SOURCE_CODE;
      V_ENTITY_ID   := HEAD_ROW.ENTITY_ID;
      --收款方法数据数量
      V_METHOD_COUNT := 0;
      FOR METHOD_ROW IN C_RECEIPT_MEHTOD LOOP
        V_METHOD_COUNT := V_METHOD_COUNT + 1;
        --收款方法配置项是否正确
        IF METHOD_ROW.INTO_ERP_FLAG = 'Y' THEN
          IF METHOD_ROW.ERP_HANDLE IS NULL THEN
            V_MESSAGE := '收款方法：ERP处理方式为空';
            RAISE V_BIZ_EXCEPTION;
          ELSIF METHOD_ROW.ERP_HANDLE = '1' AND
                METHOD_ROW.ERP_RECEIPT_METHOD_NAME IS NULL THEN
            V_MESSAGE := '收款方法：ERP收款方法为空';
            RAISE V_BIZ_EXCEPTION;
          ELSIF METHOD_ROW.ERP_HANDLE = '2' AND
                METHOD_ROW.ERP_AR_NAME IS NULL THEN
            V_MESSAGE := '收款方法：AR事物处理类型为空';
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END IF;
        IF METHOD_ROW.INTO_BAN_FLAG = 'Y' AND
           METHOD_ROW.PAY_MENT_MODE IS NULL THEN
          V_MESSAGE := '收款方法：资金结算方式为空';
          RAISE V_BIZ_EXCEPTION;
        END IF;

        --票据号长度
        V_CODE_LEN := METHOD_ROW.CASH_CODE_LENGTH;
        --票据期限
        V_DATE_TERM := METHOD_ROW.CASH_DATE_TERM;

        --收款方法配置的必填项
        IF (METHOD_ROW.RECEIPT_REQUIRE = 'Y') THEN
          IF HEAD_ROW.DRAWER IS NULL THEN
            V_MESSAGE := '收款单' || V_SOURCE_CODE || '的出票人为空';
            RAISE V_BIZ_EXCEPTION;
          ELSIF HEAD_ROW.DRAWER_BANK_ACCOUNT IS NULL THEN
            V_MESSAGE := '收款单' || V_SOURCE_CODE || '的出票人银行账户为空';
            RAISE V_BIZ_EXCEPTION;
          ELSIF HEAD_ROW.DRAWER_BANK IS NULL THEN
            V_MESSAGE := '收款单' || V_SOURCE_CODE || '的出票人银行空';
            RAISE V_BIZ_EXCEPTION;
          ELSIF HEAD_ROW.ACCEPTANCE_BANK_NAME IS NULL THEN
            V_MESSAGE := '收款单' || V_SOURCE_CODE || '的承兑银行号为空';
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END IF;

        --若引入资金，第一收款人、第一收款人银行、第一收款人银行账号不能为空
        IF METHOD_ROW.INTO_BAN_FLAG = 'Y' THEN
          IF HEAD_ROW.FIRST_RECEIPT_NAME IS NULL THEN
            V_MESSAGE := '收款单' || V_SOURCE_CODE || '的第一收款人为空';
            RAISE V_BIZ_EXCEPTION;
          ELSIF HEAD_ROW.FIRST_RECEIPT_BANK_ACCOUNT IS NULL THEN
            V_MESSAGE := '收款单' || V_SOURCE_CODE || '的第一收款人银行账户为空';
            RAISE V_BIZ_EXCEPTION;
          ELSIF HEAD_ROW.FIRST_RECEIPT_BANK IS NULL THEN
            V_MESSAGE := '收款单' || V_SOURCE_CODE || '的第一收款人银行为空';
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END IF;

        --校验票据期限：到期日>当天 、 到期日>=单据日期  、 到期日期-单据日期>票据期限
        BEGIN
          --当前系统日期
          SELECT TRUNC(SYSDATE) INTO V_CURRENT_DATE FROM DUAL;
          IF V_DATE_TERM IS NULL THEN
            IF HEAD_ROW.DUE_DATE < V_CURRENT_DATE THEN
              V_MESSAGE := '收款单' || V_SOURCE_CODE || '的到期日期不能小于当天';
              RAISE V_BIZ_EXCEPTION;
            ELSIF HEAD_ROW.DUE_DATE <= HEAD_ROW.CASH_DATE THEN
              V_MESSAGE := '收款单' || V_SOURCE_CODE || '的到期日期不能小于等于单据日期';
              RAISE V_BIZ_EXCEPTION;
            END IF;
          ELSE
            IF HEAD_ROW.DUE_DATE < V_CURRENT_DATE THEN
              V_MESSAGE := '收款单' || V_SOURCE_CODE || '的到期日期不能小于当天';
              RAISE V_BIZ_EXCEPTION;
            ELSIF HEAD_ROW.DUE_DATE IS NULL OR HEAD_ROW.CASH_DATE IS NULL THEN
              V_MESSAGE := '收款单' || V_SOURCE_CODE || '的出票日期/到期日期不能为空';
              RAISE V_BIZ_EXCEPTION;
            ELSIF HEAD_ROW.DUE_DATE - HEAD_ROW.CASH_DATE > V_DATE_TERM THEN
              V_MESSAGE := '收款单' || V_SOURCE_CODE || '的到期日期-出票日期>票据期限';
              RAISE V_BIZ_EXCEPTION;
            END IF;
          END IF;
        END;

        --校验票据号长度（收款方法配置），不校验票据号格式
        IF V_CODE_LEN IS NOT NULL THEN
          --电汇收款方法没有票据号
          IF V_CODE_LEN = 0 AND HEAD_ROW.CASH_CODE IS NOT NULL THEN
            V_MESSAGE := '收款单' || V_SOURCE_CODE || '的票据号长度不为0';
            RAISE V_BIZ_EXCEPTION;
          ELSIF V_CODE_LEN > 0 AND HEAD_ROW.CASH_CODE IS NULL THEN
            V_MESSAGE := '收款单' || V_SOURCE_CODE || '的票据号为空';
            RAISE V_BIZ_EXCEPTION;
          ELSIF HEAD_ROW.CASH_CODE IS NOT NULL AND V_CODE_LEN > 0 AND
                LENGTH(HEAD_ROW.CASH_CODE) <> V_CODE_LEN THEN
            V_MESSAGE := '收款单' || V_SOURCE_CODE || '的票据号长度为' || V_CODE_LEN;
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END IF;
      END LOOP;
      --校验收款必填项（收款方法配置）
      IF V_METHOD_COUNT <> 1 THEN
        V_MESSAGE := '根据收款接口表' || V_SOURCE_CODE || '的收款方法ID' ||
                     P_RECEIPT_METHOD_ID || '、业务分类ID' || P_BUSINESS_TYPE ||
                     '和主体ID' || V_ENTITY_ID || '查询到的收款方法为空';
        RAISE V_BIZ_EXCEPTION;
      END IF;
    END LOOP;
    IF V_HEAD_COUNT <= 0 THEN
      V_MESSAGE := '提供的收款数据有误，请联系管理员';
      RAISE V_BIZ_EXCEPTION;
    END IF;
    RETURN V_MESSAGE;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      RETURN V_MESSAGE;
    WHEN OTHERS THEN
      V_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.F_RECEIPT_METHOD_VERIFY',
                                          SQLCODE,
                                          V_MESSAGE || SQLERRM);
      RETURN V_MESSAGE;
  END;

  -- 收款单校验 by wangyf
  FUNCTION F_RECEIPT_SAVE_VERIFY(P_HEAD_ID NUMBER --收款头接口表ID
                                 ) RETURN VARCHAR2 AS

    V_RECEIPT_METHOD_ID         NUMBER; --收款方法ID
    V_REVERSE_RECEIPT_METHOD_ID NUMBER; --逆向收款方法ID
    V_ENTITY_ID                 NUMBER; --收款头主体ID
    V_CUSTOMER_ID               NUMBER; --客户ID
    V_CUSTOMER_CODE             VARCHAR2(100); --客户编码
    V_ACCOUNT_CODE              VARCHAR2(100); --账户编码
    V_SALES_CENTER_CODE         VARCHAR2(100); --营销中心编码
    V_HEAD_COUNT                NUMBER; --收款头数据总数
    V_SOURCE_CODE               VARCHAR2(32); --来源单号

    V_LINE_COUNT  NUMBER; --收款行数据总数
    V_LINE_AMOUNT NUMBER; --单张收款单的分款金额总和
    V_SALES_COUNT NUMBER; --营销大类重复记录数
    V_SALES_ERROR VARCHAR2(100); --错误信息
    V_MESSAGE     VARCHAR2(1000); --返回信息

    CURSOR C_INTF_RECEIPT_HEAD IS --收款头接口表数据
      SELECT *
        FROM CIMS.T_AR_RECEIPT_HEADER_INTF H
       WHERE H.CASH_RECEIPT_CODE IS NULL
         AND H.HEAD_ID = P_HEAD_ID;

    HEAD_ROW C_INTF_RECEIPT_HEAD%ROWTYPE; --接口表收款头游标行数据

    CURSOR C_RECEIPT_LINES IS --收款行
      SELECT *
        FROM CIMS.T_AR_RECEIPT_LINE_INTF L
       WHERE L.HEAD_ID = P_HEAD_ID;

    LINE_ROW C_RECEIPT_LINES%ROWTYPE; --收款行游标行数据

  BEGIN
    V_MESSAGE    := 'SUCCESS';
    V_HEAD_COUNT := 0;
    FOR HEAD_ROW IN C_INTF_RECEIPT_HEAD LOOP
      V_HEAD_COUNT := V_HEAD_COUNT + 1;
      --校验接口数据是否正确
      V_SOURCE_CODE               := HEAD_ROW.SOURCE_CODE;
      V_RECEIPT_METHOD_ID         := HEAD_ROW.RECEIPT_METHOD_ID;
      V_REVERSE_RECEIPT_METHOD_ID := HEAD_ROW.REVERSE_RECEIPT_METHOD_ID;
      V_ENTITY_ID                 := HEAD_ROW.ENTITY_ID;
      V_CUSTOMER_ID               := HEAD_ROW.CUSTOMER_ID;
      V_CUSTOMER_CODE             := HEAD_ROW.CUSTOMER_CODE;
      V_ACCOUNT_CODE              := HEAD_ROW.ACCOUNT_CODE;
      V_SALES_CENTER_CODE         := HEAD_ROW.SALES_CENTER_CODE;

      --校验收款单接口数据:必填项
      IF HEAD_ROW.HEAD_ID IS NULL THEN
        V_MESSAGE := '收款接口表HEAD_ID为空';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.SOURCE_CODE IS NULL THEN
        V_MESSAGE := '收款接口表来源单号为空';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.RECEIPT_METHOD_ID IS NULL THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的收款方法为空';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.RECEIPT_STATUS_ID IS NULL THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的状态为空';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.RECEIPT_STATUS_ID <> 1 AND
            HEAD_ROW.RECEIPT_STATUS_ID <> 3 THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的状态不是 1 或 3 ';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.CUSTOMER_ID IS NULL THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的客户ID为空';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.SALES_CENTER_ID IS NULL THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的营销中心ID为空';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.ACCOUNT_ID IS NULL THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的账户ID为空';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.ERP_OU_ID IS NULL THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的OU_ID为空';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.CASH_RECEIPT_DATE IS NULL THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的单据日期为空';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.GL_DATE IS NULL THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的总账日期为空';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.AMOUNT IS NULL THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的金额为空';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.CURRENCY_CODE IS NULL THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的币种为空';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.CREATED_BY IS NULL THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的创建人为空';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.CREATION_DATE IS NULL THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的创建时间为空';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.ENTITY_ID IS NULL THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的主体ID为空';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.SOURCE_CODE IS NULL THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的来源单号为空';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.SOURCE_ID IS NULL THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的来源单ID为空';
        RAISE V_BIZ_EXCEPTION;
      ELSIF HEAD_ROW.SOURCE_MODULE IS NULL THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的来源模块为空';
        RAISE V_BIZ_EXCEPTION;
        --校验金额必须大于0
      ELSIF HEAD_ROW.AMOUNT <= 0 THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '的金额必须大于0';
        RAISE V_BIZ_EXCEPTION;
      END IF;

      --校验客户-OU是否对应，且有效
      V_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_OU(V_CUSTOMER_ID,
                                                    HEAD_ROW.ERP_OU_ID);
      IF V_MESSAGE <> 'SUCCESS' THEN
        RAISE V_BIZ_EXCEPTION;
      END IF;

      --校验主体-OU是否一一对应
      V_MESSAGE := PKG_AR_COMMON.F_VALIDATE_ENTITY_OU(V_ENTITY_ID,
                                                      HEAD_ROW.ERP_OU_ID);
      IF V_MESSAGE <> 'SUCCESS' THEN
        RAISE V_BIZ_EXCEPTION;
      END IF;

      --调用收款方法校验过程
      V_MESSAGE := PKG_AR_BOND.F_RECEIPT_METHOD_VERIFY(P_HEAD_ID,
                                                       '1',
                                                       V_RECEIPT_METHOD_ID);
      IF (V_MESSAGE <> 'SUCCESS') THEN
        RAISE V_BIZ_EXCEPTION;
      END IF;

      --校验逆向生成收款单和逆向收款方法
      IF HEAD_ROW.IS_REVERSE_RECEIPT = 'Y' AND
         HEAD_ROW.REVERSE_RECEIPT_METHOD_ID IS NOT NULL THEN
        V_MESSAGE := PKG_AR_BOND.F_RECEIPT_METHOD_VERIFY(P_HEAD_ID,
                                                         '1',
                                                         V_REVERSE_RECEIPT_METHOD_ID);
        IF (V_MESSAGE <> 'SUCCESS') THEN
          RAISE V_BIZ_EXCEPTION;
        END IF;
      ELSIF HEAD_ROW.IS_REVERSE_RECEIPT = 'Y' AND
            HEAD_ROW.REVERSE_RECEIPT_METHOD_ID IS NULL THEN
        V_MESSAGE := '收款接口表' || V_SOURCE_CODE || '逆向收款方法ID为空';
        RAISE V_BIZ_EXCEPTION;
      END IF;

      --校验第一收款人银行账号格式：字母、数字、中划线
      IF HEAD_ROW.FIRST_RECEIPT_BANK_ACCOUNT IS NOT NULL THEN
        IF REGEXP_SUBSTR(HEAD_ROW.FIRST_RECEIPT_BANK_ACCOUNT,
                         '[0-9a-zA-Z\-]*') <>
           HEAD_ROW.FIRST_RECEIPT_BANK_ACCOUNT THEN
          V_MESSAGE := '收款单' || V_SOURCE_CODE || '的第一收款人银行账户格式不正确';
          RAISE V_BIZ_EXCEPTION;
        END IF;
      END IF;

      --校验出票人银行账号格式：字母、数字、中划线
      IF HEAD_ROW.DRAWER_BANK_ACCOUNT IS NOT NULL THEN
        IF REGEXP_SUBSTR(HEAD_ROW.DRAWER_BANK_ACCOUNT, '[0-9a-zA-Z\-]*') <>
           HEAD_ROW.DRAWER_BANK_ACCOUNT THEN
          V_MESSAGE := '收款单' || V_SOURCE_CODE || '的出票人银行账户格式不正确';
          RAISE V_BIZ_EXCEPTION;
        END IF;
      END IF;

      --校验票据号格式：数字
      IF HEAD_ROW.CASH_CODE IS NOT NULL THEN
        IF REGEXP_SUBSTR(HEAD_ROW.CASH_CODE, '[0-9]*') <>
           HEAD_ROW.CASH_CODE THEN
          V_MESSAGE := '收款单' || V_SOURCE_CODE || '的票据号格式不正确';
          RAISE V_BIZ_EXCEPTION;
        END IF;
      END IF;

      --校验客户-中心-账户-主体是否一一对应，且有效
      V_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_CENTER_ACC(V_ENTITY_ID,
                                                            V_CUSTOMER_CODE,
                                                            V_SALES_CENTER_CODE,
                                                            V_ACCOUNT_CODE);
      IF V_MESSAGE <> 'SUCCESS' THEN
        RAISE V_BIZ_EXCEPTION;
      END IF;
      --校验客户下的营销大类
      BEGIN
        SELECT COUNT(*)
          INTO V_LINE_COUNT
          FROM CIMS.T_AR_RECEIPT_LINE_INTF L
         WHERE L.HEAD_ID = HEAD_ROW.HEAD_ID;

        -- 校验模块间收款行接口表数据量
        IF V_LINE_COUNT > 0 THEN
          V_LINE_AMOUNT := 0.0;
          --校验分款明细
          FOR LINE_ROW IN C_RECEIPT_LINES LOOP
            IF LINE_ROW.LINE_AMOUNT IS NULL THEN
              V_MESSAGE := '收款单' || V_SOURCE_CODE || '的分款明细中金额为空';
              RAISE V_BIZ_EXCEPTION;
            ELSIF LINE_ROW.LINE_AMOUNT <= 0 THEN
              V_MESSAGE := '收款单' || V_SOURCE_CODE || '的分款明细中金额必须大于0';
              RAISE V_BIZ_EXCEPTION;
            ELSIF LINE_ROW.SALES_MAIN_TYPE_CODE IS NULL THEN
              V_MESSAGE := '收款单' || V_SOURCE_CODE || '的分款明细中营销大类编码为空';
              RAISE V_BIZ_EXCEPTION;
            ELSE
              --校验营销大类是否重复
              BEGIN
                SELECT COUNT(*)
                  INTO V_SALES_COUNT
                  FROM (SELECT L.SALES_MAIN_TYPE_CODE,
                               COUNT(L.SALES_MAIN_TYPE_CODE) SALES_COUNT
                          FROM CIMS.T_AR_RECEIPT_LINE_INTF L
                         WHERE L.HEAD_ID = P_HEAD_ID
                         GROUP BY L.SALES_MAIN_TYPE_CODE
                        HAVING COUNT(L.SALES_MAIN_TYPE_CODE) > 1);
              END;
              IF V_SALES_COUNT > 0 THEN
                V_MESSAGE := '收款单' || V_SOURCE_CODE || '的分款明细中营销大类重复';
                RAISE V_BIZ_EXCEPTION;
              END IF;

              --校验营销大类是否有效，是否属于客户
              V_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_ITEM_CLASS(V_ENTITY_ID,
                                                                    V_CUSTOMER_CODE,
                                                                    LINE_ROW.SALES_MAIN_TYPE_CODE);
              IF V_MESSAGE <> 'SUCCESS' THEN
                RAISE V_BIZ_EXCEPTION;
              END IF;

            END IF;
            V_LINE_AMOUNT := V_LINE_AMOUNT + LINE_ROW.LINE_AMOUNT;
          END LOOP;
        ELSE
          V_MESSAGE := '收款单行为空';
          RAISE V_BIZ_EXCEPTION;
        END IF;
        IF V_SALES_ERROR = 'SUCCESS' AND V_LINE_AMOUNT <> HEAD_ROW.AMOUNT THEN
          V_MESSAGE := '收款单' || V_SOURCE_CODE || '的金额与分款明细中金额总和不等';
          RAISE V_BIZ_EXCEPTION;
        END IF;
      END;

    END LOOP;
    IF V_HEAD_COUNT < 1 THEN
      V_MESSAGE := '提供的收款数据有误，请联系管理员';
      RAISE V_BIZ_EXCEPTION;
    END IF;
    RETURN V_MESSAGE;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      RETURN V_MESSAGE;
    WHEN OTHERS THEN
      V_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_RECEIPT_HEAD_VERIFY',
                                          SQLCODE,
                                          V_MESSAGE || SQLERRM);
      RETURN V_MESSAGE;
  END;

  -- 收款单生成（制单）
  PROCEDURE P_RECEIPT_HEAD_SAVE(P_HEAD_ID                   IN NUMBER, --收款头接口表ID
                                P_MESSAGE                   OUT VARCHAR2, --成功返回'SUCCESS'，否则返回出错信息
                                P_CASH_RECEIPT_ID           OUT NUMBER, --返回生成的收款单ID
                                P_REVERSE_CASH_RECEIPT_ID   OUT NUMBER, --返回生成的逆向收款单ID
                                P_CASH_RECEIPT_CODE         OUT VARCHAR2, --返回生成的收款单号
                                P_REVERSE_CASH_RECEIPT_CODE OUT VARCHAR2 --返回生成的逆向收款单号，若不生成逆向收款单则为 NULL
                                ) IS

    V_RECEIPT_METHOD_ID         NUMBER; --收款方法ID
    V_REVERSE_RECEIPT_METHOD_ID NUMBER; --逆向收款方法ID
    V_ENTITY_ID                 NUMBER; --收款头主体ID
    V_CUSTOMER_CODE             VARCHAR2(100); --客户编码
    V_ACCOUNT_CODE              VARCHAR2(100); --账户编码
    V_SALES_CENTER_CODE         VARCHAR2(100); --营销中心编码

    V_SOURCE_CODE VARCHAR2(32); --来源单号

    --V_APPENDIX_FLAG                 VARCHAR2(2);                 --附件上传标志Y/N
    --V_APPENDIX_COUNT                NUMBER;                      --附件数据总数
    --V_RP_APPENDIX                   VARCHAR2(32);                --附件ID -save

    V_CUSTOMER_ID       NUMBER; --客户ID
    V_CUSTOMER_NAME     VARCHAR2(300); --客户名称
    V_ACCOUNT_ID        NUMBER; --账户ID
    V_SALES_CENTER_ID   NUMBER; --营销中心ID
    V_SALES_CENTER_NAME VARCHAR2(240); --营销中心名称

    V_BUDGET_ITEM_CODE          VARCHAR2(32); --预算项目编码
    V_ERP_OU_NAME               VARCHAR2(300); --OU名称
    V_SALES_MAIN_TYPE_ID        NUMBER; --营销大类ID
    V_SALES_MAIN_TYPE_NAME      VARCHAR2(32); --营销大类名称
    V_CASH_RECEIPT_CODE         VARCHAR2(32); --收款单据编号
    V_CASH_RECEIPT_ID           NUMBER; --收款头ID
    V_REVERSE_CASH_RECEIPT_CODE VARCHAR2(32); --逆向收款单据编号
    V_REVERSE_CASH_RECEIPT_ID   NUMBER; --逆向收款头ID

    CURSOR C_INTF_RECEIPT_HEAD IS --收款头接口表数据
      SELECT *
        FROM CIMS.T_AR_RECEIPT_HEADER_INTF H
       WHERE H.CASH_RECEIPT_CODE IS NULL
         AND H.HEAD_ID = P_HEAD_ID;

    HEAD_ROW C_INTF_RECEIPT_HEAD%ROWTYPE; --接口表收款头游标行数据

    CURSOR C_RECEIPT_LINES IS --收款行
      SELECT *
        FROM CIMS.T_AR_RECEIPT_LINE_INTF L
       WHERE L.HEAD_ID = P_HEAD_ID;

    LINE_ROW C_RECEIPT_LINES%ROWTYPE; --收款行游标行数据

    CURSOR C_SALES_MAIN_TYPE IS --客户下有效营销大类
      SELECT T2.ITEM_CLASS_ID SALES_MAIN_TYPE_ID,
             T1.SALES_MAIN_TYPE_CODE,
             T1.SALES_MAIN_TYPE_NAME
        FROM T_CUSTOMER_SALES_MAIN_TYPE T1, T_BD_ITEM_CLASS T2
       WHERE T1.SALES_MAIN_TYPE_CODE = T2.CLASS_CODE
         AND T1.ENTITY_ID = T2.ENTITY_ID
         AND T1.ACTIVE_FLAG = 'Active'
         AND T2.ACTIVE_FLAG = 'Y'
         AND T1.ENTITY_ID = V_ENTITY_ID
         AND T1.CUSTOM_CODE = V_CUSTOMER_CODE;

    SALES_MAIN_TYPE_ROW C_SALES_MAIN_TYPE%ROWTYPE; --有效营销大类游标行数据

    /*CURSOR C_RP_APPENDIX IS                                      --附件
      SELECT *
        FROM CIMS.INTF_AR_APPENDIX_CCS AP
       WHERE AP.SOURCE_CODE = V_SOURCE_CODE;

    RP_APPENDIX_ROW C_RP_APPENDIX%ROWTYPE;                       --附件游标行数据*/

  BEGIN
    P_MESSAGE := 'SUCCESS';

    --调用收款单校验
    P_MESSAGE := PKG_AR_BOND.F_RECEIPT_SAVE_VERIFY(P_HEAD_ID);
    IF (P_MESSAGE = 'SUCCESS') THEN
      FOR HEAD_ROW IN C_INTF_RECEIPT_HEAD LOOP

        V_SOURCE_CODE               := HEAD_ROW.SOURCE_CODE;
        V_RECEIPT_METHOD_ID         := HEAD_ROW.RECEIPT_METHOD_ID;
        V_REVERSE_RECEIPT_METHOD_ID := HEAD_ROW.REVERSE_RECEIPT_METHOD_ID;
        V_ENTITY_ID                 := HEAD_ROW.ENTITY_ID;
        V_CUSTOMER_CODE             := HEAD_ROW.CUSTOMER_CODE;
        V_ACCOUNT_CODE              := HEAD_ROW.ACCOUNT_CODE;
        V_SALES_CENTER_CODE         := HEAD_ROW.SALES_CENTER_CODE;

        SELECT V2.CUSTOMER_ID,
               V2.CUSTOMER_NAME,
               V2.ACCOUNT_ID,
               V2.SALES_CENTER_ID,
               V2.SALES_CENTER_NAME
          INTO V_CUSTOMER_ID, --客户ID
               V_CUSTOMER_NAME, --客户名称
               V_ACCOUNT_ID, --账户ID
               V_SALES_CENTER_ID, --营销中心ID
               V_SALES_CENTER_NAME --营销中心名称
          FROM CIMS.V_CUSTOMER_ACCOUNT_SALECENTER V2
         WHERE V2.CUSTOMER_CODE = V_CUSTOMER_CODE
           AND V2.SALES_CENTER_CODE = V_SALES_CENTER_CODE
           AND V2.ACCOUNT_CODE = V_ACCOUNT_CODE
           AND V2.ENTITY_ID = V_ENTITY_ID
           AND V2.ACTIVE_FLAG = 'Active'
           AND V2.ACCOUNT_STATUS = '1'
           AND V2.ORGACTIVE_FLAG = 'Active';

        /* --附件
        IF V_APPENDIX_COUNT > 0 THEN
          --附件ID
          SELECT 'ARRP' || S_AR_RP_APPENDIX.NEXTVAL
            INTO V_RP_APPENDIX
            FROM DUAL;
          FOR RP_APPENDIX_ROW IN C_RP_APPENDIX LOOP
            --插入附件表
            INSERT INTO IMS_FILEINFO_INTERFACE
              (ID, BUSINESS_ID, BUSINESS_TYPE, FILE_PATH, CREATED_DATE)
            VALUES
              (SEQ_IMS_FILEINFO.NEXTVAL,
               V_RP_APPENDIX,
               'arReceiptCode',
               RP_APPENDIX_ROW.FILE_PATH,
               SYSDATE);
          END LOOP;
        END IF;*/

        --预算项目
        BEGIN
          SELECT NVL(T.BUDGETITEMCODE, '0314')
            INTO V_BUDGET_ITEM_CODE
            FROM CIMS.INTF_GTSP_BUDGET_PROJECT T
           WHERE T.ATTRIBUTE1 = 'Y';
        EXCEPTION
          WHEN OTHERS THEN
            V_BUDGET_ITEM_CODE := '0314';
        END;

        --OU名称
        SELECT U.CODE_NAME
          INTO V_ERP_OU_NAME
          FROM CIMS.V_UP_CODELIST U
         WHERE U.CODETYPE = 'ar_ou_id'
           AND U.CODE_VALUE = HEAD_ROW.ERP_OU_ID;

        --生成收款单据号
        BEGIN
          V_CASH_RECEIPT_CODE := PKG_BD.F_GET_BILL_NO('ARARCODE',
                                                      NULL,
                                                      HEAD_ROW.ENTITY_ID,
                                                      NULL);
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := '取收款单据号失败！';
            RAISE V_BIZ_EXCEPTION;
        END;

        --获取收款单据ID
        SELECT S_AR_CASH_RECEIPT_HEADERS.NEXTVAL
          INTO V_CASH_RECEIPT_ID
          FROM DUAL;

        BEGIN
          --遍历收款接口表数据，插入收款头表
          INSERT INTO T_AR_CASH_RECEIPT_HEADERS
            (CASH_RECEIPT_ID,
             RECEIPT_METHOD_ID,
             RECEIPT_STATUS_ID,
             ACCOUNT_ID,
             CASH_RECEIPT_CODE,
             CASH_RECEIPT_DATE,
             GL_DATE,
             AMOUNT,
             CURRENCY_CODE,
             CASH_CODE,
             SUB_CASH_CODE,
             UNITE_FLAG,
             CASH_DATE,
             DUE_DATE,
             DRAWER,
             DRAWER_BANK_ACCOUNT,
             DRAWER_BANK,
             BACK_WRITE_NAME,
             FIRST_RECEIPT_NAME,
             FIRST_RECEIPT_BANK_ACCOUNT,
             FIRST_RECEIPT_BANK,
             ACCEPTANCE_BANK_NAME,
             BUDGET_ITEM_NAME,
             CREATED_BY,
             CREATION_DATE,
             REMAEK,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             ACCOUNT_CODE,
             SALES_CENTER_ID,
             ENTITY_ID,
             IS_HONESTLY,
             SOURCE_TYPE,
             CONTRACT_NUM,
             ERP_OU_NAME,
             ERP_OU_ID,
             UPPER_AMOUNT,
             --APPENDIX_ID,
             ATTRIBUTE3,
             DISCOUNT_ORDER_NUMBER,
             VERSION_NUM)
          VALUES
            (V_CASH_RECEIPT_ID,
             HEAD_ROW.RECEIPT_METHOD_ID,
             '1',
             V_ACCOUNT_ID,
             V_CASH_RECEIPT_CODE,
             HEAD_ROW.CASH_RECEIPT_DATE,
             HEAD_ROW.GL_DATE,
             HEAD_ROW.AMOUNT,
             HEAD_ROW.CURRENCY_CODE,
             HEAD_ROW.CASH_CODE,
             HEAD_ROW.SUB_CASH_CODE,
             HEAD_ROW.UNITE_FLAG,
             HEAD_ROW.CASH_DATE,
             HEAD_ROW.DUE_DATE,
             HEAD_ROW.DRAWER,
             HEAD_ROW.DRAWER_BANK_ACCOUNT,
             HEAD_ROW.DRAWER_BANK,
             HEAD_ROW.BACK_WRITE_NAME,
             HEAD_ROW.FIRST_RECEIPT_NAME,
             HEAD_ROW.FIRST_RECEIPT_BANK_ACCOUNT,
             HEAD_ROW.FIRST_RECEIPT_BANK,
             HEAD_ROW.ACCEPTANCE_BANK_NAME,
             V_BUDGET_ITEM_CODE,
             HEAD_ROW.CREATED_BY,
             HEAD_ROW.CREATION_DATE,
             HEAD_ROW.SOURCE_CODE || '#' || HEAD_ROW.REMAEK,
             V_CUSTOMER_ID,
             V_CUSTOMER_CODE,
             V_CUSTOMER_NAME,
             V_ACCOUNT_CODE,
             V_SALES_CENTER_ID,
             HEAD_ROW.ENTITY_ID,
             HEAD_ROW.IS_HONESTLY,
             HEAD_ROW.SOURCE_TYPE,
             HEAD_ROW.CONTRACT_NUM,
             V_ERP_OU_NAME,
             HEAD_ROW.ERP_OU_ID,
             MONEY_TO_RMB(HEAD_ROW.AMOUNT),
             --V_RP_APPENDIX,
             HEAD_ROW.SOURCE_SYSTEM || ' ' || HEAD_ROW.SOURCE_MODULE,
             HEAD_ROW.SOURCE_CODE,
             '0');
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_RECEIPT_HEAD_SAVE',
                                                SQLCODE,
                                                '价差转到款，接口表头数据插入业务表失败！：' ||
                                                SQLERRM);
            RAISE V_BIZ_EXCEPTION;
        END;

        --遍历收款接口表行数据，插入收款行表

        FOR LINE_ROW IN C_RECEIPT_LINES LOOP
          FOR SALES_MAIN_TYPE_ROW IN C_SALES_MAIN_TYPE LOOP
            IF LINE_ROW.SALES_MAIN_TYPE_CODE =
               SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_CODE THEN
              V_SALES_MAIN_TYPE_ID   := SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_ID; --从营销大类表得到营销大类ID
              V_SALES_MAIN_TYPE_NAME := SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_NAME; --从营销大类表得到营销大类(微波/厨具/吸尘器/整体橱柜/商橱)
              EXIT;
            END IF;
          END LOOP;
          BEGIN
            INSERT INTO T_AR_CASH_RECEIPT_LINES
              (CASH_RECEIPT_LINES_ID,
               CASH_RECEIPT_ID,
               AMOUNT,
               REMARK,
               SALES_MAIN_TYPE_ID,
               SALES_MAIN_TYPE_CODE,
               SALES_MAIN_TYPE_NAME,
               ENTITY_ID)
            VALUES
              (S_AR_CASH_RECEIPT_LINES.NEXTVAL,
               V_CASH_RECEIPT_ID,
               LINE_ROW.LINE_AMOUNT,
               LINE_ROW.REMARK,
               V_SALES_MAIN_TYPE_ID,
               LINE_ROW.SALES_MAIN_TYPE_CODE,
               V_SALES_MAIN_TYPE_NAME,
               HEAD_ROW.ENTITY_ID);
          EXCEPTION
            WHEN OTHERS THEN
              P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_RECEIPT_HEAD_SAVE',
                                                  SQLCODE,
                                                  '价差转到款，接口表行数据插入业务表失败！：' ||
                                                  SQLERRM);
              RAISE V_BIZ_EXCEPTION;
          END;
        END LOOP;

        --是否生成逆向收款单
        IF HEAD_ROW.IS_REVERSE_RECEIPT = 'Y' THEN
          --成一张AMONUNT为负值的逆向收款单
          --生成逆向收款单据号
          BEGIN
            V_REVERSE_CASH_RECEIPT_CODE := PKG_BD.F_GET_BILL_NO('ARARCODE',
                                                                NULL,
                                                                HEAD_ROW.ENTITY_ID,
                                                                NULL);
          EXCEPTION
            WHEN OTHERS THEN
              P_MESSAGE := '取逆向收款单据号失败！';
              RAISE V_BIZ_EXCEPTION;
          END;

          --获取逆向收款单据ID
          SELECT S_AR_CASH_RECEIPT_HEADERS.NEXTVAL
            INTO V_REVERSE_CASH_RECEIPT_ID
            FROM DUAL;

          BEGIN
            --遍历收款接口表数据，插入收款头表
            INSERT INTO T_AR_CASH_RECEIPT_HEADERS
              (CASH_RECEIPT_ID,
               RECEIPT_METHOD_ID,
               RECEIPT_STATUS_ID,
               ACCOUNT_ID,
               CASH_RECEIPT_CODE,
               CASH_RECEIPT_DATE,
               GL_DATE,
               AMOUNT,
               CURRENCY_CODE,
               CASH_CODE,
               SUB_CASH_CODE,
               UNITE_FLAG,
               CASH_DATE,
               DUE_DATE,
               DRAWER,
               DRAWER_BANK_ACCOUNT,
               DRAWER_BANK,
               BACK_WRITE_NAME,
               FIRST_RECEIPT_NAME,
               FIRST_RECEIPT_BANK_ACCOUNT,
               FIRST_RECEIPT_BANK,
               ACCEPTANCE_BANK_NAME,
               BUDGET_ITEM_NAME,
               CREATED_BY,
               CREATION_DATE,
               REMAEK,
               CUSTOMER_ID,
               CUSTOMER_CODE,
               CUSTOMER_NAME,
               ACCOUNT_CODE,
               SALES_CENTER_ID,
               ENTITY_ID,
               IS_HONESTLY,
               SOURCE_TYPE,
               CONTRACT_NUM,
               ERP_OU_NAME,
               ERP_OU_ID,
               UPPER_AMOUNT,
               --APPENDIX_ID,
               ATTRIBUTE3,
               DISCOUNT_ORDER_NUMBER,
               VERSION_NUM)
            VALUES
              (V_REVERSE_CASH_RECEIPT_ID,
               HEAD_ROW.REVERSE_RECEIPT_METHOD_ID,
               '1',
               V_ACCOUNT_ID,
               V_REVERSE_CASH_RECEIPT_CODE,
               HEAD_ROW.CASH_RECEIPT_DATE,
               HEAD_ROW.GL_DATE,
               HEAD_ROW.AMOUNT * -1,
               HEAD_ROW.CURRENCY_CODE,
               HEAD_ROW.CASH_CODE,
               HEAD_ROW.SUB_CASH_CODE,
               HEAD_ROW.UNITE_FLAG,
               HEAD_ROW.CASH_DATE,
               HEAD_ROW.DUE_DATE,
               HEAD_ROW.DRAWER,
               HEAD_ROW.DRAWER_BANK_ACCOUNT,
               HEAD_ROW.DRAWER_BANK,
               HEAD_ROW.BACK_WRITE_NAME,
               HEAD_ROW.FIRST_RECEIPT_NAME,
               HEAD_ROW.FIRST_RECEIPT_BANK_ACCOUNT,
               HEAD_ROW.FIRST_RECEIPT_BANK,
               HEAD_ROW.ACCEPTANCE_BANK_NAME,
               V_BUDGET_ITEM_CODE,
               HEAD_ROW.CREATED_BY,
               HEAD_ROW.CREATION_DATE,
               HEAD_ROW.SOURCE_CODE || '#' || HEAD_ROW.REMAEK,
               V_CUSTOMER_ID,
               V_CUSTOMER_CODE,
               V_CUSTOMER_NAME,
               V_ACCOUNT_CODE,
               V_SALES_CENTER_ID,
               HEAD_ROW.ENTITY_ID,
               HEAD_ROW.IS_HONESTLY,
               HEAD_ROW.SOURCE_TYPE,
               HEAD_ROW.CONTRACT_NUM,
               V_ERP_OU_NAME,
               HEAD_ROW.ERP_OU_ID,
               MONEY_TO_RMB(HEAD_ROW.AMOUNT * -1),
               --V_RP_APPENDIX,
               HEAD_ROW.SOURCE_SYSTEM || ' ' || HEAD_ROW.SOURCE_MODULE,
               HEAD_ROW.SOURCE_CODE,
               '0');
          EXCEPTION
            WHEN OTHERS THEN
              P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_RECEIPT_HEAD_SAVE',
                                                  SQLCODE,
                                                  '价差转到款逆向收款单，接口表头数据插入业务表失败！：' ||
                                                  SQLERRM);
              RAISE V_BIZ_EXCEPTION;
          END;

          --遍历收款接口表行数据，插入收款行表

          FOR LINE_ROW IN C_RECEIPT_LINES LOOP
            FOR SALES_MAIN_TYPE_ROW IN C_SALES_MAIN_TYPE LOOP
              IF LINE_ROW.SALES_MAIN_TYPE_CODE =
                 SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_CODE THEN
                V_SALES_MAIN_TYPE_ID   := SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_ID;
                V_SALES_MAIN_TYPE_NAME := SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_NAME;
                EXIT;
              END IF;
            END LOOP;
            BEGIN
              INSERT INTO T_AR_CASH_RECEIPT_LINES
                (CASH_RECEIPT_LINES_ID,
                 CASH_RECEIPT_ID,
                 AMOUNT,
                 REMARK,
                 SALES_MAIN_TYPE_ID,
                 SALES_MAIN_TYPE_CODE,
                 SALES_MAIN_TYPE_NAME,
                 ENTITY_ID)
              VALUES
                (S_AR_CASH_RECEIPT_LINES.NEXTVAL,
                 V_REVERSE_CASH_RECEIPT_ID,
                 LINE_ROW.LINE_AMOUNT * -1,
                 LINE_ROW.REMARK,
                 V_SALES_MAIN_TYPE_ID,
                 LINE_ROW.SALES_MAIN_TYPE_CODE,
                 V_SALES_MAIN_TYPE_NAME,
                 HEAD_ROW.ENTITY_ID);
            EXCEPTION
              WHEN OTHERS THEN
                P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_RECEIPT_HEAD_SAVE',
                                                    SQLCODE,
                                                    '价差转到款逆向收款单，接口表行数据插入业务表失败！：' ||
                                                    SQLERRM);
                RAISE V_BIZ_EXCEPTION;
            END;
          END LOOP;

        END IF;

        --插入业务表成功，回写接口表数据
        BEGIN
          IF HEAD_ROW.IS_REVERSE_RECEIPT = 'Y' THEN
            UPDATE CIMS.T_AR_RECEIPT_HEADER_INTF T
               SET T.CASH_RECEIPT_CODE         = V_CASH_RECEIPT_CODE,
                   T.OPERATE_STATUS            = '0',
                   T.ERROR_INFO                = 'SUCCESS',
                   T.REVERSE_CASH_RECEIPT_CODE = V_REVERSE_CASH_RECEIPT_CODE --回写生成的逆向收款单
             WHERE T.HEAD_ID = P_HEAD_ID;
          ELSE
            UPDATE CIMS.T_AR_RECEIPT_HEADER_INTF T
               SET T.CASH_RECEIPT_CODE = V_CASH_RECEIPT_CODE,
                   T.OPERATE_STATUS    = '0',
                   T.ERROR_INFO        = 'SUCCESS'
             WHERE T.HEAD_ID = P_HEAD_ID;
          END IF;
          P_MESSAGE := 'SUCCESS';

          --回写接口表成功，返回生成的收款ID,单号和逆向收款ID,单号
          P_CASH_RECEIPT_ID   := V_CASH_RECEIPT_ID;
          P_CASH_RECEIPT_CODE := V_CASH_RECEIPT_CODE;

          IF HEAD_ROW.IS_REVERSE_RECEIPT = 'Y' THEN
            P_REVERSE_CASH_RECEIPT_ID   := V_REVERSE_CASH_RECEIPT_ID;
            P_REVERSE_CASH_RECEIPT_CODE := V_REVERSE_CASH_RECEIPT_CODE;
          ELSE
            P_REVERSE_CASH_RECEIPT_ID   := NULL;
            P_REVERSE_CASH_RECEIPT_CODE := NULL;
          END IF;

        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_RECEIPT_HEAD_SAVE',
                                                SQLCODE,
                                                '回写收款单异常，更新接口表失败！：' ||
                                                SQLERRM);
            --回写收款单异常，返回收款单号和逆向收款单号为空
            P_CASH_RECEIPT_CODE         := NULL;
            P_REVERSE_CASH_RECEIPT_CODE := NULL;

            RAISE V_BIZ_EXCEPTION;
        END;

      END LOOP;
    ELSE
      -- 收款单校验 验证不通过，抛出异常
      RAISE V_BIZ_EXCEPTION;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_RECEIPT_HEAD_SAVE',
                                            SQLCODE,
                                            P_MESSAGE ||
                                            substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || SQLERRM);
        UPDATE CIMS.T_AR_RECEIPT_HEADER_INTF C
           SET C.OPERATE_STATUS = '1', C.ERROR_INFO = P_MESSAGE
         WHERE C.HEAD_ID = P_HEAD_ID
           AND C.OPERATE_STATUS <> '0' -- 已处理成功过的不再输入错误信息
           AND C.ERROR_INFO <> 'SUCCESS';
      END;
  END;

  -- 收款单确认校验 by wangyf
  --1、引ERP收款，校验ERP收款方银行账号ID和ERP收款方法ID
  --2、引ERP发票，校验账套ID
  --3、引资金，校验ERP收款方银行账号ID、收款方银行账户名称、ERP收款方法ID
  PROCEDURE P_RECEIPT_CONFIRM_VERIFY(P_CASH_RECEIPT_ID       IN NUMBER, --收款头ID
                                     P_INTO_ERP_FLAG         IN VARCHAR2, --引入ERP标志
                                     P_INTO_BAN_FLAG         IN VARCHAR2, --引入资金标志
                                     P_INTO_ERP_HANDLE       IN VARCHAR2, --引入ERP方式：发票、收款
                                     P_ERP_RECEIPT_METHOD_ID OUT NUMBER, --ERP收款方法ID
                                     P_ERP_BANK_ACCT_USE_ID  OUT NUMBER, --ERP收款方银行账户ID
                                     P_ERP_BANK_ACCOUNT_ID   OUT NUMBER, --GTSP收款方银行账户ID
                                     P_ERP_BANK_ACCOUNT_NAME OUT VARCHAR2, --ERP收款方银行账户名称
                                     P_CUST_BANK_ACCOUNT     OUT VARCHAR2, --客户银行账户
                                     P_CUST_BANK             OUT VARCHAR2, --客户银行名称
                                     P_SET_OUT_ID            OUT NUMBER, --账套ID
                                     P_MESSAGE               OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                     ) IS
    V_HEAD_COUNT NUMBER; --收款头数据总数

    CURSOR C_RECEIPT_HEAD IS --收款头表数据
      SELECT TH.*,
             T.RECEIPT_METHOD_NAME,
             NVL(T.RECEIPT_ENTRY_CODE, 'N') RECEIPT_ENTRY_CODE,
             NVL(T.RECEIPT_CLASS_CODE, 'N') RECEIPT_CLASS_CODE,
             NVL(T.INTO_ERP_FLAG, 'N') INTO_ERP_FLAG,
             NVL(T.INTO_BAN_FLAG, 'N') INTO_BAN_FLAG,
             T.TYPE METHOD_TYPE,
             NVL(T.IS_EFFECTIVE, 'N') IS_EFFECTIVE,
             T.RECEIPT_TYPE,
             T.BUSINESS_TYPE,
             T.CASH_CODE_LENGTH,
             T.ERP_RECEIPT_METHOD_ID,
             T.PAY_MENT_MODE,
             T.ERP_HANDLE,
             T.CASH_DATE_TERM,
             T.RECEIPT_REQUIRE,
             T.ERP_AR_ID,
             T.ERP_RECEIPT_METHOD_NAME,
             T.ERP_AR_NAME
        FROM CIMS.T_AR_CASH_RECEIPT_HEADERS TH, CIMS.T_AR_RECEIPT_METHODS T
       WHERE TH.RECEIPT_STATUS_ID = '1'
         AND T.BUSINESS_TYPE IN ('1', '4', '5')
         AND (NVL(T.INTO_ERP_FLAG, 'N') = 'Y' OR
             NVL(T.INTO_BAN_FLAG, 'N') = 'Y')
         AND TH.RECEIPT_METHOD_ID = T.RECEIPT_METHOD_ID
         AND TH.ENTITY_ID = T.ENTITY_ID
         AND NVL(T.IS_EFFECTIVE, 'N') = 'Y'
         AND TH.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID;

    HEAD_ROW    C_RECEIPT_HEAD%ROWTYPE; --收款头游标行数据
    V_INTO_FLAG VARCHAR2(10); --引入ERP、资金标志：erp、gtsp、erpgtsp
  BEGIN
    P_MESSAGE    := 'SUCCESS';
    V_HEAD_COUNT := 0;
    FOR HEAD_ROW IN C_RECEIPT_HEAD LOOP
      V_HEAD_COUNT := V_HEAD_COUNT + 1;
      IF P_INTO_ERP_FLAG = 'Y' AND P_INTO_ERP_HANDLE = '1' AND
         P_INTO_BAN_FLAG = 'Y' THEN
        V_INTO_FLAG := 'erpgtsp';
      ELSIF P_INTO_ERP_FLAG = 'Y' AND P_INTO_ERP_HANDLE = '1' AND
            P_INTO_BAN_FLAG <> 'Y' THEN
        V_INTO_FLAG := 'erp';
      ELSIF P_INTO_ERP_FLAG = 'Y' AND P_INTO_ERP_HANDLE = '2' AND
            P_INTO_BAN_FLAG = 'Y' THEN
        V_INTO_FLAG := 'gtsp';
      ELSIF P_INTO_ERP_FLAG <> 'Y' AND P_INTO_BAN_FLAG = 'Y' THEN
        V_INTO_FLAG := 'gtsp';
      END IF;

      --引入ERP发票，校验账套ID
      IF P_INTO_ERP_FLAG = 'Y' AND P_INTO_ERP_HANDLE = '2' THEN
        PKG_AR_COMMON.P_GET_SET_BOOK_ID(HEAD_ROW.ERP_OU_ID,
                                        P_SET_OUT_ID,
                                        P_MESSAGE);
      END IF;
      IF P_MESSAGE <> 'SUCCESS' THEN
        RAISE V_BIZ_EXCEPTION;
      END IF;

      IF V_INTO_FLAG IS NOT NULL THEN
        --校验收款方银行账户（ERP/资金）
        PKG_AR_COMMON.P_VALIDATE_ERP_RECEIPT_BANK(HEAD_ROW.ERP_OU_ID, --OU_ID
                                                  HEAD_ROW.ERP_RECEIPT_METHOD_NAME, --ERP收款方法名称
                                                  HEAD_ROW.ATTRIBUTE7, --收款银行账户（收款单）
                                                  HEAD_ROW.ATTRIBUTE13, --收款银行账号（收款单）
                                                  HEAD_ROW.CASH_CODE_LENGTH, --票据号长度
                                                  HEAD_ROW.RECEIPT_ENTRY_CODE, --是否可录入
                                                  V_INTO_FLAG, --引入ERP/资金标志
                                                  P_ERP_RECEIPT_METHOD_ID, --ERP收款方法ID
                                                  P_ERP_BANK_ACCT_USE_ID, --ERP收款方银行账户ID
                                                  P_ERP_BANK_ACCOUNT_ID, --GTSP收款方银行账户ID
                                                  P_ERP_BANK_ACCOUNT_NAME, --ERP收款方银行账户名称
                                                  P_MESSAGE);
      END IF;
      IF P_MESSAGE <> 'SUCCESS' THEN
        RAISE V_BIZ_EXCEPTION;
      END IF;

      IF HEAD_ROW.INTO_BAN_FLAG = 'Y' THEN
        --校验客户银行账户 （资金）
        PKG_AR_COMMON.P_VALIDATE_CUSTOMER_BANK(HEAD_ROW.ENTITY_ID, --主体ID
                                               HEAD_ROW.CUSTOMER_ID, --客户ID
                                               P_CUST_BANK_ACCOUNT, --客户银行账户
                                               P_CUST_BANK, --客户银行名称
                                               P_MESSAGE);
        IF P_MESSAGE <> 'SUCCESS' THEN
          RAISE V_BIZ_EXCEPTION;
        END IF;
      END IF;
    END LOOP;
    IF V_HEAD_COUNT < 1 THEN
      P_MESSAGE := '收款数据有误，请联系管理员';
      RAISE V_BIZ_EXCEPTION;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_RECEIPT_CONFIRM_VERIFY',
                                          SQLCODE,
                                          P_MESSAGE || SQLERRM);
  END;

  -- 收款单确认
  PROCEDURE P_RECEIPT_HEAD_CONFIRM(P_CASH_RECEIPT_ID   IN NUMBER, --收款头ID
                                   P_USER_ACCOUNT      IN VARCHAR2, --用户账户
                                   P_MESSAGE           OUT VARCHAR2, --成功则返回“SUCCESS”，否则返回出错信息
                                   P_CASH_RECEIPT_CODE OUT VARCHAR2 --成功则返回收款单号
                                   ) IS
    V_INTO_ERP_FLAG           VARCHAR2(32); --引入ERP标志
    V_INTO_BAN_FLAG           VARCHAR2(32); --引入资金标志
    V_ERP_HANDLE              VARCHAR2(32); --引入ERP方式
    V_ENTITY_ID               NUMBER; --主体ID
    V_ERP_OU_ID               NUMBER;
    V_CUSTOMER_ID             NUMBER; --客户ID
    V_ERP_RECEIPT_METHOD_NAME T_AR_RECEIPT_METHODS.ERP_RECEIPT_METHOD_NAME%TYPE; --ERP收款方法名称（收款方法）
    V_CASH_CODE_LENGTH        T_AR_RECEIPT_METHODS.CASH_CODE_LENGTH%TYPE; --票据号长度（收款方法）
    V_RECEIPT_ENTRY_CODE      T_AR_RECEIPT_METHODS.RECEIPT_ENTRY_CODE%TYPE; --是否可录入（收款方法）
    V_ATTRIBUTE7              T_AR_CASH_RECEIPT_HEADERS.ATTRIBUTE7%TYPE; --ERP收款方银行账户名称（资金使用，对应收款单ATTRIBUTE7）
    V_ATTRIBUTE13              T_AR_CASH_RECEIPT_HEADERS.ATTRIBUTE13%TYPE; --ERP收款方银行账号资金使用，对应收款单ATTRIBUTE13）
    V_ERP_RECEIPT_METHOD_ID   NUMBER; --ERP收款方法ID
    V_ERP_BANK_ACCT_USE_ID    NUMBER; --ERP收款方银行账户ID
    V_ERP_BANK_ACCOUNT_ID     NUMBER; --GTSP收款方银行账户ID
    V_ERP_BANK_ACCOUNT_NAME   VARCHAR2(100); --ERP收款方银行账户名称
    V_SET_OF_BOOKS_ID         NUMBER; --账套ID
    V_CUST_BANK_ACCOUNT       VARCHAR2(50); --客户银行账户
    V_CUST_BANK               VARCHAR2(50); --客户银行名称
    V_CASH_RECEIPT_CODE       VARCHAR2(32); --收款单据编号
    V_METHOD_ID               NUMBER;
    V_ENTITY                  NUMBER;
    V_WRITEOFF_RECEIPT_CODE   VARCHAR2(32); --原收款单据编号
    V_REFUND_APPLY_ID   NUMBER;
  BEGIN
    P_MESSAGE := 'SUCCESS';
    SELECT TH.CASH_RECEIPT_CODE,
           NVL(T.INTO_ERP_FLAG, 'N') INTO_ERP_FLAG,
           NVL(T.INTO_BAN_FLAG, 'N') INTO_BAN_FLAG,
           T.ERP_HANDLE,
           TH.ENTITY_ID,
           TH.CUSTOMER_ID,
           TH.ERP_OU_ID,
           NVL(T.CASH_CODE_LENGTH,0),
           T.RECEIPT_ENTRY_CODE,
           T.ERP_RECEIPT_METHOD_NAME,
           TH.ATTRIBUTE7,
           TH.ATTRIBUTE13,
           TH.RECEIPT_METHOD_ID,
           TH.ENTITY_ID,
           TH.WRITEOFF_RECEIPT_CODE,
           TH.REFUND_APPLY_ID
      INTO V_CASH_RECEIPT_CODE,
           V_INTO_ERP_FLAG,
           V_INTO_BAN_FLAG,
           V_ERP_HANDLE,
           V_ENTITY_ID,
           V_CUSTOMER_ID,
           V_ERP_OU_ID,
           V_CASH_CODE_LENGTH,
           V_RECEIPT_ENTRY_CODE,
           V_ERP_RECEIPT_METHOD_NAME,
           V_ATTRIBUTE7,
           V_ATTRIBUTE13,
           V_METHOD_ID,
           V_ENTITY,
           V_WRITEOFF_RECEIPT_CODE,
           V_REFUND_APPLY_ID
      FROM CIMS.T_AR_CASH_RECEIPT_HEADERS TH, CIMS.T_AR_RECEIPT_METHODS T
     WHERE TH.RECEIPT_STATUS_ID = '1'
       AND T.BUSINESS_TYPE IN ('1','2' ,'4', '5')
  --     AND (NVL(T.INTO_ERP_FLAG, 'N') = 'Y' OR
  --         NVL(T.INTO_BAN_FLAG, 'N') = 'Y')
       AND TH.RECEIPT_METHOD_ID = T.RECEIPT_METHOD_ID
       AND TH.ENTITY_ID = T.ENTITY_ID
       AND NVL(T.IS_EFFECTIVE, 'N') = 'Y'
       AND TH.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID;
    IF V_INTO_ERP_FLAG IS NULL AND V_INTO_BAN_FLAG IS NULL AND
       V_INTO_ERP_FLAG NOT IN ('Y', 'N') AND
       V_INTO_BAN_FLAG NOT IN ('Y', 'N') THEN
      P_MESSAGE := '提供的收款数据有误，请联系管理员';
      RAISE V_BIZ_EXCEPTION;
    END IF;

    IF V_INTO_ERP_FLAG IS NOT NULL AND V_ERP_HANDLE = '1' AND
       V_ERP_RECEIPT_METHOD_NAME IS NULL THEN
      P_MESSAGE := '提供的收款数据（收款方法ID=' || V_METHOD_ID || '，主体ID=' || V_ENTITY ||
                   '）有误，请联系管理员';
      RAISE V_BIZ_EXCEPTION;
    END IF;

    IF V_WRITEOFF_RECEIPT_CODE IS NULL THEN
          --收款单确认校验  2015-1015修改
          PKG_AR_COMMON.P_VALIDATE_RECEIPT_CONFIRM(V_ENTITY_ID,
                                                   V_CUSTOMER_ID,
                                                   V_ERP_OU_ID,
                                                   V_CASH_CODE_LENGTH,
                                                   V_RECEIPT_ENTRY_CODE,
                                                   V_INTO_ERP_FLAG,
                                                   V_INTO_BAN_FLAG,
                                                   V_ERP_HANDLE,
                                                   V_ERP_RECEIPT_METHOD_NAME,
                                                   V_ATTRIBUTE7,
                                                   V_ATTRIBUTE13,
                                                   V_REFUND_APPLY_ID,
                                                   V_ERP_RECEIPT_METHOD_ID, --ERP收款方法ID
                                                   V_ERP_BANK_ACCT_USE_ID, --ERP收款方银行账户ID
                                                   V_ERP_BANK_ACCOUNT_ID, --GTSP收款方银行账户ID
                                                   V_ERP_BANK_ACCOUNT_NAME, --ERP收款方银行账户名称
                                                   V_CUST_BANK_ACCOUNT, --客户银行账户
                                                   V_CUST_BANK, --客户银行名称
                                                   V_SET_OF_BOOKS_ID, --账套ID
                                                   P_MESSAGE);

          IF P_MESSAGE <> 'SUCCESS' THEN
            RAISE V_BIZ_EXCEPTION;
          ELSE
            --校验成功，更改收款单状态：制单->已确认
            BEGIN
              --更新收款头表：确认人、确认时间、单据状态、引入接口备注ATTRIBUTE1/ATTRIBUTE2
              UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS T
                 SET T.REVIEWED_BY       = P_USER_ACCOUNT,
                     T.REVIEWED_DATE     = TRUNC(SYSDATE),
                     T.RECEIPT_STATUS_ID = '3',
                     T.ATTRIBUTE1        = DECODE(V_INTO_ERP_FLAG, 'Y', 'Y', ''),
                     T.ATTRIBUTE2        = DECODE(V_INTO_BAN_FLAG, 'Y', 'Y', ''),
                     T.UPDATED_DATE = SYSDATE
               WHERE T.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID;
              P_CASH_RECEIPT_CODE := V_CASH_RECEIPT_CODE;
            EXCEPTION
              WHEN OTHERS THEN
                BEGIN
                  P_MESSAGE := '收款确认：更新收款头表：确认人、确认时间、单据状态失败！';
                  RAISE V_BIZ_EXCEPTION;
                END;
            END;
          END IF;
          --引ERP
          IF V_INTO_ERP_FLAG = 'Y' AND V_ERP_HANDLE = '1' THEN
            --引ERP收款
            PKG_AR_COMMON.P_INSERT_ERP_RECEIPT(P_CASH_RECEIPT_ID,
                                               V_ERP_RECEIPT_METHOD_ID,
                                               V_ERP_BANK_ACCT_USE_ID,
                                               P_MESSAGE);
            IF P_MESSAGE <> 'SUCCESS' THEN
              RAISE V_BIZ_EXCEPTION;
            END IF;
          ELSIF V_INTO_ERP_FLAG = 'Y' AND V_ERP_HANDLE = '2' THEN
            --引入ERP AR发票
            PKG_AR_COMMON.P_INSERT_AR_INVOICE(P_CASH_RECEIPT_ID,
                                              V_SET_OF_BOOKS_ID,
                                              P_MESSAGE);

            IF P_MESSAGE <> 'SUCCESS' THEN
              RAISE V_BIZ_EXCEPTION;
            END IF;
          END IF;
          --引资金
          IF V_INTO_BAN_FLAG = 'Y' THEN
            PKG_AR_COMMON.P_INSERT_GTSP_RECEIPT(P_CASH_RECEIPT_ID,
                                                V_CUST_BANK_ACCOUNT,
                                                V_CUST_BANK,
                                                V_ERP_RECEIPT_METHOD_ID,
                                                V_ERP_BANK_ACCOUNT_ID,
                                                V_ERP_BANK_ACCOUNT_NAME,
                                                P_MESSAGE);
            IF P_MESSAGE <> 'SUCCESS' THEN
              RAISE V_BIZ_EXCEPTION;
            END IF;
          END IF;
    ELSE  
      
       BEGIN
          --更新收款头表：确认人、确认时间、单据状态、引入接口备注ATTRIBUTE1/ATTRIBUTE2
          UPDATE CIMS.T_AR_CASH_RECEIPT_HEADERS T
             SET T.REVIEWED_BY       = P_USER_ACCOUNT,
                 T.REVIEWED_DATE     = TRUNC(SYSDATE),
                 T.RECEIPT_STATUS_ID = '3',
                 T.ATTRIBUTE1        = DECODE(V_INTO_ERP_FLAG, 'Y', 'Y', ''),
                 T.ATTRIBUTE2        = DECODE(V_INTO_BAN_FLAG, 'Y', 'Y', ''),
                 T.UPDATED_DATE = SYSDATE
           WHERE T.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID;
          P_CASH_RECEIPT_CODE := V_CASH_RECEIPT_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            BEGIN
              P_MESSAGE := '收款确认：更新收款头表：确认人、确认时间、单据状态失败！';
              RAISE V_BIZ_EXCEPTION;
            END;
        END;
          
        --引冲销ERP
        IF V_INTO_ERP_FLAG = 'Y' AND V_ERP_HANDLE = '1' THEN  
            --引冲销ERP
            PKG_AR_COMMON.P_INSERT_AR_REVERSE(P_CASH_RECEIPT_ID,
                                              P_MESSAGE);
            IF P_MESSAGE <> 'SUCCESS' THEN
              RAISE V_BIZ_EXCEPTION;
            END IF;       
        END IF;
    END IF;  
    
    
    
  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        UPDATE CIMS.T_AR_RECEIPT_HEADER_INTF C
           SET C.OPERATE_STATUS = '1', C.ERROR_INFO = P_MESSAGE
         WHERE C.CASH_RECEIPT_CODE = V_CASH_RECEIPT_CODE;
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_RECEIPT_HEAD_CONFIRM',
                                            SQLCODE,
                                            P_MESSAGE ||
                                            substr(dbms_utility.format_error_backtrace,
                                                   1,
                                                   100) || SQLERRM);
      END;
  END;

  -- 正向、逆向收款优先核销
  PROCEDURE P_PRIORITY_WRITE_OFF(P_HEAD_ID IN NUMBER, --收款头接口表ID
                                 P_MESSAGE OUT VARCHAR2 --成功返回'SUCCESS'，否则返回出错信息
                                 ) IS
    V_COUNT                     NUMBER;
    V_CASH_RECEIPT_CODE         T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_CODE%TYPE; -- 正向收款
    V_REVERSE_CASH_RECEIPT_CODE T_AR_CASH_RECEIPT_HEADERS.CASH_RECEIPT_CODE%TYPE; -- 逆向收款
    -- 应收
    CURSOR CUR_SO_ORDER IS
      SELECT *
        FROM V_AR_CASH_RECEIPT_HEADER_LINES hl
       WHERE hl.CASH_RECEIPT_CODE IN
             (V_CASH_RECEIPT_CODE, V_REVERSE_CASH_RECEIPT_CODE)
         AND HL.AMOUNT < 0;
    --应收行游标行数据
    SO_ORDER_ROW CUR_SO_ORDER%ROWTYPE;
    -- 核销关系行数据
    V_SO_ORDER_RECEIPT_ROW T_SO_ORDER_RECEIPT%ROWTYPE;

  BEGIN
    P_MESSAGE := 'SUCCESS';
    SELECT COUNT(*)
      INTO V_COUNT
      FROM T_AR_RECEIPT_HEADER_INTF ti
     WHERE ti.HEAD_ID = P_HEAD_ID
       AND ti.IS_WRITE_OFF = 'Y'
       AND ti.CASH_RECEIPT_CODE IS NOT NULL
       AND ti.REVERSE_CASH_RECEIPT_CODE IS NOT NULL;
    IF V_COUNT > 0 THEN
      -- 配置需优先核销
      SELECT ti.CASH_RECEIPT_CODE, ti.REVERSE_CASH_RECEIPT_CODE
        INTO V_CASH_RECEIPT_CODE, V_REVERSE_CASH_RECEIPT_CODE
        FROM T_AR_RECEIPT_HEADER_INTF ti
       WHERE ti.HEAD_ID = P_HEAD_ID;
      -- 循环应收数据
      FOR SO_ORDER_ROW IN CUR_SO_ORDER LOOP
        V_SO_ORDER_RECEIPT_ROW.SO_HEAD_ID := SO_ORDER_ROW.CASH_RECEIPT_ID;
        V_SO_ORDER_RECEIPT_ROW.ORDER_TYPE := '1';

        -- 查询回款
        BEGIN
          SELECT hl.CASH_RECEIPT_ID, hl.CASH_RECEIPT_LINES_ID
            INTO V_SO_ORDER_RECEIPT_ROW.CASH_RECEIPT_ID,
                 V_SO_ORDER_RECEIPT_ROW.CASH_RECEIPT_LINES_ID
            FROM V_AR_CASH_RECEIPT_HEADER_LINES hl
           WHERE hl.CASH_RECEIPT_CODE IN
                 (V_CASH_RECEIPT_CODE, V_REVERSE_CASH_RECEIPT_CODE)
             AND HL.AMOUNT > 0
             AND hl.SALES_MAIN_TYPE_CODE =
                 SO_ORDER_ROW.SALES_MAIN_TYPE_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_PRIORITY_WRITE_OFF',
                                                SQLCODE,
                                                '根据营销大类查询回款数据失败!SALES_MAIN_TYPE_CODE=' ||
                                                SO_ORDER_ROW.SALES_MAIN_TYPE_CODE || '。' ||
                                                SQLERRM);
            RETURN;
        END;

        V_SO_ORDER_RECEIPT_ROW.RECEIPT_TYPE := '1';

        V_SO_ORDER_RECEIPT_ROW.ENTITY_ID            := SO_ORDER_ROW.ENTITY_ID;
        V_SO_ORDER_RECEIPT_ROW.CUSROMER_CODE        := SO_ORDER_ROW.CUSTOMER_CODE;
        V_SO_ORDER_RECEIPT_ROW.CUSROMER_NAME        := SO_ORDER_ROW.CUSTOMER_NAME;
        V_SO_ORDER_RECEIPT_ROW.AMOUNT               := ABS(SO_ORDER_ROW.AMOUNT);
        V_SO_ORDER_RECEIPT_ROW.MATCH_DATE           := trunc(SO_ORDER_ROW.CREATION_DATE);
        V_SO_ORDER_RECEIPT_ROW.ORDER_DATE           := trunc(SO_ORDER_ROW.CASH_RECEIPT_DATE);
        V_SO_ORDER_RECEIPT_ROW.RECEIPT_DATE         := TRUNC(SO_ORDER_ROW.CASH_RECEIPT_DATE);
        V_SO_ORDER_RECEIPT_ROW.ACTIVE_FLAG          := 'Y';
        V_SO_ORDER_RECEIPT_ROW.TO_ERP_FLAG          := 'N';
        V_SO_ORDER_RECEIPT_ROW.SALES_MAIN_TYPE_ID   := SO_ORDER_ROW.SALES_MAIN_TYPE_ID;
        V_SO_ORDER_RECEIPT_ROW.SALES_MAIN_TYPE_CODE := SO_ORDER_ROW.SALES_MAIN_TYPE_CODE;
        V_SO_ORDER_RECEIPT_ROW.SALES_MAIN_TYPE_NAME := SO_ORDER_ROW.SALES_MAIN_TYPE_NAME;

        V_SO_ORDER_RECEIPT_ROW.ORDER_RECEIPT_ID := S_SO_ORDER_RECEIPT.NEXTVAL;

        -- 插入核销关系
        INSERT INTO T_SO_ORDER_RECEIPT VALUES V_SO_ORDER_RECEIPT_ROW;
        -- 设置核销状态为完全核销
        UPDATE T_AR_CASH_RECEIPT_HEADERS H
           SET H.ATTRIBUTE5 = '0',
               H.ATTRIBUTE6 = TO_CHAR(SYSDATE, 'yyyy-MM-dd')
         WHERE H.CASH_RECEIPT_CODE IN
               (V_CASH_RECEIPT_CODE, V_REVERSE_CASH_RECEIPT_CODE);

      END LOOP;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      --ROLLBACK;
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.P_PRIORITY_WRITE_OFF',
                                          SQLCODE,
                                          P_MESSAGE || SQLERRM);
  END;

END PKG_AR_BOND;
/

