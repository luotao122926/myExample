create package body PKG_AR_ACCOUNT is

  -----------------------------------------------------------------------
  -- Author  :
  -- Created :
  --执行往来对账单数据生成
  --参数可以传：
  --      主体ID（处理该主体所有可以计算往来对账单的客户）
  --      对账日期（处理该对账期下所有可以计算往来对账的客户）
  --      空白（处理所有可以计算往来对账单的客户）
  --
  -----------------------------------------------------------------------
  PROCEDURE P_CUSG_SOA_COUNT_ALL(P_ENTITY_ID    NUMBER, --主体ID
                                 P_COUNT_PERIOD DATE, --对账日期
                                 P_RESULT IN OUT VARCHAR2) IS
    V_PERIOD_DATE       VARCHAR2(20); --账期
    V_PERIOD_START_DATE DATE; --账期开始时间
    V_PERIOD_END_DATE   DATE; --账期结束时间
    V_PERIOD_END_DATE2  DATE; --账期结束时间下一天
    V_LAST_START_DATE   DATE; --上月账期开始时间
    V_LAST_END_DATE     DATE; --上月账期结束时间
    V_CUSTOMER_ID     NUMBER; --客户ID
    --V_SALES_CENTER_ID NUMBER; --中心ID
    V_ACCOUNT_ID      NUMBER; --账户ID
    V_CLASS_CODE      VARCHAR2(20); --品类
    
    
      V_DISCOUNT_TYPE_COMMON  VARCHAR2(32);
    V_DISCOUNT_TYPE         VARCHAR2(32);

    /*
    --从客户配置表获取账号数据
    CURSOR C_ACCOUNT IS
      SELECT distinct TCO.*
        FROM T_CUSTOMER_ORG TCO,t_ar_cusg_soa_conf a
       WHERE TCO.Entity_Id = a.entity_id
       and TCO.Customer_Id = a.customer_id
       and TCO.Sales_Center_Id = a.sales_center_id
       and a.soa_produce_day = (select to_char(P_COUNT_PERIOD,'dd') from dual)
       and TCO.Entity_Id = P_ENTITY_ID;
    */

    --从对账配置表获取账号数据
    CURSOR C_ACCOUNT IS
      SELECT distinct CSC.entity_id,CSC.account_id,CSC.customer_id,CSC.customer_name,csc.customer_code,CSC.Title ,w.SALES_CENTER_ID,w.SALES_CENTER_CODE,w.SALES_CENTER_NAME
       FROM T_AR_CUSG_SOA_CONF CSC,v_customer_account_conf w
       WHERE CSC.Entity_Id = P_ENTITY_ID
       and CSC.soa_produce_day = (select to_char(P_COUNT_PERIOD,'dd') from dual)
       and w.CUSTOMER_ID = CSC.CUSTOMER_ID
       and w.ACCOUNT_ID = CSC.ACCOUNT_ID
       and w.ENTITY_ID = CSC.ENTITY_ID;

    --在对账配置表匹配需要对账的账号对账配置信息
    CURSOR C_ACCOUNT_CONF IS
      SELECT distinct CSC.ORDER_TYPE,CSC.Entity_Id
        FROM T_AR_CUSG_SOA_CONF CSC
       WHERE CSC.Entity_Id = P_ENTITY_ID
         and CSC.Customer_Id = V_CUSTOMER_ID
         --and CSC.Sales_Center_Id = V_SALES_CENTER_ID
         and CSC.Account_Id = V_ACCOUNT_ID;

    --从产品分类获取分类数据
    CURSOR C_ITEM_CLASS IS
      SELECT NVL(U.CODE_VALUE,V_DISCOUNT_TYPE_COMMON) DISCOUNT_TYPE
           , U.CODE_NAME DISCOUNT_TYPE_NAME
           , T.*
        FROM T_BD_ITEM_CLASS T
        LEFT JOIN CIMS.UP_CODELIST U on U.CODETYPE = 'DISCOUNT_TYPE'
              AND PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS', T.ENTITY_ID , NULL, NULL) = 'NC'
              AND PKG_BD.F_GET_PARAMETER_VALUE('CRE_DIS_TYPE_ENABLE', T.ENTITY_ID , NULL, NULL) = 'Y'
       WHERE T.CLASS_TYPE = 'M'
         AND T.ACTIVE_FLAG = 'Y'
         AND T.ENTITY_ID = P_ENTITY_ID;

    --按品类获取存在差异的到款单数据，检查在本期对账周期存在更新的数据
    CURSOR C_RECEIPT IS
      SELECT *
        FROM v_ar_cash_receipt_header_lines t
       WHERE t.Entity_Id = P_ENTITY_ID
         and t.Customer_Id = V_CUSTOMER_ID
         --and t.Sales_Center_Id = V_SALES_CENTER_ID
         and t.Account_Id = V_ACCOUNT_ID
         and t.SALES_MAIN_TYPE_CODE = V_CLASS_CODE
         AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
         and t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
         and t.REVIEWED_DATE >= V_LAST_START_DATE
         and t.REVIEWED_DATE < V_PERIOD_START_DATE
         and t.UPDATED_DATE >= V_PERIOD_START_DATE;

    --按品类获取存在差异的销售单、返利单（折让）数据
    CURSOR C_SO IS
      SELECT *
        FROM T_SO_HEADER t
       WHERE t.Entity_Id = P_ENTITY_ID
         and t.Customer_Id = V_CUSTOMER_ID
         --and t.Sales_Center_Id = V_SALES_CENTER_ID
         and t.Account_Id = V_ACCOUNT_ID
         and t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008','1009', '1010')
         and t.so_status <> '10'
         and t.SALES_MAIN_TYPE = V_CLASS_CODE
         AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
        -- and t.SO_DATE >= V_LAST_START_DATE --去掉日期限制 guibr 存在跨两月结算单据
         and t.SO_DATE < V_PERIOD_START_DATE
         and t.settle_date >= V_PERIOD_START_DATE
         AND t.settle_date < V_PERIOD_END_DATE2;

    --按账号、账期查询对账历史数据,账期是本个对账周期
    CURSOR C_HIS IS
      SELECT *
        FROM T_AR_SOA_ORDER_HEADS t
       WHERE t.entity_id = P_ENTITY_ID
         AND t.customer_id = V_CUSTOMER_ID
         --AND t.sales_center_id = V_SALES_CENTER_ID
         and t.Account_Id = V_ACCOUNT_ID
         AND t.PERIOD_DATE = V_PERIOD_DATE;

    ACCOUNT_ROW C_ACCOUNT%ROWTYPE; --客户游标行数据
    CONF_ROW    C_ACCOUNT_CONF%ROWTYPE; --账号对账配置信息游标行数据
    ITEMCLASS_ROW C_ITEM_CLASS%ROWTYPE; --产品分类游标行数据
    RECEIPT_ROW  C_RECEIPT%ROWTYPE; --到款单游标行数据
    SO_ROW  C_SO%ROWTYPE;           --销售单游标行数据
    HIS_ROW C_HIS%ROWTYPE;           --对账历史游标行数据

    V_COUNT     NUMBER; --判断当前账期、账号是否已对账
    V_COUNT0    NUMBER; --判断到款表是否有处理单据
    V_COUNT1    NUMBER; --判断上一账期是否存在
    V_COUNT1_   NUMBER; --判断结束日期为上个月末的账单是否存在 add by huanghb12 2019-1-3
    V_COUNT2    NUMBER; --按品类判断到款行上一账期是否存在
    V_COUNT2_   NUMBER; --按品类判断到款行上以上个月末的为结束日期的张单是否存在 add by huanghb12 2019-1-3
    V_COUNT3    NUMBER; --判断销售表是否存在销售单据
    V_COUNT4    NUMBER; --按品类判断到款表是否有到款单据
    V_COUNT5    NUMBER; --按品类判断销售表是否有销售单据
    V_COUNT6    NUMBER; --按品类判断销售表是否有折让单据
    V_COUNT7    NUMBER; --按品类判断折扣行上一账期是否存在
    V_COUNT7_   NUMBER; --按品类判断折扣行上一账期的结束日期的账期是否存在 add by huanghb12 2019-1-8
    V_COUNT7__  NUMBER; --检查上一期对账单头是否存在 add by huanghb12 2019-2-14
    V_COUNT8    NUMBER; --判断NC对账类型是否存在
    V_COUNT9    NUMBER; --按品类判断到款表是否有到款差异单据
    V_COUNT10   NUMBER; --按品类判断销售表是否有销售差异单据
    V_COUNT11   NUMBER; --按品类判断销售表是否有折让差异单据
    --V_COUNT12   NUMBER; --判断到款表是否有到款差异单据
    V_COUNT13   NUMBER; --判断销售表是否有销售差异单据
    V_COUNT14   NUMBER; --判断销售表是否有折让差异单据
    --V_COUNT15   NUMBER; --按品类判断到款表是否有到款差异单据
    V_COUNT16   NUMBER; --按品类判断销售表是否有销售差异单据
    V_COUNT17   NUMBER; --按品类判断销售表是否有折让差异单据

    V_ORDER_TYPE        VARCHAR2(20); --对账单类型

    V_AMOUNT_A NUMBER; --获取的期初余额
    V_AMOUNT_A2 NUMBER; --计算出的期初余额
    V_AMOUNT_B NUMBER; --本期到款金额
    V_AMOUNT_C NUMBER; --累计金额  C=A+B
    V_AMOUNT_D NUMBER; --本期累计到款  D = B
    V_AMOUNT_E NUMBER; --到款提货金额
    V_AMOUNT_E2 NUMBER;  --计算到款提货金额（考虑了总期内结算的销售差异数据） add by huanghb12 2019-1-8
    V_AMOUNT_F NUMBER; --本期到款余额  F = A + D - E
    V_AMOUNT_G NUMBER; --冻结金额
    V_AMOUNT_H NUMBER; --折让余额
    V_AMOUNT_I NUMBER; --应收账款余额
    V_AMOUNT_J NUMBER; --获取的期初折让余额
    V_AMOUNT_J2 NUMBER; --计算出的期初折让余额
    V_AMOUNT_K NUMBER; --本期折让金额
    V_AMOUNT_K2 NUMBER; --本期折让金额 add by huanghb12 2019-1-3
    V_AMOUNT_L NUMBER; --核销折让金额
    V_AMOUNT_L2 NUMBER; --核销折让金额 add by huanghb12 2019-1-3

    V_AMOUNT_SA  NUMBER; --获取总期初余额
    V_AMOUNT_SA2  NUMBER; --计算出的总期初余额
    V_AMOUNT_SB  NUMBER; --本期总到款金额
    V_AMOUNT_SE  NUMBER; --总到款提货金额
    V_AMOUNT_SE2 NUMBER; --计算总期提货金额 add by huanghb12 2019-1-8
    V_AMOUNT_SF  NUMBER; --本期总到款余额  F = A + D - E
    V_AMOUNT_SJ NUMBER; --获取的总期初折让余额
    V_AMOUNT_SJ2 NUMBER; --计算出的总期初折让余额 add by huanghb12 2019-1-3
    V_AMOUNT_SK NUMBER; --本期总折让金额
    V_AMOUNT_SL NUMBER; --总核销折让金额
    V_AMOUNT_SL2 NUMBER; --计算总核销折让金额 add by huanghb12 2019-1-8
    V_AMOUNT_SH NUMBER; --总折让余额

    --D_AMOUNT_SD NUMBER; --本期到款差异总和
    D_AMOUNT_SE NUMBER; --本期到款提货差异总和
    D_AMOUNT_SL NUMBER; --本期核销折让差异总和
    D_AMOUNT_SK NUMBER; --本期折让差异总和
    --D_AMOUNT_D NUMBER; --按品类计算本期到款差异总和
    D_AMOUNT_E NUMBER; --按品类计算本期到款提货差异总和
    D_AMOUNT_L NUMBER; --按品类计算本期核销折让差异总和
    D_AMOUNT_K NUMBER; --按品类计算本期折让差异总和

    V_AMOUNT_U NUMBER; --未解付金额
    V_AMOUNT_US NUMBER; --总未解付金额
    
    V_AMOUNT_TRX1  NUMBER; --未开票金额1
    V_AMOUNT_TRX2  NUMBER; --未开票金额2
    
    --V_AMOUNT_LOCI  NUMBER; --锁定金额期初
    V_AMOUNT_LOCC  NUMBER; --本期锁定金额
    V_AMOUNT_LOCE  NUMBER; --本期期末金额


    V_SOA_COUNT_BATCH_ID NUMBER; --本次对账批次ID
    V_ORDER_NUMBER       VARCHAR2(20); --对账单号

    V_RECEIPT_AMOUNT   NUMBER;    --判断到款金额是否存在差异
    V_SO_AMOUNT   NUMBER;    --判断销售金额是否存在差异
    V_DIS_AMOUNT   NUMBER;    --判断返利（折让）金额是否存在差异

    V_RESULT VARCHAR2(2000); --自定义返回信息
    V_RESULT2 VARCHAR2(2000); --自定义返回信息
    V_ERR_EXCEPT EXCEPTION; --异常信息

    V_SOA_TITLE VARCHAR2(100); --对账头
    V_SOA_PRODUCE_DAY NUMBER; --产生天
    V_SOA_SEND_DAY NUMBER; --发送天

    V_ACCOUNT_CONF VARCHAR2(100); --是否自动配置对账单
    
    --2017-02-07 tianmzh add 
    V_AUTO_FLAG VARCHAR2(2); --是否自动确认无业务往来的对账单
    V_ACCOUNT_CONFIRM_FLAG VARCHAR2(2); --是否自动确认系统参数
    
    V_PUB_FIN_SYS  varchar2(32);
    
  BEGIN
    P_RESULT := V_SUCCESS;
    V_DISCOUNT_TYPE_COMMON := 'COMMON';

    IF P_ENTITY_ID IS NULL OR P_COUNT_PERIOD IS NULL THEN
      V_RESULT := '传入参数错误，存在空值参数：P_ENTITY_ID:[' || TO_CHAR(P_ENTITY_ID) ||
                  ']  P_COUNT_PERIOD:[' || P_COUNT_PERIOD || ']';
      P_RESULT := V_RESULT;
    END IF;

    IF P_ENTITY_ID IS NOT NULL
    AND P_COUNT_PERIOD IS NOT NULL THEN
    BEGIN

        V_ACCOUNT_CONF:= PKG_BD.F_GET_PARAMETER_VALUE('AR_AUTO_ACCOUNT_CONF', P_ENTITY_ID, NULL, NULL);
        V_PUB_FIN_SYS:= PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS', P_ENTITY_ID , NULL, NULL); 
        IF V_ACCOUNT_CONF = 'Y' THEN
                FOR RESULT_BATCH_ROW IN (
                    SELECT
                         CODE_VALUE
                    FROM
                         CIMS.V_UP_CODELIST
                    WHERE
                         CODETYPE = 'ACCOUNTBALANCE_TYPE'
                     AND ENTITY_ID = P_ENTITY_ID
                )LOOP
                       BEGIN
                           SELECT
                               TITLE
                               ,SOA_PRODUCE_DAY
                               ,SOA_SEND_DAY
                            INTO
                                V_SOA_TITLE
                               ,V_SOA_PRODUCE_DAY
                               ,V_SOA_SEND_DAY
                           FROM
                               CIMS.T_AR_CUSG_SOA_CONF
                           WHERE
                                ENTITY_ID = P_ENTITY_ID
                            AND ORDER_TYPE = RESULT_BATCH_ROW.CODE_VALUE
                            AND ROWNUM = 1;

                             INSERT INTO  T_AR_CUSG_SOA_CONF
                                          (SOA_CONF_ID,
                                          CUSTOMER_ID,
                                          CUSTOMER_CODE,
                                          CUSTOMER_NAME,
                                          SALES_CENTER_ID,
                                          ORDER_TYPE,
                                          HANDMADE_INPUT_FLAG,
                                          CREATED_BY,
                                          CREATION_DATE,
                                          LAST_UPDATED_BY,
                                          LAST_UPDATE_DATE,
                                          SOA_PRODUCE_DAY,
                                          SOA_SEND_DAY,
                                          ENTITY_ID,
                                          TITLE,
                                          COMMENT_INFO,
                                          SALES_CENTER_CODE,
                                          SALES_CENTER_NAME,
                                          CUSTOMER_MAIL,
                                          ACCOUNT_ID,
                                          ACCOUNT_CODE
                                          )
                                          SELECT S_AR_CUSG_SOA_CONF.NEXTVAL,
                                          CUSTOMER_ID,
                                          CUSTOMER_CODE,
                                          CUSTOMER_NAME,
                                          SALES_CENTER_ID,
                                          RESULT_BATCH_ROW.CODE_VALUE,
                                          'Y',
                                          'sys',
                                          sysdate,
                                          '',
                                          '',
                                          V_SOA_PRODUCE_DAY,
                                          V_SOA_SEND_DAY,
                                          ENTITY_ID,
                                         (case when  V_PUB_FIN_SYS='NC' 
                                               THEN  
                                                 (select NAME from intf_nc_org_unit ncg where ncg.CODE=SALES_CENTER_CODE and rownum=1)
                                               ELSE  V_SOA_TITLE
                                              END),   
                                          '',
                                          SALES_CENTER_CODE,
                                          SALES_CENTER_NAME,
                                          CUSTOMER_MAIL,
                                          account_id,
                                          account_code
                                    from (select 
                                             c.customer_id
                                            ,c.customer_code
                                            ,a.customer_name
                                            ,a.customer_mail
                                            ,c.sales_center_id
                                            ,c.sales_center_code
                                            ,c.sales_center_name
                                            ,c.entity_id
                                            ,c.account_id,
                                             c.account_code
                                          from 
                                               cims.t_customer_header a
                                              ,cims.v_customer_account_salecenter c
                                          where 
                                                c.customer_id = a.customer_id 
                                          and   c.account_status = 1
                                          and   c.entity_id = P_ENTITY_ID
                                          ) u
                                    where /*customer_id||'-'||account_id||'-'||entity_id
                                          not in (
                                             select customer_id||'-'||ACCOUNT_ID||'-'||entity_id from T_AR_CUSG_SOA_CONF where entity_id =P_ENTITY_ID and ORDER_TYPE=RESULT_BATCH_ROW.CODE_VALUE
                                          )*/
                                          not exists (
                                              select 1
                                              from cims.T_AR_CUSG_SOA_CONF t
                                             where t.entity_id = u.entity_id
                                               and t.ORDER_TYPE = RESULT_BATCH_ROW.CODE_VALUE
                                               and t.customer_id = u.customer_id
                                               and t.account_id = u.account_id
                                          );
                       EXCEPTION
                         WHEN OTHERS THEN
                                  V_RESULT:=  PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                           SQLCODE,
                                                           '对账单配置失败！主体:' || P_ENTITY_ID  || RESULT_BATCH_ROW.CODE_VALUE ||
                                                           substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                       END;
                 END LOOP;
         END IF;

    --账期：取上一期间
    SELECT TO_CHAR(ADD_MONTHS(P_COUNT_PERIOD, -1), 'YYYY-MM')
      INTO V_PERIOD_DATE
      FROM DUAL;

    --账期期间1日
    select trunc(add_months(P_COUNT_PERIOD,-1),'mm')
    INTO V_PERIOD_START_DATE
    FROM DUAL;

    --账期期间的月份最大日期
    SELECT TRUNC(LAST_DAY(ADD_MONTHS(P_COUNT_PERIOD, -1)))
      INTO V_PERIOD_END_DATE
      FROM DUAL;

    --账期结束时间下一天
    SELECT trunc(P_COUNT_PERIOD, 'mm')
      INTO V_PERIOD_END_DATE2
      FROM DUAL;


    --账期上一期间1日
    select trunc(add_months(P_COUNT_PERIOD,-2),'mm')
      INTO V_LAST_START_DATE
      FROM DUAL;

    --账期上一期间的月份最大日期
    SELECT TRUNC(LAST_DAY(ADD_MONTHS(P_COUNT_PERIOD, -2)))
      INTO V_LAST_END_DATE
      FROM DUAL;

      --第一层循环，获取账号信息
      FOR ACCOUNT_ROW IN C_ACCOUNT LOOP
        BEGIN
        V_CUSTOMER_ID     := ACCOUNT_ROW.customer_id;
        --V_SALES_CENTER_ID := ACCOUNT_ROW.sales_center_id;
         V_ACCOUNT_ID     := ACCOUNT_ROW.Account_Id;

      --删除重复数据
          FOR HIS_ROW IN C_HIS LOOP
          BEGIN
          /*delete FROM T_AR_STATEMENT_ACC_HISTORY t
         WHERE t.entity_id = ACCOUNT_ROW.entity_id
           AND t.customer_id = ACCOUNT_ROW.customer_id
           AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
           AND t.count_period = V_PERIOD_DATE;*/


        /*   delete FROM T_AR_SOA_ORDER_RECEIPT_LINES b
             WHERE b.HEADER_ID = HIS_ROW.HEADER_ID;

             delete FROM T_AR_SOA_ORDER_DIS_LINES b
             WHERE b.HEADER_ID = HIS_ROW.HEADER_ID;

            delete FROM T_AR_SOA_ORDER_ADJUST_LINES b
            WHERE b.HEADER_ID = HIS_ROW.HEADER_ID;

            delete FROM T_AR_SOA_CUST_RECEIPT_HIS b
            WHERE b.SOA_COUNT_BATCH_ID = HIS_ROW.HEADER_ID;

           delete FROM T_AR_SOA_DIS_ORDER_HIS b
           WHERE b.SOA_COUNT_BATCH_ID = HIS_ROW.HEADER_ID;

           delete FROM T_AR_SOA_SO_ORDER_HIS b
           WHERE b.SOA_COUNT_BATCH_ID = HIS_ROW.HEADER_ID;

           delete FROM T_AR_SOA_ORDER_DETAILS b
           WHERE b.SOA_COUNT_BATCH_ID = HIS_ROW.HEADER_ID;

           delete FROM T_AR_SOA_ORDER_DIFFERENCES b
           WHERE b.HEADER_ID = HIS_ROW.HEADER_ID;

           delete FROM T_AR_SOA_ORDER_HEADS t
           WHERE t.header_id = HIS_ROW.HEADER_ID; */

          update T_AR_SOA_CUST_RECEIPT_HIS b set b.status = 'E'
           WHERE b.SOA_COUNT_BATCH_ID = HIS_ROW.HEADER_ID;

          --单据状态更改为E：作废
          update T_AR_SOA_DIS_ORDER_HIS b set b.diff_update_flag = 'E'
           WHERE b.SOA_COUNT_BATCH_ID = HIS_ROW.HEADER_ID;

          --单据状态更改为E：作废
          update T_AR_SOA_SO_ORDER_HIS b set b.diff_update_flag = 'E'
           WHERE b.SOA_COUNT_BATCH_ID = HIS_ROW.HEADER_ID;

          update T_AR_SOA_ORDER_DETAILS b set b.diff_update_flag = 'E'
           WHERE b.SOA_COUNT_BATCH_ID = HIS_ROW.HEADER_ID;


          update T_AR_SOA_ORDER_HEADS t set t.confirm_flag = 'E'
           WHERE t.header_id = HIS_ROW.HEADER_ID;

          END;
          END LOOP;

       --判断到款表账期内是否存在数据
          SELECT COUNT(*)
            INTO V_COUNT0
            FROM v_ar_cash_receipt_header_lines t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
             AND t.REVIEWED_DATE >= V_PERIOD_START_DATE
             AND t.REVIEWED_DATE < V_PERIOD_END_DATE2;

       --判断销售表账期内是否存在销售数据
          SELECT COUNT(*)
            INTO V_COUNT3
            FROM T_SO_HEADER t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008','1009', '1010')
             AND t.so_status <> '10'
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

        --判断是否存在数据
        /*if (V_COUNT0 = 0 AND V_COUNT3 = 0)  THEN
          V_RESULT := '账户账期:[' || V_PERIOD_DATE || ']内无对账数据';
          P_RESULT := V_RESULT;*/

        --else

          --判断该账号在账期内是否已对账
        /*SELECT COUNT(*)
          INTO V_COUNT
          FROM T_AR_STATEMENT_ACC_HISTORY t
         WHERE t.entity_id = ACCOUNT_ROW.entity_id
           AND t.customer_id = ACCOUNT_ROW.customer_id
           AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
           AND t.count_period = V_PERIOD_DATE;
        --该账号在账期内已对账
        if (V_COUNT > 0) THEN
          V_RESULT := '传入的客户或者中心本期已经计算过往来对账单信息，对账期间：【' || V_PERIOD_DATE || '】';
          P_RESULT := V_RESULT;
          --RAISE V_ERR_EXCEPT;
          --该账号在账期内未对账，生成对账单头表 */
       -- else

          SELECT COUNT(*)
            INTO V_COUNT1
            FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
             AND t.SOA_END_DATE = V_LAST_END_DATE
             AND nvl(t.confirm_flag,'N') <> 'E';

          --add by huanghb12 
          if (V_COUNT1 = 0) THEN
            --查询期末日期为上月对象结束日期的对账单
            SELECT COUNT(*)
            INTO V_COUNT1_
            FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             --AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
             AND t.SOA_END_DATE = V_LAST_END_DATE
             AND nvl(t.confirm_flag,'N') <> 'E';
          else
            BEGIN
            --获取期初余额（上期期末余额）
            SELECT NVL(t.RECEIPT_AMOUNT,0),NVL(t.DISCOUNT_AMOUNT,0)
              INTO V_AMOUNT_SA,V_AMOUNT_SJ
              FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
             AND t.SOA_END_DATE = V_LAST_END_DATE
             AND nvl(t.confirm_flag,'N') <> 'E';
            EXCEPTION
              WHEN OTHERS THEN
                V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                   SQLCODE,
                                                   '获取期初余额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                   substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                P_RESULT := V_RESULT;
                --RAISE V_ERR_EXCEPT;
                V_AMOUNT_SA := V_AMOUNT_SA2;
                V_AMOUNT_SJ := V_AMOUNT_SJ2;
                CONTINUE;
            END;
          end if;
          --如果上期对账单和以上期期末日期为结束日期的对账单都不存在
          IF V_COUNT1 = 0 and V_COUNT1_ = 0 THEN
            --计算总期余额
            
            --1）获取总期累计到款余额
            SELECT NVL(SUM(NVL(t.amount, 0)), 0)
              INTO V_AMOUNT_SA2
              FROM v_ar_cash_receipt_header_lines t
             WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               AND t.account_id = ACCOUNT_ROW.account_id
               AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
               --AND t.REVIEWED_DATE >= V_LAST_START_DATE
               AND t.REVIEWED_DATE < V_PERIOD_START_DATE;
               
             --2）获取总期提货金额
            --2.1）计算总期提货金额（考虑了总期内结算的差异数据）
            SELECT NVL(SUM(NVL(t.settle_amount, 0) *
                           b.APPLIED_PLUS_MINUS_FLAG),
                       0)
              INTO V_AMOUNT_SE2
              FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
             WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               AND t.account_id = ACCOUNT_ROW.account_id
               AND t.bill_type_id = b.bill_type_id
               --AND b.Can_Applied_Flag = 'Y'
               AND t.so_status <> '10'
               AND t.BIZ_SRC_BILL_TYPE_CODE in
                   ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                    '1008')
               --AND t.so_date >= V_PERIOD_START_DATE
               AND t.so_date < V_PERIOD_START_DATE;
               
             --总期余额 = 总期累计到款余额 - 计算总期提货金额
             V_AMOUNT_SA := V_AMOUNT_SA2 - V_AMOUNT_SE2;
             --计算总期初折让余额
             --1）计算总期初折让余额
             
            SELECT NVL(SUM(NVL(t.settle_amount, 0) *
                           b.APPLIED_PLUS_MINUS_FLAG),
                       0)
              INTO V_AMOUNT_SJ2 --总期折让金额（考虑了差异数据）
              FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
             WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               AND t.account_id = ACCOUNT_ROW.account_id
               AND t.bill_type_id = b.bill_type_id
               --AND b.Can_Applied_Flag = 'Y'
               AND t.so_status <> '10'
               AND t.BIZ_SRC_BILL_TYPE_CODE in ('1009', '1010')
               --AND t.SO_DATE >= V_LAST_START_DATE
                AND t.SO_DATE < V_PERIOD_START_DATE;
                
          --2）计算总期核销折让金额
          SELECT NVL(SUM(NVL(t.discount_amount, 0) *
                         b.APPLIED_PLUS_MINUS_FLAG),
                     0)
            INTO V_AMOUNT_SL2
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.bill_type_id = b.bill_type_id
             --AND b.Can_Applied_Flag = 'Y'
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             --AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_START_DATE;

             --总期折让总金额 = 计算总期折让总余额  - 计算总期核销折让金额
             V_AMOUNT_SJ := V_AMOUNT_SJ2 - V_AMOUNT_SL2;    
          ELSIF V_COUNT1 = 0 and V_COUNT1_ != 0  then
            BEGIN
            --获取期初余额
            select AMOUNT_SA,AMOUNT_SJ
                   INTO V_AMOUNT_SA,V_AMOUNT_SJ
             from (
              SELECT NVL(t.RECEIPT_AMOUNT,0) AMOUNT_SA,NVL(t.DISCOUNT_AMOUNT,0) AMOUNT_SJ
                FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               AND t.account_id = ACCOUNT_ROW.account_id
               --AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
               AND t.SOA_END_DATE = V_LAST_END_DATE
               AND nvl(t.confirm_flag,'N') <> 'E'
               order by t.SOA_BEGIN_DATE asc
               ) where rownum = 1;
            
            EXCEPTION
              WHEN OTHERS THEN
                V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                   SQLCODE,
                                                   '获取期初余额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                   substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                P_RESULT := V_RESULT;
                --RAISE V_ERR_EXCEPT;
                V_AMOUNT_SA := V_AMOUNT_SA2;
                V_AMOUNT_SJ := V_AMOUNT_SJ2;
                CONTINUE;
            END;   
          END IF;
          --end by huanghb12

        --计算本期到款金额
          SELECT NVL(SUM(NVL(t.amount, 0)), 0)
            INTO V_AMOUNT_SB
            FROM v_ar_cash_receipt_header_lines t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
             AND t.REVIEWED_DATE >= V_PERIOD_START_DATE
             AND t.REVIEWED_DATE < V_PERIOD_END_DATE2;

          --判断上期是否存在修改销售单据原始数据，本期结算的金额和对账历史表中的销售单销售金额不一样，结算金额和制单时销售单的销售金额不一样
            SELECT COUNT(*)
              INTO V_COUNT13
              FROM cims.t_so_header t,cims.T_AR_SOA_SO_ORDER_HIS b
             WHERE t.so_num = b.order_number AND t.settle_amount <> b.amount
               AND t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               AND t.account_id = ACCOUNT_ROW.account_id
             --  AND t.SO_DATE >= V_LAST_START_DATE --去掉日期限制 guibr 存在跨两月结算单据
               AND t.SO_DATE < V_PERIOD_START_DATE
               AND t.settle_date >= V_PERIOD_START_DATE
                 AND t.settle_date < V_PERIOD_END_DATE2
               AND nvl(b.diff_update_flag,'N') <> 'E';

             if (V_COUNT13 > 0) THEN
                SELECT (NVL(SUM(NVL(t.settle_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0) - NVL(SUM(NVL(b.amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0)),
                       (NVL(SUM(NVL(t.discount_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0) - NVL(SUM(NVL(b.dis_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0))
                  INTO D_AMOUNT_SE,D_AMOUNT_SL
                  FROM cims.t_so_header t,cims.T_AR_SOA_SO_ORDER_HIS b ,cims.T_SO_TYPE_EXTEND e
                 WHERE t.so_num = b.order_number AND t.bill_type_id = e.bill_type_id
                   AND t.settle_amount <> b.amount
                   AND t.entity_id = ACCOUNT_ROW.entity_id
                   AND t.customer_id = ACCOUNT_ROW.customer_id
                   --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                   AND t.account_id = ACCOUNT_ROW.account_id
                 --  AND t.SO_DATE >= V_LAST_START_DATE  --去掉日期限制 guibr 存在跨两月结算单据
                   AND t.SO_DATE < V_PERIOD_START_DATE
                   AND t.settle_date >= V_PERIOD_START_DATE
                     AND t.settle_date < V_PERIOD_END_DATE2
                   AND nvl(b.diff_update_flag,'N') <> 'E';
             else
               D_AMOUNT_SE := 0;
               D_AMOUNT_SL := 0;
             end if;

          --计算到款提货金额
          SELECT (NVL(SUM(NVL(t.settle_amount, 0) *
                         b.APPLIED_PLUS_MINUS_FLAG),
                     0) + D_AMOUNT_SE)
            INTO V_AMOUNT_SE
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.bill_type_id = b.bill_type_id
             --AND b.Can_Applied_Flag = 'Y'
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

          --计算本期到款余额  F = A + D - E
          V_AMOUNT_SF := V_AMOUNT_SA + V_AMOUNT_SB - V_AMOUNT_SE;

          --判断上期是否存在修改折让单据原始数据
            SELECT COUNT(*)
              INTO V_COUNT14
              FROM cims.t_so_header t,cims.T_AR_SOA_DIS_ORDER_HIS b
             WHERE t.so_num = b.order_number AND t.discount_amount <> b.dis_amount
               AND t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               AND t.account_id = ACCOUNT_ROW.account_id
              -- AND t.SO_DATE >= V_LAST_START_DATE  --去掉日期限制 guibr 存在跨两月结算单据
               AND t.SO_DATE < V_PERIOD_START_DATE
               AND t.settle_date >= V_PERIOD_START_DATE
                 AND t.settle_date < V_PERIOD_END_DATE2
               AND nvl(b.diff_update_flag,'N') <> 'E';

             if (V_COUNT14 > 0) THEN
                SELECT (NVL(SUM(NVL(t.discount_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0) - NVL(SUM(NVL(b.dis_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0))
                  INTO D_AMOUNT_SK
                  FROM cims.t_so_header t,cims.T_AR_SOA_DIS_ORDER_HIS b ,cims.T_SO_TYPE_EXTEND e
                 WHERE t.so_num = b.order_number AND t.bill_type_id = e.bill_type_id
                   AND t.discount_amount <> b.dis_amount
                   AND t.entity_id = ACCOUNT_ROW.entity_id
                   AND t.customer_id = ACCOUNT_ROW.customer_id
                   --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                   AND t.account_id = ACCOUNT_ROW.account_id
                 --  AND t.SO_DATE >= V_LAST_START_DATE  --去掉日期限制 guibr 存在跨两月结算单据
                   AND t.SO_DATE < V_PERIOD_START_DATE
                   AND t.settle_date >= V_PERIOD_START_DATE
                     AND t.settle_date < V_PERIOD_END_DATE2
                   AND nvl(b.diff_update_flag,'N') <> 'E';
             else
               D_AMOUNT_SK := 0;
             end if;

          --计算本期折让金额
          SELECT (NVL(SUM(NVL(t.settle_amount, 0) *
                         b.APPLIED_PLUS_MINUS_FLAG),
                     0) + D_AMOUNT_SK)
            INTO V_AMOUNT_SK
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.bill_type_id = b.bill_type_id
             --AND b.Can_Applied_Flag = 'Y'
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in ('1009', '1010')
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

          --计算本期核销折让金额
          SELECT (NVL(SUM(NVL(t.discount_amount, 0) *
                         b.APPLIED_PLUS_MINUS_FLAG),
                     0) + D_AMOUNT_SL)
            INTO V_AMOUNT_SL
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.bill_type_id = b.bill_type_id
             --AND b.Can_Applied_Flag = 'Y'
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

          --计算本期折让余额
          V_AMOUNT_SH := V_AMOUNT_SJ + V_AMOUNT_SK - V_AMOUNT_SL;

          --扣率折让单和反向扣率折让单：
           /*SELECT NVL(SUM(NVL(t.UN_SOLUTION_AMOUNT, 0)), 0)
            INTO V_AMOUNT_US
            FROM V_AR_CASH_RECEIPT_UN_SOLU t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_code = ACCOUNT_ROW.customer_code
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
             AND t.REVIEWED_DATE >= V_PERIOD_START_DATE
             AND t.REVIEWED_DATE < V_PERIOD_END_DATE2;*/

             -- add by tangfeng
             --三方承兑未解付汇总UN_SOLUTION_AMOUNT：计算三方承兑未解付金额总和:查询收款头行表中三方承兑汇票来源的资金，减去解付表中解付的资金，就是未解付三方承兑  
             select sum(un_solution_amount)
             INTO V_AMOUNT_US
             FROM(
             select nvl(l.amount,0) - nvl(acc.solution_pay_amount, 0) un_solution_amount
             from cims.t_ar_cash_receipt_headers h
             left join cims.t_ar_cash_receipt_lines l on l.cash_receipt_id = h.cash_receipt_id
             left join (SELECT p.CASH_RECEIPT_LINES_ID, nvl(SUM(p.SOLUTION_PAY_AMOUNT), 0) AS SOLUTION_PAY_AMOUNT
                       FROM cims.t_ar_acce_solu_pay p
                       WHERE p.solution_pay_status in ('2', '3') and p.solution_pay_time < V_PERIOD_END_DATE2
                       GROUP BY p.CASH_RECEIPT_LINES_ID) acc
                  on acc.cash_receipt_lines_id = l.cash_receipt_lines_id
             left join cims.t_ar_receipt_methods m on h.receipt_method_id = m.receipt_method_id
             where h.receipt_status_id not in (0,1,2,10,12,19) and m.receipt_type = '3'
             and h.entity_id = ACCOUNT_ROW.entity_id
             AND h.customer_code = ACCOUNT_ROW.customer_code
             AND h.account_id = ACCOUNT_ROW.account_id
             AND h.REVIEWED_DATE < V_PERIOD_END_DATE2);

             /**select sum(un_solution_amount)
             INTO V_AMOUNT_US
             FROM(
             select nvl(l.amount,0) - sum (nvl (acc.solution_pay_amount, 0)) un_solution_amount
             from cims.t_ar_cash_receipt_headers h left join cims.t_ar_cash_receipt_lines l on l.cash_receipt_id = h.cash_receipt_id
             left join cims.t_ar_acce_solu_pay acc on acc.cash_receipt_lines_id = l.cash_receipt_lines_id and acc.solution_pay_status in ('2', '3') and acc.solution_pay_time < V_PERIOD_END_DATE2
             left join cims.t_ar_receipt_methods m on h.receipt_method_id = m.receipt_method_id
             where h.receipt_status_id not in (0,1,2,10,12,19) and m.receipt_type = '3'
             and h.entity_id = ACCOUNT_ROW.entity_id
             AND h.customer_code = ACCOUNT_ROW.customer_code
             AND h.account_id = ACCOUNT_ROW.account_id
             group by l.cash_receipt_lines_id,l.amount);**/

        --获取确认式往来对账单头ID
          SELECT S_AR_SOA_ORDER_HEADS.NEXTVAL
            INTO V_SOA_COUNT_BATCH_ID
            FROM DUAL;

          --生成对账单号
          /*V_ORDER_NUMBER := 'ZD' || replace(V_PERIOD_DATE, '-', '') ||
          substr(('000000' ||to_char(V_SOA_COUNT_BATCH_ID)),length('000000' || to_char(V_SOA_COUNT_BATCH_ID))-5,6);*/

          BEGIN
            V_ORDER_NUMBER := PKG_BD.F_GET_BILL_NO('ARBICODE',
                                                        'ZD',
                                                        P_ENTITY_ID,
                                                        null);
          EXCEPTION
            WHEN OTHERS THEN
              V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                  SQLCODE,
                                                  '生成对账单据号失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                  substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
              CONTINUE;
          END;

        BEGIN

            --插入确认式往来对账单头表
            INSERT INTO T_AR_SOA_ORDER_HEADS
              (HEADER_ID, --对账单ID
               CUSTOMER_ID, --客户ID
               CUSTOMER_CODE, --客户编码
               CUSTOMER_NAME, --客户名称
               SALES_CENTER_ID, --中心ID
               ORDER_DATE, --对账单日期
               ORDER_NUMBER, --对账单号
               ORDER_TYPE, --对账单类型
               CONFIRM_USER_ID, --客户确认人ID
               CONFIRM_USER_NAME, --客户确认人名称
               CONFIRM_FLAG, --客户确认标志
               PRINT_FLAG, --打印标志
               PRINTER_BY, --最后一次打印人员ID
               PRINT_DATE, --最后一次打印日期
               RECEIPT_AMOUNT, --本期到款余额
               DISCOUNT_AMOUNT, --本期折让余额
               COMMENT_INFO, --备注
               ENTITY_ID, --主体
               CREATED_BY, --创建人
               CREATION_DATE, --创建时间
               LAST_UPDATED_BY, --最后更新人
               LAST_UPDATE_DATE, --最后更新时间
               SOA_COUNT_BATCH_ID,
               PERIOD_DATE, --对账期间
               SOA_BEGIN_DATE, --对账开始日期
               SOA_END_DATE, --对账结束日期
               CLOSE_FLAG,
               EXECUTE_MODE, --手工录入标志
               ACCOUNT_ID,
               ACCOUNT_CODE,
               ACCOUNT_NAME,
               ORDER_STATE,
               UN_SOLUTION_AMOUNT,--三方承兑未解付汇总
               COMPANY_RISE,
               SEND_CCS_FLAG
               )
            VALUES
              (V_SOA_COUNT_BATCH_ID,
               ACCOUNT_ROW.CUSTOMER_ID,
               ACCOUNT_ROW.CUSTOMER_CODE,
               ACCOUNT_ROW.CUSTOMER_NAME,
               /* (select distinct w.CUSTOMER_NAME
                  from cims.T_CUSTOMER_ORG t,cims.t_customer_header w
                 where t.customer_id = w.customer_id
                   and t.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                   and t.SALES_CENTER_ID = ACCOUNT_ROW.SALES_CENTER_ID
                   and t.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID) */
               ACCOUNT_ROW.SALES_CENTER_ID,
               SYSDATE,
               V_ORDER_NUMBER, -- 对账单号存疑
               /*NVL((select CSC.ORDER_TYPE
                                    from T_AR_CUSG_SOA_CONF CSC
                                   where CSC.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                                     and CSC.SALES_CENTER_ID = ACCOUNT_ROW.SALES_CENTER_ID
                                     and CSC.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID),
                                  '1'),*/
               '余额确认式', --头表对账单类型    确认式
               NULL, --客户确认人ID
               NULL, --客户确认人名称
               'N', --客户确认标志
               'N', --打印标志
               NULL, --最后一次打印人员ID
               NULL, --最后一次打印日期
               V_AMOUNT_SF, --本期总到款余额
               V_AMOUNT_SH, --本期总折让余额
               NULL, --备注
               ACCOUNT_ROW.ENTITY_ID, --主体
               --P_USER_CODE CREATED_BY, --创建人
               'cims', --创建人
               SYSDATE, --创建时间
               NULL, --最后更新人
               NULL, --最后更新时间
               V_SOA_COUNT_BATCH_ID,
               V_PERIOD_DATE,
               V_PERIOD_START_DATE,
               V_PERIOD_END_DATE,
               'N',
               'N',                      -- '系统生成',
               ACCOUNT_ROW.ACCOUNT_ID,
               (select distinct w.ACCOUNT_CODE
                  from v_customer_account_conf w
                 where w.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                   and w.ACCOUNT_ID = ACCOUNT_ROW.ACCOUNT_ID
                   and w.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID),
               (select distinct w.ACCOUNT_NAME
                  from v_customer_account_conf w
                 where w.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                   and w.ACCOUNT_ID = ACCOUNT_ROW.ACCOUNT_ID
                   and w.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID),
               /* (select distinct w.ACCOUNT_ID
                  from v_cust_account w
                 where w.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                   and w.SALES_CENTER_ID = ACCOUNT_ROW.SALES_CENTER_ID
                   and w.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID),
               (select distinct w.ACCOUNT_CODE
                  from v_cust_account w
                 where w.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                   and w.SALES_CENTER_ID = ACCOUNT_ROW.SALES_CENTER_ID
                   and w.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID),
               (select distinct w.ACCOUNT_NAME
                  from v_cust_account w
                 where w.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                   and w.SALES_CENTER_ID = ACCOUNT_ROW.SALES_CENTER_ID
                   and w.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID), */
               'Y',
               V_AMOUNT_US,
               ACCOUNT_ROW.Title,
               'Y'
               );

               --2017-02-06 tianmzh add 增加判断，根据主体+客户+账户获取对账配置表中是否自动确认标志，Y-自动确认；N-不自动确认。
               --获取系统参数配置：0-按对账配置表中的是否自动确认标志控制、1-自动确认、2-不自动确认'
               PKG_BD.P_GET_PARAMETER_VALUE('ar_account_confirm_flag',
                                   ACCOUNT_ROW.ENTITY_ID,
                                   '',
                                   '',
                                   V_ACCOUNT_CONFIRM_FLAG);
               BEGIN
                 SELECT NVL(TC.IS_AUTO_FLAG, 'N')
                   INTO V_AUTO_FLAG
                   FROM CIMS.T_AR_CUSG_SOA_CONF TC
                  WHERE TC.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID
                    AND TC.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                    AND TC.ACCOUNT_ID = ACCOUNT_ROW.ACCOUNT_ID
                    --2017-02-22 tianmzh增加，防止一个客户多条配置数据时报错
                    AND ROWNUM = 1;
               EXCEPTION
                 --若没有查询到数据，则默认对账单自动确认
                 WHEN NO_DATA_FOUND THEN
                   V_AUTO_FLAG := 'Y';
               END;
               --期内是不在数据，期内是不在销售数据，自动确认
               IF V_COUNT0=0 and  V_COUNT3 =0 AND (V_ACCOUNT_CONFIRM_FLAG = '1'OR (V_ACCOUNT_CONFIRM_FLAG = '0' AND V_AUTO_FLAG = 'Y')) then
                   update T_AR_SOA_ORDER_HEADS set
                        CONFIRM_DATE = sysdate
                        ,CONFIRM_FLAG = 'Y'
                        ,CONFIRM_USER_ID = 0
                        ,CONFIRM_USER_NAME = 'cims'
                        ,CENTER_CHECK_FLAG='Y'
                        ,CENTER_CHECK_DATE = sysdate
                        ,ORDER_TYPE='系统自动确认'
                        ,COMMENT_INFO='客户本期对账期间，无业务往来或者业务单据金额合计为0，系统自动确认'
                   where HEADER_ID = V_SOA_COUNT_BATCH_ID;
               END IF;

          EXCEPTION
            WHEN OTHERS THEN
              V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                 SQLCODE,
                                                 '插入确认式往来对账单头表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                 substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
              P_RESULT := V_RESULT;
              --RAISE V_ERR_EXCEPT;

              --插入往来对账客户表
               V_RESULT2 := PKG_AR_ACCOUNT.F_ADD_SOA_HISTORY
               (NULL,
               ACCOUNT_ROW.CUSTOMER_ID,
               ACCOUNT_ROW.CUSTOMER_CODE,
               ACCOUNT_ROW.CUSTOMER_NAME,
               NULL,
               ACCOUNT_ROW.SALES_CENTER_ID,
               'N',
               V_PERIOD_START_DATE,
               V_PERIOD_END_DATE,
               V_PERIOD_DATE,
               --NVL(CSC.ORDER_TYPE, '余额确认式'),
               NULL,
               V_ORDER_NUMBER,
               NULL,
               NULL,
               NULL,
               'FAILURE',
               V_RESULT,
               NULL,
               ACCOUNT_ROW.ENTITY_ID,
               NULL,
               SYSDATE,
               NULL,
               NULL,
               V_SOA_COUNT_BATCH_ID);
            /*
            INSERT INTO T_AR_STATEMENT_ACC_HISTORY
              (ACC_HISTORY_ID,
               HEADER_ID,
               CUSTOMER_ID,
               CUSTOMER_CODE,
               CUSTOMER_NAME,
               CUSTOMER_FLAG,
               SALES_CENTER_ID,
               HANDMODE_FLAG,
               COUNT_START_DATE,
               COUNT_END_DATE,
               COUNT_PERIOD,
               ORDER_TYPE,
               ORDER_NUMBER,
               SOA_RECEIPT_BATCH_ID,
               SOA_SO_ORDER_BATHC_ID,
               SOA_DISCOUNT_BACHT_ID,
               STATES,
               COUNT_RESULT,
               COMMENTS,
               ENTITY_ID,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE,
               SOA_COUNT_BATCH_ID)
            VALUES
              (S_AR_STATEMENT_ACC_HISTORY.NEXTVAL,
               NULL,
               ACCOUNT_ROW.CUSTOMER_ID,
               ACCOUNT_ROW.CUSTOMER_CODE,
               NULL,
               NULL,
               ACCOUNT_ROW.SALES_CENTER_ID,
               'N',
               V_PERIOD_START_DATE,
               V_PERIOD_END_DATE,
               V_PERIOD_DATE,
               --NVL(CSC.ORDER_TYPE, '余额确认式'),
               NULL,
               V_ORDER_NUMBER,
               NULL,
               NULL,
               NULL,
               'FAILURE',
               V_RESULT,
               NULL,
               ACCOUNT_ROW.ENTITY_ID,
               NULL,
               SYSDATE,
               NULL,
               NULL,
               V_SOA_COUNT_BATCH_ID);
            COMMIT;
            */
            CONTINUE;
              --EXIT; --退出当前循环
          END;
          --order_type 1-到款结算 2-折让扣款 3-NC对账单 4-调节式
          SELECT COUNT(*)
            INTO V_COUNT8
            FROM t_ar_cusg_soa_conf t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             and t.account_id = ACCOUNT_ROW.account_id
             AND t.order_type = '3';
            --如果配置表中配置了本客户需要做NC对账单，使用NC对账单格式展示张单
           if (V_COUNT8 > 0) THEN
             BEGIN
                --插入调节试对账单行表，对账单展示方式不同而已，NC对账单
                INSERT INTO T_AR_SOA_ORDER_ADJUST_LINES
                  (ADJUST_LINE_ID, --行ID
                   HEADER_ID, --对账单头ID
                   DEBIT_PERIOD_AMOUNT, --借方期初余额(合计)
                   PRODUCT_AR_DEBIT_PERIOD_AMOUNT, --应收借方期初额（成品）
                   FITTING_AR_DEBIT_PERIOD_AMOUNT, --应收借方期初额（配件）
                   AR_DEBIT_AMOUNT,                --本期借方发生额（合计）
                   PRODUCT_AR_DEBIT_AMOUNT, --成品本期借方本期累计到款余额
                   PRODUCT_SALES_DEBIT_AMOUNT, --成品本期借方本期累计到款提贷金额
                   FITTING_AR_DEBIT_AMOUNT,    --配件本期借方本期累计到款余额
                   FITTING_SALES_DEBIT_AMOUNT, --配件本期借方本期累计到款提贷金额
                   ENTITY_ID, --主体ID
                   CREATED_BY, --创建人
                   CREATION_DATE, --创建日期
                   LAST_UPDATED_BY, --最后更新人
                   LAST_UPDATED_DATE） --最后更新日期)
                VALUES
                  (S_AR_SOA_ORDER_LINES.NEXTVAL,
                   V_SOA_COUNT_BATCH_ID,
                   (-1 * V_AMOUNT_SA + 0), --借方期初余额(合计)
                   -1 * V_AMOUNT_SA,   --应收借方期初额（成品）
                   0,            --应收借方期初额（配件）
                   (V_AMOUNT_SE - V_AMOUNT_SB + 0 - 0),         --本期借方发生额（合计）
                   V_AMOUNT_SB, --成品本期借方本期累计到款余额
                   V_AMOUNT_SE, --成品本期借方本期累计到款提贷金额
                   0,          --配件本期借方本期累计到款余额
                   0,          --配件本期借方本期累计到款提贷金额
                   ACCOUNT_ROW.ENTITY_ID,
                   NULL,
                   SYSDATE,
                   NULL,
                   NULL);

              EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                     SQLCODE,
                                                     '插入调节试对账单行表！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
              END;

           end if;

           --按照品类再去核对到款金额、折让金额等信息
          FOR ITEMCLASS_ROW IN C_ITEM_CLASS LOOP

          V_CLASS_CODE := ITEMCLASS_ROW.CLASS_CODE;
          V_DISCOUNT_TYPE := ITEMCLASS_ROW.DISCOUNT_TYPE;

          --按品类判断到款表账期内是否存在数据
          SELECT COUNT(*)
            INTO V_COUNT4
            FROM v_ar_cash_receipt_header_lines t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             and t.account_id = ACCOUNT_ROW.account_id
             AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
             AND t.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
             AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             AND t.REVIEWED_DATE >= V_PERIOD_START_DATE
             AND t.REVIEWED_DATE < V_PERIOD_END_DATE2;

          --按品类判断销售表账期内是否存在销售数据
          SELECT COUNT(*)
            INTO V_COUNT5
            FROM T_SO_HEADER t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             and t.account_id = ACCOUNT_ROW.account_id
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             AND t.so_status <> '10'
             AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
             AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

           --按品类判断销售表账期内是否存在折让数据，1009和1010是扣率折让单
          SELECT COUNT(*)
            INTO V_COUNT6
            FROM T_SO_HEADER t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             and t.account_id = ACCOUNT_ROW.account_id
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1009', '1010')
             AND t.so_status <> '10'
             AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
              AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

          --判断当前品类是否存在数据
          /*if (V_COUNT4 = 0 AND V_COUNT5 = 0 AND V_COUNT6 = 0) THEN
            V_RESULT := '账户无品类[' || ITEMCLASS_ROW.CLASS_CODE || ']的对账数据';
            P_RESULT := V_RESULT;*/

          --else
            --按品类判断上一账期数据是否存在
            SELECT COUNT(*)
              INTO V_COUNT2
              FROM T_AR_SOA_ORDER_RECEIPT_LINES b
             WHERE b.HEADER_ID = (SELECT MAX(t.HEADER_ID)
              FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               and t.account_id = ACCOUNT_ROW.account_id
               AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
               AND t.SOA_END_DATE = V_LAST_END_DATE
               AND nvl(t.confirm_flag,'N') <> 'E')
               AND b.sales_main_name = ITEMCLASS_ROW.CLASS_CODE
               AND NVL(b.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE;
               
           --revised by huanghb12 2019-1-3
           if (V_COUNT2 = 0) THEN
            --按品类判断以本期开始日期为结束日期的账期数据是否存在
            SELECT COUNT(*)
              INTO V_COUNT2_
              FROM T_AR_SOA_ORDER_RECEIPT_LINES b
             WHERE b.HEADER_ID = (SELECT MAX(t.HEADER_ID)
              FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               and t.account_id = ACCOUNT_ROW.account_id
               --AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
               AND t.SOA_END_DATE = V_LAST_END_DATE
               AND nvl(t.confirm_flag,'N') <> 'E')
               AND b.sales_main_name = ITEMCLASS_ROW.CLASS_CODE
               AND NVL(b.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE;      
          else
            BEGIN
            --按品类获取期初余额，和保证金锁定金额（保证金锁定金额就是临时铺底单据中冻结保证金类型的铺底单据对应的金额）
            SELECT NVL(b.CURRENT_AMOUNT,0)
              INTO V_AMOUNT_A
              FROM T_AR_SOA_ORDER_RECEIPT_LINES b
             WHERE b.HEADER_ID = (SELECT MAX(t.HEADER_ID)
             FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               and t.account_id = ACCOUNT_ROW.account_id
               AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
               AND t.SOA_END_DATE = V_LAST_END_DATE
               AND nvl(t.confirm_flag,'N') <> 'E')
               AND b.sales_main_name = ITEMCLASS_ROW.CLASS_CODE
                AND NVL(b.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE;
            EXCEPTION
              WHEN OTHERS THEN
                V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                   SQLCODE,
                                                   '获取期初余额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                   substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                P_RESULT := V_RESULT;
                --RAISE V_ERR_EXCEPT;
                V_AMOUNT_A := 0;
                CONTINUE;
            END;
          end if;
          
          IF  V_COUNT2 = 0 and V_COUNT2_ = 0  THEN
               --按品类计算期初余额,以本期开始日期为结束日期的账期数据是否存在(本期之前所有的数据)
            SELECT NVL(SUM(NVL(t.amount, 0)), 0)
              INTO V_AMOUNT_A2
              FROM v_ar_cash_receipt_header_lines t
             WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               and t.account_id = ACCOUNT_ROW.account_id
               AND t.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
               AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
               AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
               --AND t.REVIEWED_DATE >= V_LAST_START_DATE
               AND t.REVIEWED_DATE < V_PERIOD_START_DATE;

          --按品类计算总期的到款提货金额
          SELECT NVL(SUM(NVL(t.settle_amount, 0) *
                         b.APPLIED_PLUS_MINUS_FLAG),
                     0)
            INTO V_AMOUNT_E2
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             and t.account_id = ACCOUNT_ROW.account_id
             AND t.bill_type_id = b.bill_type_id
             AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
              AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             --AND b.Can_Applied_Flag = 'Y'
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             --AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_START_DATE;

             --总期到款余额 = 计算总期到款余额 - 到款提货金额（考虑了总期内结算的销售差异数据）
             V_AMOUNT_A := V_AMOUNT_A2 - V_AMOUNT_E2;
             
             --计算总期锁定金额，保证金锁定金额（保证金锁定金额就是临时铺底单据中冻结保证金类型的铺底单据对应的金额）  
              /*SELECT NVL(SUM(NVL(D.APPROVAL_AMOUNT, 0)),0) 
                INTO  V_AMOUNT_LOCI
                FROM  T_CREDIT_DELAYPAY D --铺底单据信息表
                WHERE DELAYPAY_TYPE =10     --冻结保证金
                  AND BILL_STATUS = 3       --已审批
                  AND D.DUE_TIME IS NULL    --没过期
                 AND V_DISCOUNT_TYPE = V_DISCOUNT_TYPE_COMMON
                  AND D.entity_id = ACCOUNT_ROW.entity_id
                  AND D.customer_id = ACCOUNT_ROW.customer_id
                  AND D.account_id = ACCOUNT_ROW.account_id
                  AND D.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
                  --AND D.BILL_DATE >= V_LAST_START_DATE   
                  AND D.BILL_DATE < V_PERIOD_START_DATE;*/
                 
            ELSIF V_COUNT2 = 0 and V_COUNT2_ != 0 THEN
              BEGIN
                --按品类获取期初余额
                SELECT NVL(b.CURRENT_AMOUNT,0)--,NVL(b.DEPOSIT_LOCK_AMOUNT,0)
                  INTO V_AMOUNT_A--,V_AMOUNT_LOCI
                  FROM T_AR_SOA_ORDER_RECEIPT_LINES b
                 WHERE b.HEADER_ID = (SELECT MAX(t.HEADER_ID)
                 FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
                   AND t.customer_id = ACCOUNT_ROW.customer_id
                   --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                   and t.account_id = ACCOUNT_ROW.account_id
                   --AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
                   AND t.SOA_END_DATE = V_LAST_END_DATE
                   AND nvl(t.confirm_flag,'N') <> 'E')
                   AND b.sales_main_name = ITEMCLASS_ROW.CLASS_CODE
                    AND NVL(b.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE;
                EXCEPTION
                  WHEN OTHERS THEN
                    V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                       SQLCODE,
                                                       '获取期初余额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                       substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                    P_RESULT := V_RESULT;
                    --RAISE V_ERR_EXCEPT;
                    V_AMOUNT_A := 0;
                    CONTINUE;
                END;
            END IF; 
            --end by huanghb12
            
          --按品类计算本期到款金额
          SELECT NVL(SUM(NVL(t.amount, 0)), 0)
            INTO V_AMOUNT_B
            FROM v_ar_cash_receipt_header_lines t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             and t.account_id = ACCOUNT_ROW.account_id
             AND t.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
              AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
             AND t.REVIEWED_DATE >= V_PERIOD_START_DATE
             AND t.REVIEWED_DATE < V_PERIOD_END_DATE2;

          --按品类计算累计金额  C=A+B
          V_AMOUNT_C := V_AMOUNT_A + V_AMOUNT_B;

          --按品类计算本期累计到款  D = B
          V_AMOUNT_D := V_AMOUNT_B;

          --按品类判断上期(本期结算)是否存在修改销售单据原始数据（本期结算，此前的销售单）
            SELECT COUNT(*)
              INTO V_COUNT16
              FROM cims.t_so_header t,cims.T_AR_SOA_SO_ORDER_HIS b
             WHERE t.so_num = b.order_number AND t.settle_amount <> b.amount
               AND t.Entity_Id = ACCOUNT_ROW.Entity_Id
               AND t.Customer_Id = ACCOUNT_ROW.Customer_Id
               --AND t.Sales_Center_Id = V_SALES_CENTER_ID
               and t.account_id = ACCOUNT_ROW.account_id
               AND t.SALES_MAIN_TYPE = V_CLASS_CODE
                AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             --  AND t.SO_DATE >= V_LAST_START_DATE --去掉日期限制 guibr 存在跨两月结算单据
               AND t.SO_DATE < V_PERIOD_START_DATE
               AND t.settle_date >= V_PERIOD_START_DATE
                 AND t.settle_date < V_PERIOD_END_DATE2
               AND nvl(b.diff_update_flag,'N') <> 'E';

             if (V_COUNT16 > 0) THEN
                SELECT (NVL(SUM(NVL(t.settle_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0) - NVL(SUM(NVL(b.amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0)),
                       (NVL(SUM(NVL(t.discount_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0) - NVL(SUM(NVL(b.dis_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0))
                  INTO D_AMOUNT_E,D_AMOUNT_L
                  FROM cims.t_so_header t,cims.T_AR_SOA_SO_ORDER_HIS b ,cims.T_SO_TYPE_EXTEND e
                 WHERE t.so_num = b.order_number AND t.bill_type_id = e.bill_type_id
                   AND t.settle_amount <> b.amount
                   AND t.Entity_Id = ACCOUNT_ROW.Entity_Id
                   AND t.Customer_Id = ACCOUNT_ROW.Customer_Id
                   --AND t.Sales_Center_Id = V_SALES_CENTER_ID
                   and t.account_id = ACCOUNT_ROW.account_id
                   AND t.SALES_MAIN_TYPE = V_CLASS_CODE
                    AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                 --  AND t.SO_DATE >= V_LAST_START_DATE --去掉日期限制 guibr 存在跨两月结算单据
                   AND t.SO_DATE < V_PERIOD_START_DATE
                   AND t.settle_date >= V_PERIOD_START_DATE
                     AND t.settle_date < V_PERIOD_END_DATE2
                   AND nvl(b.diff_update_flag,'N') <> 'E';
             else
               D_AMOUNT_E := 0;
               D_AMOUNT_L := 0;
             end if;

          --按品类计算本期到款提货金额
          SELECT (NVL(SUM(NVL(t.settle_amount, 0) *
                         b.APPLIED_PLUS_MINUS_FLAG),
                     0) + D_AMOUNT_E)
            INTO V_AMOUNT_E
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             and t.account_id = ACCOUNT_ROW.account_id
             AND t.bill_type_id = b.bill_type_id
             AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
              AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             --AND b.Can_Applied_Flag = 'Y'
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

          --计算本期到款余额  F = A + D - E
          V_AMOUNT_F := V_AMOUNT_A + V_AMOUNT_D - V_AMOUNT_E;

          --计算冻结金额
          V_AMOUNT_G := 0;

          --计算应收账款余额
          V_AMOUNT_I := -1 * V_AMOUNT_F;
          --上一期中是否存在折让余额
          SELECT COUNT(*)
            INTO V_COUNT7
            FROM T_AR_SOA_ORDER_DIS_LINES b   --确认式往来对账单折让R扣款行表
           WHERE b.HEADER_ID = (SELECT MAX(t.HEADER_ID)
            FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             and t.account_id = ACCOUNT_ROW.account_id
             AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
             AND t.SOA_END_DATE = V_LAST_END_DATE
             AND nvl(t.confirm_flag,'N') <> 'E')
             AND b.SALES_MAIN_ID = ITEMCLASS_ROW.ITEM_CLASS_ID
              AND NVL(b.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE;

          if (V_COUNT7 = 0) THEN
            --add huanghb12  按品类计算总期折让余额
            --检查是否存在对账头，如果存在对账头，但是(V_COUNT7 = 0)，说明行中没有对应的转款类型的单据
            SELECT COUNT(*)
             INTO V_COUNT7__
            FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
             AND t.SOA_END_DATE = V_LAST_END_DATE
             AND nvl(t.confirm_flag,'N') <> 'E';
            --如果存在对账头，但是(V_COUNT7 = 0)，说明行中没有对应的转款类型的单据
            IF (V_COUNT7__ > 0) THEN
              --则期初余额为0
              V_AMOUNT_J := 0;
            ELSIF (V_COUNT7__ = 0) THEN
              SELECT COUNT(*)
                INTO V_COUNT7_
                FROM T_AR_SOA_ORDER_DIS_LINES b
               WHERE b.HEADER_ID = (SELECT MAX(t.HEADER_ID)
                FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
                 AND t.customer_id = ACCOUNT_ROW.customer_id
                 --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                 and t.account_id = ACCOUNT_ROW.account_id
                 --AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
                 AND t.SOA_END_DATE = V_LAST_END_DATE
                 AND nvl(t.confirm_flag,'N') <> 'E')
                 AND b.SALES_MAIN_ID = ITEMCLASS_ROW.ITEM_CLASS_ID
                 AND NVL(b.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE;
                 
              if (V_COUNT7_ = 0) then
                 --按品类计算总期折让余额，折让余额就是统计销售表中的扣率折让单和反向扣率折让单的总和
                SELECT NVL(SUM(NVL(t.settle_amount, 0) *
                               b.APPLIED_PLUS_MINUS_FLAG),
                           0)
                  INTO V_AMOUNT_J2
                  FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
                 WHERE t.entity_id = ACCOUNT_ROW.entity_id
                   AND t.customer_id = ACCOUNT_ROW.customer_id
                   --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                   and t.account_id = ACCOUNT_ROW.account_id
                   AND t.bill_type_id = b.bill_type_id
                   AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
                    AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                   --AND b.Can_Applied_Flag = 'Y'
                   AND t.so_status <> '10'
                   AND t.BIZ_SRC_BILL_TYPE_CODE in ('1009', '1010')
                   --AND t.SO_DATE >= V_LAST_START_DATE
                   AND t.SO_DATE < V_PERIOD_START_DATE;

                  --按品类计算总期核销折让金额，核销折让金额就是销售单上的折扣金额，这个折扣金额就是消耗上面的扣率折让单总金额中的金额
                SELECT NVL(SUM(NVL(t.discount_amount, 0) *
                               b.APPLIED_PLUS_MINUS_FLAG),
                           0)
                  INTO V_AMOUNT_L2
                  FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
                 WHERE t.entity_id = ACCOUNT_ROW.entity_id
                   AND t.customer_id = ACCOUNT_ROW.customer_id
                   --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                   and t.account_id = ACCOUNT_ROW.account_id
                   AND t.bill_type_id = b.bill_type_id
                   AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
                    AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                   --AND b.Can_Applied_Flag = 'Y'
                   AND t.so_status <> '10'
                   AND t.BIZ_SRC_BILL_TYPE_CODE in
                       ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                        '1008')
                   --AND t.so_date >= V_PERIOD_START_DATE
                   AND t.so_date < V_PERIOD_START_DATE;
                   
                --计算总期折让余额
                V_AMOUNT_J := V_AMOUNT_J2 - V_AMOUNT_L2;
              
              elsif(V_COUNT7_ != 0) then
               --获取已存在的总期折让余额
               BEGIN
                --按品类获取期初折让余额
                SELECT NVL(b.CURRENT_AMOUNT,0)
                  INTO V_AMOUNT_J
                  FROM T_AR_SOA_ORDER_DIS_LINES b
                 WHERE b.HEADER_ID = (SELECT MAX(t.HEADER_ID)
                  FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
                   AND t.customer_id = ACCOUNT_ROW.customer_id
                   --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                   and t.account_id = ACCOUNT_ROW.account_id
                   --AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
                   AND t.SOA_END_DATE = V_LAST_END_DATE
                   AND nvl(t.confirm_flag,'N') <> 'E')
                   AND b.SALES_MAIN_ID = ITEMCLASS_ROW.ITEM_CLASS_ID
                    AND NVL(b.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE;
                EXCEPTION
                  WHEN OTHERS THEN
                    V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                       SQLCODE,
                                                       '获取期初折让余额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                       substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                    P_RESULT := V_RESULT;
                    --RAISE V_ERR_EXCEPT;
                    V_AMOUNT_J := 0;
                    CONTINUE;
                END;
              end if;
              --end huanghb12
            END IF;
          --如果上期存在对账信息
          else
            BEGIN
            --按品类获取期初折让余额
            SELECT NVL(b.CURRENT_AMOUNT,0)
              INTO V_AMOUNT_J
              FROM T_AR_SOA_ORDER_DIS_LINES b
             WHERE b.HEADER_ID = (SELECT MAX(t.HEADER_ID)
              FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               and t.account_id = ACCOUNT_ROW.account_id
               AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
               AND t.SOA_END_DATE = V_LAST_END_DATE
               AND nvl(t.confirm_flag,'N') <> 'E')
               AND b.SALES_MAIN_ID = ITEMCLASS_ROW.ITEM_CLASS_ID
                AND NVL(b.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE;
            EXCEPTION
              WHEN OTHERS THEN
                V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                   SQLCODE,
                                                   '获取期初折让余额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                   substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                P_RESULT := V_RESULT;
                --RAISE V_ERR_EXCEPT;
                V_AMOUNT_J := 0;
                CONTINUE;
            END;
          end if;

          --按品类判断上期是否存在修改折让单据原始数据
            SELECT COUNT(*)
              INTO V_COUNT17
              FROM cims.t_so_header t,cims.T_AR_SOA_DIS_ORDER_HIS b
             WHERE t.so_num = b.order_number AND t.discount_amount <> b.dis_amount
               AND t.Entity_Id = ACCOUNT_ROW.Entity_Id
               AND t.Customer_Id = ACCOUNT_ROW.Customer_Id
               --AND t.Sales_Center_Id = V_SALES_CENTER_ID
               and t.account_id = ACCOUNT_ROW.account_id
               AND t.SALES_MAIN_TYPE = V_CLASS_CODE
                AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
              -- AND t.SO_DATE >= V_LAST_START_DATE  --去掉日期限制 guibr 存在跨两月结算单据
               AND t.SO_DATE < V_PERIOD_START_DATE
               AND t.settle_date >= V_PERIOD_START_DATE
                 AND t.settle_date < V_PERIOD_END_DATE2
               AND nvl(b.diff_update_flag,'N') <> 'E';

             if (V_COUNT17 > 0) THEN
                SELECT (NVL(SUM(NVL(t.discount_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0) - NVL(SUM(NVL(b.dis_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0))
                  INTO D_AMOUNT_K
                  FROM cims.t_so_header t,cims.T_AR_SOA_DIS_ORDER_HIS b ,cims.T_SO_TYPE_EXTEND e
                 WHERE t.so_num = b.order_number AND t.bill_type_id = e.bill_type_id
                   AND t.discount_amount <> b.dis_amount
                   AND t.Entity_Id = ACCOUNT_ROW.Entity_Id
                   AND t.Customer_Id = ACCOUNT_ROW.Customer_Id
                   --AND t.Sales_Center_Id = V_SALES_CENTER_ID
                   and t.account_id = ACCOUNT_ROW.account_id
                   AND t.SALES_MAIN_TYPE = V_CLASS_CODE
                    AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                 --  AND t.SO_DATE >= V_LAST_START_DATE --去掉日期限制 guibr 存在跨两月结算单据
                   AND t.SO_DATE < V_PERIOD_START_DATE
                   AND t.settle_date >= V_PERIOD_START_DATE
                     AND t.settle_date < V_PERIOD_END_DATE2
                   AND nvl(b.diff_update_flag,'N') <> 'E';
             else
               D_AMOUNT_K := 0;
             end if;

          --按品类计算本期折让金额
          SELECT (NVL(SUM(NVL(t.settle_amount, 0) *
                         b.APPLIED_PLUS_MINUS_FLAG),
                     0) + D_AMOUNT_K)
            INTO V_AMOUNT_K
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             and t.account_id = ACCOUNT_ROW.account_id
             AND t.bill_type_id = b.bill_type_id
             AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
              AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             --AND b.Can_Applied_Flag = 'Y'
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in ('1009', '1010')
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

          --按品类计算核销折让金额
          SELECT (NVL(SUM(NVL(t.discount_amount, 0) *
                         b.APPLIED_PLUS_MINUS_FLAG),
                     0) + D_AMOUNT_L)
            INTO V_AMOUNT_L
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             and t.account_id = ACCOUNT_ROW.account_id
             AND t.bill_type_id = b.bill_type_id
             AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
              AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             --AND b.Can_Applied_Flag = 'Y'
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

          --计算折让余额
          V_AMOUNT_H := V_AMOUNT_J + V_AMOUNT_K - V_AMOUNT_L;

          --按品类计算本期未解付金额
          /*
          SELECT NVL(SUM(NVL(t.UN_SOLUTION_AMOUNT, 0)), 0)
            INTO V_AMOUNT_U
            FROM V_AR_CASH_RECEIPT_UN_SOLU t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_code = ACCOUNT_ROW.customer_code
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
             AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
             AND t.REVIEWED_DATE >= V_PERIOD_START_DATE
             AND t.REVIEWED_DATE < V_PERIOD_END_DATE2;*/

             -- add by tangfeng
             select sum(un_solution_amount)
             INTO V_AMOUNT_U
             FROM(
               select nvl(l.amount,0) - nvl (acc.solution_pay_amount, 0) un_solution_amount
               from cims.t_ar_cash_receipt_headers h
               left join cims.t_ar_cash_receipt_lines l on l.cash_receipt_id = h.cash_receipt_id
               left join (SELECT p.CASH_RECEIPT_LINES_ID, nvl(SUM(p.SOLUTION_PAY_AMOUNT), 0) AS SOLUTION_PAY_AMOUNT
                       FROM cims.t_ar_acce_solu_pay p
                       WHERE p.solution_pay_status in ('2', '3') and p.solution_pay_time < V_PERIOD_END_DATE2
                       GROUP BY p.CASH_RECEIPT_LINES_ID) acc
                    on acc.cash_receipt_lines_id = l.cash_receipt_lines_id
               left join cims.t_ar_receipt_methods m on h.receipt_method_id = m.receipt_method_id
               where h.receipt_status_id not in (0,1,2,10,12,19) and m.receipt_type = '3'
               and h.entity_id = ACCOUNT_ROW.entity_id
               AND h.customer_code = ACCOUNT_ROW.customer_code
               AND h.account_id = ACCOUNT_ROW.account_id
               AND l.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
                AND NVL(h.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
               AND h.REVIEWED_DATE < V_PERIOD_END_DATE2);

             /**select sum(un_solution_amount)
             INTO V_AMOUNT_U
             FROM(
             select nvl(l.amount,0) - sum (nvl (acc.solution_pay_amount, 0)) un_solution_amount
             from cims.t_ar_cash_receipt_headers h left join cims.t_ar_cash_receipt_lines l on l.cash_receipt_id = h.cash_receipt_id
             left join cims.t_ar_acce_solu_pay acc on acc.cash_receipt_lines_id = l.cash_receipt_lines_id and acc.solution_pay_status in ('2', '3') and acc.solution_pay_time < V_PERIOD_END_DATE2
             left join cims.t_ar_receipt_methods m on h.receipt_method_id = m.receipt_method_id
             where h.receipt_status_id not in (0,1,2,10,12,19) and m.receipt_type = '3'
             and h.entity_id = ACCOUNT_ROW.entity_id
             AND h.customer_code = ACCOUNT_ROW.customer_code
             AND h.account_id = ACCOUNT_ROW.account_id
             AND l.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
             group by l.cash_receipt_lines_id,l.amount);**/
             
         /**     
            --计算未开票金额
           SELECT  
                NVL(SUM(NVL(t.settle_amount, 0) *
                            b.APPLIED_PLUS_MINUS_FLAG),
                       0)
            INTO V_AMOUNT_TRX1
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
             AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             AND t.bill_type_id = b.bill_type_id
             AND t.so_status <> '10'
             AND t.invoice_num_list is null
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

           SELECT  
               NVL(SUM(NVL(t.settle_amount, 0) *
                            b.APPLIED_PLUS_MINUS_FLAG),
                0)
            INTO V_AMOUNT_TRX2
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
             AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             AND t.bill_type_id = b.bill_type_id
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2
             AND t.invoice_num_list is not null
             AND t.invoice_date >=V_PERIOD_END_DATE2;
             
            V_AMOUNT_TRX1 := V_AMOUNT_TRX1 + V_AMOUNT_TRX2;   **/ 
             
           --计算本期末冻结保证金额度，冻结保证金会使得一部分到款冻结不能，
            SELECT 
                NVL(SUM(NVL(D.APPROVAL_AMOUNT, 0)),0) 
            INTO V_AMOUNT_LOCC
            FROM  T_CREDIT_DELAYPAY D 
            WHERE DELAYPAY_TYPE =10     --冻结保证金
              AND BILL_STATUS = 3       --已审批
              AND D.DUE_TIME IS NULL    --没过期
              AND V_DISCOUNT_TYPE = V_DISCOUNT_TYPE_COMMON
              AND d.entity_id = ACCOUNT_ROW.entity_id
              AND d.customer_id = ACCOUNT_ROW.customer_id
              AND d.account_id = ACCOUNT_ROW.account_id
              AND d.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
              --AND D.BILL_DATE >= V_PERIOD_START_DATE   
              AND D.BILL_DATE < V_PERIOD_END_DATE2;
              
          --遍历配置表中，用户配置的对账类型Order_Type  --1-到款结算 2-折让扣款 3-NC对账单 4-调节式
          FOR CONF_ROW IN C_ACCOUNT_CONF LOOP
            V_ORDER_TYPE := CONF_ROW.Order_Type;
            --配置了到款结算
            if (V_ORDER_TYPE = '1' /*AND (V_COUNT4 > 0 OR V_COUNT5 > 0)*/) THEN
              /*SELECT COUNT(*)
               INTO V_COUNT
               FROM T_AR_STATEMENT_ACC_HISTORY t
              WHERE t.entity_id = CONF_ROW.entity_id
                AND t.customer_id = CONF_ROW.customer_id
                AND t.sales_center_id = CONF_ROW.sales_center_id
                AND t.count_period = V_PERIOD_DATE
                AND t.order_type = V_ORDER_TYPE;

              if (V_COUNT > 0) THEN
                 V_RESULT := '传入的客户或者中心本期已经计算过往来对账单信息，对账期间：【' || V_PERIOD_DATE
                 || '】，对账单类型：【' || V_ORDER_TYPE || '】';
                 P_RESULT := V_RESULT;
                 --RAISE V_ERR_EXCEPT;

               else*/
              BEGIN
                --插入确认式往来对账单到款结算行
                INSERT INTO T_AR_SOA_ORDER_RECEIPT_LINES
                  (RECEIPT_LINE_ID, --到款行ID
                   HEADER_ID, --对账单头ID
                   SOA_TYPE, --对账类型
                   PERIOD_AMOUNT, --期初余额
                   RECEIPT_AMOUNT, --本期累计到款
                   SALES_AMOUNT, --到款提货金额
                   CURRENT_AMOUNT, --本期到款余额
                   RECEIVABLE_AMOUNT, --应收账款金额
                   CUS_RECEIVABLE_AMOUNT, --客户确认应收账款金额
                   DIFFERENACE_AMOUNT, --应收账款差异金额
                   COMMENTS, --备注
                   ENTITY_ID, --主体ID
                   CREATED_BY, --创建人
                   CREATION_DATE, --创建日期
                   LAST_UPDATED_BY, --最后更新人
                   LAST_UPDATE_DATE, --最后更新日期
                   SOA_COUNT_BATCH_ID,
                   SALES_MAIN_ID,
                   SALES_MAIN_NAME,
                   DIFF_SALES_AMOUNT,
                   UN_SOLUTION_AMOUNT,
                   DISCOUNT_TYPE,
                   DEPOSIT_LOCK_AMOUNT,
                   NOT_INVOICE_AMOUNT
                   )
                VALUES
                  (S_AR_SOA_ORDER_LINES.NEXTVAL,
                   V_SOA_COUNT_BATCH_ID,
                   V_ORDER_TYPE, --'RECEIPT_TYPE', --到款结算
                   V_AMOUNT_A, --期初余额
                   V_AMOUNT_D, --本期累计到款
                   V_AMOUNT_E, --到款提货金额
                   V_AMOUNT_F, --本期到款余额
                   V_AMOUNT_I + nvl(V_AMOUNT_U,0), --应收账款金额
                   NULL, --客户确认应收账款金额
                   NULL, --应收账款差异金额
                   NULL, --备注
                   CONF_ROW.ENTITY_ID,
                   NULL,
                   SYSDATE,
                   NULL,
                   NULL,
                   V_SOA_COUNT_BATCH_ID,
                   ITEMCLASS_ROW.ITEM_CLASS_ID,
                   ITEMCLASS_ROW.CLASS_CODE,
                   D_AMOUNT_E,
                   V_AMOUNT_U,
                   V_DISCOUNT_TYPE,
                   V_AMOUNT_LOCC,
                   V_AMOUNT_TRX1
                   );

              EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                     SQLCODE,
                                                     '插入确认式往来对账单到款结算行失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
              END;

            BEGIN
                V_RESULT := '插入到款单数据到到款历史表';
                INSERT INTO T_AR_SOA_CUST_RECEIPT_HIS
                  (SOA_COUNT_BATCH_ID, --对账单批次ID
                   SOURCE_ORDER_TYPE,  --来源单据类型
                   SOA_ORDER_TYPE,     --对账单类型（余额确认式、借贷调节式）
                   HEADER_ID,          --收款单ID
                   ORDER_NUMBER,       --收款单号
                   ORDERED_DATE,       --单据日期
                   ACCOUNT_DATE,       --结算日期
                   FINANCE_CHECK_DATE, --财务审核日期
                   CUSTOMER_ID,        --客户ID
                   CASH_DATE,          --票据日期
                   CASH_CODE,          --票据号
                   DISCOUNT_TYPE_ID,   --折扣ID
                   RECEIPT_METHOD_ID,  --收款方法ID
                   RECEIPT_AMOUNT,     --收款金额
                   ENTITY_ID,          --主体ID
                   SALES_CENTER_ID,    --中心ID
                   STATUS,             --状态
                   BI_LAST_UPDATE_DATE, --BI日期
                   SOA_SALES_CENTER_ID, --对账单中心ID
                   SOA_ORDER_HEAD_ID,   --对账单ID
                   CREATION_DATE,       --创建日期
                   difference_AMOUNT,   --差异金额
                   difference_DIS_AMOUNT,   --差异折让金额
                   SOA_PERIOD_DATE,     --对账单周期
                   SOA_BEGIN_DATE,      --对账单开始日期
                   SOA_END_DATE,        --对账单结束日期
                   HISTORY_ID,          --历史ID，历史表主键
                   DISCOUNT_TYPE
                   )
                  SELECT V_SOA_COUNT_BATCH_ID,
                         '到款单',
                         V_ORDER_TYPE,
                         t.CASH_RECEIPT_ID,
                         t.CASH_RECEIPT_CODE,
                         t.CASH_RECEIPT_DATE,
                         null,
                         null,
                         ACCOUNT_ROW.CUSTOMER_ID,
                         t.CASH_DATE,
                         t.CASH_CODE,
                         null,                        --DISCOUNT_TYPE_ID,
                         t.RECEIPT_METHOD_ID,
                         NVL(t.AMOUNT, 0),
                         ACCOUNT_ROW.ENTITY_ID,
                         ACCOUNT_ROW.SALES_CENTER_ID,
                         '',                        --STATUS,
                         null,
                         null,
                         V_SOA_COUNT_BATCH_ID,
                         SYSDATE,
                         null,
                         null,
                         V_PERIOD_DATE,
                         V_PERIOD_START_DATE,
                         V_PERIOD_END_DATE,
                         S_AR_SOA_CUST_RECEIPT_HIS.NEXTVAL,
                         V_DISCOUNT_TYPE
                      FROM v_ar_cash_receipt_header_lines t
                     WHERE t.entity_id = ACCOUNT_ROW.entity_id
                       AND t.customer_id = ACCOUNT_ROW.customer_id
                       --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                       and t.account_id = ACCOUNT_ROW.account_id
                       AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
                       AND t.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
                       AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                       AND t.REVIEWED_DATE >= V_PERIOD_START_DATE
                       AND t.REVIEWED_DATE < V_PERIOD_END_DATE2;
              EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                     SQLCODE,
                                                     '插入到款单数据到到款历史表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
              END;

            BEGIN
                V_RESULT := '插入本期销售单数据到销售历史表';
                INSERT INTO T_AR_SOA_SO_ORDER_HIS
                  (SOA_COUNT_BATCH_ID,
                   SOA_SALES_CENTER_ID,
                   SOA_ORDER_TYPE,
                   SOA_ORDER_HEAD_ID,
                   SOA_ORDER_NUMBER,
                   SOURCE_ORDER_TYPE,
                   HEADER_ID,
                   LINE_ID,
                   CANCEL_QUANTITY,
                   ORDER_TYPE_ID,
                   ENTITY_ID,
                   SALES_CENTER_ID,
                   CUSTOMER_ID,
                   DISCOUNT_TYPE_ID,
                   ORDER_NUMBER,
                   ORDERED_DATE,
                   ACCOUNT_DATE,
                   PRESALES_FLAG,
                   ACCOUNT_FLAG,
                   MATERIAL_ID,
                   MATERIAL_CODE,
                   QUANTITY,
                   LIST_PRICE,
                   STATIC_DISCOUNT_RATE,
                   ORDERED_DISCOUNT_RATE,
                   PRESALES_LIST_PRICE,
                   DYNAMIC_DISCOUNT_RATE,
                   DOWN_PRICE,
                   INS_DEC,
                   LIST_AMOUNT,
                   AMOUNT,
                   PRE_DIS_AMOUNT,
                   MIDDLE_DISCOUNT_AMOUNT,
                   PRESALES_AMOUNT,
                   DIS_AMOUNT,
                   ORDERED_DISCOUNT_AMOUNT,
                   INSTANT_DIS_AMOUNT,
                   BI_LAST_UPDATE_DATE,
                   difference_AMOUNT,
                   difference_DIS_AMOUNT,
                   SOA_PERIOD_DATE,
                   SOA_BEGIN_DATE,
                   SOA_END_DATE,
                   HISTORY_ID,
                   CREATION_DATE,
                   DISCOUNT_TYPE,
                   RAW_SRC_BILL_NUM
                   )
                  SELECT V_SOA_COUNT_BATCH_ID,
                         null,
                         V_ORDER_TYPE,
                         V_SOA_COUNT_BATCH_ID,
                         V_ORDER_NUMBER,
                         '销售单',
                         t.SO_HEADER_ID,
                         null,  --销售单行ID
                         null,  --红冲数量
                         t.BILL_TYPE_ID,
                         t.ENTITY_ID,
                         t.SALES_CENTER_ID,
                         t.CUSTOMER_ID,
                         null,                       --SDA.DISCOUNT_MODE,
                         t.SO_NUM,
                         t.SO_DATE,
                         t.SETTLE_DATE,          --结算日期
                         null,       --SDA.PRESALES_FLAG,
                         t.SETTLE_FLAG,          --结算标识
                         null,
                         null,
                         null,                   --数量
                         null,                   --列表价
                         null,       --固定折扣,
                         null,       --月返
                         null,       --SDA.PRESALES_LIST_PRICE,
                         null,       --折扣率
                         null,       --SDA.DOWN_PRICE,
                         null,       --SDA.INS_DEC,
                         t.LIST_AMOUNT,     --列表总金额
                         t.SETTLE_AMOUNT,   --结算总金额
                         null,              --PRE_DIS_AMOUNT,
                         null,   --中间折扣金额
                         null,
                         t.DISCOUNT_AMOUNT,
                         null,              --月返金额
                         null,              --INSTANT_DIS_AMOUNT,
                         null,
                         0,
                         0,
                         V_PERIOD_DATE,
                         V_PERIOD_START_DATE,
                         V_PERIOD_END_DATE,
                         S_AR_SOA_SO_ORDER_HIS.NEXTVAL,
                         SYSDATE,
                         V_DISCOUNT_TYPE,
                         (case when t.RAW_SRC_TYPE ='02' then t.RAW_SRC_BILL_NUM
                               when t.ORIGIN_ORIGIN_TYPE ='02' then t.ORIGIN_ORIGIN_ORDER_CODE
                               else null  end) RAW_SRC_BILL_NUM
                      FROM T_SO_HEADER t
                     WHERE t.entity_id = ACCOUNT_ROW.entity_id
                       AND t.customer_id = ACCOUNT_ROW.customer_id
                       --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                       AND t.account_id = ACCOUNT_ROW.account_id
                       AND t.so_status <> '10'
                       AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
                       AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                       AND t.BIZ_SRC_BILL_TYPE_CODE in
                           ('1001', '1002', '1003', '1004', '1005', '1006', '1007', '1008')
                       AND t.so_date >= V_PERIOD_START_DATE
                       AND t.so_date < V_PERIOD_END_DATE2;
                    EXCEPTION
                    WHEN OTHERS THEN
                      V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                         SQLCODE,
                                                         '插入本期销售单数据到销售历史表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                         substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                      P_RESULT := V_RESULT;
                      --RAISE V_ERR_EXCEPT;
                      CONTINUE;
                      END;

            --插入数据到明细表
            BEGIN
                V_RESULT := '插入本期到款单数据到明细表';
              --插入本期到款单数据到明细表
              INSERT INTO T_AR_SOA_ORDER_DETAILS
               (SOA_COUNT_BATCH_ID ,   --对账单批次ID
                SOURCE_ORDER_TYPE ,   --来源单据类型：到款单、销售单、返利单
                SOA_ORDER_TYPE ,   --对账单类型
                SOA_ORDER_HEAD_ID ,   --对账单ID
                SOA_ORDER_NUMBER ,   --对账单号
                HEADER_ID ,   --单据ID
                ENTITY_ID ,   --主体ID
                SALES_YEAR_ID ,   --销售年度
                ORDER_TYPE ,   --单据类型
                SALES_REGION_ID ,   --经营区域ID
                CUSTOMER_ID ,   --客户ID
                CUSTOMER_CODE ,   --客户编码
                CUSTOMER_NAME ,   --客户名称
                DISCOUNT_TYPE_ID ,   --折扣类型ID
                DISCOUNT_METHOD ,   --折让方法
                SALES_CENTER_ID ,   --营销中心ID
                ORDER_NUMBER ,   --单据编号
                ORDERED_DATE ,   --单据日期
                ACCOUNT_DATE ,   --结算日期
                ACCOUNT_FLAG ,   --结算标志
                ITEM_TYPE ,   --商品大类
                DIS_AMOUNT ,   --折让金额
                INTEND_AMOUNT ,   --含税金额
                AMOUNT ,   --到款金额
                DIFFERENCE_AMOUNT ,   --差异金额
                DIFFERENCE_DIS_AMOUNT ,   --差异折让金额
                SOA_PERIOD_DATE ,   --对账单周期
                SOA_BEGIN_DATE ,   --对账单开始日期
                SOA_END_DATE ,   --对账单结束日期
                HISTORY_ID ,   --历史ID
                DETAILS_ID ,   --明细ID
                DIFF_UPDATE_FLAG ,   --创建的历史差异已更新标志
                SOA_ADJUST_CODE ,   --注释：上期单据在本期调整金额
                CREATION_DATE ,   --录入日期
                REMARKS ,   --备注
                SALES_CENTER_CODE ,   --营销中心编码
                SALES_CENTER_NAME ,   --营销中心名称
                INVOICE_NUM_LIST ,   --发票号串：多个发票号用逗号分隔（,）。
                INVOICE_DATE ,   --发票日期：一张销售单只有一个发票开票日期。
                CASH_CODE ,   --票据号
                CASH_DATE ,   --出票日期
                DUE_DATE ,   --票据到期日期
                LIST_AMOUNT ,   --列表金额
                SETTLE_AMOUNT ,   --结算金额
                DISCOUNT_AMOUNT,    --核销折让金额
                ORDER_TYPE_ID,      --单据类型ID
                SALES_MAIN_ID,      --品类ID
                SALES_MAIN_NAME,    --品类名称
                DISCOUNT_TYPE,
                UN_SOLUTION_AMOUNT --三方承兑未解付金额
                )
              SELECT
                 V_SOA_COUNT_BATCH_ID,
                 '到款单据',
                 V_ORDER_TYPE,
                 V_SOA_COUNT_BATCH_ID,
                 V_ORDER_NUMBER,
                 t.CASH_RECEIPT_ID,
                 t.ENTITY_ID,
                 null,
                 (SELECT distinct b.RECEIPT_METHOD_NAME
                 FROM T_AR_RECEIPT_METHODS b
                 WHERE b.RECEIPT_METHOD_ID = t.RECEIPT_METHOD_ID),
                 null,
                 t.CUSTOMER_ID,
                 t.CUSTOMER_CODE,
                 t.CUSTOMER_NAME,
                 null,
                 null,
                 t.SALES_CENTER_ID,
                 t.CASH_RECEIPT_CODE,
                 t.CASH_RECEIPT_DATE,
                 null,
                 null,
                 null,
                 null,
                 null,
                 t.AMOUNT,
                 null,
                 null,
                 V_PERIOD_DATE,
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 /*(SELECT t.HISTORY_ID
                FROM T_AR_SOA_CUST_RECEIPT_HIS t
               WHERE t.ORDER_NUMBER = RECEIPT_ROW.CASH_RECEIPT_CODE
                 AND t.HEADER_ID = RECEIPT_ROW.CASH_RECEIPT_ID),*/
                 null,
                 S_AR_SOA_ORDER_DETAILS.NEXTVAL,
                 null,
                 null,
                 sysdate,
                 --null,--备注
                 t.remaek,--备注
                 ACCOUNT_ROW.SALES_CENTER_CODE,
                 ACCOUNT_ROW.SALES_CENTER_NAME,
                 null,
                 null,
                 t.CASH_CODE,
                 t.CASH_DATE,
                 t.DUE_DATE,
                 null,
                 null,
                 null,
                 t.RECEIPT_METHOD_ID,
                 ITEMCLASS_ROW.ITEM_CLASS_ID,
                 ITEMCLASS_ROW.CLASS_CODE,
                 V_DISCOUNT_TYPE,
                 /*NVL((SELECT a.UN_SOLUTION_AMOUNT
                 FROM V_AR_CASH_RECEIPT_UN_SOLU a
                 WHERE a.cash_receipt_id = t.cash_receipt_id),0)*/
                 (select nvl(l.amount,0) - sum (nvl (acc.solution_pay_amount, 0))
                 from cims.t_ar_cash_receipt_headers h left join cims.t_ar_cash_receipt_lines l on l.cash_receipt_id = h.cash_receipt_id
                 left join cims.t_ar_acce_solu_pay acc on acc.cash_receipt_lines_id = l.cash_receipt_lines_id and acc.solution_pay_status in ('2', '3') and acc.solution_pay_time < V_PERIOD_END_DATE2
                 left join cims.t_ar_receipt_methods m on h.receipt_method_id = m.receipt_method_id
                 where m.receipt_type = '3'
                 and l.cash_receipt_id = t.cash_receipt_id
                 group by l.cash_receipt_lines_id,l.amount)
                FROM v_ar_cash_receipt_header_lines t
               WHERE t.entity_id = ACCOUNT_ROW.entity_id
                 AND t.customer_id = ACCOUNT_ROW.customer_id
                 --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                 AND t.account_id = ACCOUNT_ROW.account_id
                 AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
                 AND t.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
                  AND NVL(t.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                 AND t.REVIEWED_DATE >= V_PERIOD_START_DATE
                 AND t.REVIEWED_DATE < V_PERIOD_END_DATE2;
                 EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                     SQLCODE,
                                                     '插入本期到款单数据到明细表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
                  END;


              BEGIN
                V_RESULT := '插入本期三方承兑未解付数据到明细表';
              --插入本期三方承兑未解付数据到明细表
              INSERT INTO T_AR_SOA_ORDER_DETAILS
               (SOA_COUNT_BATCH_ID ,   --对账单批次ID
                SOURCE_ORDER_TYPE ,   --来源单据类型：到款未解付
                SOA_ORDER_TYPE ,   --对账单类型
                SOA_ORDER_HEAD_ID ,   --对账单ID
                SOA_ORDER_NUMBER ,   --对账单号
                HEADER_ID ,   --单据ID
                ENTITY_ID ,   --主体ID
                SALES_YEAR_ID ,   --销售年度
                ORDER_TYPE ,   --单据类型
                SALES_REGION_ID ,   --经营区域ID
                CUSTOMER_ID ,   --客户ID
                CUSTOMER_CODE ,   --客户编码
                CUSTOMER_NAME ,   --客户名称
                DISCOUNT_TYPE_ID ,   --折扣类型ID
                DISCOUNT_METHOD ,   --折让方法
                SALES_CENTER_ID ,   --营销中心ID
                ORDER_NUMBER ,   --单据编号
                ORDERED_DATE ,   --单据日期
                ACCOUNT_DATE ,   --结算日期
                ACCOUNT_FLAG ,   --结算标志
                ITEM_TYPE ,   --商品大类
                DIS_AMOUNT ,   --折让金额
                INTEND_AMOUNT ,   --含税金额
                AMOUNT ,   --到款金额
                DIFFERENCE_AMOUNT ,   --差异金额
                DIFFERENCE_DIS_AMOUNT ,   --差异折让金额
                SOA_PERIOD_DATE ,   --对账单周期
                SOA_BEGIN_DATE ,   --对账单开始日期
                SOA_END_DATE ,   --对账单结束日期
                HISTORY_ID ,   --历史ID
                DETAILS_ID ,   --明细ID
                DIFF_UPDATE_FLAG ,   --创建的历史差异已更新标志
                SOA_ADJUST_CODE ,   --注释：上期单据在本期调整金额
                CREATION_DATE ,   --录入日期
                REMARKS ,   --备注
                SALES_CENTER_CODE ,   --营销中心编码
                SALES_CENTER_NAME ,   --营销中心名称
                INVOICE_NUM_LIST ,   --发票号串：多个发票号用逗号分隔（,）。
                INVOICE_DATE ,   --发票日期：一张销售单只有一个发票开票日期。
                CASH_CODE ,   --票据号
                CASH_DATE ,   --出票日期
                DUE_DATE ,   --票据到期日期
                LIST_AMOUNT ,   --列表金额
                SETTLE_AMOUNT ,   --结算金额
                DISCOUNT_AMOUNT,    --核销折让金额
                ORDER_TYPE_ID,      --单据类型ID
                SALES_MAIN_ID,      --品类ID
                SALES_MAIN_NAME,    --品类名称
                UN_SOLUTION_AMOUNT, --三方承兑未解付金额
                DISCOUNT_TYPE
                )
              SELECT
                 V_SOA_COUNT_BATCH_ID,
                 '到款未解付',
                 V_ORDER_TYPE,
                 V_SOA_COUNT_BATCH_ID,
                 V_ORDER_NUMBER,
                 t.CASH_RECEIPT_ID,
                 t.ENTITY_ID,
                 null,
                 t.RECEIPT_METHOD_NAME,
                 null,
                 t.CUSTOMER_ID,
                 t.CUSTOMER_CODE,
                 t.CUSTOMER_NAME,
                 null,
                 null,
                 t.SALES_CENTER_ID,
                 t.CASH_RECEIPT_CODE,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 V_PERIOD_DATE,
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 /*(SELECT t.HISTORY_ID
                FROM T_AR_SOA_CUST_RECEIPT_HIS t
               WHERE t.ORDER_NUMBER = RECEIPT_ROW.CASH_RECEIPT_CODE
                 AND t.HEADER_ID = RECEIPT_ROW.CASH_RECEIPT_ID),*/
                 null,
                 S_AR_SOA_ORDER_DETAILS.NEXTVAL,
                 null,
                 null,
                 sysdate,
                 null,--备注
                 ACCOUNT_ROW.SALES_CENTER_CODE,
                 ACCOUNT_ROW.SALES_CENTER_NAME,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 t.RECEIPT_METHOD_ID,
                 ITEMCLASS_ROW.ITEM_CLASS_ID,
                 ITEMCLASS_ROW.CLASS_CODE,
                 un_solution_amount,
                 V_DISCOUNT_TYPE
                 from (select h.entity_id,h.cash_receipt_id,l.cash_receipt_lines_id,h.receipt_method_id,m.receipt_method_name,
                 h.customer_id,h.customer_code,h.customer_name,h.sales_center_id,h.cash_receipt_code,
                 l.amount,sum (nvl (acc.solution_pay_amount, 0))solution_amount, nvl(l.amount,0) - sum (nvl (acc.solution_pay_amount, 0)) un_solution_amount
                 from cims.t_ar_cash_receipt_headers h left join cims.t_ar_cash_receipt_lines l on l.cash_receipt_id = h.cash_receipt_id
                 left join cims.t_ar_acce_solu_pay acc on acc.cash_receipt_lines_id = l.cash_receipt_lines_id and acc.solution_pay_status in ('2', '3') and acc.solution_pay_time < V_PERIOD_END_DATE2
                 left join cims.t_ar_receipt_methods m on h.receipt_method_id = m.receipt_method_id
                 where h.receipt_status_id not in (0,1,2,10,12,19) and m.receipt_type = '3'
                 and h.reviewed_date < V_PERIOD_START_DATE
                 and h.entity_id = ACCOUNT_ROW.entity_id
                 AND h.customer_code = ACCOUNT_ROW.customer_code
                 AND l.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
                  AND NVL(h.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                 AND h.account_id = ACCOUNT_ROW.account_id
                 group by h.entity_id,h.cash_receipt_id,l.cash_receipt_lines_id,h.receipt_method_id,m.receipt_method_name,
                 h.customer_id,h.customer_code,h.customer_name,h.sales_center_id,h.cash_receipt_code,l.cash_receipt_lines_id,l.amount) t
                 ;

                 EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                     SQLCODE,
                                                     '插入本期到款未解付数据到明细表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
                  END;


            BEGIN
                V_RESULT := '插入本期销售单数据到明细表';
              --插入本期销售单数据到明细表
              INSERT INTO T_AR_SOA_ORDER_DETAILS
               (SOA_COUNT_BATCH_ID ,   --对账单批次ID
                SOURCE_ORDER_TYPE ,   --来源单据类型：到款单、销售单、返利单
                SOA_ORDER_TYPE ,   --对账单类型
                SOA_ORDER_HEAD_ID ,   --对账单ID
                SOA_ORDER_NUMBER ,   --对账单号
                HEADER_ID ,   --单据ID
                ENTITY_ID ,   --主体ID
                SALES_YEAR_ID ,   --销售年度
                ORDER_TYPE ,   --单据类型
                SALES_REGION_ID ,   --经营区域ID
                CUSTOMER_ID ,   --客户ID
                CUSTOMER_CODE ,   --客户编码
                CUSTOMER_NAME ,   --客户名称
                DISCOUNT_TYPE_ID ,   --折扣类型ID
                DISCOUNT_METHOD ,   --折让方法
                SALES_CENTER_ID ,   --营销中心ID
                ORDER_NUMBER ,   --单据编号
                ORDERED_DATE ,   --单据日期
                ACCOUNT_DATE ,   --结算日期
                ACCOUNT_FLAG ,   --结算标志
                ITEM_TYPE ,   --商品大类
                DIS_AMOUNT ,   --折让金额
                INTEND_AMOUNT ,   --含税金额
                AMOUNT ,   --到款金额
                DIFFERENCE_AMOUNT ,   --差异金额
                DIFFERENCE_DIS_AMOUNT ,   --差异折让金额
                SOA_PERIOD_DATE ,   --对账单周期
                SOA_BEGIN_DATE ,   --对账单开始日期
                SOA_END_DATE ,   --对账单结束日期
                HISTORY_ID ,   --历史ID
                DETAILS_ID ,   --明细ID
                DIFF_UPDATE_FLAG ,   --创建的历史差异已更新标志
                SOA_ADJUST_CODE ,   --注释：上期单据在本期调整金额
                CREATION_DATE ,   --录入日期
                REMARKS ,   --备注
                SALES_CENTER_CODE ,   --营销中心编码
                SALES_CENTER_NAME ,   --营销中心名称
                INVOICE_NUM_LIST ,   --发票号串：多个发票号用逗号分隔（,）。
                INVOICE_DATE ,   --发票日期：一张销售单只有一个发票开票日期。
                CASH_CODE ,   --票据号
                CASH_DATE ,   --出票日期
                DUE_DATE ,   --票据到期日期
                LIST_AMOUNT ,   --列表金额
                SETTLE_AMOUNT ,   --结算金额
                DISCOUNT_AMOUNT,    --核销折让金额
                ITEM_MONTH_DISCOUNT_AMOUNT,    --月返金额
                ORDER_TYPE_ID,      --单据类型ID
                SALES_MAIN_ID,      --品类ID
                SALES_MAIN_NAME,    --品类名称
                ITEM_CODE,    --产品编码
                ITEM_NAME,    --产品名称
                ITEM_PRICE,    --产品价格
                ITEM_UOM,    --产品单位
                ITEM_QTY,    --产品数量
                RECEIVED_QTY,    --签收数量
                REVERSAL_QTY,    --已红冲数量
                RETURN_QTY,    --已退回数量
                DISCOUNT_TYPE,
                RAW_SRC_BILL_NUM
                )
              SELECT
                 V_SOA_COUNT_BATCH_ID,
                 '销售单据',
                 V_ORDER_TYPE,
                 V_SOA_COUNT_BATCH_ID,
                 V_ORDER_NUMBER,
                 t.SO_HEADER_ID,
                 t.ENTITY_ID,
                 null,
                 t.BILL_TYPE_NAME,
                 null,
                 t.CUSTOMER_ID,
                 t.CUSTOMER_CODE,
                 t.CUSTOMER_NAME,
                 null,
                 null,
                 t.SALES_CENTER_ID,
                 t.SO_NUM,
                 t.SO_DATE,
                 t.SETTLE_DATE,
                 t.SETTLE_FLAG,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 V_PERIOD_DATE,
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 /*(SELECT t.HISTORY_ID
                FROM T_AR_SOA_SO_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID),*/
                 null,
                 S_AR_SOA_ORDER_DETAILS.NEXTVAL,
                 null,
                 null,
                 sysdate,
                 --null,--备注
                 substrb(t.REMARK, 1, 1000),--备注
                 t.SALES_CENTER_CODE,
                 t.SALES_CENTER_NAME,
                 t.INVOICE_NUM_LIST,
                 t.INVOICE_DATE,
                 null,
                 null,
                 null,
                 ROUND(e.PLUS_MINUS_FLAG * NVL(b.ITEM_LIST_AMOUNT,0),2), --t.LIST_AMOUNT,
                 ROUND(e.PLUS_MINUS_FLAG * NVL(b.ITEM_SETTLE_AMOUNT,0),2), --t.SETTLE_AMOUNT,
                 ROUND(e.PLUS_MINUS_FLAG * NVL(b.DISCOUNT_AMOUNT,0),2), --t.DISCOUNT_AMOUNT,
                 ROUND(e.PLUS_MINUS_FLAG * NVL(b.MONTH_DISCOUNT_AMOUNT,0),2), --ITEM_MONTH_DISCOUNT_AMOUNT
                 t.BILL_TYPE_ID,
                 ITEMCLASS_ROW.ITEM_CLASS_ID,
                 ITEMCLASS_ROW.CLASS_CODE,
                 b.ITEM_CODE,
                 b.ITEM_NAME,
                 b.ITEM_PRICE,
                 b.ITEM_UOM,
                 e.PLUS_MINUS_FLAG * b.ITEM_QTY,
                 b.RECEIVED_QTY,
                 b.REVERSAL_QTY,
                 b.RETURN_QTY,
                 V_DISCOUNT_TYPE,
                (case when t.RAW_SRC_TYPE ='02' then t.RAW_SRC_BILL_NUM
                      when t.ORIGIN_ORIGIN_TYPE ='02' then t.ORIGIN_ORIGIN_ORDER_CODE
                      else null  end) RAW_SRC_BILL_NUM
                  FROM T_SO_HEADER t,T_SO_LINE b,T_SO_TYPE_EXTEND e
                 WHERE t.SO_HEADER_ID = b.SO_HEADER_ID
                   AND t.bill_type_id = e.bill_type_id
                   AND t.entity_id = ACCOUNT_ROW.entity_id
                   AND t.customer_id = ACCOUNT_ROW.customer_id
                   --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                   AND t.account_id = ACCOUNT_ROW.account_id
                   AND t.so_status <> '10'
                   AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
                   AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                   AND t.BIZ_SRC_BILL_TYPE_CODE in
                       ('1001', '1002', '1003', '1004', '1005', '1006', '1007', '1008')
                   AND t.so_date >= V_PERIOD_START_DATE
                   AND t.so_date < V_PERIOD_END_DATE2;
                 EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                     SQLCODE,
                                                     '插入本期销售单数据到明细表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
                  END;
                  
              BEGIN
                  V_RESULT := '插入本期冻结保证金数据到明细表';
              --插入本期销售单数据到明细表
              INSERT INTO T_AR_SOA_ORDER_DETAILS
               (SOA_COUNT_BATCH_ID ,   --对账单批次ID
                SOURCE_ORDER_TYPE ,   --来源单据类型：到款单、销售单、返利单
                SOA_ORDER_TYPE ,   --对账单类型
                SOA_ORDER_HEAD_ID ,   --对账单ID
                SOA_ORDER_NUMBER ,   --对账单号
                HEADER_ID ,   --单据ID
                ENTITY_ID ,   --主体ID
                SALES_YEAR_ID ,   --销售年度
                ORDER_TYPE ,   --单据类型
                SALES_REGION_ID ,   --经营区域ID
                CUSTOMER_ID ,   --客户ID
                CUSTOMER_CODE ,   --客户编码
                CUSTOMER_NAME ,   --客户名称
                DISCOUNT_TYPE_ID ,   --折扣类型ID
                DISCOUNT_METHOD ,   --折让方法
                SALES_CENTER_ID ,   --营销中心ID
                ORDER_NUMBER ,   --单据编号
                ORDERED_DATE ,   --单据日期
                ACCOUNT_DATE ,   --结算日期
                ACCOUNT_FLAG ,   --结算标志
                ITEM_TYPE ,   --商品大类
                DIS_AMOUNT ,   --折让金额
                INTEND_AMOUNT ,   --含税金额
                AMOUNT ,   --到款金额
                DIFFERENCE_AMOUNT ,   --差异金额
                DIFFERENCE_DIS_AMOUNT ,   --差异折让金额
                SOA_PERIOD_DATE ,   --对账单周期
                SOA_BEGIN_DATE ,   --对账单开始日期
                SOA_END_DATE ,   --对账单结束日期
                HISTORY_ID ,   --历史ID
                DETAILS_ID ,   --明细ID
                DIFF_UPDATE_FLAG ,   --创建的历史差异已更新标志
                SOA_ADJUST_CODE ,   --注释：上期单据在本期调整金额
                CREATION_DATE ,   --录入日期
                REMARKS ,   --备注
                SALES_CENTER_CODE ,   --营销中心编码
                SALES_CENTER_NAME ,   --营销中心名称
                INVOICE_NUM_LIST ,   --发票号串：多个发票号用逗号分隔（,）。
                INVOICE_DATE ,   --发票日期：一张销售单只有一个发票开票日期。
                CASH_CODE ,   --票据号
                CASH_DATE ,   --出票日期
                DUE_DATE ,   --票据到期日期
                LIST_AMOUNT ,   --列表金额
                SETTLE_AMOUNT ,   --结算金额
                DISCOUNT_AMOUNT,    --核销折让金额
                ITEM_MONTH_DISCOUNT_AMOUNT,    --月返金额
                ORDER_TYPE_ID,      --单据类型ID
                SALES_MAIN_ID,      --品类ID
                SALES_MAIN_NAME,    --品类名称
                ITEM_CODE,    --产品编码
                ITEM_NAME,    --产品名称
                ITEM_PRICE,    --产品价格
                ITEM_UOM,    --产品单位
                ITEM_QTY,    --产品数量
                RECEIVED_QTY,    --签收数量
                REVERSAL_QTY,    --已红冲数量
                RETURN_QTY,    --已退回数量
                DISCOUNT_TYPE
                )
              SELECT
                 V_SOA_COUNT_BATCH_ID,
                 '冻结保证金',
                 V_ORDER_TYPE,
                 V_SOA_COUNT_BATCH_ID,
                 V_ORDER_NUMBER,
                 t.BILL_ID,
                 t.ENTITY_ID,
                 null,
                 '冻结保证金',
                 null,
                 t.CUSTOMER_ID,
                 t.CUSTOMER_CODE,
                 t.CUSTOMER_NAME,
                 null,
                 null,
                 t.SALES_CENTER_ID,
                 t.BILL_NUM,
                 t.BILL_DATE,
                 t.BILL_DATE,
                 'Y',
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 V_PERIOD_DATE,
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 /*(SELECT t.HISTORY_ID
                FROM T_AR_SOA_SO_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID),*/
                 null,
                 S_AR_SOA_ORDER_DETAILS.NEXTVAL,
                 null,
                 null,
                 sysdate,
                 --null,--备注
                 substrb(t.REMARK, 1, 1000),--备注
                 t.SALES_CENTER_CODE,
                 t.SALES_CENTER_NAME,
                 null,
                 null,
                 null,
                 null,
                 null,
                 ROUND(t.APPROVAL_AMOUNT,2), --t.LIST_AMOUNT,
                 ROUND(t.APPROVAL_AMOUNT,2), --t.SETTLE_AMOUNT,
                 ROUND(t.APPROVAL_AMOUNT,2), --t.DISCOUNT_AMOUNT,
                 ROUND(t.APPROVAL_AMOUNT,2), --ITEM_MONTH_DISCOUNT_AMOUNT
                 t.BILL_TYPE_ID,
                 ITEMCLASS_ROW.ITEM_CLASS_ID,
                 ITEMCLASS_ROW.CLASS_CODE,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 V_DISCOUNT_TYPE
                 FROM  T_CREDIT_DELAYPAY t 
                 WHERE t.DELAYPAY_TYPE =10     --冻结保证金
                   AND t.BILL_STATUS = 3       --已审批
                   AND t.DUE_TIME IS NULL    --没过期
                   AND V_DISCOUNT_TYPE = V_DISCOUNT_TYPE_COMMON
                   AND t.entity_id = ACCOUNT_ROW.entity_id
                   AND t.customer_id = ACCOUNT_ROW.customer_id
                   AND t.account_id = ACCOUNT_ROW.account_id
                   AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
                   AND t.BILL_DATE >= V_PERIOD_START_DATE   
                   AND t.BILL_DATE < V_PERIOD_END_DATE2;
                   
                 EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                     SQLCODE,
                                                     '插入本期冻结保证金数据到明细表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
                  END;     
                  

            --判断到款更新数据是否存在金额差异，算法是：通过获取到款单中在本期内更新的到款单，用这个到款单id查询到款历史表中
            FOR RECEIPT_ROW IN C_RECEIPT LOOP
              SELECT COUNT(*)
                INTO V_COUNT9
                FROM T_AR_SOA_CUST_RECEIPT_HIS t
               WHERE t.ORDER_NUMBER = RECEIPT_ROW.CASH_RECEIPT_CODE
                 AND t.HEADER_ID = RECEIPT_ROW.CASH_RECEIPT_ID
                 AND nvl(t.status,'N') <> 'E';
              if(V_COUNT9 > 0) THEN
                BEGIN
                  V_RESULT := '获取到款差异金额';
                SELECT NVL(t.RECEIPT_AMOUNT,0)
                  INTO V_RECEIPT_AMOUNT
                  FROM T_AR_SOA_CUST_RECEIPT_HIS t
                 WHERE t.ORDER_NUMBER = RECEIPT_ROW.CASH_RECEIPT_CODE
                   AND t.HEADER_ID = RECEIPT_ROW.CASH_RECEIPT_ID
                   AND nvl(t.status,'N') <> 'E';
                EXCEPTION
                  WHEN OTHERS THEN
                    V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                       SQLCODE,
                                                       '获取到款差异金额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                       substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                    P_RESULT := V_RESULT;
                    --RAISE V_ERR_EXCEPT;
                    V_RECEIPT_AMOUNT := 0;
                    CONTINUE;
                    END;

              if(V_RECEIPT_AMOUNT <> RECEIPT_ROW.AMOUNT) THEN
              BEGIN
                V_RESULT := '插入上期到款单差异数据到明细表';
              --插入差异数据到明细表
              INSERT INTO T_AR_SOA_ORDER_DETAILS
               (SOA_COUNT_BATCH_ID ,   --对账单批次ID
                SOURCE_ORDER_TYPE ,   --来源单据类型：到款单、销售单、返利单
                SOA_ORDER_TYPE ,   --对账单类型
                SOA_ORDER_HEAD_ID ,   --对账单ID
                SOA_ORDER_NUMBER ,   --对账单号
                HEADER_ID ,   --单据ID
                ENTITY_ID ,   --主体ID
                SALES_YEAR_ID ,   --销售年度
                ORDER_TYPE ,   --单据类型
                SALES_REGION_ID ,   --经营区域ID
                CUSTOMER_ID ,   --客户ID
                CUSTOMER_CODE ,   --客户编码
                CUSTOMER_NAME ,   --客户名称
                DISCOUNT_TYPE_ID ,   --折扣类型ID
                DISCOUNT_METHOD ,   --折让方法
                SALES_CENTER_ID ,   --营销中心ID
                ORDER_NUMBER ,   --单据编号
                ORDERED_DATE ,   --单据日期
                ACCOUNT_DATE ,   --结算日期
                ACCOUNT_FLAG ,   --结算标志
                ITEM_TYPE ,   --商品大类
                DIS_AMOUNT ,   --折让金额
                INTEND_AMOUNT ,   --含税金额
                AMOUNT ,   --到款金额
                DIFFERENCE_AMOUNT ,   --差异金额
                DIFFERENCE_DIS_AMOUNT ,   --差异折让金额
                SOA_PERIOD_DATE ,   --对账单周期
                SOA_BEGIN_DATE ,   --对账单开始日期
                SOA_END_DATE ,   --对账单结束日期
                HISTORY_ID ,   --历史ID
                DETAILS_ID ,   --明细ID
                DIFF_UPDATE_FLAG ,   --创建的历史差异已更新标志
                SOA_ADJUST_CODE ,   --注释：上期单据在本期调整金额
                CREATION_DATE ,   --录入日期
                REMARKS ,   --备注
                SALES_CENTER_CODE ,   --营销中心编码
                SALES_CENTER_NAME ,   --营销中心名称
                INVOICE_NUM_LIST ,   --发票号串：多个发票号用逗号分隔（,）。
                INVOICE_DATE ,   --发票日期：一张销售单只有一个发票开票日期。
                CASH_CODE ,   --票据号
                CASH_DATE ,   --出票日期
                DUE_DATE ,   --票据到期日期
                LIST_AMOUNT ,   --列表金额
                SETTLE_AMOUNT ,   --结算金额
                DISCOUNT_AMOUNT,    --核销折让金额
                ORDER_TYPE_ID,      --单据类型ID
                SALES_MAIN_ID,      --品类ID
                SALES_MAIN_NAME,    --品类名称
                DISCOUNT_TYPE
                )
              VALUES
                (V_SOA_COUNT_BATCH_ID,
                 '到款单差异',
                 V_ORDER_TYPE,
                 V_SOA_COUNT_BATCH_ID,
                 V_ORDER_NUMBER,
                 RECEIPT_ROW.CASH_RECEIPT_ID,
                 RECEIPT_ROW.ENTITY_ID,
                 null,
                 (SELECT distinct t.RECEIPT_METHOD_NAME
                 FROM T_AR_RECEIPT_METHODS t
                 WHERE t.RECEIPT_METHOD_ID = RECEIPT_ROW.RECEIPT_METHOD_ID),
                 null,
                 RECEIPT_ROW.CUSTOMER_ID,
                 RECEIPT_ROW.CUSTOMER_CODE,
                 RECEIPT_ROW.CUSTOMER_NAME,
                 null,
                 null,
                 RECEIPT_ROW.SALES_CENTER_ID,
                 RECEIPT_ROW.CASH_RECEIPT_CODE,
                 RECEIPT_ROW.CASH_RECEIPT_DATE,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 (RECEIPT_ROW.AMOUNT - V_RECEIPT_AMOUNT),
                 null,
                 V_PERIOD_DATE,
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 (SELECT t.HISTORY_ID
                FROM T_AR_SOA_CUST_RECEIPT_HIS t
               WHERE t.ORDER_NUMBER = RECEIPT_ROW.CASH_RECEIPT_CODE
                 AND t.HEADER_ID = RECEIPT_ROW.CASH_RECEIPT_ID
                 AND nvl(t.status,'N') <> 'E'),
                 S_AR_SOA_ORDER_DETAILS.NEXTVAL,
                 null,
                 null,
                 sysdate,
                 --null,-- 备注
                 RECEIPT_ROW.REMAEK,-- 备注
                 ACCOUNT_ROW.SALES_CENTER_CODE,
                 ACCOUNT_ROW.SALES_CENTER_NAME,
                 null,
                 null,
                 RECEIPT_ROW.CASH_CODE,
                 RECEIPT_ROW.CASH_DATE,
                 RECEIPT_ROW.DUE_DATE,
                 null,
                 null,
                 null,
                 RECEIPT_ROW.RECEIPT_METHOD_ID,
                 ITEMCLASS_ROW.ITEM_CLASS_ID,
                 ITEMCLASS_ROW.CLASS_CODE,
                 V_DISCOUNT_TYPE
                 );
                 EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                     SQLCODE,
                                                     '插入上期到款单差异数据到明细表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
                  END;
              end if;
              end if;
            END LOOP;

            --判断销售更新数据是否存在金额差异
            FOR SO_ROW IN C_SO LOOP
              SELECT COUNT(*)
                INTO V_COUNT10
                FROM T_AR_SOA_SO_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID
                 AND nvl(t.diff_update_flag,'N') <> 'E';
              if(V_COUNT10 > 0) THEN
              BEGIN
                V_RESULT := '获取销售差异金额';
              SELECT NVL(t.AMOUNT,0)
                INTO V_SO_AMOUNT
                FROM T_AR_SOA_SO_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID
                 AND nvl(t.diff_update_flag,'N') <> 'E';
              EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                     SQLCODE,
                                                     '获取销售差异金额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  V_SO_AMOUNT := 0;
                  CONTINUE;
                  END;

              if(V_SO_AMOUNT <> SO_ROW.SETTLE_AMOUNT) THEN
              BEGIN
                V_RESULT := '插入上期销售单差异数据到明细表';
              --插入差异数据到明细表
              INSERT INTO T_AR_SOA_ORDER_DETAILS
               (SOA_COUNT_BATCH_ID ,   --对账单批次ID
                SOURCE_ORDER_TYPE ,   --来源单据类型：到款单、销售单、返利单
                SOA_ORDER_TYPE ,   --对账单类型
                SOA_ORDER_HEAD_ID ,   --对账单ID
                SOA_ORDER_NUMBER ,   --对账单号
                HEADER_ID ,   --单据ID
                ENTITY_ID ,   --主体ID
                SALES_YEAR_ID ,   --销售年度
                ORDER_TYPE ,   --单据类型
                SALES_REGION_ID ,   --经营区域ID
                CUSTOMER_ID ,   --客户ID
                CUSTOMER_CODE ,   --客户编码
                CUSTOMER_NAME ,   --客户名称
                DISCOUNT_TYPE_ID ,   --折扣类型ID
                DISCOUNT_METHOD ,   --折让方法
                SALES_CENTER_ID ,   --营销中心ID
                ORDER_NUMBER ,   --单据编号
                ORDERED_DATE ,   --单据日期
                ACCOUNT_DATE ,   --结算日期
                ACCOUNT_FLAG ,   --结算标志
                ITEM_TYPE ,   --商品大类
                DIS_AMOUNT ,   --折让金额
                INTEND_AMOUNT ,   --含税金额
                AMOUNT ,   --到款金额
                DIFFERENCE_AMOUNT ,   --差异金额
                DIFFERENCE_DIS_AMOUNT ,   --差异折让金额
                SOA_PERIOD_DATE ,   --对账单周期
                SOA_BEGIN_DATE ,   --对账单开始日期
                SOA_END_DATE ,   --对账单结束日期
                HISTORY_ID ,   --历史ID
                DETAILS_ID ,   --明细ID
                DIFF_UPDATE_FLAG ,   --创建的历史差异已更新标志
                SOA_ADJUST_CODE ,   --注释：上期单据在本期调整金额
                CREATION_DATE ,   --录入日期
                REMARKS ,   --备注
                SALES_CENTER_CODE ,   --营销中心编码
                SALES_CENTER_NAME ,   --营销中心名称
                INVOICE_NUM_LIST ,   --发票号串：多个发票号用逗号分隔（,）。
                INVOICE_DATE ,   --发票日期：一张销售单只有一个发票开票日期。
                CASH_CODE ,   --票据号
                CASH_DATE ,   --出票日期
                DUE_DATE ,   --票据到期日期
                LIST_AMOUNT ,   --列表金额
                SETTLE_AMOUNT ,   --结算金额
                DISCOUNT_AMOUNT,    --核销折让金额
                ORDER_TYPE_ID,      --单据类型ID
                SALES_MAIN_ID,      --品类ID
                SALES_MAIN_NAME,    --品类名称
                DISCOUNT_TYPE,
                RAW_SRC_BILL_NUM
                )
              VALUES
                (V_SOA_COUNT_BATCH_ID,
                 '销售单差异',
                 V_ORDER_TYPE,
                 V_SOA_COUNT_BATCH_ID,
                 V_ORDER_NUMBER,
                 SO_ROW.SO_HEADER_ID,
                 SO_ROW.ENTITY_ID,
                 null,
                 SO_ROW.BILL_TYPE_NAME,
                 null,
                 SO_ROW.CUSTOMER_ID,
                 SO_ROW.CUSTOMER_CODE,
                 SO_ROW.CUSTOMER_NAME,
                 null,
                 null,
                 SO_ROW.SALES_CENTER_ID,
                 SO_ROW.SO_NUM,
                 SO_ROW.SO_DATE,
                 SO_ROW.SETTLE_DATE,
                 SO_ROW.SETTLE_FLAG,
                 null,
                 null,
                 null,
                 null,
                 (SO_ROW.SETTLE_AMOUNT - V_SO_AMOUNT),
                 null,
                 V_PERIOD_DATE,
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 (SELECT t.HISTORY_ID
                FROM T_AR_SOA_SO_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID
                 AND nvl(t.diff_update_flag,'N') <> 'E'),
                 S_AR_SOA_ORDER_DETAILS.NEXTVAL,
                 null,
                 null,
                 sysdate,
                 --null,  --备注
                 substrb(SO_ROW.REMARK, 1, 1000),--备注
                 SO_ROW.SALES_CENTER_CODE,
                 SO_ROW.SALES_CENTER_NAME,
                 SO_ROW.INVOICE_NUM_LIST,
                 SO_ROW.INVOICE_DATE,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 SO_ROW.BILL_TYPE_ID,
                 ITEMCLASS_ROW.ITEM_CLASS_ID,
                 ITEMCLASS_ROW.CLASS_CODE,
                 V_DISCOUNT_TYPE,
                  (case when SO_ROW.RAW_SRC_TYPE ='02' then SO_ROW.RAW_SRC_BILL_NUM
                      when SO_ROW.ORIGIN_ORIGIN_TYPE ='02' then SO_ROW.ORIGIN_ORIGIN_ORDER_CODE
                      else null  end)
                 );
                 EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                     SQLCODE,
                                                     '插入上期销售单差异数据到明细表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
                  END;
              end if;
              end if;
            END LOOP;
            --2-折让扣款
            elsif (V_ORDER_TYPE = '2' /*AND V_COUNT6 > 0*/) THEN
              BEGIN
                --插入确认式往来对账单折让扣款行
                INSERT INTO T_AR_SOA_ORDER_DIS_LINES
                  (DISCOUNT_LINE_ID, --到款行ID
                   HEADER_ID, --对账单头ID
                   SOA_TYPE, --对账类型
                   PERIOD_AMOUNT, --期初余额
                   DISCOUNT_AMOUNT, --本期累计折让
                   DIS_SALES_AMOUNT, --本期累计核销折让
                   CURRENT_AMOUNT, --本期折让余额
                   CUS_DISCOUNT_AMOUNT, --客户确认的折让余额
                   DIFFERENACE_AMOUNT, --差异金额
                   SS_DISCOUNT_REM_AMOUNT, --本期销售政策折让余额
                   COMMENTS, --备注
                   ENTITY_ID, --主体ID
                   CREATED_BY, --创建人
                   CREATION_DATE, --创建日期
                   LAST_UPDATED_BY, --最后更新人
                   LAST_UPDATE_DATE, --最后更新日期
                   SOA_COUNT_BATCH_ID,
                   SALES_MAIN_ID,
                   DIFF_DISCOUNT_AMOUNT,      --品类ID
                   DISCOUNT_TYPE
                   )
                VALUES
                  (S_AR_SOA_ORDER_LINES.NEXTVAL, --S_AR_SOA_ORDER_LINES.NEXTVAL,
                   V_SOA_COUNT_BATCH_ID,
                   V_ORDER_TYPE, --'DISCOUNT_TYPE', --折让扣款
                   V_AMOUNT_J, --期初余额
                   V_AMOUNT_K, --本期累计折让
                   V_AMOUNT_L, --本期累计核销折让
                   V_AMOUNT_H, --本期折让余额
                   null, --客户确认的折让余额
                   null, --差异金额
                   null, --本期销售政策折让余额
                   null, --备注
                   CONF_ROW.ENTITY_ID,
                   'D',
                   SYSDATE,
                   null,
                   null,
                   V_SOA_COUNT_BATCH_ID,
                   ITEMCLASS_ROW.ITEM_CLASS_ID,
                   D_AMOUNT_K,
                   V_DISCOUNT_TYPE
                   );

              EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                     SQLCODE,
                                                     '插入确认式往来对账单折让扣款行失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
              END;

             BEGIN
              V_RESULT := '插入折扣让利单数据到折扣历史表';
              INSERT INTO T_AR_SOA_DIS_ORDER_HIS
                (SOA_COUNT_BATCH_ID,  --对账单批次ID
                 SOURCE_ORDER_TYPE,   --来源单据类型：返利单
                 SOA_SALES_CENTER_ID, --对账单中心ID
                 SOA_ORDER_TYPE,      --对账单类型（余额确认式、借贷调节式）
                 SOA_ORDER_HEAD_ID,   --对账单ID
                 SOA_ORDER_NUMBER,    --对账单号
                 HEADER_ID,           --返利单ID
                 ENTITY_ID,
                 ORDER_TYPE_ID,       --单据类型iD
                 SALES_REGION_ID,
                 CUSTOMER_ID,
                 DISCOUNT_TYPE_ID,    --折扣类型ID
                 DISCOUNT_METHOD,     --折让方法
                 SALES_CENTER_ID,
                 --POLICY_CODE,
                 --DOC_CODE,
                 ORDER_NUMBER,
                 ORDERED_DATE,
                 ACCOUNT_DATE,        --结算日期
                 ACCOUNT_FLAG,
                 ITEM_TYPE,           --商品大类
                 DIS_AMOUNT,          --折让金额
                 INTEND_AMOUNT,       --含税金额
                 AMOUNT,              --总额
                 BI_LAST_UPDATE_DATE,
                 difference_AMOUNT,
                 difference_DIS_AMOUNT,
                 SOA_PERIOD_DATE,
                 SOA_BEGIN_DATE,
                 SOA_END_DATE,
                 HISTORY_ID,
                 CREATION_DATE,
                 DISCOUNT_TYPE
                 )
                SELECT V_SOA_COUNT_BATCH_ID,
                       '返利单' ,
                       null,
                       V_ORDER_TYPE,
                       V_SOA_COUNT_BATCH_ID,
                       V_ORDER_NUMBER,
                       t.SO_HEADER_ID,
                       t.ENTITY_ID,
                       t.BILL_TYPE_ID,        --单据类型
                       null,                --CDD.SALES_REGION_ID,
                       t.CUSTOMER_ID,
                       null,                --CDD.DISCOUNT_TYPE_ID,
                       t.DISCOUNT_MODE,
                       t.SALES_CENTER_ID,
                       --CDD.POLICY_CODE,
                       --CDD.DOC_CODE,
                       t.SO_NUM,
                       t.SO_DATE,
                       t.SETTLE_DATE,
                       t.SETTLE_FLAG,
                       null,                        --CDD.ITEM_TYPE,
                       t.DISCOUNT_AMOUNT,
                       null,
                       t.SETTLE_AMOUNT,
                       null,
                       0,
                       0,
                       V_PERIOD_DATE,
                       V_PERIOD_START_DATE,
                       V_PERIOD_END_DATE,
                       S_AR_SOA_DIS_ORDER_HIS.NEXTVAL,
                       SYSDATE,
                       V_DISCOUNT_TYPE
                      FROM T_SO_HEADER t
                     WHERE t.entity_id = ACCOUNT_ROW.entity_id
                       AND t.customer_id = ACCOUNT_ROW.customer_id
                       --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                       AND t.account_id = ACCOUNT_ROW.account_id
                       AND t.so_status <> '10'
                       AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
                       AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                       AND t.BIZ_SRC_BILL_TYPE_CODE in ('1009', '1010')
                       AND t.so_date >= V_PERIOD_START_DATE
                       AND t.so_date < V_PERIOD_END_DATE2;
            EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                     SQLCODE,
                                                     '插入折扣让利单数据到折扣历史表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
              END;

            --插入明细表
            BEGIN
                V_RESULT := '插入本期返利单（折让）数据到明细表';
              --插入本期返利单（折让）数据到明细表
              INSERT INTO T_AR_SOA_ORDER_DETAILS
               (SOA_COUNT_BATCH_ID ,   --对账单批次ID
                SOURCE_ORDER_TYPE ,   --来源单据类型：到款单、销售单、返利单
                SOA_ORDER_TYPE ,   --对账单类型
                SOA_ORDER_HEAD_ID ,   --对账单ID
                SOA_ORDER_NUMBER ,   --对账单号
                HEADER_ID ,   --单据ID
                ENTITY_ID ,   --主体ID
                SALES_YEAR_ID ,   --销售年度
                ORDER_TYPE ,   --单据类型
                SALES_REGION_ID ,   --经营区域ID
                CUSTOMER_ID ,   --客户ID
                CUSTOMER_CODE ,   --客户编码
                CUSTOMER_NAME ,   --客户名称
                DISCOUNT_TYPE_ID ,   --折扣类型ID
                DISCOUNT_METHOD ,   --折让方法
                SALES_CENTER_ID ,   --营销中心ID
                ORDER_NUMBER ,   --单据编号
                ORDERED_DATE ,   --单据日期
                ACCOUNT_DATE ,   --结算日期
                ACCOUNT_FLAG ,   --结算标志
                ITEM_TYPE ,   --商品大类
                DIS_AMOUNT ,   --折让金额
                INTEND_AMOUNT ,   --含税金额
                AMOUNT ,   --到款金额
                DIFFERENCE_AMOUNT ,   --差异金额
                DIFFERENCE_DIS_AMOUNT ,   --差异折让金额
                SOA_PERIOD_DATE ,   --对账单周期
                SOA_BEGIN_DATE ,   --对账单开始日期
                SOA_END_DATE ,   --对账单结束日期
                HISTORY_ID ,   --历史ID
                DETAILS_ID ,   --明细ID
                DIFF_UPDATE_FLAG ,   --创建的历史差异已更新标志
                SOA_ADJUST_CODE ,   --注释：上期单据在本期调整金额
                CREATION_DATE ,   --录入日期
                REMARKS ,   --备注
                SALES_CENTER_CODE ,   --营销中心编码
                SALES_CENTER_NAME ,   --营销中心名称
                INVOICE_NUM_LIST ,   --发票号串：多个发票号用逗号分隔（,）。
                INVOICE_DATE ,   --发票日期：一张销售单只有一个发票开票日期。
                CASH_CODE ,   --票据号
                CASH_DATE ,   --出票日期
                DUE_DATE ,   --票据到期日期
                LIST_AMOUNT ,   --列表金额
                SETTLE_AMOUNT ,   --结算金额
                DISCOUNT_AMOUNT,    --核销折让金额
                ORDER_TYPE_ID,      --单据类型ID
                SALES_MAIN_ID,      --品类ID
                SALES_MAIN_NAME,    --品类名称
                DISCOUNT_TYPE
                )
              SELECT
                 V_SOA_COUNT_BATCH_ID,
                 '返利单据',
                 V_ORDER_TYPE,
                 V_SOA_COUNT_BATCH_ID,
                 V_ORDER_NUMBER,
                 t.SO_HEADER_ID,
                 t.ENTITY_ID,
                 null,
                 t.BILL_TYPE_NAME,
                 null,
                 t.CUSTOMER_ID,
                 t.CUSTOMER_CODE,
                 t.CUSTOMER_NAME,
                 null,
                 null,
                 t.SALES_CENTER_ID,
                 t.SO_NUM,
                 t.SO_DATE,
                 t.SETTLE_DATE,
                 t.SETTLE_FLAG,
                 null,
                 ROUND(e.PLUS_MINUS_FLAG * NVL(t.SETTLE_AMOUNT,0),2),--t.SETTLE_AMOUNT,
                 null,
                 null,
                 null,
                 null,
                 V_PERIOD_DATE,
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 /*(SELECT t.HISTORY_ID
                FROM T_AR_SOA_SO_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID),*/
                 null,
                 S_AR_SOA_ORDER_DETAILS.NEXTVAL,
                 null,
                 null,
                 sysdate,
                 --null,--备注
                 substrb(t.REMARK, 1, 1000),--备注
                 t.SALES_CENTER_CODE,
                 t.SALES_CENTER_NAME,
                 t.INVOICE_NUM_LIST,
                 t.INVOICE_DATE,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 t.BILL_TYPE_ID,
                 ITEMCLASS_ROW.ITEM_CLASS_ID,
                 ITEMCLASS_ROW.CLASS_CODE,
                 V_DISCOUNT_TYPE
                      FROM T_SO_HEADER t,T_SO_TYPE_EXTEND e
                      WHERE t.bill_type_id = e.bill_type_id
                       AND t.entity_id = ACCOUNT_ROW.entity_id
                       AND t.customer_id = ACCOUNT_ROW.customer_id
                       --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                       AND t.account_id = ACCOUNT_ROW.account_id
                       AND t.BIZ_SRC_BILL_TYPE_CODE in ('1009', '1010')
                       AND t.so_status <> '10'
                       AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
                        AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                       AND t.so_date >= V_PERIOD_START_DATE
                       AND t.so_date < V_PERIOD_END_DATE2;
                 EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                     SQLCODE,
                                                     '插入本期返利单数据到明细表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
                  END;

            --判断返利单（折让）更新数据是否存在金额差异
            FOR SO_ROW IN C_SO LOOP
              SELECT COUNT(*)
                INTO V_COUNT11
                FROM T_AR_SOA_DIS_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID
                 AND nvl(t.diff_update_flag,'N') <> 'E';

              if(V_COUNT11 > 0) THEN
              BEGIN
                V_RESULT := '获取折让差异金额';
              SELECT NVL(t.DIS_AMOUNT,0)
                INTO V_DIS_AMOUNT
                FROM T_AR_SOA_DIS_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID
                 AND nvl(t.diff_update_flag,'N') <> 'E';
              EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                     SQLCODE,
                                                     '获取折让差异金额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  V_DIS_AMOUNT := 0;
                  CONTINUE;
                  END;

              if(V_DIS_AMOUNT <> SO_ROW.DISCOUNT_AMOUNT) THEN
              BEGIN
                V_RESULT := '插入上期返利单差异数据到明细表';
              --插入差异数据到明细表
              INSERT INTO T_AR_SOA_ORDER_DETAILS
               (SOA_COUNT_BATCH_ID ,   --对账单批次ID
                SOURCE_ORDER_TYPE ,   --来源单据类型：到款单、销售单、返利单
                SOA_ORDER_TYPE ,   --对账单类型
                SOA_ORDER_HEAD_ID ,   --对账单ID
                SOA_ORDER_NUMBER ,   --对账单号
                HEADER_ID ,   --单据ID
                ENTITY_ID ,   --主体ID
                SALES_YEAR_ID ,   --销售年度
                ORDER_TYPE ,   --单据类型
                SALES_REGION_ID ,   --经营区域ID
                CUSTOMER_ID ,   --客户ID
                CUSTOMER_CODE ,   --客户编码
                CUSTOMER_NAME ,   --客户名称
                DISCOUNT_TYPE_ID ,   --折扣类型ID
                DISCOUNT_METHOD ,   --折让方法
                SALES_CENTER_ID ,   --营销中心ID
                ORDER_NUMBER ,   --单据编号
                ORDERED_DATE ,   --单据日期
                ACCOUNT_DATE ,   --结算日期
                ACCOUNT_FLAG ,   --结算标志
                ITEM_TYPE ,   --商品大类
                DIS_AMOUNT ,   --折让金额
                INTEND_AMOUNT ,   --含税金额
                AMOUNT ,   --到款金额
                DIFFERENCE_AMOUNT ,   --差异金额
                DIFFERENCE_DIS_AMOUNT ,   --差异折让金额
                SOA_PERIOD_DATE ,   --对账单周期
                SOA_BEGIN_DATE ,   --对账单开始日期
                SOA_END_DATE ,   --对账单结束日期
                HISTORY_ID ,   --历史ID
                DETAILS_ID ,   --明细ID
                DIFF_UPDATE_FLAG ,   --创建的历史差异已更新标志
                SOA_ADJUST_CODE ,   --注释：上期单据在本期调整金额
                CREATION_DATE ,   --录入日期
                REMARKS ,   --备注
                SALES_CENTER_CODE ,   --营销中心编码
                SALES_CENTER_NAME ,   --营销中心名称
                INVOICE_NUM_LIST ,   --发票号串：多个发票号用逗号分隔（,）。
                INVOICE_DATE ,   --发票日期：一张销售单只有一个发票开票日期。
                CASH_CODE ,   --票据号
                CASH_DATE ,   --出票日期
                DUE_DATE ,   --票据到期日期
                LIST_AMOUNT ,   --列表金额
                SETTLE_AMOUNT ,   --结算金额
                DISCOUNT_AMOUNT,    --核销折让金额
                ORDER_TYPE_ID,      --单据类型ID
                SALES_MAIN_ID,      --品类ID
                SALES_MAIN_NAME,    --品类名称
                DISCOUNT_TYPE
                )
              VALUES
                (V_SOA_COUNT_BATCH_ID,
                 '返利单差异',
                 V_ORDER_TYPE,
                 V_SOA_COUNT_BATCH_ID,
                 V_ORDER_NUMBER,
                 SO_ROW.SO_HEADER_ID,
                 SO_ROW.ENTITY_ID,
                 null,
                 SO_ROW.BILL_TYPE_NAME,
                 null,
                 SO_ROW.CUSTOMER_ID,
                 SO_ROW.CUSTOMER_CODE,
                 SO_ROW.CUSTOMER_NAME,
                 null,
                 SO_ROW.DISCOUNT_MODE,
                 SO_ROW.SALES_CENTER_ID,
                 SO_ROW.SO_NUM,
                 SO_ROW.SO_DATE,
                 SO_ROW.SETTLE_DATE,
                 SO_ROW.SETTLE_FLAG,
                 null,
                 null,
                 null,
                 null,
                 null,
                 (SO_ROW.DISCOUNT_AMOUNT - V_DIS_AMOUNT),
                 V_PERIOD_DATE,
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 (SELECT t.HISTORY_ID
                FROM T_AR_SOA_SO_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID
                 AND nvl(t.diff_update_flag,'N') <> 'E'),
                 S_AR_SOA_ORDER_DETAILS.NEXTVAL,
                 null,
                 null,
                 sysdate,
                 --null,--备注
                 substrb(SO_ROW.REMARK, 1, 1000),--备注
                 SO_ROW.SALES_CENTER_CODE,
                 SO_ROW.SALES_CENTER_NAME,
                 SO_ROW.INVOICE_NUM_LIST,
                 SO_ROW.INVOICE_DATE,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 SO_ROW.BILL_TYPE_ID,
                 ITEMCLASS_ROW.ITEM_CLASS_ID,
                 ITEMCLASS_ROW.CLASS_CODE,
                 V_DISCOUNT_TYPE
                 );
                 EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                     SQLCODE,
                                                     '插入上期返利单差异数据到明细表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
                  END;
              end if;
              end if;
            END LOOP;

            end if;

          END LOOP;

          --end if;

          END LOOP;
          
          --插入确认式往来对账单折让扣款行
          --由于在以上计算中，是按照品类且考虑了到款方式的DISCOUNT_TYPE（COMMON-常规到款  DISCOUNT-折让到款）来计算中，
          --所以针对对账单到款结算行表中T_AR_SOA_ORDER_RECEIPT_LINES，本来就需要按照这两种方式去统计
          --但是针对对账单折让扣款行（T_AR_SOA_ORDER_DIS_LINES），就不存在到款方式的区分，所以汇总统计重新插入明细；
          BEGIN
               INSERT INTO T_AR_SOA_ORDER_DIS_LINES
                  (DISCOUNT_LINE_ID, --到款行ID
                   HEADER_ID, --对账单头ID
                   SOA_TYPE, --对账类型
                   PERIOD_AMOUNT, --期初余额
                   DISCOUNT_AMOUNT, --本期累计折让
                   DIS_SALES_AMOUNT, --本期累计核销折让
                   CURRENT_AMOUNT, --本期折让余额
                   CUS_DISCOUNT_AMOUNT, --客户确认的折让余额
                   DIFFERENACE_AMOUNT, --差异金额
                   SS_DISCOUNT_REM_AMOUNT, --本期销售政策折让余额
                   COMMENTS, --备注
                   ENTITY_ID, --主体ID
                   CREATED_BY, --创建人
                   CREATION_DATE, --创建日期
                   LAST_UPDATED_BY, --最后更新人
                   LAST_UPDATE_DATE, --最后更新日期
                   SOA_COUNT_BATCH_ID,
                   SALES_MAIN_ID,  --品类ID
                   DIFF_DISCOUNT_AMOUNT)   
               SELECT  S_AR_SOA_ORDER_LINES.NEXTVAL,
                       HEADER_ID, --对账单头ID
                       SOA_TYPE, --对账类型
                       PERIOD_AMOUNT, --期初余额
                       DISCOUNT_AMOUNT, --本期累计折让
                       DIS_SALES_AMOUNT, --本期累计核销折让
                       CURRENT_AMOUNT, --本期折让余额
                       CUS_DISCOUNT_AMOUNT, --客户确认的折让余额
                       DIFFERENACE_AMOUNT, --差异金额
                       SS_DISCOUNT_REM_AMOUNT, --本期销售政策折让余额
                       COMMENTS, --备注
                       ENTITY_ID, --主体ID
                       'admin', --创建人
                       CREATION_DATE, --创建日期
                       LAST_UPDATED_BY, --最后更新人
                       LAST_UPDATE_DATE, --最后更新日期
                       SOA_COUNT_BATCH_ID,
                       SALES_MAIN_ID,  --品类ID
                       DIFF_DISCOUNT_AMOUNT
               from   
                (SELECT 
                       D.HEADER_ID,
                       D.SOA_TYPE,
                       D.SALES_MAIN_ID,
                       SUM(D.PERIOD_AMOUNT) PERIOD_AMOUNT,
                       SUM(D.DISCOUNT_AMOUNT) DISCOUNT_AMOUNT,
                       SUM(D.DIS_SALES_AMOUNT) DIS_SALES_AMOUNT,
                       SUM(D.CURRENT_AMOUNT) CURRENT_AMOUNT,
                       SUM(D.CUS_DISCOUNT_AMOUNT) CUS_DISCOUNT_AMOUNT,
                       SUM(D.DIFFERENACE_AMOUNT) DIFFERENACE_AMOUNT,
                       SUM(D.SS_DISCOUNT_REM_AMOUNT) SS_DISCOUNT_REM_AMOUNT,
                       MAX(D.COMMENTS) COMMENTS,
                       D.ENTITY_ID,
                       MAX(D.CREATED_BY) CREATED_BY,
                       MAX(D.CREATION_DATE) CREATION_DATE,
                       MAX(D.LAST_UPDATED_BY) LAST_UPDATED_BY,
                       MAX(D.LAST_UPDATE_DATE) LAST_UPDATE_DATE,
                       D.SOA_COUNT_BATCH_ID,
                       SUM(D.DIFF_DISCOUNT_AMOUNT) DIFF_DISCOUNT_AMOUNT
                  FROM CIMS.T_AR_SOA_ORDER_DIS_LINES D
                 WHERE D.HEADER_ID = V_SOA_COUNT_BATCH_ID
                 AND D.CREATED_BY = 'D'
                 GROUP BY D.ENTITY_ID,
                          D.HEADER_ID,
                          D.HEADER_ID,
                          D.SOA_TYPE,
                          D.SALES_MAIN_ID,
                          D.SOA_COUNT_BATCH_ID ) A;    
                          
                   DELETE CIMS.T_AR_SOA_ORDER_DIS_LINES L WHERE L.HEADER_ID = V_SOA_COUNT_BATCH_ID AND L.CREATED_BY = 'D'; 
          EXCEPTION
            WHEN OTHERS THEN
              V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                 SQLCODE,
                                                 '插入往来对账客户表！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' || substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
              P_RESULT := V_RESULT;
              CONTINUE;
          END;
          

          BEGIN
            V_RESULT := 'SUCCESS';
            --插入往来对账客户表
            INSERT INTO T_AR_STATEMENT_ACC_HISTORY
              (ACC_HISTORY_ID,
               HEADER_ID,
               CUSTOMER_ID,
               CUSTOMER_CODE,
               CUSTOMER_NAME,
               CUSTOMER_FLAG,
               SALES_CENTER_ID,
               HANDMODE_FLAG,
               COUNT_START_DATE,
               COUNT_END_DATE,
               COUNT_PERIOD,
               ORDER_TYPE,
               ORDER_NUMBER,
               SOA_RECEIPT_BATCH_ID,
               SOA_SO_ORDER_BATHC_ID,
               SOA_DISCOUNT_BACHT_ID,
               STATES,
               COUNT_RESULT,
               COMMENTS,
               ENTITY_ID,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE,
               SOA_COUNT_BATCH_ID)
            VALUES
              (S_AR_STATEMENT_ACC_HISTORY.NEXTVAL,
               NULL,
               ACCOUNT_ROW.CUSTOMER_ID,
               ACCOUNT_ROW.CUSTOMER_CODE,
               ACCOUNT_ROW.CUSTOMER_NAME,
               /* (select distinct w.CUSTOMER_NAME
                  from v_cust_account w
                 where w.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                   and w.SALES_CENTER_ID = ACCOUNT_ROW.SALES_CENTER_ID
                   and w.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID), */
               NULL,
               ACCOUNT_ROW.SALES_CENTER_ID,
               'N',
               V_PERIOD_START_DATE,
               V_PERIOD_END_DATE,
               V_PERIOD_DATE,
               --NVL(CSC.ORDER_TYPE, '余额确认式'),
               /*NVL((select CSC.ORDER_TYPE
                     from T_AR_CUSG_SOA_CONF CSC
                    where CSC.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                      and CSC.SALES_CENTER_ID = ACCOUNT_ROW.SALES_CENTER_ID
                      and CSC.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID),
                   '1'),*/
               '',
               V_ORDER_NUMBER,
               NULL,
               NULL,
               NULL,
               'COMPLETED',
               V_RESULT,
               NULL,
               ACCOUNT_ROW.ENTITY_ID,
               NULL,
               SYSDATE,
               NULL,
               NULL,
               V_SOA_COUNT_BATCH_ID);

          EXCEPTION
            WHEN OTHERS THEN
              V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                 SQLCODE,
                                                 '插入往来对账客户表！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' || substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
              P_RESULT := V_RESULT;
              --RAISE V_ERR_EXCEPT;
              CONTINUE;
          END;

        --end if;
        --end if;
        COMMIT;

        EXCEPTION
          WHEN OTHERS THEN

              ROLLBACK;
              V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                 SQLCODE,
                                                 '插入确认式往来对账单头表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                 substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
              P_RESULT := V_RESULT;
              --RAISE V_ERR_EXCEPT;

              --插入往来对账客户表
              V_RESULT2 := PKG_AR_ACCOUNT.F_ADD_SOA_HISTORY
              (NULL,
               ACCOUNT_ROW.CUSTOMER_ID,
               ACCOUNT_ROW.CUSTOMER_CODE,
               ACCOUNT_ROW.CUSTOMER_NAME,
               NULL,
               ACCOUNT_ROW.SALES_CENTER_ID,
               'N',
               V_PERIOD_START_DATE,
               V_PERIOD_END_DATE,
               V_PERIOD_DATE,
               --NVL(CSC.ORDER_TYPE, '余额确认式'),
               NULL,
               V_ORDER_NUMBER,
               NULL,
               NULL,
               NULL,
               'FAILURE',
               V_RESULT,
               NULL,
               ACCOUNT_ROW.ENTITY_ID,
               NULL,
               SYSDATE,
               NULL,
               NULL,
               V_SOA_COUNT_BATCH_ID);
              /*
            INSERT INTO T_AR_STATEMENT_ACC_HISTORY
              (ACC_HISTORY_ID,
               HEADER_ID,
               CUSTOMER_ID,
               CUSTOMER_CODE,
               CUSTOMER_NAME,
               CUSTOMER_FLAG,
               SALES_CENTER_ID,
               HANDMODE_FLAG,
               COUNT_START_DATE,
               COUNT_END_DATE,
               COUNT_PERIOD,
               ORDER_TYPE,
               ORDER_NUMBER,
               SOA_RECEIPT_BATCH_ID,
               SOA_SO_ORDER_BATHC_ID,
               SOA_DISCOUNT_BACHT_ID,
               STATES,
               COUNT_RESULT,
               COMMENTS,
               ENTITY_ID,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE,
               SOA_COUNT_BATCH_ID)
            VALUES
              (S_AR_STATEMENT_ACC_HISTORY.NEXTVAL,
               NULL,
               ACCOUNT_ROW.CUSTOMER_ID,
               ACCOUNT_ROW.CUSTOMER_CODE,
               NULL,
               NULL,
               ACCOUNT_ROW.SALES_CENTER_ID,
               'N',
               V_PERIOD_START_DATE,
               V_PERIOD_END_DATE,
               V_PERIOD_DATE,
               --NVL(CSC.ORDER_TYPE, '余额确认式'),
               NULL,
               V_ORDER_NUMBER,
               NULL,
               NULL,
               NULL,
               'FAILURE',
               V_RESULT,
               NULL,
               ACCOUNT_ROW.ENTITY_ID,
               NULL,
               SYSDATE,
               NULL,
               NULL,
               V_SOA_COUNT_BATCH_ID);
            COMMIT;
            */
            CONTINUE;
        END;

      END LOOP;

    EXCEPTION
      WHEN OTHERS THEN

        ROLLBACK;
        V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                   SQLCODE,
                                                   '对账失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                   substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
        P_RESULT := V_RESULT;
        --RAISE V_ERR_EXCEPT;
        --CONTINUE;
    END;

    COMMIT;
    P_RESULT := 'SUCCESS';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                   SQLCODE,
                                                   '对账失败！：' ||
                                                   substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
      P_RESULT := V_RESULT;
      --RAISE V_ERR_EXCEPT;
      --CONTINUE;
  END;

  -----------------------------------------------------------------------
  -- Author  :
  -- Created :
  --手动执行往来对账单数据生成
  --参数可以传：
  --      客户ID（单独该客户）
  --      账户ID（处理该账户）
  --      空白   （处理该主体所有可以计算往来对账单的客户）
  --
  -----------------------------------------------------------------------
  PROCEDURE P_CUSG_SOA_COUNT_HAND(P_ENTITY_ID       NUMBER, --主体ID
                                  --P_COUNT_PERIOD    VARCHAR2, --对账期间
                                  P_CUSTOMER_ID     NUMBER, --客户ID
                                  P_ACCOUNT_ID     NUMBER, --账户ID
                                  --P_SALES_CENTER_ID NUMBER, --营销中心ID
                                  --P_ORDER_TYPE             VARCHAR2, --对账单类型
                                  --P_USER_CODE              VARCHAR2, --用户ID
                                  --P_HANDMODE_FLAG          VARCHAR2, --手工请求标志
                                  P_COUNT_START_DATE       DATE, --对账开始日期
                                  P_COUNT_END_DATE         DATE, --对账结束日期
                                  P_RESULT IN OUT VARCHAR2) IS
    V_PERIOD_DATE       VARCHAR2(20); --账期
    V_PERIOD_START_DATE DATE; --账期开始时间
    V_PERIOD_END_DATE   DATE; --账期结束时间
    V_PERIOD_END_DATE2  DATE; --账期结束时间下一天
    V_LAST_START_DATE   DATE; --上月账期开始时间
    V_LAST_END_DATE     DATE; --上月账期结束时间
    V_ORDER_TYPE        VARCHAR2(20); --对账单类型
    V_CLASS_CODE      VARCHAR2(20); --品类
    V_CUSTOMER_ID     NUMBER; --客户ID
    --V_SALES_CENTER_ID NUMBER; --中心ID
    V_ACCOUNT_ID NUMBER; --账户ID
    V_DISCOUNT_TYPE_COMMON  VARCHAR2(32);
    V_DISCOUNT_TYPE         VARCHAR2(32);

   --从客户配置表获取账号数据
    /* CURSOR C_ACCOUNT IS
      SELECT distinct TCO.*
        FROM T_CUSTOMER_ORG TCO,t_ar_cusg_soa_conf a
       WHERE TCO.Entity_Id = a.entity_id
         and TCO.Customer_Id = a.customer_id
         and TCO.Sales_Center_Id = a.sales_center_id
         and a.entity_id = P_ENTITY_ID
         and a.customer_id = P_CUSTOMER_ID
         and a.sales_center_id = P_SALES_CENTER_ID;  */

    --从对账配置表获取账号数据
    CURSOR C_ACCOUNT IS
      SELECT distinct CSC.entity_id,CSC.account_id,CSC.customer_id,CSC.customer_name,csc.customer_code,csc.title, w.SALES_CENTER_ID,w.SALES_CENTER_CODE,w.SALES_CENTER_NAME
       FROM T_AR_CUSG_SOA_CONF CSC,v_customer_account_conf w
       WHERE CSC.Entity_Id = P_ENTITY_ID
       and CSC.CUSTOMER_ID = P_CUSTOMER_ID
       and CSC.ACCOUNT_ID = P_ACCOUNT_ID
       and w.CUSTOMER_ID = CSC.CUSTOMER_ID
       and w.ACCOUNT_ID = CSC.ACCOUNT_ID
       and w.ENTITY_ID = CSC.ENTITY_ID;


    --在对账配置表匹配需要对账的账号对账配置信息
    CURSOR C_ACCOUNT_CONF IS
      SELECT distinct CSC.ORDER_TYPE,CSC.Entity_Id
        FROM T_AR_CUSG_SOA_CONF CSC
       WHERE CSC.Entity_Id = P_ENTITY_ID
         and CSC.Customer_Id = P_CUSTOMER_ID
         --and CSC.Sales_Center_Id = P_SALES_CENTER_ID
         and CSC.Account_Id = P_ACCOUNT_ID
         ;

    --从产品分类获取分类数据
    CURSOR C_ITEM_CLASS IS
      SELECT NVL(U.CODE_VALUE,V_DISCOUNT_TYPE_COMMON) DISCOUNT_TYPE
           , U.CODE_NAME DISCOUNT_TYPE_NAME
           , T.*
        FROM T_BD_ITEM_CLASS T
        LEFT JOIN CIMS.UP_CODELIST U on U.CODETYPE = 'DISCOUNT_TYPE'
              AND PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS', T.ENTITY_ID , NULL, NULL) = 'NC'
              AND PKG_BD.F_GET_PARAMETER_VALUE('CRE_DIS_TYPE_ENABLE', T.ENTITY_ID , NULL, NULL) = 'Y'
       WHERE T.CLASS_TYPE = 'M'
         AND T.ACTIVE_FLAG = 'Y'
         AND T.ENTITY_ID = P_ENTITY_ID;

    --按品类获取存在差异的到款单数据
    CURSOR C_RECEIPT IS
      SELECT *
        FROM v_ar_cash_receipt_header_lines t
       WHERE t.Entity_Id = P_ENTITY_ID
         and t.Customer_Id = V_CUSTOMER_ID
         --and t.Sales_Center_Id = V_SALES_CENTER_ID
         and t.account_id = V_ACCOUNT_ID
         and t.SALES_MAIN_TYPE_CODE = V_CLASS_CODE
         AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
         and t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
         and t.REVIEWED_DATE >= V_LAST_START_DATE
         and t.REVIEWED_DATE < V_PERIOD_START_DATE
         and t.UPDATED_DATE >= V_PERIOD_START_DATE;

    --按品类获取存在差异的销售单、返利单（折让）数据
    CURSOR C_SO IS
      SELECT *
        FROM T_SO_HEADER t
       WHERE t.Entity_Id = P_ENTITY_ID
         and t.Customer_Id = V_CUSTOMER_ID
         --and t.Sales_Center_Id = V_SALES_CENTER_ID
         and t.account_id = V_ACCOUNT_ID
         and t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008','1009', '1010')
         and t.so_status <> '10'
         and t.SALES_MAIN_TYPE = V_CLASS_CODE
         AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
        -- and t.SO_DATE >= V_LAST_START_DATE  --去掉日期限制 guibr 存在跨两月结算单据
         and t.SO_DATE < V_PERIOD_START_DATE
         and t.settle_date >= V_PERIOD_START_DATE
           AND t.settle_date < V_PERIOD_END_DATE2;

    --按账号、账期查询对账历史数据
    CURSOR C_HIS IS
      SELECT *
        FROM T_AR_SOA_ORDER_HEADS t
       WHERE t.entity_id = P_ENTITY_ID
         AND t.customer_id = V_CUSTOMER_ID
         --AND t.sales_center_id = V_SALES_CENTER_ID
         and t.account_id = V_ACCOUNT_ID
         AND t.PERIOD_DATE = V_PERIOD_DATE
         AND nvl(t.confirm_flag,'N') <> 'E';

    ACCOUNT_ROW C_ACCOUNT%ROWTYPE; --客户、中心游标行数据
    CONF_ROW    C_ACCOUNT_CONF%ROWTYPE; --账号对账配置信息游标行数据
    ITEMCLASS_ROW C_ITEM_CLASS%ROWTYPE; --产品分类游标行数据
    RECEIPT_ROW  C_RECEIPT%ROWTYPE; --到款单游标行数据
    SO_ROW  C_SO%ROWTYPE;           --销售单游标行数据
    HIS_ROW C_HIS%ROWTYPE;           --对账历史游标行数据

    V_SOA_CONF_COUNT     NUMBER; --判断对账配置是否存在

    V_COUNT     NUMBER; --判断当前账期、账号是否已对账
    V_COUNT0    NUMBER; --判断到款表是否有处理单据
    V_COUNT1    NUMBER; --判断上一账期是否存在
    
    V_COUNT1_   NUMBER; --判断结束日期为上个月末的账单是否存在 add by huanghb12 2019-1-3
    V_COUNT2    NUMBER; --按品类判断到款行上一账期是否存在
    V_COUNT2_   NUMBER; --按品类判断到款行上以上个月末的为结束日期的张单是否存在 add by huanghb12 2019-1-3

    V_COUNT3    NUMBER; --判断销售表是否存在销售单据
    V_COUNT4    NUMBER; --按品类判断到款表是否有到款单据
    V_COUNT5    NUMBER; --按品类判断销售表是否有销售单据
    V_COUNT6    NUMBER; --按品类判断销售表是否有折让单据
    V_COUNT7    NUMBER; --按品类判断折扣行上一账期是否存在
    V_COUNT7_   NUMBER; --按品类判断折扣行上一账期的结束日期的账期是否存在 add by huanghb12 2019-1-8
    V_COUNT7__  NUMBER; --检查上一期对账单头是否存在 add by huanghb12 2019-2-14
    V_COUNT8    NUMBER; --判断NC对账类型是否存在
    V_COUNT9    NUMBER; --按品类判断到款表是否有到款差异单据
    V_COUNT10   NUMBER; --按品类判断销售表是否有销售差异单据
    V_COUNT11   NUMBER; --按品类判断销售表是否有折让差异单据
    --V_COUNT12   NUMBER; --判断到款表是否有到款差异单据
    V_COUNT13   NUMBER; --判断销售表是否有销售差异单据
    V_COUNT14   NUMBER; --判断销售表是否有折让差异单据
    --V_COUNT15   NUMBER; --按品类判断到款表是否有到款差异单据
    V_COUNT16   NUMBER; --按品类判断销售表是否有销售差异单据
    V_COUNT17   NUMBER; --按品类判断销售表是否有折让差异单据

    V_AMOUNT_A NUMBER; --获取的期初余额
    V_AMOUNT_A2 NUMBER; --计算出的期初余额
    V_AMOUNT_B NUMBER; --本期到款金额
    V_AMOUNT_C NUMBER; --累计金额  C=A+B
    V_AMOUNT_D NUMBER; --本期累计到款  D = B
    V_AMOUNT_E NUMBER; --到款提货金额
    V_AMOUNT_E2 NUMBER;  --计算到款提货金额（考虑了总期内结算的销售差异数据） add by huanghb12 2019-1-8
    V_AMOUNT_F NUMBER; --本期到款余额  F = A + D - E
    V_AMOUNT_G NUMBER; --冻结金额
    V_AMOUNT_H NUMBER; --折让余额
    V_AMOUNT_I NUMBER; --应收账款余额
    V_AMOUNT_J NUMBER; --获取的期初折让余额
    V_AMOUNT_J2 NUMBER; --计算出的期初折让余额
    V_AMOUNT_K NUMBER; --本期折让金额
    V_AMOUNT_K2 NUMBER; --本期折让金额 add by huanghb12 2019-1-3
    V_AMOUNT_L NUMBER; --核销折让金额
    V_AMOUNT_L2 NUMBER; --核销折让金额 add by huanghb12 2019-1-3

    V_AMOUNT_SA  NUMBER; --获取总期初余额
    V_AMOUNT_SA2  NUMBER; --计算出的总期初余额
    V_AMOUNT_SB  NUMBER; --本期总到款金额
    V_AMOUNT_SE  NUMBER; --总到款提货金额
    V_AMOUNT_SE2 NUMBER; --计算总期提货金额 add by huanghb12 2019-1-8
    V_AMOUNT_SF  NUMBER; --本期总到款余额  F = A + D - E
    V_AMOUNT_SJ NUMBER; --获取的总期初折让余额
    V_AMOUNT_SJ2 NUMBER; --计算出的总期初折让余额
    V_AMOUNT_SK NUMBER; --本期总折让金额
    V_AMOUNT_SL NUMBER; --总核销折让金额
    V_AMOUNT_SL2 NUMBER; --计算总核销折让金额 add by huanghb12 2019-1-8
    V_AMOUNT_SH NUMBER; --总折让余额

    V_AMOUNT_U NUMBER; --未解付金额
    V_AMOUNT_US NUMBER; --总未解付金额
    
    V_AMOUNT_TRX1  NUMBER; --未开票金额1
    V_AMOUNT_TRX2  NUMBER; --未开票金额2
    
    --V_AMOUNT_LOCI  NUMBER; --锁定金额期初
    V_AMOUNT_LOCC  NUMBER; --本期锁定金额
    V_AMOUNT_LOCE  NUMBER; --本期期末金额
    
    
    --D_AMOUNT_SD NUMBER; --本期到款差异总和
    D_AMOUNT_SE NUMBER; --本期到款提货差异总和
    D_AMOUNT_SL NUMBER; --本期核销折让差异总和
    D_AMOUNT_SK NUMBER; --本期折让差异总和
    --D_AMOUNT_D NUMBER; --按品类计算本期到款差异总和
    D_AMOUNT_E NUMBER; --按品类计算本期到款提货差异总和
    D_AMOUNT_L NUMBER; --按品类计算本期核销折让差异总和
    D_AMOUNT_K NUMBER; --按品类计算本期折让差异总和

    V_SOA_COUNT_BATCH_ID NUMBER; --本次对账批次ID
    V_ORDER_NUMBER       VARCHAR2(20); --对账单号

    V_RECEIPT_AMOUNT   NUMBER;    --判断到款金额是否存在差异
    V_SO_AMOUNT   NUMBER;    --判断销售金额是否存在差异
    V_DIS_AMOUNT   NUMBER;    --判断返利（折让）金额是否存在差异

    V_RESULT VARCHAR2(2000); --自定义返回信息
    V_RESULT2 VARCHAR2(2000); --自定义返回信息
    V_ERR_EXCEPT EXCEPTION; --异常信息

    V_SOA_TITLE VARCHAR2(100); --对账头
    V_SOA_PRODUCE_DAY NUMBER; --产生天
    V_SOA_SEND_DAY NUMBER; --发送天
    V_SOA_COUNT_C   NUMBER; --对账单数

    V_ACCOUNT_CONF VARCHAR2(100); --是否自动配置对账单
    --2017-02-07 tianmzh add 
    V_IS_AUTO_FLAG VARCHAR2(2); --是否自动确认无业务往来的对账单
    V_ACC_CONFIRM_FLAG VARCHAR2(2); --是否自动确认系统参数
    V_PUB_FIN_SYS  varchar2(32);
  BEGIN
    P_RESULT := V_SUCCESS;
    V_DISCOUNT_TYPE_COMMON := 'COMMON';

    IF P_ENTITY_ID IS NULL
    OR P_CUSTOMER_ID IS NULL
    --OR P_SALES_CENTER_ID IS NULL
    OR P_ACCOUNT_ID IS NULL
    OR P_COUNT_START_DATE IS NULL
    OR P_COUNT_END_DATE IS NULL THEN
      V_RESULT := '传入参数错误，存在空值参数';
      P_RESULT := V_RESULT;
       RAISE V_ERR_EXCEPT;
    END IF;

     IF P_ENTITY_ID IS NOT NULL
    AND P_CUSTOMER_ID IS NOT NULL
    --AND P_SALES_CENTER_ID IS NOT NULL
    OR P_ACCOUNT_ID IS NULL
    AND P_COUNT_START_DATE IS NOT NULL
    AND P_COUNT_END_DATE IS NOT NULL THEN

        V_ACCOUNT_CONF:= PKG_BD.F_GET_PARAMETER_VALUE('AR_AUTO_ACCOUNT_CONF', P_ENTITY_ID, NULL, NULL);
        V_PUB_FIN_SYS:= PKG_BD.F_GET_PARAMETER_VALUE('PUB_FIN_SYS', P_ENTITY_ID , NULL, NULL); 
     IF V_ACCOUNT_CONF = 'Y' THEN
             FOR RESULT_BATCH_ROW IN (
                    SELECT
                         CODE_VALUE
                    FROM
                         CIMS.V_UP_CODELIST
                    WHERE
                         CODETYPE = 'ACCOUNTBALANCE_TYPE'
                     AND ENTITY_ID = P_ENTITY_ID
                )LOOP
                       BEGIN

                            SELECT
                              COUNT(1)
                            INTO
                               V_SOA_COUNT_C
                            FROM
                               CIMS.T_AR_CUSG_SOA_CONF
                            WHERE ENTITY_ID = P_ENTITY_ID
                            AND CUSTOMER_ID = P_CUSTOMER_ID
                            AND ACCOUNT_ID = P_ACCOUNT_ID
                            and ORDER_TYPE = RESULT_BATCH_ROW.CODE_VALUE;

                            IF V_SOA_COUNT_C = 0 THEN
                               SELECT
                                   TITLE
                                   ,SOA_PRODUCE_DAY
                                   ,SOA_SEND_DAY
                                INTO
                                    V_SOA_TITLE
                                   ,V_SOA_PRODUCE_DAY
                                   ,V_SOA_SEND_DAY
                               FROM
                                   CIMS.T_AR_CUSG_SOA_CONF
                               WHERE
                                    ENTITY_ID = P_ENTITY_ID
                                AND ORDER_TYPE = RESULT_BATCH_ROW.CODE_VALUE
                                AND ROWNUM = 1;

                               INSERT INTO  T_AR_CUSG_SOA_CONF
                                            (SOA_CONF_ID,
                                            CUSTOMER_ID,
                                            CUSTOMER_CODE,
                                            CUSTOMER_NAME,
                                            SALES_CENTER_ID,
                                            ORDER_TYPE,
                                            HANDMADE_INPUT_FLAG,
                                            CREATED_BY,
                                            CREATION_DATE,
                                            LAST_UPDATED_BY,
                                            LAST_UPDATE_DATE,
                                            SOA_PRODUCE_DAY,
                                            SOA_SEND_DAY,
                                            ENTITY_ID,
                                            TITLE,
                                            COMMENT_INFO,
                                            SALES_CENTER_CODE,
                                            SALES_CENTER_NAME,
                                            CUSTOMER_MAIL,
                                                ACCOUNT_ID,
                                          ACCOUNT_CODE
                                            )
                                            SELECT S_AR_CUSG_SOA_CONF.NEXTVAL,
                                            CUSTOMER_ID,
                                            CUSTOMER_CODE,
                                            CUSTOMER_NAME,
                                            SALES_CENTER_ID,
                                            RESULT_BATCH_ROW.CODE_VALUE,
                                            'Y',
                                            'sys',
                                            sysdate,
                                            '',
                                            '',
                                            V_SOA_PRODUCE_DAY,
                                            V_SOA_SEND_DAY,
                                            ENTITY_ID,
                                            (case when V_PUB_FIN_SYS='NC' 
                                                 THEN  
                                                    (select NAME from intf_nc_org_unit ncg where ncg.CODE=SALES_CENTER_CODE and rownum=1)
                                                 ELSE  V_SOA_TITLE
                                                END),
                                            '',
                                            SALES_CENTER_CODE,
                                            SALES_CENTER_NAME,
                                            CUSTOMER_MAIL,
                                            account_id,
                                            account_code
                                      from (select 
                                             c.customer_id
                                            ,c.customer_code
                                            ,a.customer_name
                                            ,a.customer_mail
                                            ,c.sales_center_id
                                            ,c.sales_center_code
                                            ,c.sales_center_name
                                            ,c.entity_id
                                            ,c.account_id,
                                             c.account_code
                                          from 
                                               t_customer_header a
                                              ,v_customer_account_salecenter c
                                          where 
                                                c.customer_id = a.customer_id 
                                          and   c.account_status = 1
                                          and   c.entity_id = P_ENTITY_ID
                                          AND   c.account_id = P_ACCOUNT_ID
                                          AND   c.customer_id = P_CUSTOMER_ID
                                         )u
                                    where /*customer_id||'-'||account_id||'-'||entity_id
                                          not in (
                                             select customer_id||'-'||ACCOUNT_ID||'-'||entity_id from T_AR_CUSG_SOA_CONF where entity_id =P_ENTITY_ID and ORDER_TYPE=RESULT_BATCH_ROW.CODE_VALUE
                                          )*/
                                          not exists (
                                              select 1
                                              from cims.T_AR_CUSG_SOA_CONF t
                                             where t.entity_id = u.entity_id
                                               and t.ORDER_TYPE = RESULT_BATCH_ROW.CODE_VALUE
                                               and t.customer_id = u.customer_id
                                               and t.account_id = u.account_id
                                          );
                                END IF;

                              EXCEPTION
                         WHEN OTHERS THEN
                                   V_RESULT:=  PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                           SQLCODE,
                                                           '对账单配置失败！主体:' || P_ENTITY_ID  || RESULT_BATCH_ROW.CODE_VALUE ||
                                                           substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);


                      END;
                 END LOOP;
         END IF;


    --检查客户配置表数据
    SELECT COUNT(*) into V_SOA_CONF_COUNT
      FROM T_CUSTOMER_ORG TCO,t_ar_cusg_soa_conf a
    WHERE TCO.Entity_Id = a.entity_id
      and TCO.Customer_Id = a.customer_id
      and TCO.Sales_Center_Id = a.sales_center_id
      and a.entity_id = P_ENTITY_ID
      and a.customer_id = P_CUSTOMER_ID
      and a.account_id = P_ACCOUNT_ID;

    if (V_SOA_CONF_COUNT = 0) then
       V_RESULT := '对账单配置(主体：'||P_ENTITY_ID||'、客户：'||P_CUSTOMER_ID||'、账户：'||P_ACCOUNT_ID||')不存在或配置不正确，请先维护对账单配置！';
       P_RESULT := V_RESULT;
       RAISE V_ERR_EXCEPT;
    end if;

    BEGIN

    --账期
    if (to_char(TRUNC(LAST_DAY(ADD_MONTHS(P_COUNT_END_DATE, -0))), 'yyyy-mm-dd') = to_char(P_COUNT_END_DATE, 'yyyy-mm-dd')) then
        select to_char(P_COUNT_END_DATE, 'yyyy-mm')
        INTO V_PERIOD_DATE
        FROM DUAL;
    else
        select to_char(P_COUNT_END_DATE, 'yyyy-mm-dd')
        INTO V_PERIOD_DATE
        FROM DUAL;
    end if;

    --账期期间1日
    select trunc(P_COUNT_START_DATE, 'mm')
      into V_PERIOD_START_DATE
      from dual;

    --账期期间的月份最大日期
    --SELECT TRUNC(LAST_DAY(ADD_MONTHS(P_COUNT_END_DATE, -0)))
    SELECT P_COUNT_END_DATE
      INTO V_PERIOD_END_DATE
      FROM DUAL;

    --账期结束时间下一天
    V_PERIOD_END_DATE2 := V_PERIOD_END_DATE + 1;

    --账期上一期间1日
    SELECT TRUNC(last_day(add_months(P_COUNT_START_DATE, -2)) + 1)
      INTO V_LAST_START_DATE
      FROM DUAL;

    --账期上一期间的月份最大日期
      SELECT TRUNC(LAST_DAY(ADD_MONTHS(P_COUNT_START_DATE, -1)))
      INTO V_LAST_END_DATE
      FROM DUAL;

      --第一层循环，获取账号信息
      FOR ACCOUNT_ROW IN C_ACCOUNT LOOP
        BEGIN
        V_CUSTOMER_ID     := ACCOUNT_ROW.customer_id;
        --V_SALES_CENTER_ID := ACCOUNT_ROW.sales_center_id;
        V_ACCOUNT_ID     := ACCOUNT_ROW.Account_Id;


      --删除重复数据
          FOR HIS_ROW IN C_HIS LOOP
          BEGIN
          /*delete FROM T_AR_STATEMENT_ACC_HISTORY t
         WHERE t.entity_id = ACCOUNT_ROW.entity_id
           AND t.customer_id = ACCOUNT_ROW.customer_id
           AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
           AND t.count_period = V_PERIOD_DATE;*/

           /*delete FROM T_AR_SOA_ORDER_RECEIPT_LINES b
          WHERE b.HEADER_ID = HIS_ROW.HEADER_ID;*/

           /*delete FROM T_AR_SOA_ORDER_DIS_LINES b
          WHERE b.HEADER_ID = HIS_ROW.HEADER_ID;*/

           /*delete FROM T_AR_SOA_ORDER_ADJUST_LINES b
          WHERE b.HEADER_ID = HIS_ROW.HEADER_ID;*/

           /*delete FROM T_AR_SOA_CUST_RECEIPT_HIS b
          WHERE b.SOA_COUNT_BATCH_ID = HIS_ROW.HEADER_ID;*/

          --单据状态更改为E：作废
          update T_AR_SOA_CUST_RECEIPT_HIS b set b.status = 'E'
           WHERE b.SOA_COUNT_BATCH_ID = HIS_ROW.HEADER_ID;

           /*delete FROM T_AR_SOA_DIS_ORDER_HIS b
          WHERE b.SOA_COUNT_BATCH_ID = HIS_ROW.HEADER_ID;*/

          --单据状态更改为E：作废
          update T_AR_SOA_DIS_ORDER_HIS b set b.diff_update_flag = 'E'
           WHERE b.SOA_COUNT_BATCH_ID = HIS_ROW.HEADER_ID;

           /*delete FROM T_AR_SOA_SO_ORDER_HIS b
          WHERE b.SOA_COUNT_BATCH_ID = HIS_ROW.HEADER_ID;*/

          --单据状态更改为E：作废
          update T_AR_SOA_SO_ORDER_HIS b set b.diff_update_flag = 'E'
           WHERE b.SOA_COUNT_BATCH_ID = HIS_ROW.HEADER_ID;

           /*delete FROM T_AR_SOA_ORDER_DETAILS b
          WHERE b.SOA_COUNT_BATCH_ID = HIS_ROW.HEADER_ID;*/

          update T_AR_SOA_ORDER_DETAILS b set b.diff_update_flag = 'E'
           WHERE b.SOA_COUNT_BATCH_ID = HIS_ROW.HEADER_ID;

           /*delete FROM T_AR_SOA_ORDER_DIFFERENCES b
          WHERE b.HEADER_ID = HIS_ROW.HEADER_ID;*/

           /*delete FROM T_AR_SOA_ORDER_HEADS t
          WHERE t.header_id = HIS_ROW.HEADER_ID;*/

          update T_AR_SOA_ORDER_HEADS t set t.confirm_flag = 'E'
           WHERE t.header_id = HIS_ROW.HEADER_ID;

          END;
          END LOOP;

       --判断到款表账期内是否存在数据
          SELECT COUNT(*)
            INTO V_COUNT0
            FROM v_ar_cash_receipt_header_lines t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
             AND t.REVIEWED_DATE >= V_PERIOD_START_DATE
             AND t.REVIEWED_DATE < V_PERIOD_END_DATE2;

       --判断销售表账期内是否存在销售数据
          SELECT COUNT(*)
            INTO V_COUNT3
            FROM T_SO_HEADER t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008','1009', '1010')
             AND t.so_status <> '10'
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

        --判断是否存在数据
        /*if (V_COUNT0 = 0 AND V_COUNT3 = 0)  THEN
          V_RESULT := '账户账期:[' || V_PERIOD_DATE || ']内无对账数据';
          P_RESULT := V_RESULT;*/

        --else

          --判断该账号在账期内是否已对账
        /* SELECT COUNT(*)
          INTO V_COUNT
          FROM T_AR_STATEMENT_ACC_HISTORY t
         WHERE t.entity_id = ACCOUNT_ROW.entity_id
           AND t.customer_id = ACCOUNT_ROW.customer_id
           AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
           AND t.count_period = V_PERIOD_DATE; */
        --该账号在账期内已对账
        /*if (V_COUNT > 0) THEN
          V_RESULT := '传入的客户或者中心本期已经计算过往来对账单信息，对账期间：【' || V_PERIOD_DATE || '】';
          P_RESULT := V_RESULT;
          --RAISE V_ERR_EXCEPT;
          --该账号在账期内未对账，生成对账单头表 */
       -- else

          SELECT COUNT(*)
            INTO V_COUNT1
            FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
             AND t.SOA_END_DATE = V_LAST_END_DATE
             AND nvl(t.confirm_flag,'N') <> 'E';
         --add by huanghb12 
          if (V_COUNT1 = 0) THEN
            --如果查询上个对账单不存在，则查询期末日期为上月对象结束日期的（年或者半年）对账单
            SELECT COUNT(*)
            INTO V_COUNT1_
            FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             --AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
             AND t.SOA_END_DATE = V_LAST_END_DATE
             AND nvl(t.confirm_flag,'N') <> 'E';
          else
            BEGIN
            --获取本期的期初余额（也就是上期期末余额）
            SELECT NVL(t.RECEIPT_AMOUNT,0),NVL(t.DISCOUNT_AMOUNT,0)
              INTO V_AMOUNT_SA,V_AMOUNT_SJ
              FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               AND t.account_id = ACCOUNT_ROW.account_id
               AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
               AND t.SOA_END_DATE = V_LAST_END_DATE
               AND nvl(t.confirm_flag,'N') <> 'E';
            EXCEPTION
              WHEN OTHERS THEN
                V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                   SQLCODE,
                                                   '获取期初余额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id||
                                                   ',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                   substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                P_RESULT := V_RESULT;
                --RAISE V_ERR_EXCEPT;
                V_AMOUNT_SA := V_AMOUNT_SA2;
                V_AMOUNT_SJ := V_AMOUNT_SJ2;
                CONTINUE;
            END;
          end if;
          --如果上期对账单和以上期期末日期为结束日期的对账单都不存在
          IF V_COUNT1 = 0 and V_COUNT1_ = 0 THEN
            --计算总期余额
            
            --1）获取总期累计到款余额
            SELECT NVL(SUM(NVL(t.amount, 0)), 0)
              INTO V_AMOUNT_SA2
              FROM v_ar_cash_receipt_header_lines t
             WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               AND t.account_id = ACCOUNT_ROW.account_id
               AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
               --AND t.REVIEWED_DATE >= V_LAST_START_DATE
               AND t.REVIEWED_DATE < V_PERIOD_START_DATE;
               
             --2）获取总期提货金额
            --2.1）计算总期提货金额（考虑了总期内结算的差异数据）
            SELECT NVL(SUM(NVL(t.settle_amount, 0) *
                           b.APPLIED_PLUS_MINUS_FLAG),
                       0)
              INTO V_AMOUNT_SE2
              FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
             WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               AND t.account_id = ACCOUNT_ROW.account_id
               AND t.bill_type_id = b.bill_type_id
               --AND b.Can_Applied_Flag = 'Y'
               AND t.so_status <> '10'
               AND t.BIZ_SRC_BILL_TYPE_CODE in
                   ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                    '1008')
               --AND t.so_date >= V_PERIOD_START_DATE
               AND t.so_date < V_PERIOD_START_DATE;
               
             --总期余额 = 总期累计到款余额 - 计算总期提货金额
             V_AMOUNT_SA := V_AMOUNT_SA2 - V_AMOUNT_SE2;
             --计算总期初折让余额
             --1）计算总期初折让余额
             
            SELECT NVL(SUM(NVL(t.settle_amount, 0) *
                           b.APPLIED_PLUS_MINUS_FLAG),
                       0)
              INTO V_AMOUNT_SJ2 --总期折让金额（考虑了差异数据）
              FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
             WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               AND t.account_id = ACCOUNT_ROW.account_id
               AND t.bill_type_id = b.bill_type_id
               --AND b.Can_Applied_Flag = 'Y'
               AND t.so_status <> '10'
               AND t.BIZ_SRC_BILL_TYPE_CODE in ('1009', '1010')
               --AND t.SO_DATE >= V_LAST_START_DATE
                AND t.SO_DATE < V_PERIOD_START_DATE;
                
          --2）计算总期核销折让金额
          SELECT NVL(SUM(NVL(t.discount_amount, 0) *
                         b.APPLIED_PLUS_MINUS_FLAG),
                     0)
            INTO V_AMOUNT_SL2
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.bill_type_id = b.bill_type_id
             --AND b.Can_Applied_Flag = 'Y'
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             --AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_START_DATE;

             --总期折让总金额 = 计算总期折让总余额  - 计算总期核销折让金额
             V_AMOUNT_SJ := V_AMOUNT_SJ2 - V_AMOUNT_SL2;    
          ELSIF V_COUNT1 = 0 and V_COUNT1_ != 0  then
            BEGIN
            --获取期初余额
            select AMOUNT_SA,AMOUNT_SJ
                   INTO V_AMOUNT_SA,V_AMOUNT_SJ
             from (
              SELECT NVL(t.RECEIPT_AMOUNT,0) AMOUNT_SA,NVL(t.DISCOUNT_AMOUNT,0) AMOUNT_SJ
                FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               AND t.account_id = ACCOUNT_ROW.account_id
               --AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
               AND t.SOA_END_DATE = V_LAST_END_DATE
               AND nvl(t.confirm_flag,'N') <> 'E'
               order by t.SOA_BEGIN_DATE asc
               ) where rownum = 1;
            
            EXCEPTION
              WHEN OTHERS THEN
                V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                   SQLCODE,
                                                   '获取期初余额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id||
                                                   ',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                   substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                P_RESULT := V_RESULT;
                --RAISE V_ERR_EXCEPT;
                V_AMOUNT_SA := V_AMOUNT_SA2;
                V_AMOUNT_SJ := V_AMOUNT_SJ2;
                CONTINUE;
            END;   
          END IF;
          --end by huanghb12

        --计算本期到款金额
          SELECT NVL(SUM(NVL(t.amount, 0)), 0)
            INTO V_AMOUNT_SB
            FROM v_ar_cash_receipt_header_lines t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
             AND t.REVIEWED_DATE >= V_PERIOD_START_DATE
             AND t.REVIEWED_DATE < V_PERIOD_END_DATE2;

          --判断上期是否存在修改销售单据原始数据
            SELECT COUNT(*)
              INTO V_COUNT13
              FROM cims.t_so_header t,cims.T_AR_SOA_SO_ORDER_HIS b
             WHERE t.so_num = b.order_number AND t.settle_amount <> b.amount
               AND t.Entity_Id = ACCOUNT_ROW.entity_id
               AND t.Customer_Id = ACCOUNT_ROW.customer_id
               --AND t.Sales_Center_Id = V_SALES_CENTER_ID
               AND t.account_id = ACCOUNT_ROW.account_id
               --AND t.SO_DATE >= V_LAST_START_DATE  --去掉日期限制 guibr 存在跨两月结算单据
               AND t.SO_DATE < V_PERIOD_START_DATE
               AND t.settle_date >= V_PERIOD_START_DATE
                 AND t.settle_date < V_PERIOD_END_DATE2
               AND nvl(b.diff_update_flag,'N') <> 'E';

             if (V_COUNT13 > 0) THEN
                SELECT (NVL(SUM(NVL(t.settle_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0) - NVL(SUM(NVL(b.amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0)),
                       (NVL(SUM(NVL(t.discount_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0) - NVL(SUM(NVL(b.dis_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0))
                  INTO D_AMOUNT_SE,D_AMOUNT_SL
                  FROM cims.t_so_header t,cims.T_AR_SOA_SO_ORDER_HIS b ,cims.T_SO_TYPE_EXTEND e
                 WHERE t.so_num = b.order_number AND t.bill_type_id = e.bill_type_id
                   AND t.settle_amount <> b.amount
                   AND t.Entity_Id = ACCOUNT_ROW.entity_id
                   AND t.Customer_Id = ACCOUNT_ROW.customer_id
                   --AND t.Sales_Center_Id = V_SALES_CENTER_ID
                   AND t.account_id = ACCOUNT_ROW.account_id
                 --  AND t.SO_DATE >= V_LAST_START_DATE  --去掉日期限制 guibr 存在跨两月结算单据
                   AND t.SO_DATE < V_PERIOD_START_DATE
                   AND t.settle_date >= V_PERIOD_START_DATE
                     AND t.settle_date < V_PERIOD_END_DATE2
                   AND nvl(b.diff_update_flag,'N') <> 'E';
             else
               D_AMOUNT_SE := 0;
               D_AMOUNT_SL := 0;
             end if;

          --计算到款提货金额
          SELECT (NVL(SUM(NVL(t.settle_amount, 0) *
                         b.APPLIED_PLUS_MINUS_FLAG),
                     0) + D_AMOUNT_SE)
            INTO V_AMOUNT_SE
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.bill_type_id = b.bill_type_id
             --AND b.Can_Applied_Flag = 'Y'
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

          --计算本期到款余额  F = A + D - E
          V_AMOUNT_SF := V_AMOUNT_SA + V_AMOUNT_SB - V_AMOUNT_SE;

          --判断上期是否存在修改折让单据原始数据
            SELECT COUNT(*)
              INTO V_COUNT14
              FROM cims.t_so_header t,cims.T_AR_SOA_DIS_ORDER_HIS b
             WHERE t.so_num = b.order_number AND t.discount_amount <> b.dis_amount
               AND t.Entity_Id = ACCOUNT_ROW.entity_id
               AND t.Customer_Id = ACCOUNT_ROW.customer_id
               --AND t.Sales_Center_Id = V_SALES_CENTER_ID
               AND t.account_id = ACCOUNT_ROW.account_id
              -- AND t.SO_DATE >= V_LAST_START_DATE  --去掉日期限制 guibr 存在跨两月结算单据
               AND t.SO_DATE < V_PERIOD_START_DATE
               AND t.settle_date >= V_PERIOD_START_DATE
                 AND t.settle_date < V_PERIOD_END_DATE2
               AND nvl(b.diff_update_flag,'N') <> 'E';

             if (V_COUNT14 > 0) THEN
                SELECT (NVL(SUM(NVL(t.discount_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0) - NVL(SUM(NVL(b.dis_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0))
                  INTO D_AMOUNT_SK
                  FROM cims.t_so_header t,cims.T_AR_SOA_DIS_ORDER_HIS b ,cims.T_SO_TYPE_EXTEND e
                 WHERE t.so_num = b.order_number AND t.bill_type_id = e.bill_type_id
                   AND t.discount_amount <> b.dis_amount
                   AND t.Entity_Id = ACCOUNT_ROW.entity_id
                   AND t.Customer_Id = ACCOUNT_ROW.customer_id
                   --AND t.Sales_Center_Id = V_SALES_CENTER_ID
                   AND t.account_id = ACCOUNT_ROW.account_id
                  -- AND t.SO_DATE >= V_LAST_START_DATE  --去掉日期限制 guibr 存在跨两月结算单据
                   AND t.SO_DATE < V_PERIOD_START_DATE
                   AND t.settle_date >= V_PERIOD_START_DATE
                     AND t.settle_date < V_PERIOD_END_DATE2
                   AND nvl(b.diff_update_flag,'N') <> 'E';
             else
               D_AMOUNT_SK := 0;
             end if;

          --计算本期折让金额
          SELECT (NVL(SUM(NVL(t.settle_amount, 0) *
                         b.APPLIED_PLUS_MINUS_FLAG),
                     0) + D_AMOUNT_SK)
            INTO V_AMOUNT_SK
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.bill_type_id = b.bill_type_id
             --AND b.Can_Applied_Flag = 'Y'
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in ('1009', '1010')
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

          --计算本期核销折让金额
          SELECT (NVL(SUM(NVL(t.discount_amount, 0) *
                         b.APPLIED_PLUS_MINUS_FLAG),
                     0) + D_AMOUNT_SL)
            INTO V_AMOUNT_SL
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.bill_type_id = b.bill_type_id
             --AND b.Can_Applied_Flag = 'Y'
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

          --计算本期折让余额
          V_AMOUNT_SH := V_AMOUNT_SJ + V_AMOUNT_SK - V_AMOUNT_SL;


          --计算三方承兑未解付汇总
          /*SELECT NVL(SUM(NVL(t.UN_SOLUTION_AMOUNT, 0)), 0)
            INTO V_AMOUNT_US
            FROM V_AR_CASH_RECEIPT_UN_SOLU t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_code = ACCOUNT_ROW.customer_code
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
             AND t.REVIEWED_DATE >= V_PERIOD_START_DATE
             AND t.REVIEWED_DATE < V_PERIOD_END_DATE2;*/

             -- add by tangfeng
             select sum(un_solution_amount)
             INTO V_AMOUNT_US
             FROM(
             select nvl(l.amount,0) - nvl (acc.solution_pay_amount, 0) un_solution_amount
             from cims.t_ar_cash_receipt_headers h
             left join cims.t_ar_cash_receipt_lines l on l.cash_receipt_id = h.cash_receipt_id
             left join (SELECT p.CASH_RECEIPT_LINES_ID, nvl(SUM(p.SOLUTION_PAY_AMOUNT), 0) AS SOLUTION_PAY_AMOUNT
                       FROM cims.t_ar_acce_solu_pay p
                       WHERE p.solution_pay_status in ('2', '3') and p.solution_pay_time < V_PERIOD_END_DATE2
                       GROUP BY p.CASH_RECEIPT_LINES_ID) acc
                  on acc.cash_receipt_lines_id = l.cash_receipt_lines_id
             left join cims.t_ar_receipt_methods m on h.receipt_method_id = m.receipt_method_id
             where h.receipt_status_id not in (0,1,2,10,12,19) and m.receipt_type = '3'
             and h.entity_id = ACCOUNT_ROW.entity_id
             AND h.customer_code = ACCOUNT_ROW.customer_code
             AND h.account_id = ACCOUNT_ROW.account_id
             AND h.REVIEWED_DATE < V_PERIOD_END_DATE2);

             /**select sum(un_solution_amount)
             INTO V_AMOUNT_US
             FROM(
             select nvl(l.amount,0) - sum (nvl (acc.solution_pay_amount, 0)) un_solution_amount
             from cims.t_ar_cash_receipt_headers h left join cims.t_ar_cash_receipt_lines l on l.cash_receipt_id = h.cash_receipt_id
             left join cims.t_ar_acce_solu_pay acc on acc.cash_receipt_lines_id = l.cash_receipt_lines_id and acc.solution_pay_status in ('2', '3') and acc.solution_pay_time < V_PERIOD_END_DATE2
             left join cims.t_ar_receipt_methods m on h.receipt_method_id = m.receipt_method_id
             where h.receipt_status_id not in (0,1,2,10,12,19) and m.receipt_type = '3'
             and h.entity_id = ACCOUNT_ROW.entity_id
             AND h.customer_code = ACCOUNT_ROW.customer_code
             AND h.account_id = ACCOUNT_ROW.account_id
             group by l.cash_receipt_lines_id,l.amount);**/

        --获取确认式往来对账单头ID
          SELECT S_AR_SOA_ORDER_HEADS.NEXTVAL
            INTO V_SOA_COUNT_BATCH_ID
            FROM DUAL;

          --生成对账单号
          /*V_ORDER_NUMBER := 'SD' || replace(V_PERIOD_DATE, '-', '') ||
          substr(('000000' ||to_char(V_SOA_COUNT_BATCH_ID)),length('000000' || to_char(V_SOA_COUNT_BATCH_ID))-5,6);*/

          BEGIN
            V_ORDER_NUMBER := PKG_BD.F_GET_BILL_NO('ARBICODE',
                                                        'SD',
                                                        P_ENTITY_ID,
                                                        null);
          EXCEPTION
            WHEN OTHERS THEN
              V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                  SQLCODE,
                                                  '生成对账单据号失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') ||',账期:' || V_PERIOD_DATE || '！:' ||
                                                  substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
              CONTINUE;
          END;

        BEGIN
            --RAISE V_ERR_EXCEPT;

            --插入确认式往来对账单头表
            INSERT INTO T_AR_SOA_ORDER_HEADS
              (HEADER_ID, --对账单ID
               CUSTOMER_ID, --客户ID
               CUSTOMER_CODE, --客户编码
               CUSTOMER_NAME, --客户名称
               SALES_CENTER_ID, --中心ID
               ORDER_DATE, --对账单日期
               ORDER_NUMBER, --对账单号
               ORDER_TYPE, --对账单类型
               CONFIRM_USER_ID, --客户确认人ID
               CONFIRM_USER_NAME, --客户确认人名称
               CONFIRM_FLAG, --客户确认标志
               PRINT_FLAG, --打印标志
               PRINTER_BY, --最后一次打印人员ID
               PRINT_DATE, --最后一次打印日期
               RECEIPT_AMOUNT, --本期到款余额
               DISCOUNT_AMOUNT, --本期折让余额
               COMMENT_INFO, --备注
               ENTITY_ID, --主体
               CREATED_BY, --创建人
               CREATION_DATE, --创建时间
               LAST_UPDATED_BY, --最后更新人
               LAST_UPDATE_DATE, --最后更新时间
               SOA_COUNT_BATCH_ID,
               PERIOD_DATE, --对账期间
               SOA_BEGIN_DATE, --对账开始日期
               SOA_END_DATE, --对账结束日期
               CLOSE_FLAG,
               EXECUTE_MODE, --手工录入标志
               ACCOUNT_ID,
               ACCOUNT_CODE,
               ACCOUNT_NAME,
               ORDER_STATE,
               UN_SOLUTION_AMOUNT,
               COMPANY_RISE,
               SEND_CCS_FLAG
               )
            VALUES
              (V_SOA_COUNT_BATCH_ID,
               ACCOUNT_ROW.CUSTOMER_ID,
               ACCOUNT_ROW.CUSTOMER_CODE,
               ACCOUNT_ROW.CUSTOMER_NAME,
               /* (select distinct w.CUSTOMER_NAME
                  from cims.T_CUSTOMER_ORG t,cims.t_customer_header w
                 where t.customer_id = w.customer_id
                   and t.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                   and t.SALES_CENTER_ID = ACCOUNT_ROW.SALES_CENTER_ID
                   and t.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID), */
               ACCOUNT_ROW.SALES_CENTER_ID,
               SYSDATE,
               V_ORDER_NUMBER, -- 对账单号存疑
               /*NVL((select CSC.ORDER_TYPE
                                    from T_AR_CUSG_SOA_CONF CSC
                                   where CSC.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                                     and CSC.SALES_CENTER_ID = ACCOUNT_ROW.SALES_CENTER_ID
                                     and CSC.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID),
                                  '1'),*/
               '余额确认式', --头表对账单类型    确认式
               NULL, --客户确认人ID
               NULL, --客户确认人名称
               'N', --客户确认标志
               'N', --打印标志
               NULL, --最后一次打印人员ID
               NULL, --最后一次打印日期
               V_AMOUNT_SF, --本期总到款余额
               V_AMOUNT_SH, --本期总折让余额
               NULL, --备注
               ACCOUNT_ROW.ENTITY_ID, --主体
               --P_USER_CODE CREATED_BY, --创建人
               NULL, --创建人
               SYSDATE, --创建时间
               NULL, --最后更新人
               NULL, --最后更新时间
               V_SOA_COUNT_BATCH_ID,
               V_PERIOD_DATE,
               V_PERIOD_START_DATE,
               V_PERIOD_END_DATE,
               'N',
               'N',                      -- '系统生成',
               ACCOUNT_ROW.ACCOUNT_ID,
               (select distinct w.ACCOUNT_CODE
                  from v_customer_account_conf w
                 where w.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                   and w.ACCOUNT_ID = ACCOUNT_ROW.ACCOUNT_ID
                   and w.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID),
               (select distinct w.ACCOUNT_NAME
                  from v_customer_account_conf w
                 where w.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                   and w.ACCOUNT_ID = ACCOUNT_ROW.ACCOUNT_ID
                   and w.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID),
               /* (select distinct w.ACCOUNT_ID
                  from v_cust_account w
                 where w.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                   and w.SALES_CENTER_ID = ACCOUNT_ROW.SALES_CENTER_ID
                   and w.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID),
               (select distinct w.ACCOUNT_CODE
                  from v_cust_account w
                 where w.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                   and w.SALES_CENTER_ID = ACCOUNT_ROW.SALES_CENTER_ID
                   and w.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID),
               (select distinct w.ACCOUNT_NAME
                  from v_cust_account w
                 where w.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                   and w.SALES_CENTER_ID = ACCOUNT_ROW.SALES_CENTER_ID
                   and w.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID),*/
               'Y',
               V_AMOUNT_US,
               ACCOUNT_ROW.Title,
               'Y'
               );
              
               --2017-02-06 tianmzh add 增加判断，根据主体+客户+账户获取对账配置表中是否自动确认标志，Y-自动确认；N-不自动确认。
               --获取系统参数配置：0-按对账配置表中的是否自动确认标志控制、1-自动确认、2-不自动确认'
               PKG_BD.P_GET_PARAMETER_VALUE('ar_account_confirm_flag',
                                   ACCOUNT_ROW.ENTITY_ID,
                                   '',
                                   '',
                                   V_ACC_CONFIRM_FLAG);
               BEGIN
                 SELECT NVL(TC.IS_AUTO_FLAG, 'N')
                   INTO V_IS_AUTO_FLAG
                   FROM CIMS.T_AR_CUSG_SOA_CONF TC
                  WHERE TC.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID
                    AND TC.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                    AND TC.ACCOUNT_ID = ACCOUNT_ROW.ACCOUNT_ID
                    --2017-02-22 tianmzh增加，防止一个客户多条配置数据时报错
                    AND ROWNUM = 1;
               EXCEPTION
                 --若没有查询到数据，则默认对账单自动确认
                 WHEN NO_DATA_FOUND THEN
                   V_IS_AUTO_FLAG := 'Y';
               END;

             IF V_COUNT0=0 and  V_COUNT3 =0 AND (V_ACC_CONFIRM_FLAG = '1' OR (V_ACC_CONFIRM_FLAG = '0' AND V_IS_AUTO_FLAG = 'Y')) then
                   update T_AR_SOA_ORDER_HEADS set
                        CONFIRM_DATE = sysdate
                        ,CONFIRM_FLAG = 'Y'
                        ,CONFIRM_USER_ID = 0
                        ,CONFIRM_USER_NAME = 'cims'
                        ,CENTER_CHECK_FLAG='Y'
                        ,CENTER_CHECK_DATE = sysdate
                        ,ORDER_TYPE='系统自动确认'
                        ,COMMENT_INFO='客户本期对账期间，无业务往来或者业务单据金额合计为0，系统自动确认'
                   where HEADER_ID = V_SOA_COUNT_BATCH_ID;
            END IF;


          EXCEPTION
            WHEN OTHERS THEN
              V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                 SQLCODE,
                                                 '插入确认式往来对账单头表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') ||',账期:' || V_PERIOD_DATE || '！:' ||
                                                 substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
              P_RESULT := V_RESULT;
              --RAISE V_ERR_EXCEPT;

              --插入往来对账客户表
              V_RESULT2 := PKG_AR_ACCOUNT.F_ADD_SOA_HISTORY
              (NULL,
               ACCOUNT_ROW.CUSTOMER_ID,
               ACCOUNT_ROW.CUSTOMER_CODE,
               ACCOUNT_ROW.CUSTOMER_NAME,
               NULL,
               ACCOUNT_ROW.SALES_CENTER_ID,
               'N',
               V_PERIOD_START_DATE,
               V_PERIOD_END_DATE,
               V_PERIOD_DATE,
               --NVL(CSC.ORDER_TYPE, '余额确认式'),
               NULL,
               V_ORDER_NUMBER,
               NULL,
               NULL,
               NULL,
               'FAILURE',
               V_RESULT,
               NULL,
               ACCOUNT_ROW.ENTITY_ID,
               NULL,
               SYSDATE,
               NULL,
               NULL,
               V_SOA_COUNT_BATCH_ID);
              /*
            INSERT INTO T_AR_STATEMENT_ACC_HISTORY
              (ACC_HISTORY_ID,
               HEADER_ID,
               CUSTOMER_ID,
               CUSTOMER_CODE,
               CUSTOMER_NAME,
               CUSTOMER_FLAG,
               SALES_CENTER_ID,
               HANDMODE_FLAG,
               COUNT_START_DATE,
               COUNT_END_DATE,
               COUNT_PERIOD,
               ORDER_TYPE,
               ORDER_NUMBER,
               SOA_RECEIPT_BATCH_ID,
               SOA_SO_ORDER_BATHC_ID,
               SOA_DISCOUNT_BACHT_ID,
               STATES,
               COUNT_RESULT,
               COMMENTS,
               ENTITY_ID,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE,
               SOA_COUNT_BATCH_ID)
            VALUES
              (S_AR_STATEMENT_ACC_HISTORY.NEXTVAL,
               NULL,
               ACCOUNT_ROW.CUSTOMER_ID,
               ACCOUNT_ROW.CUSTOMER_CODE,
               NULL,
               NULL,
               ACCOUNT_ROW.SALES_CENTER_ID,
               'N',
               V_PERIOD_START_DATE,
               V_PERIOD_END_DATE,
               V_PERIOD_DATE,
               --NVL(CSC.ORDER_TYPE, '余额确认式'),
               NULL,
               V_ORDER_NUMBER,
               NULL,
               NULL,
               NULL,
               'FAILURE',
               V_RESULT,
               NULL,
               ACCOUNT_ROW.ENTITY_ID,
               NULL,
               SYSDATE,
               NULL,
               NULL,
               V_SOA_COUNT_BATCH_ID);
            COMMIT;
            */

              --EXIT; --退出当前循环
              CONTINUE;
          END;

          SELECT COUNT(*)
            INTO V_COUNT8
            FROM t_ar_cusg_soa_conf t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.order_type = '3';

           if (V_COUNT8 > 0) THEN
             BEGIN
                --插入调节试对账单行表
                INSERT INTO T_AR_SOA_ORDER_ADJUST_LINES
                  (ADJUST_LINE_ID, --行ID
                   HEADER_ID, --对账单头ID
                   DEBIT_PERIOD_AMOUNT, --借方期初余额(合计)
                   PRODUCT_AR_DEBIT_PERIOD_AMOUNT, --应收借方期初额（成品）
                   FITTING_AR_DEBIT_PERIOD_AMOUNT, --应收借方期初额（配件）
                   AR_DEBIT_AMOUNT,                --本期借方发生额（合计）
                   PRODUCT_AR_DEBIT_AMOUNT, --成品本期借方本期累计到款余额
                   PRODUCT_SALES_DEBIT_AMOUNT, --成品本期借方本期累计到款提贷金额
                   FITTING_AR_DEBIT_AMOUNT,    --配件本期借方本期累计到款余额
                   FITTING_SALES_DEBIT_AMOUNT, --配件本期借方本期累计到款提贷金额
                   ENTITY_ID, --主体ID
                   CREATED_BY, --创建人
                   CREATION_DATE, --创建日期
                   LAST_UPDATED_BY, --最后更新人
                   LAST_UPDATED_DATE） --最后更新日期)
                VALUES
                  (S_AR_SOA_ORDER_LINES.NEXTVAL,
                   V_SOA_COUNT_BATCH_ID,
                   (-1 * V_AMOUNT_SA + 0), --借方期初余额(合计)
                   -1 * V_AMOUNT_SA,   --应收借方期初额（成品）
                   0,            --应收借方期初额（配件）
                   (V_AMOUNT_SE - V_AMOUNT_SB + 0 - 0),         --本期借方发生额（合计）
                   V_AMOUNT_SB, --成品本期借方本期累计到款余额
                   V_AMOUNT_SE, --成品本期借方本期累计到款提贷金额
                   0,          --配件本期借方本期累计到款余额
                   0,          --配件本期借方本期累计到款提贷金额
                   ACCOUNT_ROW.ENTITY_ID,
                   NULL,
                   SYSDATE,
                   NULL,
                   NULL);

              EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                     SQLCODE,
                                                     '插入调节试对账单行表！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') ||',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
              END;

           end if;

          FOR ITEMCLASS_ROW IN C_ITEM_CLASS LOOP

          V_CLASS_CODE := ITEMCLASS_ROW.CLASS_CODE;
          V_DISCOUNT_TYPE := ITEMCLASS_ROW.DISCOUNT_TYPE;

          --按品类判断到款表账期内是否存在数据
          SELECT COUNT(*)
            INTO V_COUNT4
            FROM v_ar_cash_receipt_header_lines t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
             AND t.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
             AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             AND t.REVIEWED_DATE >= V_PERIOD_START_DATE
             AND t.REVIEWED_DATE < V_PERIOD_END_DATE2;

          --按品类判断销售表账期内是否存在销售数据
          SELECT COUNT(*)
            INTO V_COUNT5
            FROM T_SO_HEADER t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             AND t.so_status <> '10'
             AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
             AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

           --按品类判断销售表账期内是否存在折让数据
          SELECT COUNT(*)
            INTO V_COUNT6
            FROM T_SO_HEADER t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1009', '1010')
             AND t.so_status <> '10'
             AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
             AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

          --判断当前品类是否存在数据
          /*if (V_COUNT4 = 0 AND V_COUNT5 = 0 AND V_COUNT6 = 0) THEN
            V_RESULT := '账户无品类[' || ITEMCLASS_ROW.CLASS_CODE || ']的对账数据';
            P_RESULT := V_RESULT;*/

          --else
            --按品类判断上一账期数据是否存在
            SELECT COUNT(*)
              INTO V_COUNT2
              FROM T_AR_SOA_ORDER_RECEIPT_LINES b
             WHERE b.HEADER_ID = (SELECT MAX(t.HEADER_ID)
              FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               AND t.account_id = ACCOUNT_ROW.account_id
               AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
               AND t.SOA_END_DATE = V_LAST_END_DATE
               AND nvl(t.confirm_flag,'N') <> 'E')
               AND b.sales_main_name = ITEMCLASS_ROW.CLASS_CODE
               AND NVL(b.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE;

          --revised by huanghb12 2019-1-3
           if (V_COUNT2 = 0) THEN
            --按品类判断以本期开始日期为结束日期的账期数据是否存在
            SELECT COUNT(*)
              INTO V_COUNT2_
              FROM T_AR_SOA_ORDER_RECEIPT_LINES b
             WHERE b.HEADER_ID = (SELECT MAX(t.HEADER_ID)
              FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               and t.account_id = ACCOUNT_ROW.account_id
               --AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
               AND t.SOA_END_DATE = V_LAST_END_DATE
               AND nvl(t.confirm_flag,'N') <> 'E')
               AND b.sales_main_name = ITEMCLASS_ROW.CLASS_CODE
               AND NVL(b.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE;      
          else
            BEGIN
            --按品类获取期初余额
            SELECT NVL(b.CURRENT_AMOUNT,0)--,NVL(b.DEPOSIT_LOCK_AMOUNT,0)
              INTO V_AMOUNT_A--,V_AMOUNT_LOCI
              FROM T_AR_SOA_ORDER_RECEIPT_LINES b
             WHERE b.HEADER_ID = (SELECT MAX(t.HEADER_ID)
             FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               AND t.account_id = ACCOUNT_ROW.account_id
               AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
               AND t.SOA_END_DATE = V_LAST_END_DATE
               AND nvl(t.confirm_flag,'N') <> 'E')
               AND b.sales_main_name = ITEMCLASS_ROW.CLASS_CODE
               AND NVL(b.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE;
            EXCEPTION
              WHEN OTHERS THEN
                V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                   SQLCODE,
                                                   '获取期初余额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') ||',账期:' || V_PERIOD_DATE || '！:' ||
                                                   substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                P_RESULT := V_RESULT;
                --RAISE V_ERR_EXCEPT;
                V_AMOUNT_A := 0;
                CONTINUE;
            END;
          end if;
          
          IF V_COUNT2 = 0 and V_COUNT2_ = 0 THEN
               --按品类计算期初余额,以本期开始日期为结束日期的账期数据是否存在(本期之前所有的数据)
            SELECT NVL(SUM(NVL(t.amount, 0)), 0)
              INTO V_AMOUNT_A2
              FROM v_ar_cash_receipt_header_lines t
             WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               and t.account_id = ACCOUNT_ROW.account_id
               AND t.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
               AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
               AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
               --AND t.REVIEWED_DATE >= V_LAST_START_DATE
               AND t.REVIEWED_DATE < V_PERIOD_START_DATE;

          --按品类计算总期的到款提货金额
          SELECT NVL(SUM(NVL(t.settle_amount, 0) *
                         b.APPLIED_PLUS_MINUS_FLAG),
                     0)
            INTO V_AMOUNT_E2
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             and t.account_id = ACCOUNT_ROW.account_id
             AND t.bill_type_id = b.bill_type_id
             AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
              AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             --AND b.Can_Applied_Flag = 'Y'
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             --AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_START_DATE;

             --总期到款余额 = 计算总期到款余额 - 到款提货金额（考虑了总期内结算的销售差异数据）
             V_AMOUNT_A := V_AMOUNT_A2 - V_AMOUNT_E2;
             
             --计算总期锁定金额  
              /*SELECT NVL(SUM(NVL(D.APPROVAL_AMOUNT, 0)),0) 
                INTO  V_AMOUNT_LOCI
                FROM  T_CREDIT_DELAYPAY D 
                WHERE DELAYPAY_TYPE =10     --冻结保证金
                  AND BILL_STATUS = 3       --已审批
                  AND D.DUE_TIME IS NULL    --没过期
                 AND V_DISCOUNT_TYPE = V_DISCOUNT_TYPE_COMMON
                  AND D.entity_id = ACCOUNT_ROW.entity_id
                  AND D.customer_id = ACCOUNT_ROW.customer_id
                  AND D.account_id = ACCOUNT_ROW.account_id
                  AND D.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
                  --AND D.BILL_DATE >= V_LAST_START_DATE   
                  AND D.BILL_DATE < V_PERIOD_START_DATE;*/
                 
            ELSIF V_COUNT2 = 0 and V_COUNT2_ != 0 THEN
              BEGIN
                --按品类获取期初余额
                SELECT NVL(b.CURRENT_AMOUNT,0)--,NVL(b.DEPOSIT_LOCK_AMOUNT,0)
                  INTO V_AMOUNT_A--,V_AMOUNT_LOCI
                  FROM T_AR_SOA_ORDER_RECEIPT_LINES b
                 WHERE b.HEADER_ID = (SELECT MAX(t.HEADER_ID)
                 FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
                   AND t.customer_id = ACCOUNT_ROW.customer_id
                   --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                   and t.account_id = ACCOUNT_ROW.account_id
                   --AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
                   AND t.SOA_END_DATE = V_LAST_END_DATE
                   AND nvl(t.confirm_flag,'N') <> 'E')
                   AND b.sales_main_name = ITEMCLASS_ROW.CLASS_CODE
                    AND NVL(b.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE;
                EXCEPTION
                  WHEN OTHERS THEN
                     V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                   SQLCODE,
                                                   '获取期初余额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') ||',账期:' || V_PERIOD_DATE || '！:' ||
                                                   substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                P_RESULT := V_RESULT;
                    --RAISE V_ERR_EXCEPT;
                    V_AMOUNT_A := 0;
                    CONTINUE;
                END;
            END IF; 
            --end by huanghb12
            
          --按品类计算本期到款金额
          SELECT NVL(SUM(NVL(t.amount, 0)), 0)
            INTO V_AMOUNT_B
            FROM v_ar_cash_receipt_header_lines t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
             AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
             AND t.REVIEWED_DATE >= V_PERIOD_START_DATE
             AND t.REVIEWED_DATE < V_PERIOD_END_DATE2;

          --按品类计算累计金额  C=A+B
          V_AMOUNT_C := V_AMOUNT_A + V_AMOUNT_B;

          --按品类计算本期累计到款  D = B
          V_AMOUNT_D := V_AMOUNT_B;

          --按品类判断上期(本期结算)是否存在修改销售单据原始数据（本期结算，此前的销售单）
            SELECT COUNT(*)
              INTO V_COUNT16
              FROM cims.t_so_header t,cims.T_AR_SOA_SO_ORDER_HIS b
             WHERE t.so_num = b.order_number AND t.settle_amount <> b.amount
               AND t.Entity_Id = ACCOUNT_ROW.entity_id
               AND t.Customer_Id = ACCOUNT_ROW.customer_id
               --AND t.Sales_Center_Id = V_SALES_CENTER_ID
               AND t.account_id = ACCOUNT_ROW.account_id
               AND t.SALES_MAIN_TYPE = V_CLASS_CODE
               AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
            --   AND t.SO_DATE >= V_LAST_START_DATE  --去掉日期限制 guibr 存在跨两月结算单据
               AND t.SO_DATE < V_PERIOD_START_DATE
               AND t.settle_date >= V_PERIOD_START_DATE
                 AND t.settle_date < V_PERIOD_END_DATE2
               AND nvl(b.diff_update_flag,'N') <> 'E';

             if (V_COUNT16 > 0) THEN
                SELECT (NVL(SUM(NVL(t.settle_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0) - NVL(SUM(NVL(b.amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0)),
                       (NVL(SUM(NVL(t.discount_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0) - NVL(SUM(NVL(b.dis_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0))
                  INTO D_AMOUNT_E,D_AMOUNT_L
                  FROM cims.t_so_header t,cims.T_AR_SOA_SO_ORDER_HIS b ,cims.T_SO_TYPE_EXTEND e
                 WHERE t.so_num = b.order_number AND t.bill_type_id = e.bill_type_id
                   AND t.settle_amount <> b.amount
                   AND t.Entity_Id = ACCOUNT_ROW.entity_id
                   AND t.Customer_Id = ACCOUNT_ROW.customer_id
                   --AND t.Sales_Center_Id = V_SALES_CENTER_ID
                   AND t.account_id = ACCOUNT_ROW.account_id
                   AND t.SALES_MAIN_TYPE = V_CLASS_CODE
                   AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                  -- AND t.SO_DATE >= V_LAST_START_DATE --去掉日期限制 guibr 存在跨两月结算单据
                   AND t.SO_DATE < V_PERIOD_START_DATE
                   AND t.settle_date >= V_PERIOD_START_DATE
                     AND t.settle_date < V_PERIOD_END_DATE2
                   AND nvl(b.diff_update_flag,'N') <> 'E';
             else
               D_AMOUNT_E := 0;
               D_AMOUNT_L := 0;
             end if;

          --按品类计算本期到款提货金额
          SELECT (NVL(SUM(NVL(t.settle_amount, 0) *
                         b.APPLIED_PLUS_MINUS_FLAG),
                     0) + D_AMOUNT_E)
            INTO V_AMOUNT_E
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.bill_type_id = b.bill_type_id
             AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
             AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             --AND b.Can_Applied_Flag = 'Y'
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

          --计算本期到款余额  F = A + D - E
          V_AMOUNT_F := V_AMOUNT_A + V_AMOUNT_D - V_AMOUNT_E;

          --计算冻结金额
          V_AMOUNT_G := 0;

          --计算应收账款余额
          V_AMOUNT_I := -1 * V_AMOUNT_F;

          SELECT COUNT(*)
            INTO V_COUNT7
            FROM T_AR_SOA_ORDER_DIS_LINES b
           WHERE b.HEADER_ID = (SELECT MAX(t.HEADER_ID)
            FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
             AND t.SOA_END_DATE = V_LAST_END_DATE
             AND nvl(t.confirm_flag,'N') <> 'E')
             AND b.SALES_MAIN_ID = ITEMCLASS_ROW.ITEM_CLASS_ID
             AND NVL(b.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE;

          if (V_COUNT7 = 0) THEN
            --add huanghb12  按品类计算总期折让余额
            --检查是否存在对账头，如果存在对账头，但是(V_COUNT7 = 0)，说明行中没有对应的转款类型的单据
            SELECT COUNT(*)
             INTO V_COUNT7__
            FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
             AND t.SOA_END_DATE = V_LAST_END_DATE
             AND nvl(t.confirm_flag,'N') <> 'E';
             
            --如果存在对账头，但是(V_COUNT7 = 0)，说明行中没有对应的转款类型的单据
            IF (V_COUNT7__ > 0) THEN
              --则期初余额为0
              V_AMOUNT_J := 0;
            ELSIF (V_COUNT7__ = 0) THEN
              SELECT COUNT(*)
                INTO V_COUNT7_
                FROM T_AR_SOA_ORDER_DIS_LINES b
               WHERE b.HEADER_ID = (SELECT MAX(t.HEADER_ID)
                FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
                 AND t.customer_id = ACCOUNT_ROW.customer_id
                 --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                 and t.account_id = ACCOUNT_ROW.account_id
                 --AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
                 AND t.SOA_END_DATE = V_LAST_END_DATE
                 AND nvl(t.confirm_flag,'N') <> 'E')
                 AND b.SALES_MAIN_ID = ITEMCLASS_ROW.ITEM_CLASS_ID
                 AND NVL(b.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE;
                 
              if (V_COUNT7_ = 0) then
                 --按品类计算总期折让余额
                SELECT NVL(SUM(NVL(t.settle_amount, 0) *
                               b.APPLIED_PLUS_MINUS_FLAG),
                           0)
                  INTO V_AMOUNT_J2
                  FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
                 WHERE t.entity_id = ACCOUNT_ROW.entity_id
                   AND t.customer_id = ACCOUNT_ROW.customer_id
                   --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                   and t.account_id = ACCOUNT_ROW.account_id
                   AND t.bill_type_id = b.bill_type_id
                   AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
                    AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                   --AND b.Can_Applied_Flag = 'Y'
                   AND t.so_status <> '10'
                   AND t.BIZ_SRC_BILL_TYPE_CODE in ('1009', '1010')
                   --AND t.SO_DATE >= V_LAST_START_DATE
                   AND t.SO_DATE < V_PERIOD_START_DATE;

                  --按品类计算总期核销折让金额
                SELECT NVL(SUM(NVL(t.discount_amount, 0) *
                               b.APPLIED_PLUS_MINUS_FLAG),
                           0)
                  INTO V_AMOUNT_L2
                  FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
                 WHERE t.entity_id = ACCOUNT_ROW.entity_id
                   AND t.customer_id = ACCOUNT_ROW.customer_id
                   --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                   and t.account_id = ACCOUNT_ROW.account_id
                   AND t.bill_type_id = b.bill_type_id
                   AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
                    AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                   --AND b.Can_Applied_Flag = 'Y'
                   AND t.so_status <> '10'
                   AND t.BIZ_SRC_BILL_TYPE_CODE in
                       ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                        '1008')
                   --AND t.so_date >= V_PERIOD_START_DATE
                   AND t.so_date < V_PERIOD_START_DATE;
                   
                --计算总期折让余额
                V_AMOUNT_J := V_AMOUNT_J2 - V_AMOUNT_L2;
              
              elsif(V_COUNT7_ != 0) then
               --获取已存在的总期折让余额
               BEGIN
                --按品类获取期初折让余额
                SELECT NVL(b.CURRENT_AMOUNT,0)
                  INTO V_AMOUNT_J
                  FROM T_AR_SOA_ORDER_DIS_LINES b
                 WHERE b.HEADER_ID = (SELECT MAX(t.HEADER_ID)
                  FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
                   AND t.customer_id = ACCOUNT_ROW.customer_id
                   --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                   and t.account_id = ACCOUNT_ROW.account_id
                   --AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
                   AND t.SOA_END_DATE = V_LAST_END_DATE
                   AND nvl(t.confirm_flag,'N') <> 'E')
                   AND b.SALES_MAIN_ID = ITEMCLASS_ROW.ITEM_CLASS_ID
                    AND NVL(b.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE;
                EXCEPTION
                  WHEN OTHERS THEN
                    V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                       SQLCODE,
                                                       '获取期初折让余额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                       substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                    P_RESULT := V_RESULT;
                    --RAISE V_ERR_EXCEPT;
                    V_AMOUNT_J := 0;
                    CONTINUE;
                END;
              end if;
              --end huanghb12
            END IF;
            
            
          --如果上期存在对账信息
          else
            BEGIN
            --按品类获取期初折让余额
            SELECT NVL(b.CURRENT_AMOUNT,0)
              INTO V_AMOUNT_J
              FROM T_AR_SOA_ORDER_DIS_LINES b
             WHERE b.HEADER_ID = (SELECT MAX(t.HEADER_ID)
              FROM T_AR_SOA_ORDER_HEADS t WHERE t.entity_id = ACCOUNT_ROW.entity_id
               AND t.customer_id = ACCOUNT_ROW.customer_id
               --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
               AND t.account_id = ACCOUNT_ROW.account_id
               AND t.SOA_BEGIN_DATE = V_LAST_START_DATE
               AND t.SOA_END_DATE = V_LAST_END_DATE
               AND nvl(t.confirm_flag,'N') <> 'E')
               AND b.SALES_MAIN_ID = ITEMCLASS_ROW.ITEM_CLASS_ID
               AND NVL(b.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE;
            EXCEPTION
              WHEN OTHERS THEN
                V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                   SQLCODE,
                                                   '获取期初折让余额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') ||',账期:' || V_PERIOD_DATE || '！:' ||
                                                   substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                P_RESULT := V_RESULT;
                --RAISE V_ERR_EXCEPT;
                V_AMOUNT_J := 0;
                CONTINUE;
            END;
          end if;

          --按品类判断上期是否存在修改折让单据原始数据
            SELECT COUNT(*)
              INTO V_COUNT17
              FROM cims.t_so_header t,cims.T_AR_SOA_DIS_ORDER_HIS b
             WHERE t.so_num = b.order_number AND t.discount_amount <> b.dis_amount
               AND t.Entity_Id = ACCOUNT_ROW.entity_id
               AND t.Customer_Id = ACCOUNT_ROW.customer_id
               --AND t.Sales_Center_Id = V_SALES_CENTER_ID
               AND t.account_id = ACCOUNT_ROW.account_id
               AND t.SALES_MAIN_TYPE = V_CLASS_CODE
               AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
              -- AND t.SO_DATE >= V_LAST_START_DATE --去掉日期限制 guibr 存在跨两月结算单据
               AND t.SO_DATE < V_PERIOD_START_DATE
               AND t.settle_date >= V_PERIOD_START_DATE
                 AND t.settle_date < V_PERIOD_END_DATE2
               AND nvl(b.diff_update_flag,'N') <> 'E';

             if (V_COUNT17 > 0) THEN
                SELECT (NVL(SUM(NVL(t.discount_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0) - NVL(SUM(NVL(b.dis_amount, 0) *e.APPLIED_PLUS_MINUS_FLAG),0))
                  INTO D_AMOUNT_K
                  FROM cims.t_so_header t,cims.T_AR_SOA_DIS_ORDER_HIS b ,cims.T_SO_TYPE_EXTEND e
                 WHERE t.so_num = b.order_number AND t.bill_type_id = e.bill_type_id
                   AND t.discount_amount <> b.dis_amount
                   AND t.Entity_Id = ACCOUNT_ROW.entity_id
                   AND t.Customer_Id = ACCOUNT_ROW.customer_id
                   --AND t.Sales_Center_Id = V_SALES_CENTER_ID
                   AND t.account_id = ACCOUNT_ROW.account_id
                   AND t.SALES_MAIN_TYPE = V_CLASS_CODE
                   AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                --   AND t.SO_DATE >= V_LAST_START_DATE --去掉日期限制 guibr 存在跨两月结算单据
                   AND t.SO_DATE < V_PERIOD_START_DATE
                   AND t.settle_date >= V_PERIOD_START_DATE
                     AND t.settle_date < V_PERIOD_END_DATE2
                   AND nvl(b.diff_update_flag,'N') <> 'E';
             else
               D_AMOUNT_K := 0;
             end if;

          --按品类计算本期折让金额
          SELECT (NVL(SUM(NVL(t.settle_amount, 0) *
                         b.APPLIED_PLUS_MINUS_FLAG),
                     0) + D_AMOUNT_K)
            INTO V_AMOUNT_K
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.bill_type_id = b.bill_type_id
             AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
             AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             --AND b.Can_Applied_Flag = 'Y'
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in ('1009', '1010')
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

          --按品类计算核销折让金额
          SELECT (NVL(SUM(NVL(t.discount_amount, 0) *
                         b.APPLIED_PLUS_MINUS_FLAG),
                     0) + D_AMOUNT_L)
            INTO V_AMOUNT_L
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.bill_type_id = b.bill_type_id
             AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
             AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             --AND b.Can_Applied_Flag = 'Y'
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

          --计算折让余额
          V_AMOUNT_H := V_AMOUNT_J + V_AMOUNT_K - V_AMOUNT_L;


          --按品类计算本期未解付金额
          /*SELECT NVL(SUM(NVL(t.UN_SOLUTION_AMOUNT, 0)), 0)
            INTO V_AMOUNT_U
            FROM V_AR_CASH_RECEIPT_UN_SOLU t
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_code = ACCOUNT_ROW.customer_code
             --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
             AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
             AND t.REVIEWED_DATE >= V_PERIOD_START_DATE
             AND t.REVIEWED_DATE < V_PERIOD_END_DATE2;*/

             -- add by tangfeng
             select sum(un_solution_amount)
             INTO V_AMOUNT_U
             FROM(
             select nvl(l.amount,0) - nvl(acc.solution_pay_amount, 0) un_solution_amount
             from cims.t_ar_cash_receipt_headers h
             left join cims.t_ar_cash_receipt_lines l on l.cash_receipt_id = h.cash_receipt_id
             left join (SELECT p.CASH_RECEIPT_LINES_ID, nvl(SUM(p.SOLUTION_PAY_AMOUNT), 0) AS SOLUTION_PAY_AMOUNT
                       FROM cims.t_ar_acce_solu_pay p
                       WHERE p.solution_pay_status in ('2', '3') and p.solution_pay_time < V_PERIOD_END_DATE2
                       GROUP BY p.CASH_RECEIPT_LINES_ID) acc
                  on acc.cash_receipt_lines_id = l.cash_receipt_lines_id
             left join cims.t_ar_receipt_methods m on h.receipt_method_id = m.receipt_method_id
             where h.receipt_status_id not in (0,1,2,10,12,19) and m.receipt_type = '3'
             and h.entity_id = ACCOUNT_ROW.entity_id
             AND h.customer_code = ACCOUNT_ROW.customer_code
             AND h.account_id = ACCOUNT_ROW.account_id
             AND l.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
             AND NVL(h.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             AND h.REVIEWED_DATE < V_PERIOD_END_DATE2);
             
             
           /**  
             --计算未开票金额
           SELECT  
                NVL(SUM(NVL(t.settle_amount, 0) *
                            b.APPLIED_PLUS_MINUS_FLAG),
                       0)
            INTO V_AMOUNT_TRX1
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
             AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             AND t.bill_type_id = b.bill_type_id
             AND t.so_status <> '10'
             AND t.invoice_num_list is null
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2;

           SELECT  
               NVL(SUM(NVL(t.settle_amount, 0) *
                            b.APPLIED_PLUS_MINUS_FLAG),
                0)
            INTO V_AMOUNT_TRX2
            FROM T_SO_HEADER t, T_SO_TYPE_EXTEND b
           WHERE t.entity_id = ACCOUNT_ROW.entity_id
             AND t.customer_id = ACCOUNT_ROW.customer_id
             AND t.account_id = ACCOUNT_ROW.account_id
             AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
             AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
             AND t.bill_type_id = b.bill_type_id
             AND t.so_status <> '10'
             AND t.BIZ_SRC_BILL_TYPE_CODE in
                 ('1001', '1002', '1003', '1004', '1005', '1006', '1007',
                  '1008')
             AND t.so_date >= V_PERIOD_START_DATE
             AND t.so_date < V_PERIOD_END_DATE2
             AND t.invoice_num_list is not null
             AND t.invoice_date >=V_PERIOD_END_DATE2;
             
            V_AMOUNT_TRX1 := V_AMOUNT_TRX1 + V_AMOUNT_TRX2;  **/  
             
            SELECT 
                NVL(SUM(NVL(D.APPROVAL_AMOUNT, 0)),0) 
            INTO V_AMOUNT_LOCC
            FROM  T_CREDIT_DELAYPAY D 
            WHERE DELAYPAY_TYPE =10     --冻结保证金
              AND BILL_STATUS = 3       --已审批
              AND D.DUE_TIME IS NULL    --没过期
              AND V_DISCOUNT_TYPE = V_DISCOUNT_TYPE_COMMON
              AND d.entity_id = ACCOUNT_ROW.entity_id
              AND d.customer_id = ACCOUNT_ROW.customer_id
              AND d.account_id = ACCOUNT_ROW.account_id
              AND d.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
              --AND D.BILL_DATE >= V_PERIOD_START_DATE   
              AND D.BILL_DATE < V_PERIOD_END_DATE2;
             

             /**select sum(un_solution_amount)
             INTO V_AMOUNT_U
             FROM(
             select nvl(l.amount,0) - sum (nvl (acc.solution_pay_amount, 0)) un_solution_amount
             from cims.t_ar_cash_receipt_headers h left join cims.t_ar_cash_receipt_lines l on l.cash_receipt_id = h.cash_receipt_id
             left join cims.t_ar_acce_solu_pay acc on acc.cash_receipt_lines_id = l.cash_receipt_lines_id and acc.solution_pay_status in ('2', '3') and acc.solution_pay_time < V_PERIOD_END_DATE2
             left join cims.t_ar_receipt_methods m on h.receipt_method_id = m.receipt_method_id
             where h.receipt_status_id not in (0,1,2,10,12,19) and m.receipt_type = '3'
             and h.entity_id = ACCOUNT_ROW.entity_id
             AND h.customer_code = ACCOUNT_ROW.customer_code
             AND h.account_id = ACCOUNT_ROW.account_id
             AND l.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
             group by l.cash_receipt_lines_id,l.amount);**/

          FOR CONF_ROW IN C_ACCOUNT_CONF LOOP
            V_ORDER_TYPE := CONF_ROW.Order_Type;

            if (V_ORDER_TYPE = '1' /*AND (V_COUNT4 > 0 OR V_COUNT5 > 0)*/) THEN
              /*SELECT COUNT(*)
               INTO V_COUNT
               FROM T_AR_STATEMENT_ACC_HISTORY t
              WHERE t.entity_id = CONF_ROW.entity_id
                AND t.customer_id = CONF_ROW.customer_id
                AND t.sales_center_id = CONF_ROW.sales_center_id
                AND t.count_period = V_PERIOD_DATE
                AND t.order_type = V_ORDER_TYPE;

              if (V_COUNT > 0) THEN
                 V_RESULT := '传入的客户或者中心本期已经计算过往来对账单信息，对账期间：【' || V_PERIOD_DATE
                 || '】，对账单类型：【' || V_ORDER_TYPE || '】';
                 P_RESULT := V_RESULT;
                 --RAISE V_ERR_EXCEPT;

               else*/
              BEGIN
                --插入确认式往来对账单到款结算行
                INSERT INTO T_AR_SOA_ORDER_RECEIPT_LINES
                  (RECEIPT_LINE_ID, --到款行ID
                   HEADER_ID, --对账单头ID
                   SOA_TYPE, --对账类型
                   PERIOD_AMOUNT, --期初余额
                   RECEIPT_AMOUNT, --本期累计到款
                   SALES_AMOUNT, --到款提货金额
                   CURRENT_AMOUNT, --本期到款余额
                   RECEIVABLE_AMOUNT, --应收账款金额
                   CUS_RECEIVABLE_AMOUNT, --客户确认应收账款金额
                   DIFFERENACE_AMOUNT, --应收账款差异金额
                   COMMENTS, --备注
                   ENTITY_ID, --主体ID
                   CREATED_BY, --创建人
                   CREATION_DATE, --创建日期
                   LAST_UPDATED_BY, --最后更新人
                   LAST_UPDATE_DATE, --最后更新日期
                   SOA_COUNT_BATCH_ID,
                   SALES_MAIN_ID,
                   SALES_MAIN_NAME,
                   DIFF_SALES_AMOUNT,
                   UN_SOLUTION_AMOUNT,
                   DISCOUNT_TYPE,
                   DEPOSIT_LOCK_AMOUNT,
                   NOT_INVOICE_AMOUNT
                   )
                VALUES
                  (S_AR_SOA_ORDER_LINES.NEXTVAL,
                   V_SOA_COUNT_BATCH_ID,
                   V_ORDER_TYPE, --'RECEIPT_TYPE', --到款结算
                   V_AMOUNT_A, --期初余额
                   V_AMOUNT_D, --本期累计到款
                   V_AMOUNT_E, --到款提货金额
                   V_AMOUNT_F, --本期到款余额
                   V_AMOUNT_I + nvl(V_AMOUNT_U,0), --应收账款金额
                   NULL, --客户确认应收账款金额
                   NULL, --应收账款差异金额
                   NULL, --备注
                   CONF_ROW.ENTITY_ID,
                   NULL,
                   SYSDATE,
                   NULL,
                   NULL,
                   V_SOA_COUNT_BATCH_ID,
                   ITEMCLASS_ROW.ITEM_CLASS_ID,
                   ITEMCLASS_ROW.CLASS_CODE,
                   D_AMOUNT_E,
                   V_AMOUNT_U,
                   V_DISCOUNT_TYPE,
                   V_AMOUNT_LOCC,
                   V_AMOUNT_TRX1
                   );

              EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                     SQLCODE,
                                                     '插入确认式往来对账单到款结算行失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') ||',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
              END;

            BEGIN
                V_RESULT := '插入到款单数据到到款历史表';
                INSERT INTO T_AR_SOA_CUST_RECEIPT_HIS
                  (SOA_COUNT_BATCH_ID, --对账单批次ID
                   SOURCE_ORDER_TYPE,  --来源单据类型
                   SOA_ORDER_TYPE,     --对账单类型（余额确认式、借贷调节式）
                   HEADER_ID,          --收款单ID
                   ORDER_NUMBER,       --收款单号
                   ORDERED_DATE,       --单据日期
                   ACCOUNT_DATE,       --结算日期
                   FINANCE_CHECK_DATE, --财务审核日期
                   CUSTOMER_ID,        --客户ID
                   CASH_DATE,          --票据日期
                   CASH_CODE,          --票据号
                   DISCOUNT_TYPE_ID,   --折扣ID
                   RECEIPT_METHOD_ID,  --收款方法ID
                   RECEIPT_AMOUNT,     --收款金额
                   ENTITY_ID,          --主体ID
                   SALES_CENTER_ID,    --中心ID
                   STATUS,             --状态
                   BI_LAST_UPDATE_DATE, --BI日期
                   SOA_SALES_CENTER_ID, --对账单中心ID
                   SOA_ORDER_HEAD_ID,   --对账单ID
                   CREATION_DATE,       --创建日期
                   difference_AMOUNT,   --差异金额
                   difference_DIS_AMOUNT,   --差异折让金额
                   SOA_PERIOD_DATE,     --对账单周期
                   SOA_BEGIN_DATE,      --对账单开始日期
                   SOA_END_DATE,        --对账单结束日期
                   HISTORY_ID,           --历史ID，历史表主键
                   DISCOUNT_TYPE         --折扣类型
                   )
                  SELECT V_SOA_COUNT_BATCH_ID,
                         '到款单',
                         V_ORDER_TYPE,
                         t.CASH_RECEIPT_ID,
                         t.CASH_RECEIPT_CODE,
                         t.CASH_RECEIPT_DATE,
                         null,
                         null,
                         ACCOUNT_ROW.CUSTOMER_ID,
                         t.CASH_DATE,
                         t.CASH_CODE,
                         null,                        --DISCOUNT_TYPE_ID,
                         t.RECEIPT_METHOD_ID,
                         NVL(t.AMOUNT, 0),
                         ACCOUNT_ROW.ENTITY_ID,
                         ACCOUNT_ROW.SALES_CENTER_ID,
                         '',                        --STATUS,
                         null,
                         null,
                         V_SOA_COUNT_BATCH_ID,
                         SYSDATE,
                         null,
                         null,
                         V_PERIOD_DATE,
                         V_PERIOD_START_DATE,
                         V_PERIOD_END_DATE,
                         S_AR_SOA_CUST_RECEIPT_HIS.NEXTVAL,
                         V_DISCOUNT_TYPE
                      FROM v_ar_cash_receipt_header_lines t
                     WHERE t.entity_id = ACCOUNT_ROW.entity_id
                       AND t.customer_id = ACCOUNT_ROW.customer_id
                       --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                       AND t.account_id = ACCOUNT_ROW.account_id
                       AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
                       AND t.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
                       AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                       AND t.REVIEWED_DATE >= V_PERIOD_START_DATE
                       AND t.REVIEWED_DATE < V_PERIOD_END_DATE2;
              EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                     SQLCODE,
                                                     '插入到款单数据到到款历史表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') ||',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
              END;

            BEGIN
                V_RESULT := '插入本期销售单数据到销售历史表';
                INSERT INTO T_AR_SOA_SO_ORDER_HIS
                  (SOA_COUNT_BATCH_ID,
                   SOA_SALES_CENTER_ID,
                   SOA_ORDER_TYPE,
                   SOA_ORDER_HEAD_ID,
                   SOA_ORDER_NUMBER,
                   SOURCE_ORDER_TYPE,
                   HEADER_ID,
                   LINE_ID,
                   CANCEL_QUANTITY,
                   ORDER_TYPE_ID,
                   ENTITY_ID,
                   SALES_CENTER_ID,
                   CUSTOMER_ID,
                   DISCOUNT_TYPE_ID,
                   ORDER_NUMBER,
                   ORDERED_DATE,
                   ACCOUNT_DATE,
                   PRESALES_FLAG,
                   ACCOUNT_FLAG,
                   MATERIAL_ID,
                   MATERIAL_CODE,
                   QUANTITY,
                   LIST_PRICE,
                   STATIC_DISCOUNT_RATE,
                   ORDERED_DISCOUNT_RATE,
                   PRESALES_LIST_PRICE,
                   DYNAMIC_DISCOUNT_RATE,
                   DOWN_PRICE,
                   INS_DEC,
                   LIST_AMOUNT,
                   AMOUNT,
                   PRE_DIS_AMOUNT,
                   MIDDLE_DISCOUNT_AMOUNT,
                   PRESALES_AMOUNT,
                   DIS_AMOUNT,
                   ORDERED_DISCOUNT_AMOUNT,
                   INSTANT_DIS_AMOUNT,
                   BI_LAST_UPDATE_DATE,
                   difference_AMOUNT,
                   difference_DIS_AMOUNT,
                   SOA_PERIOD_DATE,
                   SOA_BEGIN_DATE,
                   SOA_END_DATE,
                   HISTORY_ID,
                   CREATION_DATE,
                   DISCOUNT_TYPE,
                   RAW_SRC_BILL_NUM
                   )
                  SELECT V_SOA_COUNT_BATCH_ID,
                         null,
                         V_ORDER_TYPE,
                         V_SOA_COUNT_BATCH_ID,
                         V_ORDER_NUMBER,
                         '销售单',
                         t.SO_HEADER_ID,
                         null,  --销售单行ID
                         null,  --红冲数量
                         t.BILL_TYPE_ID,
                         t.ENTITY_ID,
                         t.SALES_CENTER_ID,
                         t.CUSTOMER_ID,
                         null,                       --SDA.DISCOUNT_MODE,
                         t.SO_NUM,
                         t.SO_DATE,
                         t.SETTLE_DATE,          --结算日期
                         null,       --SDA.PRESALES_FLAG,
                         t.SETTLE_FLAG,          --结算标识
                         null,
                         null,
                         null,                   --数量
                         null,                   --列表价
                         null,       --固定折扣,
                         null,       --月返
                         null,       --SDA.PRESALES_LIST_PRICE,
                         null,       --折扣率
                         null,       --SDA.DOWN_PRICE,
                         null,       --SDA.INS_DEC,
                         t.LIST_AMOUNT,     --列表总金额
                         t.SETTLE_AMOUNT,   --结算总金额
                         null,              --PRE_DIS_AMOUNT,
                         null,   --中间折扣金额
                         null,
                         t.DISCOUNT_AMOUNT,
                         null,              --月返金额
                         null,              --INSTANT_DIS_AMOUNT,
                         null,
                         0,
                         0,
                         V_PERIOD_DATE,
                         V_PERIOD_START_DATE,
                         V_PERIOD_END_DATE,
                         S_AR_SOA_SO_ORDER_HIS.NEXTVAL,
                         SYSDATE,
                         V_DISCOUNT_TYPE,
                         (case when t.RAW_SRC_TYPE ='02' then t.RAW_SRC_BILL_NUM
                               when t.ORIGIN_ORIGIN_TYPE ='02' then t.ORIGIN_ORIGIN_ORDER_CODE
                                else null  end) RAW_SRC_BILL_NUM
                      FROM T_SO_HEADER t
                     WHERE t.entity_id = ACCOUNT_ROW.entity_id
                       AND t.customer_id = ACCOUNT_ROW.customer_id
                       --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                       AND t.account_id = ACCOUNT_ROW.account_id
                       AND t.so_status <> '10'
                       AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
                       AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                       AND t.BIZ_SRC_BILL_TYPE_CODE in
                           ('1001', '1002', '1003', '1004', '1005', '1006', '1007', '1008')
                       AND t.so_date >= V_PERIOD_START_DATE
                       AND t.so_date < V_PERIOD_END_DATE2;
                    EXCEPTION
                    WHEN OTHERS THEN
                      V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                         SQLCODE,
                                                         '插入本期销售单数据到销售历史表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') ||',账期:' || V_PERIOD_DATE || '！:' ||
                                                         substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                      P_RESULT := V_RESULT;
                      --RAISE V_ERR_EXCEPT;
                      CONTINUE;
                      END;

            --插入数据到明细表
            BEGIN
                V_RESULT := '插入本期到款单数据到明细表';
              --插入本期到款单数据到明细表
              INSERT INTO T_AR_SOA_ORDER_DETAILS
               (SOA_COUNT_BATCH_ID ,   --对账单批次ID
                SOURCE_ORDER_TYPE ,   --来源单据类型：到款单、销售单、返利单
                SOA_ORDER_TYPE ,   --对账单类型
                SOA_ORDER_HEAD_ID ,   --对账单ID
                SOA_ORDER_NUMBER ,   --对账单号
                HEADER_ID ,   --单据ID
                ENTITY_ID ,   --主体ID
                SALES_YEAR_ID ,   --销售年度
                ORDER_TYPE ,   --单据类型
                SALES_REGION_ID ,   --经营区域ID
                CUSTOMER_ID ,   --客户ID
                CUSTOMER_CODE ,   --客户编码
                CUSTOMER_NAME ,   --客户名称
                DISCOUNT_TYPE_ID ,   --折扣类型ID
                DISCOUNT_METHOD ,   --折让方法
                SALES_CENTER_ID ,   --营销中心ID
                ORDER_NUMBER ,   --单据编号
                ORDERED_DATE ,   --单据日期
                ACCOUNT_DATE ,   --结算日期
                ACCOUNT_FLAG ,   --结算标志
                ITEM_TYPE ,   --商品大类
                DIS_AMOUNT ,   --折让金额
                INTEND_AMOUNT ,   --含税金额
                AMOUNT ,   --到款金额
                DIFFERENCE_AMOUNT ,   --差异金额
                DIFFERENCE_DIS_AMOUNT ,   --差异折让金额
                SOA_PERIOD_DATE ,   --对账单周期
                SOA_BEGIN_DATE ,   --对账单开始日期
                SOA_END_DATE ,   --对账单结束日期
                HISTORY_ID ,   --历史ID
                DETAILS_ID ,   --明细ID
                DIFF_UPDATE_FLAG ,   --创建的历史差异已更新标志
                SOA_ADJUST_CODE ,   --注释：上期单据在本期调整金额
                CREATION_DATE ,   --录入日期
                REMARKS ,   --备注
                SALES_CENTER_CODE ,   --营销中心编码
                SALES_CENTER_NAME ,   --营销中心名称
                INVOICE_NUM_LIST ,   --发票号串：多个发票号用逗号分隔（,）。
                INVOICE_DATE ,   --发票日期：一张销售单只有一个发票开票日期。
                CASH_CODE ,   --票据号
                CASH_DATE ,   --出票日期
                DUE_DATE ,   --票据到期日期
                LIST_AMOUNT ,   --列表金额
                SETTLE_AMOUNT ,   --结算金额
                DISCOUNT_AMOUNT,    --核销折让金额
                ORDER_TYPE_ID,      --单据类型ID
                SALES_MAIN_ID,      --品类ID
                SALES_MAIN_NAME,    --品类名称
                  DISCOUNT_TYPE,      --折扣类型
                UN_SOLUTION_AMOUNT--三方承兑未解付金额
                ) 
              SELECT
                 V_SOA_COUNT_BATCH_ID,
                 '到款单据',
                 V_ORDER_TYPE,
                 V_SOA_COUNT_BATCH_ID,
                 V_ORDER_NUMBER,
                 t.CASH_RECEIPT_ID,
                 t.ENTITY_ID,
                 null,
                 (SELECT distinct b.RECEIPT_METHOD_NAME
                 FROM T_AR_RECEIPT_METHODS b
                 WHERE b.RECEIPT_METHOD_ID = t.RECEIPT_METHOD_ID),
                 null,
                 t.CUSTOMER_ID,
                 t.CUSTOMER_CODE,
                 t.CUSTOMER_NAME,
                 null,
                 null,
                 t.SALES_CENTER_ID,
                 t.CASH_RECEIPT_CODE,
                 t.CASH_RECEIPT_DATE,
                 null,
                 null,
                 null,
                 null,
                 null,
                 t.AMOUNT,
                 null,
                 null,
                 V_PERIOD_DATE,
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 /*(SELECT t.HISTORY_ID
                FROM T_AR_SOA_CUST_RECEIPT_HIS t
               WHERE t.ORDER_NUMBER = RECEIPT_ROW.CASH_RECEIPT_CODE
                 AND t.HEADER_ID = RECEIPT_ROW.CASH_RECEIPT_ID),*/
                 null,
                 S_AR_SOA_ORDER_DETAILS.NEXTVAL,
                 null,
                 null,
                 sysdate,
--                 null,--备注
                 t.remaek,--备注
                 ACCOUNT_ROW.SALES_CENTER_CODE,
                 ACCOUNT_ROW.SALES_CENTER_NAME,
                 null,
                 null,
                 t.CASH_CODE,
                 t.CASH_DATE,
                 t.DUE_DATE,
                 null,
                 null,
                 null,
                 t.RECEIPT_METHOD_ID,
                 ITEMCLASS_ROW.ITEM_CLASS_ID,
                 ITEMCLASS_ROW.CLASS_CODE,
                 V_DISCOUNT_TYPE,
                 (select nvl(l.amount,0) - sum (nvl (acc.solution_pay_amount, 0))
                 from cims.t_ar_cash_receipt_headers h left join cims.t_ar_cash_receipt_lines l on l.cash_receipt_id = h.cash_receipt_id
                 left join cims.t_ar_acce_solu_pay acc on acc.cash_receipt_lines_id = l.cash_receipt_lines_id and acc.solution_pay_status in ('2', '3') and acc.solution_pay_time < V_PERIOD_END_DATE2
                 left join cims.t_ar_receipt_methods m on h.receipt_method_id = m.receipt_method_id
                 where m.receipt_type = '3'
                 and l.cash_receipt_id = t.cash_receipt_id
                 group by l.cash_receipt_lines_id,l.amount)
                 /*NVL((SELECT a.UN_SOLUTION_AMOUNT
                 FROM V_AR_CASH_RECEIPT_UN_SOLU a
                 WHERE a.cash_receipt_id = t.cash_receipt_id),0)*/
                FROM v_ar_cash_receipt_header_lines t
               WHERE t.entity_id = ACCOUNT_ROW.entity_id
                 AND t.customer_id = ACCOUNT_ROW.customer_id
                 --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                 AND t.account_id = ACCOUNT_ROW.account_id
                 AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
                 AND t.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
                 AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                 AND t.REVIEWED_DATE >= V_PERIOD_START_DATE
                 AND t.REVIEWED_DATE < V_PERIOD_END_DATE2;
                 EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                     SQLCODE,
                                                     '插入本期到款单数据到明细表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') ||',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
                  END;


                  BEGIN
                V_RESULT := '插入本期三方承兑未解付数据到明细表';
              --插入本期三方承兑未解付数据到明细表
              INSERT INTO T_AR_SOA_ORDER_DETAILS
               (SOA_COUNT_BATCH_ID ,   --对账单批次ID
                SOURCE_ORDER_TYPE ,   --来源单据类型：到款未解付
                SOA_ORDER_TYPE ,   --对账单类型
                SOA_ORDER_HEAD_ID ,   --对账单ID
                SOA_ORDER_NUMBER ,   --对账单号
                HEADER_ID ,   --单据ID
                ENTITY_ID ,   --主体ID
                SALES_YEAR_ID ,   --销售年度
                ORDER_TYPE ,   --单据类型
                SALES_REGION_ID ,   --经营区域ID
                CUSTOMER_ID ,   --客户ID
                CUSTOMER_CODE ,   --客户编码
                CUSTOMER_NAME ,   --客户名称
                DISCOUNT_TYPE_ID ,   --折扣类型ID
                DISCOUNT_METHOD ,   --折让方法
                SALES_CENTER_ID ,   --营销中心ID
                ORDER_NUMBER ,   --单据编号
                ORDERED_DATE ,   --单据日期
                ACCOUNT_DATE ,   --结算日期
                ACCOUNT_FLAG ,   --结算标志
                ITEM_TYPE ,   --商品大类
                DIS_AMOUNT ,   --折让金额
                INTEND_AMOUNT ,   --含税金额
                AMOUNT ,   --到款金额
                DIFFERENCE_AMOUNT ,   --差异金额
                DIFFERENCE_DIS_AMOUNT ,   --差异折让金额
                SOA_PERIOD_DATE ,   --对账单周期
                SOA_BEGIN_DATE ,   --对账单开始日期
                SOA_END_DATE ,   --对账单结束日期
                HISTORY_ID ,   --历史ID
                DETAILS_ID ,   --明细ID
                DIFF_UPDATE_FLAG ,   --创建的历史差异已更新标志
                SOA_ADJUST_CODE ,   --注释：上期单据在本期调整金额
                CREATION_DATE ,   --录入日期
                REMARKS ,   --备注
                SALES_CENTER_CODE ,   --营销中心编码
                SALES_CENTER_NAME ,   --营销中心名称
                INVOICE_NUM_LIST ,   --发票号串：多个发票号用逗号分隔（,）。
                INVOICE_DATE ,   --发票日期：一张销售单只有一个发票开票日期。
                CASH_CODE ,   --票据号
                CASH_DATE ,   --出票日期
                DUE_DATE ,   --票据到期日期
                LIST_AMOUNT ,   --列表金额
                SETTLE_AMOUNT ,   --结算金额
                DISCOUNT_AMOUNT,    --核销折让金额
                ORDER_TYPE_ID,      --单据类型ID
                SALES_MAIN_ID,      --品类ID
                SALES_MAIN_NAME,    --品类名称
                UN_SOLUTION_AMOUNT,--三方承兑未解付金额
                DISCOUNT_TYPE
                ) 
              SELECT
                 V_SOA_COUNT_BATCH_ID,
                 '到款未解付',
                 V_ORDER_TYPE,
                 V_SOA_COUNT_BATCH_ID,
                 V_ORDER_NUMBER,
                 t.CASH_RECEIPT_ID,
                 t.ENTITY_ID,
                 null,
                 t.RECEIPT_METHOD_NAME,
                 null,
                 t.CUSTOMER_ID,
                 t.CUSTOMER_CODE,
                 t.CUSTOMER_NAME,
                 null,
                 null,
                 t.SALES_CENTER_ID,
                 t.CASH_RECEIPT_CODE,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 V_PERIOD_DATE,
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 /*(SELECT t.HISTORY_ID
                FROM T_AR_SOA_CUST_RECEIPT_HIS t
               WHERE t.ORDER_NUMBER = RECEIPT_ROW.CASH_RECEIPT_CODE
                 AND t.HEADER_ID = RECEIPT_ROW.CASH_RECEIPT_ID),*/
                 null,
                 S_AR_SOA_ORDER_DETAILS.NEXTVAL,
                 null,
                 null,
                 sysdate,
                 null,--备注
                 ACCOUNT_ROW.SALES_CENTER_CODE,
                 ACCOUNT_ROW.SALES_CENTER_NAME,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 t.RECEIPT_METHOD_ID,
                 ITEMCLASS_ROW.ITEM_CLASS_ID,
                 ITEMCLASS_ROW.CLASS_CODE,
                 un_solution_amount,
                 V_DISCOUNT_TYPE
                 from (select h.entity_id,h.cash_receipt_id,l.cash_receipt_lines_id,h.receipt_method_id,m.receipt_method_name,
                 h.customer_id,h.customer_code,h.customer_name,h.sales_center_id,h.cash_receipt_code,
                 l.amount,sum (nvl (acc.solution_pay_amount, 0))solution_amount, nvl(l.amount,0) - sum (nvl (acc.solution_pay_amount, 0)) un_solution_amount
                 from cims.t_ar_cash_receipt_headers h left join cims.t_ar_cash_receipt_lines l on l.cash_receipt_id = h.cash_receipt_id
                 left join cims.t_ar_acce_solu_pay acc on acc.cash_receipt_lines_id = l.cash_receipt_lines_id and acc.solution_pay_status in ('2', '3') and acc.solution_pay_time < V_PERIOD_END_DATE2
                 left join cims.t_ar_receipt_methods m on h.receipt_method_id = m.receipt_method_id
                 where h.receipt_status_id not in (0,1,2,10,12,19) and m.receipt_type = '3'
                 and h.reviewed_date < V_PERIOD_START_DATE
                 and h.entity_id = ACCOUNT_ROW.entity_id
                 AND h.customer_code = ACCOUNT_ROW.customer_code
                 AND l.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
                 AND NVL(h.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                 AND h.account_id = ACCOUNT_ROW.account_id
                 group by h.entity_id,h.cash_receipt_id,l.cash_receipt_lines_id,h.receipt_method_id,m.receipt_method_name,
                 h.customer_id,h.customer_code,h.customer_name,h.sales_center_id,h.cash_receipt_code,l.cash_receipt_lines_id,l.amount) t
                 ;
                 /*FROM v_ar_cash_receipt_header_lines t
                 WHERE t.entity_id = ACCOUNT_ROW.entity_id
                 AND t.customer_id = ACCOUNT_ROW.customer_id
                 --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                 AND t.account_id = ACCOUNT_ROW.account_id
                 AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
                 AND t.SALES_MAIN_TYPE_CODE = ITEMCLASS_ROW.CLASS_CODE
                 AND t.REVIEWED_DATE >= V_PERIOD_START_DATE
                 AND t.REVIEWED_DATE < V_PERIOD_END_DATE2*/
                 EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                     SQLCODE,
                                                     '插入本期到款未解付数据到明细表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id ||',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
                  END;

            BEGIN
                V_RESULT := '插入本期销售单数据到明细表';
              --插入本期销售单数据到明细表
              INSERT INTO T_AR_SOA_ORDER_DETAILS
               (SOA_COUNT_BATCH_ID ,   --对账单批次ID
                SOURCE_ORDER_TYPE ,   --来源单据类型：到款单、销售单、返利单
                SOA_ORDER_TYPE ,   --对账单类型
                SOA_ORDER_HEAD_ID ,   --对账单ID
                SOA_ORDER_NUMBER ,   --对账单号
                HEADER_ID ,   --单据ID
                ENTITY_ID ,   --主体ID
                SALES_YEAR_ID ,   --销售年度
                ORDER_TYPE ,   --单据类型
                SALES_REGION_ID ,   --经营区域ID
                CUSTOMER_ID ,   --客户ID
                CUSTOMER_CODE ,   --客户编码
                CUSTOMER_NAME ,   --客户名称
                DISCOUNT_TYPE_ID ,   --折扣类型ID
                DISCOUNT_METHOD ,   --折让方法
                SALES_CENTER_ID ,   --营销中心ID
                ORDER_NUMBER ,   --单据编号
                ORDERED_DATE ,   --单据日期
                ACCOUNT_DATE ,   --结算日期
                ACCOUNT_FLAG ,   --结算标志
                ITEM_TYPE ,   --商品大类
                DIS_AMOUNT ,   --折让金额
                INTEND_AMOUNT ,   --含税金额
                AMOUNT ,   --到款金额
                DIFFERENCE_AMOUNT ,   --差异金额
                DIFFERENCE_DIS_AMOUNT ,   --差异折让金额
                SOA_PERIOD_DATE ,   --对账单周期
                SOA_BEGIN_DATE ,   --对账单开始日期
                SOA_END_DATE ,   --对账单结束日期
                HISTORY_ID ,   --历史ID
                DETAILS_ID ,   --明细ID
                DIFF_UPDATE_FLAG ,   --创建的历史差异已更新标志
                SOA_ADJUST_CODE ,   --注释：上期单据在本期调整金额
                CREATION_DATE ,   --录入日期
                REMARKS ,   --备注
                SALES_CENTER_CODE ,   --营销中心编码
                SALES_CENTER_NAME ,   --营销中心名称
                INVOICE_NUM_LIST ,   --发票号串：多个发票号用逗号分隔（,）。
                INVOICE_DATE ,   --发票日期：一张销售单只有一个发票开票日期。
                CASH_CODE ,   --票据号
                CASH_DATE ,   --出票日期
                DUE_DATE ,   --票据到期日期
                LIST_AMOUNT ,   --列表金额
                SETTLE_AMOUNT ,   --结算金额
                DISCOUNT_AMOUNT,    --核销折让金额
                ITEM_MONTH_DISCOUNT_AMOUNT,    --月返金额
                ORDER_TYPE_ID,      --单据类型ID
                SALES_MAIN_ID,      --品类ID
                SALES_MAIN_NAME,    --品类名称
                ITEM_CODE,    --产品编码
                ITEM_NAME,    --产品名称
                ITEM_PRICE,    --产品价格
                ITEM_UOM,    --产品单位
                ITEM_QTY,    --产品数量
                RECEIVED_QTY,    --签收数量
                REVERSAL_QTY,    --已红冲数量
                RETURN_QTY,   --已退回数量
                DISCOUNT_TYPE,
                RAW_SRC_BILL_NUM
                )    
              SELECT
                 V_SOA_COUNT_BATCH_ID,
                 '销售单据',
                 V_ORDER_TYPE,
                 V_SOA_COUNT_BATCH_ID,
                 V_ORDER_NUMBER,
                 t.SO_HEADER_ID,
                 t.ENTITY_ID,
                 null,
                 t.BILL_TYPE_NAME,
                 null,
                 t.CUSTOMER_ID,
                 t.CUSTOMER_CODE,
                 t.CUSTOMER_NAME,
                 null,
                 null,
                 t.SALES_CENTER_ID,
                 t.SO_NUM,
                 t.SO_DATE,
                 t.SETTLE_DATE,
                 t.SETTLE_FLAG,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 V_PERIOD_DATE,
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 /*(SELECT t.HISTORY_ID
                FROM T_AR_SOA_SO_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID),*/
                 null,
                 S_AR_SOA_ORDER_DETAILS.NEXTVAL,
                 null,
                 null,
                 sysdate,
--                 null,--备注
                 substrb(t.REMARK, 1, 1000),--备注
                 t.SALES_CENTER_CODE,
                 t.SALES_CENTER_NAME,
                 t.INVOICE_NUM_LIST,
                 t.INVOICE_DATE,
                 null,
                 null,
                 null,
                 ROUND(e.PLUS_MINUS_FLAG * NVL(b.ITEM_LIST_AMOUNT,0),2), --t.LIST_AMOUNT,
                 ROUND(e.PLUS_MINUS_FLAG * NVL(b.ITEM_SETTLE_AMOUNT,0),2), --t.SETTLE_AMOUNT,
                 ROUND(e.PLUS_MINUS_FLAG * NVL(b.DISCOUNT_AMOUNT,0),2), --t.DISCOUNT_AMOUNT,
                 ROUND(e.PLUS_MINUS_FLAG * NVL(b.MONTH_DISCOUNT_AMOUNT,0),2), --ITEM_MONTH_DISCOUNT_AMOUNT
                 t.BILL_TYPE_ID,
                 ITEMCLASS_ROW.ITEM_CLASS_ID,
                 ITEMCLASS_ROW.CLASS_CODE,
                 b.ITEM_CODE,
                 b.ITEM_NAME,
                 b.ITEM_PRICE,
                 b.ITEM_UOM,
                 e.PLUS_MINUS_FLAG * b.ITEM_QTY,
                 b.RECEIVED_QTY,
                 b.REVERSAL_QTY,
                 b.RETURN_QTY,
                 V_DISCOUNT_TYPE,
                 (case when t.RAW_SRC_TYPE ='02' then t.RAW_SRC_BILL_NUM
                      when t.ORIGIN_ORIGIN_TYPE ='02' then t.ORIGIN_ORIGIN_ORDER_CODE
                      else null  end) RAW_SRC_BILL_NUM
                  FROM T_SO_HEADER t,T_SO_LINE b,T_SO_TYPE_EXTEND e
                 WHERE t.SO_HEADER_ID = b.SO_HEADER_ID
                   AND t.bill_type_id = e.bill_type_id
                   AND t.entity_id = ACCOUNT_ROW.entity_id
                   AND t.customer_id = ACCOUNT_ROW.customer_id
                   --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                   AND t.account_id = ACCOUNT_ROW.account_id
                   AND t.so_status <> '10'
                   AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
                   AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                   AND t.BIZ_SRC_BILL_TYPE_CODE in
                       ('1001', '1002', '1003', '1004', '1005', '1006', '1007', '1008')
                   AND t.so_date >= V_PERIOD_START_DATE
                   AND t.so_date < V_PERIOD_END_DATE2;
                 EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                     SQLCODE,
                                                     '插入本期销售单数据到明细表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id ||',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
                  END;
                  
              BEGIN
                  V_RESULT := '插入本期冻结保证金数据到明细表';
              --插入本期销售单数据到明细表
              INSERT INTO T_AR_SOA_ORDER_DETAILS
               (SOA_COUNT_BATCH_ID ,   --对账单批次ID
                SOURCE_ORDER_TYPE ,   --来源单据类型：到款单、销售单、返利单
                SOA_ORDER_TYPE ,   --对账单类型
                SOA_ORDER_HEAD_ID ,   --对账单ID
                SOA_ORDER_NUMBER ,   --对账单号
                HEADER_ID ,   --单据ID
                ENTITY_ID ,   --主体ID
                SALES_YEAR_ID ,   --销售年度
                ORDER_TYPE ,   --单据类型
                SALES_REGION_ID ,   --经营区域ID
                CUSTOMER_ID ,   --客户ID
                CUSTOMER_CODE ,   --客户编码
                CUSTOMER_NAME ,   --客户名称
                DISCOUNT_TYPE_ID ,   --折扣类型ID
                DISCOUNT_METHOD ,   --折让方法
                SALES_CENTER_ID ,   --营销中心ID
                ORDER_NUMBER ,   --单据编号
                ORDERED_DATE ,   --单据日期
                ACCOUNT_DATE ,   --结算日期
                ACCOUNT_FLAG ,   --结算标志
                ITEM_TYPE ,   --商品大类
                DIS_AMOUNT ,   --折让金额
                INTEND_AMOUNT ,   --含税金额
                AMOUNT ,   --到款金额
                DIFFERENCE_AMOUNT ,   --差异金额
                DIFFERENCE_DIS_AMOUNT ,   --差异折让金额
                SOA_PERIOD_DATE ,   --对账单周期
                SOA_BEGIN_DATE ,   --对账单开始日期
                SOA_END_DATE ,   --对账单结束日期
                HISTORY_ID ,   --历史ID
                DETAILS_ID ,   --明细ID
                DIFF_UPDATE_FLAG ,   --创建的历史差异已更新标志
                SOA_ADJUST_CODE ,   --注释：上期单据在本期调整金额
                CREATION_DATE ,   --录入日期
                REMARKS ,   --备注
                SALES_CENTER_CODE ,   --营销中心编码
                SALES_CENTER_NAME ,   --营销中心名称
                INVOICE_NUM_LIST ,   --发票号串：多个发票号用逗号分隔（,）。
                INVOICE_DATE ,   --发票日期：一张销售单只有一个发票开票日期。
                CASH_CODE ,   --票据号
                CASH_DATE ,   --出票日期
                DUE_DATE ,   --票据到期日期
                LIST_AMOUNT ,   --列表金额
                SETTLE_AMOUNT ,   --结算金额
                DISCOUNT_AMOUNT,    --核销折让金额
                ITEM_MONTH_DISCOUNT_AMOUNT,    --月返金额
                ORDER_TYPE_ID,      --单据类型ID
                SALES_MAIN_ID,      --品类ID
                SALES_MAIN_NAME,    --品类名称
                ITEM_CODE,    --产品编码
                ITEM_NAME,    --产品名称
                ITEM_PRICE,    --产品价格
                ITEM_UOM,    --产品单位
                ITEM_QTY,    --产品数量
                RECEIVED_QTY,    --签收数量
                REVERSAL_QTY,    --已红冲数量
                RETURN_QTY,    --已退回数量
                DISCOUNT_TYPE
                )
              SELECT
                 V_SOA_COUNT_BATCH_ID,
                 '冻结保证金',
                 V_ORDER_TYPE,
                 V_SOA_COUNT_BATCH_ID,
                 V_ORDER_NUMBER,
                 t.BILL_ID,
                 t.ENTITY_ID,
                 null,
                 '冻结保证金',
                 null,
                 t.CUSTOMER_ID,
                 t.CUSTOMER_CODE,
                 t.CUSTOMER_NAME,
                 null,
                 null,
                 t.SALES_CENTER_ID,
                 t.BILL_NUM,
                 t.BILL_DATE,
                 t.BILL_DATE,
                 'Y',
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 V_PERIOD_DATE,
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 /*(SELECT t.HISTORY_ID
                FROM T_AR_SOA_SO_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID),*/
                 null,
                 S_AR_SOA_ORDER_DETAILS.NEXTVAL,
                 null,
                 null,
                 sysdate,
                 --null,--备注
                 substrb(t.REMARK, 1, 1000),--备注
                 t.SALES_CENTER_CODE,
                 t.SALES_CENTER_NAME,
                 null,
                 null,
                 null,
                 null,
                 null,
                 ROUND(t.APPROVAL_AMOUNT,2), --t.LIST_AMOUNT,
                 ROUND(t.APPROVAL_AMOUNT,2), --t.SETTLE_AMOUNT,
                 ROUND(t.APPROVAL_AMOUNT,2), --t.DISCOUNT_AMOUNT,
                 ROUND(t.APPROVAL_AMOUNT,2), --ITEM_MONTH_DISCOUNT_AMOUNT
                 t.BILL_TYPE_ID,
                 ITEMCLASS_ROW.ITEM_CLASS_ID,
                 ITEMCLASS_ROW.CLASS_CODE,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 V_DISCOUNT_TYPE
                 FROM  T_CREDIT_DELAYPAY t 
                 WHERE t.DELAYPAY_TYPE =10     --冻结保证金
                   AND t.BILL_STATUS = 3       --已审批
                   AND t.DUE_TIME IS NULL    --没过期
                   AND V_DISCOUNT_TYPE = V_DISCOUNT_TYPE_COMMON
                   AND t.entity_id = ACCOUNT_ROW.entity_id
                   AND t.customer_id = ACCOUNT_ROW.customer_id
                   AND t.account_id = ACCOUNT_ROW.account_id
                   AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
                   AND t.BILL_DATE >= V_PERIOD_START_DATE   
                   AND t.BILL_DATE < V_PERIOD_END_DATE2;
                   
                 EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                     SQLCODE,
                                                     '插入本期冻结保证金数据到明细表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
               END;     
                  

            --判断到款更新数据是否存在金额差异
            FOR RECEIPT_ROW IN C_RECEIPT LOOP
              SELECT COUNT(*)
                INTO V_COUNT9
                FROM T_AR_SOA_CUST_RECEIPT_HIS t
               WHERE t.ORDER_NUMBER = RECEIPT_ROW.CASH_RECEIPT_CODE
                 AND t.HEADER_ID = RECEIPT_ROW.CASH_RECEIPT_ID
                 AND nvl(t.status,'N') <> 'E';

              if(V_COUNT9 > 0) THEN
              BEGIN
                V_RESULT := '获取到款差异金额';
              SELECT NVL(t.RECEIPT_AMOUNT,0)
                INTO V_RECEIPT_AMOUNT
                FROM T_AR_SOA_CUST_RECEIPT_HIS t
               WHERE t.ORDER_NUMBER = RECEIPT_ROW.CASH_RECEIPT_CODE
                 AND t.HEADER_ID = RECEIPT_ROW.CASH_RECEIPT_ID
                 AND nvl(t.status,'N') <> 'E';
              EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                     SQLCODE,
                                                     '获取到款差异金额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id ||',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  V_RECEIPT_AMOUNT := 0;
                  CONTINUE;
                  END;

              if(V_RECEIPT_AMOUNT <> RECEIPT_ROW.AMOUNT) THEN
              BEGIN
                V_RESULT := '插入上期到款单差异数据到明细表';
              --插入差异数据到明细表
              INSERT INTO T_AR_SOA_ORDER_DETAILS
               (SOA_COUNT_BATCH_ID ,   --对账单批次ID
                SOURCE_ORDER_TYPE ,   --来源单据类型：到款单、销售单、返利单
                SOA_ORDER_TYPE ,   --对账单类型
                SOA_ORDER_HEAD_ID ,   --对账单ID
                SOA_ORDER_NUMBER ,   --对账单号
                HEADER_ID ,   --单据ID
                ENTITY_ID ,   --主体ID
                SALES_YEAR_ID ,   --销售年度
                ORDER_TYPE ,   --单据类型
                SALES_REGION_ID ,   --经营区域ID
                CUSTOMER_ID ,   --客户ID
                CUSTOMER_CODE ,   --客户编码
                CUSTOMER_NAME ,   --客户名称
                DISCOUNT_TYPE_ID ,   --折扣类型ID
                DISCOUNT_METHOD ,   --折让方法
                SALES_CENTER_ID ,   --营销中心ID
                ORDER_NUMBER ,   --单据编号
                ORDERED_DATE ,   --单据日期
                ACCOUNT_DATE ,   --结算日期
                ACCOUNT_FLAG ,   --结算标志
                ITEM_TYPE ,   --商品大类
                DIS_AMOUNT ,   --折让金额
                INTEND_AMOUNT ,   --含税金额
                AMOUNT ,   --到款金额
                DIFFERENCE_AMOUNT ,   --差异金额
                DIFFERENCE_DIS_AMOUNT ,   --差异折让金额
                SOA_PERIOD_DATE ,   --对账单周期
                SOA_BEGIN_DATE ,   --对账单开始日期
                SOA_END_DATE ,   --对账单结束日期
                HISTORY_ID ,   --历史ID
                DETAILS_ID ,   --明细ID
                DIFF_UPDATE_FLAG ,   --创建的历史差异已更新标志
                SOA_ADJUST_CODE ,   --注释：上期单据在本期调整金额
                CREATION_DATE ,   --录入日期
                REMARKS ,   --备注
                SALES_CENTER_CODE ,   --营销中心编码
                SALES_CENTER_NAME ,   --营销中心名称
                INVOICE_NUM_LIST ,   --发票号串：多个发票号用逗号分隔（,）。
                INVOICE_DATE ,   --发票日期：一张销售单只有一个发票开票日期。
                CASH_CODE ,   --票据号
                CASH_DATE ,   --出票日期
                DUE_DATE ,   --票据到期日期
                LIST_AMOUNT ,   --列表金额
                SETTLE_AMOUNT ,   --结算金额
                DISCOUNT_AMOUNT,    --核销折让金额
                ORDER_TYPE_ID,      --单据类型ID
                SALES_MAIN_ID,      --品类ID
                SALES_MAIN_NAME,   --品类名称
                DISCOUNT_TYPE
                )  
              VALUES
                (V_SOA_COUNT_BATCH_ID,
                 '到款单差异',
                 V_ORDER_TYPE,
                 V_SOA_COUNT_BATCH_ID,
                 V_ORDER_NUMBER,
                 RECEIPT_ROW.CASH_RECEIPT_ID,
                 RECEIPT_ROW.ENTITY_ID,
                 null,
                 (SELECT distinct t.RECEIPT_METHOD_NAME
                 FROM T_AR_RECEIPT_METHODS t
                 WHERE t.RECEIPT_METHOD_ID = RECEIPT_ROW.RECEIPT_METHOD_ID),
                 null,
                 RECEIPT_ROW.CUSTOMER_ID,
                 RECEIPT_ROW.CUSTOMER_CODE,
                 RECEIPT_ROW.CUSTOMER_NAME,
                 null,
                 null,
                 RECEIPT_ROW.SALES_CENTER_ID,
                 RECEIPT_ROW.CASH_RECEIPT_CODE,
                 RECEIPT_ROW.CASH_RECEIPT_DATE,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 (RECEIPT_ROW.AMOUNT - V_RECEIPT_AMOUNT),
                 null,
                 V_PERIOD_DATE,
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 (SELECT t.HISTORY_ID
                FROM T_AR_SOA_CUST_RECEIPT_HIS t
               WHERE t.ORDER_NUMBER = RECEIPT_ROW.CASH_RECEIPT_CODE
                 AND t.HEADER_ID = RECEIPT_ROW.CASH_RECEIPT_ID
                 AND nvl(t.status,'N') <> 'E'),
                 S_AR_SOA_ORDER_DETAILS.NEXTVAL,
                 null,
                 null,
                 sysdate,
--                 null,--备注
                 RECEIPT_ROW.REMAEK,--备注
                 ACCOUNT_ROW.SALES_CENTER_CODE,
                 ACCOUNT_ROW.SALES_CENTER_NAME,
                 null,
                 null,
                 RECEIPT_ROW.CASH_CODE,
                 RECEIPT_ROW.CASH_DATE,
                 RECEIPT_ROW.DUE_DATE,
                 null,
                 null,
                 null,
                 RECEIPT_ROW.RECEIPT_METHOD_ID,
                 ITEMCLASS_ROW.ITEM_CLASS_ID,
                 ITEMCLASS_ROW.CLASS_CODE,
                 V_DISCOUNT_TYPE
                 );
                 EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                     SQLCODE,
                                                     '插入上期到款单差异数据到明细表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') ||',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
                  END;
              end if;
              end if;
            END LOOP;

            --判断销售更新数据是否存在金额差异
            FOR SO_ROW IN C_SO LOOP
              SELECT COUNT(*)
                INTO V_COUNT10
                FROM T_AR_SOA_SO_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID
                 AND nvl(t.diff_update_flag,'N') <> 'E';

              if(V_COUNT10 > 0) THEN
              BEGIN
                V_RESULT := '获取销售差异金额';
              SELECT NVL(t.AMOUNT,0)
                INTO V_SO_AMOUNT
                FROM T_AR_SOA_SO_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID
                 AND nvl(t.diff_update_flag,'N') <> 'E';
              EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                     SQLCODE,
                                                     '获取销售差异金额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') ||',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  V_SO_AMOUNT := 0;
                  CONTINUE;
                  END;

              if(V_SO_AMOUNT <> SO_ROW.SETTLE_AMOUNT) THEN
              BEGIN
                V_RESULT := '插入上期销售单差异数据到明细表';
              --插入差异数据到明细表
              INSERT INTO T_AR_SOA_ORDER_DETAILS
               (SOA_COUNT_BATCH_ID ,   --对账单批次ID
                SOURCE_ORDER_TYPE ,   --来源单据类型：到款单、销售单、返利单
                SOA_ORDER_TYPE ,   --对账单类型
                SOA_ORDER_HEAD_ID ,   --对账单ID
                SOA_ORDER_NUMBER ,   --对账单号
                HEADER_ID ,   --单据ID
                ENTITY_ID ,   --主体ID
                SALES_YEAR_ID ,   --销售年度
                ORDER_TYPE ,   --单据类型
                SALES_REGION_ID ,   --经营区域ID
                CUSTOMER_ID ,   --客户ID
                CUSTOMER_CODE ,   --客户编码
                CUSTOMER_NAME ,   --客户名称
                DISCOUNT_TYPE_ID ,   --折扣类型ID
                DISCOUNT_METHOD ,   --折让方法
                SALES_CENTER_ID ,   --营销中心ID
                ORDER_NUMBER ,   --单据编号
                ORDERED_DATE ,   --单据日期
                ACCOUNT_DATE ,   --结算日期
                ACCOUNT_FLAG ,   --结算标志
                ITEM_TYPE ,   --商品大类
                DIS_AMOUNT ,   --折让金额
                INTEND_AMOUNT ,   --含税金额
                AMOUNT ,   --到款金额
                DIFFERENCE_AMOUNT ,   --差异金额
                DIFFERENCE_DIS_AMOUNT ,   --差异折让金额
                SOA_PERIOD_DATE ,   --对账单周期
                SOA_BEGIN_DATE ,   --对账单开始日期
                SOA_END_DATE ,   --对账单结束日期
                HISTORY_ID ,   --历史ID
                DETAILS_ID ,   --明细ID
                DIFF_UPDATE_FLAG ,   --创建的历史差异已更新标志
                SOA_ADJUST_CODE ,   --注释：上期单据在本期调整金额
                CREATION_DATE ,   --录入日期
                REMARKS ,   --备注
                SALES_CENTER_CODE ,   --营销中心编码
                SALES_CENTER_NAME ,   --营销中心名称
                INVOICE_NUM_LIST ,   --发票号串：多个发票号用逗号分隔（,）。
                INVOICE_DATE ,   --发票日期：一张销售单只有一个发票开票日期。
                CASH_CODE ,   --票据号
                CASH_DATE ,   --出票日期
                DUE_DATE ,   --票据到期日期
                LIST_AMOUNT ,   --列表金额
                SETTLE_AMOUNT ,   --结算金额
                DISCOUNT_AMOUNT,    --核销折让金额
                ORDER_TYPE_ID,      --单据类型ID
                SALES_MAIN_ID,      --品类ID
                SALES_MAIN_NAME,--品类名称
                DISCOUNT_TYPE,
                RAW_SRC_BILL_NUM
                )   
              VALUES
                (V_SOA_COUNT_BATCH_ID,
                 '销售单差异',
                 V_ORDER_TYPE,
                 V_SOA_COUNT_BATCH_ID,
                 V_ORDER_NUMBER,
                 SO_ROW.SO_HEADER_ID,
                 SO_ROW.ENTITY_ID,
                 null,
                 SO_ROW.BILL_TYPE_NAME,
                 null,
                 SO_ROW.CUSTOMER_ID,
                 SO_ROW.CUSTOMER_CODE,
                 SO_ROW.CUSTOMER_NAME,
                 null,
                 null,
                 SO_ROW.SALES_CENTER_ID,
                 SO_ROW.SO_NUM,
                 SO_ROW.SO_DATE,
                 SO_ROW.SETTLE_DATE,
                 SO_ROW.SETTLE_FLAG,
                 null,
                 null,
                 null,
                 null,
                 (SO_ROW.SETTLE_AMOUNT - V_SO_AMOUNT),
                 null,
                 V_PERIOD_DATE,
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 (SELECT t.HISTORY_ID
                FROM T_AR_SOA_SO_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID
                 AND nvl(t.diff_update_flag,'N') <> 'E'),
                 S_AR_SOA_ORDER_DETAILS.NEXTVAL,
                 null,
                 null,
                 sysdate,
--                 null,--备注
                 substrb(SO_ROW.REMARK, 1, 1000),--备注
                 SO_ROW.SALES_CENTER_CODE,
                 SO_ROW.SALES_CENTER_NAME,
                 SO_ROW.INVOICE_NUM_LIST,
                 SO_ROW.INVOICE_DATE,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 SO_ROW.BILL_TYPE_ID,
                 ITEMCLASS_ROW.ITEM_CLASS_ID,
                 ITEMCLASS_ROW.CLASS_CODE,
                 V_DISCOUNT_TYPE,
                 (case when SO_ROW.RAW_SRC_TYPE ='02' then SO_ROW.RAW_SRC_BILL_NUM
                      when SO_ROW.ORIGIN_ORIGIN_TYPE ='02' then SO_ROW.ORIGIN_ORIGIN_ORDER_CODE
                      else null  end)
                 );
                 EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                     SQLCODE,
                                                     '插入上期销售单差异数据到明细表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') ||',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
                  END;
              end if;
              end if;
            END LOOP;

            elsif (V_ORDER_TYPE = '2' /*AND V_COUNT6 > 0*/) THEN
              BEGIN
                --插入确认式往来对账单折让扣款行
                INSERT INTO T_AR_SOA_ORDER_DIS_LINES
                  (DISCOUNT_LINE_ID, --到款行ID
                   HEADER_ID, --对账单头ID
                   SOA_TYPE, --对账类型
                   PERIOD_AMOUNT, --期初余额
                   DISCOUNT_AMOUNT, --本期累计折让
                   DIS_SALES_AMOUNT, --本期累计核销折让
                   CURRENT_AMOUNT, --本期折让余额
                   CUS_DISCOUNT_AMOUNT, --客户确认的折让余额
                   DIFFERENACE_AMOUNT, --差异金额
                   SS_DISCOUNT_REM_AMOUNT, --本期销售政策折让余额
                   COMMENTS, --备注
                   ENTITY_ID, --主体ID
                   CREATED_BY, --创建人
                   CREATION_DATE, --创建日期
                   LAST_UPDATED_BY, --最后更新人
                   LAST_UPDATE_DATE, --最后更新日期
                   SOA_COUNT_BATCH_ID,
                   SALES_MAIN_ID,  --品类ID
                   DIFF_DISCOUNT_AMOUNT,
                   DISCOUNT_TYPE
                   )      
                VALUES
                  (S_AR_SOA_ORDER_LINES.NEXTVAL, --S_AR_SOA_ORDER_LINES.NEXTVAL,
                   V_SOA_COUNT_BATCH_ID,
                   V_ORDER_TYPE, --'DISCOUNT_TYPE', --折让扣款
                   V_AMOUNT_J, --期初余额
                   V_AMOUNT_K, --本期累计折让
                   V_AMOUNT_L, --本期累计核销折让
                   V_AMOUNT_H, --本期折让余额
                   null, --客户确认的折让余额
                   null, --差异金额
                   null, --本期销售政策折让余额
                   null, --备注
                   CONF_ROW.ENTITY_ID,
                   'D',
                   SYSDATE,
                   null,
                   null,
                   V_SOA_COUNT_BATCH_ID,
                   ITEMCLASS_ROW.ITEM_CLASS_ID,
                   D_AMOUNT_K,
                   V_DISCOUNT_TYPE
                   );

              EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                     SQLCODE,
                                                     '插入确认式往来对账单折让扣款行失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id ||',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
              END;

             BEGIN
              V_RESULT := '插入折扣让利单数据到折扣历史表';
              INSERT INTO T_AR_SOA_DIS_ORDER_HIS
                (SOA_COUNT_BATCH_ID,  --对账单批次ID
                 SOURCE_ORDER_TYPE,   --来源单据类型：返利单
                 SOA_SALES_CENTER_ID, --对账单中心ID
                 SOA_ORDER_TYPE,      --对账单类型（余额确认式、借贷调节式）
                 SOA_ORDER_HEAD_ID,   --对账单ID
                 SOA_ORDER_NUMBER,    --对账单号
                 HEADER_ID,           --返利单ID
                 ENTITY_ID,
                 ORDER_TYPE_ID,       --单据类型iD
                 SALES_REGION_ID,
                 CUSTOMER_ID,
                 DISCOUNT_TYPE_ID,    --折扣类型ID
                 DISCOUNT_METHOD,     --折让方法
                 SALES_CENTER_ID,
                 --POLICY_CODE,
                 --DOC_CODE,
                 ORDER_NUMBER,
                 ORDERED_DATE,
                 ACCOUNT_DATE,        --结算日期
                 ACCOUNT_FLAG,
                 ITEM_TYPE,           --商品大类
                 DIS_AMOUNT,          --折让金额
                 INTEND_AMOUNT,       --含税金额
                 AMOUNT,              --总额
                 BI_LAST_UPDATE_DATE,
                 difference_AMOUNT,
                 difference_DIS_AMOUNT,
                 SOA_PERIOD_DATE,
                 SOA_BEGIN_DATE,
                 SOA_END_DATE,
                 HISTORY_ID,
                 CREATION_DATE,
                 DISCOUNT_TYPE
                 )
                SELECT V_SOA_COUNT_BATCH_ID,
                       '返利单' ,
                       null,
                       V_ORDER_TYPE,
                       V_SOA_COUNT_BATCH_ID,
                       V_ORDER_NUMBER,
                       t.SO_HEADER_ID,
                       t.ENTITY_ID,
                       t.BILL_TYPE_ID,        --单据类型
                       null,                --CDD.SALES_REGION_ID,
                       t.CUSTOMER_ID,
                       null,                --CDD.DISCOUNT_TYPE_ID,
                       t.DISCOUNT_MODE,
                       t.SALES_CENTER_ID,
                       --CDD.POLICY_CODE,
                       --CDD.DOC_CODE,
                       t.SO_NUM,
                       t.SO_DATE,
                       t.SETTLE_DATE,
                       t.SETTLE_FLAG,
                       null,                        --CDD.ITEM_TYPE,
                       t.DISCOUNT_AMOUNT,
                       null,
                       t.SETTLE_AMOUNT,
                       null,
                       0,
                       0,
                       V_PERIOD_DATE,
                       V_PERIOD_START_DATE,
                       V_PERIOD_END_DATE,
                       S_AR_SOA_DIS_ORDER_HIS.NEXTVAL,
                       SYSDATE,
                       V_DISCOUNT_TYPE
                      FROM T_SO_HEADER t
                     WHERE t.entity_id = ACCOUNT_ROW.entity_id
                       AND t.customer_id = ACCOUNT_ROW.customer_id
                       --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                       AND t.account_id = ACCOUNT_ROW.account_id
                       AND t.so_status <> '10'
                       AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
                       AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                       AND t.BIZ_SRC_BILL_TYPE_CODE in ('1009', '1010')
                       AND t.so_date >= V_PERIOD_START_DATE
                       AND t.so_date < V_PERIOD_END_DATE2;
            EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                     SQLCODE,
                                                     '插入折扣让利单数据到折扣历史表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id ||',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
              END;

            --插入明细表
            BEGIN
                V_RESULT := '插入本期返利单（折让）数据到明细表';
              --插入本期返利单（折让）数据到明细表
              INSERT INTO T_AR_SOA_ORDER_DETAILS
               (SOA_COUNT_BATCH_ID ,   --对账单批次ID
                SOURCE_ORDER_TYPE ,   --来源单据类型：到款单、销售单、返利单
                SOA_ORDER_TYPE ,   --对账单类型
                SOA_ORDER_HEAD_ID ,   --对账单ID
                SOA_ORDER_NUMBER ,   --对账单号
                HEADER_ID ,   --单据ID
                ENTITY_ID ,   --主体ID
                SALES_YEAR_ID ,   --销售年度
                ORDER_TYPE ,   --单据类型
                SALES_REGION_ID ,   --经营区域ID
                CUSTOMER_ID ,   --客户ID
                CUSTOMER_CODE ,   --客户编码
                CUSTOMER_NAME ,   --客户名称
                DISCOUNT_TYPE_ID ,   --折扣类型ID
                DISCOUNT_METHOD ,   --折让方法
                SALES_CENTER_ID ,   --营销中心ID
                ORDER_NUMBER ,   --单据编号
                ORDERED_DATE ,   --单据日期
                ACCOUNT_DATE ,   --结算日期
                ACCOUNT_FLAG ,   --结算标志
                ITEM_TYPE ,   --商品大类
                DIS_AMOUNT ,   --折让金额
                INTEND_AMOUNT ,   --含税金额
                AMOUNT ,   --到款金额
                DIFFERENCE_AMOUNT ,   --差异金额
                DIFFERENCE_DIS_AMOUNT ,   --差异折让金额
                SOA_PERIOD_DATE ,   --对账单周期
                SOA_BEGIN_DATE ,   --对账单开始日期
                SOA_END_DATE ,   --对账单结束日期
                HISTORY_ID ,   --历史ID
                DETAILS_ID ,   --明细ID
                DIFF_UPDATE_FLAG ,   --创建的历史差异已更新标志
                SOA_ADJUST_CODE ,   --注释：上期单据在本期调整金额
                CREATION_DATE ,   --录入日期
                REMARKS ,   --备注
                SALES_CENTER_CODE ,   --营销中心编码
                SALES_CENTER_NAME ,   --营销中心名称
                INVOICE_NUM_LIST ,   --发票号串：多个发票号用逗号分隔（,）。
                INVOICE_DATE ,   --发票日期：一张销售单只有一个发票开票日期。
                CASH_CODE ,   --票据号
                CASH_DATE ,   --出票日期
                DUE_DATE ,   --票据到期日期
                LIST_AMOUNT ,   --列表金额
                SETTLE_AMOUNT ,   --结算金额
                DISCOUNT_AMOUNT,    --核销折让金额
                ORDER_TYPE_ID,      --单据类型ID
                SALES_MAIN_ID,      --品类ID
                SALES_MAIN_NAME,--品类名称
                DISCOUNT_TYPE
                
                )    
              SELECT
                 V_SOA_COUNT_BATCH_ID,
                 '返利单据',
                 V_ORDER_TYPE,
                 V_SOA_COUNT_BATCH_ID,
                 V_ORDER_NUMBER,
                 t.SO_HEADER_ID,
                 t.ENTITY_ID,
                 null,
                 t.BILL_TYPE_NAME,
                 null,
                 t.CUSTOMER_ID,
                 t.CUSTOMER_CODE,
                 t.CUSTOMER_NAME,
                 null,
                 null,
                 t.SALES_CENTER_ID,
                 t.SO_NUM,
                 t.SO_DATE,
                 t.SETTLE_DATE,
                 t.SETTLE_FLAG,
                 null,
                 ROUND(e.PLUS_MINUS_FLAG * NVL(t.SETTLE_AMOUNT,0),2),--t.SETTLE_AMOUNT,
                 null,
                 null,
                 null,
                 null,
                 V_PERIOD_DATE,
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 /*(SELECT t.HISTORY_ID
                FROM T_AR_SOA_SO_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID),*/
                 null,
                 S_AR_SOA_ORDER_DETAILS.NEXTVAL,
                 null,
                 null,
                 sysdate,
--                 null,--备注
                 substrb(t.REMARK, 1, 1000),--备注
                 t.SALES_CENTER_CODE,
                 t.SALES_CENTER_NAME,
                 t.INVOICE_NUM_LIST,
                 t.INVOICE_DATE,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 t.BILL_TYPE_ID,
                 ITEMCLASS_ROW.ITEM_CLASS_ID,
                 ITEMCLASS_ROW.CLASS_CODE,
                 V_DISCOUNT_TYPE
                      FROM T_SO_HEADER t,T_SO_TYPE_EXTEND e
                      WHERE t.bill_type_id = e.bill_type_id
                       AND t.entity_id = ACCOUNT_ROW.entity_id
                       AND t.customer_id = ACCOUNT_ROW.customer_id
                       --AND t.sales_center_id = ACCOUNT_ROW.sales_center_id
                       AND t.account_id = ACCOUNT_ROW.account_id
                       AND t.BIZ_SRC_BILL_TYPE_CODE in ('1009', '1010')
                       AND t.so_status <> '10'
                       AND t.SALES_MAIN_TYPE = ITEMCLASS_ROW.CLASS_CODE
                        AND NVL(T.DISCOUNT_TYPE ,V_DISCOUNT_TYPE_COMMON) = V_DISCOUNT_TYPE
                       AND t.so_date >= V_PERIOD_START_DATE
                       AND t.so_date < V_PERIOD_END_DATE2;
                 EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                     SQLCODE,
                                                     '插入本期返利单数据到明细表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id ||',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
                  END;

            --判断返利单（折让）更新数据是否存在金额差异
            FOR SO_ROW IN C_SO LOOP
              SELECT COUNT(*)
                INTO V_COUNT11
                FROM T_AR_SOA_DIS_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID
                 AND nvl(t.diff_update_flag,'N') <> 'E';

              if(V_COUNT11 > 0) THEN
              BEGIN
                V_RESULT := '获取折让差异金额';
              SELECT NVL(t.DIS_AMOUNT,0)
                INTO V_DIS_AMOUNT
                FROM T_AR_SOA_DIS_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID
                 AND nvl(t.diff_update_flag,'N') <> 'E';
              EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                     SQLCODE,
                                                     '获取折让差异金额失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id ||',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  V_DIS_AMOUNT := 0;
                  CONTINUE;
                  END;

              if(V_DIS_AMOUNT <> SO_ROW.DISCOUNT_AMOUNT) THEN
              BEGIN
                V_RESULT := '插入上期返利单差异数据到明细表';
              --插入差异数据到明细表
              INSERT INTO T_AR_SOA_ORDER_DETAILS
               (SOA_COUNT_BATCH_ID ,   --对账单批次ID
                SOURCE_ORDER_TYPE ,   --来源单据类型：到款单、销售单、返利单
                SOA_ORDER_TYPE ,   --对账单类型
                SOA_ORDER_HEAD_ID ,   --对账单ID
                SOA_ORDER_NUMBER ,   --对账单号
                HEADER_ID ,   --单据ID
                ENTITY_ID ,   --主体ID
                SALES_YEAR_ID ,   --销售年度
                ORDER_TYPE ,   --单据类型
                SALES_REGION_ID ,   --经营区域ID
                CUSTOMER_ID ,   --客户ID
                CUSTOMER_CODE ,   --客户编码
                CUSTOMER_NAME ,   --客户名称
                DISCOUNT_TYPE_ID ,   --折扣类型ID
                DISCOUNT_METHOD ,   --折让方法
                SALES_CENTER_ID ,   --营销中心ID
                ORDER_NUMBER ,   --单据编号
                ORDERED_DATE ,   --单据日期
                ACCOUNT_DATE ,   --结算日期
                ACCOUNT_FLAG ,   --结算标志
                ITEM_TYPE ,   --商品大类
                DIS_AMOUNT ,   --折让金额
                INTEND_AMOUNT ,   --含税金额
                AMOUNT ,   --到款金额
                DIFFERENCE_AMOUNT ,   --差异金额
                DIFFERENCE_DIS_AMOUNT ,   --差异折让金额
                SOA_PERIOD_DATE ,   --对账单周期
                SOA_BEGIN_DATE ,   --对账单开始日期
                SOA_END_DATE ,   --对账单结束日期
                HISTORY_ID ,   --历史ID
                DETAILS_ID ,   --明细ID
                DIFF_UPDATE_FLAG ,   --创建的历史差异已更新标志
                SOA_ADJUST_CODE ,   --注释：上期单据在本期调整金额
                CREATION_DATE ,   --录入日期
                REMARKS ,   --备注
                SALES_CENTER_CODE ,   --营销中心编码
                SALES_CENTER_NAME ,   --营销中心名称
                INVOICE_NUM_LIST ,   --发票号串：多个发票号用逗号分隔（,）。
                INVOICE_DATE ,   --发票日期：一张销售单只有一个发票开票日期。
                CASH_CODE ,   --票据号
                CASH_DATE ,   --出票日期
                DUE_DATE ,   --票据到期日期
                LIST_AMOUNT ,   --列表金额
                SETTLE_AMOUNT ,   --结算金额
                DISCOUNT_AMOUNT,    --核销折让金额
                ORDER_TYPE_ID,      --单据类型ID
                SALES_MAIN_ID,      --品类ID
                SALES_MAIN_NAME,
                DISCOUNT_TYPE
                )    --品类名称
              VALUES
                (V_SOA_COUNT_BATCH_ID,
                 '返利单差异',
                 V_ORDER_TYPE,
                 V_SOA_COUNT_BATCH_ID,
                 V_ORDER_NUMBER,
                 SO_ROW.SO_HEADER_ID,
                 SO_ROW.ENTITY_ID,
                 null,
                 SO_ROW.BILL_TYPE_NAME,
                 null,
                 SO_ROW.CUSTOMER_ID,
                 SO_ROW.CUSTOMER_CODE,
                 SO_ROW.CUSTOMER_NAME,
                 null,
                 SO_ROW.DISCOUNT_MODE,
                 SO_ROW.SALES_CENTER_ID,
                 SO_ROW.SO_NUM,
                 SO_ROW.SO_DATE,
                 SO_ROW.SETTLE_DATE,
                 SO_ROW.SETTLE_FLAG,
                 null,
                 null,
                 null,
                 null,
                 null,
                 (SO_ROW.DISCOUNT_AMOUNT - V_DIS_AMOUNT),
                 V_PERIOD_DATE,
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 (SELECT t.HISTORY_ID
                FROM T_AR_SOA_SO_ORDER_HIS t
               WHERE t.ORDER_NUMBER = SO_ROW.SO_NUM
                 AND t.HEADER_ID = SO_ROW.SO_HEADER_ID
                 AND nvl(t.diff_update_flag,'N') <> 'E'),
                 S_AR_SOA_ORDER_DETAILS.NEXTVAL,
                 null,
                 null,
                 sysdate,
--                 null,--备注
                 substrb(SO_ROW.REMARK, 1, 1000),--备注
                 SO_ROW.SALES_CENTER_CODE,
                 SO_ROW.SALES_CENTER_NAME,
                 SO_ROW.INVOICE_NUM_LIST,
                 SO_ROW.INVOICE_DATE,
                 null,
                 null,
                 null,
                 null,
                 null,
                 null,
                 SO_ROW.BILL_TYPE_ID,
                 ITEMCLASS_ROW.ITEM_CLASS_ID,
                 ITEMCLASS_ROW.CLASS_CODE,
                 V_DISCOUNT_TYPE
                 );
                 EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                     SQLCODE,
                                                     '插入上期返利单差异数据到明细表失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id ||',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
                  CONTINUE;
                  END;
              end if;
            end if;
            END LOOP;

            /*elsif (V_ORDER_TYPE = '3' AND (V_COUNT4 > 0 OR V_COUNT5 > 0)) THEN
              BEGIN
                --插入调节试对账单行表
                INSERT INTO T_AR_SOA_ORDER_ADJUST_LINES
                  (ADJUST_LINE_ID, --行ID
                   HEADER_ID, --对账单头ID
                   DEBIT_PERIOD_AMOUNT, --借方期初余额(合计)
                   PRODUCT_AR_DEBIT_PERIOD_AMOUNT, --应收借方期初额（成品）
                   FITTING_AR_DEBIT_PERIOD_AMOUNT, --应收借方期初额（配件）
                   AR_DEBIT_AMOUNT,                --本期借方发生额（合计）
                   PRODUCT_AR_DEBIT_AMOUNT, --成品本期借方本期累计到款余额
                   PRODUCT_SALES_DEBIT_AMOUNT, --成品本期借方本期累计到款提贷金额
                   FITTING_AR_DEBIT_AMOUNT,    --配件本期借方本期累计到款余额
                   FITTING_SALES_DEBIT_AMOUNT, --配件本期借方本期累计到款提贷金额
                   ENTITY_ID, --主体ID
                   CREATED_BY, --创建人
                   CREATION_DATE, --创建日期
                   LAST_UPDATED_BY, --最后更新人
                   LAST_UPDATED_DATE） --最后更新日期)
                VALUES
                  (S_AR_SOA_ORDER_LINES.NEXTVAL,
                   V_SOA_COUNT_BATCH_ID,
                   (V_AMOUNT_A + 0), --借方期初余额(合计)
                   V_AMOUNT_A,   --应收借方期初额（成品）
                   0,            --应收借方期初额（配件）
                   (V_AMOUNT_D - V_AMOUNT_E + 0 - 0),         --本期借方发生额（合计）
                   V_AMOUNT_D, --成品本期借方本期累计到款余额
                   V_AMOUNT_E, --成品本期借方本期累计到款提贷金额
                   0,          --配件本期借方本期累计到款余额
                   0,          --配件本期借方本期累计到款提贷金额
                   CONF_ROW.ENTITY_ID,
                   NULL,
                   SYSDATE,
                   NULL,
                   NULL);

              EXCEPTION
                WHEN OTHERS THEN
                  V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                     SQLCODE,
                                                     '插入调节试对账单行表！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                     substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
                  P_RESULT := V_RESULT;
                  --RAISE V_ERR_EXCEPT;
              END;*/

            end if;

          END LOOP;

          --end if;

          END LOOP;
          
          
          --插入确认式往来对账单折让扣款行
          BEGIN
               INSERT INTO T_AR_SOA_ORDER_DIS_LINES
                  (DISCOUNT_LINE_ID, --到款行ID
                   HEADER_ID, --对账单头ID
                   SOA_TYPE, --对账类型
                   PERIOD_AMOUNT, --期初余额
                   DISCOUNT_AMOUNT, --本期累计折让
                   DIS_SALES_AMOUNT, --本期累计核销折让
                   CURRENT_AMOUNT, --本期折让余额
                   CUS_DISCOUNT_AMOUNT, --客户确认的折让余额
                   DIFFERENACE_AMOUNT, --差异金额
                   SS_DISCOUNT_REM_AMOUNT, --本期销售政策折让余额
                   COMMENTS, --备注
                   ENTITY_ID, --主体ID
                   CREATED_BY, --创建人
                   CREATION_DATE, --创建日期
                   LAST_UPDATED_BY, --最后更新人
                   LAST_UPDATE_DATE, --最后更新日期
                   SOA_COUNT_BATCH_ID,
                   SALES_MAIN_ID,  --品类ID
                   DIFF_DISCOUNT_AMOUNT)   
               SELECT  S_AR_SOA_ORDER_LINES.NEXTVAL,
                       HEADER_ID, --对账单头ID
                       SOA_TYPE, --对账类型
                       PERIOD_AMOUNT, --期初余额
                       DISCOUNT_AMOUNT, --本期累计折让
                       DIS_SALES_AMOUNT, --本期累计核销折让
                       CURRENT_AMOUNT, --本期折让余额
                       CUS_DISCOUNT_AMOUNT, --客户确认的折让余额
                       DIFFERENACE_AMOUNT, --差异金额
                       SS_DISCOUNT_REM_AMOUNT, --本期销售政策折让余额
                       COMMENTS, --备注
                       ENTITY_ID, --主体ID
                       'admin', --创建人
                       CREATION_DATE, --创建日期
                       LAST_UPDATED_BY, --最后更新人
                       LAST_UPDATE_DATE, --最后更新日期
                       SOA_COUNT_BATCH_ID,
                       SALES_MAIN_ID,  --品类ID
                       DIFF_DISCOUNT_AMOUNT
               from   
                (SELECT 
                       D.HEADER_ID,
                       D.SOA_TYPE,
                       D.SALES_MAIN_ID,
                       SUM(D.PERIOD_AMOUNT) PERIOD_AMOUNT,
                       SUM(D.DISCOUNT_AMOUNT) DISCOUNT_AMOUNT,
                       SUM(D.DIS_SALES_AMOUNT) DIS_SALES_AMOUNT,
                       SUM(D.CURRENT_AMOUNT) CURRENT_AMOUNT,
                       SUM(D.CUS_DISCOUNT_AMOUNT) CUS_DISCOUNT_AMOUNT,
                       SUM(D.DIFFERENACE_AMOUNT) DIFFERENACE_AMOUNT,
                       SUM(D.SS_DISCOUNT_REM_AMOUNT) SS_DISCOUNT_REM_AMOUNT,
                       MAX(D.COMMENTS) COMMENTS,
                       D.ENTITY_ID,
                       MAX(D.CREATED_BY) CREATED_BY,
                       MAX(D.CREATION_DATE) CREATION_DATE,
                       MAX(D.LAST_UPDATED_BY) LAST_UPDATED_BY,
                       MAX(D.LAST_UPDATE_DATE) LAST_UPDATE_DATE,
                       D.SOA_COUNT_BATCH_ID,
                       SUM(D.DIFF_DISCOUNT_AMOUNT) DIFF_DISCOUNT_AMOUNT
                  FROM CIMS.T_AR_SOA_ORDER_DIS_LINES D
                 WHERE D.HEADER_ID = V_SOA_COUNT_BATCH_ID
                 AND D.CREATED_BY = 'D'
                 GROUP BY D.ENTITY_ID,
                          D.HEADER_ID,
                          D.HEADER_ID,
                          D.SOA_TYPE,
                          D.SALES_MAIN_ID,
                          D.SOA_COUNT_BATCH_ID ) A;       
                          
                   DELETE CIMS.T_AR_SOA_ORDER_DIS_LINES L WHERE L.HEADER_ID = V_SOA_COUNT_BATCH_ID AND L.CREATED_BY = 'D'; 
          EXCEPTION
            WHEN OTHERS THEN
              V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_ALL',
                                                 SQLCODE,
                                                 '插入往来对账客户表！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id || ',账期:' || V_PERIOD_DATE || '！:' || substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
              P_RESULT := V_RESULT;
              CONTINUE;
          END;
          
          
          
          

        --end if;
        --end if;

        BEGIN
            V_RESULT := 'SUCCESS';
            --插入往来对账客户表
            INSERT INTO T_AR_STATEMENT_ACC_HISTORY
              (ACC_HISTORY_ID,
               HEADER_ID,
               CUSTOMER_ID,
               CUSTOMER_CODE,
               CUSTOMER_NAME,
               CUSTOMER_FLAG,
               SALES_CENTER_ID,
               HANDMODE_FLAG,
               COUNT_START_DATE,
               COUNT_END_DATE,
               COUNT_PERIOD,
               ORDER_TYPE,
               ORDER_NUMBER,
               SOA_RECEIPT_BATCH_ID,
               SOA_SO_ORDER_BATHC_ID,
               SOA_DISCOUNT_BACHT_ID,
               STATES,
               COUNT_RESULT,
               COMMENTS,
               ENTITY_ID,
               CREATED_BY,
               CREATION_DATE,
               LAST_UPDATED_BY,
               LAST_UPDATE_DATE,
               SOA_COUNT_BATCH_ID)
            VALUES
              (S_AR_STATEMENT_ACC_HISTORY.NEXTVAL,
               NULL,
               ACCOUNT_ROW.CUSTOMER_ID,
               ACCOUNT_ROW.CUSTOMER_CODE,
               ACCOUNT_ROW.CUSTOMER_NAME,
               NULL,
               ACCOUNT_ROW.SALES_CENTER_ID,
               'N',
               V_PERIOD_START_DATE,
               V_PERIOD_END_DATE,
               V_PERIOD_DATE,
               --NVL(CSC.ORDER_TYPE, '余额确认式'),
               /*NVL((select CSC.ORDER_TYPE
                     from T_AR_CUSG_SOA_CONF CSC
                    where CSC.CUSTOMER_ID = ACCOUNT_ROW.CUSTOMER_ID
                      and CSC.SALES_CENTER_ID = ACCOUNT_ROW.SALES_CENTER_ID
                      and CSC.ENTITY_ID = ACCOUNT_ROW.ENTITY_ID),
                   '1'),*/
               '',
               V_ORDER_NUMBER,
               NULL,
               NULL,
               NULL,
               'COMPLETED',
               V_RESULT,
               NULL,
               ACCOUNT_ROW.ENTITY_ID,
               NULL,
               SYSDATE,
               NULL,
               NULL,
               V_SOA_COUNT_BATCH_ID);

          EXCEPTION
            WHEN OTHERS THEN
              V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                 SQLCODE,
                                                 '插入往来对账客户表！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id ||',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') || ',账期:' || V_PERIOD_DATE || '！:' || substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
              P_RESULT := V_RESULT;
              --RAISE V_ERR_EXCEPT;
              CONTINUE;
          END;

        COMMIT;

        EXCEPTION
          WHEN OTHERS THEN

              ROLLBACK;
              P_RESULT := V_RESULT;
              --RAISE V_ERR_EXCEPT;
              --插入往来对账客户表
              V_RESULT2 := PKG_AR_ACCOUNT.F_ADD_SOA_HISTORY
                 (NULL,
                 ACCOUNT_ROW.CUSTOMER_ID,
                 ACCOUNT_ROW.CUSTOMER_CODE,
                 ACCOUNT_ROW.CUSTOMER_NAME,
                 NULL,
                 ACCOUNT_ROW.SALES_CENTER_ID,
                 'N',
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 V_PERIOD_DATE,
                 --NVL(CSC.ORDER_TYPE, '余额确认式'),
                 NULL,
                 V_ORDER_NUMBER,
                 NULL,
                 NULL,
                 NULL,
                 'FAILURE',
                 V_RESULT,
                 NULL,
                 ACCOUNT_ROW.ENTITY_ID,
                 NULL,
                 SYSDATE,
                 NULL,
                 NULL,
                 V_SOA_COUNT_BATCH_ID);
              /*
              INSERT INTO T_AR_STATEMENT_ACC_HISTORY
                (ACC_HISTORY_ID,
                 HEADER_ID,
                 CUSTOMER_ID,
                 CUSTOMER_CODE,
                 CUSTOMER_NAME,
                 CUSTOMER_FLAG,
                 SALES_CENTER_ID,
                 HANDMODE_FLAG,
                 COUNT_START_DATE,
                 COUNT_END_DATE,
                 COUNT_PERIOD,
                 ORDER_TYPE,
                 ORDER_NUMBER,
                 SOA_RECEIPT_BATCH_ID,
                 SOA_SO_ORDER_BATHC_ID,
                 SOA_DISCOUNT_BACHT_ID,
                 STATES,
                 COUNT_RESULT,
                 COMMENTS,
                 ENTITY_ID,
                 CREATED_BY,
                 CREATION_DATE,
                 LAST_UPDATED_BY,
                 LAST_UPDATE_DATE,
                 SOA_COUNT_BATCH_ID)
              VALUES
                (S_AR_STATEMENT_ACC_HISTORY.NEXTVAL,
                 NULL,
                 ACCOUNT_ROW.CUSTOMER_ID,
                 ACCOUNT_ROW.CUSTOMER_CODE,
                 NULL,
                 NULL,
                 ACCOUNT_ROW.SALES_CENTER_ID,
                 'N',
                 V_PERIOD_START_DATE,
                 V_PERIOD_END_DATE,
                 V_PERIOD_DATE,
                 --NVL(CSC.ORDER_TYPE, '余额确认式'),
                 NULL,
                 V_ORDER_NUMBER,
                 NULL,
                 NULL,
                 NULL,
                 'FAILURE',
                 V_RESULT,
                 NULL,
                 ACCOUNT_ROW.ENTITY_ID,
                 NULL,
                 SYSDATE,
                 NULL,
                 NULL,
                 V_SOA_COUNT_BATCH_ID);
              COMMIT;
              */
              CONTINUE;
        END;

      END LOOP;

    EXCEPTION
      WHEN OTHERS THEN

        ROLLBACK;
        V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                   SQLCODE,
                                                   '对账失败！主体:' || ACCOUNT_ROW.entity_id || ',客户ID:' || ACCOUNT_ROW.customer_id || ',账户ID:' || ACCOUNT_ROW.account_id ||',开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| ',结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') || ',账期:' || V_PERIOD_DATE || '！:' ||
                                                   substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
        P_RESULT := V_RESULT;
        --RAISE V_ERR_EXCEPT;
        --CONTINUE;
    END;

    COMMIT;
    P_RESULT := 'SUCCESS';
    END IF;

  EXCEPTION
    WHEN V_ERR_EXCEPT THEN
      ROLLBACK;
      V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                   SQLCODE,
                                                   '对账失败！'||nvl(V_RESULT, '')||'：' ||
                                                   substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
      P_RESULT := V_RESULT;
    WHEN OTHERS THEN
      ROLLBACK;
      V_RESULT := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ACCOUNT.P_CUSG_SOA_COUNT_HAND',
                                                   SQLCODE,
                                                   '对账失败！主体：'||P_ENTITY_ID||'、客户：'||P_CUSTOMER_ID||'、账户：'||P_ACCOUNT_ID||'、开始日期:' || to_char(P_COUNT_START_DATE, 'yyyy-MM-dd')|| '、结束日期:' || to_char(P_COUNT_END_DATE, 'yyyy-MM-dd') ||'：' ||
                                                   substr(dbms_utility.format_error_backtrace, 1, 100) ||SQLERRM);
      P_RESULT := V_RESULT;
      --RAISE V_ERR_EXCEPT;
      --CONTINUE;
  END;

  function F_ADD_SOA_HISTORY
  ----插入往来对账客户表
  (F_HEADER_ID IN NUMBER,
   F_CUSTOMER_ID IN NUMBER,
   F_CUSTOMER_CODE in varchar2,
   F_CUSTOMER_NAME in varchar2,
   F_CUSTOMER_FLAG in varchar2,
   F_SALES_CENTER_ID in NUMBER,
   F_HANDMODE_FLAG in varchar2,
   F_COUNT_START_DATE in DATE,
   F_COUNT_END_DATE in DATE,
   F_COUNT_PERIOD in varchar2,
   F_ORDER_TYPE in varchar2,
   F_ORDER_NUMBER in varchar2,
   F_SOA_RECEIPT_BATCH_ID in NUMBER,
   F_SOA_SO_ORDER_BATHC_ID in NUMBER,
   F_SOA_DISCOUNT_BACHT_ID in NUMBER,
   F_STATES in varchar2,
   F_COUNT_RESULT in varchar2,
   F_COMMENTS in varchar2,
   F_ENTITY_ID in NUMBER,
   F_CREATED_BY in varchar2,
   F_CREATION_DATE in DATE,
   F_LAST_UPDATED_BY in varchar2,
   F_LAST_UPDATE_DATE in DATE,
   F_SOA_COUNT_BATCH_ID in NUMBER)
   return varchar2
   is
    L_RETURN_MSG varchar2(255);
    pragma autonomous_transaction;

  begin
    L_RETURN_MSG := 'SUCCESS';
    --启用独立事务
    begin
      --插入往来对账客户表
      INSERT INTO T_AR_STATEMENT_ACC_HISTORY
      (ACC_HISTORY_ID,
      HEADER_ID,
      CUSTOMER_ID,
      CUSTOMER_CODE,
      CUSTOMER_NAME,
      CUSTOMER_FLAG,
      SALES_CENTER_ID,
      HANDMODE_FLAG,
      COUNT_START_DATE,
      COUNT_END_DATE,
      COUNT_PERIOD,
      ORDER_TYPE,
      ORDER_NUMBER,
      SOA_RECEIPT_BATCH_ID,
      SOA_SO_ORDER_BATHC_ID,
      SOA_DISCOUNT_BACHT_ID,
      STATES,
      COUNT_RESULT,
      COMMENTS,
      ENTITY_ID,
      CREATED_BY,
      CREATION_DATE,
      LAST_UPDATED_BY,
      LAST_UPDATE_DATE,
      SOA_COUNT_BATCH_ID)
      VALUES
      (S_AR_STATEMENT_ACC_HISTORY.NEXTVAL,
      F_HEADER_ID,
      F_CUSTOMER_ID,
      F_CUSTOMER_CODE,
      F_CUSTOMER_NAME,
      F_CUSTOMER_FLAG,
      F_SALES_CENTER_ID,
      F_HANDMODE_FLAG,
      F_COUNT_START_DATE,
      F_COUNT_END_DATE,
      F_COUNT_PERIOD,
      F_ORDER_TYPE,
      F_ORDER_NUMBER,
      F_SOA_RECEIPT_BATCH_ID,
      F_SOA_SO_ORDER_BATHC_ID,
      F_SOA_DISCOUNT_BACHT_ID,
      F_STATES,
      F_COUNT_RESULT,
      F_COMMENTS,
      F_ENTITY_ID,
      F_CREATED_BY,
      F_CREATION_DATE,
      F_LAST_UPDATED_BY,
      F_LAST_UPDATE_DATE,
      F_SOA_COUNT_BATCH_ID);
      commit;

    exception
      when others then
        rollback;
        L_RETURN_MSG := 'FAIL';
    end;

    return L_RETURN_MSG;
    end;

end PKG_AR_ACCOUNT;
/

