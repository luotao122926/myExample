create view V_BD_ITEM_ASSEMBLIES_CCS as
select a.item_code        product_assembly_code,
       a.item_name        product_assembly_name,
       b.item_code        product_sub_code,
       b.item_name        product_sub_name,
       b.value_scale,
       b.fittings_flag,
       b.quantity,
       a.ENTITY_ID,
       a.created_by,
       a.creation_date,
       a.last_updated_by,
       a.last_update_date
  from T_BD_ITEM_ASSEMBLIES a, t_Bd_Item_Assemblies_Sub b
 where a.item_assembly_id = b.item_assembly_id
/

comment on column V_BD_ITEM_ASSEMBLIES_CCS.PRODUCT_ASSEMBLY_CODE is '产品编码'
/

comment on column V_BD_ITEM_ASSEMBLIES_CCS.PRODUCT_ASSEMBLY_NAME is '产品名称'
/

comment on column V_BD_ITEM_ASSEMBLIES_CCS.PRODUCT_SUB_CODE is '散件产品编码'
/

comment on column V_BD_ITEM_ASSEMBLIES_CCS.PRODUCT_SUB_NAME is '散件产品名称'
/

comment on column V_BD_ITEM_ASSEMBLIES_CCS.VALUE_SCALE is '价值比例'
/

comment on column V_BD_ITEM_ASSEMBLIES_CCS.FITTINGS_FLAG is '配件标志'
/

comment on column V_BD_ITEM_ASSEMBLIES_CCS.QUANTITY is '数量'
/

comment on column V_BD_ITEM_ASSEMBLIES_CCS.ENTITY_ID is '主体'
/

