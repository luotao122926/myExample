create view V_INV_PO_LINES as
select
  po_line_id ,
  po_id  ,
  po_line_num ,
  item_id ,
  item_code,
  item_name,
  item_bar_code ,
  uom_code  ,
  item_price ,
  billed_qty ,
  shipped_qty,
  received_qty,
  executed_qty ,
  canceled_qty,
  compensate_qty,
  shatter_qty ,
  transfer_fee_price,
  load_fee_off_price,
  load_fee_price,
  volume_uom ,
  volume_total,
  weight_uom ,
  weight_total
from T_INV_PO_LINES
/

comment on column V_INV_PO_LINES.PO_LINE_ID is '采购单行ID'
/

comment on column V_INV_PO_LINES.PO_ID is '采购单ID'
/

comment on column V_INV_PO_LINES.PO_LINE_NUM is '采购单行编码'
/

comment on column V_INV_PO_LINES.ITEM_ID is '产品ID'
/

comment on column V_INV_PO_LINES.ITEM_CODE is '产品编码，即销售码'
/

comment on column V_INV_PO_LINES.ITEM_NAME is '产品名称'
/

comment on column V_INV_PO_LINES.ITEM_BAR_CODE is '产品标识'
/

comment on column V_INV_PO_LINES.UOM_CODE is '产品单位'
/

comment on column V_INV_PO_LINES.ITEM_PRICE is '产品价格'
/

comment on column V_INV_PO_LINES.BILLED_QTY is '开单数量'
/

comment on column V_INV_PO_LINES.SHIPPED_QTY is '发货数量，发货数量与开单数量一样。'
/

comment on column V_INV_PO_LINES.RECEIVED_QTY is '接收数量，安得回写的实际收货数量。'
/

comment on column V_INV_PO_LINES.EXECUTED_QTY is '执行数量'
/

comment on column V_INV_PO_LINES.CANCELED_QTY is '红冲数量'
/

comment on column V_INV_PO_LINES.COMPENSATE_QTY is '全赔数量'
/

comment on column V_INV_PO_LINES.SHATTER_QTY is '破损数量'
/

comment on column V_INV_PO_LINES.TRANSFER_FEE_PRICE is '中转费总金额'
/

comment on column V_INV_PO_LINES.LOAD_FEE_OFF_PRICE is '下线装卸费金额'
/

comment on column V_INV_PO_LINES.LOAD_FEE_PRICE is '出入库装卸费金额'
/

comment on column V_INV_PO_LINES.VOLUME_UOM is '单位体积'
/

comment on column V_INV_PO_LINES.VOLUME_TOTAL is '总体积'
/

comment on column V_INV_PO_LINES.WEIGHT_UOM is '单位重量'
/

comment on column V_INV_PO_LINES.WEIGHT_TOTAL is '总重量'
/

