create view V_INV_LG_SHIPDOC as
SELECT '01' AS bill_type, toh.trsf_order_id AS so_header_id,     --财务单ID
          toh.trsf_order_num AS so_num,                             --财务单号
                                       toh.vehicle_num AS vehicle_num,
          tol.ship_doc_line_id AS ship_doc_line_id,             --发货通知行ID
          tol.billed_qty AS item_qty                                --产品数量
     FROM t_inv_trsf_order toh, t_inv_trsf_order_line tol
    WHERE toh.trsf_order_id = tol.trsf_order_id
      AND tol.order_line_id_orig IS NOT NULL
   UNION ALL
   SELECT '02' AS bill_type, tsh.stockup_order_id AS so_header_id,  --财务单ID
          tsh.stockup_order_num AS so_num, tsh.vehicle_code AS vehicle_num,
          tsl.ship_doc_line_id AS ship_doc_line_id,
          tsl.billed_qty AS item_qty
     FROM t_inv_stockup_order tsh, t_inv_stockup_order_line tsl
    WHERE tsh.stockup_order_id = tsl.stockup_order_id
/

