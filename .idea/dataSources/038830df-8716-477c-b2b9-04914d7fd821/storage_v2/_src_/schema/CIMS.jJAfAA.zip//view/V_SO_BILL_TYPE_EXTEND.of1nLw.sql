create view V_SO_BILL_TYPE_EXTEND as
SELECT STE.ENTITY_ID, --实体ID
       STE.BILL_TYPE_ID,--单据类型ID
       STE.BILL_TYPE_CODE,--单据类型编码
       STE.BILL_TYPE_NAME,--单据类型名称
       STE.ORIG_BILL_TYPE_ID,--蓝单据类型
       STE.SETTLE_TYPE_CODE,--结算类型编码
       STE.SETTLE_TYPE_NAME,--结算类型名称
       STE.TOTAL_AMOUNT,--总金额
       STE.TOTAL_LINE,--总行数
       STE.BASE_PRICE_CTRL_FLAG,--底价控制
       STE.SETTLE_FLAG,--是否参与结算
       STE.SETTLE_AUTO_FLAG,--是否自动结算
       --STE.NEGATIVE_INV_FLAG,--是否允许负库存
       VBT.NEGATIVE_INVENTORY_FLAG AS NEGATIVE_INV_FLAG, --是否允许负库存，是  Y，否 N，默认为 是 Y
       STE.PLUS_MINUS_FLAG,--信用控制正负值标识：用于信用计算时标识出单据的数据正负，值为1或-1。用于信用模块计算！
       STE.REVERSAL_BILL_FLAG,--是否红冲单
       STE.REVERSAL_ALL_FLAG,--是否完全红冲
       STE.RETURN_BILL_FLAG,--是否退货单
       STE.AUTO_AUDIT_FLAG,--是否自动审核
       STE.TO_ERP_FLAG,--是否引到ERP系统
       STE.CAN_APPLIED_FLAG, --是否参与核销标识
       STE.APPLIED_PLUS_MINUS_FLAG, --核销正负值标识：用于财务核销时标识出单据的数据正负，值为1或-1。
       STE.INV_TRANSACTION_FLAG, --是否库存事务处理：Y-是，N-否
       STE.VALID_DAYS,--时效天数
       STE.ALERT_DAYS,--报警天数
       STE.AUTO_CHG_DISCOUNT,--自动修改折扣
       STE.PRICE_MODIFY_FLAG, --是否允许修改产品价格：Y-是，N-否
       STE.DISCOUNT_MODIFY_FLAG, --是否允许修改折扣，Y是，N否默认为Y
       STE.MONTHDISCOUNT_MODIFY_FLAG, --是否允许修改月返，Y是，N否默认为Y
       NVL(STE.PROMOTION_FLAY,'N') AS PROMOTION_FLAY,--是否推广物料 ，Y是，N否
       STE.EFFCT_FLAG,--是否生效
       VBT.BILL_PERIOD_HEAD_ID, --单据周期头ID
       VBT.BILL_PERIOD_NAME, --单据周期名称
       VBT.BEGIN_DATE, --单据生效日期
       VBT.END_DATE, --单据失效日期
       VBT.SRC_TYPE_ID, --单据源类型ID
       VBT.SRC_TYPE_CODE, --单据源类型编码
       VBT.SRC_TYPE_NAME, --单据源类型名称
       VBT.ERP_SOURCE_TYPE_CODE, --ERP事务源类型
       VBT.ERP_SOURCE_TYPE_NAME --ERP事务源类型名称
  FROM T_SO_TYPE_EXTEND STE
  LEFT JOIN V_SO_BILL_TYPE VBT ON (VBT.BILL_TYPE_CODE = STE.BILL_TYPE_CODE AND STE.ENTITY_ID=VBT.ENTITY_ID)
with read only
/

