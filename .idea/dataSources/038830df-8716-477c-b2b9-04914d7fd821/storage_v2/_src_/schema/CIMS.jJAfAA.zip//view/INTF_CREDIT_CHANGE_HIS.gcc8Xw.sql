create view INTF_CREDIT_CHANGE_HIS as
select T.CREDIT_CHANGE_HIS_ID ,
         T.ENTITY_ID,
         T.CUSTOMER_ID,
         T.CUSTOMER_CODE,
         T.CUSTOMER_NAME,
         T.SALES_CENTER_CODE,
         T.SALES_CENTER_NAME,
         T.SALES_MAIN_TYPE,
         T.CUSTOMER_LEVEL,
         T.CREDIT_RATING_ID,
         T.CREDIT_RATING_NAME,
         T.CREDIT_CHANGE_DATE,
         T.CREDIT_CHANGE_REASON,
         T.CREATED_BY,
         T.CREATION_DATE,
         T.LAST_UPDATED_BY,
         T.LAST_UPDATE_DATE
    from T_CREDIT_CHANGE_HIS T with read only
/

comment on column INTF_CREDIT_CHANGE_HIS.CREDIT_CHANGE_HIS_ID is '变更历史信息ID'
/

comment on column INTF_CREDIT_CHANGE_HIS.ENTITY_ID is '经营主体ID'
/

comment on column INTF_CREDIT_CHANGE_HIS.CUSTOMER_ID is '客户ID'
/

comment on column INTF_CREDIT_CHANGE_HIS.CUSTOMER_CODE is '客户编码'
/

comment on column INTF_CREDIT_CHANGE_HIS.CUSTOMER_NAME is '客户名称'
/

comment on column INTF_CREDIT_CHANGE_HIS.SALES_CENTER_CODE is '营销中心编码（一个客户属于多个中心时，需要以多值逗号分隔的形式存储）'
/

comment on column INTF_CREDIT_CHANGE_HIS.SALES_CENTER_NAME is '营销中心名称  '
/

comment on column INTF_CREDIT_CHANGE_HIS.SALES_MAIN_TYPE is '营销大类'
/

comment on column INTF_CREDIT_CHANGE_HIS.CUSTOMER_LEVEL is '客户等级'
/

comment on column INTF_CREDIT_CHANGE_HIS.CREDIT_RATING_ID is '信用等级ID'
/

comment on column INTF_CREDIT_CHANGE_HIS.CREDIT_RATING_NAME is '信用等级名称'
/

comment on column INTF_CREDIT_CHANGE_HIS.CREDIT_CHANGE_DATE is '调整日期'
/

comment on column INTF_CREDIT_CHANGE_HIS.CREDIT_CHANGE_REASON is '调整原因'
/

comment on column INTF_CREDIT_CHANGE_HIS.CREATED_BY is '创建人'
/

comment on column INTF_CREDIT_CHANGE_HIS.CREATION_DATE is '创建日期'
/

comment on column INTF_CREDIT_CHANGE_HIS.LAST_UPDATED_BY is '最后修改人'
/

comment on column INTF_CREDIT_CHANGE_HIS.LAST_UPDATE_DATE is '最后修改日期'
/

