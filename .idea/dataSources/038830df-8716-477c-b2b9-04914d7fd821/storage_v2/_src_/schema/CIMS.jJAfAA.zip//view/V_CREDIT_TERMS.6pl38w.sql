create view V_CREDIT_TERMS as
SELECT b.entity_id,                                                --主体ID
                      c.customer_id,                                  --客户ID
                                    c.customer_code,                --客户编码
                                                    c.customer_name,
                                                                    --客户名称
          NVL(B.ACCOUNT_ID,0) AS ACCOUNT_ID,
                                                                  --账户ID 梁颜明 20140425 增加账户ID
          TO_CHAR(B.SALES_CENTER_IDS) AS SALES_CENTER_ID,
                                                                  --营销中心ID 梁颜明 20140425 增加账户ID
          B.SALES_CENTER_CODES sales_center_code,
                                                                --营销中心编码 梁颜明 20140425 增加账户ID
          B.SALES_CENTER_NAMES sales_center_name,
                                                                --营销中心名称 梁颜明 20140425 增加账户ID
          (c.customer_id || b.Credit_Customer_Id) sales_main_type_id,
                                                                    --营销大类 梁颜明 20140425 增加账户ID
          b.sales_main_type_name,                               --营销大类名称
                                 b.sales_main_type_code,        --营销大类编码
                                                        b.custom_level,
                                                                    --客户等级
          b.custom_credit_level,                                    --信用等级
                                NVL (b.credit_line, 0) credit_line, --信用额度

          /*nvl((SELECT SUM(T.ADJ_AMOUNT)
             FROM T_CREDIT_ADJ_REQUIS T
            WHERE T.CUSTOMER_ID = B.CUSTOM_ID
              AND T.ENTITY_ID = B.ENTITY_ID
              AND T.SALES_MAIN_TYPE = B.SALES_MAIN_TYPE_CODE
              AND T.BILL_STATUS = '3'
              AND SYSDATE BETWEEN T.BEGIN_DATE AND NVL(T.END_DATE,SYSDATE)),0) requis_amount, --调整额度*/
          pkg_credit_tools.fun_get_adj_amount
                                        (b.entity_id,
                                         b.customer_id,
                                         b.sales_main_type_code,
                                         B.ACCOUNT_ID
                                        ) requis_amount,            --调整额度 梁颜明 20140425 增加账户ID

          /*(SELECT nvl(SUM(T.delaypay_amount),0)
                 FROM T_SALES_ACCOUNT_MX_AMOUNT T
                WHERE T.ENTITY_ID = B.ENTITY_ID
                  AND T.CUSTOMER_ID = C.CUSTOMER_ID
                  AND T.SALES_MAIN_TYPE = B.SALES_MAIN_TYPE_CODE)*/
          (  pkg_credit_tools.fun_get_use_delay (b.entity_id,
                                                 b.customer_id,
                                                 b.sales_main_type_code,
                                                 B.ACCOUNT_ID
                                                )
           - pkg_credit_tools.fun_get_threedelay_amount
                                                       (b.entity_id,
                                                        b.customer_id,
                                                        b.sales_main_type_code,
                                                        B.ACCOUNT_ID
                                                       )
          ) user_delaypay,                                        --已使用铺底 梁颜明 20140425 增加账户ID
          pkg_credit_tools.fun_get_can_use_amount
                              (b.entity_id,
                               b.customer_id,
                               NVL (b.credit_line, 0),
                               NVL (b.lastyear_credit_line, 0),
                               NVL (b.thisyear_credit_line, 0),
                               NVL (b.copper_date, 0),
                               NVL (b.twelve_amount, 0),
                               b.sales_main_type_code,
                               B.ACCOUNT_ID
                              ) remainder_amount,                   --可用额度 梁颜明 20140425 增加账户ID

          /*(nvl(b.credit_line,0)
            + PKG_CREDIT_TOOLS.FUN_GET_ADJ_AMOUNT(B.ENTITY_ID,B.CUSTOM_ID,B.SALES_MAIN_TYPE_CODE)
            - PKG_CREDIT_TOOLS.FUN_GET_USE_DELAY(B.ENTITY_ID,B.CUSTOM_ID,B.SALES_MAIN_TYPE_CODE)
            + PKG_CREDIT_TOOLS.FUN_GET_THREEDELAY_AMOUNT(B.ENTITY_ID,B.CUSTOM_ID,B.SALES_MAIN_TYPE_CODE)) remainder_amount,*/ --可用额度
          b.lastyear_credit_line,                             --上年度信用额度
                                 b.thisyear_credit_line,      --本年度信用额度
                                                        b.copper_date,
                                                                    --合作天数
          b.twelve_amount,                               --前12个月销售提货金额
          b.lastyear_sales_amount_avg,  --上年月均销售金额
          b.thisyear_sales_amount_avg,  --本年月均销售金额
          b.thisyear_delaypay_avg       --本年月均铺底
     FROM T_CREDIT_CUSTOMER b,
          t_customer_header c                      /*,
                      T_CUSTOMER_ORG              E, --客户组织信息
                      T_CUSTOMER_ACC_ORG_RELATION F --客户账户和分部对应关系*/
    WHERE c.customer_id = b.customer_id
      AND NVL (UPPER (c.active_flag), 'ACTIVE') = 'ACTIVE'
/

comment on column V_CREDIT_TERMS.LASTYEAR_SALES_AMOUNT_AVG is '上年月均销售金额'
/

comment on column V_CREDIT_TERMS.THISYEAR_SALES_AMOUNT_AVG is '本年月均销售金额'
/

comment on column V_CREDIT_TERMS.THISYEAR_DELAYPAY_AVG is '本年月均铺底'
/

