create PACKAGE      PKG_SO_IO_ERP AS
  ------------------------------------------------------------------------------------------------
  --                                                                                            --
  --  销售跟ERP有 DBLINK 交互方式 的程序包                                                                              --
  --                                                                                            --
  --                                                                 --
  ------------------------------------------------------------------------------------------------

  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2016-10-19
  --处理内部客户关联交易号更新事物接口
  --------------------------------------------------------------------------
  Procedure P_ENTITY_CUST_TRANSACTION_INTF(
                            IN_ENTITY_ID IN NUMBER
                             , OS_MESSAGE OUT VARCHAR2); --返回值
                              
                              
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-12
  --处理ERP接口错误自动修复
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_OE_HEADERS(
                             IN_SPACE_TIME IN NUMBER
                             ,IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2); --返回值     
                            
                            
                            
   --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-12
  --处理ERP接口错误自动修复   --SO变更
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_OE_CHANGE(
                            IN_SPACE_TIME IN NUMBER
                            ,IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2);  
                            
                            
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-29
  --处理ERP接口错误自动修复   --关联订单
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_REQ_HEADERS(
                            IN_SPACE_TIME IN NUMBER
                            ,IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2);
                            
    --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-29
  --处理ERP接口错误自动修复   --关联物流发出
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_REQ_SEND(
                            IN_SPACE_TIME IN NUMBER
                            ,IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2);
                            
                            
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-29
  --处理ERP接口错误自动修复   --关联订单
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_REQ_RECEIVE(
                            IN_SPACE_TIME IN NUMBER
                            ,IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2);
                            
  
    --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-29
  --处理ERP接口错误自动修复   --财务发票
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_REQ_INVOICE(
                            IN_SPACE_TIME IN NUMBER
                            ,IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2);                          
                            
    --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-29
  --处理ERP接口错误自动修复   --财务收款
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_REQ_RECEIPT(
                            IN_SPACE_TIME IN NUMBER
                            ,IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2); --返回值       
                            
   
  
      
    --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-29
  --处理ERP接口错误自动修复   --RMA 
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_OE_RMA(
                            IN_SPACE_TIME IN NUMBER
                            ,IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2); --返回值        
                           
                            
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2019-07-29
  --处理ERP接口错误自动修复   --库存事物
  --------------------------------------------------------------------------
  Procedure P_AUTO_REPAIR_INV_TRANSACTION(
                            IN_SPACE_TIME IN NUMBER
                            ,IN_RE_SEND IN VARCHAR2
                            ,OS_MESSAGE OUT VARCHAR2) ;                    
                                                                                      

END PKG_SO_IO_ERP;
/

