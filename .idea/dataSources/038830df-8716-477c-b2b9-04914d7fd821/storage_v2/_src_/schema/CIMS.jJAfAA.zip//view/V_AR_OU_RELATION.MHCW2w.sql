create view V_AR_OU_RELATION as
SELECT aor.entity_id entity_id,                                    --主体ID
                                  entity.entity_name entity_name,   --主体名称
          aor.sales_center_code sales_center_code,                  --中心编码
          center.sales_center_name sales_center_name,               --中心名称
                                                     aor.erp_ou_id erp_ou_id,

          --OU ID
          aor.erp_ou_name erp_ou_name,                                --OU名称
                                      aor.is_default          --是否主体默认OU
     FROM t_ar_ou_relation aor, v_bd_entity entity, v_bd_sales_center center
    WHERE aor.entity_id = entity.entity_id(+)
      AND aor.sales_center_code = center.sales_center_code(+)
      AND (SYSDATE BETWEEN aor.effective_tiame AND aor.failure_time)
/

comment on column V_AR_OU_RELATION.ENTITY_ID is '主体ID'
/

comment on column V_AR_OU_RELATION.ENTITY_NAME is '主体名称'
/

comment on column V_AR_OU_RELATION.SALES_CENTER_CODE is '中心编码'
/

comment on column V_AR_OU_RELATION.SALES_CENTER_NAME is '中心名称'
/

comment on column V_AR_OU_RELATION.ERP_OU_ID is 'OU ID'
/

comment on column V_AR_OU_RELATION.ERP_OU_NAME is 'OU名称'
/

comment on column V_AR_OU_RELATION.IS_DEFAULT is '是否主体默认OU'
/

