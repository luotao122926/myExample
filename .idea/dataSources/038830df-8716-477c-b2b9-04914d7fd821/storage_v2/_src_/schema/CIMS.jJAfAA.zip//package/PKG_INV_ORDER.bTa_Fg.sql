create PACKAGE      PKG_INV_ORDER  AS

  -----------------------------------------------------------------------------
  --处理中转单订单入库完成主过程
  -----------------------------------------------------------------------------
  PROCEDURE P_INV_ORDER_MAIN
  (
    P_PO_HEADER_ID       IN T_INV_PO_HEADERS.PO_ID%TYPE,--中转单头ID
    P_RESULT         IN OUT NUMBER, --返回错误ID
    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
  );

  -----------------------------------------------------------------------------
  --更新提货订单行入库完成时间
  -----------------------------------------------------------------------------
  PROCEDURE P_UPDATE_LG_ORDER_LINE
  (
    P_ORDER_LINE_ID IN T_PLN_LG_ORDER_LINE.ORDER_LINE_ID%TYPE,--提货订单行ID
    P_COMPLETE_DATE IN DATE, --入库完成时间
    P_RESULT         IN OUT NUMBER, --返回错误ID
    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
  );

END PKG_INV_ORDER;
/

