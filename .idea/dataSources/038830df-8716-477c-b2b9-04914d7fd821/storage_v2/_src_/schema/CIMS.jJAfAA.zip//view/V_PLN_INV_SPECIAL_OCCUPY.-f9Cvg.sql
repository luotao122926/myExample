create view V_PLN_INV_SPECIAL_OCCUPY as
Select Iso.Item_Id,
       Tbi.Item_Code,
       Tbi.Item_Name,
       Tbi.Defaultunit,
       Iso.Inventory_Id,
       Ii.Inventory_Code,
       Ii.Inventory_Name,
       Poh.Sales_Center_Id,
       Poh.Sales_Center_Code,
       Poh.Sales_Center_Name,
       pol.producing_area_name,
       Iso.Special_Occupy_Id,
       Iso.Entity_Id,
       Iso.Transaction_Date,
       Iso.Occupy_Qty,
       Iso.Release_Qty,
       Pkg_Inv_Pub.f_Get_Item_Inv_Qoh(p_Entity_Id    => Iso.Entity_Id,
                                      p_Inventory_Id => Iso.Inventory_Id,
                                      p_Item_Id      => Iso.Item_Id,
                                      p_User_Code    => Iso.Created_By,
                                      p_Get_Qoh_Type => 2) Item_Qoh_Qty,
       Iso.Compelete_Flag,
       Iso.Origin_Order_Type_Id,
       Iso.Origin_Order_Type_Name,
       Iso.Origin_Head_Id,
       Iso.Origin_Order_Number,
       Iso.Origin_Line_Id,
       Iso.Special_Type,
       Iso.Created_By,
       Iso.Creation_Date,
       Iso.Last_Updated_By,
       Iso.Last_Update_Date
  From t_Pln_Inv_Special_Occupy Iso,
       t_Bd_Item                Tbi,
       t_Inv_Inventories        Ii,
       t_Pln_Order_Head         Poh,
       t_pln_order_line         pol
 Where Tbi.Item_Id = Iso.Item_Id
   And Ii.Inventory_Id = Iso.Inventory_Id
   And Poh.Order_Head_Id = Iso.Origin_Head_Id
   AND pol.order_line_id = iso.origin_line_id
/

