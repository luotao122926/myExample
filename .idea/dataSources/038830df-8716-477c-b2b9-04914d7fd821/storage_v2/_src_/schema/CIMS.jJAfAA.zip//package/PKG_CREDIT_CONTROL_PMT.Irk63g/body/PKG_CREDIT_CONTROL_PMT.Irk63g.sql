create package body PKG_CREDIT_CONTROL_PMT is

  V_NL             CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
  V_SEC_RESULT     CONSTANT NUMBER := 0; --成功返回
  V_SUCCESS        CONSTANT VARCHAR2(10) := 'SUCCESS';

  PROCEDURE 以下推广物料信用控制 is begin null ; end ;

   -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-06-29
  *     创建者：龙鸿文
  *   功能说明：资源提货资金校验接口【新增】
  *   参数说明：P_ACTION_TYPE 动作标识

                按产品提货
                1-27 跟成品的资金校验一样
  *             按资源提货
                30：资源返利单
                31：资源返利红冲单
                32：资源提货订单
                33：资源提货订单取消
                34：资源发放单
                领用
                40：领用
  */
  -------------------------------------------------------------------------------

  PROCEDURE PRC_CREDIT_CONTROL_PMT( P_ENTITY_ID           IN NUMBER,--主ID体
                                    P_ACTION_TYPE         IN VARCHAR2, --动作标示
                                    P_Settlement_SUM      IN NUMBER, --结算金额
                                    P_Discount_SUM        IN NUMBER, --折扣金额
                                    P_SALES_MAIN_TYPE     IN VARCHAR2, --营销大类
                                    P_ORDER_ID            IN NUMBER, --单据ID
                                    P_ACCOUNT_ID          IN NUMBER, --账户ID
                                    P_CUSTOMER_ID         IN NUMBER, --客户ID
                                    P_PROJ_NUMBER         IN VARCHAR2, --项目号
                                    P_CREATED_MODE         IN NUMBER,   --开单方式
                                    P_ORDER_TYPE          IN VARCHAR2, --单据类型
                                    P_USERNAME            IN VARCHAR2 ,
                                    P_RESULT              IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG             IN OUT VARCHAR2 --返回错误信息
                                    ) IS
  BEGIN
    IF P_ACTION_TYPE > 0 AND P_ACTION_TYPE < 30 THEN
      PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_ORDER_BILL(P_ENTITY_ID => P_ENTITY_ID,
      P_ACTION_TYPE =>  P_ACTION_TYPE,
      P_Settlement_SUM => P_Settlement_SUM,
      P_Discount_SUM => P_Discount_SUM,
      P_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE,
      P_ACCOUNT_ID => P_ACCOUNT_ID,
      P_CUSTOMER_ID => P_CUSTOMER_ID,
      P_PROJ_NUMBER => P_PROJ_NUMBER,
      P_ORDER_ID => P_ORDER_ID,
      P_ORDER_TYPE => P_ORDER_TYPE,
      P_USERNAME => P_USERNAME,P_RESULT => P_RESULT,P_ERR_MSG => P_ERR_MSG);
      RETURN;
    END IF;

    --校验传入参数是否正确
    IF P_ENTITY_ID IS NULL THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '主体不能为空，请检查传入参数值！';
       RETURN ;
    ELSIF P_ACTION_TYPE IS NULL THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '动作标示不能为空，请检查传入参数值！';
       RETURN ;
    ELSIF P_Settlement_SUM IS NULL THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '结算金额不能为空，请检查传入参数值！';
       RETURN ;
    ELSIF P_SALES_MAIN_TYPE IS NULL AND P_PROJ_NUMBER IS NULL THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '传入营销大类和项目号有误，必须有一个不为空！';
       RETURN ;
    ELSIF P_ACCOUNT_ID IS NULL THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '账号ID不能为空，请检查传入参数值！';
       RETURN ;
    ELSIF P_CUSTOMER_ID IS NULL THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '客户ID不能为空，请检查传入参数值！';
       RETURN ;
    ELSIF P_ORDER_ID IS NULL THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '单据ID不能为空，请检查传入参数值！';
       RETURN ;
    ELSIF P_ORDER_TYPE IS NULL THEN
       P_RESULT  := -20000;
       P_ERR_MSG := '单据类型不能为空，请检查传入参数值！';
       RETURN ;
    END IF;

    --增加信用控制的总保存点2015-07-18. 龙鸿文
    SAVEPOINT SAVEPOINT_CREDIT ;
    BEGIN
      PRC_CREDIT_VERIFICATION(P_ENTITY_ID          => P_ENTITY_ID, --主体ID
                              P_ACTION_TYPE        => P_ACTION_TYPE, --动作标示
                              P_Settlement_SUM     => P_Settlement_SUM, --结算金额
                              P_Discount_SUM       => P_Discount_SUM, --折扣金额
                              P_ORDER_ID           => P_ORDER_ID, --单据ID
                              P_SALES_MAIN_TYPE    => P_SALES_MAIN_TYPE , --营销大类
                              P_ACCOUNT_ID         => P_ACCOUNT_ID, --账户ID
                              P_CUSTOMER_ID        => P_CUSTOMER_ID, --客户ID
                              P_PROJ_NUMBER        => P_PROJ_NUMBER , --项目号
                              P_RESULT             => P_RESULT, --返回错误ID
                              P_ERR_MSG            => P_ERR_MSG, --返回错误信息
                              P_ORDER_TYPE         => P_ORDER_TYPE
                              ) ;
        IF P_RESULT <> V_SEC_RESULT THEN
           ROLLBACK TO SAVEPOINT_CREDIT ;
           GOTO HERE ;
        END IF ;
     EXCEPTION WHEN OTHERS THEN
        P_RESULT  := -20000;
        P_ERR_MSG := '调用资金校验模块出现异常，请了解！'|| V_NL || SQLERRM ;
        ROLLBACK TO SAVEPOINT_CREDIT ;
        RETURN ;
     END ;

     --如果检验通过，则调用款项变更
     IF P_RESULT = V_SEC_RESULT THEN
        IF P_ACTION_TYPE > 0 AND P_ACTION_TYPE < 30 THEN
           BEGIN
                PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_FUND_UPDATE( P_ENTITY_ID       => P_ENTITY_ID, --主体ID
                                                                   P_ACTION_TYPE     => P_ACTION_TYPE, --动作标示
                                                                   P_Settlement_SUM  => P_Settlement_SUM, --结算金额
                                                                   P_Discount_SUM    => P_Discount_SUM, --折扣金额
                                                                   P_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE, --营销大类
                                                                   P_ACCOUNT_ID      => P_ACCOUNT_ID, --账户ID
                                                                   P_CUSTOMER_ID     => P_CUSTOMER_ID, --客户ID
                                                                   P_PROJ_NUMBER     => P_PROJ_NUMBER, --项目号
                                                                   P_ORDER_ID        => P_ORDER_ID, --单据ID
                                                                   P_ORDER_TYPE      => P_ORDER_TYPE, --单据类型
                                                                   P_CREATED_MODE    => P_CREATED_MODE ,  --开单方式：1-自动，2-人工（销售开单，如果为人工开单，则校验时不解锁金额）
                                                                   P_USERNAME        => P_USERNAME ,
                                                                   P_RESULT          => P_RESULT, --返回错误ID
                                                                   P_ERR_MSG         => P_ERR_MSG --返回错误信息
                                                                   );
               IF P_RESULT <> V_SEC_RESULT THEN
                 ROLLBACK TO SAVEPOINT_CREDIT ;
                 GOTO HERE ;
                END IF ;
             EXCEPTION WHEN OTHERS THEN
                P_RESULT  := -20000;
                P_ERR_MSG := '调用款项变更模块出现异常，请了解！'|| V_NL || SQLERRM ;
                ROLLBACK TO SAVEPOINT_CREDIT ;
                RETURN ;
             END ;
        ELSIF P_ACTION_TYPE IN (30,31,32,33,34) THEN
              BEGIN
              PRC_CREDIT_FUND_UPDATE(P_ENTITY_ID       => P_ENTITY_ID, --主体ID
                                     P_ACTION_TYPE     => P_ACTION_TYPE, --动作标示
                                     P_Settlement_SUM  => P_Settlement_SUM, --结算金额
                                     P_Discount_SUM    => P_Discount_SUM, --折扣金额
                                     P_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE, --营销大类
                                     P_ACCOUNT_ID      => P_ACCOUNT_ID, --账户ID
                                     P_CUSTOMER_ID     => P_CUSTOMER_ID, --客户ID
                                     P_PROJ_NUMBER     => P_PROJ_NUMBER, --项目号
                                     P_ORDER_ID        => P_ORDER_ID, --单据ID
                                     P_ORDER_TYPE      => P_ORDER_TYPE, --单据类型
                                     P_USERNAME        => P_USERNAME ,
                                     P_RESULT          => P_RESULT, --返回错误ID
                                     P_ERR_MSG         => P_ERR_MSG --返回错误信息
                                     );
               IF P_RESULT <> V_SEC_RESULT THEN
                 ROLLBACK TO SAVEPOINT_CREDIT ;
                 GOTO HERE ;
               END IF ;
            EXCEPTION WHEN OTHERS THEN
               P_RESULT  := -20000;
               P_ERR_MSG := '调用款项变更模块出现异常，请了解！'|| V_NL || SQLERRM ;
               ROLLBACK TO SAVEPOINT_CREDIT ;
               RETURN ;
            END ;
        ELSIF P_ACTION_TYPE = '40' THEN
              RETURN;
        END IF;
     END IF ;
     <<HERE>>
     NULL ;
  END PRC_CREDIT_CONTROL_PMT;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-07-16
  *     创建者：龙鸿文
  *   功能说明：推广物料信用资源资金校验
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE 资源资金校验 is begin null ; end ;


  PROCEDURE PRC_CREDIT_VERIFICATION(P_ENTITY_ID            IN NUMBER, --主体ID
                                    P_ACTION_TYPE          IN NUMBER, --动作标示
                                    P_Settlement_SUM       IN NUMBER, --结算金额
                                    P_Discount_SUM         IN NUMBER, --折扣金额
                                    P_ORDER_ID             IN NUMBER, --单据ID
                                    P_SALES_MAIN_TYPE      IN VARCHAR2, --营销大类
                                    P_ACCOUNT_ID           IN NUMBER, --账户ID
                                    P_CUSTOMER_ID          IN NUMBER, --客户ID
                                    P_PROJ_NUMBER          IN VARCHAR2, --项目号
                                    P_RESULT               IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG              IN OUT VARCHAR2, --返回错误信息
                                    P_ORDER_TYPE        IN VARCHAR2 DEFAULT NULL
                                    ) IS

  V_CREDIT_GROUP_ID T_SALES_ACCOUNT_AMOUNT.Credit_Group_Id%TYPE ; --额度组
  V_ENTITY_ID T_SALES_ACCOUNT_AMOUNT.Entity_Id%TYPE ;
  V_CONTROL_GRADE VARCHAR2(2) ; --控制级别
  V_CREDIT_GROUP_C NUMBER; --判断当前大类是否跟推广物料同一额度组
  C_SALES_ACCOUNT_AMOUNT CUR_SALES_ACCOUNT_AMOUNT ;
  C_SALES_ACCOUNT_MX_AMOUNT CUR_SALES_ACCOUNT_MX_AMOUNT ;
  V_AMOUNT_CRTL_FLAG T_SALES_ACCOUNT_AMOUNT.AMOUNT_CRTL_FLAG%TYPE ; --金额控制
  V_DISCONT_CRTL_FLAG T_SALES_ACCOUNT_AMOUNT.DISCONT_CRTL_FLAG%TYPE ; --折扣控制

  BEGIN

    --初始值
    P_RESULT  := V_SEC_RESULT;
    P_ERR_MSG := V_SUCCESS ;
    V_CREDIT_GROUP_C := 0;

    ----0、判断是否存在此种单据类型
    IF P_ACTION_TYPE < 1 OR P_ACTION_TYPE > 40 OR MOD(P_ACTION_TYPE,1) <> 0 THEN
       P_RESULT  := -20005;
       P_ERR_MSG := '传入动作标识有问题，请确认是否有此种单据类型！';
       RETURN ;
    END IF ;

    V_ENTITY_ID := P_ENTITY_ID ;
    --2、根据系统参数获取款项控制级别（基础数据提供接口）
    V_CONTROL_GRADE := '2' ;

    --3、根据营销大类ID，客户ID，获取额度组--2017-4-22 获取额度组增加账户ID liangym2
    V_CREDIT_GROUP_ID := pkg_credit_tools.FUN_GET_CREDITGROUPID(P_ENTITY_ID,P_CUSTOMER_ID,P_SALES_MAIN_TYPE,P_ACCOUNT_ID);
    IF V_CREDIT_GROUP_ID = -2 THEN
      P_RESULT := -20002;
      P_ERR_MSG := '该客户已经存在特殊额度组，请到额度组维护模块维护特殊额度组与'|| P_SALES_MAIN_TYPE ||'的关系！' || V_NL || SQLERRM;
      RETURN ;
    ELSIF V_CREDIT_GROUP_ID = -1 THEN
      P_RESULT := -20002;
      P_ERR_MSG := '根据营销大类查询额度组出错，请到额度组管理模块维护！' || V_NL || SQLERRM;
      RETURN ;
    END IF ;

    --判断大类所在的额度组ID是否跟推广物料所在的额度组ID一样。
    /*SELECT COUNT(*) INTO V_CREDIT_GROUP_C
        FROM T_CREDIT_CATEGORY_GROUP_REL D
        WHERE D.SALES_MAIN_TYPE = 'TGWL'
          AND D.CREDIT_GROUP_ID =
             (SELECT nvl(R.CREDIT_GROUP_ID, -1) CREDIT_GROUP_ID
                FROM T_CREDIT_CATEGORY_GROUP_REL R
               WHERE R.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE);*/
      SELECT COUNT(*)
       INTO V_CREDIT_GROUP_C
       FROM T_CREDIT_CATEGORY_GROUP_REL D, T_CREDIT_GROUP G
      WHERE D.SALES_MAIN_TYPE = 'TGWL'
        AND D.CREDIT_GROUP_ID = G.CREDIT_GROUP_ID
        AND G.ENTITY_ID = P_ENTITY_ID
        AND D.CREDIT_GROUP_ID =--2017-4-22 获取额度组增加账户ID liangym2
            PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(P_ENTITY_ID       => P_ENTITY_ID,
                                                   P_CUSTOMER_ID     => P_CUSTOMER_ID,
                                                   P_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE,
                                                   IN_ACCOUNT_ID     => P_ACCOUNT_ID);


     IF V_CREDIT_GROUP_C < 0 THEN
        P_RESULT  := -20000;
        P_ERR_MSG := '提货中，该客户的大类必须与推广物料大类同一额度组'|| V_NL || SQLERRM ;
        RETURN ;
     END IF;

     IF V_CONTROL_GRADE = '1' THEN --客户级别
        NULL;
     ELSIF V_CONTROL_GRADE = '2' THEN --账号级别
        --增加信用控制的总保存点
        SAVEPOINT SAVEPOINT_CREDIT ;
        IF P_ACTION_TYPE > 0 AND P_ACTION_TYPE < 30 THEN
            BEGIN
                PKG_CREDIT_ACCOUNT_CONTROL.PRC_CREDIT_VERIFICATION( P_ENTITY_ID        => P_ENTITY_ID, --主体ID
                                                                    P_ACTION_TYPE      => P_ACTION_TYPE, --动作标示
                                                                    P_Settlement_SUM   => P_Settlement_SUM, --结算金额
                                                                    P_Discount_SUM     => P_Discount_SUM, --折扣金额
                                                                    P_ORDER_ID         => P_ORDER_ID, --单据ID
                                                                    P_SALES_MAIN_TYPE  => P_SALES_MAIN_TYPE , --营销大类
                                                                    P_ACCOUNT_ID       => P_ACCOUNT_ID, --账户ID
                                                                    P_CUSTOMER_ID      => P_CUSTOMER_ID, --客户ID
                                                                    P_PROJ_NUMBER      => P_PROJ_NUMBER , --项目号
                                                                    P_CREATED_MODE     =>  NULL ,
                                                                    P_RESULT           =>  P_RESULT, --返回错误ID
                                                                    P_ERR_MSG          =>  P_ERR_MSG, --返回错误信息
                                                                    P_ORDER_TYPE       => P_ORDER_TYPE
                                                                    ) ;
                  IF P_RESULT <> V_SEC_RESULT THEN
                     ROLLBACK TO SAVEPOINT_CREDIT ;
                     GOTO HERE ;
                  END IF ;
              EXCEPTION WHEN OTHERS THEN
                  P_RESULT  := -20000;
                  P_ERR_MSG := '调用资金校验模块出现异常，请了解！'|| V_NL || SQLERRM ;
                  ROLLBACK TO SAVEPOINT_CREDIT ;
                  RETURN ;
              END ;

        ELSIF P_ACTION_TYPE IN (30,31,32,33,34) THEN
              /*
              IF P_SALES_MAIN_TYPE <> 'TGWL' THEN
                  P_RESULT  := -20000;
                  P_ERR_MSG := '按资源提货中，推广物料大类类型不正确，请检查！'|| V_NL || SQLERRM ;
                  RETURN ;
              END IF;
              */
              BEGIN
                 --锁定款项明细信息
                 SELECT * BULK COLLECT INTO C_SALES_ACCOUNT_MX_AMOUNT
                    FROM T_SALES_ACCOUNT_MX_AMOUNT T
                   WHERE T.ENTITY_ID = V_ENTITY_ID
                     AND T.CUSTOMER_ID = P_CUSTOMER_ID
                     AND T.ACCOUNT_ID = P_ACCOUNT_ID
                     AND nvl(T.PROJ_NUMBER,-1) = nvl(P_PROJ_NUMBER,-1)
                     AND T.SALES_MAIN_TYPE = P_SALES_MAIN_TYPE
                     FOR UPDATE NOWAIT;

                 --缺少客户款项明细信息，初始化该客户该账户下的营销大类款项明细信息
                 IF C_SALES_ACCOUNT_MX_AMOUNT.COUNT < 1 THEN
                     PKG_CREDIT_ACCOUNT_CONTROL.prc_credit_amount_contorl_init( p_entity_id => p_entity_id,
                                                                                p_customer_id => p_customer_id,
                                                                                p_account_id => p_account_id,
                                                                                p_proj_number => p_proj_number,
                                                                                p_sales_main_type => p_sales_main_type,
                                                                                p_username => '初始化',
                                                                                p_result => p_result,
                                                                                p_err_msg => p_err_msg);
                     IF P_RESULT <> V_SEC_RESULT THEN
                        RETURN ;
                     END IF ;
                 END IF ;

                 --锁定款项信息
                 SELECT * BULK COLLECT INTO C_SALES_ACCOUNT_AMOUNT
                     FROM T_SALES_ACCOUNT_AMOUNT T
                     WHERE T.ENTITY_ID = V_ENTITY_ID
                     AND nvl(T.CREDIT_GROUP_ID,-1) = V_CREDIT_GROUP_ID
                     AND nvl(T.PROJ_NUMBER,-1) = nvl(P_PROJ_NUMBER,-1)
                     AND T.CUSTOMER_ID = P_CUSTOMER_ID
                     AND T.ACCOUNT_ID = P_ACCOUNT_ID
                     FOR UPDATE NOWAIT;

                  IF C_SALES_ACCOUNT_AMOUNT.COUNT < 1 THEN
                     P_RESULT  := -20004;
                     P_ERR_MSG := '系统中不存在该客户在该账户下，营销大类为'|| P_SALES_MAIN_TYPE ||'的客户款项信息！' || V_NL || SQLERRM;
                     RETURN ;
                  END IF ;
                  --获取控制方式
                  V_AMOUNT_CRTL_FLAG :=  NVL(C_SALES_ACCOUNT_AMOUNT(1).AMOUNT_CRTL_FLAG,'-1') ;
                  V_DISCONT_CRTL_FLAG := NVL(C_SALES_ACCOUNT_AMOUNT(1).DISCONT_CRTL_FLAG,'-1') ;
                EXCEPTION WHEN OTHERS THEN
                  P_RESULT  := -20003;
                  P_ERR_MSG := '锁定款项信息出错，可能该款项信息被其他用户操作，请稍后再试！' || V_NL || SQLERRM;
                  --ROLLBACK ;
                  RETURN ;
                END ;

                PRC_CREDIT_VERIFICATION_IMPL(P_ACTION_TYPE , --动作标示
                                              NVL(P_Settlement_SUM,0) , --结算金额
                                              NVL(P_Discount_SUM,0) , --折扣金额
                                              P_ORDER_ID,      --单据ID
                                              C_SALES_ACCOUNT_AMOUNT ,
                                              V_AMOUNT_CRTL_FLAG, --金额控制方式
                                              V_DISCONT_CRTL_FLAG , --折扣控制方式
                                              P_RESULT , --返回错误ID
                                              P_ERR_MSG,  --返回错误信息
                                              P_ORDER_TYPE
                                              )  ;
                 IF P_RESULT <> V_SEC_RESULT THEN
                    ROLLBACK TO SAVEPOINT_CREDIT ;
                    GOTO HERE ;
                 END IF ;
        ELSIF P_ACTION_TYPE = '40' THEN
              P_RESULT  := V_SEC_RESULT ;
              P_ERR_MSG := V_SUCCESS ;
              RETURN ;
        ELSE
              P_RESULT  := -20005;
              P_ERR_MSG := '传入动作标识有问题，请确认是否有此种单据类型！';
              RETURN;
        END IF;
        <<HERE>>
        NULL ;
     END IF;


  END PRC_CREDIT_VERIFICATION;

  PROCEDURE PRC_CREDIT_VERIFICATION_IMPL( P_ACTION_TYPE          IN NUMBER, --动作标示
                                          P_Settlement_SUM       IN NUMBER, --结算金额
                                          P_Discount_SUM         IN NUMBER, --折扣金额
                                          P_ORDER_ID             IN NUMBER, --单据ID
                                          P_SALES_ACCOUNT_AMOUNT CUR_SALES_ACCOUNT_AMOUNT ,
                                          P_AMOUNT_CRTL_FLAG     IN VARCHAR2, --金额控制方式
                                          P_DISCONT_CRTL_FLAG    IN VARCHAR2, --折扣控制方式
                                          P_RESULT            IN OUT NUMBER, --返回错误ID
                                          P_ERR_MSG           IN OUT VARCHAR2, --返回错误信息
                                          P_ORDER_TYPE        IN VARCHAR2 DEFAULT NULL
                                          ) IS

  V_SETTLEMENT_AMOUNT NUMBER := 0 ;   --控制结算金额
  V_AMOUNT_FLAG       VARCHAR2(2) ; --金额校验通过标识（0：通过，-1：不通过）
  V_RESOURCE_AMOUNT T_SALES_ACCOUNT_AMOUNT.Resource_Amount%TYPE := 0 ; --资源资金
  V_LOCK_RESOURCE_AMOUNT T_SALES_ACCOUNT_AMOUNT.Lock_Resource_Amount%TYPE := 0  ;--锁定资源资金
  V_TRANSACTION_AMOUNT T_SALES_ACCOUNT_AMOUNT.Transaction_Amount%TYPE := 0 ;  --资源核销资金

  BEGIN

       FOR I IN 1.. P_SALES_ACCOUNT_AMOUNT.COUNT LOOP

           --资源金额
           V_RESOURCE_AMOUNT := V_RESOURCE_AMOUNT + P_SALES_ACCOUNT_AMOUNT(I).RESOURCE_AMOUNT;
           --锁定资源金额
           V_LOCK_RESOURCE_AMOUNT := V_LOCK_RESOURCE_AMOUNT + P_SALES_ACCOUNT_AMOUNT(I).LOCK_RESOURCE_AMOUNT;
           --资源核销金额
           V_TRANSACTION_AMOUNT := V_TRANSACTION_AMOUNT + P_SALES_ACCOUNT_AMOUNT(I).TRANSACTION_AMOUNT;

       END LOOP;

       IF P_ACTION_TYPE = 30 THEN
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           RETURN ;
       ELSIF P_ACTION_TYPE = 31 THEN
           IF P_AMOUNT_CRTL_FLAG = '0' THEN --金额控制
              V_SETTLEMENT_AMOUNT := V_RESOURCE_AMOUNT - V_TRANSACTION_AMOUNT;
              IF V_SETTLEMENT_AMOUNT < P_Settlement_SUM THEN
                 V_AMOUNT_FLAG := '1' ;
              ELSE
                  V_AMOUNT_FLAG := '0' ;
              END IF;
           ELSIF P_AMOUNT_CRTL_FLAG = '1' THEN --金额控制标识为-1，不用校验直接通过
                 V_AMOUNT_FLAG := '0' ;
           END IF;

           --判断最终的校验结果：金额控制=0 通过，其他都不通过
           IF V_AMOUNT_FLAG = '0' THEN
               P_RESULT  := V_SEC_RESULT ;
               P_ERR_MSG := V_SUCCESS ;
              RETURN ;
           ELSE
               P_RESULT  := -20000 ;
               P_ERR_MSG := '资源返利红冲单校验不通过！'
                     || V_NL || (CASE WHEN P_Settlement_SUM > V_SETTLEMENT_AMOUNT THEN '【原因：结算金额('|| P_Settlement_SUM ||')超过预算】' END);
           END IF ;

       ELSIF P_ACTION_TYPE = 32 THEN
             IF P_AMOUNT_CRTL_FLAG = '0' THEN --金额控制
                V_SETTLEMENT_AMOUNT := V_RESOURCE_AMOUNT - V_TRANSACTION_AMOUNT - V_LOCK_RESOURCE_AMOUNT;
                IF V_SETTLEMENT_AMOUNT < P_Settlement_SUM THEN
                   V_AMOUNT_FLAG := '1' ;
                 ELSE
                   V_AMOUNT_FLAG := '0' ;
                 END IF;
             ELSIF P_AMOUNT_CRTL_FLAG = '1' THEN
                   V_AMOUNT_FLAG := '0' ;
             END IF;

             --判断最终的校验结果：金额控制=0 通过，其他都不通过
             IF V_AMOUNT_FLAG = '0' THEN
                 P_RESULT  := V_SEC_RESULT ;
                 P_ERR_MSG := V_SUCCESS ;
                RETURN ;
             ELSE
                 P_RESULT  := -20000 ;
                 P_ERR_MSG := '资源提货订单校验不通过！'
                        || V_NL || (CASE WHEN P_Settlement_SUM > V_SETTLEMENT_AMOUNT THEN '【原因：结算金额('|| P_Settlement_SUM ||')超过预算】' END);
             END IF ;

       ELSIF P_ACTION_TYPE = 33 OR P_ACTION_TYPE = 34 THEN
             IF P_AMOUNT_CRTL_FLAG = '0' THEN --金额控制
                V_SETTLEMENT_AMOUNT := V_LOCK_RESOURCE_AMOUNT;
                IF V_SETTLEMENT_AMOUNT < P_Settlement_SUM THEN
                   V_AMOUNT_FLAG := '1' ;
                ELSE
                     V_AMOUNT_FLAG := '0' ;
                END IF;
             ELSIF P_AMOUNT_CRTL_FLAG = '1' THEN
                   V_AMOUNT_FLAG := '0' ;
             END IF;

           --判断最终的校验结果：金额控制=0 通过，其他都不通过
             IF V_AMOUNT_FLAG = '0' THEN
                 P_RESULT  := V_SEC_RESULT ;
                 P_ERR_MSG := V_SUCCESS ;
                 RETURN ;
             ELSE
                 P_RESULT  := -20000 ;
                 P_ERR_MSG := '资源提货订单取消或资源发放单校验不通过！'
                      || V_NL || (CASE WHEN P_Settlement_SUM > V_SETTLEMENT_AMOUNT THEN '【原因：结算金额('|| P_Settlement_SUM ||')超过预算】' END);
             END IF ;


       ELSIF P_ACTION_TYPE = 40 THEN
           P_RESULT  := V_SEC_RESULT ;
           P_ERR_MSG := V_SUCCESS ;
           RETURN ;
       END IF;

  END PRC_CREDIT_VERIFICATION_IMPL ;

    -------------------------------------------------------------------------------
  /*
  *   创建日期：2015-07-16
  *     创建者：龙鸿文
  *   功能说明：推广物料信用资源款项更新
  *
  */
  -------------------------------------------------------------------------------
  PROCEDURE 资源款项更新 is begin null ; end ;

  PROCEDURE PRC_CREDIT_FUND_UPDATE(P_ENTITY_ID     IN NUMBER, --主体ID
                                   P_ACTION_TYPE     IN NUMBER, --动作标示
                                   P_Settlement_SUM  IN NUMBER, --结算金额
                                   P_Discount_SUM    IN NUMBER, --折扣金额
                                   P_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                   P_ACCOUNT_ID      IN NUMBER, --账户ID
                                   P_CUSTOMER_ID     IN NUMBER, --客户ID
                                   P_PROJ_NUMBER     IN VARCHAR2, --项目号
                                   P_ORDER_ID   IN NUMBER, --单据ID
                                   P_ORDER_TYPE IN VARCHAR2, --单据类型
                                   P_USERNAME   IN VARCHAR2,
                                   P_RESULT     IN OUT NUMBER, --返回错误ID
                                   P_ERR_MSG    IN OUT VARCHAR2 --返回错误信息
                                   ) IS

  V_UPDATE_TABLE VARCHAR2(4000) ;
  V_UPDATE_COLS  VARCHAR2(4000) ;
  V_UPDATE_WHERE VARCHAR2(4000) ;
  V_UPDATE_TABLE_MX VARCHAR2(4000) ;
  --V_UPDATE_COLS_MX  VARCHAR2(100) ;
  V_UPDATE_WHERE_MX VARCHAR2(4000) ;
  V_CREDIT_GROUP_ID T_CREDIT_GROUP_CUST.Credit_Group_Id%TYPE ;
  V_SQL     VARCHAR2(4000) ;
  V_SQL_MX  VARCHAR2(4000) ;
  V_ORDER_TYPE VARCHAR2(400) ;
  TYPE TRANS_TYPE IS RECORD(R_TRANS_ACTION t_sales_amount_trans.Trans_Action%TYPE,
                            R_AMOUNT_NAME  t_sales_amount_trans.Amount_Name%TYPE,
                            R_AMOUNT       t_sales_amount_trans.Amount%TYPE) ;
  TYPE CUR_TRANS_TYPE IS TABLE OF TRANS_TYPE INDEX BY BINARY_INTEGER;
  TRANS_TABLE CUR_TRANS_TYPE ;

  BEGIN
      P_RESULT  := V_SEC_RESULT;
      P_ERR_MSG := V_SUCCESS;

      V_ORDER_TYPE := P_ORDER_TYPE ;

      --3、根据营销大类ID，客户ID，获取额度组--2017-4-22 获取额度组增加账户ID liangym2
      V_CREDIT_GROUP_ID := pkg_credit_tools.FUN_GET_CREDITGROUPID(P_ENTITY_ID,P_CUSTOMER_ID,P_SALES_MAIN_TYPE,P_ACCOUNT_ID);
      IF V_CREDIT_GROUP_ID = -2 THEN
        P_RESULT := -20002;
        P_ERR_MSG := '该客户已经存在特殊额度组，请到额度组维护模块维护特殊额度组与'|| P_SALES_MAIN_TYPE ||'的关系！' || V_NL || SQLERRM;
        RETURN ;
      ELSIF V_CREDIT_GROUP_ID = -1 THEN
        P_RESULT := -20002;
        P_ERR_MSG := '根据营销大类查询额度组出错，请到额度组管理模块维护！' || V_NL || SQLERRM;
        RETURN ;
      END IF ;

      --更新款项
      V_UPDATE_TABLE := 'UPDATE T_SALES_ACCOUNT_AMOUNT T SET ' ;
      V_UPDATE_COLS  := '' ;
      V_UPDATE_WHERE := ' WHERE T.ENTITY_ID = ' || P_ENTITY_ID
                          ||' AND T.CUSTOMER_ID = '|| P_CUSTOMER_ID
                          ||' AND T.ACCOUNT_ID = '|| P_ACCOUNT_ID
                          ||' AND nvl(T.CREDIT_GROUP_ID,-1) = '|| nvl(V_CREDIT_GROUP_ID,-1)
                          ||' AND nvl(T.PROJ_NUMBER,-1) = '||nvl(P_PROJ_NUMBER,-1) ;
      --更新款项明细
      V_UPDATE_TABLE_MX := 'UPDATE T_SALES_ACCOUNT_MX_AMOUNT T SET ' ;
      V_UPDATE_WHERE_MX := ' WHERE T.ENTITY_ID = '||P_ENTITY_ID
                             ||' AND T.CUSTOMER_ID = '||P_CUSTOMER_ID
                             ||' AND T.ACCOUNT_ID = '||P_ACCOUNT_ID
                             ||' AND T.SALES_MAIN_TYPE = '''||P_SALES_MAIN_TYPE
                             ||''' AND nvl(T.PROJ_NUMBER,-1) = '||nvl(P_PROJ_NUMBER,-1) ;
      --资源返利单（增加资源金额）
      IF P_ACTION_TYPE = 30 THEN
         V_UPDATE_COLS := 'T.RESOURCE_AMOUNT = T.RESOURCE_AMOUNT + ' || P_Settlement_SUM ||
                          ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                          ''',T.LAST_UPDATE_DATE = SYSDATE ';
         TRANS_TABLE(1).R_TRANS_ACTION := '1' ;
         TRANS_TABLE(1).R_AMOUNT_NAME  := '资源金额' ;
         TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;
      --资源返利红冲单（减少资源金额）
      ELSIF P_ACTION_TYPE = 31 THEN
            V_UPDATE_COLS := 'T.RESOURCE_AMOUNT = T.RESOURCE_AMOUNT - ' || P_Settlement_SUM ||
                             ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                             ''',T.LAST_UPDATE_DATE = SYSDATE ';
            TRANS_TABLE(1).R_TRANS_ACTION := '2' ;
            TRANS_TABLE(1).R_AMOUNT_NAME  := '资源金额' ;
            TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;
      --资源提货订单（增加锁定资源金额）
      ELSIF P_ACTION_TYPE = 32 THEN
            V_UPDATE_COLS := 'T.LOCK_RESOURCE_AMOUNT = T.LOCK_RESOURCE_AMOUNT + ' || P_Settlement_SUM ||
                             ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                             ''',T.LAST_UPDATE_DATE = SYSDATE ';
            TRANS_TABLE(1).R_TRANS_ACTION := '1' ;
            TRANS_TABLE(1).R_AMOUNT_NAME  := '锁定资源金额' ;
            TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;
      --资源提货订单取消(减少锁定资源金额)
      ELSIF P_ACTION_TYPE = 33 THEN
            V_UPDATE_COLS := 'T.LOCK_RESOURCE_AMOUNT = T.LOCK_RESOURCE_AMOUNT - ' || P_Settlement_SUM ||
                             ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                             ''',T.LAST_UPDATE_DATE = SYSDATE ';
            TRANS_TABLE(1).R_TRANS_ACTION := '2' ;
            TRANS_TABLE(1).R_AMOUNT_NAME  := '锁定资源金额' ;
            TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;
      --资源发放单（减少锁定资源金额，增加资源核销金额）
      ELSIF P_ACTION_TYPE = 34 THEN
            V_UPDATE_COLS := 'T.LOCK_RESOURCE_AMOUNT = T.LOCK_RESOURCE_AMOUNT - ' || P_Settlement_SUM ||
                             ',T.TRANSACTION_AMOUNT = T.TRANSACTION_AMOUNT + ' || P_Settlement_SUM ||
                             ',T.LAST_UPDATED_BY = ''' || P_USERNAME ||
                             ''',T.LAST_UPDATE_DATE = SYSDATE ';
            TRANS_TABLE(1).R_TRANS_ACTION := '2' ;
            TRANS_TABLE(1).R_AMOUNT_NAME  := '锁定资源金额' ;
            TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;

            TRANS_TABLE(1).R_TRANS_ACTION := '1' ;
            TRANS_TABLE(1).R_AMOUNT_NAME  := '资源核销金额' ;
            TRANS_TABLE(1).R_AMOUNT       := P_Settlement_SUM ;
      ELSIF P_ACTION_TYPE = 40 THEN
            RETURN;
      END IF;

      V_UPDATE_COLS := V_UPDATE_COLS || ',T.PRE_FIELD_01 = ''1''';
      V_SQL := V_UPDATE_TABLE || V_UPDATE_COLS || V_UPDATE_WHERE ;
      V_SQL_MX := V_UPDATE_TABLE_MX || V_UPDATE_COLS || V_UPDATE_WHERE_MX ;

        BEGIN
            EXECUTE IMMEDIATE V_SQL ;
            EXECUTE IMMEDIATE V_SQL_MX ;
            --记录款项变更历史
            FOR I IN 1 .. TRANS_TABLE.COUNT LOOP
              INSERT INTO t_sales_amount_trans
                  ( trans_id,   --事务ID
                    entity_id,   --主体ID
                    sales_year_id,   --销售年度ID
                    customer_id,   --客户ID
                    account_id,   --账户ID
                    credit_group_id, --额度组ID
                    proj_number,   --项目号
                    sales_main_type,   --营销大类ID
                    order_id,   --单据ID
                    order_type,   --单据类型
                    action_flag,   --动作标识
                    trans_action,   --事务动作（1：增加；2：减少；3：变更）
                    amount_name,   --款项名称
                    amount,   --金额
                    due_flag,   --处理标识（1：成功；2：失败）
                    created_by,   --创建人
                    creation_date,   --创建日期
                    last_updated_by,   --最后修改人
                    last_update_date,   --最后修改日期
                    pre_field_01,
                    pre_field_02,
                    pre_field_03,
                    pre_field_04,
                    pre_field_05,
                    pre_field_06 )
             VALUES
                  ( S_sales_amount_trans.Nextval ,   --事务ID
                    P_ENTITY_ID,   --主体ID
                    NULL ,   --销售年度ID
                    P_CUSTOMER_ID,   --客户ID
                    P_ACCOUNT_ID,   --账户ID
                    V_CREDIT_GROUP_ID,   --额度组ID
                    P_PROJ_NUMBER,   --项目号
                    P_SALES_MAIN_TYPE,   --营销大类
                    P_ORDER_ID,   --单据ID
                    V_ORDER_TYPE,   --单据类型
                    P_ACTION_TYPE,  --动作标识
                    TRANS_TABLE(I).R_TRANS_ACTION,   --事务动作（1：增加；2：减少；3：变更）
                    TRANS_TABLE(I).R_AMOUNT_NAME,   --款项名称
                    TRANS_TABLE(I).R_AMOUNT,   --金额
                    '1' ,   --处理标识（1：成功；2：失败）
                    P_USERNAME,   --创建人
                    SYSDATE ,   --创建日期
                    P_USERNAME,   --最后修改人
                    SYSDATE,   --最后修改日期
                    NULL ,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                     );
            END LOOP ;
        EXCEPTION WHEN OTHERS THEN
          P_RESULT  := -20000 ;
          P_ERR_MSG := '执行更新款项信息操作失败，请了解！'|| V_NL || SQLERRM;
          --ROLLBACK ;
          --RAISE V_BASE_EXCEPTION ;
          RETURN ;
        END ;

  END PRC_CREDIT_FUND_UPDATE;

  PROCEDURE 订单检查不锁款调用 is begin null ; end ;


  Procedure PRC_CREDIT_ORDER_PMT_CHECK(P_ENTITY_ID               IN NUMBER, --主体ID
                                    P_ACTION_TYPE          IN NUMBER, --动作标示
                                    P_Settlement_SUM       IN NUMBER, --结算金额
                                    P_Discount_SUM         IN NUMBER, --折让金额
                                    P_SALES_MAIN_TYPE   IN VARCHAR2, --营销大类
                                    P_ACCOUNT_ID           IN NUMBER, --账户ID
                                    P_CUSTOMER_ID          IN NUMBER, --客户ID
                                    P_PROJ_NUMBER          IN VARCHAR2, --项目号
                                    P_ORDER_ID             IN NUMBER,   --单据ID
                                    P_RESULT            IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG           IN OUT VARCHAR2, --返回错误信息
                                    P_ORDER_TYPE        IN VARCHAR2 DEFAULT NULL
                            ) Is
  Begin
    Savepoint SAVEPOINT_CREDIT ;
    PRC_CREDIT_VERIFICATION(P_ENTITY_ID => P_ENTITY_ID,
                            P_ACTION_TYPE => P_ACTION_TYPE,
                            P_Settlement_SUM => P_Settlement_SUM,
                            P_Discount_SUM => P_Discount_SUM,
                            P_ORDER_ID => P_ORDER_ID,
                            P_SALES_MAIN_TYPE => P_SALES_MAIN_TYPE,
                            P_ACCOUNT_ID => P_ACCOUNT_ID,
                            P_CUSTOMER_ID => P_CUSTOMER_ID,
                            P_PROJ_NUMBER => P_PROJ_NUMBER,
                            P_RESULT =>  P_RESULT,
                            P_ERR_MSG => P_ERR_MSG,
                            P_ORDER_TYPE => P_ORDER_TYPE) ;
   --以上调用过程客户款项记录数据被for update 锁定，回滚
   Rollback To SAVEPOINT_CREDIT ;
  End ;

end PKG_CREDIT_CONTROL_PMT;
/

