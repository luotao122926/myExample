create PROCEDURE      p_seq_modify is
  --更新各序列值的动态sql语句
  rowid number;

begin

  --查询表中主键的最大值,后根据最大值重新创建ksequence
  --rowid := f_get_maxid(tablename,keyname);  
  --p_seq_replace(seqname,rowid);
  --示例
  --rowid := f_get_maxid('t_bd_esb_log','row_id');  --获取最大值
  --p_seq_replace('s_bd_esb_log',rowid);         ----设置seq最大值
  rowid := GREATEST(f_get_maxid('t_bd_code_rule', 'code_rule_id'),
                    f_get_maxid('t_bd_code_rule_detail',
                                'code_rule_detail_id'),
                    f_get_maxid('t_bd_district', 'row_id'),
                    f_get_maxid('t_bd_item', 'item_id'),
                    f_get_maxid('t_bd_item_assemblies', 'item_assembly_id'),
                    f_get_maxid('t_bd_item_assemblies_sub',
                                'item_subassembly_id'),
                    f_get_maxid('t_bd_item_class', 'item_class_id'),
                    f_get_maxid('t_bd_item_codelist', 'id'),
                    f_get_maxid('t_bd_price_line', 'price_line_id'),
                    f_get_maxid('t_bd_price_list', 'price_list_id'),
                    f_get_maxid('t_bd_price_system', 'price_system_id'),
                    f_get_maxid('t_bd_price_system_cust', 'system_cust_id'),
                    f_get_maxid('t_bd_price_system_org', 'system_org_id'),
                    f_get_maxid('t_bd_uom', 'uom_id'));
  p_seq_replace('seq_bd_row_id', rowid);

  rowid := f_get_maxid('up_org_unit', 'unit_id');
  p_seq_replace('seq_up_org_unit', rowid);

  rowid := f_get_maxid('up_org_user', 'user_id');
  p_seq_replace('seq_up_org_user', rowid);

  rowid := f_get_maxid('up_sec_busi_role', 'busi_role_id');
  p_seq_replace('seq_up_sec_busi_role', rowid);
  ----------------bd end  ------------------

  rowid := f_get_maxid('T_PLN_CENTER_COST_RELATION',
                       'CENTER_COST_RELATION_ID');
  p_seq_replace('S_PLN_CENTER_COST_RELATION', rowid);
  rowid := f_get_maxid('T_PLN_COMPANY_RELA', 'RELA_ID');
  p_seq_replace('S_PLN_COMPANY_RELA', rowid);
  rowid := f_get_maxid('T_PLN_CUSTOMER_PRIORITY',
                       'SALES_CENTER_PRIORITY_ID');
  p_seq_replace('S_PLN_CUSTOMER_PRIORITY', rowid);
  rowid := f_get_maxid('T_PLN_CUS_MAINTAIN_ORDER_HEAD', 'ORDER_HEAD_ID');
  p_seq_replace('S_PLN_CUS_MAINTAIN_ORDER_HEAD', rowid);
  rowid := f_get_maxid('T_PLN_CUS_MAINTAIN_ORDER_LINE', 'ORDER_LINE_ID');
  p_seq_replace('S_PLN_CUS_MAINTAIN_ORDER_LINE', rowid);

  rowid := GREATEST(f_get_maxid('T_PLN_FLOW', 'FLOW_ID'),
                    f_get_maxid('T_PLN_FLOW_STATUS', 'FLOW_STATUS_ID'),
                    f_get_maxid('T_PLN_FLOW_TYPE', 'FLOW_TYPE_ID'),
                    f_get_maxid('T_PLN_FLOW_TYPE_ACTION', 'ACTION_ID'),
                    f_get_maxid('T_PLN_FLOW_TYPE_STATUS', 'STATUS_ID'));
  p_seq_replace('S_PLN_FLOW', rowid);

  rowid := f_get_maxid('T_PLN_INV_SPECIAL_OCCUPY', 'SPECIAL_OCCUPY_ID');
  p_seq_replace('S_PLN_INV_SPECIAL_OCCUPY', rowid);
  rowid := f_get_maxid('T_PLN_INV_SPECIAL_OCCUPY_HIS', 'HIS_ID');
  p_seq_replace('S_PLN_INV_SPECIAL_OCCUPY_HIS', rowid);

  rowid := f_get_maxid('T_PLN_ITEM_PLASTIC', 'ITEM_PLASTIC_ID');
  p_seq_replace('S_PLN_ITEM_PLASTIC', rowid);

  rowid := f_get_maxid('T_PLN_LG_ORDER_HEAD', 'ORDER_HEAD_ID');
  p_seq_replace('S_PLN_LG_ORDER_HEAD', rowid);
  rowid := f_get_maxid('T_PLN_LG_ORDER_LINE', 'ORDER_LINE_ID');
  p_seq_replace('S_PLN_LG_ORDER_LINE', rowid);
  rowid := f_get_maxid('T_PLN_MOULD_PRODUCTIVITY_AREA', 'AREA_PLASTIC_ID');
  p_seq_replace('S_PLN_MOULD_PRODUCTIVITY_AREA', rowid);
  rowid := f_get_maxid('T_PLN_MOULD_PRODUCTIVITY_SHOW',
                       'MOULD_PRODUCTIVITY_SHOW_ID');
  p_seq_replace('S_PLN_MOULD_PRODUCTIVITY_SHOW', rowid);
  rowid := f_get_maxid('T_PLN_ORDER_ADJUST_DETAIL',
                       'ORDER_ADJUST_DETAIL_ID');
  p_seq_replace('S_PLN_ORDER_ADJUST_DETAIL', rowid);
  rowid := f_get_maxid('T_PLN_ORDER_ADJUST_HEAD', 'ORDER_ADJUST_HEAD_ID');
  p_seq_replace('S_PLN_ORDER_ADJUST_HEAD', rowid);
  rowid := f_get_maxid('T_PLN_ORDER_ADJUST_LINE', 'ORDER_ADJUST_LINE_ID');
  p_seq_replace('S_PLN_ORDER_ADJUST_LINE', rowid);
  rowid := f_get_maxid('T_PLN_ORDER_COLLECT_DETAIL', 'COLL_ORD_DETAIL_ID');
  p_seq_replace('S_PLN_ORDER_COLLECT_DETAIL', rowid);
  rowid := GREATEST(f_get_maxid('T_PLN_ORDER_COLLECT_HEAD',
                                'COLL_ORD_HEAD_ID'),
                    f_get_maxid('T_PLN_ORDER_COLLECT_LINE',
                                'COLL_ORD_LINE_ID'));
  p_seq_replace('S_PLN_ORDER_COLLECT_LINE', rowid);
  rowid := f_get_maxid('T_PLN_ORDER_COLLECT_SHOW', 'ORDER_COLLECT_SHOW_ID');
  p_seq_replace('S_PLN_ORDER_COLLECT_SHOW', rowid);
  rowid := f_get_maxid('T_PLN_ORDER_DETAIL', 'ORDER_DETAIL_ID');
  p_seq_replace('S_PLN_ORDER_DETAIL', rowid);
  --rowid := f_get_maxid('T_PLN_ORDER_DETAIL_OA','ORDER_DETAIL_ID');
  --p_seq_replace('S_PLN_ORDER_DETAIL_OA',rowid);
  rowid := f_get_maxid('T_PLN_ORDER_HEAD', 'ORDER_HEAD_ID');
  p_seq_replace('S_PLN_ORDER_HEAD', rowid);
  rowid := f_get_maxid('T_PLN_ORDER_INV_OCCUPY_HIS', 'INV_OCCUPY_HIS_ID');
  p_seq_replace('S_PLN_ORDER_INV_OCCUPY_HIS', rowid);
  rowid := f_get_maxid('T_PLN_ORDER_INV_REVIEW', 'ORDER_INV_ID');
  p_seq_replace('S_PLN_ORDER_INV_REVIEW', rowid);
  rowid := f_get_maxid('T_PLN_ORDER_LINE', 'ORDER_LINE_ID');
  p_seq_replace('S_PLN_ORDER_LINE', rowid);
  --rowid := f_get_maxid('T_PLN_ORDER_LINE_OA','ORDER_LINE_ID');
  -- p_seq_replace('S_PLN_ORDER_LINE_OA',rowid);
  --rowid := f_get_maxid('T_PLN_ORDER_LOOKUPS','LOOKUP_ID');
  --p_seq_replace('S_PLN_ORDER_LOOKUPS',rowid);
  rowid := f_get_maxid('T_PLN_ORDER_PERIOD', 'PERIOD_ID');
  p_seq_replace('S_PLN_ORDER_PERIOD', rowid);
  rowid := f_get_maxid('T_PLN_ORDER_REVIEW_INFO', 'ORDER_REVIEW_ID');
  p_seq_replace('S_PLN_ORDER_REVIEW_INFO', rowid);
  rowid := f_get_maxid('T_PLN_ORDER_SHARE_HISTORY',
                       'ORDER_SHARE_HISTORY_ID');
  p_seq_replace('S_PLN_ORDER_SHARE_HISTORY', rowid);
  rowid := f_get_maxid('T_PLN_ORDER_SHARE_SHIPMENT', 'ORDER_SHARE_ID');
  p_seq_replace('S_PLN_ORDER_SHARE_SHIPMENT', rowid);
  rowid := f_get_maxid('T_PLN_ORDER_STOCK_AFFIRM', 'ORDER_LINE_ID');
  p_seq_replace('S_PLN_ORDER_STOCK_AFFIRM', rowid);
  rowid := f_get_maxid('T_PLN_ORDER_TYPE', 'ORDER_TYPE_ID');
  p_seq_replace('S_PLN_ORDER_TYPE', rowid);
  rowid := f_get_maxid('T_PLN_ORDER_TYPE_PAGE', 'ORDER_TYPE_PAGE_ID');
  p_seq_replace('S_PLN_ORDER_TYPE_PAGE', rowid);
  rowid := f_get_maxid('T_PLN_PLASTIC', 'PLASTIC_ID');
  p_seq_replace('S_PLN_PLASTIC', rowid);
  rowid := f_get_maxid('T_PLN_PRDC_AREA_RCV_INVENTORY', 'AREA_INV_ID');
  p_seq_replace('S_PLN_PRDC_AREA_RCV_INVENTORY', rowid);
  rowid := f_get_maxid('T_PLN_PRODUCING_AREA', 'PRODUCING_AREA_ID');
  p_seq_replace('S_PLN_PRODUCING_AREA', rowid);
  rowid := f_get_maxid('T_PLN_TOTAL_PRODUCTIVITY_AREA', 'AREA_TOTAL_PRO_ID');
  p_seq_replace('S_PLN_TOTAL_PRODUCTIVITY_AREA', rowid);
  --rowid := f_get_maxid('T_PLN_TOTAL_PRODUCTIVITY_SHOW','TOTAL_PRODUCTIVITY_SHOW_ID');
  --p_seq_replace('S_PLN_TOTAL_PRODUCTIVITY_SHOW',rowid);
  rowid := f_get_maxid('T_PLN_WIP_ORDER_RELATION', 'WIP_ORDER_ID');
  p_seq_replace('S_PLN_WIP_ORDER_RELATION', rowid);

  ----------AR BY ANHT START--------------
  rowid := f_get_maxid('T_AR_OU_RELATION', 'RELATION_ID') + 1; --中心默认OU
  p_seq_replace('s_ar_ou_relation', rowid);

  rowid := f_get_maxid('T_AR_RECEIPT_WRITEOFF_TYPES', 'WRITE_OFF_ID') + 1; --冲销原因 
  p_seq_replace('s_ar_receipt_writeoff_types', rowid);

  rowid := f_get_maxid('T_AR_RECEIPT_METHODS', 'RECEIPT_METHOD_ID') + 1; --收款方法
  p_seq_replace('s_ar_receipt_methods', rowid);

  rowid := f_get_maxid('t_ar_cash_receipt_headers', 'CASH_RECEIPT_ID') + 1; --收款头
  p_seq_replace('s_ar_cash_receipt_headers', rowid);

  rowid := f_get_maxid('T_AR_CASH_RECEIPT_LINES', 'CASH_RECEIPT_LINES_ID') + 1; --收款行
  p_seq_replace('s_ar_cash_receipt_lines', rowid);

  rowid := f_get_maxid('INTF_AR_INVOICE', 'TRX_ID') + 1; --ERP接口 AR发票
  p_seq_replace('s_intf_ar_invoice', rowid);

  rowid := f_get_maxid('INTF_AR_CASH_RECEIPT', 'TRX_ID') + 1; --ERP接口 收款
  p_seq_replace('s_intf_ar_cash_receipt', rowid);

  ----------AR BY ANHT START--------------

  ----------AR BY zhangwm START--------------  

  rowid := f_get_maxid('T_INV_CHECK_ORDERS', 'CHECK_ORDER_ID') + 1; --盘点单头序列
  p_seq_replace('S_INV_CHECK_ORDERS', rowid);

  rowid := f_get_maxid('T_INV_CHECK_ORDER_LINES', 'CHECK_ORDER_LINE_ID') + 1; --盘点单行序列
  p_seq_replace('S_INV_CHECK_ORDER_LINES', rowid);

  rowid := f_get_maxid('T_INV_LOGISTICS_SHIP_TO_PRIV', 'LOGISTICS_SHIP_ID') + 1; --分仓仓信息序列
  p_seq_replace('S_INV_SEQ', rowid);

  rowid := f_get_maxid('T_INV_STORAGE_INFO', 'STORAGE_ID') + 1; --A3实体仓序列
  p_seq_replace('S_INV_STORAGE_INFO', rowid);

  rowid := f_get_maxid('T_INV_STORAGE_INTF', 'LOGISTIC_INTERFACE_ID') + 1; --A3仓库接口序列
  p_seq_replace('S_INV_SEQ', rowid);

  rowid := f_get_maxid('T_INV_VENDOR_MRPII_INV', 'VENDOR_MRPII_ID') + 1; --车间仓结算仓序列
  p_seq_replace('S_INV_VENDOR_MRPII_INV', rowid);

  ----------AR BY zhangwm START--------------

  ----------INV BY QINQINGHUA START--------------  

  rowid := f_get_maxid('T_INV_SECONDARY_INVENTORIES', 'SUB_ID'); --ERP子库存接口序列
  p_seq_replace('S_INV_SECONDARY_INVENTORIES', rowid);

  rowid := f_get_maxid('T_INV_BILL_TYPES', 'BILL_TYPE_ID'); --业务单据类型序列
  p_seq_replace('S_INV_BILL_TYPES', rowid);

  rowid := f_get_maxid('T_INV_BILL_CONFIG', 'BILL_CONFIG_ID'); --业务单据配置序列
  p_seq_replace('S_INV_BILL_CONFIG', rowid);

  rowid := f_get_maxid('T_INV_MONTHSUM', 'MONTHSUM_ID'); --产品月度收发存表序列
  p_seq_replace('S_INV_MONTHSUM', rowid);

  rowid := f_get_maxid('T_INV_INVENTORIES_ITEM_CLASS', 'INVENTORY_CLASS_ID'); --仓库产品类别对照序列
  p_seq_replace('S_INV_INVENTORIES_ITEM_CLASS', rowid);

  rowid := f_get_maxid('T_INV_INVENTORIES_SALES_CENTER', 'INVENTORY_ORG_ID'); --仓库营销中心对照序列
  p_seq_replace('S_INV_INVENTORIES_SALES_CENTER', rowid);

  rowid := f_get_maxid('T_INV_INVENTORIES', 'INVENTORY_ID'); --仓库设置序列
  p_seq_replace('S_INV_INVENTORIES', rowid);

  rowid := f_get_maxid('T_INV_BILL_PERIOD_HEAD', 'BILL_PERIOD_HEAD_ID'); --单据周期维护头序列
  p_seq_replace('S_INV_BILL_PERIOD_HEAD', rowid);

  rowid := f_get_maxid('T_INV_BILL_PERIOD_LINE', 'BILL_PERIOD_LINE_ID'); --单据周期维护行序列
  p_seq_replace('S_INV_BILL_PERIOD_LINE', rowid);

  rowid := f_get_maxid('T_INV_SOURCE_TYPES', 'SOURCE_TYPE_ID'); --单据源类型序列
  p_seq_replace('S_INV_SOURCE_TYPES', rowid);

  rowid := f_get_maxid('T_INV_BILL_GENERIC', 'BILL_GENERIC_ID'); --单据账户别名组织对照序列
  p_seq_replace('S_INV_BILL_GENERIC', rowid);

  rowid := f_get_maxid('T_INV_INVENTORY_PERIODS', 'PERIOD_ID'); --存货会计期间序列
  p_seq_replace('S_INV_INVENTORY_PERIODS', rowid);

  rowid := f_get_maxid('T_INV_RECONCILIATION', 'RECONCILIATION_ID'); --库存对账序列
  p_seq_replace('S_INV_RECONCILIATION', rowid);

  rowid := f_get_maxid('T_INV_ONHAND', 'INV_ID'); --库存现有量序列
  p_seq_replace('S_INV_CURRENT_INVENTORY', rowid);

  rowid := f_get_maxid('T_INV_RECALCULATION_HISTORY', 'RECALCULATION_ID'); --库存现有量重算历史序列
  p_seq_replace('S_INV_RECALCULATION_HISTORY', rowid);

  rowid := f_get_maxid('T_INV_ORGANIZATION', 'INV_ID'); --库存组织序列
  p_seq_replace('S_INV_ORGANIZATION', rowid);

  rowid := f_get_maxid('T_INV_TRANSACTION_HISTORY', 'TRANSACTION_ID'); --物料事务历史序列
  p_seq_replace('S_INV_TRANSACTION_HISTORY', rowid);

  rowid := f_get_maxid('T_INV_GENERIC_DISPOSITIONS', 'ALIAS_ID'); --账户别名接口表序列
  p_seq_replace('S_INV_GENERIC_DISPOSITIONS', rowid);
  ----------INV BY QINQINGHUA END--------------

  ----------POL BY QINQINGHUA START--------------  

  rowid := f_get_maxid('T_POL_YEAR_BUDGET', 'POL_YEAR_BUDGET_ID'); --年度预算管理序列
  p_seq_replace('S_POL_YEAR_BUDGET', rowid);

  rowid := f_get_maxid('T_POL_POLICY_TYPE', 'POLICY_TYPE_ID'); --政策大类（预算大类）序列
  p_seq_replace('S_POL_POLICY_TYPE', rowid);

  rowid := f_get_maxid('T_POL_POLICY_SECTION', 'POLICY_SECTION_ID'); --政策小类（预算小类）序列
  p_seq_replace('S_POL_POLICY_SECTION', rowid);

  rowid := f_get_maxid('T_POL_POLICY_BUDGET_FEE_REPORT',
                       'POLICY_BUDGET_FEE_ID'); --政策预提使用序列
  p_seq_replace('S_POL_POLICY_BUDGET_FEE_REPORT', rowid);

  rowid := f_get_maxid('T_POL_DEALER_POLICY_FEE_REPORT',
                       'DEALER_POLICY_FEE_ID'); --经销商政策使用序列
  p_seq_replace('S_POL_DEALER_POLICY_FEE_REPORT', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_RELEASE_HEAD', 'RELEASE_ID'); --预留资源释放头序列
  --p_seq_replace('S_POL_BUDGET_RELEASE_HEAD', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_RELEASE_LINES', 'RELEASE_ID'); --预留资源释放行信息序列
  --p_seq_replace('S_POL_BUDGET_RELEASE_LINES', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_FEE_DETAIL', 'FEE_DETAIL_ID'); --预算使用明细序列
  p_seq_replace('S_POL_BUDGET_FEE_DETAIL', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_CONTROL', 'BUDGET_SEG_CTR_ID'); --预算层次控制序列
  p_seq_replace('S_POL_BUDGET_CONTROL', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_YEAR', 'BUDGET_YEAR_ID'); --预算年度管理序列
  p_seq_replace('S_POL_BUDGET_YEAR', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_SEGMENT', 'BUDGET_SEGMENT_ID'); --预算层次管理序列
  p_seq_replace('S_POL_BUDGET_SEGMENT', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_DATA_FLOW', 'DATA_FLOW_ID'); --预算数据流序列
  p_seq_replace('S_POL_BUDGET_DATA_FLOW', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_DETAIL', 'T_POL_BUDGET_DETAIL'); --预算明细序列
  p_seq_replace('S_POL_BUDGET_DETAIL', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_PERIOD', 'BUDGET_PERIOD_ID'); --预算月度序列
  p_seq_replace('S_POL_BUDGET_PERIOD', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_CALCULATION_EXPRE', 'EXPRESS_ID'); --预算来源计算公式分解序列
  p_seq_replace('S_POL_BUDGET_CALCULATION_EXPRE', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_CALCULATION_FORMU', 'CALCULATION_ID'); --预算来源计算公式头序列
  p_seq_replace('S_POL_BUDGET_CALCULATION_FORMU', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_CALC_FORMU_LINES',
                       'CALC_FORMU_LINES_ID'); --预算来源计算公式行序列
  p_seq_replace('S_POL_BUDGET_CALC_FORMU_LINES', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_SEMANTIC', 'SEMANTIC_ID'); --预算来源计算字典序列
  p_seq_replace('S_POL_BUDGET_SEMANTIC', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_CALC_PERIOD', 'BUDGET_CALC_PERIOD_ID'); --预算来源计算阶段序列
  p_seq_replace('S_POL_BUDGET_CALC_PERIOD', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_TREE', 'BUDGET_TREE_ID'); --预算树序列
  p_seq_replace('S_POL_BUDGET_TREE', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_RESULT_HEAD', 'BUDGET_RESULT_ID'); --预算计算结果头序列
  p_seq_replace('S_POL_BUDGET_RESULT_HEAD', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_RESULT_LINE', 'RESULT_LINE_ID'); --预算计算结果行序列
  p_seq_replace('S_POL_BUDGET_RESULT_LINE', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_ADJUST_HEAD', 'BUDGET_ADJUST_ID'); --预算调整头序列
  p_seq_replace('S_POL_BUDGET_ADJUST_HEAD', rowid);

  rowid := f_get_maxid('T_POL_BUDGET_ADJUST_LINE', 'BUDGET_ADJUST_LINE_ID'); --预算调整行序列
  p_seq_replace('S_POL_BUDGET_ADJUST_LINE', rowid);

  rowid := f_get_maxid('T_POL_OI_CUSTOMER_CSS_RELA', 'CUSTOMER_CSS_RELA_ID'); --CSS与IMS客户关系序列
  p_seq_replace('S_POL_OI_CUSTOMER_CSS_RELA', rowid);

  rowid := f_get_maxid('T_POL_POLICY_MTL_TYPE', 'MTL_TYPE_ID'); --商品分类序列
  p_seq_replace('S_POL_POLICY_MTL_TYPE', rowid);

  rowid := f_get_maxid('T_POL_POLICY_OUT_DATA', 'OUT_DATA_ID'); --外部数据序列
  p_seq_replace('S_POL_POLICY_OUT_DATA', rowid);

  rowid := f_get_maxid('T_POL_POLICY_MAIL', 'POLICY_MAIL_ID'); --收件人清单序列
  p_seq_replace('S_POL_POLICY_MAIL', rowid);

  rowid := f_get_maxid('T_POL_ORDER_HEADERS', 'POLICY_ORDER_ID'); --政策Y单头序列
  p_seq_replace('S_POL_ORDER_HEADERS', rowid);

  rowid := f_get_maxid('T_POL_ORDER_LINES', 'LINE_ID'); --政策Y单行序列
  p_seq_replace('S_POL_ORDER_LINES', rowid);

  rowid := f_get_maxid('T_POL_POLICY_DEF_STD', 'STD_ID'); --政策兑现标准序列
  p_seq_replace('S_POL_POLICY_DEF_STD', rowid);

  rowid := f_get_maxid('T_POL_POLICY_CUS_TYPE', 'CUS_TYPE_LINE_ID'); --政策客户信息序列
  p_seq_replace('S_POL_POLICY_CUS_TYPE', rowid);

  rowid := f_get_maxid('T_POL_POLICY_LINE', 'DETAIL_ID'); --政策申请行序列
  p_seq_replace('S_POL_POLICY_LINE', rowid);

  rowid := f_get_maxid('T_POL_POLICY', 'POLICY_ID'); --政策申请序列
  p_seq_replace('S_POL_POLICY', rowid);

  rowid := f_get_maxid('T_POL_POLICY_DEF_ITEM', 'ITEM_ID'); --政策算法定义子项序列
  p_seq_replace('S_POL_POLICY_DEF_ITEM', rowid);

  rowid := f_get_maxid('T_POL_POLICY_DEFINE', 'DEFINE_ID'); --政策算法定义序列
  p_seq_replace('S_POL_POLICY_DEFINE', rowid);

  rowid := f_get_maxid('T_POL_TYPE', 'APPLY_TYPE_ID'); --政策类型维护序列
  p_seq_replace('S_POL_TYPE', rowid);

  rowid := f_get_maxid('T_POL_POLICY_ADJUST', 'POLICY_ADJUST_ID'); --政策调整项序列
  p_seq_replace('S_POL_POLICY_ADJUST', rowid);

  rowid := f_get_maxid('T_POL_SEMANTIC_LINE', 'SEMANTIC_LINE_ID'); --语义定义行序列
  p_seq_replace('S_POL_SEMANTIC_LINE', rowid);

  rowid := f_get_maxid('T_POL_SEMANTIC', 'SEMANTIC_ID'); --语义定义序列
  p_seq_replace('S_POL_SEMANTIC', rowid);

  rowid := f_get_maxid('T_POL_POLICY_FREEZE', 'FREEZE_ID'); --冻结数据明细序列
  p_seq_replace('S_POL_POLICY_FREEZE', rowid);

  rowid := f_get_maxid('T_POL_POLICY_RESULT_CHK', 'RESULT_CHK_ID'); --政策结果审批序列
  p_seq_replace('S_POL_POLICY_RESULT_CHK', rowid);

  rowid := f_get_maxid('T_POL_POLICY_RESULT_DETAIL', 'DETAIL_ID'); --政策结果明细序列
  p_seq_replace('S_POL_POLICY_RESULT_DETAIL', rowid);

  rowid := f_get_maxid('T_POL_POLICY_RESULT', 'RESULT_ID'); --政策结果序列
  p_seq_replace('S_POL_POLICY_RESULT', rowid);

  rowid := f_get_maxid('T_POL_DISCOUNT_SPLIT', 'SPLIT_ID'); --返利上账拆单序列
  p_seq_replace('S_POL_DISCOUNT_SPLIT', rowid);

  rowid := f_get_maxid('T_POL_DISCOUNT_LINES', 'LINE_ID'); --返利单明细行序列
  p_seq_replace('S_POL_DISCOUNT_LINES', rowid);

  rowid := f_get_maxid('T_POL_DISCOUNT_ORDER', 'DISCOUNT_ORDER_ID'); --返利单序列
  p_seq_replace('S_POL_DISCOUNT_ORDER', rowid);

  rowid := f_get_maxid('T_POL_DISCOUNT_REPORT', 'SALES_DISCOUNT_ID'); --返利消化统计报表序列
  p_seq_replace('S_POL_DISCOUNT_REPORT', rowid);

  rowid := f_get_maxid('T_POL_SEND_EMAIL', 'SEND_ID'); --邮件发送序列
  p_seq_replace('S_POL_SEND_EMAIL', rowid);

  rowid := f_get_maxid('T_POL_EMAIL_TEMPLET_DETAIL', 'LINE_ID'); --邮件模板配置序列
  p_seq_replace('S_POL_EMAIL_TEMPLET_DETAIL', rowid);

  rowid := f_get_maxid('T_POL_EMIAL_TEMPLET', 'TEMPLATE_ID'); --邮件模板配置序列
  --p_seq_replace('S_POL_EMIAL_TEMPLET', rowid);

  rowid := f_get_maxid('T_POL_SALES_DATA', 'SALES_DATA_ID'); --销售数据历史序列
  p_seq_replace('S_POL_SALES_DATA', rowid);

  ----------POL BY QINQINGHUA END--------------

  ----------LG BY XUQF START--------------

  --物流分类
  rowid := f_get_maxid('T_LG_CHARGES_CATEGORY', 'CHARGES_CATEGORY_ID');
  p_seq_replace('SEQ_LG_CC_ID', rowid);

  --物流产品
  rowid := f_get_maxid('T_LG_CHARGES_MATERIAL', 'LG_PRODUCT_ID');
  p_seq_replace('SEQ_LG_CM_ID', rowid);

  --物流费用类型
  rowid := f_get_maxid('T_LG_CHARGES_TYPE', 'CHARGES_TYPE_ID');
  p_seq_replace('SEQ_LG_CT_ID', rowid);

  --物流费用标准
  rowid := f_get_maxid('T_LG_FARE_STAND', 'CHARGES_SORT_ID');
  p_seq_replace('SEQ_LG_FS_ID', rowid);

  --物流产品受损程度
  rowid := f_get_maxid('T_LG_VALUE_RATE', 'VALUE_RATE_ID');
  p_seq_replace('SEQ_LG_RATE_ID', rowid);

  --保险商免陪率
  rowid := f_get_maxid('T_LG_INSURER_EXCESS', 'INSURER_EXCESS_ID');
  p_seq_replace('SEQ_LG_INSURER_EXCESS_ID', rowid);

  --运输线路
  rowid := f_get_maxid('T_LG_TRANSPORT_LINE', 'TRANSPORT_LINE_ID');
  p_seq_replace('SEQ_LG_LINE_ID', rowid);

  ----------LG BY XUQF END--------------
  
  ----------AR BY sudy START--------------  
  
  rowid := f_get_maxid('T_CREDIT_GROUP','CREDIT_GROUP_ID'); --额度组序列
  p_seq_replace('S_CREDIT_GROUP',rowid);         
  
  rowid := f_get_maxid('T_CREDIT_CATEGORY_GROUP_REL','REL_ID') ;  --额度组营销大类关系序列
  p_seq_replace('S_CREDIT_CATEGORY_GROUP_REL',rowid);         
  

  rowid := f_get_maxid('T_CREDIT_CUST_GROUP','CUST_GROUP_ID') ;  --客户组序列
  p_seq_replace('S_CREDIT_CUST_GROUP',rowid);         
    
  rowid := f_get_maxid('T_CREDIT_CUST_GROUP_REL','REL_ID');  --客户组客户关系序列
  p_seq_replace('S_CREDIT_CUST_GROUP_REL',rowid);   
  
  rowid := f_get_maxid('T_CREDIT_RATING','CREDIT_RATING_ID') ;  --信用等级、计算规则序列
  p_seq_replace('S_CREDIT_RATING',rowid);  
  
  
  rowid := f_get_maxid('T_SALES_ACCOUNT_AMOUNT','ACCOUNT_AMOUNT_ID');  --客户款项序列
  p_seq_replace('S_SALES_ACCOUNT_AMOUNT',rowid);  
  
  rowid := f_get_maxid('T_SALES_ACCOUNT_MX_AMOUNT','ACCOUNT_AMOUNT_MX_ID');  --客户款项序列
  p_seq_replace('S_SALES_ACCOUNT_MX_AMOUNT',rowid);  
  
  rowid := f_get_maxid('T_CREDIT_CONTROL_TEMP','CONTROL_TEMP_ID');  --临时表序列
  p_seq_replace('S_CREDIT_CONTROL_TEMP',rowid);  
   
    ----------AR BY sudy START--------------

end p_seq_modify;
/

