create view V_BD_ITEM_FOR_CCS as
select b.item_code,
       b.item_name,
       a.customer_code,
       a.customer_name,
       a.sales_center_code,
       a.sales_center_name,
       a.begin_date,
       a.end_date,
       a.entity_id,
       a.active_flag,
       a.created_by,
       a.creation_date,
       a.last_updated_by,
       a.last_update_date
  from  T_BD_ITEM_FOR a, t_bd_item b
 where a.item_id = b.item_id
     and a.active_flag = 'Y'
     and nvl(b.is_specialfor,'N') = 'Y'
/

