create view INTF_CREDIT_BAD_RECORD as
select T.BAD_RECORD_ID ,
         T.ENTITY_ID,
         T.CUSTOMER_ID,
         T.CUSTOMER_CODE,
         T.CUSTOMER_NAME,
         T.SALES_CENTER_ID,
         T.SALES_CENTER_CODE,
         T.SALES_CENTER_NAME,
         T.SALES_MAIN_TYPE,
         T.SALES_REGION_ID,
         T.SALES_REGION_CODE,
         T.SALES_REGION_NAME,
         T.BAD_RECORD_TYPE,
         T.CREATED_BY,
         T.CREATION_DATE,
         T.LAST_UPDATED_BY,
         T.LAST_UPDATE_DATE,
         T.PAY_DATE,
         T.COUNTER,
         t.bill_id
    from t_Credit_Bad_Record T with read only
/

comment on column INTF_CREDIT_BAD_RECORD.BAD_RECORD_ID is '不良记录ID'
/

comment on column INTF_CREDIT_BAD_RECORD.ENTITY_ID is '经营主体ID'
/

comment on column INTF_CREDIT_BAD_RECORD.CUSTOMER_ID is '客户ID'
/

comment on column INTF_CREDIT_BAD_RECORD.CUSTOMER_CODE is '客户编码'
/

comment on column INTF_CREDIT_BAD_RECORD.CUSTOMER_NAME is '客户名称'
/

comment on column INTF_CREDIT_BAD_RECORD.SALES_CENTER_ID is '营销中心ID'
/

comment on column INTF_CREDIT_BAD_RECORD.SALES_CENTER_CODE is '营销中心编码'
/

comment on column INTF_CREDIT_BAD_RECORD.SALES_CENTER_NAME is '营销中心名称'
/

comment on column INTF_CREDIT_BAD_RECORD.SALES_MAIN_TYPE is '营销大类'
/

comment on column INTF_CREDIT_BAD_RECORD.SALES_REGION_ID is '销售区域ID'
/

comment on column INTF_CREDIT_BAD_RECORD.SALES_REGION_CODE is '销售区域编码'
/

comment on column INTF_CREDIT_BAD_RECORD.SALES_REGION_NAME is '销售区域名称'
/

comment on column INTF_CREDIT_BAD_RECORD.BAD_RECORD_TYPE is '不良记录类型(1：逾期记录；2：延期记录)'
/

comment on column INTF_CREDIT_BAD_RECORD.CREATED_BY is '创建人'
/

comment on column INTF_CREDIT_BAD_RECORD.CREATION_DATE is '创建日期'
/

comment on column INTF_CREDIT_BAD_RECORD.LAST_UPDATED_BY is '最后修改人'
/

comment on column INTF_CREDIT_BAD_RECORD.LAST_UPDATE_DATE is '最后修改日期'
/

comment on column INTF_CREDIT_BAD_RECORD.PAY_DATE is '还清日期'
/

comment on column INTF_CREDIT_BAD_RECORD.COUNTER is '次数'
/

comment on column INTF_CREDIT_BAD_RECORD.BILL_ID is '铺底单据ID'
/

