create PACKAGE BODY      PKG_IO_ERP AS

  -----------------------------------------------------------------------------
  -- 将出错的接口更新状态，以重新引ERP
  -- 由于更新SQL中已有状态判断，故更新前不需锁表
  -- 出错则将出错信息记录出错日志表。
  -----------------------------------------------------------------------------
  PROCEDURE P_RESET_ALL_INTF
  IS
    N_CUR     NUMBER;
    N_ROW     NUMBER;
    N_HEADER_ID NUMBER;
    S_MSG     VARCHAR2(1000);
  BEGIN
    
  
  FOR C_INTF_REPEAT IN
    (
       SELECT 
              TRX_ID
             ,BUSINESSTYPE
             ,RECEIPT_NUMBER
         FROM V_AR_INTF_RESET
        WHERE INTF_STATUS = 'E'
          AND RESPONSEMESSAGE LIKE '%已存在%'
    )
    LOOP  
       BEGIN
           N_HEADER_ID := null;
           
           IF C_INTF_REPEAT.BUSINESSTYPE = '推式关联物流接收' THEN 
               BEGIN
                   SELECT 
                       REQ_HEADER_ID 
                   INTO 
                       N_HEADER_ID    
                   FROM 
                       CUX_ICP_LOGIST_REQ_HEADERS_V 
                   WHERE 
                       REQUIREMENT_ORDER_NUM = C_INTF_REPEAT.RECEIPT_NUMBER 
                   AND REQUIREMENT_ORDER_TYPE ='CIMS-RECEIVE';
                EXCEPTION
                   WHEN NO_DATA_FOUND THEN   
                    NULL;
                END; 
                IF N_HEADER_ID IS NOT NULL THEN 
                     UPDATE CIMS.INTF_CUX_ICP_LOGIST_REQ_HEADER H
                     SET H.X_ICP_SEQ_ID      = N_HEADER_ID,
                         H.RESPONSETYPE_2 = 'N',
                         H.RESPONSECODE_2 = '000000',
                         H.RESPONSEMESSAGE_2 = 'AUTO补充X_ICP_SEQ_ID及返回状态修复'
                     WHERE H.REQUIREMENT_ORDER_NUM =  C_INTF_REPEAT.RECEIPT_NUMBER;   
                END IF;
                
              ELSIF  C_INTF_REPEAT.BUSINESSTYPE = '推式关联物流发出' THEN    
                  BEGIN
                   SELECT 
                       REQ_HEADER_ID 
                   INTO 
                       N_HEADER_ID    
                   FROM 
                       CUX_ICP_LOGIST_REQ_HEADERS_V 
                   WHERE 
                       REQUIREMENT_ORDER_NUM = C_INTF_REPEAT.RECEIPT_NUMBER
                       AND REQUIREMENT_ORDER_TYPE ='CIMS-SEND';
                EXCEPTION
                   WHEN NO_DATA_FOUND THEN   
                    NULL;
                END; 
                IF N_HEADER_ID IS NOT NULL THEN 
                     update INTF_CUX_ICP_LOGIST_REQ_LINES 
                     set LOGIST_HEADER_ID = N_HEADER_ID
                     where HEADERS_ID = C_INTF_REPEAT.TRX_ID;    
                
                     UPDATE CIMS.INTF_CUX_ICP_LOGIST_REQ_HEADER H
                     SET H.X_ICP_SEQ_ID  = N_HEADER_ID,
                         H.Req_Header_Id = N_HEADER_ID,
                         H.RESPONSETYPE_1 = 'N',
                         H.RESPONSECODE_1 = '000000',
                         H.RESPONSEMESSAGE_1 = 'AUTO补充X_ICP_SEQ_ID及返回状态修复'
                     WHERE H.REQUIREMENT_ORDER_NUM =  C_INTF_REPEAT.RECEIPT_NUMBER;  
                   
                     IF C_INTF_REPEAT.RECEIPT_NUMBER like 'G%' THEN 
                          UPDATE T_SO_HEADER H SET H.ERP_LOGIST_HEADER_ID2 = N_HEADER_ID where H.SO_NUM = C_INTF_REPEAT.RECEIPT_NUMBER;  
                     ELSIF C_INTF_REPEAT.RECEIPT_NUMBER like 'P%' THEN 
                          UPDATE T_INV_PO_HEADERS H SET H.ERP_LOGIST_HEADER_ID = N_HEADER_ID where H.PO_NUM = C_INTF_REPEAT.RECEIPT_NUMBER;  
                     END IF;       
                END IF;
             ELSIF  C_INTF_REPEAT.BUSINESSTYPE = '拉式关联物流订单' THEN  
              BEGIN
                   SELECT 
                       REQ_HEADER_ID 
                   INTO 
                       N_HEADER_ID    
                   FROM 
                       CUX_ICP_LOGIST_REQ_HEADERS_V 
                   WHERE 
                       REQUIREMENT_ORDER_NUM = C_INTF_REPEAT.RECEIPT_NUMBER;
                EXCEPTION
                   WHEN NO_DATA_FOUND THEN   
                    NULL;
                END; 
                IF N_HEADER_ID IS NOT NULL THEN   
                     UPDATE CIMS.INTF_CUX_ICP_LOGIST_REQ_HEADER H
                     SET H.X_ICP_SEQ_ID  = N_HEADER_ID,
                         H.RESPONSETYPE_1 = 'N',
                         H.RESPONSECODE_1 = '000000',
                         H.RESPONSEMESSAGE_1 = 'AUTO补充X_ICP_SEQ_ID及返回状态修复'
                     WHERE H.REQUIREMENT_ORDER_NUM =  C_INTF_REPEAT.RECEIPT_NUMBER;  
                   
                     IF C_INTF_REPEAT.RECEIPT_NUMBER like 'G%' THEN 
                          UPDATE T_SO_HEADER H SET H.ERP_LOGIST_HEADER_ID2 = N_HEADER_ID where H.SO_NUM = C_INTF_REPEAT.RECEIPT_NUMBER;  
                     ELSE
                          UPDATE T_SO_HEADER H SET H.ERP_LOGIST_HEADER_ID = N_HEADER_ID where H.SO_NUM = C_INTF_REPEAT.RECEIPT_NUMBER;  
                     END IF;    
                  END IF;     
                        
             END IF;  
          
       COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          --出错则记录异常
          S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_IO_ERP.P_RESET_ALL_INTF', NULL, C_INTF_REPEAT.TRX_ID || ':' || SQLERRM);
      END;
    END LOOP;
  
    --循环取出要重置状态的内容（接口处理出错，由于历史数据存在无效信息，需取2016年3月起的数据）
    FOR C_INTF IN
    (
      SELECT
        ID
        ,UPDATESQL
      FROM
        V_AR_INTF_RESET
      WHERE
        INTF_STATUS = 'E'
        AND POST_DATE >= TO_DATE('2016-03-01','YYYY-MM-DD')
    )
    LOOP
      --执行重置SQL
      BEGIN
        --打开光标
        N_CUR := DBMS_SQL.OPEN_CURSOR;
        --解析动态SQL语句
        DBMS_SQL.PARSE(N_CUR, C_INTF.UPDATESQL, DBMS_SQL.NATIVE);
        --执行语句
        N_ROW := DBMS_SQL.EXECUTE(N_CUR);
        --关闭光标
        DBMS_SQL.CLOSE_CURSOR(N_CUR);
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          --出错则记录异常
          S_MSG := PKG_BD.F_ADD_ERROR_LOG('PKG_IO_ERP.P_RESET_ALL_INTF', NULL, C_INTF.ID || ':' || SQLERRM);
      END;
    END LOOP;
    
    

  END P_RESET_ALL_INTF;

END PKG_IO_ERP;
/

