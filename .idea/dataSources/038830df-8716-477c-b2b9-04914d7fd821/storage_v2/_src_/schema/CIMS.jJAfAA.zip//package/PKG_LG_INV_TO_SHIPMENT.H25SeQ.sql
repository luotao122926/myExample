create PACKAGE      PKG_LG_INV_TO_SHIPMENT AS

  -----------------------------------------------------------------------------
  --      销售单生成运输合同                                             --
  -----------------------------------------------------------------------------
  PROCEDURE P_LG_CONTRACT_BY_INVNUM(INV_NUM                  IN VARCHAR2,
                                    INV_NUMS                 IN VARCHAR2,
                                    SHIP_WAY                 IN VARCHAR2,
                                    SHIP_TYPE                IN VARCHAR2,
                                    LOAD_VEHICLE_TYPE        IN VARCHAR2,
                                    VENDOR_CDE               IN VARCHAR2,
                                    CONSIGNEE_LOCCDE         IN VARCHAR2, --收货地址
                                    VEHICLE_NUM              IN VARCHAR2,
                                    SHIP_DATE                IN VARCHAR2,
                                    VEHICLE_BRAND_NUM        IN VARCHAR2,
                                    CHAUFFEUR_TEL            IN VARCHAR2,
                                    CHAUFFEUR_IDENTITY_NUM   IN VARCHAR2,
                                    CHAUFFEUR                IN VARCHAR2,
                                    CUSTOMER_CONTACTS        IN VARCHAR2,
                                    CUSTOMER_CONTACTS_PHONES IN Varchar2,
                                    CONSIGNEE_COMPANY_ADDR   IN VARCHAR2,
                                    O_RESULT                 OUT VARCHAR2,
                                    O_RESULT_MSG             OUT VARCHAR2);

  -----------------------------------------------------------------------------
  --      调拨单生成运输合同                                             --
  -----------------------------------------------------------------------------
  PROCEDURE P_LG_CONTRACT_BY_TRSFNUM(TRSF_NUM                 IN VARCHAR2,
                                     TRSF_NUMS                IN VARCHAR2,
                                     SHIP_WAY                 IN VARCHAR2,
                                     SHIP_TYPE                IN VARCHAR2,
                                     LOAD_VEHICLE_TYPE        IN VARCHAR2,
                                     VENDOR_CDE               IN VARCHAR2,
                                     CONSIGNEE_LOCCDE         IN VARCHAR2, --收货地址
                                     VEHICLE_NUM              IN VARCHAR2,
                                     SHIP_DATE                IN VARCHAR2,
                                     VEHICLE_BRAND_NUM        IN VARCHAR2,
                                     CHAUFFEUR_TEL            IN VARCHAR2,
                                     CHAUFFEUR_IDENTITY_NUM   IN VARCHAR2,
                                     CHAUFFEUR                IN VARCHAR2,
                                     CUSTOMER_CONTACTS        IN VARCHAR2,
                                     CUSTOMER_CONTACTS_PHONES IN Varchar2,
                                     CONSIGNEE_COMPANY_ADDR   IN VARCHAR2,
                                     O_RESULT                 OUT VARCHAR2,
                                     O_RESULT_MSG             OUT VARCHAR2);

  -----------------------------------------------------------------------------
  --      获取线路的承运商                                             --
  -----------------------------------------------------------------------------
  PROCEDURE P_LG_CONTRACT_GET_VENDOR(NUM                      IN VARCHAR2,
                                     TYP                      IN VARCHAR2,
                                     CONSIGNEE_LOCCDE         IN VARCHAR2,
                                     O_RESULT                 OUT VARCHAR2,
                                     O_RESULT_MSG             OUT VARCHAR2);

  -----------------------------------------------------------------------------
  --      根据财务单生成运输合同2                                             --
  -----------------------------------------------------------------------------
  PROCEDURE P_LG_CONTRACT_BY_INVNUM2(INV_NUM                  IN VARCHAR2,
                                     INV_NUMS                 IN VARCHAR2,
                                     VENDOR_CDE               IN VARCHAR2,
                                     VEHICLE_NUM              IN VARCHAR2,
                                     VEHICLE_BRAND_NUM        IN VARCHAR2,
                                     CHAUFFEUR_TEL            IN VARCHAR2,
                                     CHAUFFEUR_IDENTITY_NUM   IN VARCHAR2,
                                     CHAUFFEUR                IN VARCHAR2,
                                     O_RESULT                 OUT VARCHAR2,
                                     O_RESULT_MSG             OUT VARCHAR2);

 -----------------------------------------------------------------------------
  --      调拨单生成运输合同                                             --
  -----------------------------------------------------------------------------
  PROCEDURE P_LG_CONTRACT_BY_TRSFNUM2(TRSF_NUM                 IN VARCHAR2,
                                      TRSF_NUMS                IN VARCHAR2,
                                      VENDOR_CDE               IN VARCHAR2,
                                      VEHICLE_NUM              IN VARCHAR2,
                                      VEHICLE_BRAND_NUM        IN VARCHAR2,
                                      CHAUFFEUR_TEL            IN VARCHAR2,
                                      CHAUFFEUR_IDENTITY_NUM   IN VARCHAR2,
                                      CHAUFFEUR                IN VARCHAR2,
                                      O_RESULT                 OUT VARCHAR2,
                                      O_RESULT_MSG             OUT VARCHAR2);

END PKG_LG_INV_TO_SHIPMENT;
/

