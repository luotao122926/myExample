create view V_SALES_ACCOUNT_AMOUNT as
SELECT a.account_amount_id,
          a.entity_id,
          a.customer_id, a.account_id, a.credit_group_id,
          (a.received_amount - a.sales_amount) account_balance,
          (  a.received_amount
           - a.sales_amount
           + a.delaypay_amount
           + a.temp_delaypay_amount
           - a.lock_received_amount
           + a.discount_amount
           + a.freeze_discount_amount
           - a.lock_discount_amount
          ) delivery_amount,
          a.received_amount, a.sales_amount, a.delaypay_amount,
          a.temp_delaypay_amount, a.lock_received_amount,
          (a.discount_amount - a.applied_discount_amount) allowance_balance,
          a.discount_amount, a.applied_discount_amount,
          a.freeze_discount_amount, a.lock_discount_amount, a.dispay_amount,A.FREEZE_DELAY_AMOUNT,--ADD BY 梁颜明 2017-10-11 增加冻结保证金
          a.amount_crtl_flag, a.discont_crtl_flag, b.credit_group_num,
          b.credit_group_name, c.account_code, c.account_name,
          d.customer_code, d.customer_name, e.class_code sales_main_type_code,
          e.class_name sales_main_type_name,
          f.sales_main_type
     FROM t_sales_account_amount a,
          t_credit_group b,
          t_customer_account c,
          t_customer_header d,
          t_bd_item_class e,
          t_credit_category_group_rel f
    WHERE a.entity_id = b.entity_id
      And a.entity_id = c.entity_id
      And a.entity_id = e.entity_id(+)
      And a.credit_group_id = b.credit_group_id
      AND a.account_id = c.account_id
      AND a.customer_id = d.customer_id
      AND a.credit_group_id = f.credit_group_id
      AND e.class_code = f.sales_main_type
/

