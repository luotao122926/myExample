create package PKG_CREDIT_DATA_CUTTING is

  PROCEDURE PRC_CREDIT_INIT(P_ENTITY_ID NUMBER);
  PROCEDURE 客户款项余额切割脚本 ;
  PROCEDURE PRC_CREDIT_AMOUNT_INIT(P_ENTITY_ID NUMBER);
  PROCEDURE 客户组关系切割脚本 ;
  PROCEDURE PRC_CREDIT_CUST_GROUP_INIT(P_ENTITY_ID NUMBER) ;
  PROCEDURE PRC_CREDIT_DATA_CUT(P_ENTITY_ID NUMBER);
  PROCEDURE 铺底核销过程 ;
  Function FUN_GET_AMOUNT_BALANCE(P_ENTITY_ID Number,
                                  P_CUSTOMER_ID Number ,
                                  P_ACCOUNT_ID Number,
                                  P_SALES_MAIN_TYPE Varchar2) Return Number ;
  Function FUN_GET_AMOUNT_BALANCE_GROUP(P_ENTITY_ID Number,
                                        P_CUSTOMER_ID Number ,
                                        P_ACCOUNT_ID Number,
                                        P_CREDIT_GROUP_ID Number) Return Number ;
  Function FUN_GET_AMOUNT_OVERDUE(P_ENTITY_ID Number,
                                  P_CUSTOMER_ID Number ,
                                  P_ACCOUNT_ID Number,
                                  P_SALES_MAIN_TYPE Varchar2) Return Number ;
  Function FUN_GET_AMOUNT_OVERDUE_GROUP(P_ENTITY_ID Number,
                                        P_CUSTOMER_ID Number ,
                                        P_ACCOUNT_ID Number,
                                        P_CREDIT_GROUP_ID Number) Return Number ;
  PROCEDURE PRC_CREDIT_DELAYPAY_PAUSE(P_BILL_ID NUMBER,
                                      p_result Out NUMBER ,
                                      p_err_msg Out Varchar2 ) ;

  PROCEDURE PRC_CREDIT_DELAYPAY_DUE_DATE ;
  PROCEDURE PRC_CREDIT_DELAYPAY_APPLIED ;
  PROCEDURE PRC_CREDIT_DELAYPAY_BADRECORD(row_credit_delaypay t_credit_delaypay%Rowtype,
                                          p_result Out NUMBER ,
                                          p_err_msg Out Varchar2) ;
  PROCEDURE PRC_CREDIT_DELAYPAY_APPLIED_AT ;
  PROCEDURE PRC_CREDIT_DELAYPAY_ACCRUAL(row_credit_delaypay t_credit_delaypay%Rowtype,
                                        p_overdue_days Out Number , --逾期天数
                                        p_Accrual_Amount Out Number , --逾期金额
                                        p_result Out NUMBER ,
                                        p_err_msg Out Varchar2) ;
  PROCEDURE PRC_CREDIT_DELAYPAY_APPLIED_HS ;
  PROCEDURE PRC_CREDIT_DELAYPAY_MAIN ;
end PKG_CREDIT_DATA_CUTTING;
/

