create view V_INV_LOGISTICS_SHIP_TO_PRIV as
SELECT sales_center_id, sales_center_code, sales_center_name, storage_code, storage_name,
          site_code, site_name, active_date, invalid_date, entity_id
     FROM t_inv_logistics_ship_to_priv
/

