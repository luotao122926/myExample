create PACKAGE PKG_INV_ITEM  AS
-------------------------------------------------------------------------------
    /*
    *   创建日期：2016-04-27
    *   创建者：chenyj8
    *   功能说明：JOB每天一次自动遍历产品，更新财务分类码表，更新商用中转财务分类维护表，更新商用中转产品
    */
-------------------------------------------------------------------------------
PROCEDURE P_SYS_INV_ITEM_JOB(
	P_ORGANIZATION_CODE T_INV_ORGANIZATION.ORGANIZATION_CODE%TYPE, --组织编码
	P_RESULT    IN OUT NUMBER, --返回错误ID
    P_ERR_MSG   IN OUT VARCHAR2 --返回错误信息
);

-------------------------------------------------------------------------------
    /*
    *   创建日期：2016-04-27
    *   创建者：chenyj8
    *   功能说明：码表新增
    */
-------------------------------------------------------------------------------
PROCEDURE P_SYS_UP_CODELIST_INSERT(
	P_PRODUCTFINANCIALCLS T_BD_ITEM.PRODUCTFINANCIALCLS%TYPE,--财务分类
	P_RESULT    IN OUT NUMBER, --返回错误ID
    P_ERR_MSG   IN OUT VARCHAR2 --返回错误信息
);

-------------------------------------------------------------------------------
    /*
    *   创建日期：2016-04-27
    *   创建者：chenyj8
    *   功能说明：财务分类表新增
    */
-------------------------------------------------------------------------------
PROCEDURE P_SYS_FINANC_TYPE_INSERT(
	P_ENTITY_ID T_BD_ITEM.ENTITY_ID%TYPE,--主体
	P_PRODUCTFINANCIALCLS T_BD_ITEM.PRODUCTFINANCIALCLS%TYPE,--财务分类
	P_ORGANIZATION_CODE T_INV_ORGANIZATION.ORGANIZATION_CODE%TYPE, --组织编码
	P_RESULT    IN OUT NUMBER, --返回错误ID
    P_ERR_MSG   IN OUT VARCHAR2 --返回错误信息
);

-------------------------------------------------------------------------------
    /*
    *   创建日期：2016-04-27
    *   创建者：chenyj8
    *   功能说明：新增中转产品
    */
-------------------------------------------------------------------------------
PROCEDURE P_SYS_INV_ITEM_INSERT(
	P_BD_ITEM T_BD_ITEM%ROWTYPE,--产品信息
	P_ORGANIZATION_CODE T_INV_ORGANIZATION.ORGANIZATION_CODE%TYPE, --组织编码
	P_RESULT    IN OUT NUMBER, --返回错误ID
    P_ERR_MSG   IN OUT VARCHAR2 --返回错误信息
);

END PKG_INV_ITEM;
/

