create Package Body      Pkg_Pln_Job Is

  -- Private type declarations
  v_Nl      Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Null    Constant Varchar2(4) := 'NULL'; --空值
  v_True    Constant Varchar2(2) := 'Y';
  v_False   Constant Varchar2(2) := 'N';
  v_Result  Constant Number := 0; --成功返回
  v_Success Constant Varchar2(10) := 'SUCCESS';
  v_Failure Constant Varchar2(10) := 'FAILURE';
  
  V_PUSH_STATE_CENTER_CHECK CONSTANT VARCHAR2(100) := '中心评审';
  V_PUSH_STATE_INV_AFFIRM CONSTANT VARCHAR2(100) := '库存评审';
  V_PUSH_STATE_PRODUCE CONSTANT VARCHAR2(100) := '已排产';
  V_PUSH_STATE_PLN_AFFIRM CONSTANT VARCHAR2(100) := '发货评审';
  V_PUSH_STATE_SHIP_AFFIRM CONSTANT VARCHAR2(100) := '发货确认';
  V_PUSH_STATE_REJECT CONSTANT VARCHAR2(100) := '驳回';
  V_PUSH_STATE_CLOSED CONSTANT VARCHAR2(100) := '关闭';

  ------------------------------------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2016-06-06 10:51:13
  -- Purpose : 产能可视已处理完成但产能不满足订单申请，用户未及时处理的单据系统第间隔8分钟执行一次
  ------------------------------------------------------------------------------------------------
  Procedure p_Aps_Capacity_Insufficient_j(p_Entity_Id Number) Is
    v_Capacity_Reject_No_Satisfied Varchar2(32);
    Cursor c_Get_Lg_Order Is
      Select h.Order_Head_Id, h.Order_Number
        From Cims.t_Pln_Lg_Order_Head h
       Where (Select Count(1)
                From Cims.t_Pln_Lg_Order_Line Lol
               Where Lol.Order_Head_Id = h.Order_Head_Id
                 And Lol.To_Aps_Capacity_Qty Is Not Null) =
             (Select Count(1)
                From Cims.t_Pln_Lg_Order_Line Lol
               Where Lol.Order_Head_Id = h.Order_Head_Id
                 And Lol.Aps_Capacity_Rec_Date Is Not Null)
         And h.Order_Head_State = 2225
         And h.Aps_Capacity_State = 'S'
         And h.Entity_Id = p_Entity_Id;
    r_Get_Lg_Order c_Get_Lg_Order%Rowtype;
    v_Result       Varchar2(3000);
  Begin
    v_Result := v_Success;
    --add by lizhen 2016-05-20
    --APS产能可视处理完成，用户未及时处理时系统自动处理时动作
    Begin
      v_Capacity_Reject_No_Satisfied := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_REJECT_NO_SATISFIED',
                                                                     p_Entity_Id);
    Exception
      When Others Then
        v_Capacity_Reject_No_Satisfied := '驳回';
    End;
  
    Open c_Get_Lg_Order;
    Loop
      Fetch c_Get_Lg_Order
        Into r_Get_Lg_Order;
      Exit When c_Get_Lg_Order%Notfound;
      v_Result := '系统驳回';
      Pkg_Pln_Lg_Order.p_Back_Or_Close_Order(p_Order_Head_Id    => r_Get_Lg_Order.Order_Head_Id,
                                             p_Operation_Action => v_Capacity_Reject_No_Satisfied,
                                             p_User_Code        => 'db_job',
                                             p_Result           => v_Result);
      If v_Result <> v_Success Then
        Rollback;
        Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                    p_Procedure_Name       => 'p_Aps_Capacity_Insufficient_J',
                                    p_Error_Msg            => '产能可视已处理完成数据，用户未及时处理的单据，系统后台处理！' ||
                                                              v_Result,
                                    p_Source_Order_Head_Id => r_Get_Lg_Order.Order_Head_Id,
                                    p_Source_Order_Line_Id => Null,
                                    p_Item_Id              => Null,
                                    p_Inventory_Id         => Null,
                                    p_Quantity             => Null);
        Commit;
      End If;
    
      If v_Result = v_Success Then
        Commit;
        Pkg_Pln_Intf_Ccs.p_Submit_Aps_Capacity_Request(p_Lg_Order_Head_Id => r_Get_Lg_Order.Order_Head_Id,
                                                       p_Result           => v_Result);
        If v_Result <> v_Success Then
          Rollback;
          Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                      p_Procedure_Name       => 'p_Aps_Capacity_Insufficient_J',
                                      p_Error_Msg            => '产能可视已处理完成数据，用户未及时处理的单据，系统后台处理！' ||
                                                                v_Result,
                                      p_Source_Order_Head_Id => r_Get_Lg_Order.Order_Head_Id,
                                      p_Source_Order_Line_Id => Null,
                                      p_Item_Id              => Null,
                                      p_Inventory_Id         => Null,
                                      p_Quantity             => Null);
          Commit;
        Else
          Commit;
        End If;
      End If;
    End Loop;
    Close c_Get_Lg_Order;
  Exception
    When Others Then
      Null;
  End;
  
  ------------------------------------------------------------------------------------------------
  -- Author  : hejy3
  -- Created : 2016-09-14
  -- Purpose : 提货订单APS承诺日期回写
  ------------------------------------------------------------------------------------------------
  Procedure p_Upd_Pln_Lg_Order_Date(p_Entity_Id NUMBER DEFAULT -1)
  IS
    V_LAST_UPDATE_TIME DATE;
    V_EXPECTED_ARRIVAL_DATE DATE;
    V_CURRENT_TIME DATE;
    V_DEFAULT_ONWAY_DAY NUMBER;
    V_ENTITY_ID NUMBER;
  BEGIN
    V_CURRENT_TIME := SYSDATE;
    --获取上次更新时间
    BEGIN
      SELECT TO_DATE(pkg_bd.F_GET_PARAMETER_VALUE('PLN_UPDATE_LG_DATE_TIME',
                                                  NULL,
                                                  NULL,
                                                  NULL),
                     'YYYY-MM-DD HH24:MI:SS')
        INTO V_LAST_UPDATE_TIME
        FROM dual;
    EXCEPTION
      WHEN OTHERS THEN
        V_LAST_UPDATE_TIME := V_LAST_UPDATE_TIME - 1;
    END;
    
    FOR RE IN (SELECT * FROM V_BD_ENTITY E WHERE (E.entity_id = p_Entity_Id OR p_Entity_Id = -1)) LOOP
      V_ENTITY_ID := re.entity_id;
      
      --取默认在途天数
      BEGIN
        SELECT TO_NUMBER(pkg_bd.F_GET_PARAMETER_VALUE('PLN_LG_DEFAULT_ONWAY_DAY',
                                                      V_ENTITY_ID,
                                                      NULL,
                                                      NULL))
          INTO V_DEFAULT_ONWAY_DAY
          FROM dual;
      EXCEPTION
        WHEN OTHERS THEN
          V_DEFAULT_ONWAY_DAY := 7;
      END;
      
      FOR RO IN (
        SELECT H.ORDER_HEAD_ID, H.CONSIGNMENT_DATE
          FROM T_PLN_LG_ORDER_HEAD H
         WHERE H.ENTITY_ID = V_ENTITY_ID
           AND EXISTS (SELECT 1
                  FROM T_PLN_ORDER_TYPE T
                 WHERE T.ORDER_TYPE_ID = H.ORDER_TYPE_ID
                   AND T.SOURCE_ORDER_TYPE_ID = 1) --提货订单
           --上次更新时间后有更新过的提货订单
           AND EXISTS (SELECT 1
                  FROM T_PLN_LG_ORDER_LINE L
                 WHERE L.ORDER_HEAD_ID = H.ORDER_HEAD_ID
                   AND L.LAST_UPDATE_DATE >= V_LAST_UPDATE_TIME
                   AND L.LAST_UPDATE_DATE <= V_CURRENT_TIME)
           --不存在订单数量-中心库评量-总部库评量-转T+3数量-取消数量>0的订单行
           AND NOT EXISTS
         (SELECT 1
                  FROM T_PLN_LG_ORDER_LINE OL
                 WHERE OL.ORDER_HEAD_ID = H.ORDER_HEAD_ID
                   AND OL.QUANTITY - NVL(OL.CENTER_AFFIRMED_QTY, 0) -
                       NVL(OL.HQ_AFFIRMED_QTY, 0) - NVL(OL.TO_PLN_QTY, 0) -
                       NVL(OL.CANCEL_QTY, 0) > 0)
           AND NVL(H.APS_PROMISE_DATE, TRUNC(SYSDATE)-360) <> (SELECT MAX(LOL.APS_PROMISE_DATE)
                                                             FROM T_PLN_LG_ORDER_LINE LOL
                                                            WHERE LOL.ORDER_HEAD_ID = H.ORDER_HEAD_ID)
      ) LOOP
        --承诺日期
        UPDATE T_PLN_LG_ORDER_HEAD H
           SET H.APS_PROMISE_DATE = (SELECT MAX(LOL.APS_PROMISE_DATE)
                                       FROM T_PLN_LG_ORDER_LINE LOL
                                      WHERE LOL.ORDER_HEAD_ID = H.ORDER_HEAD_ID),
               H.LAST_UPDATE_DATE = SYSDATE,
               H.VERSION = NVL(H.VERSION, 0) + 1
         WHERE H.ORDER_HEAD_ID = RO.ORDER_HEAD_ID;
        
        --预计到货日期
        BEGIN
          SELECT NVL(DECODE(H.PROD_AREA_ID,
                            NULL,
                            --订单头的产地为空，则按行的产地取最长的线路在途天数
                            (SELECT MAX(H.APS_PROMISE_DATE +
                                        NVL((SELECT TLL.scatte_transport_days
                                               FROM Table(pkg_pln_report.f_Get_Lg_Transport_Line_New(pa.district_code, h.consignee_addr_code, h.entity_id)) tll), V_DEFAULT_ONWAY_DAY))
                               FROM T_PLN_LG_ORDER_LINE L,
                                    T_PLN_PRODUCING_AREA PA
                              WHERE L.ORDER_HEAD_ID = H.ORDER_HEAD_ID
                                AND L.PRODUCING_AREA_ID = PA.PRODUCING_AREA_ID),
                            --订单头的产地不为空，则按头的产地取线路在途天数
                            (SELECT H.APS_PROMISE_DATE +
                                    NVL((SELECT TL.scatte_transport_days FROM
                                          Table(pkg_pln_report.f_Get_Lg_Transport_Line_New(a.district_code, h.consignee_addr_code, h.entity_id)) tl), V_DEFAULT_ONWAY_DAY)
                               --FROM T_PLN_PRODUCING_AREA A
                               FROM T_PLN_PRODUCTION_BASE A
                              WHERE A.PROD_AREA_ID = h.prod_area_id)), H.CONSIGNMENT_DATE)
            INTO V_EXPECTED_ARRIVAL_DATE
            FROM T_PLN_LG_ORDER_HEAD H
           WHERE H.ORDER_HEAD_ID = RO.ORDER_HEAD_ID;
        EXCEPTION
          WHEN OTHERS THEN
            V_EXPECTED_ARRIVAL_DATE := RO.CONSIGNMENT_DATE;
        END;
        
        --取最大值
        UPDATE T_PLN_LG_ORDER_HEAD H
           SET H.EXPECTED_ARRIVAL_DATE = GREATEST(H.CONSIGNMENT_DATE, V_EXPECTED_ARRIVAL_DATE)
         WHERE H.ORDER_HEAD_ID = RO.ORDER_HEAD_ID;
      END LOOP;
      
      --有齐套号：取最大的预计到货日期
      UPDATE T_PLN_LG_ORDER_HEAD H
       SET H.EXPECTED_ARRIVAL_DATE =
           (SELECT MAX(OH.EXPECTED_ARRIVAL_DATE)
              FROM T_PLN_LG_ORDER_HEAD OH
             WHERE OH.CARLOAD_MEET_NUM = H.CARLOAD_MEET_NUM)
     WHERE H.ENTITY_ID = V_ENTITY_ID
       AND H.CARLOAD_MEET_NUM IS NOT NULL
       and exists (SELECT 1 FROM cims.T_PLN_LG_ORDER_HEAD OH 
              WHERE OH.CARLOAD_MEET_NUM = H.CARLOAD_MEET_NUM
                and OH.ENTITY_ID = V_ENTITY_ID
                and OH.EXPECTED_ARRIVAL_DATE > H.EXPECTED_ARRIVAL_DATE);
    END LOOP;
    
    UPDATE T_BD_PARAM_LIST L
       SET L.DEFAULT_VALUE = TO_CHAR(V_CURRENT_TIME, 'YYYY-MM-DD HH24:MI:SS')
     WHERE L.PARAM_CODE = 'PLN_UPDATE_LG_DATE_TIME';
  EXCEPTION
    WHEN OTHERS THEN
      Rollback;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'p_Upd_Pln_Lg_Order_Date',
                                  p_Error_Msg            => '更新提货订单头日期！' || sqlerrm,
                                  p_Source_Order_Head_Id => NULL,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
      Commit;
  END p_Upd_Pln_Lg_Order_Date;
  
  ------------------------------------------------------------------------------------------------
  -- Author  : hejy3
  -- Created : 2016-11-03
  -- Purpose : 获取提货订单物流发货数量，每晚执行
  ------------------------------------------------------------------------------------------------
  Procedure p_Get_Pln_Lg_Ship_Qty(p_Entity_Id IN NUMBER DEFAULT -1)
  IS
    v_msg varchar2(1000);
  BEGIN
    --发货通知单、开单数据
    v_msg := pkg_bd.F_ADD_ERROR_LOG('Pkg_Pln_Job.p_Get_Pln_Lg_Ship_Qty','000000','删除物流发货冻结表数据开始:'||to_char(p_Entity_Id));
    --删除原表数据
    DELETE FROM T_PLN_LG_SHIP_DOC_RPT R
     WHERE 1 = 1
       AND (R.ENTITY_ID = P_ENTITY_ID OR P_ENTITY_ID = -1);
    v_msg := pkg_bd.F_ADD_ERROR_LOG('Pkg_Pln_Job.p_Get_Pln_Lg_Ship_Qty','000000','删除物流发货冻结表数据结束:'||to_char(p_Entity_Id));
    
    v_msg := pkg_bd.F_ADD_ERROR_LOG('Pkg_Pln_Job.p_Get_Pln_Lg_Ship_Qty','000000','冻结物流发货数据开始:'||to_char(p_Entity_Id));
    --获取前一天数据
    INSERT INTO T_pln_lg_ship_doc_rpt
      (Entity_Id,
       Origin_Type,
       Origin_Order_Id,
       Origin_Order_Num,
       Origin_Line_Id,
       First_Check_Qty,
       First_Check_Date,
       Last_Check_Qty,
       Last_Check_Date,
       TOTAL_CHECK_QTY,
       Review_Cancel_Qty,
       Doc_Date,
       Ship_Doc_Qty,
       Fact_Ship_Qty,
       Ship_Doc_Cancel_Qty,
       VEHICLE_NUM,
       So_Date,
       Finance_Qty,
       Finance_Decompose_Qty,
       Receive_Date,
       Received_Qty,
       ship_doc_code,
       ship_inv_name,
       so_num,
       so_line_received_qty,
       min_so_date,
       max_so_date,
       min_receive_date,
       max_receive_date,
       Creation_Date)
     SELECT entity_id,
           Origin_Type,
           Origin_Order_Id,
           Origin_Order_Num,
           Origin_Line_Id,
           SUM(FIRST_CHECK_QTY) FIRST_CHECK_QTY,
           MIN(CHECK_DATE) FIRST_CHECK_DATE,
           SUM(LAST_CHECK_QTY) LAST_CHECK_QTY,
           MAX(CHECK_DATE) LAST_CHECK_DATE,
           SUM(TOTAL_CHECK_QTY) TOTAL_CHECK_QTY,
           SUM(REVIEW_CANCEL_QTY) REVIEW_CANCEL_QTY,
           max(doc_date) doc_date,
           SUM(SHIP_DOC_QTY) SHIP_DOC_QTY,
           Sum(Fact_Ship_Qty) Fact_Ship_Qty,
           SUM(SHIP_DOC_CANCEL_QTY) SHIP_DOC_CANCEL_QTY,
           --substrb(to_char(wm_concat(Vehicle_Num)),1,4000) Vehicle_Num,
           DBMS_LOB.SUBSTR(wm_concat(Vehicle_Num),3000,1) Vehicle_Num,
           MAX(so_date) so_date,
           SUM(FINANCE_QTY) FINANCE_QTY,
           SUM(FINANCE_DECOMPOSE_QTY) FINANCE_DECOMPOSE_QTY,
           MAX(receive_date) receive_date,
           SUM(received_qty) received_qty,
           --to_char(wm_concat(ship_doc_code)) ship_doc_code,
           DBMS_LOB.SUBSTR(wm_concat(ship_doc_code),3000,1) ship_doc_code,
           --substrb(to_char(wm_concat(ship_inv_name)),1,4000) ship_inv_name,
           DBMS_LOB.SUBSTR(wm_concat(ship_inv_name),1000,1) ship_inv_name,
           --substrb(to_char(wm_concat(decode(So_Num, null, null, So_Num || '【' || To_Char(So_Date, 'YYYY-MM-DD') || '】'))),1,4000) So_Num,
           DBMS_LOB.SUBSTR(wm_concat(decode(So_Num, null, null, So_Num || '【' || To_Char(So_Date, 'YYYY-MM-DD') || '】')),3000,1) So_Num,
           sum(so_line_received_qty) so_line_received_qty,
           min(so_date) min_so_date,
           max(so_date) max_so_date,
           min(receive_date) min_receive_date,
           max(receive_date) max_receive_date,
           SYSDATE
      From (--评审明细
            SELECT i.entity_id,
                   '02' Origin_Type,
                   I.ORIGIN_ORDER_HEAD_ID Origin_Order_Id,
                   I.ORDER_NUMBER Origin_Order_Num,
                   I.ORIGIN_ORDER_LINE_ID Origin_Line_Id,
                   I.HQ_DATE CHECK_DATE,
                   DECODE(I.LOT_NUM, 1, I.AFFIRM_QTY, NULL) FIRST_CHECK_QTY,
                   DECODE(I.LOT_NUM, (MAX(SIGN(I.AFFIRM_QTY)*I.LOT_NUM) OVER (PARTITION BY I.ORIGIN_ORDER_LINE_ID)), I.AFFIRM_QTY, NULL) LAST_CHECK_QTY,
                   DECODE(SIGN(I.AFFIRM_QTY), 1, I.AFFIRM_QTY, 0) total_check_qty,
                   DECODE(SIGN(I.AFFIRM_QTY), -1, ABS(I.AFFIRM_QTY), NULL) REVIEW_CANCEL_QTY,
                   NULL doc_date,
                   0 SHIP_DOC_QTY,
                   0 fact_ship_qty,
                   0 SHIP_DOC_CANCEL_QTY,
                   NULL so_date,
                   0 FINANCE_QTY,
                   0 FINANCE_DECOMPOSE_QTY,
                   NULL receive_date,
                   0 received_qty,
                   NULL Vehicle_Num,
                   null ship_doc_code,
                   null ship_inv_name,
                   null so_num,
                   0 so_line_received_qty
              FROM CIMS.t_Pln_Order_Review_Info I
             WHERE trunc(I.CREATION_DATE) <= TRUNC(SYSDATE)-1
               and (i.entity_id = p_Entity_Id or p_Entity_Id = -1)
            UNION ALL
            --来源计划发货提货订单的发货通知单
            SELECT lsd.entity_id,
                   Sdl.Origin_Origin_Type     Origin_Type,
                   Sdl.Origin_Origin_Head_Id  Origin_Order_Id,
                   Sdl.Origin_Origin_Doc_Code Origin_Order_Num,
                   Sdl.Origin_Origin_Line_Id  Origin_Line_Id,
                   NULL CHECK_DATE,
                   NULL FIRST_CHECK_QTY,
                   NULL LAST_CHECK_QTY,
                   0 total_check_qty,
                   NULL REVIEW_CANCEL_QTY,
                   lsd.doc_date,
                   Nvl(Sdl.Item_Qty, 0) - nvl(sdl.cancel_qty, 0) SHIP_DOC_QTY,
                   NVL(sdl.fact_ship_qty, 0) fact_ship_qty,
                   NVL(sdl.cancel_qty, 0) SHIP_DOC_CANCEL_QTY,
                   NULL so_date,
                   0 FINANCE_QTY,
                   0 FINANCE_DECOMPOSE_QTY,
                   NULL receive_date,
                   0 received_qty,
                   NULL Vehicle_Num,
                   lsd.ship_doc_code,
                   lsd.ship_inventory_name,
                   null so_num,
                   0 so_line_received_qty
              From Cims.t_Lg_Ship_Doc_Line Sdl, Cims.t_Lg_Ship_Doc Lsd
             Where Sdl.Ship_Doc_Id = Lsd.Ship_Doc_Id
               AND trunc(lsd.creation_date) <= TRUNC(SYSDATE)-1
               And Sdl.Origin_Origin_Type = '02'
               And Lsd.Doc_Status = '00'
               and (lsd.entity_id = p_Entity_Id or p_Entity_Id = -1)
            Union ALL
            --来源库存评审提货订单的发货通知单
            SELECT lsd.entity_id,
                   Sdl.Origin_Type,
                   Sdl.Origin_Order_Id,
                   Sdl.Origin_Order_Num,
                   Sdl.Origin_Line_Id,
                   NULL CHECK_DATE,
                   NULL FIRST_CHECK_QTY,
                   NULL LAST_CHECK_QTY,
                   0 total_check_qty,
                   NULL REVIEW_CANCEL_QTY,
                   lsd.doc_date,
                   Nvl(Sdl.Item_Qty, 0) - nvl(sdl.cancel_qty, 0) SHIP_DOC_QTY,
                   NVL(sdl.fact_ship_qty, 0) fact_ship_qty,
                   NVL(sdl.cancel_qty, 0) SHIP_DOC_CANCEL_QTY,
                   NULL so_date,
                   0 FINANCE_QTY,
                   0 FINANCE_DECOMPOSE_QTY,
                   NULL receive_date,
                   0 received_qty,
                   NULL Vehicle_Num,
                   lsd.ship_doc_code,
                   lsd.ship_inventory_name,
                   null so_num,
                   0 so_line_received_qty
              From Cims.t_Lg_Ship_Doc_Line Sdl, Cims.t_Lg_Ship_Doc Lsd
             Where Sdl.Ship_Doc_Id = Lsd.Ship_Doc_Id
               AND trunc(lsd.creation_date) <= TRUNC(SYSDATE)-1
               And Lsd.Doc_Status = '00'
               AND Sdl.Origin_Type = '02'
               and (lsd.entity_id = p_Entity_Id or p_Entity_Id = -1)
            Union All
            --来源计划发货提货订单的发运计划
            SELECT lsp.entity_id,
                   lsp.origin_type,
                   lsp.origin_order_id,
                   lsp.origin_order_num,
                   lsp.origin_line_id,
                   NULL CHECK_DATE,
                   NULL FIRST_CHECK_QTY,
                   NULL LAST_CHECK_QTY,
                   0 total_check_qty,
                   NULL REVIEW_CANCEL_QTY,
                   NULL doc_date,
                   nvl(lsp.item_qty, 0) SHIP_DOC_QTY,
                   0 fact_ship_qty,
                   0 SHIP_DOC_CANCEL_QTY,
                   NULL so_date,
                   0 FINANCE_QTY,
                   0 FINANCE_DECOMPOSE_QTY,
                   NULL receive_date,
                   0 received_qty,
                   NULL Vehicle_Num,
                   null ship_doc_code,
                   null ship_inv_name,
                   null so_num,
                   0 so_line_received_qty
              From Cims.t_Lg_Ship_Plan Lsp
             Where Lsp.Status In ('00', '01')
               AND trunc(lsp.creation_date) <= TRUNC(SYSDATE)-1
               AND Lsp.Origin_Type = '02'
               and (lsp.entity_id = p_Entity_Id or p_Entity_Id = -1)
            UNION ALL
            --来源库存评审提货订单的发运计划
            SELECT lsp.entity_id,
                   lsp.origin_origin_type,
                   lsp.origin_origin_head_id,
                   lsp.origin_origin_order_code,
                   lsp.origin_origin_line_id,
                   NULL CHECK_DATE,
                   NULL FIRST_CHECK_QTY,
                   NULL LAST_CHECK_QTY,
                   0 total_check_qty,
                   NULL REVIEW_CANCEL_QTY,
                   NULL doc_date,
                   nvl(lsp.item_qty, 0) SHIP_DOC_QTY,
                   0 fact_ship_qty,
                   0 SHIP_DOC_CANCEL_QTY,
                   NULL so_date,
                   0 FINANCE_QTY,
                   0 FINANCE_DECOMPOSE_QTY,
                   NULL receive_date,
                   0 received_qty,
                   NULL Vehicle_Num,
                   null ship_doc_code,
                   null ship_inv_name,
                   null so_num,
                   0 so_line_received_qty
              From Cims.t_Lg_Ship_Plan Lsp
             Where Lsp.Status In ('00', '01')
               AND trunc(lsp.creation_date) <= TRUNC(SYSDATE)-1
               AND Lsp.Origin_Origin_Type = '02'
               and (lsp.entity_id = p_Entity_Id or p_Entity_Id = -1)
            UNION ALL
            --最原始的来源类型标识：用于记录单据最开始的来源，主要用于解决F红冲单触发生成折让红冲单等情况，
            --01计划订单 02提货订单 03调拨订单
            --04促销品 09采购单据 10调拨单据
            --11备货单据 12财务单据 13退货申请 14F单 15电商
            --来源计划发货提货订单的销售单
            SELECT tsh.entity_id,
                   Tsh.Origin_Origin_Type Raw_Src_Type,
                   Tsh.Origin_Origin_Head_Id Raw_Src_Bill_Id,
                   Tsh.Origin_Origin_Order_Code Raw_Src_Bill_Num,
                   Tsl.Lg_Order_Head_Line_Id Raw_Src_Line_Id,
                   NULL CHECK_DATE,
                   NULL FIRST_CHECK_QTY,
                   NULL LAST_CHECK_QTY,
                   0 total_check_qty,
                   NULL REVIEW_CANCEL_QTY,
                   NULL doc_date,
                   0 SHIP_DOC_QTY,
                   0 fact_ship_qty,
                   0 SHIP_DOC_CANCEL_QTY,
                   tsh.so_date,
                   DECODE((rank() Over(Partition By tsl.Lg_Order_Head_Line_Id, tsl.so_line_id Order By sld.so_line_detail_id)), 1, tsl.item_qty, 0) FINANCE_QTY,
                   Ste.Applied_Plus_Minus_Flag * sld.component_qty FINANCE_DECOMPOSE_QTY,
                   tsh.receive_date,
                   decode(tsh.biz_src_bill_type_id,1,nvl(tsl.received_qty,0),0) received_qty,
                   NULL Vehicle_Num,
                   null ship_doc_code,
                   null ship_inv_name,
                   DECODE((rank() Over(Partition By tsl.Lg_Order_Head_Line_Id, tsl.so_line_id Order By sld.so_line_detail_id)), 1, tsh.so_num, null) so_num,
                   DECODE((rank() Over(Partition By tsl.Lg_Order_Head_Line_Id, tsl.so_line_id Order By sld.so_line_detail_id)), 1, tsl.received_qty, 0) so_line_received_qty
              From Cims.t_So_Header      Tsh,
                   Cims.t_So_Line        Tsl,
                   Cims.t_So_Line_Detail Sld,
                   Cims.v_So_Bill_Type   Sbt,
                   Cims.t_So_Type_Extend Ste
             Where Tsh.So_Header_Id = Tsl.So_Header_Id
               And Tsh.So_Header_Id = Sld.So_Header_Id
               And Tsl.So_Line_Id = Sld.So_Line_Id
               And Sbt.Bill_Type_Id = Tsh.Bill_Type_Id
               And Tsh.Origin_Origin_Type = '02'
               AND trunc(tsh.creation_date) <= TRUNC(SYSDATE)-1
               And Ste.Bill_Type_Id = Tsh.Bill_Type_Id
               and (tsh.entity_id = p_Entity_Id or p_Entity_Id = -1)
            UNION ALL
            --来源库存评审提货订单的销售单
            SELECT tsh.entity_id,
                   Tsh.Raw_Src_Type,
                   Tsh.Raw_Src_Bill_Id,
                   Tsh.Raw_Src_Bill_Num,
                   Tsl.Raw_Src_Line_Id,
                   NULL CHECK_DATE,
                   NULL FIRST_CHECK_QTY,
                   NULL LAST_CHECK_QTY,
                   0 total_check_qty,
                   NULL REVIEW_CANCEL_QTY,
                   NULL doc_date,
                   0 SHIP_DOC_QTY,
                   0 fact_ship_qty,
                   0 SHIP_DOC_CANCEL_QTY,
                   tsh.so_date,
                   DECODE((rank() Over(Partition By tsl.Lg_Order_Head_Line_Id, tsl.so_line_id Order By sld.so_line_detail_id)), 1, tsl.item_qty, 0) FINANCE_QTY,
                   Ste.Applied_Plus_Minus_Flag * sld.component_qty FINANCE_DECOMPOSE_QTY,
                   tsh.receive_date,
                   decode(tsh.biz_src_bill_type_id,1,nvl(tsl.received_qty,0),0) received_qty,
                   NULL Vehicle_Num,
                   null ship_doc_code,
                   null ship_inv_name,
                   DECODE((rank() Over(Partition By tsl.Lg_Order_Head_Line_Id, tsl.so_line_id Order By sld.so_line_detail_id)), 1, tsh.so_num, null) so_num,
                   DECODE((rank() Over(Partition By tsl.Lg_Order_Head_Line_Id, tsl.so_line_id Order By sld.so_line_detail_id)), 1, tsl.received_qty, 0) so_line_received_qty
              From Cims.t_So_Header      Tsh,
                   Cims.t_So_Line        Tsl,
                   Cims.t_So_Line_Detail Sld,
                   Cims.v_So_Bill_Type   Sbt,
                   Cims.t_So_Type_Extend Ste
             Where Tsh.So_Header_Id = Tsl.So_Header_Id
               And Tsh.So_Header_Id = Sld.So_Header_Id
               And Tsl.So_Line_Id = Sld.So_Line_Id
               And Sbt.Bill_Type_Id = Tsh.Bill_Type_Id
               And Tsh.Raw_Src_Type = '02'
               AND trunc(tsh.creation_date) <= TRUNC(SYSDATE)-1
               And Ste.Bill_Type_Id = Tsh.Bill_Type_Id
               and (tsh.entity_id = p_Entity_Id or p_Entity_Id = -1)
            UNION ALL
            --来源库存评审的备货提货订单
            SELECT o.entity_id,
                   o.orig_order_type,
                   o.orig_order_id,
                   o.orig_order_num,
                   l.order_line_id_orig,
                   NULL CHECK_DATE,
                   NULL FIRST_CHECK_QTY,
                   NULL LAST_CHECK_QTY,
                   0 total_check_qty,
                   NULL REVIEW_CANCEL_QTY,
                   NULL doc_date,
                   0 SHIP_DOC_QTY,
                   0 fact_ship_qty,
                   0 SHIP_DOC_CANCEL_QTY,
                   o.billed_date,
                   l.billed_qty FINANCE_QTY,
                   l.billed_qty FINANCE_DECOMPOSE_QTY,
                   o.rcv_date receive_date,
                   nvl(l.rcv_qty, 0) + nvl(l.damaged_qty, 0) received_qty,
                   NULL Vehicle_Num,
                   null ship_doc_code,
                   null ship_inv_name,
                   o.trsf_order_num,
                   nvl(l.rcv_qty, 0) + nvl(l.damaged_qty, 0) received_qty
              FROM T_INV_TRSF_ORDER O, T_INV_TRSF_ORDER_LINE L
             WHERE O.TRSF_ORDER_ID = L.TRSF_ORDER_ID
               AND O.ORIG_ORDER_TYPE = '02'
               and o.trsf_order_status = '13' --已接收
               AND o.creation_date < trunc(sysdate)
               and (o.entity_id = p_Entity_Id or p_Entity_Id = -1)
            UNION ALL
            --来源计划订单评审的备货提货订单
            SELECT o.entity_id,
                   '02',
                   l.lg_order_head_id,
                   l.lg_order_number,
                   l.lg_order_line_id,
                   NULL CHECK_DATE,
                   NULL FIRST_CHECK_QTY,
                   NULL LAST_CHECK_QTY,
                   0 total_check_qty,
                   NULL REVIEW_CANCEL_QTY,
                   NULL doc_date,
                   0 SHIP_DOC_QTY,
                   0 fact_ship_qty,
                   0 SHIP_DOC_CANCEL_QTY,
                   o.billed_date,
                   l.billed_qty FINANCE_QTY,
                   l.billed_qty FINANCE_DECOMPOSE_QTY,
                   o.rcv_date receive_date,
                   nvl(l.rcv_qty, 0) + nvl(l.damaged_qty, 0) received_qty,
                   NULL Vehicle_Num,
                   null ship_doc_code,
                   null ship_inv_name,
                   o.trsf_order_num,
                   nvl(l.rcv_qty, 0) + nvl(l.damaged_qty, 0) received_qty
              FROM T_INV_TRSF_ORDER O, T_INV_TRSF_ORDER_LINE L
             WHERE O.TRSF_ORDER_ID = L.TRSF_ORDER_ID
               AND O.ORIG_ORDER_TYPE = '01'
               and l.lg_order_number is not null
               and o.trsf_order_status = '13' --已接收
               AND o.creation_date < trunc(sysdate)
               and (o.entity_id = p_Entity_Id or p_Entity_Id = -1)
            UNION ALL
            --排车号
            Select entity_id,
                   ORIGIN_TYPE,
                   ORIGIN_ORDER_ID,
                   ORIGIN_ORDER_NUM,
                   ORIGIN_LINE_ID,
                   NULL CHECK_DATE,
                   NULL FIRST_CHECK_QTY,
                   NULL LAST_CHECK_QTY,
                   0 TOTAL_CHECK_QTY,
                   NULL REVIEW_CANCEL_QTY,
                   NULL doc_date,
                   0 SHIP_DOC_QTY,
                   0 fact_ship_qty,
                   0 SHIP_DOC_CANCEL_QTY,
                   NULL so_date,
                   0 FINANCE_QTY,
                   0 FINANCE_DECOMPOSE_QTY,
                   NULL receive_date,
                   0 received_qty,
                   Vehicle_Num,
                   null ship_doc_code,
                   null ship_inv_name,
                   null so_num,
                   0 so_line_received_qty
              From (SELECT vi.entity_id,
                           sdl.origin_origin_type ORIGIN_TYPE,
                           Sdl.Origin_Origin_Head_Id ORIGIN_ORDER_ID,
                           sdl.origin_origin_doc_code ORIGIN_ORDER_NUM,
                           sdl.origin_origin_line_id ORIGIN_LINE_ID,
                           Vi.Vehicle_Num
                      From Cims.t_Lg_Vehicle_Info      Vi,
                           Cims.t_Lg_Vehicle_Info_Line Vl,
                           Cims.t_Lg_Ship_Doc_Line     Sdl
                     Where Vi.Vehicle_Info_Id = Vl.Vehicle_Info_Id
                       And Vl.Ship_Doc_Line_Id = Sdl.Ship_Doc_Line_Id
                       And Sdl.Origin_Origin_Type = '02'
                       AND trunc(vi.creation_date) <= TRUNC(SYSDATE)-1
                       and (vi.entity_id = p_Entity_Id or p_Entity_Id = -1)
                    Union All
                    Select vi.entity_id,
                           sdl.origin_type, 
                           Sdl.Origin_Order_Id,
                           sdl.origin_order_num,
                           sdl.origin_line_id,
                           Vi.Vehicle_Num
                      From Cims.t_Lg_Vehicle_Info      Vi,
                           Cims.t_Lg_Vehicle_Info_Line Vl,
                           Cims.t_Lg_Ship_Doc_Line     Sdl
                     Where Vi.Vehicle_Info_Id = Vl.Vehicle_Info_Id
                       And Vl.Ship_Doc_Line_Id = Sdl.Ship_Doc_Line_Id
                       And Sdl.Origin_Type = '02'
                       AND trunc(vi.creation_date) <= TRUNC(SYSDATE)-1
                       and (vi.entity_id = p_Entity_Id or p_Entity_Id = -1))
            )
     where (entity_id = P_ENTITY_ID OR P_ENTITY_ID = -1)
     Group By entity_id, Origin_Type, Origin_Order_Id, Origin_Order_Num, Origin_Line_Id;
    COMMIT;
    v_msg := pkg_bd.F_ADD_ERROR_LOG('Pkg_Pln_Job.p_Get_Pln_Lg_Ship_Qty','000000','冻结物流发货数据结束:'||to_char(p_Entity_Id));
    
    --合同数据
    v_msg := pkg_bd.F_ADD_ERROR_LOG('Pkg_Pln_Job.p_Get_Pln_Lg_Ship_Qty','000000','删除合同冻结表数据开始:'||to_char(p_Entity_Id));
    --删除原表数据
    DELETE FROM t_pln_lg_contract_rpt R
     WHERE 1 = 1
       AND (R.ENTITY_ID = P_ENTITY_ID OR P_ENTITY_ID = -1);
    v_msg := pkg_bd.F_ADD_ERROR_LOG('Pkg_Pln_Job.p_Get_Pln_Lg_Ship_Qty','000000','删除合同冻结表数据结束:'||to_char(p_Entity_Id));
    
    v_msg := pkg_bd.F_ADD_ERROR_LOG('Pkg_Pln_Job.p_Get_Pln_Lg_Ship_Qty','000000','冻结合同数据开始:'||to_char(p_Entity_Id));
    INSERT INTO t_pln_lg_contract_rpt
     (entity_id,
      origin_type,
      origin_order_id,
      origin_order_num,
      origin_line_id,
      ship_doc_line_id,
      contract_code,
      so_contract_code,
      receive_flag,
      fact_ship_date,
      cl_fact_ship_qty,
      total_volume,
      receive_date,
      affirm_qty,
      diff_qty,
      creation_date)
     SELECT ENTITY_ID,
            ORIGIN_TYPE,
            ORIGIN_ORDER_ID,
            ORIGIN_ORDER_NUM,
            ORIGIN_LINE_ID,
            SHIP_DOC_LINE_ID,
            CONTRACT_CODE,
            SO_CONTRACT_CODE,
            RECEIVE_FLAG,
            FACT_SHIP_DATE,
            CL_FACT_SHIP_QTY,
            TOTAL_VOLUME,
            RECEIVE_DATE,
            AFFIRM_QTY,
            DIFF_QTY,
            SYSDATE
       FROM (
         SELECT C.ENTITY_ID,
                CL.ORIGIN_ORIGIN_TYPE ORIGIN_TYPE,
                CL.ORIGIN_ORIGIN_HEAD_ID ORIGIN_ORDER_ID,
                CL.ORIGIN_ORIGIN_DOC_CODE ORIGIN_ORDER_NUM,
                CL.ORIGIN_ORIGIN_LINE_ID ORIGIN_LINE_ID,
                CL.SHIP_DOC_LINE_ID,
                C.CONTRACT_CODE,
                CL.SO_DOC_NUM SO_CONTRACT_CODE,
                C.RECEIVE_FLAG,
                C.FACT_SHIP_DATE,
                MIN(SL.ITEM_QTY) CL_FACT_SHIP_QTY,
                MIN(SL.ITEM_QTY * SL.ITEM_VOLUME) TOTAL_VOLUME,
                C.RECEIVE_DATE,
                MIN(NVL(CL.AFFIRM_QTY, 0) /
                    PKG_PLN_PUB.F_GET_ITEM_ASSEMBLY_BASE(P_ASS_ITEM_ID => SL.ITEM_ID,
                                                         P_SUB_ITEM_ID => SUBBI.ITEM_ID)) AFFIRM_QTY,
                MIN((NVL(CL.Fact_Ship_Qty, 0) - NVL(CL.Fact_Receive_Qty, 0)) /
                    PKG_PLN_PUB.F_GET_ITEM_ASSEMBLY_BASE(P_ASS_ITEM_ID => SL.ITEM_ID,
                                                         P_SUB_ITEM_ID => SUBBI.ITEM_ID)) DIFF_QTY
           FROM CIMS.T_LG_CONTRACT      C,
                CIMS.T_LG_CONTRACT_LINE CL,
                CIMS.T_SO_HEADER        SH,
                CIMS.T_SO_LINE          SL,
                CIMS.T_BD_ITEM          SUBBI
          WHERE C.CONTRACT_ID = CL.CONTRACT_ID
            AND CL.SO_DOC_ID = SH.SO_HEADER_ID
            AND CL.SHIP_DOC_LINE_ID = SL.SHIP_DOC_LINE_ID
            AND SH.SO_HEADER_ID = SL.SO_HEADER_ID
            AND CL.ORIGIN_ORIGIN_TYPE = '02'
            And c.bills_status <> '00'
            AND SUBBI.ITEM_CODE = CL.ITEM_CODE
            AND SUBBI.ENTITY_ID = C.ENTITY_ID
            AND TRUNC(C.CREATION_DATE) <= TRUNC(SYSDATE)-1
            and (c.entity_id = p_Entity_Id or p_Entity_Id = -1)
          GROUP BY C.ENTITY_ID,
                   CL.ORIGIN_ORIGIN_TYPE,
                   CL.ORIGIN_ORIGIN_HEAD_ID,
                   CL.ORIGIN_ORIGIN_DOC_CODE,
                   CL.ORIGIN_ORIGIN_LINE_ID,
                   CL.SHIP_DOC_LINE_ID,
                   C.CONTRACT_CODE,
                   CL.SO_DOC_NUM,
                   C.RECEIVE_FLAG,
                   C.FACT_SHIP_DATE,
                   C.RECEIVE_DATE
         UNION ALL
         SELECT C.ENTITY_ID,
                CL.ORIGIN_TYPE,
                CL.ORIGIN_ORDER_ID,
                CL.ORIGIN_ORDER_NUM,
                CL.ORIGIN_LINE_ID,
                CL.SHIP_DOC_LINE_ID,
                C.CONTRACT_CODE,
                CL.SO_DOC_NUM SO_CONTRACT_CODE,
                C.RECEIVE_FLAG,
                C.FACT_SHIP_DATE,
                MIN(SL.ITEM_QTY) CL_FACT_SHIP_QTY,
                MIN(SL.ITEM_QTY * SL.ITEM_VOLUME) TOTAL_VOLUME,
                C.RECEIVE_DATE,
                MIN(NVL(CL.AFFIRM_QTY, 0) /
                    PKG_PLN_PUB.F_GET_ITEM_ASSEMBLY_BASE(P_ASS_ITEM_ID => SL.ITEM_ID,
                                                         P_SUB_ITEM_ID => SUBBI.ITEM_ID)) AFFIRM_QTY,
                MIN((NVL(CL.Fact_Ship_Qty, 0) - NVL(CL.Fact_Receive_Qty, 0)) /
                    PKG_PLN_PUB.F_GET_ITEM_ASSEMBLY_BASE(P_ASS_ITEM_ID => SL.ITEM_ID,
                                                         P_SUB_ITEM_ID => SUBBI.ITEM_ID)) DIFF_QTY
           FROM CIMS.T_LG_CONTRACT      C,
                CIMS.T_LG_CONTRACT_LINE CL,
                CIMS.T_SO_HEADER        SH,
                CIMS.T_SO_LINE          SL,
                CIMS.T_BD_ITEM          SUBBI
          WHERE C.CONTRACT_ID = CL.CONTRACT_ID
            AND CL.SO_DOC_ID = SH.SO_HEADER_ID
            AND CL.SHIP_DOC_LINE_ID = SL.SHIP_DOC_LINE_ID
            AND SH.SO_HEADER_ID = SL.SO_HEADER_ID
            AND CL.ORIGIN_TYPE = '02'
            And c.bills_status <> '00'
            AND SUBBI.ITEM_CODE = CL.ITEM_CODE
            AND SUBBI.ENTITY_ID = C.ENTITY_ID
            AND TRUNC(C.CREATION_DATE) <= TRUNC(SYSDATE)-1
            and (c.entity_id = p_Entity_Id or p_Entity_Id = -1)
          GROUP BY C.ENTITY_ID,
                   CL.ORIGIN_TYPE,
                   CL.ORIGIN_ORDER_ID,
                   CL.ORIGIN_ORDER_NUM,
                   CL.ORIGIN_LINE_ID,
                   CL.SHIP_DOC_LINE_ID,
                   C.CONTRACT_CODE,
                   CL.SO_DOC_NUM,
                   C.RECEIVE_FLAG,
                   C.FACT_SHIP_DATE,
                   C.RECEIVE_DATE
         UNION ALL
         --转过T+3的自提
         SELECT SH.ENTITY_ID,
                SH.ORIGIN_ORIGIN_TYPE ORIGIN_TYPE,
                SH.ORIGIN_ORIGIN_HEAD_ID ORIGIN_ORDER_ID,
                SH.ORIGIN_ORIGIN_ORDER_CODE ORIGIN_ORDER_NUM,
                SL.LG_ORDER_HEAD_LINE_ID ORIGIN_LINE_ID,
                SL.SHIP_DOC_LINE_ID,
                NULL CONTRACT_CODE,
                SH.SO_NUM SO_CONTRACT_CODE,
                SH.RECEIVE_FLAG,
                SH.SHIP_DATE FACT_SHIP_DATE,
                (Case
                 When (Sh.Biz_Src_Bill_Type_Code In ('1002')) Then
                  -1
                 Else
                  1
               End) * SL.ITEM_QTY CL_FACT_SHIP_QTY,
                SL.ITEM_QTY * SL.ITEM_VOLUME TOTAL_VOLUME,
                SH.RECEIVE_DATE,
                NULL AFFIRM_QTY,
                NULL DIFF_QTY
           FROM CIMS.T_SO_HEADER SH, CIMS.T_SO_LINE SL
          WHERE SH.SO_HEADER_ID = SL.SO_HEADER_ID
            AND (SH.SELF_PICK_FLAG = 'Y' OR NOT EXISTS (SELECT 1 FROM CIMS.T_LG_CONTRACT_LINE L
                                                 WHERE L.SO_DOC_NUM = SH.SO_NUM
                                                   AND NVL(L.SET_CODE, L.ITEM_CODE) = SL.ITEM_CODE))
            AND SH.ORIGIN_ORIGIN_TYPE = '02'
            AND sh.src_type <> '31'  --排除转采购生成的
            AND TRUNC(SH.CREATION_DATE) <= TRUNC(SYSDATE)-1
            and (sh.entity_id = p_Entity_Id or p_Entity_Id = -1)
         UNION ALL
         --没转T+3
         SELECT SH.ENTITY_ID,
                SH.RAW_SRC_TYPE ORIGIN_TYPE,
                SL.RAW_SRC_HEADER_ID ORIGIN_ORDER_ID,
                SH.RAW_SRC_BILL_NUM ORIGIN_ORDER_NUM,
                SL.RAW_SRC_LINE_ID ORIGIN_LINE_ID,
                SL.SHIP_DOC_LINE_ID,
                NULL CONTRACT_CODE,
                SH.SO_NUM SO_CONTRACT_CODE,
                SH.RECEIVE_FLAG,
                SH.SHIP_DATE FACT_SHIP_DATE,
                (Case
                 When (Sh.Biz_Src_Bill_Type_Code In ('1002')) Then
                  -1
                 Else
                  1
               End) * SL.ITEM_QTY CL_FACT_SHIP_QTY,
                SL.ITEM_QTY * SL.ITEM_VOLUME TOTAL_VOLUME,
                SH.RECEIVE_DATE,
                NULL AFFIRM_QTY,
                NULL DIFF_QTY
           FROM CIMS.T_SO_HEADER SH, CIMS.T_SO_LINE SL
          WHERE SH.SO_HEADER_ID = SL.SO_HEADER_ID
            AND (SH.SELF_PICK_FLAG = 'Y' OR NOT EXISTS (SELECT 1 FROM CIMS.T_LG_CONTRACT_LINE L
                                                 WHERE L.SO_DOC_NUM = SH.SO_NUM
                                                   AND NVL(L.SET_CODE, L.ITEM_CODE) = SL.ITEM_CODE))
            AND SH.RAW_SRC_TYPE = '02'
            AND sh.src_type <> '31'  --排除转采购生成的
            AND TRUNC(SH.CREATION_DATE) <= TRUNC(SYSDATE)-1
            and (sh.entity_id = p_Entity_Id or p_Entity_Id = -1)
          UNION ALL
         --销司转采购
         SELECT SH.ENTITY_ID,
                SH.ORIGIN_ORIGIN_TYPE ORIGIN_TYPE,
                SH.ORIGIN_ORIGIN_HEAD_ID ORIGIN_ORDER_ID,
                SH.ORIGIN_ORIGIN_ORDER_CODE ORIGIN_ORDER_NUM,
                SL.LG_ORDER_HEAD_LINE_ID ORIGIN_LINE_ID,
                SL.SHIP_DOC_LINE_ID,
                NULL CONTRACT_CODE,
                SH.SO_NUM SO_CONTRACT_CODE,
                SH.RECEIVE_FLAG,
                SH.SHIP_DATE FACT_SHIP_DATE,
                (Case
                 When (Sh.Biz_Src_Bill_Type_Code In ('1002')) Then
                  -1
                 Else
                  1
               End) * SL.ITEM_QTY CL_FACT_SHIP_QTY,
                SL.ITEM_QTY * SL.ITEM_VOLUME TOTAL_VOLUME,
                SH.RECEIVE_DATE,
                NULL AFFIRM_QTY,
                NULL DIFF_QTY
           FROM CIMS.T_SO_HEADER SH, CIMS.T_SO_LINE SL
          WHERE SH.SO_HEADER_ID = SL.SO_HEADER_ID
            AND SH.SRC_TYPE = '31'
            AND TRUNC(SH.CREATION_DATE) <= TRUNC(SYSDATE)-1
            and (sh.entity_id = p_Entity_Id or p_Entity_Id = -1)
            )
    WHERE (entity_id = P_ENTITY_ID OR P_ENTITY_ID = -1);
    COMMIT;
    v_msg := pkg_bd.F_ADD_ERROR_LOG('Pkg_Pln_Job.p_Get_Pln_Lg_Ship_Qty','000000','冻结合同数据结束:'||to_char(p_Entity_Id));
  EXCEPTION
    WHEN OTHERS THEN
      Rollback;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'p_Get_Pln_Lg_Ship_Qty',
                                  p_Error_Msg            => '获取提货订单物流发货数量！' || sqlerrm,
                                  p_Source_Order_Head_Id => NULL,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
      Commit;
  END p_Get_Pln_Lg_Ship_Qty;
  
  ------------------------------------------------------------------------------------------------
  -- Author  : hejy3
  -- Created : 2016-12-08
  -- Purpose : 更新订单行和明细行已入库数量不一致的数据
  ------------------------------------------------------------------------------------------------
  Procedure p_Pln_Upd_Supply_Qty_Diff(p_Entity_Id IN NUMBER DEFAULT -1)
  IS
  BEGIN
    UPDATE T_PLN_ORDER_LINE OL
       SET OL.SUPPLY_QTY = (SELECT MIN(NVL(OD.SUPPLY_QTY, 0))
                             FROM CIMS.T_PLN_ORDER_DETAIL OD
                            WHERE OD.ORDER_LINE_ID = OL.ORDER_LINE_ID),
           OL.LAST_UPDATE_DATE = SYSDATE
     WHERE OL.ORDER_LINE_ID IN (
        SELECT /*H.ORDER_HEAD_ID,
               H.FORM_STATE,
               H.ORDER_TYPE_NAME,
               H.Period_Code,*/
               L.ORDER_LINE_ID/*,
               L.SUPPLY_QTY,
               MIN(NVL(D.SUPPLY_QTY, 0))*/
          FROM CIMS.T_PLN_ORDER_LINE   L,
               CIMS.T_PLN_ORDER_DETAIL D,
               CIMS.T_PLN_ORDER_HEAD   H
         WHERE L.ORDER_LINE_ID = D.ORDER_LINE_ID
           AND L.ORDER_HEAD_ID = H.ORDER_HEAD_ID
           --之前配套关系错误导致问题数据，不统计这些明细行
           AND NVL(D.REMARK,'_') <> 'PLM引入的配套关系错误，生成了错误的明细行，后台取消错误明细行'
         GROUP BY H.ORDER_HEAD_ID,
               H.FORM_STATE,
               H.ORDER_TYPE_NAME,
               H.PERIOD_CODE,
               L.ORDER_LINE_ID,
               L.SUPPLY_QTY
        HAVING NVL(L.SUPPLY_QTY, 0) <> MIN(NVL(D.SUPPLY_QTY, 0)));
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      Rollback;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'p_Pln_Upd_Supply_Qty_Diff',
                                  p_Error_Msg            => '更新订单行和明细行已入库数量不一致的数据！' || sqlerrm,
                                  p_Source_Order_Head_Id => NULL,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
      Commit;
  END p_Pln_Upd_Supply_Qty_Diff;
  
  ------------------------------------------------------------------------------------------------
  -- Author  : hejy3
  -- Created : 2016-12-08
  -- Purpose : 内销每日配套产出情况报表
  ------------------------------------------------------------------------------------------------
  Procedure p_Pln_Daily_Match_Rpt(p_Report_Date IN DATE,
                                  p_Entity_Id IN NUMBER)
  IS
    V_TRANSACTION_ID NUMBER;
    V_MSG VARCHAR2(4000);
    V_BASE_EXCEPTION EXCEPTION;
    V_STEP VARCHAR2(1000);
    V_LAST_DAY DATE;
  BEGIN
    --先删除已存在的数据
    V_STEP := '先删除已存在的数据';
    DELETE FROM T_PLN_DAILY_MATCH_DETAIL D WHERE D.REPORT_DATE = p_Report_Date;
    
    IF p_Report_Date = to_date('2016-12-31', 'YYYY-MM-DD') THEN --上线初始数据
      INSERT INTO T_PLN_DAILY_MATCH_DETAIL
        (DETAIL_ID,
         ENTITY_ID,
         TRANSACTION_ID,
         REPORT_DATE,
         ORDER_HEAD_ID,
         ORDER_NUMBER,
         ORDER_HEAD_STATE,
         ORDER_LINE_ID,
         PRODUCING_AREA_ID,
         PRODUCING_AREA_NAME,
         ASS_ITEM_ID,
         ASS_ITEM_CODE,
         ASS_ITEM_NAME,
         ASS_ITEM_UOM,
         ASS_PROD_FORM,
         ASS_CAN_PRODUCE_QTY,
         ASS_SUPPLY_QTY,
         ORDER_DETAIL_ID,
         SUB_ITEM_ID,
         SUB_ITEM_CODE,
         SUB_ITEM_NAME,
         SUB_ITEM_UOM,
         SUB_PROD_FORM,
         SUB_CAN_PRODUCE_QTY,
         SUB_SUPPLY_QTY,
         SUB_CANCEL_QTY,
         DATA_TYPE,
         PRE_FIELD_01,
         PRE_FIELD_02,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        SELECT S_PLN_DAILY_MATCH_DETAIL.NEXTVAL DETAIL_ID,
               HF.ENTITY_ID ENTITY_ID,
               -1 TRANSACTION_ID,
               p_Report_Date REPORT_DATE,
               HF.ORDER_HEAD_ID,
               HF.ORDER_NUMBER,
               HF.FORM_STATE ORDER_HEAD_STATE,
               LF.ORDER_LINE_ID,
               LF.PRODUCING_AREA_ID,
               A.PRODUCING_AREA_NAME,
               LF.ITEM_ID ASS_ITEM_ID,
               ASS.ITEM_CODE ASS_ITEM_CODE,
               ASS.ITEM_NAME ASS_ITEM_NAME,
               ASS.DEFAULTUNIT ASS_ITEM_UOM,
               ASS.PRODUCTFORM ASS_PROD_FORM,
               LF.CAN_PRODUCE_QTY ASS_CAN_PRODUCE_QTY,
               LF.SUPPLY_QTY ASS_SUPPLY_QTY,
               DF.ORDER_DETAIL_ID,
               SUB.ITEM_ID SUB_ITEM_ID,
               SUB.ITEM_CODE SUB_ITEM_CODE,
               SUB.ITEM_NAME SUB_ITEM_NAME,
               SUB.DEFAULTUNIT SUB_ITEM_UOM,
               SUB.PRODUCTFORM SUB_PROD_FORM,
               DF.CAN_PRODUCE_QTY SUB_CAN_PRODUCE_QTY,
               DF.SUPPLY_QTY SUB_SUPPLY_QTY,
               DF.CANCEL_QTY SUB_CANCEL_QTY,
               '统计明细' DATA_TYPE,
               '入库订单' PRE_FIELD_01,
               TO_CHAR(p_Report_Date, 'YYYY')||'年'||TO_CHAR(p_Report_Date, 'MM')||'月' PRE_FIELD_02,
               'p_Pln_Daily_Match_Rpt' CREATED_BY,
               SYSDATE CREATION_DATE,
               'p_Pln_Daily_Match_Rpt' LAST_UPDATED_BY,
               SYSDATE LAST_UPDATE_DATE
          FROM CIMS.t_Pln_Order_Detail DF,
               CIMS.T_PLN_ORDER_LINE LF,
               CIMS.T_PLN_ORDER_HEAD HF,
               CIMS.T_PLN_ORDER_TYPE     T,
               CIMS.T_PLN_PRODUCING_AREA A,
               CIMS.T_BD_ITEM            ASS,
               CIMS.T_BD_ITEM            SUB
         WHERE DF.ORDER_LINE_ID = LF.ORDER_LINE_ID
           AND DF.ORDER_HEAD_ID = HF.ORDER_HEAD_ID
           AND LF.ORDER_HEAD_ID = HF.ORDER_HEAD_ID
           AND LF.ITEM_ID = ASS.ITEM_ID
           AND DF.ITEM_ID = SUB.ITEM_ID
           AND T.ORDER_TYPE_ID = HF.ORDER_TYPE_ID
           AND LF.PRODUCING_AREA_ID = A.PRODUCING_AREA_ID
           AND HF.ENTITY_ID = p_Entity_Id
           AND HF.FORM_STATE IN ('23', '32', '306') --评审完毕、已排产
           AND NVL(DF.REMARK, '_') <> 'PLM引入的配套关系错误，生成了错误的明细行，后台取消错误明细行'
           AND T.SEND_BY_TYPE NOT IN ('1', '2') --非按月报送订单
           AND T.SOURCE_ORDER_TYPE_ID = 0 --计划订单
           AND T.IS_APS_NEED = 'Y';
      
      INSERT INTO T_PLN_DAILY_MATCH_DETAIL
        (DETAIL_ID,
         ENTITY_ID,
         TRANSACTION_ID,
         REPORT_DATE,
         ORDER_HEAD_ID,
         ORDER_NUMBER,
         ORDER_LINE_ID,
         PRODUCING_AREA_ID,
         PRODUCING_AREA_NAME,
         ASS_ITEM_ID,
         ASS_ITEM_CODE,
         ASS_ITEM_NAME,
         ASS_ITEM_UOM,
         ASS_PROD_FORM,
         ASS_CAN_PRODUCE_QTY,
         ASS_SUPPLY_QTY,
         ORDER_DETAIL_ID,
         SUB_ITEM_ID,
         SUB_ITEM_CODE,
         SUB_ITEM_NAME,
         SUB_ITEM_UOM,
         SUB_PROD_FORM,
         SUB_CAN_PRODUCE_QTY,
         SUB_SUPPLY_QTY,
         SUB_CANCEL_QTY,
         DATA_TYPE,
         CAN_PRODUCE_QTY,
         SUPPLY_QTY,
         PRE_FIELD_01,
         PRE_FIELD_02,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
      SELECT S_PLN_DAILY_MATCH_DETAIL.NEXTVAL,
             D.ENTITY_ID,
             -1 TRANSACTION_ID,
             p_Report_Date REPORT_DATE,
             D.ORDER_HEAD_ID,
             D.ORDER_NUMBER,
             D.ORDER_LINE_ID,
             D.PRODUCING_AREA_ID,
             D.PRODUCING_AREA_NAME,
             D.ASS_ITEM_ID,
             D.ASS_ITEM_CODE,
             D.ASS_ITEM_NAME,
             D.ASS_ITEM_UOM,
             D.ASS_PROD_FORM,
             D.ASS_CAN_PRODUCE_QTY,
             D.ASS_SUPPLY_QTY,
             D.ORDER_DETAIL_ID,
             D.SUB_ITEM_ID,
             D.SUB_ITEM_CODE,
             D.SUB_ITEM_NAME,
             D.SUB_ITEM_UOM,
             D.SUB_PROD_FORM,
             D.SUB_CAN_PRODUCE_QTY,
             D.SUB_SUPPLY_QTY,
             D.SUB_CANCEL_QTY,
             '配套结果数据' DATA_TYPE,
             D.SUB_CAN_PRODUCE_QTY-NVL(D.SUB_SUPPLY_QTY,0)-NVL(D.SUB_CANCEL_QTY,0) CAN_PRODUCE_QTY,
             D.SUB_SUPPLY_QTY SUPPLY_QTY,
             DECODE(D.ASS_PROD_FORM, 'SAMPLE_PRODUCT', '样机', '单边机OR整体机') PRE_FIELD_01,
             TO_CHAR(p_Report_Date, 'YYYY')||'年'||TO_CHAR(p_Report_Date, 'MM')||'月' PRE_FIELD_02,
             'p_Pln_Daily_Match_Rpt' CREATED_BY,
             SYSDATE CREATION_DATE,
             'p_Pln_Daily_Match_Rpt' LAST_UPDATED_BY,
             SYSDATE LAST_UPDATE_DATE
        FROM T_PLN_DAILY_MATCH_DETAIL D
       WHERE D.REPORT_DATE = p_Report_Date
         AND D.ENTITY_ID = p_Entity_Id
         AND NVL(D.ASS_PROD_FORM, '_') NOT IN ('SET_PRODUCT', 'ACCESSORIES_PRODUCT') --非套机、非配件
         AND D.DATA_TYPE = '统计明细'
         AND D.PRE_FIELD_01 = '入库订单';
    ELSE
      SELECT NVL(MAX(D.REPORT_DATE), P_REPORT_DATE - 1)
        INTO V_LAST_DAY
        FROM T_PLN_DAILY_MATCH_DETAIL D
       WHERE D.REPORT_DATE < P_REPORT_DATE;
      
      --取最大ID值
      V_STEP := '先删除已存在的数据';
      SELECT MAX(NVL(TRANSACTION_ID, 0)) + 1
        INTO V_TRANSACTION_ID
        FROM T_BD_SUBASSEMBLIES2MTL;
      
      --插入统计临时表：入库订单
      V_STEP := '插入统计临时表：入库订单';
      INSERT INTO T_PLN_DAILY_MATCH_DETAIL
        (DETAIL_ID,
         ENTITY_ID,
         TRANSACTION_ID,
         REPORT_DATE,
         ORDER_HEAD_ID,
         ORDER_NUMBER,
         ORDER_HEAD_STATE,
         ORDER_LINE_ID,
         PRODUCING_AREA_ID,
         PRODUCING_AREA_NAME,
         ASS_ITEM_ID,
         ASS_ITEM_CODE,
         ASS_ITEM_NAME,
         ASS_ITEM_UOM,
         ASS_PROD_FORM,
         ASS_CAN_PRODUCE_QTY,
         ASS_SUPPLY_QTY,
         ORDER_DETAIL_ID,
         SUB_ITEM_ID,
         SUB_ITEM_CODE,
         SUB_ITEM_NAME,
         SUB_ITEM_UOM,
         SUB_PROD_FORM,
         SUB_CAN_PRODUCE_QTY,
         SUB_SUPPLY_QTY,
         SUB_CANCEL_QTY,
         DATA_TYPE,
         PRE_FIELD_01,
         PRE_FIELD_02,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        SELECT S_PLN_DAILY_MATCH_DETAIL.NEXTVAL DETAIL_ID,
               HF.ENTITY_ID ENTITY_ID,
               V_TRANSACTION_ID TRANSACTION_ID,
               P_REPORT_DATE REPORT_DATE,
               HF.ORDER_HEAD_ID,
               HF.ORDER_NUMBER,
               HF.FORM_STATE ORDER_HEAD_STATE,
               LF.ORDER_LINE_ID,
               LF.PRODUCING_AREA_ID,
               A.PRODUCING_AREA_NAME,
               LF.ITEM_ID ASS_ITEM_ID,
               ASS.ITEM_CODE ASS_ITEM_CODE,
               ASS.ITEM_NAME ASS_ITEM_NAME,
               ASS.DEFAULTUNIT ASS_ITEM_UOM,
               ASS.PRODUCTFORM ASS_PROD_FORM,
               LF.CAN_PRODUCE_QTY ASS_CAN_PRODUCE_QTY,
               LF.SUPPLY_QTY ASS_SUPPLY_QTY,
               DF.ORDER_DETAIL_ID,
               SUB.ITEM_ID SUB_ITEM_ID,
               SUB.ITEM_CODE SUB_ITEM_CODE,
               SUB.ITEM_NAME SUB_ITEM_NAME,
               SUB.DEFAULTUNIT SUB_ITEM_UOM,
               SUB.PRODUCTFORM SUB_PROD_FORM,
               DF.CAN_PRODUCE_QTY SUB_CAN_PRODUCE_QTY,
               DF.SUPPLY_QTY SUB_SUPPLY_QTY,
               DF.CANCEL_QTY SUB_CANCEL_QTY,
               '统计明细' DATA_TYPE,
               '入库订单' PRE_FIELD_01,
               TO_CHAR(p_Report_Date, 'YYYY')||'年'||TO_CHAR(p_Report_Date, 'MM')||'月' PRE_FIELD_02,
               'p_Pln_Daily_Match_Rpt' CREATED_BY,
               SYSDATE CREATION_DATE,
               'p_Pln_Daily_Match_Rpt' LAST_UPDATED_BY,
               SYSDATE LAST_UPDATE_DATE
          FROM CIMS.T_PLN_ORDER_DETAIL DF,
               CIMS.T_PLN_ORDER_LINE LF,
               CIMS.T_PLN_ORDER_HEAD HF,
               CIMS.T_PLN_ORDER_TYPE     T,
               CIMS.T_PLN_PRODUCING_AREA A,
               CIMS.T_BD_ITEM            ASS,
               CIMS.T_BD_ITEM            SUB
         WHERE DF.ORDER_LINE_ID = LF.ORDER_LINE_ID
           AND DF.ORDER_HEAD_ID = HF.ORDER_HEAD_ID
           AND LF.ORDER_HEAD_ID = HF.ORDER_HEAD_ID
           AND LF.ITEM_ID = ASS.ITEM_ID
           AND DF.ITEM_ID = SUB.ITEM_ID
           AND T.ORDER_TYPE_ID = HF.ORDER_TYPE_ID
           AND LF.PRODUCING_AREA_ID = A.PRODUCING_AREA_ID
           AND HF.ENTITY_ID = P_ENTITY_ID
           AND HF.FORM_STATE IN ('23', '32', '306') --评审完毕、已排产
           AND NVL(DF.REMARK, '_') <> 'PLM引入的配套关系错误，生成了错误的明细行，后台取消错误明细行'
           AND T.SEND_BY_TYPE NOT IN ('1', '2')
           AND T.SOURCE_ORDER_TYPE_ID = 0 --计划订单
           AND T.IS_APS_NEED = 'Y';
      COMMIT;
      
      --对单据明细数据进行配套处理
      --1、插入配套临时表
      V_STEP := '插入配套临时表';
      INSERT INTO T_BD_SUBASSEMBLIES2MTL
        (ROW_ID,
         ENTITY_ID,
         TRANSACTION_ID,
         CLASSFY_CODE,
         PROC_LEVEL,
         ITEM_ID,
         ITEM_CODE,
         ITEM_NAME,
         UOM_CODE,
         MATCH_FLAG,
         QTY1,
         COMMENTS,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
       SELECT SEQ_BD_ROW_ID.NEXTVAL ROW_ID,
              ENTITY_ID,
              V_TRANSACTION_ID TRANSACTION_ID,
              PRODUCING_AREA_NAME CLASSFY_CODE,
              1 PROC_LEVEL,
              SUB_ITEM_ID ITEM_ID,
              SUB_ITEM_CODE ITEM_CODE,
              SUB_ITEM_NAME ITEM_NAME,
              SUB_ITEM_UOM UOM_CODE,
              'N' MATCH_FLAG,
              QUANTITY QTY1,
              '配套单据明细' COMMENTS,
              'p_Pln_Daily_Match_Rpt' CREATED_BY,
               SYSDATE CREATION_DATE,
               'p_Pln_Daily_Match_Rpt' LAST_UPDATED_BY,
               SYSDATE LAST_UPDATE_DATE
         FROM (SELECT D.ENTITY_ID,
                      D.PRODUCING_AREA_NAME,
                      D.SUB_ITEM_ID,
                      D.SUB_ITEM_CODE,
                      D.SUB_ITEM_NAME,
                      D.SUB_ITEM_UOM,
                      SUM(D.SUB_SUPPLY_QTY - NVL(D.ASS_SUPPLY_QTY, 0)) QUANTITY
                 FROM T_PLN_DAILY_MATCH_DETAIL D
                WHERE D.REPORT_DATE = p_Report_Date
                  AND D.ENTITY_ID = p_Entity_Id
                  AND D.DATA_TYPE = '统计明细'
                  AND D.PRE_FIELD_01 = '入库订单'
                  AND D.ASS_PROD_FORM = 'SET_PRODUCT' --套机
                  AND NVL(D.SUB_PROD_FORM, '_') <> 'ACCESSORIES_PRODUCT' --非配件产品
                  AND D.ORDER_HEAD_STATE IN ('23', '32') --评审完毕、已排产
                  AND D.SUB_CAN_PRODUCE_QTY > 0
                  AND D.SUB_CAN_PRODUCE_QTY - NVL(D.SUB_SUPPLY_QTY, 0) - NVL(D.SUB_CANCEL_QTY, 0) > 0
                  AND NVL(D.SUB_SUPPLY_QTY, 0) > NVL(D.ASS_SUPPLY_QTY, 0)
                GROUP BY D.ENTITY_ID,
                         D.PRODUCING_AREA_NAME,
                         D.SUB_ITEM_ID,
                         D.SUB_ITEM_CODE,
                         D.SUB_ITEM_NAME,
                         D.SUB_ITEM_UOM);
      
      --配套处理
      V_STEP := '配套处理。批次ID：' || TO_CHAR(V_TRANSACTION_ID);
      PKG_BD_ITEM.P_MATCHING_MTL_150(P_TRANSACTION_ID => V_TRANSACTION_ID,
                                     P_ENTITY_ID      => p_Entity_Id,
                                     P_MESSAGE        => V_MSG);
      
      IF V_MSG <> 'OK' THEN
        RAISE V_BASE_EXCEPTION;
      END IF;
      
      --插入统计结果
      V_STEP := '插入统计结果：未入库完毕散件配套明细';
      INSERT INTO T_PLN_DAILY_MATCH_DETAIL
        (DETAIL_ID,
         ENTITY_ID,
         TRANSACTION_ID,
         REPORT_DATE,
         ORDER_HEAD_ID,
         ORDER_NUMBER,
         ORDER_LINE_ID,
         PRODUCING_AREA_ID,
         PRODUCING_AREA_NAME,
         ASS_ITEM_ID,
         ASS_ITEM_CODE,
         ASS_ITEM_NAME,
         ASS_ITEM_UOM,
         ASS_CAN_PRODUCE_QTY,
         ASS_SUPPLY_QTY,
         SUB_ITEM_ID,
         SUB_ITEM_CODE,
         SUB_ITEM_NAME,
         SUB_ITEM_UOM,
         SUB_CAN_PRODUCE_QTY,
         SUB_SUPPLY_QTY,
         SUB_CANCEL_QTY,
         DATA_TYPE,
         MATCH_FLAG,
         SUPPLY_QTY,
         PRE_FIELD_01,
         PRE_FIELD_02,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
       SELECT S_PLN_DAILY_MATCH_DETAIL.NEXTVAL DETAIL_ID,
              R.ENTITY_ID,
              R.TRANSACTION_ID,
              p_Report_Date REPORT_DATE,
              NULL ORDER_HEAD_ID,
              NULL ORDER_NUMBER,
              NULL ORDER_LINE_ID,
              A.PRODUCING_AREA_ID,
              A.PRODUCING_AREA_NAME,
              DECODE(R.MATCH_FLAG, 'Y', R.ITEM_ID, NULL) ASS_ITEM_ID,
              DECODE(R.MATCH_FLAG, 'Y', R.ITEM_CODE, NULL) ASS_ITEM_CODE,
              DECODE(R.MATCH_FLAG, 'Y', R.ITEM_NAME, NULL) ASS_ITEM_NAME,
              DECODE(R.MATCH_FLAG, 'Y', R.UOM_CODE, NULL) ASS_ITEM_UOM,
              NULL ASS_CAN_PRODUCE_QTY,
              NULL ASS_SUPPLY_QTY,
              DECODE(R.MATCH_FLAG, 'Y', NULL, R.ITEM_ID) SUB_ITEM_ID,
              DECODE(R.MATCH_FLAG, 'Y', NULL, R.ITEM_CODE) SUB_ITEM_CODE,
              DECODE(R.MATCH_FLAG, 'Y', NULL, R.ITEM_NAME) SUB_ITEM_NAME,
              DECODE(R.MATCH_FLAG, 'Y', NULL, R.UOM_CODE) SUB_ITEM_UOM,
              NULL SUB_CAN_PRODUCE_QTY,
              NULL SUB_SUPPLY_QTY,
              NULL SUB_CANCEL_QTY,
              '配套结果数据' DATA_TYPE,
              R.MATCH_FLAG,
              R.QTY1 SUPPLY_QTY,
              '未入库完毕散件配套结果' PRE_FIELD_01,
              TO_CHAR(p_Report_Date, 'YYYY')||'年'||TO_CHAR(p_Report_Date, 'MM')||'月' PRE_FIELD_02,
              'p_Pln_Daily_Match_Rpt' CREATED_BY,
              SYSDATE CREATION_DATE,
              'p_Pln_Daily_Match_Rpt' LAST_UPDATED_BY,
              SYSDATE LAST_UPDATE_DATE
         FROM T_BD_SUBASS2MTL_RESULT R,
              T_PLN_PRODUCING_AREA A
        WHERE R.TRANSACTION_ID = V_TRANSACTION_ID
          AND R.CLASSFY_CODE = A.PRODUCING_AREA_NAME
          AND R.ENTITY_ID = A.ENTITY_ID;
      
      --插入统计结果：配套入库订单明细
      --先插入上次统计数据到临时表
      INSERT INTO T_PLN_DAILY_MD_TEMP
        (DETAIL_ID,
         ENTITY_ID,
         TRANSACTION_ID,
         REPORT_DATE,
         ORDER_HEAD_ID,
         ORDER_NUMBER,
         ORDER_LINE_ID,
         PRODUCING_AREA_ID,
         PRODUCING_AREA_NAME,
         ASS_ITEM_ID,
         ASS_ITEM_CODE,
         ASS_ITEM_NAME,
         ASS_ITEM_UOM,
         ASS_CAN_PRODUCE_QTY,
         ASS_SUPPLY_QTY,
         ORDER_DETAIL_ID,
         SUB_ITEM_ID,
         SUB_ITEM_CODE,
         SUB_ITEM_NAME,
         SUB_ITEM_UOM,
         SUB_CAN_PRODUCE_QTY,
         SUB_SUPPLY_QTY,
         SUB_CANCEL_QTY,
         DATA_TYPE,
         MATCH_FLAG,
         SUPPLY_QTY,
         PRE_FIELD_01,
         PRE_FIELD_02,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        SELECT -1 DETAIL_ID,
               D.ENTITY_ID,
               V_TRANSACTION_ID TRANSACTION_ID,
               D.REPORT_DATE,
               D.ORDER_HEAD_ID,
               D.ORDER_NUMBER,
               D.ORDER_LINE_ID,
               D.PRODUCING_AREA_ID,
               D.PRODUCING_AREA_NAME,
               D.ASS_ITEM_ID,
               D.ASS_ITEM_CODE,
               D.ASS_ITEM_NAME,
               D.ASS_ITEM_UOM,
               D.ASS_CAN_PRODUCE_QTY,
               D.ASS_SUPPLY_QTY,
               D.ORDER_DETAIL_ID,
               D.SUB_ITEM_ID,
               D.SUB_ITEM_CODE,
               D.SUB_ITEM_NAME,
               D.SUB_ITEM_UOM,
               D.SUB_CAN_PRODUCE_QTY,
               D.SUB_SUPPLY_QTY,
               D.SUB_CANCEL_QTY,
               D.DATA_TYPE,
               D.MATCH_FLAG,
               D.SUPPLY_QTY,
               D.PRE_FIELD_01,
               D.PRE_FIELD_02,
               'p_Pln_Daily_Match_Rpt' CREATED_BY,
               SYSDATE CREATION_DATE,
               'p_Pln_Daily_Match_Rpt' LAST_UPDATED_BY,
               SYSDATE LAST_UPDATE_DATE
          FROM T_PLN_DAILY_MATCH_DETAIL D
         WHERE D.REPORT_DATE = V_LAST_DAY
           AND D.ENTITY_ID = p_Entity_Id
           AND D.DATA_TYPE = '统计明细'
           AND D.PRE_FIELD_01 = '入库订单'
           --AND D.ASS_PROD_FORM = 'SET_PRODUCT' --套机
           AND NVL(D.SUB_PROD_FORM, '_') <> 'ACCESSORIES_PRODUCT'; --非配件
      
      V_STEP := '插入统计结果：配套入库明细';
      INSERT INTO T_PLN_DAILY_MATCH_DETAIL
        (DETAIL_ID,
         ENTITY_ID,
         TRANSACTION_ID,
         REPORT_DATE,
         ORDER_HEAD_ID,
         ORDER_NUMBER,
         ORDER_LINE_ID,
         PRODUCING_AREA_ID,
         PRODUCING_AREA_NAME,
         ASS_ITEM_ID,
         ASS_ITEM_CODE,
         ASS_ITEM_NAME,
         ASS_ITEM_UOM,
         ASS_CAN_PRODUCE_QTY,
         ASS_SUPPLY_QTY,
         ORDER_DETAIL_ID,
         SUB_ITEM_ID,
         SUB_ITEM_CODE,
         SUB_ITEM_NAME,
         SUB_ITEM_UOM,
         SUB_CAN_PRODUCE_QTY,
         SUB_SUPPLY_QTY,
         SUB_CANCEL_QTY,
         DATA_TYPE,
         MATCH_FLAG,
         SUPPLY_QTY,
         PRE_FIELD_01,
         PRE_FIELD_02,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
        SELECT S_PLN_DAILY_MATCH_DETAIL.NEXTVAL DETAIL_ID,
               ENTITY_ID ENTITY_ID,
               V_TRANSACTION_ID TRANSACTION_ID,
               P_REPORT_DATE REPORT_DATE,
               ORDER_HEAD_ID,
               ORDER_NUMBER,
               ORDER_LINE_ID,
               PRODUCING_AREA_ID,
               PRODUCING_AREA_NAME,
               ASS_ITEM_ID,
               ASS_ITEM_CODE,
               ASS_ITEM_NAME,
               ASS_ITEM_UOM,
               ASS_CAN_PRODUCE_QTY,
               ASS_SUPPLY_QTY,
               ORDER_DETAIL_ID,
               SUB_ITEM_ID,
               SUB_ITEM_CODE,
               SUB_ITEM_NAME,
               SUB_ITEM_UOM,
               SUB_CAN_PRODUCE_QTY,
               SUB_SUPPLY_QTY,
               SUB_CANCEL_QTY,
               '配套结果数据' DATA_TYPE,
               'Y' MATCH_FLAG,
               SUPPLY_QTY,
               '配套入库明细' PRE_FIELD_01,
               TO_CHAR(p_Report_Date, 'YYYY')||'年'||TO_CHAR(p_Report_Date, 'MM')||'月' PRE_FIELD_02,
               'p_Pln_Daily_Match_Rpt' CREATED_BY,
               SYSDATE CREATION_DATE,
               'p_Pln_Daily_Match_Rpt' LAST_UPDATED_BY,
               SYSDATE LAST_UPDATE_DATE
          FROM (SELECT D.ENTITY_ID,
                   D.ORDER_HEAD_ID,
                   D.ORDER_NUMBER,
                   D.ORDER_LINE_ID,
                   D.PRODUCING_AREA_ID,
                   D.PRODUCING_AREA_NAME,
                   D.ASS_ITEM_ID,
                   D.ASS_ITEM_CODE,
                   D.ASS_ITEM_NAME,
                   D.ASS_ITEM_UOM,
                   D.ASS_CAN_PRODUCE_QTY,
                   D.ASS_SUPPLY_QTY,
                   D.ORDER_DETAIL_ID,
                   D.SUB_ITEM_ID,
                   D.SUB_ITEM_CODE,
                   D.SUB_ITEM_NAME,
                   D.SUB_ITEM_UOM,
                   D.SUB_CAN_PRODUCE_QTY,
                   D.SUB_SUPPLY_QTY,
                   D.SUB_CANCEL_QTY,
                   D.ASS_SUPPLY_QTY - NVL(DY.ASS_SUPPLY_QTY, 0) SUPPLY_QTY
              FROM T_PLN_DAILY_MATCH_DETAIL D,
                   T_PLN_DAILY_MD_TEMP DY
             WHERE D.ORDER_DETAIL_ID = DY.ORDER_DETAIL_ID(+)
               AND D.REPORT_DATE = p_Report_Date
               AND D.ENTITY_ID = p_Entity_Id
               AND D.DATA_TYPE = '统计明细'
               AND D.PRE_FIELD_01 = '入库订单'
               AND D.ASS_PROD_FORM = 'SET_PRODUCT' --套机
               AND NVL(D.SUB_PROD_FORM, '_') <> 'ACCESSORIES_PRODUCT' --非配件
               AND NVL(D.ASS_SUPPLY_QTY, 0) - NVL(DY.ASS_SUPPLY_QTY, 0) > 0
             ORDER BY D.ORDER_NUMBER, D.ASS_ITEM_CODE, D.PRODUCING_AREA_NAME);
      
      --插入统计结果：当月样机、单边机OR整体机数据
      V_STEP := '插入统计结果：样机、单边机OR整体机数据';
      INSERT INTO T_PLN_DAILY_MATCH_DETAIL
        (DETAIL_ID,
         ENTITY_ID,
         TRANSACTION_ID,
         REPORT_DATE,
         ORDER_HEAD_ID,
         ORDER_NUMBER,
         ORDER_LINE_ID,
         PRODUCING_AREA_ID,
         PRODUCING_AREA_NAME,
         ASS_ITEM_ID,
         ASS_ITEM_CODE,
         ASS_ITEM_NAME,
         ASS_ITEM_UOM,
         ASS_PROD_FORM,
         ASS_CAN_PRODUCE_QTY,
         ASS_SUPPLY_QTY,
         ORDER_DETAIL_ID,
         SUB_ITEM_ID,
         SUB_ITEM_CODE,
         SUB_ITEM_NAME,
         SUB_ITEM_UOM,
         SUB_PROD_FORM,
         SUB_CAN_PRODUCE_QTY,
         SUB_SUPPLY_QTY,
         SUB_CANCEL_QTY,
         DATA_TYPE,
         CAN_PRODUCE_QTY,
         SUPPLY_QTY,
         PRE_FIELD_01,
         PRE_FIELD_02,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATED_BY,
         LAST_UPDATE_DATE)
      SELECT S_PLN_DAILY_MATCH_DETAIL.NEXTVAL,
             D.ENTITY_ID,
             V_TRANSACTION_ID TRANSACTION_ID,
             p_Report_Date REPORT_DATE,
             D.ORDER_HEAD_ID,
             D.ORDER_NUMBER,
             D.ORDER_LINE_ID,
             D.PRODUCING_AREA_ID,
             D.PRODUCING_AREA_NAME,
             D.ASS_ITEM_ID,
             D.ASS_ITEM_CODE,
             D.ASS_ITEM_NAME,
             D.ASS_ITEM_UOM,
             D.ASS_PROD_FORM,
             D.ASS_CAN_PRODUCE_QTY,
             D.ASS_SUPPLY_QTY,
             D.ORDER_DETAIL_ID,
             D.SUB_ITEM_ID,
             D.SUB_ITEM_CODE,
             D.SUB_ITEM_NAME,
             D.SUB_ITEM_UOM,
             D.SUB_PROD_FORM,
             D.SUB_CAN_PRODUCE_QTY,
             D.SUB_SUPPLY_QTY,
             D.SUB_CANCEL_QTY,
             '配套结果数据' DATA_TYPE,
             NVL((SELECT MD.CAN_PRODUCE_QTY
                    FROM T_PLN_DAILY_MATCH_DETAIL MD
                   WHERE MD.REPORT_DATE = V_LAST_DAY
                     AND MD.ENTITY_ID = p_Entity_Id
                     AND MD.DATA_TYPE = '配套结果数据'
                     AND MD.PRE_FIELD_01 = DECODE(D.ASS_PROD_FORM, 'SAMPLE_PRODUCT', '样机', '单边机OR整体机')
                     AND MD.ORDER_DETAIL_ID = D.ORDER_DETAIL_ID), 0) + 
             (NVL(D.SUB_CAN_PRODUCE_QTY, 0) - NVL(DY.SUB_CAN_PRODUCE_QTY, 0)) -
             (NVL(D.SUB_CANCEL_QTY, 0) - NVL(DY.SUB_CANCEL_QTY, 0)) CAN_PRODUCE_QTY,
             D.ASS_SUPPLY_QTY - NVL(DY.ASS_SUPPLY_QTY, 0) SUPPLY_QTY,
             DECODE(D.ASS_PROD_FORM, 'SAMPLE_PRODUCT', '样机', '单边机OR整体机') PRE_FIELD_01,
             TO_CHAR(p_Report_Date, 'YYYY')||'年'||TO_CHAR(p_Report_Date, 'MM')||'月' PRE_FIELD_02,
             'p_Pln_Daily_Match_Rpt' CREATED_BY,
             SYSDATE CREATION_DATE,
             'p_Pln_Daily_Match_Rpt' LAST_UPDATED_BY,
             SYSDATE LAST_UPDATE_DATE
        FROM T_PLN_DAILY_MD_TEMP DY,
             T_PLN_DAILY_MATCH_DETAIL D
       WHERE D.ORDER_DETAIL_ID = DY.ORDER_DETAIL_ID(+)
         AND D.REPORT_DATE = p_Report_Date
         AND D.ENTITY_ID = p_Entity_Id
         AND NVL(D.ASS_PROD_FORM, '_') NOT IN ('SET_PRODUCT', 'ACCESSORIES_PRODUCT') --非套机、非配件
         AND D.DATA_TYPE = '统计明细'
         AND D.PRE_FIELD_01 = '入库订单';
      
      --删除临时表数据
      DELETE FROM T_PLN_DAILY_MD_TEMP T WHERE T.TRANSACTION_ID = V_TRANSACTION_ID;
    END IF;
    COMMIT;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      Rollback;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'p_Pln_Daily_Match_Rpt',
                                  p_Error_Msg            => '内销每日配套产出情况报表！' || v_Nl || V_STEP || v_Nl || V_MSG,
                                  p_Source_Order_Head_Id => NULL,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
      Commit;
    WHEN OTHERS THEN
      Rollback;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'p_Pln_Daily_Match_Rpt',
                                  p_Error_Msg            => '内销每日配套产出情况报表！' || v_Nl || V_STEP || v_Nl || sqlerrm,
                                  p_Source_Order_Head_Id => NULL,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
      Commit;
  END p_Pln_Daily_Match_Rpt;

	------------------------------------------------------------------------------------------------
  -- Author  : hejy3
  -- Created : 2017-07-01
  -- Purpose : 产能可视报表
  ------------------------------------------------------------------------------------------------
  Procedure p_Pln_Capacity_Rpt(p_Entity_Id IN NUMBER)
  IS
    V_OCCUPY_CAPACITI_QTY NUMBER := 0;
  BEGIN
    FOR RC IN (SELECT C.* FROM T_PLN_MONTH_REMAIN_CAPACIT C WHERE C.ENTITY_ID = p_Entity_Id) LOOP
      SELECT Pkg_Pln_Pub.f_Get_Lgorder_Noship_Qty(-1,
                                                  -1,
                                                  '_',
                                                  null,
                                                  RC.MRP_ORG_ID,
                                                  RC.ITEM_CODE)
        INTO V_OCCUPY_CAPACITI_QTY
        FROM DUAL;
      UPDATE T_PLN_MONTH_REMAIN_CAPACIT C
         SET C.OCCUPY_QTY = V_OCCUPY_CAPACITI_QTY
       WHERE C.ENTITY_ID = p_Entity_Id
         and c.mrp_org_id = rc.mrp_org_id
         and c.item_code = rc.item_code;
      COMMIT;
    END LOOP;
  exception
    WHEN OTHERS THEN
      ROLLBACK;
      PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'PLN',
                                  P_PROCEDURE_NAME       => 'P_PLN_CAPACITY_RPT',
                                  P_ERROR_MSG            => '生成产能可视报表数据！' || V_NL ||
                                                            SQLERRM,
                                  P_SOURCE_ORDER_HEAD_ID => NULL,
                                  P_SOURCE_ORDER_LINE_ID => NULL,
                                  P_ITEM_ID              => NULL,
                                  P_INVENTORY_ID         => NULL,
                                  P_QUANTITY             => NULL);
      COMMIT;
  END p_Pln_Capacity_Rpt;

  -------------------------------------------------------------------------
  -- Author  : lilh6
  -- Created : 2017-04-14 
  -- Purpose : 产品型谱推送
  -------------------------------------------------------------------------
  PROCEDURE P_ITEM_DYN_JOB(P_ENTITY_ID_HQ IN NUMBER, --总部主体id
                           P_ENTITY_ID_SC IN NUMBER --销司主体id
                           ) IS
    V_MSG VARCHAR2(4000); --错误信息
    V_BASE_EXCEPTION EXCEPTION;
    V_ITEM_CODE VARCHAR2(100); --产品编码
    V_ITEM_ID   NUMBER; --产品id
    V_ITEM_NAME VARCHAR2(300); --产品描述
  
    --获取总部产品型谱与销司产品型谱的差异，只获取总部主体有的而销司主体没有的
    CURSOR T_PLN_ITEM_DYN_CURSOR IS
      SELECT IDA.ITEM_CODE
        FROM (SELECT A.ITEM_CODE
                FROM CIMS.T_PLN_ITEM_DYN_ATTRIBUTE A
               WHERE A.ENTITY_ID = P_ENTITY_ID_HQ
                 AND A.BEGIN_DATE <= SYSDATE
                 AND NVL(A.END_DATE, SYSDATE) >= SYSDATE
              MINUS
              SELECT AA.ITEM_CODE
                FROM CIMS.T_PLN_ITEM_DYN_ATTRIBUTE AA
               WHERE AA.ENTITY_ID = P_ENTITY_ID_SC) IDA
       WHERE EXISTS (SELECT 1
                FROM CIMS.T_BD_ITEM I
               WHERE I.ITEM_CODE = IDA.ITEM_CODE
                 AND I.ENTITY_ID = P_ENTITY_ID_SC);
  BEGIN
    OPEN T_PLN_ITEM_DYN_CURSOR;
    LOOP
      FETCH T_PLN_ITEM_DYN_CURSOR
        INTO V_ITEM_CODE;
      EXIT WHEN T_PLN_ITEM_DYN_CURSOR%NOTFOUND;
    
      BEGIN
        --获取销司主体的产品id，产品名称
        SELECT I.ITEM_ID, I.ITEM_NAME
          INTO V_ITEM_ID, V_ITEM_NAME
          FROM T_BD_ITEM I
         WHERE I.ENTITY_ID = P_ENTITY_ID_SC
           AND I.ITEM_CODE = V_ITEM_CODE;
        /*EXCEPTION
        WHEN OTHERS THEN
          V_MSG := '获取销司主体产品信息失败，请检查销司主体是否存在此产品：' || V_ITEM_CODE || V_NL ||
                   SQLERRM;
          RAISE V_BASE_EXCEPTION;*/
      END;
    
      --开始插入销司主体产品型谱表
      BEGIN
        INSERT INTO T_PLN_ITEM_DYN_ATTRIBUTE
          (ENTITY_ID,
           ITEM_ID,
           ITEM_CODE,
           ITEM_NAME,
           ITEM_DYNAMIC_ATTRIBUTE,
           BEGIN_DATE,
           END_DATE,
           ITEM_MAX_QTY,
           ITEM_MIN_QTY,
           IS_CONVENTIONAL,
           SAMPLE_FLAG,
           ITEM_SUPPLY_PERIOD,
           IMP_ERP_FLAG,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATE_BY,
           LAST_UPDATE_DATE,
           REMARK,
           PRE_FIELD_01,
           PRE_FIELD_02,
           PRE_FIELD_03,
           PRE_FIELD_04,
           PRE_FIELD_05,
           PRE_FIELD_06,
           PROGRAM_UPDATED_BY,
           PROGRAM_UPDATE_DATE,
           VERSION)
        VALUES
          (P_ENTITY_ID_SC,
           V_ITEM_ID,
           V_ITEM_CODE,
           V_ITEM_NAME,
           '定制机型',
           TO_DATE('01-01-2014', 'dd-mm-yyyy'),
           NULL,
           10000,
           1,
           NULL,
           NULL,
           2,
           'Y',
           'admin',
           SYSDATE,
           'admin',
           SYSDATE,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           1);
        COMMIT;
      
        -------同时插入客户SKU表，给所有有效中心都插入一条记录
        INSERT INTO T_PLN_ITEM_SKU
          (ENTITY_ID,
           ITEM_SKU_ID,
           SALES_CENTER_ID,
           SALES_CENTER_CODE,
           SALES_CENTER_NAME,
           ITEM_ID,
           ITEM_CODE,
           ITEM_NAME,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATE_BY,
           LAST_UPDATE_DATE,
           VERSION,
           IS_SUBMIT)
          SELECT U.ENTITY_ID,
                 S_PLN_ITEM_SKU.NEXTVAL,
                 U.UNIT_ID,
                 U.CODE,
                 U.NAME,
                 A.ITEM_ID,
                 A.ITEM_CODE,
                 A.ITEM_NAME,
                 'admin',
                 SYSDATE,
                 'admin',
                 SYSDATE,
                 1,
                 'Y'
            FROM T_PLN_ITEM_DYN_ATTRIBUTE A, UP_ORG_UNIT U
           WHERE U.ENTITY_ID = P_ENTITY_ID_SC
             AND U.TYPE_CODE = 'SC'
             AND U.ACTIVE_FLAG = 'T'
             AND A.ITEM_ID = V_ITEM_ID
             AND EXISTS
           (SELECT 1
                    FROM T_PLN_ITEM_SKU PIS, T_BD_CENTER_RELATION R
                   WHERE PIS.SALES_CENTER_CODE = R.HQ_SALES_CENTER_CODE
                     AND R.SC_SALES_CENTER_CODE = U.CODE
                     AND PIS.ITEM_CODE = A.ITEM_CODE
                     AND PIS.ENTITY_ID = P_ENTITY_ID_HQ
                     AND SYSDATE BETWEEN R.BEGIN_DATE AND
                         NVL(R.END_DATE, SYSDATE));
        COMMIT;
      END;
    END LOOP;
  EXCEPTION
    WHEN V_BASE_EXCEPTION THEN
      ROLLBACK;
      PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'PLN',
                                  P_PROCEDURE_NAME       => 'P_ITEM_DYN_JOB',
                                  P_ERROR_MSG            => '总部主体推送产品型谱到销司主体！' || V_NL ||
                                                            V_MSG,
                                  P_SOURCE_ORDER_HEAD_ID => NULL,
                                  P_SOURCE_ORDER_LINE_ID => NULL,
                                  P_ITEM_ID              => NULL,
                                  P_INVENTORY_ID         => NULL,
                                  P_QUANTITY             => NULL);
      COMMIT;
    WHEN OTHERS THEN
      ROLLBACK;
      PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'PLN',
                                  P_PROCEDURE_NAME       => 'P_ITEM_DYN_JOB',
                                  P_ERROR_MSG            => '总部主体推送产品型谱到销司主体！' || V_NL ||
                                                            SQLERRM,
                                  P_SOURCE_ORDER_HEAD_ID => NULL,
                                  P_SOURCE_ORDER_LINE_ID => NULL,
                                  P_ITEM_ID              => NULL,
                                  P_INVENTORY_ID         => NULL,
                                  P_QUANTITY             => NULL);
      COMMIT;
  END;
  
  -------------------------------------------------------------------------
  -- Author  : hejy3
  -- Created : 2018-05-23
  -- Purpose : APS产能可视返回且未处理数据补偿机制
  -------------------------------------------------------------------------
  Procedure p_Aps_Capacity_Compensate(In_Entity_Id Number Default -1) Is
    v_Result                   Varchar2(4000);
    v_Order_Number             t_Pln_Lg_Order_Head.Order_Number%Type;
    v_Order_Head_Id            t_Pln_Lg_Order_Head.Order_Head_Id%Type;
    v_Pln_Capacity_Strict_Flag Varchar2(100);
  Begin
    For r_Entity In (Select *
                       From Cims.v_Bd_Entity e
                      Where e.Entity_Id = In_Entity_Id
                         Or In_Entity_Id = -1) Loop
    
      --获取产能严控标识
      Begin
        v_Pln_Capacity_Strict_Flag := Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_STRICT_FLAG',
                                                                   r_Entity.Entity_Id);
      Exception
        When Others Then
          v_Pln_Capacity_Strict_Flag := 'STRICT';
      End;
      --获取产能可视返回接口存在处理标志为N的数据
      For r_Order In (Select Distinct h.Order_Head_Id,
                                      h.Order_Number,
                                      r.Batch_Id,
                                      r.Entity_Code
                        From t_Pln_Lg_Order_Head         h,
                             Intf_Pln_Order_Capacity_Rec r
                       Where h.To_Checkup_Date > Sysdate - 30 --1个月内
                         And h.To_Checkup_Date < Sysdate - 1 / 24 --一个小时前的数据，避免处理正在正常提交的订单
                         And h.Order_Head_State = '2225' --已APS产能可视状态
                         And h.Aps_Capacity_State = 'P' --处理中
                         And h.Entity_Id = r_Entity.Entity_Id
                         And r.Order_Number = h.Order_Number
                         And r.Intf_State = 'N') Loop
        v_Order_Number  := r_Order.Order_Number;
        v_Order_Head_Id := r_Order.Order_Head_Id;
        --调用订单处理过程
        Pkg_Pln_Intf_Aps.p_Capacity_Receiver_Pro(p_Batch_Id    => r_Order.Batch_Id,
                                                 p_Entity_Code => r_Order.Entity_Code,
                                                 p_Result      => v_Result);
        If v_Result = v_Success Then
          Commit;
        Else
          Rollback;
          Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                      p_Procedure_Name       => 'P_APS_CAPACITY_COMPENSATE',
                                      p_Error_Msg            => '订单：' ||
                                                                v_Order_Number || v_Nl ||
                                                                v_Result,
                                      p_Source_Order_Head_Id => v_Order_Head_Id,
                                      p_Source_Order_Line_Id => Null,
                                      p_Item_Id              => Null,
                                      p_Inventory_Id         => Null,
                                      p_Quantity             => Null);
          Commit;
        End If;
      End Loop;
      --产能可视不严控的,把已引APS产能可视状态的订单全部更新为已送审
      If v_Pln_Capacity_Strict_Flag = 'NOSTRICT' Then
        Update t_Pln_Lg_Order_Head h
           Set h.Order_Head_State = 20,
               h.aps_capacity_state = 'N',
               h.Last_Update_Date = Sysdate,
               h.Version          = Nvl(h.Version, 0) + 1
         Where h.To_Checkup_Date > Sysdate - 30 --1个月内
           And h.Order_Head_State = '2225' --已APS产能可视状态
           And h.Entity_Id = r_Entity.Entity_Id;
        Commit;
      End If;
    End Loop;
  Exception
    When Others Then
      Rollback;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'P_APS_CAPACITY_COMPENSATE',
                                  p_Error_Msg            => '订单：' ||
                                                            v_Order_Number || v_Nl ||
                                                            Sqlerrm,
                                  p_Source_Order_Head_Id => v_Order_Head_Id,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
      Commit;
  End p_Aps_Capacity_Compensate;
  
  ------------------------------------------------------------------------------------------------
  -- Author  : hejy3
  -- Created : 2018-06-08
  -- Purpose : 回款提醒数据冻结
  ------------------------------------------------------------------------------------------------
  PROCEDURE P_FREEZE_LG_ORDER_MESSAGE_JOB(IN_STAT_DATE IN DATE) IS
  BEGIN
    insert into intf_lg_order_message_detail
      (stat_date,
       entity_id,
       order_number,
       sys_source,
       source_order_id,
       order_date,
       order_head_state,
       order_line_state,
       customer_id,
       customer_code,
       customer_name,
       sales_center_id,
       sales_center_code,
       sales_center_name,
       item_code,
       send_list_price,
       send_discount_rate,
       ordered_discount_rate,
       lg_pln_unaffirm_qty_curr,
       pln_canaffirm_qty,
       lg_pln_unaffirm_qty_before,
       begin_date,
       end_date,
       created_by,
       creation_date,
       last_updated_by,
       last_update_date,
       account_id)
     SELECT IN_STAT_DATE,
             ENTITY_ID,
             ORDER_NUMBER,
             SYS_SOURCE,
             SOURCE_ORDER_ID,
             ORDER_DATE,
             ORDER_HEAD_STATE,
             ORDER_LINE_STATE,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             SALES_CENTER_ID,
             SALES_CENTER_CODE,
             SALES_CENTER_NAME,
             ITEM_CODE,
             SEND_LIST_PRICE,
             SEND_DISCOUNT_RATE,
             ORDERED_DISCOUNT_RATE,
             LG_PLN_UNAFFIRM_QTY_CURR,
             PLN_CANAFFIRM_QTY,
             LG_PLN_UNAFFIRM_QTY_BEFORE,
             BEGIN_DATE,
             END_DATE,
             'admin',
             SYSDATE,
             'admin',
             sysdate,
             ACCOUNT_ID
        FROM (
          SELECT H.ENTITY_ID,
                 H.ORDER_NUMBER,
                 H.SYS_SOURCE,
                 H.SOURCE_ORDER_ID,
                 H.ORDER_DATE,
                 H.ORDER_HEAD_STATE,
                 L.ORDER_LINE_STATE,
                 H.CUSTOMER_ID,
                 CH.CUSTOMER_CODE,
                 CH.CUSTOMER_NAME,
                 H.SALES_CENTER_ID,
                 OU.CODE SALES_CENTER_CODE,
                 OU.NAME SALES_CENTER_NAME,
                 H.ACCOUNT_ID,
                 L.ITEM_CODE,
                 L.PROJECT_ORDER_TYPE,
                 NVL(L.LIST_PRICE, 0) LIST_PRICE,
                 NVL(L.DISCOUNT_RATE, 0) DISCOUNT_RATE,
                 NVL(L.ORDERED_DISCOUNT_RATE, 0) ORDERED_DISCOUNT_RATE,
                 NVL(L.APPLY_LIST_PRICE, 0) APPLY_LIST_PRICE,
                 NVL(L.APPLY_DISCOUNT_RATE, 0) APPLY_DISCOUNT_RATE,
                 DECODE(L.PROJECT_ORDER_TYPE,
                        NULL,
                        NVL(L.LIST_PRICE, 0),
                        NVL(L.APPLY_LIST_PRICE, 0)) SEND_LIST_PRICE,
                 DECODE(L.PROJECT_ORDER_TYPE,
                        NULL,
                        NVL(L.DISCOUNT_RATE, 0),
                        NVL(L.APPLY_DISCOUNT_RATE, 0)) SEND_DISCOUNT_RATE,
                 L.CENTER_AFFIRM_QUANTITY,
                 L.HQ_AFFIRMED_QTY,
                 L.CENTER_AFFIRMED_QTY,
                 L.CANCEL_QTY,
                 NVL(L.TO_PLN_QTY, 0) TO_PLN_QTY,
                 NVL(L.PLN_AFFIRMED_QTY,0),  
                 CASE
                   WHEN NVL(L.IS_LOCK_AMOUNT, 'N') = 'NT' THEN 
                        LEAST(GREATEST(NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) - 
                        NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0), 
                        0), 
                        GREATEST(NVL(L.TO_PLN_QTY, 0) - NVL(L.PLN_AFFIRMED_QTY, 0), 0))
                   WHEN H.ORDER_HEAD_STATE IN ('304', '23') OR
                        L.ORDER_LINE_STATE = 'CLOSED' THEN
                    0
                   ELSE
                    LEAST(GREATEST(NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) -
                                   NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0) -
                                   (NVL(L.DIRECT_TRANSPORT_QTY, 0) - NVL(L.ALREADY_DIRECT_TRANSPORT_QTY, 0)),
                                   0),
                          GREATEST(NVL(L.TO_PLN_QTY, 0) - NVL(L.PLN_AFFIRMED_QTY, 0) -
                                   (NVL(L.DIRECT_TRANSPORT_QTY, 0) - NVL(L.ALREADY_DIRECT_TRANSPORT_QTY, 0)), 0))
                 END LG_PLN_UNAFFIRM_QTY_CURR,
                 OH.ORDER_NUMBER PLN_ORDER_NUMBER,
                 OL.INV_AFFIRM_QTY,
                 OL.SUPPLY_QTY,
                 GREATEST(NVL(OL.SHARE_QTY, 0) - NVL(OL.CARRY_QTY, 0),0) PLN_CANAFFIRM_QTY,
                 l.order_line_id,
                 OL.ORDER_LINE_ID,
                 OP.BEGIN_DATE,
                 OP.END_DATE,
                 NVL((Select Sum(CASE
                               WHEN NVL(L.IS_LOCK_AMOUNT, 'N') = 'NT' THEN 
                                    LEAST(GREATEST(NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) - 
                                    NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0), 
                                    0), 
                                    GREATEST(NVL(L.TO_PLN_QTY, 0) - NVL(L.PLN_AFFIRMED_QTY, 0), 0))
                               WHEN Loha.ORDER_HEAD_STATE IN ('304', '23') OR
                                    Lola.ORDER_LINE_STATE = 'CLOSED' THEN
                                0
                               ELSE
                                LEAST(GREATEST(NVL(Lola.CENTER_AFFIRM_QUANTITY, Lola.QUANTITY) -
                                               NVL(Lola.AFFIRMED_QUANTITY, 0) - NVL(Lola.CANCEL_QTY, 0) -
                                               (NVL(L.DIRECT_TRANSPORT_QTY, 0) - NVL(L.ALREADY_DIRECT_TRANSPORT_QTY, 0)),
                                               0),
                                      GREATEST(NVL(Lola.TO_PLN_QTY, 0) - NVL(Lola.PLN_AFFIRMED_QTY, 0) -
                                               (NVL(L.DIRECT_TRANSPORT_QTY, 0) - NVL(L.ALREADY_DIRECT_TRANSPORT_QTY, 0)), 0))
                             END)
                   From t_Pln_Lg_Order_Line Lola,
                        t_Pln_Lg_Order_Head Loha,
                        t_Pln_Lg_Relation   Plra,
                        t_Pln_Order_Head    Poha,
                        t_Pln_Order_Line    Pola
                  Where Loha.Order_Head_Id = Lola.Order_Head_Id
                    And Lola.Order_Line_Id = Plra.Lg_Order_Line_Id
                    And Lola.Order_Head_Id = Plra.Lg_Order_Head_Id
                    And Plra.Order_Line_Id = Pola.Order_Line_Id
                    And Plra.Order_Head_Id = Pola.Order_Head_Id
                    And Plra.Order_Head_Id = Poha.Order_Head_Id
                    And Plra.Relation_Type = 'T3_ORDER_TYPE'
                    And Poha.Form_State In ('32', '23', '306', '304')
                    And Plra.Order_Line_Id = ol.Order_Line_Id
                    And Plra.Lg_Order_Line_Id <> l.Order_Line_Id
                    And Loha.To_Checkup_Date <= h.To_Checkup_Date), 0) LG_PLN_UNAFFIRM_QTY_BEFORE
            FROM T_PLN_LG_ORDER_HEAD H,
                 T_PLN_LG_ORDER_LINE L,
                 T_PLN_ORDER_TYPE    T,
                 T_PLN_LG_RELATION   LR,
                 T_CUSTOMER_HEADER   CH,
                 UP_ORG_UNIT         OU,
                 T_PLN_ORDER_HEAD    OH,
                 T_PLN_ORDER_LINE    OL,
                 T_PLN_ORDER_PERIOD  OP
           WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
             AND H.ORDER_TYPE_ID = T.ORDER_TYPE_ID
             AND H.ORDER_HEAD_ID = LR.LG_ORDER_HEAD_ID
             AND L.ORDER_LINE_ID = LR.LG_ORDER_LINE_ID
             AND H.CUSTOMER_ID = CH.CUSTOMER_ID
             AND H.SALES_CENTER_ID = OU.UNIT_ID
             AND LR.ORDER_HEAD_ID = OH.ORDER_HEAD_ID
             AND LR.ORDER_LINE_ID = OL.ORDER_LINE_ID
             AND OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
             AND OH.PERIOD_ID = OP.PERIOD_ID
             AND LR.RELATION_TYPE = 'T3_ORDER_TYPE'
             AND CASE
                   WHEN NVL(L.IS_LOCK_AMOUNT, 'N') = 'NT' THEN 
                        LEAST(GREATEST(NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) - 
                        NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0), 
                        0), 
                        GREATEST(NVL(L.TO_PLN_QTY, 0) - NVL(L.PLN_AFFIRMED_QTY, 0), 0))
                   WHEN H.ORDER_HEAD_STATE IN ('304', '23') OR
                        L.ORDER_LINE_STATE = 'CLOSED' THEN
                    0
                   ELSE
                    LEAST(GREATEST(NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) -
                                   NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0) -
                                   (NVL(L.DIRECT_TRANSPORT_QTY, 0) - NVL(L.ALREADY_DIRECT_TRANSPORT_QTY, 0)),
                                   0),
                          GREATEST(NVL(L.TO_PLN_QTY, 0) - NVL(L.PLN_AFFIRMED_QTY, 0) -
                                   (NVL(L.DIRECT_TRANSPORT_QTY, 0) - NVL(L.ALREADY_DIRECT_TRANSPORT_QTY, 0)), 0))
                 END > 0);
  
    INSERT INTO INTF_LG_ORDER_MESSAGE (STAT_DATE,
                                       ENTITY_ID,
                                       CUSTOMER_ID,
                                       CUSTOMER_CODE,
                                       CUSTOMER_NAME,
                                       SALES_CENTER_ID,
                                       SALES_CENTER_CODE,
                                       SALES_CENTER_NAME,
                                       BILL_T3_AMOUNT,
                                       BILL_IN_AMOUNT,
                                       T3_START_DATE,
                                       T3_END_DATE,
                                       INTF_STATE,
                                       CREATED_BY,
                                       CREATION_DATE,
                                       LAST_UPDATED_BY,
                                       LAST_UPDATE_DATE,
                                       ACCOUNT_ID)
      SELECT IN_STAT_DATE,
             ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             SALES_CENTER_ID,
             SALES_CENTER_CODE,
             SALES_CENTER_NAME,
             SUM(ROUND(LG_PLN_UNAFFIRM_QTY_CURR * SEND_LIST_PRICE * (100 - SEND_DISCOUNT_RATE - ORDERED_DISCOUNT_RATE) / 100, 2)),
             SUM(ROUND(GREATEST(LEAST(PLN_CANAFFIRM_QTY - LG_PLN_UNAFFIRM_QTY_BEFORE, LG_PLN_UNAFFIRM_QTY_CURR), 0)
             * SEND_LIST_PRICE * (100 - SEND_DISCOUNT_RATE - ORDERED_DISCOUNT_RATE) / 100, 2)),
             BEGIN_DATE,
             END_DATE,
             'N',
             'admin',
             SYSDATE,
             'admin',
             sysdate,
             ACCOUNT_ID
        FROM intf_lg_order_message_detail
       where stat_date = IN_STAT_DATE
       GROUP BY ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             SALES_CENTER_ID,
             SALES_CENTER_CODE,
             SALES_CENTER_NAME,
             BEGIN_DATE,
             END_DATE,
             ACCOUNT_ID;
    
    INSERT INTO INTF_LG_ORDER_MESSAGE (STAT_DATE,
                                       ENTITY_ID,
                                       CUSTOMER_ID,
                                       CUSTOMER_CODE,
                                       CUSTOMER_NAME,
                                       SALES_CENTER_ID,
                                       SALES_CENTER_CODE,
                                       SALES_CENTER_NAME,
                                       BILL_T3_AMOUNT,
                                       BILL_IN_AMOUNT,
                                       T3_START_DATE,
                                       T3_END_DATE,
                                       INTF_STATE,
                                       CREATED_BY,
                                       CREATION_DATE,
                                       LAST_UPDATED_BY,
                                       LAST_UPDATE_DATE,
                                       ACCOUNT_ID)
      SELECT IN_STAT_DATE,
             oh.ENTITY_ID,
             oh.CUSTOMER_ID,
             ch.CUSTOMER_CODE,
             ch.CUSTOMER_NAME,
             oh.SALES_CENTER_ID,
             ou.code SALES_CENTER_CODE,
             ou.name SALES_CENTER_NAME,
             SUM(ROUND(--减去已锁定金额
                       case
                         when nvl(ol.is_lock_amount,'N') = 'Y' then 0
                         when oh.lock_amount_flag in ('S','HQ') then 
                           (100-nvl(oh.down_pay_scale,100))/100
                          else 1
                        end *
                       d.LG_PLN_UNAFFIRM_QTY_CURR *
                       decode(ol.project_order_type,
                              null,
                              nvl(ol.list_price, 0),
                              nvl(ol.apply_list_price, 0)) *
                       (100 - decode(ol.project_order_type,
                                     null,
                                     nvl(ol.discount_rate, 0),
                                     nvl(ol.apply_discount_rate, 0))
                            - nvl(ol.ORDERED_DISCOUNT_RATE, 0)) / 100, 2)),
             SUM(ROUND(GREATEST(LEAST(d.PLN_CANAFFIRM_QTY - d.LG_PLN_UNAFFIRM_QTY_BEFORE, d.LG_PLN_UNAFFIRM_QTY_CURR), 0)
                       * decode(ol.project_order_type,
                                null,
                                nvl(ol.list_price, 0),
                                nvl(ol.apply_list_price, 0)) *
                         (100 - decode(ol.project_order_type,
                                       null,
                                       nvl(ol.discount_rate, 0),
                                       nvl(ol.apply_discount_rate, 0))
                              - nvl(ol.ORDERED_DISCOUNT_RATE, 0)) / 100, 2)),
             d.BEGIN_DATE,
             d.END_DATE,
             'N',
             'admin',
             SYSDATE,
             'admin',
             sysdate,
             oh.account_id
        FROM intf_lg_order_message_detail d,
             t_pln_lg_order_head oh,
             t_pln_lg_order_line ol,
             t_customer_header ch,
             up_org_unit ou
       where d.stat_date = IN_STAT_DATE
         and d.sys_source = 'CIMS'
         and d.source_order_id = oh.order_head_id
         and oh.order_head_id = ol.order_head_id
         and d.item_code = ol.item_code
         and oh.customer_id = ch.customer_id
         and oh.sales_center_id = ou.unit_id
       GROUP BY oh.ENTITY_ID,
             oh.CUSTOMER_ID,
             ch.CUSTOMER_CODE,
             ch.CUSTOMER_NAME,
             oh.SALES_CENTER_ID,
             ou.code,
             ou.name,
             d.BEGIN_DATE,
             d.END_DATE,
             oh.account_id;
    
    --更新可用到款余额
    UPDATE INTF_LG_ORDER_MESSAGE M
       SET M.AVAILABLE_AMOUNT = NVL(PKG_CREDIT_TOOLS.F_GET_AMOUNT(M.ENTITY_ID,
                                                              M.CUSTOMER_ID,
                                                              M.ACCOUNT_ID,
                                                              NULL,
                                                              NULL,
                                                              1,
                                                              'ALL'), 0)
     WHERE M.STAT_DATE = IN_STAT_DATE;
    
    INSERT INTO SYM_INTF_CIMS_MESSAGE_PUSH (ID,
                                            SUP_CAT_ID,
                                            SUP_CUST_CODE,
                                            SUP_CUST_NAME,
                                            BILL_DATE,
                                            BILL_T3_AMOUNT,
                                            BILL_IN_AMOUNT,
                                            T3_START_DATE,
                                            T3_END_DATE,
                                            MAIL_STAT,
                                            MSG_STAT,
                                            CREATED_BY,
                                            CREATION_DATE,
                                            LAST_UPDATED_BY,
                                            LAST_UPDATE_DATE,
                                            SUP_DEPT_CODE,
                                            SUP_DEPT_NAME,
                                            AVAILABLE_AMOUNT)
     SELECT SYM_SQ_INTF_CIMS_MESSAGE_PUSH.NEXTVAL,
            M.ENTITY_ID,
            M.CUSTOMER_CODE,
            M.CUSTOMER_NAME,
            IN_STAT_DATE,
            M.BILL_T3_AMOUNT,
            M.BILL_IN_AMOUNT,
            M.T3_START_DATE,
            M.T3_END_DATE,
            1,
            1,
            'CIMS_JOB',
            SYSDATE,
            'CIMS_JOB',
            SYSDATE,
            M.SALES_CENTER_CODE,
            M.SALES_CENTER_NAME,
            M.AVAILABLE_AMOUNT
       FROM INTF_LG_ORDER_MESSAGE M
      WHERE M.STAT_DATE = IN_STAT_DATE
        AND M.INTF_STATE = 'N'
        AND M.BILL_T3_AMOUNT + M.BILL_IN_AMOUNT <> 0;
    
    UPDATE INTF_LG_ORDER_MESSAGE M
       SET M.INTF_STATE = 'Y'
     WHERE M.STAT_DATE = IN_STAT_DATE
       AND M.INTF_STATE = 'N';
    COMMIT;
    
    DELETE FROM intf_lg_order_message_detail D WHERE D.STAT_DATE = IN_STAT_DATE;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      Rollback;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'P_FREEZE_LG_ORDER_MESSAGE_JOB',
                                  p_Error_Msg            => '回款冻结异常：' || sqlerrm,
                                  p_Source_Order_Head_Id => NULL,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
      commit;
  END P_FREEZE_LG_ORDER_MESSAGE_JOB;

  ------------------------------------------------------------------------------------------------
  -- Author  : huanghb12
  -- Created : 2020-03-33
  -- Purpose : 回款提醒数据冻结:按主体冻结当前时间在订单所在周期的起始时间之后
  ------------------------------------------------------------------------------------------------
  PROCEDURE P_FREEZE_LG_ORDER_MESSAGE_INFO(IN_STAT_DATE IN DATE,P_ENTITY_ID IN NUMBER) IS
  BEGIN
    insert into intf_lg_order_message_detail
      (stat_date,
       entity_id,
       order_number,
       sys_source,
       source_order_id,
       order_date,
       order_head_state,
       order_line_state,
       customer_id,
       customer_code,
       customer_name,
       sales_center_id,
       sales_center_code,
       sales_center_name,
       item_code,
       send_list_price,
       send_discount_rate,
       ordered_discount_rate,
       lg_pln_unaffirm_qty_curr,
       pln_canaffirm_qty,
       lg_pln_unaffirm_qty_before,
       begin_date,
       end_date,
       created_by,
       creation_date,
       last_updated_by,
       last_update_date,
       account_id)
     SELECT IN_STAT_DATE,
             ENTITY_ID,
             ORDER_NUMBER,
             SYS_SOURCE,
             SOURCE_ORDER_ID,
             ORDER_DATE,
             ORDER_HEAD_STATE,
             ORDER_LINE_STATE,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             SALES_CENTER_ID,
             SALES_CENTER_CODE,
             SALES_CENTER_NAME,
             ITEM_CODE,
             SEND_LIST_PRICE,
             SEND_DISCOUNT_RATE,
             ORDERED_DISCOUNT_RATE,
             LG_PLN_UNAFFIRM_QTY_CURR,
             PLN_CANAFFIRM_QTY,
             LG_PLN_UNAFFIRM_QTY_BEFORE,
             BEGIN_DATE,
             END_DATE,
             'admin',
             SYSDATE,
             'admin',
             sysdate,
             ACCOUNT_ID
        FROM (
          SELECT H.ENTITY_ID,
                 H.ORDER_NUMBER,
                 H.SYS_SOURCE,
                 H.SOURCE_ORDER_ID,
                 H.ORDER_DATE,
                 H.ORDER_HEAD_STATE,
                 L.ORDER_LINE_STATE,
                 H.CUSTOMER_ID,
                 CH.CUSTOMER_CODE,
                 CH.CUSTOMER_NAME,
                 H.SALES_CENTER_ID,
                 OU.CODE SALES_CENTER_CODE,
                 OU.NAME SALES_CENTER_NAME,
                 H.ACCOUNT_ID,
                 L.ITEM_CODE,
                 L.PROJECT_ORDER_TYPE,
                 NVL(L.LIST_PRICE, 0) LIST_PRICE,
                 NVL(L.DISCOUNT_RATE, 0) DISCOUNT_RATE,
                 NVL(L.ORDERED_DISCOUNT_RATE, 0) ORDERED_DISCOUNT_RATE,
                 NVL(L.APPLY_LIST_PRICE, 0) APPLY_LIST_PRICE,
                 NVL(L.APPLY_DISCOUNT_RATE, 0) APPLY_DISCOUNT_RATE,
                 DECODE(L.PROJECT_ORDER_TYPE,
                        NULL,
                        NVL(L.LIST_PRICE, 0),
                        NVL(L.APPLY_LIST_PRICE, 0)) SEND_LIST_PRICE,
                 DECODE(L.PROJECT_ORDER_TYPE,
                        NULL,
                        NVL(L.DISCOUNT_RATE, 0),
                        NVL(L.APPLY_DISCOUNT_RATE, 0)) SEND_DISCOUNT_RATE,
                 L.CENTER_AFFIRM_QUANTITY,
                 L.HQ_AFFIRMED_QTY,
                 L.CENTER_AFFIRMED_QTY,
                 L.CANCEL_QTY,
                 NVL(L.TO_PLN_QTY, 0) TO_PLN_QTY,
                 NVL(L.PLN_AFFIRMED_QTY,0),  
                 CASE
                   WHEN NVL(L.IS_LOCK_AMOUNT, 'N') = 'NT' THEN 
                        LEAST(GREATEST(NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) - 
                        NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0), 
                        0), 
                        GREATEST(NVL(L.TO_PLN_QTY, 0) - NVL(L.PLN_AFFIRMED_QTY, 0), 0))
                   WHEN H.ORDER_HEAD_STATE IN ('304', '23') OR
                        L.ORDER_LINE_STATE = 'CLOSED' THEN
                    0
                   ELSE
                    LEAST(GREATEST(NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) -
                                   NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0) -
                                   (NVL(L.DIRECT_TRANSPORT_QTY, 0) - NVL(L.ALREADY_DIRECT_TRANSPORT_QTY, 0)),
                                   0),
                          GREATEST(NVL(L.TO_PLN_QTY, 0) - NVL(L.PLN_AFFIRMED_QTY, 0) -
                                   (NVL(L.DIRECT_TRANSPORT_QTY, 0) - NVL(L.ALREADY_DIRECT_TRANSPORT_QTY, 0)), 0))
                 END LG_PLN_UNAFFIRM_QTY_CURR,
                 OH.ORDER_NUMBER PLN_ORDER_NUMBER,
                 OL.INV_AFFIRM_QTY,
                 OL.SUPPLY_QTY,
                 GREATEST(NVL(OL.SHARE_QTY, 0) - NVL(OL.CARRY_QTY, 0),0) PLN_CANAFFIRM_QTY,
                 l.order_line_id,
                 OL.ORDER_LINE_ID,
                 OP.BEGIN_DATE,
                 OP.END_DATE,
                 NVL((Select Sum(CASE
                               WHEN NVL(L.IS_LOCK_AMOUNT, 'N') = 'NT' THEN 
                                    LEAST(GREATEST(NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) - 
                                    NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0), 
                                    0), 
                                    GREATEST(NVL(L.TO_PLN_QTY, 0) - NVL(L.PLN_AFFIRMED_QTY, 0), 0))
                               WHEN Loha.ORDER_HEAD_STATE IN ('304', '23') OR
                                    Lola.ORDER_LINE_STATE = 'CLOSED' THEN
                                0
                               ELSE
                                LEAST(GREATEST(NVL(Lola.CENTER_AFFIRM_QUANTITY, Lola.QUANTITY) -
                                               NVL(Lola.AFFIRMED_QUANTITY, 0) - NVL(Lola.CANCEL_QTY, 0) -
                                               (NVL(L.DIRECT_TRANSPORT_QTY, 0) - NVL(L.ALREADY_DIRECT_TRANSPORT_QTY, 0)),
                                               0),
                                      GREATEST(NVL(Lola.TO_PLN_QTY, 0) - NVL(Lola.PLN_AFFIRMED_QTY, 0) -
                                               (NVL(L.DIRECT_TRANSPORT_QTY, 0) - NVL(L.ALREADY_DIRECT_TRANSPORT_QTY, 0)), 0))
                             END)
                   From t_Pln_Lg_Order_Line Lola,
                        t_Pln_Lg_Order_Head Loha,
                        t_Pln_Lg_Relation   Plra,
                        t_Pln_Order_Head    Poha,
                        t_Pln_Order_Line    Pola
                  Where Loha.Order_Head_Id = Lola.Order_Head_Id
                    And Lola.Order_Line_Id = Plra.Lg_Order_Line_Id
                    And Lola.Order_Head_Id = Plra.Lg_Order_Head_Id
                    And Plra.Order_Line_Id = Pola.Order_Line_Id
                    And Plra.Order_Head_Id = Pola.Order_Head_Id
                    And Plra.Order_Head_Id = Poha.Order_Head_Id
                    And Plra.Relation_Type = 'T3_ORDER_TYPE'
                    And Poha.Form_State In ('32', '23', '306', '304')
                    And Plra.Order_Line_Id = ol.Order_Line_Id
                    And Plra.Lg_Order_Line_Id <> l.Order_Line_Id
                    And Loha.To_Checkup_Date <= h.To_Checkup_Date), 0) LG_PLN_UNAFFIRM_QTY_BEFORE
            FROM T_PLN_LG_ORDER_HEAD H,
                 T_PLN_LG_ORDER_LINE L,
                 T_PLN_ORDER_TYPE    T,
                 T_PLN_LG_RELATION   LR,
                 T_CUSTOMER_HEADER   CH,
                 UP_ORG_UNIT         OU,
                 T_PLN_ORDER_HEAD    OH,
                 T_PLN_ORDER_LINE    OL,
                 T_PLN_ORDER_PERIOD  OP
           WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
             AND H.ORDER_TYPE_ID = T.ORDER_TYPE_ID
             AND H.ORDER_HEAD_ID = LR.LG_ORDER_HEAD_ID
             AND L.ORDER_LINE_ID = LR.LG_ORDER_LINE_ID
             AND H.CUSTOMER_ID = CH.CUSTOMER_ID
             AND H.SALES_CENTER_ID = OU.UNIT_ID
             AND LR.ORDER_HEAD_ID = OH.ORDER_HEAD_ID
             AND LR.ORDER_LINE_ID = OL.ORDER_LINE_ID
             AND OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
             AND OH.PERIOD_ID = OP.PERIOD_ID
             AND LR.RELATION_TYPE = 'T3_ORDER_TYPE'
             --只获取当前时间所在周期的数据，且所款失败的数据
             And IN_STAT_DATE >= OP.Begin_Date
             AND NVL(OH.AMOUNT_LOCK_FLAG,'N') <> 'Y' --锁款失败
             AND H.ENTITY_ID = P_ENTITY_ID
             AND CASE
                   WHEN NVL(L.IS_LOCK_AMOUNT, 'N') = 'NT' THEN 
                        LEAST(GREATEST(NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) - 
                        NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0), 
                        0), 
                        GREATEST(NVL(L.TO_PLN_QTY, 0) - NVL(L.PLN_AFFIRMED_QTY, 0), 0))
                   WHEN H.ORDER_HEAD_STATE IN ('304', '23') OR
                        L.ORDER_LINE_STATE = 'CLOSED' THEN
                    0
                   ELSE
                    LEAST(GREATEST(NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) -
                                   NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0) -
                                   (NVL(L.DIRECT_TRANSPORT_QTY, 0) - NVL(L.ALREADY_DIRECT_TRANSPORT_QTY, 0)),
                                   0),
                          GREATEST(NVL(L.TO_PLN_QTY, 0) - NVL(L.PLN_AFFIRMED_QTY, 0) -
                                   (NVL(L.DIRECT_TRANSPORT_QTY, 0) - NVL(L.ALREADY_DIRECT_TRANSPORT_QTY, 0)), 0))
                 END > 0);
  
    INSERT INTO INTF_LG_ORDER_MESSAGE (STAT_DATE,
                                       ENTITY_ID,
                                       CUSTOMER_ID,
                                       CUSTOMER_CODE,
                                       CUSTOMER_NAME,
                                       SALES_CENTER_ID,
                                       SALES_CENTER_CODE,
                                       SALES_CENTER_NAME,
                                       BILL_T3_AMOUNT,
                                       BILL_IN_AMOUNT,
                                       T3_START_DATE,
                                       T3_END_DATE,
                                       INTF_STATE,
                                       CREATED_BY,
                                       CREATION_DATE,
                                       LAST_UPDATED_BY,
                                       LAST_UPDATE_DATE,
                                       ACCOUNT_ID)
      SELECT IN_STAT_DATE,
             ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             SALES_CENTER_ID,
             SALES_CENTER_CODE,
             SALES_CENTER_NAME,
             SUM(ROUND(LG_PLN_UNAFFIRM_QTY_CURR * SEND_LIST_PRICE * (100 - SEND_DISCOUNT_RATE - ORDERED_DISCOUNT_RATE) / 100, 2)),
             SUM(ROUND(GREATEST(LEAST(PLN_CANAFFIRM_QTY - LG_PLN_UNAFFIRM_QTY_BEFORE, LG_PLN_UNAFFIRM_QTY_CURR), 0)
             * SEND_LIST_PRICE * (100 - SEND_DISCOUNT_RATE - ORDERED_DISCOUNT_RATE) / 100, 2)),
             BEGIN_DATE,
             END_DATE,
             'N',
             'admin',
             SYSDATE,
             'admin',
             sysdate,
             ACCOUNT_ID
        FROM intf_lg_order_message_detail
       where stat_date = IN_STAT_DATE
       GROUP BY ENTITY_ID,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             SALES_CENTER_ID,
             SALES_CENTER_CODE,
             SALES_CENTER_NAME,
             BEGIN_DATE,
             END_DATE,
             ACCOUNT_ID;
    
    INSERT INTO INTF_LG_ORDER_MESSAGE (STAT_DATE,
                                       ENTITY_ID,
                                       CUSTOMER_ID,
                                       CUSTOMER_CODE,
                                       CUSTOMER_NAME,
                                       SALES_CENTER_ID,
                                       SALES_CENTER_CODE,
                                       SALES_CENTER_NAME,
                                       BILL_T3_AMOUNT,
                                       BILL_IN_AMOUNT,
                                       T3_START_DATE,
                                       T3_END_DATE,
                                       INTF_STATE,
                                       CREATED_BY,
                                       CREATION_DATE,
                                       LAST_UPDATED_BY,
                                       LAST_UPDATE_DATE,
                                       ACCOUNT_ID)
      SELECT IN_STAT_DATE,
             oh.ENTITY_ID,
             oh.CUSTOMER_ID,
             ch.CUSTOMER_CODE,
             ch.CUSTOMER_NAME,
             oh.SALES_CENTER_ID,
             ou.code SALES_CENTER_CODE,
             ou.name SALES_CENTER_NAME,
             SUM(ROUND(
                      --减去已锁定金额
                       case
                         when nvl(ol.is_lock_amount,'N') = 'Y' then 0
                         when oh.lock_amount_flag in ('S','HQ') then 
                           (100-nvl(oh.down_pay_scale,100))/100
                          else 1
                        end *
                       d.LG_PLN_UNAFFIRM_QTY_CURR *
                       decode(ol.project_order_type,
                              null,
                              nvl(ol.list_price, 0),
                              nvl(ol.apply_list_price, 0)) *
                       (100 - decode(ol.project_order_type,
                                     null,
                                     nvl(ol.discount_rate, 0),
                                     nvl(ol.apply_discount_rate, 0))
                            - nvl(ol.ORDERED_DISCOUNT_RATE, 0)) / 100, 2)),
             SUM(ROUND(GREATEST(LEAST(d.PLN_CANAFFIRM_QTY - d.LG_PLN_UNAFFIRM_QTY_BEFORE, d.LG_PLN_UNAFFIRM_QTY_CURR), 0)
                       * decode(ol.project_order_type,
                                null,
                                nvl(ol.list_price, 0),
                                nvl(ol.apply_list_price, 0)) *
                         (100 - decode(ol.project_order_type,
                                       null,
                                       nvl(ol.discount_rate, 0),
                                       nvl(ol.apply_discount_rate, 0))
                              - nvl(ol.ORDERED_DISCOUNT_RATE, 0)) / 100, 2)),
             d.BEGIN_DATE,
             d.END_DATE,
             'N',
             'admin',
             SYSDATE,
             'admin',
             sysdate,
             oh.account_id
        FROM intf_lg_order_message_detail d,
             t_pln_lg_order_head oh,
             t_pln_lg_order_line ol,
             t_customer_header ch,
             up_org_unit ou
       where d.stat_date = IN_STAT_DATE
         and d.sys_source = 'CIMS'
         and d.source_order_id = oh.order_head_id
         and oh.order_head_id = ol.order_head_id
         and d.item_code = ol.item_code
         and oh.customer_id = ch.customer_id
         and oh.sales_center_id = ou.unit_id
       GROUP BY oh.ENTITY_ID,
             oh.CUSTOMER_ID,
             ch.CUSTOMER_CODE,
             ch.CUSTOMER_NAME,
             oh.SALES_CENTER_ID,
             ou.code,
             ou.name,
             d.BEGIN_DATE,
             d.END_DATE,
             oh.account_id;
    
    --更新可用到款余额
    UPDATE INTF_LG_ORDER_MESSAGE M
       SET M.AVAILABLE_AMOUNT = NVL(PKG_CREDIT_TOOLS.F_GET_AMOUNT(M.ENTITY_ID,
                                                              M.CUSTOMER_ID,
                                                              M.ACCOUNT_ID,
                                                              NULL,
                                                              NULL,
                                                              1,
                                                              'ALL'), 0)
     WHERE M.STAT_DATE = IN_STAT_DATE;
    
    INSERT INTO SYM_INTF_CIMS_MESSAGE_PUSH (ID,
                                            SUP_CAT_ID,
                                            SUP_CUST_CODE,
                                            SUP_CUST_NAME,
                                            BILL_DATE,
                                            BILL_T3_AMOUNT,
                                            BILL_IN_AMOUNT,
                                            T3_START_DATE,
                                            T3_END_DATE,
                                            MAIL_STAT,
                                            MSG_STAT,
                                            CREATED_BY,
                                            CREATION_DATE,
                                            LAST_UPDATED_BY,
                                            LAST_UPDATE_DATE,
                                            SUP_DEPT_CODE,
                                            SUP_DEPT_NAME,
                                            AVAILABLE_AMOUNT)
     SELECT SYM_SQ_INTF_CIMS_MESSAGE_PUSH.NEXTVAL,
            M.ENTITY_ID,
            M.CUSTOMER_CODE,
            M.CUSTOMER_NAME,
            IN_STAT_DATE,
            M.BILL_T3_AMOUNT,
            M.BILL_IN_AMOUNT,
            M.T3_START_DATE,
            M.T3_END_DATE,
            1,
            1,
            'CIMS_JOB',
            SYSDATE,
            'CIMS_JOB',
            SYSDATE,
            M.SALES_CENTER_CODE,
            M.SALES_CENTER_NAME,
            M.AVAILABLE_AMOUNT
       FROM INTF_LG_ORDER_MESSAGE M
      WHERE M.STAT_DATE = IN_STAT_DATE
        AND M.INTF_STATE = 'N'
        AND M.BILL_T3_AMOUNT + M.BILL_IN_AMOUNT <> 0;
    
    UPDATE INTF_LG_ORDER_MESSAGE M
       SET M.INTF_STATE = 'Y'
     WHERE M.STAT_DATE = IN_STAT_DATE
       AND M.INTF_STATE = 'N';
    COMMIT;
    
    DELETE FROM intf_lg_order_message_detail D WHERE D.STAT_DATE = IN_STAT_DATE;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      Rollback;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'P_FREEZE_LG_ORDER_MESSAGE_INFO',
                                  p_Error_Msg            => '回款冻结异常：' || sqlerrm,
                                  p_Source_Order_Head_Id => NULL,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
      commit;
  END P_FREEZE_LG_ORDER_MESSAGE_INFO;
  ------------------------------------------------------------------------------------------------
  -- Author  : hejy3
  -- Created : 2018-05-08
  -- Purpose : 协同仓未评审订单占用面积冻结
  ------------------------------------------------------------------------------------------------
  PROCEDURE P_FREEZE_CUST_OCCUPY_AREA(IN_ENTITY_ID IN NUMBER DEFAULT -1)
  IS
  BEGIN
    DELETE FROM T_PLN_CUST_OCCUPY_AREA A WHERE 1=1 AND (A.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1);
    
    INSERT INTO T_PLN_CUST_OCCUPY_AREA
     (ENTITY_ID,
      CUSTOMER_ID,
      CUSTOMER_CODE,
      CUSTOMER_NAME,
      ADDRESS,
      ADDRESS_ID,
      OCCUPY_AREA,
      CREATED_BY,
      CREATION_DATE)
    SELECT NVL(ME.MERGE_ENTITY_ID, H.ENTITY_ID) ENTITY_ID,
           H.CUSTOMER_ID,
           CH.CUSTOMER_CODE,
           CH.CUSTOMER_NAME,
           A.ADDRESS,
           A.SIEBEL_ADDRESS_ID,
           SUM(NVL(BI.ITEM_PLOT_RATIO, 0) *
               CASE
                 WHEN H.ORDER_HEAD_STATE IN ('20', '2225', '1455') AND H.HQ_LG_ORDER_HEAD_ID IS NULL THEN
                   L.QUANTITY - NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0)
                 ELSE
                   NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) - NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0)
               END) OCCUPY_QTY,
           'PLN_JOB',
           SYSDATE
      FROM T_PLN_LG_ORDER_HEAD H,
           T_PLN_LG_ORDER_LINE L,
           T_BD_ITEM BI,
           T_CUSTOMER_ADDRESS A,
           (SELECT C.ENTITY_ID, MIN(C.CODE_VALUE) MERGE_ENTITY_ID
              FROM V_UP_CODELIST C
             WHERE C.CODETYPE = 'plnMergeEntity'
               GROUP BY C.ENTITY_ID) ME,
           T_CUSTOMER_HEADER CH
     WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
       AND L.ITEM_ID = BI.ITEM_ID
       AND H.CONSIGNEE_ID = A.ADDRESS_ID
       AND H.CUSTOMER_ID = CH.CUSTOMER_ID
       AND A.PRE_FIELD_04 = 'Y' --协同仓
       AND H.TO_CHECKUP_DATE BETWEEN ADD_MONTHS(SYSDATE, -6) AND SYSDATE --6个月内
       AND H.ORDER_HEAD_STATE NOT IN ('19', '304', '23', '415') --非制单、已关闭、评审完毕、已驳回状态
       AND NVL(L.ORDER_LINE_STATE, 'NORMAL') <> 'CLOSED' --行状态非已关闭
       AND EXISTS (SELECT 1 FROM T_PLN_ORDER_TYPE T
                    WHERE T.ORDER_TYPE_ID = H.ORDER_TYPE_ID
                      AND T.SOURCE_ORDER_TYPE_ID = 1 --提货订单
                      AND UPPER(NVL(T.IS_BUSINESS_CONTROL, '_')) <> 'PRO_ORDER') --非推广物料提货订单
       AND H.ENTITY_ID = ME.ENTITY_ID(+)
       AND (H.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1)
     GROUP BY NVL(ME.MERGE_ENTITY_ID, H.ENTITY_ID),
             H.CUSTOMER_ID,
             CH.CUSTOMER_CODE,
             CH.CUSTOMER_NAME,
             A.ADDRESS,
             A.SIEBEL_ADDRESS_ID;
    commit;
  EXCEPTION
    WHEN OTHERS THEN
      Rollback;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'P_FREEZE_CUST_OCCUPY_AREA',
                                  p_Error_Msg            => '协同仓未评审订单占用面积冻结：' || sqlerrm,
                                  p_Source_Order_Head_Id => NULL,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
      commit;
  END P_FREEZE_CUST_OCCUPY_AREA;
  ----------------------------------------------------------------------
  -- Author  : huanghb12
  -- Created : 2018/05/10 
  -- Purpose : 冻结库存水位        
  ----------------------------------------------------------------------
PROCEDURE P_FREEZE_INV_LEVEL(P_SO_DATE_FROM IN VARCHAR2,
                                P_SO_DATE_TO   IN VARCHAR2,
                                P_ENEITY_ID    IN VARCHAR2,
                                P_RESULT       OUT VARCHAR2) IS

  V_VALUE VARCHAR2(500); --存储信息

  BEGIN
    P_RESULT := V_SUCCESS;
    --第0步：同步冻结库存水位表与正式库存水位表行信息
    V_VALUE  := '更新或者插入在存数据';
    MERGE INTO T_INV_INVENTORIES_LEVEL TL
    USING (
           --获得正式库存水位表库存和产品信息
           SELECT DISTINCT T1.INVENTORY_ID, --库存ID
                   T1.ITEM_ID, --产品ID
                   T1.ENTITY_ID
             FROM CIMS.T_PLN_INV_LEVEL   T1 --库存水位正式表
             WHERE T1.ENTITY_ID = P_ENEITY_ID
            ) UT
    ON (UT.INVENTORY_ID = TL.INVENTORY_ID AND UT.ITEM_ID = TL.ITEM_ID AND UT.ENTITY_ID = TL.ENTITY_ID)
    WHEN NOT MATCHED THEN --如果匹配，则什么也不做，如果不匹配，则新增一行
      INSERT
        (TL.ID,
         TL.INVENTORY_ID,
         TL.ITEM_ID,
         TL.ENTITY_ID,
         TL.ON_ROAD_QUANTITY,
         TL.IN_QUANTITY, --插入在存数量
         TL.AVG_OUT_QUANTITY,
         TL.CREATED_BY,
         TL.CREATION_DATE,
         TL.LAST_UPDATED_BY,
         TL.LAST_UPDATE_DATE)
      VALUES
        (S_INV_INVENTORIES_LEVEL.NEXTVAL,
         UT.INVENTORY_ID,
         UT.ITEM_ID,
         UT.ENTITY_ID,
         0,
         0,
         0,
         'PROGRAM',
         SYSDATE,
         'PROGRAM',
         SYSDATE);
    
    --第一步，更新或者插入在途数据
    V_VALUE  := '更新或者插入在途数据';
    MERGE INTO CIMS.T_INV_INVENTORIES_LEVEL TL
    USING (SELECT UA.INVENTORY_ID, UA.ENTITY_ID, UA.ITEM_ID, SUM(ON_ROAD_QUANTITY) ON_ROAD_QUANTITY
             FROM (
            WITH ORDER_INV_TEMP AS(
            SELECT  /*+index(I U_PLN_INV_LEVEL_N01)*/ I.INVENTORY_ID, --收货仓库
                    /*+index(T I_PLN_LGORDER_HEAD_N04)*/ T.ORDER_DATE,
                    T.ORDER_HEAD_STATE,
                    T.ORDER_HEAD_ID,
                    T.ORDER_NUMBER,
                    I.ITEM_ID,
                    i.item_code,
                    L.QUANTITY,
                    L.AFFIRMED_QUANTITY,
                    L.CENTER_AFFIRM_QUANTITY,
                    L.ORDER_LINE_STATE,
                    L.CANCEL_QTY,
                    T.ENTITY_ID
              FROM CIMS.T_PLN_LG_ORDER_HEAD T,
                   CIMS.T_PLN_LG_ORDER_LINE L,
                   CIMS.T_PLN_ORDER_TYPE OT,
                   CIMS.T_PLN_INV_LEVEL   I --库存水位正式表
             WHERE 1=1            --库存水位正式表中的产品id
               AND I.INVENTORY_ID = T.INVENTORY_TO_ID --库存水位正式表中的仓库id
               AND I.ENTITY_ID = T.ENTITY_ID
               AND T.ORDER_HEAD_ID = L.ORDER_HEAD_ID
               AND I.ITEM_ID = L.ITEM_ID
                  --获取需要维护库存水平的订单类型ID
               AND OT.Is_Inv_Level_Control = 'Y'
               AND OT.ENTITY_ID = T.ENTITY_ID
               AND T.ORDER_TYPE_ID =OT.ORDER_TYPE_ID
               AND T.ENTITY_ID = P_ENEITY_ID
               AND T.Order_Date BETWEEN TO_DATE(P_SO_DATE_FROM,'YYYY-MM-DD HH24:MI:SS') AND TO_DATE(P_SO_DATE_TO,'YYYY-MM-DD HH24:MI:SS') --给定的时间段内的销售数据，前6个月的数据
            ) 
                SELECT T.INVENTORY_ID, --收货仓库
                    T.ITEM_ID, --产品ID
                    CASE
                    --23-评审完毕 20-已送审 1455-中心发货 679-已中心评审  381-部分评审 23-评审完毕  2225-中心发货状态
                    --如果状态是20  1455 2225 申请数量-已评审的数量-已取消的数量
                      WHEN T.ORDER_HEAD_STATE IN ('20','1455','2225') THEN
                       NVL(T.QUANTITY, 0) - NVL(T.AFFIRMED_QUANTITY, 0) - NVL(T.CANCEL_QTY, 0)
                    --如果状态是679 381 中心接单量-已评审的数量-已取消的数量
                      WHEN T.ORDER_HEAD_STATE IN ('679','381') THEN
                       NVL(T.CENTER_AFFIRM_QUANTITY, 0) - NVL(T.AFFIRMED_QUANTITY, 0) - NVL(T.CANCEL_QTY, 0)
                    END ON_ROAD_QUANTITY,
                    T.ENTITY_ID
                FROM ORDER_INV_TEMP T
                WHERE 1=1
                --未完成评审的数据 23-评审完毕 20-已送审 1455-中心发货 679-已中心评审  381-部分评审 23-评审完毕  2225-不考虑中心发货状态
                AND T.ORDER_HEAD_STATE IN ('679', '381', '20', '1455', '2225')
                AND NVL(T.ORDER_LINE_STATE,'NORMAL') <> 'CLOSED'
            UNION ALL
                SELECT T.INVENTORY_ID, --收货仓库
                       T.ITEM_ID, --产品ID
                       NVL(P.UNAFFIRM_QTY, 0) ON_ROAD_QUANTITY, --未确认数量
                       P.ENTITY_ID
                  FROM CIMS.T_LG_SHIP_PLAN P
                  ,ORDER_INV_TEMP T
                  WHERE 1=1
                   AND T.INVENTORY_ID = P.CONSIGNEE_INVENTORY_ID --物流订单中维护的 收货仓库ID（？调拨使用）
                   AND P.ITEM_CODE = T.ITEM_CODE
                   AND P.ENTITY_ID = T.ENTITY_ID
                   --如果p.origin_origin_order_code存在（转T+3类型），则取该值，如果不存在，则取p.origin_order_num
                   and p.origin_type in ('02','03') --来源单号是02-提货订单或者03-调拨单
                   AND p.origin_order_num = T.ORDER_NUMBER
                   AND P.STATUS IN ('00', '01') --00 未分配 01-已分配 02-已确认（最终确认后会生成发货通知单）
            UNION ALL
                SELECT T.INVENTORY_ID, --收货仓库
                       T.ITEM_ID, --产品ID
                       NVL(P.UNAFFIRM_QTY, 0) ON_ROAD_QUANTITY, --未确认数量
                       P.ENTITY_ID
                  FROM CIMS.T_LG_SHIP_PLAN P
                  ,ORDER_INV_TEMP T
                  WHERE 1=1
                   AND T.INVENTORY_ID = P.CONSIGNEE_INVENTORY_ID --物流订单中维护的 收货仓库ID（？调拨使用）
                   AND P.ITEM_CODE = T.ITEM_CODE
                   AND P.ENTITY_ID = T.ENTITY_ID
                   --如果p.origin_origin_order_code存在（转T+3类型），则取该值，如果不存在，则取p.origin_order_num
                   and p.origin_origin_type = '02' --来源单号是02-提货订单或者03-调拨单
                   AND p.origin_origin_order_code = T.ORDER_NUMBER
                   AND P.STATUS IN ('00', '01') --00 未分配 01-已分配 02-已确认（最终确认后会生成发货通知单） 
            UNION ALL
                --查询发货通知单中未发出的货物数量
                SELECT S.CONSIGNEE_INVENTORY_ID INVENTORY_ID, --收货仓库
                      T.ITEM_ID,
                      --产品数量- 实际发货数量 - 已取消数量 = 在途数量
                      NVL(SL.ITEM_QTY, 0)- NVL(sl.fact_ship_qty,0) - NVL(sl.cancel_qty,0) ON_ROAD_QUANTITY, --产品数量
                      T.ENTITY_ID
                 FROM CIMS.T_LG_SHIP_DOC      S,
                      CIMS.T_LG_SHIP_DOC_LINE SL,
                      ORDER_INV_TEMP T
                 WHERE 1 = 1
                  AND SL.SHIP_DOC_ID = S.SHIP_DOC_ID
                  AND T.INVENTORY_ID = S.CONSIGNEE_INVENTORY_ID --物流订单中维护的 收货仓库ID（？调拨使用）
                  AND T.ENTITY_ID = S.ENTITY_ID
                  AND SL.ITEM_CODE = T.ITEM_CODE
                  and SL.origin_type in ('02','03') --来源单号是02-提货订单或者03-调拨单
                  AND SL.ORIGIN_ORDER_NUM = T.order_number
                  and s.doc_status = '00' --非红冲单,只取非红冲单
            UNION ALL
                --查询发货通知单中未发出的货物数量
                SELECT S.CONSIGNEE_INVENTORY_ID INVENTORY_ID, --收货仓库
                      T.ITEM_ID,
                      --产品数量- 实际发货数量 - 已取消数量 = 在途数量
                      NVL(SL.ITEM_QTY, 0)- NVL(sl.fact_ship_qty,0) - NVL(sl.cancel_qty,0) ON_ROAD_QUANTITY, --产品数量
                      T.ENTITY_ID
                 FROM CIMS.T_LG_SHIP_DOC      S,
                      CIMS.T_LG_SHIP_DOC_LINE SL,
                      ORDER_INV_TEMP T
                 WHERE 1 = 1
                  AND SL.SHIP_DOC_ID = S.SHIP_DOC_ID
                  AND T.INVENTORY_ID = S.CONSIGNEE_INVENTORY_ID --物流订单中维护的 收货仓库ID（？调拨使用）
                  AND T.ENTITY_ID = S.ENTITY_ID
                  AND SL.ITEM_CODE = T.ITEM_CODE
                  and SL.origin_origin_type = '02' --来源单号是02-提货订单或者03-调拨单
                  AND SL.origin_origin_DOC_code = T.order_number
                  and s.doc_status = '00' --非红冲单,只取非红冲单          
               ) UA
            GROUP BY (UA.INVENTORY_ID,UA.ITEM_ID,UA.ENTITY_ID)) UT
    ON (UT.INVENTORY_ID = TL.INVENTORY_ID AND UT.ITEM_ID = TL.ITEM_ID AND TL.ENTITY_ID = UT.ENTITY_ID)
    WHEN MATCHED THEN
      UPDATE --更新在存产品数量
         SET TL.ON_ROAD_QUANTITY = UT.ON_ROAD_QUANTITY
    WHEN NOT MATCHED THEN
      INSERT
        (TL.ID,
         TL.INVENTORY_ID,
         TL.ITEM_ID,
         TL.ENTITY_ID,
         TL.ON_ROAD_QUANTITY,
         TL.IN_QUANTITY,
         TL.AVG_OUT_QUANTITY,
         TL.CREATED_BY,
         TL.CREATION_DATE,
         TL.LAST_UPDATED_BY,
         TL.LAST_UPDATE_DATE)
      VALUES
        (S_INV_INVENTORIES_LEVEL.NEXTVAL,
         UT.INVENTORY_ID,
         UT.ITEM_ID,
         UT.ENTITY_ID,
         UT.ON_ROAD_QUANTITY,
         0,
         0,
         'PROGRAM',
         SYSDATE,
         'PROGRAM',
         SYSDATE);
    
    --第二步，更新或者插入在存数据
    V_VALUE  := '更新或者插入在存数据';
    MERGE INTO T_INV_INVENTORIES_LEVEL TL
    USING (
            --获得中心仓库的现有库存量
            SELECT UA.INVENTORY_ID,
                   UA.ITEM_ID,
                   UA.ENTITY_ID,
                   SUM(IN_QUANTITY) IN_QUANTITY
              from (SELECT T1.INVENTORY_ID, --库存ID
                           T1.ITEM_ID, --产品ID
                           T1.ENTITY_ID,
                           NVL(T1.QUANTITY, 0) IN_QUANTITY --在库数量
                      FROM CIMS.T_INV_ONHAND T1, CIMS.T_PLN_INV_LEVEL T2 --库存水位正式表
                     WHERE T1.INVENTORY_ID = T2.INVENTORY_ID
                       AND T1.ITEM_ID = T2.ITEM_ID
                       AND T1.ENTITY_ID = T2.ENTITY_ID
                       AND T2.ENTITY_ID = P_ENEITY_ID
                     UNION ALL
                    --获得已经发货，也就是发车了，在路上的产品，还没有收货的数量   
                    select T3.INVENTORY_ID, --库存ID
                           T1.ITEM_ID, --产品ID
                           T1.ENTITY_ID,
                           NVL(T1.QUANTITY, 0) IN_QUANTITY --在途数量
                      from CIMS.T_INV_ONHAND      T1,
                           cims.t_inv_inventories t2,
                           CIMS.T_PLN_INV_LEVEL   T3
                     where t3.inventory_id = t2.inventory_id
                       and t2.onway_inventory_id = t1.inventory_id
                       AND T1.ITEM_ID = T3.ITEM_ID
                       AND T1.ENTITY_ID = T3.ENTITY_ID
                       AND T3.ENTITY_ID = P_ENEITY_ID
                    ) UA
             GROUP BY (UA.INVENTORY_ID, UA.ITEM_ID, UA.ENTITY_ID)
            ) UT
    ON (UT.INVENTORY_ID = TL.INVENTORY_ID AND UT.ITEM_ID = TL.ITEM_ID AND UT.ENTITY_ID = TL.ENTITY_ID)
    WHEN MATCHED THEN
      UPDATE --更新在存产品数量
         SET TL.IN_QUANTITY = UT.IN_QUANTITY
    WHEN NOT MATCHED THEN
      INSERT
        (TL.ID,
         TL.INVENTORY_ID,
         TL.ITEM_ID,
         TL.ENTITY_ID,
         TL.ON_ROAD_QUANTITY,
         TL.IN_QUANTITY, --插入在存数量
         TL.AVG_OUT_QUANTITY,
         TL.CREATED_BY,
         TL.CREATION_DATE,
         TL.LAST_UPDATED_BY,
         TL.LAST_UPDATE_DATE)
      VALUES
        (S_INV_INVENTORIES_LEVEL.NEXTVAL,
         UT.INVENTORY_ID,
         UT.ITEM_ID,
         UT.ENTITY_ID,
         0,
         UT.IN_QUANTITY,
         0,
         'PROGRAM',
         SYSDATE,
         'PROGRAM',
         SYSDATE);
         
    COMMIT;
    --第四步，获取所有产品的销售数据，保存到事务级临时表中
    V_VALUE  := '获取所有产品的销售数据，保存到事务级临时表中T_SO_INV_HEADER_TMP';
    --插入临时表T_SO_INV_HEADER_TMP
    INSERT INTO CIMS.T_SO_INV_HEADER_TMP
      (ID, INVENTORY_ID, ENTITY_ID, ITEM_ID, OUT_QUANTITY, SO_DATE_CHAR)
      SELECT S_T_SO_INV_HEADER_TMP.NEXTVAL,
             SO.INVENTORY_ID,
             SO.ENTITY_ID,
             SO.ITEM_ID,
             SO.OUT_QUANTITY,
             SO.SO_DATE_CHAR
        FROM (
              --统计销售情况，根据销售单 销售红冲单 退货单 退货红冲单确定
              With SO_HEADER AS(
                 select H.BIZ_SRC_BILL_TYPE_CODE
                        ,H.SHIP_INV_ID
                        ,H.CONSIGNEE_INV_ID
                        ,/*+index(H IDX_SO_HEADER_01)*/ H.SO_DATE
                        ,H.ENTITY_ID
                        ,H.SO_HEADER_ID
                   FROM CIMS.T_SO_HEADER H
                    WHERE  1=1
                    AND H.SO_DATE BETWEEN TO_DATE(P_SO_DATE_FROM,'YYYY-MM-DD HH24:MI:SS') AND TO_DATE(P_SO_DATE_TO,'YYYY-MM-DD HH24:MI:SS') --给定的时间段内的销售数据，前6个月的数据
                    --单据类型 --'1003'-销售退货, '1004'-销售退货红冲， '1001'-销售单 , '1002'-销售红冲 
                   AND H.BIZ_SRC_BILL_TYPE_CODE IN ('1001', '1002', '1003', '1004')
                   AND H.ENTITY_ID = P_ENEITY_ID
              ) SELECT I.INVENTORY_ID, --中心仓ID
                      I.ITEM_ID, --产品ID
                      H.ENTITY_ID,
                      --TO_CHAR(H.SO_DATE, 'YYYY-MM') SO_DATE_CHAR,--截取年月，用于统计产品销售及退货行为发生月数，用于求平均值
                      TO_CHAR(H.SO_DATE, 'IYIW') SO_DATE_CHAR, --获取日期所在的年份的周，用于统计产品销售及退货行为发生周数，用于周求平均值
                      CASE
                        WHEN H.BIZ_SRC_BILL_TYPE_CODE IN('1001','1004') THEN --销售单就是出货  退货红冲，也即是本来要退货的后面又不退了
                         NVL(SL.ITEM_QTY, 0) --  最终出货数量 = 正 产品数量
                        WHEN H.BIZ_SRC_BILL_TYPE_CODE IN('1003','1002') THEN --销售退货 销售红冲单
                         -NVL(SL.ITEM_QTY, 0) --最终出货数量 = 负 退货数量
                      END OUT_QUANTITY --总出仓的数量
                FROM CIMS.T_SO_LINE SL
                     ,SO_HEADER H
                     ,CIMS.T_PLN_INV_LEVEL I
               WHERE 1 = 1
                 AND SL.SO_HEADER_ID = H.SO_HEADER_ID
                 AND SL.ITEM_ID = I.ITEM_ID
                 AND H.SHIP_INV_ID = I.INVENTORY_ID  --收货仓或者发货仓库必须是中心仓库类型
                 AND H.ENTITY_ID = I.ENTITY_ID
                 AND H.BIZ_SRC_BILL_TYPE_CODE IN('1001','1002')
              UNION ALL 
                SELECT I.INVENTORY_ID, --中心仓ID
                      I.ITEM_ID, --产品ID
                      H.ENTITY_ID,
                      --TO_CHAR(H.SO_DATE, 'YYYY-MM') SO_DATE_CHAR,--截取年月，用于统计产品销售及退货行为发生月数，用于求平均值
                      TO_CHAR(H.SO_DATE, 'IYIW') SO_DATE_CHAR, --获取日期所在的年份的周，用于统计产品销售及退货行为发生周数，用于周求平均值
                      CASE
                        WHEN H.BIZ_SRC_BILL_TYPE_CODE IN('1001','1004') THEN --销售单就是出货  退货红冲，也即是本来要退货的后面又不退了
                         NVL(SL.ITEM_QTY, 0) --  最终出货数量 = 正 产品数量
                        WHEN H.BIZ_SRC_BILL_TYPE_CODE IN('1003','1002') THEN --销售退货 销售红冲单
                         -NVL(SL.ITEM_QTY, 0) --最终出货数量 = 负 退货数量
                      END OUT_QUANTITY --总出仓的数量
                FROM CIMS.T_SO_LINE SL
                     ,SO_HEADER H
                     ,CIMS.T_PLN_INV_LEVEL I
               WHERE 1 = 1
                 AND SL.SO_HEADER_ID = H.SO_HEADER_ID
                 AND SL.ITEM_ID = I.ITEM_ID
                 AND H.CONSIGNEE_INV_ID = I.INVENTORY_ID  --收货仓或者发货仓库必须是中心仓库类型
                 AND H.ENTITY_ID = I.ENTITY_ID
                 AND H.BIZ_SRC_BILL_TYPE_CODE IN('1003','1004')
                 ) SO;

    --第五步，通过上表，计算周平均销量（产品销售总量/销售发生的周数），再并入到库存水位表中
    V_VALUE  := '计算月平均销量，再并入到库存水位表中';
    MERGE INTO T_INV_INVENTORIES_LEVEL TL
    USING (
           --计算月平均销量
           SELECT T.INVENTORY_ID,
                  T.ENTITY_ID,
                  T.ITEM_ID,
                  CASE 
                    --当分子为0 
                    WHEN SUM(T.OUT_QUANTITY) = 0 THEN 0
                    --当分母为0
                    WHEN COUNT(DISTINCT T.SO_DATE_CHAR) = 0 THEN 0
                    ELSE (SUM(T.OUT_QUANTITY) / (COUNT(DISTINCT T.SO_DATE_CHAR)))
                  END AVG_OUT_QUANTITY
             FROM CIMS.T_SO_INV_HEADER_TMP T
             where T.ENTITY_ID = P_ENEITY_ID
            GROUP BY (T.INVENTORY_ID, T.ITEM_ID, T.ENTITY_ID)) UT
    ON (UT.INVENTORY_ID = TL.INVENTORY_ID AND UT.ITEM_ID = TL.ITEM_ID AND TL.ENTITY_ID = UT.ENTITY_ID)
    WHEN MATCHED THEN
      UPDATE --更新在存产品数量
         SET TL.AVG_OUT_QUANTITY = UT.AVG_OUT_QUANTITY;

    --第六步，计算库存水位，并更新到T_INV_INVENTORIES_LEVEL
    V_VALUE  := '计算库存水位，并更新到T_INV_INVENTORIES_LEVEL'; 
    MERGE INTO T_INV_INVENTORIES_LEVEL TL
    USING (
           --计算库存水位
           SELECT T.INVENTORY_ID,
                  T.ENTITY_ID,
                  T.ITEM_ID,
                  --计算库存水位TEMP_LEVEL
                  CASE 
                    --当分子为0时，库存水平为0
                    WHEN (T.ON_ROAD_QUANTITY + T.In_Quantity) = 0 THEN 0
                    --当分子不为0时，分母为0时，库存水平为无穷大，将结果也设置为9999，
                    WHEN T.AVG_OUT_QUANTITY = 0 THEN 9999
                    ELSE ROUND((T.ON_ROAD_QUANTITY + T.In_Quantity)/T.AVG_OUT_QUANTITY,2)
                  END TEMP_LEVEL 
             FROM CIMS.T_INV_INVENTORIES_LEVEL T
             WHERE T.ENTITY_ID = P_ENEITY_ID
             ) UT
    ON (UT.INVENTORY_ID = TL.INVENTORY_ID AND UT.ITEM_ID = TL.ITEM_ID AND TL.ENTITY_ID = UT.ENTITY_ID)
    WHEN MATCHED THEN
      UPDATE --更新在存产品数量
         SET TL.Inventories_Level = UT.TEMP_LEVEL,
             TL.LAST_UPDATED_BY = 'PROGRAM',
             TL.LAST_UPDATE_DATE = SYSDATE;
             
  --提交释放临时表           
  COMMIT;
  --第7步 将冻结后计算库存水位数据更新到正式库存水位表中
  V_VALUE  := '将临时库存水位表中的数据，计算并入到正式库存水位表中'; 
  MERGE INTO T_PLN_INV_LEVEL TL
    USING (
           --获得正式库存水位表库存和产品信息
           SELECT DISTINCT T1.INVENTORY_ID, --库存ID
                   T1.ITEM_ID, --产品ID
                   T1.ENTITY_ID,
                   T1.AVG_OUT_QUANTITY,
                   T1.INVENTORIES_LEVEL
             FROM CIMS.T_INV_INVENTORIES_LEVEL   T1 --库存水位正式表
             WHERE T1.ENTITY_ID = P_ENEITY_ID
            ) UT
    ON (UT.INVENTORY_ID = TL.INVENTORY_ID AND UT.ITEM_ID = TL.ITEM_ID AND UT.ENTITY_ID = TL.ENTITY_ID)
    WHEN MATCHED THEN --如果匹配，则什么也不做，如果不匹配，则新增一行
      UPDATE
        SET TL.AVG_OUT_QUANTITY = UT.AVG_OUT_QUANTITY
            ,TL.CURRENT_INVENTORIES_LEVEL = UT.INVENTORIES_LEVEL
            --计算最大补货量：当计算库存水位为无穷大时，也就是平均出库量为0，最大补货量取指定的配置值，否则就按公式计算
            ,TL.MAXIMUM_REPLENISHMENT_QTY = DECODE(UT.AVG_OUT_QUANTITY,0,(SELECT PKG_BD.f_GET_PARAMETER_VALUE('ORDER_MAXIMUM_REPLENISHMENT_QTY',TL.ENTITY_ID,NULL,NULL) FROM DUAL),(NVL(TL.STANDARD_LEVEL,0) - UT.INVENTORIES_LEVEL)*UT.AVG_OUT_QUANTITY)
            --计算临时补货量：当临时库存水位为0时，则临时补货量也为NULL,否则，根据一下逻辑计算：当计算库存水位为无穷大时，也就是平均出库量为0，临时补货量取指定的配置值，否则就按公式计算
            ,TL.TEMP_ORDERING_QTY = DECODE(NVL(TL.TEMP_LEVEL,0),0,NULL,DECODE(UT.AVG_OUT_QUANTITY,0,(SELECT PKG_BD.f_GET_PARAMETER_VALUE('ORDER_MAXIMUM_REPLENISHMENT_QTY',TL.ENTITY_ID,NULL,NULL) FROM DUAL),(NVL(TL.TEMP_LEVEL,0) - UT.INVENTORIES_LEVEL)*UT.AVG_OUT_QUANTITY))
            ,TL.Acc_Affirm_Quantity = 0
            ,TL.ACC_CANCEL_QUANTITY = 0
            ,TL.LAST_UPDATED_BY = 'PROGRAM'
            ,TL.LAST_UPDATE_DATE = SYSDATE
      ;
      
     COMMIT;
  EXCEPTION
    --抓取整个范围的异常 
    WHEN OTHERS THEN
      ROLLBACK;
      P_RESULT := '失败：' || V_VALUE || v_Nl || SQLERRM;
  END;
  
  ------------------------------------------------------------------------------------------------
  -- Author  : hejy3
  -- Created : 2018-08-06
  -- Purpose : 未满足提货订单数据冻结
  ------------------------------------------------------------------------------------------------
  PROCEDURE P_FREEZE_PLN_LG_ORDER(IN_STAT_DATE IN DATE,
                                  IN_ENTITY_ID IN NUMBER DEFAULT -1)
  IS
  BEGIN
    --先删除当天数据
    DELETE FROM T_PLN_ORDER_FREEZE F
     WHERE F.STAT_DATE = IN_STAT_DATE
       AND (F.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1);
    
    --未满足订单冻结
    INSERT INTO T_PLN_ORDER_FREEZE
      (STAT_DATE,
       DATA_TYPE,
       ENTITY_ID,
       SALES_CENTER_ID,
       SALES_CENTER_CODE,
       SALES_CENTER_NAME,
       CUSTOMER_ID,
       CUSTOMER_CODE,
       CUSTOMER_NAME,
       ACCOUNT_ID,
       ACCOUNT_CODE,
       ITEM_ID,
       ITEM_CODE,
       ITEM_NAME,
       QUANTITY,
       AMOUNT,
       CREATED_BY,
       CREATION_DATE)
    SELECT IN_STAT_DATE,
           'UNMET',
           H.ENTITY_ID,
           H.SALES_CENTER_ID,
           H.SALES_CENTER_CODE,
           H.SALES_CENTER_NAME,
           H.CUSTOMER_ID,
           CH.CUSTOMER_CODE,
           CH.CUSTOMER_NAME,
           H.ACCOUNT_ID,
           H.ACCOUNT_CODE,
           L.ITEM_ID,
           BI.ITEM_CODE,
           BI.ITEM_NAME,
           SUM(CASE
                 WHEN H.ORDER_HEAD_STATE IN ('20', '2225', '1455') AND H.HQ_LG_ORDER_HEAD_ID IS NULL THEN
                   L.QUANTITY - NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0)
                 ELSE
                   NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) - NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0)
               END) QUANTITY,
           SUM(CASE
                 WHEN H.ORDER_HEAD_STATE IN ('20', '2225', '1455') AND H.HQ_LG_ORDER_HEAD_ID IS NULL THEN
                   L.QUANTITY - NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0)
                 ELSE
                   NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) - NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0)
               END *
               DECODE(L.PROJECT_ORDER_TYPE, NULL, L.LIST_PRICE, L.APPLY_LIST_PRICE) *
               (100 - DECODE(L.PROJECT_ORDER_TYPE, NULL, NVL(L.DISCOUNT_RATE, 0), NVL(L.APPLY_DISCOUNT_RATE, 0)) -
                 NVL(L.ORDERED_DISCOUNT_RATE, 0)) / 100
               ) AMOUNT,
           'PLN_JOB',
           SYSDATE
      FROM T_PLN_LG_ORDER_HEAD H,
           T_PLN_LG_ORDER_LINE L,
           T_BD_ITEM BI,
           T_CUSTOMER_HEADER CH
     WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
       AND L.ITEM_ID = BI.ITEM_ID
       AND H.CUSTOMER_ID = CH.CUSTOMER_ID
       AND H.TO_CHECKUP_DATE BETWEEN ADD_MONTHS(SYSDATE, -3) AND TRUNC(SYSDATE) --3个月内
       AND H.ORDER_HEAD_STATE NOT IN ('19', '304', '23', '415') --非制单、已关闭、评审完毕、已驳回状态
       AND NVL(L.ORDER_LINE_STATE, 'NORMAL') <> 'CLOSED' --行状态非已关闭
       AND EXISTS (SELECT 1 FROM T_PLN_ORDER_TYPE T
                    WHERE T.ORDER_TYPE_ID = H.ORDER_TYPE_ID
                      AND T.SOURCE_ORDER_TYPE_ID = 1 --提货订单
                      AND UPPER(NVL(T.IS_BUSINESS_CONTROL, '_')) NOT IN ('PRO_ORDER', 'COMPENSATION')) --非推广物料提货订单
       AND H.ORDER_TYPE_ID NOT IN (SELECT UCL.CODE_VALUE
                               FROM CIMS.UP_CODELIST        UCL,
                                    CIMS.UP_CODELIST_ENTITY UCLE
                              WHERE UCL.CODETYPE = 'PLG_LGORDER_CENTER_TRANSFER'
                                AND UCL.ID = UCLE.CODELIST_ID
                                AND UCL.ENABLED = 0
                                AND UCLE.ENTITY_ID = H.ENTITY_ID)
       AND CASE
             WHEN H.ORDER_HEAD_STATE IN ('20', '2225', '1455') AND H.HQ_LG_ORDER_HEAD_ID IS NULL THEN
               L.QUANTITY - NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0)
             ELSE
               NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) - NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0)
           END > 0
       AND (H.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1)
     GROUP BY H.ENTITY_ID,
             H.SALES_CENTER_ID,
             H.SALES_CENTER_CODE,
             H.SALES_CENTER_NAME,
             H.CUSTOMER_ID,
             CH.CUSTOMER_CODE,
             CH.CUSTOMER_NAME,
             H.ACCOUNT_ID,
             H.ACCOUNT_CODE,
             L.ITEM_ID,
             BI.ITEM_CODE,
             BI.ITEM_NAME;
    
    --当月评审数据冻结
    INSERT INTO T_PLN_ORDER_FREEZE
      (STAT_DATE,
       DATA_TYPE,
       ENTITY_ID,
       SALES_CENTER_ID,
       SALES_CENTER_CODE,
       SALES_CENTER_NAME,
       CUSTOMER_ID,
       CUSTOMER_CODE,
       CUSTOMER_NAME,
       ACCOUNT_ID,
       ACCOUNT_CODE,
       ITEM_ID,
       ITEM_CODE,
       ITEM_NAME,
       QUANTITY,
       AMOUNT,
       CREATED_BY,
       CREATION_DATE)
     SELECT IN_STAT_DATE,
            'MONTH_CHECK',
            ENTITY_ID,
            SALES_CENTER_ID,
            SALES_CENTER_CODE,
            SALES_CENTER_NAME,
            CUSTOMER_ID,
            CUSTOMER_CODE,
            CUSTOMER_NAME,
            ACCOUNT_ID,
            ACCOUNT_CODE,
            ITEM_ID,
            ITEM_CODE,
            ITEM_NAME,
            SUM(AFFIRM_QTY) QUANTITY,
            SUM(AMOUNT) AMOUNT,
            'PLN_JOB',
            SYSDATE
      FROM (SELECT H.ENTITY_ID,
                  H.SALES_CENTER_ID,
                  H.SALES_CENTER_CODE,
                  H.SALES_CENTER_NAME,
                  H.CUSTOMER_ID,
                  CH.CUSTOMER_CODE,
                  CH.CUSTOMER_NAME,
                  H.ACCOUNT_ID,
                  H.ACCOUNT_CODE,
                  L.ITEM_ID,
                  BI.ITEM_CODE,
                  BI.ITEM_NAME,
                  REVIEWINFO.AFFIRM_QTY AFFIRM_QTY,
                  REVIEWINFO.AFFIRM_QTY *
                     DECODE(L.PROJECT_ORDER_TYPE, NULL, L.LIST_PRICE, L.APPLY_LIST_PRICE) *
                     (100 - DECODE(L.PROJECT_ORDER_TYPE, NULL, NVL(L.DISCOUNT_RATE, 0), NVL(L.APPLY_DISCOUNT_RATE, 0)) -
                       NVL(L.ORDERED_DISCOUNT_RATE, 0)) / 100 AMOUNT
             FROM T_PLN_LG_ORDER_HEAD H,
                  T_PLN_LG_ORDER_LINE L,
                  (SELECT RI.ORIGIN_ORDER_LINE_ID,
                          SUM(RI.AFFIRM_QTY) AFFIRM_QTY
                     FROM CIMS.T_PLN_ORDER_REVIEW_INFO RI
                    WHERE RI.HQ_DATE BETWEEN TRUNC(SYSDATE, 'MM') AND TRUNC(SYSDATE)-1
                    GROUP BY RI.ORIGIN_ORDER_LINE_ID) REVIEWINFO,
                  CIMS.T_PLN_ORDER_TYPE T,
                  T_CUSTOMER_HEADER CH,
                  T_BD_ITEM BI
            WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
              AND REVIEWINFO.ORIGIN_ORDER_LINE_ID = L.ORDER_LINE_ID
              AND H.ORDER_TYPE_ID = T.ORDER_TYPE_ID
              AND H.CUSTOMER_ID = CH.CUSTOMER_ID
              AND L.ITEM_ID = BI.ITEM_ID
              AND T.SOURCE_ORDER_TYPE_ID = 1
              AND T.IS_BUSINESS_CONTROL NOT IN ('pro_order', 'COMPENSATION')
              AND H.ORDER_TYPE_ID NOT IN
                  (SELECT UCL.CODE_VALUE
                     FROM CIMS.UP_CODELIST        UCL,
                          CIMS.UP_CODELIST_ENTITY UCLE
                    WHERE UCL.CODETYPE = 'PLG_LGORDER_CENTER_TRANSFER'
                      AND UCL.ID = UCLE.CODELIST_ID
                      AND UCL.ENABLED = 0
                      AND UCLE.ENTITY_ID = H.ENTITY_ID)
              AND H.ORDER_HEAD_STATE NOT IN ('19', '415')
              AND H.TO_CHECKUP_DATE < TRUNC(SYSDATE)
              AND (H.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1)
           UNION ALL
           SELECT H.ENTITY_ID,
                  H.SALES_CENTER_ID,
                  H.SALES_CENTER_CODE,
                  H.SALES_CENTER_NAME,
                  H.CUSTOMER_ID,
                  CH.CUSTOMER_CODE,
                  CH.CUSTOMER_NAME,
                  H.ACCOUNT_ID,
                  H.ACCOUNT_CODE,
                  L.ITEM_ID,
                  BI.ITEM_CODE,
                  BI.ITEM_NAME,
                  L.TO_PLN_QTY AFFIRM_QTY,
                  L.TO_PLN_QTY *
                     DECODE(L.PROJECT_ORDER_TYPE, NULL, L.LIST_PRICE, L.APPLY_LIST_PRICE) *
                     (100 - DECODE(L.PROJECT_ORDER_TYPE, NULL, NVL(L.DISCOUNT_RATE, 0), NVL(L.APPLY_DISCOUNT_RATE, 0)) -
                       NVL(L.ORDERED_DISCOUNT_RATE, 0)) / 100 AMOUNT
             FROM CIMS.T_PLN_LG_ORDER_HEAD H,
                  CIMS.T_PLN_LG_ORDER_LINE L,
                  CIMS.T_PLN_LG_RELATION   LR, 
                  CIMS.T_PLN_ORDER_TYPE    T,
                  T_CUSTOMER_HEADER CH,
                  T_BD_ITEM BI
            WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
              AND LR.LG_ORDER_LINE_ID = L.ORDER_LINE_ID
              AND LR.CREATION_DATE BETWEEN TRUNC(SYSDATE, 'MM') AND TRUNC(SYSDATE)
              AND H.ORDER_TYPE_ID = T.ORDER_TYPE_ID
              AND H.CUSTOMER_ID = CH.CUSTOMER_ID
              AND L.ITEM_ID = BI.ITEM_ID
              AND T.SOURCE_ORDER_TYPE_ID = 1
              AND T.IS_BUSINESS_CONTROL NOT IN ('pro_order', 'COMPENSATION')
              AND H.ORDER_TYPE_ID NOT IN
                  (SELECT UCL.CODE_VALUE
                     FROM CIMS.UP_CODELIST        UCL,
                          CIMS.UP_CODELIST_ENTITY UCLE
                    WHERE UCL.CODETYPE = 'PLG_LGORDER_CENTER_TRANSFER'
                      AND UCL.ID = UCLE.CODELIST_ID
                      AND UCL.ENABLED = 0
                      AND UCLE.ENTITY_ID = H.ENTITY_ID)
              AND H.ORDER_HEAD_STATE NOT IN ('19', '415')
              AND H.TO_CHECKUP_DATE < TRUNC(SYSDATE)
              AND (H.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1))
    GROUP BY ENTITY_ID,
            SALES_CENTER_ID,
            SALES_CENTER_CODE,
            SALES_CENTER_NAME,
            CUSTOMER_ID,
            CUSTOMER_CODE,
            CUSTOMER_NAME,
            ACCOUNT_ID,
            ACCOUNT_CODE,
            ITEM_ID,
            ITEM_CODE,
            ITEM_NAME;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      Rollback;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'P_FREEZE_PLN_LG_ORDER',
                                  p_Error_Msg            => '未满足提货订单数据冻结：' || sqlerrm,
                                  p_Source_Order_Head_Id => NULL,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
      commit;
  END P_FREEZE_PLN_LG_ORDER;
  
  ------------------------------------------------------------------------------------------------
  -- Author  : hejy3
  -- Created : 2018-08-06
  -- Purpose : 订单分级量化报表
  ------------------------------------------------------------------------------------------------
  PROCEDURE P_PLN_LG_ORDER_QUANTIFY_RPT(IN_ENTITY_ID IN NUMBER DEFAULT -1)
  IS
  BEGIN
    --先删除当天数据
    DELETE FROM T_PLN_LG_ORDER_QUANTIFY Q
     WHERE (Q.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1);
    
    --取3个月内未评审完毕订单
    INSERT INTO T_PLN_LG_ORDER_QUANTIFY
      (ENTITY_ID,
       ORDER_HEAD_ID,
       ORDER_LINE_ID,
       ACCOUNT_ID,
       ITEM_ID,
       CREATED_BY,
       CREATION_DATE)
    SELECT H.ENTITY_ID,
           H.ORDER_HEAD_ID,
           L.ORDER_LINE_ID,
           H.ACCOUNT_ID,
           L.ITEM_ID,
           'PLN_JOB',
           SYSDATE
      FROM T_PLN_LG_ORDER_HEAD H,
           T_PLN_LG_ORDER_LINE L
     WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
       AND H.TO_CHECKUP_DATE BETWEEN TRUNC(ADD_MONTHS(SYSDATE, -3)) AND TRUNC(SYSDATE)+1 --3个月内
       AND H.ORDER_HEAD_STATE NOT IN ('19', '304', '23', '415') --非制单、已关闭、评审完毕、已驳回状态
       AND NVL(L.ORDER_LINE_STATE, 'NORMAL') <> 'CLOSED' --行状态非已关闭
       AND EXISTS (SELECT 1 FROM T_PLN_ORDER_TYPE T
                    WHERE T.ORDER_TYPE_ID = H.ORDER_TYPE_ID
                      AND T.SOURCE_ORDER_TYPE_ID = 1 --提货订单
                      AND UPPER(NVL(T.IS_BUSINESS_CONTROL, '_')) NOT IN ('PRO_ORDER', 'COMPENSATION')) --非推广物料提货订单
       AND H.ORDER_TYPE_ID NOT IN (SELECT UCL.CODE_VALUE
                               FROM CIMS.UP_CODELIST        UCL,
                                    CIMS.UP_CODELIST_ENTITY UCLE
                              WHERE UCL.CODETYPE = 'PLG_LGORDER_CENTER_TRANSFER'
                                AND UCL.ID = UCLE.CODELIST_ID
                                AND UCL.ENABLED = 0
                                AND UCLE.ENTITY_ID = H.ENTITY_ID)
       AND CASE
             WHEN H.ORDER_HEAD_STATE IN ('20', '2225', '1455') AND H.HQ_LG_ORDER_HEAD_ID IS NULL THEN
               L.QUANTITY - NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0)
             ELSE
               NVL(L.CENTER_AFFIRM_QUANTITY, L.QUANTITY) - NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0)
           END > 0
       AND (H.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1);
    
    --账户冻结余额
    UPDATE T_PLN_LG_ORDER_QUANTIFY Q
       SET Q.ATTRIBUTE_11 = 
           nvl((Select sum(a.Received_Amount --到款金额
                        - a.Sales_Amount --销售金额
                        + a.Delaypay_Amount --铺底额度
                        + a.Temp_Delaypay_Amount --临时额度
                        - a.Lock_Received_Amount --锁定到款金额
                        + a.Mpay_Stream_Amount --流水金额
                        - a.Mpay_Cash_Amount --提现金额
                        + a.Discount_Amount --折让金额
                        - a.Applied_Discount_Amount --核销折让金额
                        + a.Freeze_Discount_Amount --冻结扣率折让金额
                        - a.Lock_Discount_Amount) --锁定扣率折让金额
                        Usable_Amount
                   From t_Sales_Amount_Freeze a
                  Where a.Freeze_Date = Trunc(Sysdate - 1)
                    and a.entity_id = q.entity_id
                    and a.account_id = q.account_id),0)
     WHERE (Q.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1);
    
    --账户冻结未满足金额
    UPDATE T_PLN_LG_ORDER_QUANTIFY Q
       SET Q.ATTRIBUTE_12 = 
           nvl((select sum(f.amount)
                  from T_PLN_ORDER_FREEZE f
                 where f.stat_date = Trunc(Sysdate - 1)
                   and f.entity_id = q.entity_id
                   and f.account_id = q.account_id
                   and f.data_type = 'UNMET'),0)
     WHERE (Q.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1);
    
    --账户当天提交未满足金额
    UPDATE T_PLN_LG_ORDER_QUANTIFY Q
       SET Q.ATTRIBUTE_13 = 
           nvl((select sum(f.amount)
                  from V_PLN_ORDER_FREEZE f
                 where f.entity_id = q.entity_id
                   and f.account_id = q.account_id
                   and f.data_type = 'UNMET'),0)
     WHERE (Q.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1);
     
    --账户产品冻结未满足数量
    UPDATE T_PLN_LG_ORDER_QUANTIFY Q
       SET Q.ATTRIBUTE_14 = 
           nvl((select sum(f.quantity)
                  from T_PLN_ORDER_FREEZE f, T_PLN_ITEM_PROPERTY P
                 where f.stat_date = Trunc(Sysdate - 1)
                   and f.item_id = p.item_id
                   and f.entity_id = p.entity_id
                   and p.accuracy_rate = '1'
                   and f.entity_id = q.entity_id
                   and f.account_id = q.account_id
                   and f.item_id = q.item_id
                   and f.data_type = 'UNMET'),0)
     WHERE (Q.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1);
    
    --账户产品冻结当月评审数量
    UPDATE T_PLN_LG_ORDER_QUANTIFY Q
       SET Q.ATTRIBUTE_15 = 
           nvl((select sum(f.Quantity)
                  from T_PLN_ORDER_FREEZE f, T_PLN_ITEM_PROPERTY P
                 where f.stat_date = Trunc(Sysdate - 1)
                   and f.item_id = p.item_id
                   and f.entity_id = p.entity_id
                   and p.accuracy_rate = '1'
                   and f.entity_id = q.entity_id
                   and f.account_id = q.account_id
                   and f.item_id = q.item_id
                   and f.data_type = 'MONTH_CHECK'),0)
     WHERE (Q.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1);
    
    --账户产品当天提交数量
    UPDATE T_PLN_LG_ORDER_QUANTIFY Q
       SET Q.ATTRIBUTE_16 = 
           nvl((select sum(f.QUANTITY)
                  from V_PLN_ORDER_FREEZE f, T_PLN_ITEM_PROPERTY P
                 where f.item_id = p.item_id
                   and f.entity_id = p.entity_id
                   and p.accuracy_rate = '1'
                   and f.entity_id = q.entity_id
                   and f.account_id = q.account_id
                   and f.item_id = q.item_id
                   and f.data_type = 'MONTH_CHECK'),0)
     WHERE (Q.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1);
    
    --账户产品M+1月计划量
    UPDATE T_PLN_LG_ORDER_QUANTIFY Q
       SET Q.ATTRIBUTE_17 = 
           nvl((select sum(l.month_plan_qty)
                  from T_STP_MONTH_PLAN_HEAD H,
                       T_STP_MONTH_PLAN_LINES L,
                       T_PLN_ITEM_PROPERTY P,
                       T_PLN_ORDER_TYPE T,
                       T_PLN_ORDER_PERIOD OP
                 where h.month_plan_head_id = l.month_plan_head_id
                   and h.entity_id = p.entity_id
                   and l.item_id = p.item_id
                   and p.accuracy_rate = '1'
                   and h.Plan_Type = T.ORDER_TYPE_ID
                   AND T.ORDER_TYPE_NAME IN ('月预测计划(M+1)', '月增补预测计划(M+1)')
                   AND H.PLAN_PERIOD = Op.period_id
                   and trunc(sysdate) between Op.begin_date and Op.end_date
                   and h.entity_id = q.entity_id
                   and h.account_id = q.account_id
                   and L.item_id = q.item_id),0)
     WHERE (Q.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1);
    
    --计算得分
    --资金占比：账户冻结可提货余额/(账户冻结未满足金额+账户当天提交未满足金额)
    UPDATE T_PLN_LG_ORDER_QUANTIFY Q
       SET Q.ATTRIBUTE_01 =
           round((select 1 * 100 * nvl(tc.allot_rate, 0) / 100
              from T_PLN_LG_COLL_PRIORITY_CONFIG t,
                   T_PLN_LG_COLL_PRIORITY_CONFIG tc
             where t.config_type = '提货分级量化设置'
               and t.entity_id = q.entity_id
               and tc.parent_config_id = t.priority_config_id
               and tc.priority_config_type = 'CAPITAL_RATIO'), 4)
     WHERE (Q.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1)
       AND TO_NUMBER(NVL(Q.ATTRIBUTE_12, '0')) + TO_NUMBER(NVL(Q.ATTRIBUTE_13, '0')) = 0
       AND Q.ATTRIBUTE_01 IS NULL;
     
    UPDATE T_PLN_LG_ORDER_QUANTIFY Q
       SET Q.ATTRIBUTE_01 =
           round((select
                   CASE
                     WHEN TO_NUMBER(nvl(q.attribute_11, '0')) < 0 THEN
                       0
                     WHEN TO_NUMBER(nvl(q.attribute_11, '0')) /
                       (TO_NUMBER(NVL(Q.ATTRIBUTE_12, '0')) + TO_NUMBER(NVL(Q.ATTRIBUTE_13, '0'))) > 1 THEN
                       1
                     ELSE
                       TO_NUMBER(nvl(q.attribute_11, '0')) /
                       (TO_NUMBER(NVL(Q.ATTRIBUTE_12, '0')) + TO_NUMBER(NVL(Q.ATTRIBUTE_13, '0')))
                   END
                   * 100 * nvl(tc.allot_rate, 0) / 100
              from T_PLN_LG_COLL_PRIORITY_CONFIG t,
                   T_PLN_LG_COLL_PRIORITY_CONFIG tc
             where t.config_type = '提货分级量化设置'
               and t.entity_id = q.entity_id
               and tc.parent_config_id = t.priority_config_id
               and tc.priority_config_type = 'CAPITAL_RATIO'), 4)
     WHERE (Q.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1)
       AND Q.ATTRIBUTE_01 IS NULL;
    
    --库存分销比
    UPDATE T_PLN_LG_ORDER_QUANTIFY Q
       SET Q.ATTRIBUTE_02 = 
           round((SELECT CASE
                     WHEN L.AGENT_STOCK_QTY IS NULL THEN
                       0
                     WHEN L.AGENT_STOCK_QTY = 0 THEN
                       100
                     ELSE
                       NULL
                   END
              FROM T_PLN_LG_ORDER_LINE L
             WHERE L.ORDER_LINE_ID = Q.ORDER_LINE_ID)
             *
           (select nvl(tc.allot_rate, 0) / 100
              from T_PLN_LG_COLL_PRIORITY_CONFIG t,
                   T_PLN_LG_COLL_PRIORITY_CONFIG tc
             where t.config_type = '提货分级量化设置'
               and t.entity_id = q.entity_id
               and tc.parent_config_id = t.priority_config_id
               and t.entity_id = q.entity_id
               and tc.priority_config_type = 'STOCK_DISTRIBUTION_RATE'), 4)
     WHERE (Q.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1);
    
    UPDATE T_PLN_LG_ORDER_QUANTIFY Q
       SET Q.ATTRIBUTE_02 =
           round((select nvl(ptc.allot_rate, 0) * nvl(tc.allot_rate, 0) / 100
              from T_PLN_LG_COLL_PRIORITY_CONFIG t,
                   T_PLN_LG_COLL_PRIORITY_CONFIG tc,
                   T_PLN_LG_COLL_PRIORITY_CONFIG ptc,
                   T_PLN_LG_ORDER_LINE L
             where t.config_type = '提货分级量化设置'
               and tc.parent_config_id = t.priority_config_id
               and ptc.parent_config_id = tc.priority_config_id
               and t.entity_id = q.entity_id
               and tc.priority_config_type = 'STOCK_DISTRIBUTION_RATE'
               and q.order_line_id = l.order_line_id
               and l.agent_stock_qty >
                     to_number(Substr(ptc.Priority_Config_Value,
                            1,
                            Instr(ptc.Priority_Config_Value, '~') - 1))
               and l.agent_stock_qty <=
                     to_number(Substr(ptc.Priority_Config_Value,
                            Instr(ptc.Priority_Config_Value, '~') + 1,
                            Length(ptc.Priority_Config_Value)))), 4)
     WHERE (Q.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1)
       AND Q.ATTRIBUTE_02 IS NULL;
    
    --需求提报
    --不统计需求提报准确率
    UPDATE T_PLN_LG_ORDER_QUANTIFY Q
       SET Q.ATTRIBUTE_03 =
           round((select 100 * nvl(tc.allot_rate, 0) / 100
              from T_PLN_LG_COLL_PRIORITY_CONFIG t,
                   T_PLN_LG_COLL_PRIORITY_CONFIG tc
             where t.config_type = '提货分级量化设置'
               and t.entity_id = q.entity_id
               and tc.parent_config_id = t.priority_config_id
               and t.entity_id = q.entity_id
               and tc.priority_config_type = 'DEMAND_REPORT'), 4)
     WHERE (Q.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1)
       AND (NOT EXISTS (SELECT 1 FROM T_PLN_ITEM_PROPERTY P
                    WHERE P.ENTITY_ID = Q.ENTITY_ID
                      AND P.ITEM_ID = Q.ITEM_ID
                      AND P.ACCURACY_RATE = '1')
         OR (TO_NUMBER(NVL(Q.ATTRIBUTE_14, '0'))+TO_NUMBER(NVL(Q.ATTRIBUTE_15, '0'))+TO_NUMBER(NVL(Q.ATTRIBUTE_16, '0'))) = 0);
    
    --没提交过预测的为0
    UPDATE T_PLN_LG_ORDER_QUANTIFY Q
       SET Q.ATTRIBUTE_03 = 0
     WHERE (Q.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1)
       AND Q.ATTRIBUTE_03 IS NULL
       AND TO_NUMBER(NVL(Q.ATTRIBUTE_17, '0')) = 0
       AND EXISTS (SELECT 1 FROM T_PLN_ITEM_PROPERTY P
                    WHERE P.ENTITY_ID = Q.ENTITY_ID
                      AND P.ITEM_ID = Q.ITEM_ID
                      AND P.ACCURACY_RATE = '1');
    
    --需统计需求提报准确率
    UPDATE T_PLN_LG_ORDER_QUANTIFY Q
       SET Q.ATTRIBUTE_03 =
           round((select nvl(ptc.allot_rate, 0) * nvl(tc.allot_rate, 0) / 100
              from T_PLN_LG_COLL_PRIORITY_CONFIG t,
                   T_PLN_LG_COLL_PRIORITY_CONFIG tc,
                   T_PLN_LG_COLL_PRIORITY_CONFIG ptc
             where t.config_type = '提货分级量化设置'
               and t.entity_id = q.entity_id
               and tc.parent_config_id = t.priority_config_id
               and ptc.parent_config_id = tc.priority_config_id
               and t.entity_id = q.entity_id
               and tc.priority_config_type = 'DEMAND_REPORT'
               and ((TO_NUMBER(NVL(Q.ATTRIBUTE_14, '0'))+TO_NUMBER(NVL(Q.ATTRIBUTE_15, '0'))+TO_NUMBER(NVL(Q.ATTRIBUTE_16, '0')))
                           / TO_NUMBER(NVL(Q.ATTRIBUTE_17, '0'))) * 100 >
                           to_number(Substr(ptc.Priority_Config_Value,
                                  1,
                                  Instr(ptc.Priority_Config_Value, '~') - 1))
               AND ((TO_NUMBER(NVL(Q.ATTRIBUTE_14, '0'))+TO_NUMBER(NVL(Q.ATTRIBUTE_15, '0'))+TO_NUMBER(NVL(Q.ATTRIBUTE_16, '0')))
                           / TO_NUMBER(NVL(Q.ATTRIBUTE_17, '0'))) * 100 <=
                           to_number(Substr(ptc.Priority_Config_Value,
                                  Instr(ptc.Priority_Config_Value, '~') + 1,
                                  Length(ptc.Priority_Config_Value)))
               ), 4)
     WHERE (Q.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1)
       AND Q.ATTRIBUTE_03 IS NULL
       AND EXISTS (SELECT 1 FROM T_PLN_ITEM_PROPERTY P
                    WHERE P.ENTITY_ID = Q.ENTITY_ID
                      AND P.ITEM_ID = Q.ITEM_ID
                      AND P.ACCURACY_RATE = '1');

    --产品属性
    UPDATE T_PLN_LG_ORDER_QUANTIFY Q
       SET Q.ATTRIBUTE_04 =
           round((select nvl(ptc.allot_rate, 0) * nvl(tc.allot_rate, 0) / 100
              from T_PLN_LG_COLL_PRIORITY_CONFIG t,
                   T_PLN_LG_COLL_PRIORITY_CONFIG tc,
                   T_PLN_LG_COLL_PRIORITY_CONFIG ptc,
                   T_PLN_ITEM_PROPERTY P
             where t.config_type = '提货分级量化设置'
               and t.entity_id = q.entity_id
               and tc.parent_config_id = t.priority_config_id
               and ptc.parent_config_id = tc.priority_config_id
               and tc.priority_config_type = 'PRODUCT_ATTR'
               and p.product_level = ptc.priority_config_type
               and p.entity_id = q.entity_id
               and p.item_id = q.item_id), 4)
     WHERE (Q.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1);
    
    --没有维护属性的
    UPDATE T_PLN_LG_ORDER_QUANTIFY Q
       SET Q.ATTRIBUTE_04 = 0
     WHERE (Q.ENTITY_ID = IN_ENTITY_ID OR IN_ENTITY_ID = -1)
       AND Q.ATTRIBUTE_04 IS NULL;
    
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      Rollback;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'P_PLN_LG_ORDER_QUANTIFY_RPT',
                                  p_Error_Msg            => '订单分级量化报表数据冻结：' || sqlerrm,
                                  p_Source_Order_Head_Id => NULL,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
      commit;
  END P_PLN_LG_ORDER_QUANTIFY_RPT;
  
  ------------------------------------------------------------------------------------------------
  -- Author  : hejy3
  -- Created : 2018-09-14
  -- Purpose : 更新订单行有效性
  ------------------------------------------------------------------------------------------------
  PROCEDURE P_UPDATE_LG_LINE_EFFECTIVE(IN_ENTITY_ID IN NUMBER DEFAULT -1)
  IS
    V_BEGIN_DATE DATE;
    V_BEGIN_DATE_CURR_MONTH DATE;
    V_END_DATE DATE;
    V_ENTITY_ID NUMBER;
    v_Pln_Of_Time_Month number;
    V_STEP VARCHAR2(100);
  BEGIN
    FOR R_ENTITY IN (
      SELECT E.entity_id
        FROM V_BD_ENTITY E
       WHERE (E.entity_id = IN_ENTITY_ID OR IN_ENTITY_ID = -1)
      )
    LOOP
      V_ENTITY_ID := R_ENTITY.ENTITY_ID;
      --获取月统计的起始和终止日期
      PKG_PLN_PUB.p_Get_CurrentPeriodDate(p_Entity_Id                 => V_ENTITY_ID,
                                          IN_CAL_DATE                 => TRUNC(SYSDATE),
                                          p_Current_Period_Begin_Date => V_BEGIN_DATE,
                                          p_Current_Period_End_Date   => V_END_DATE);
      
      Begin
        v_Pln_Of_Time_Month := to_number(Pkg_Bd.f_Get_Parameter_Value('PLN_CAPACITY_AHEAD_OF_TIME_MONTH',
                                                                      V_ENTITY_ID));
      Exception
        When Others Then
          v_Pln_Of_Time_Month := 0;
      End;
      
      V_BEGIN_DATE_CURR_MONTH := ADD_MONTHS(V_BEGIN_DATE, v_Pln_Of_Time_Month);
      
      --先插入待处理单据到临时表
      INSERT INTO T_PLN_LINE_EFF_TMP_G (ORDER_HEAD_ID)
       SELECT H.ORDER_HEAD_ID
         FROM T_PLN_LG_ORDER_HEAD H
        WHERE H.ENTITY_ID = V_ENTITY_ID
          AND H.To_Checkup_Date BETWEEN V_BEGIN_DATE AND V_END_DATE + 1;
       
      --删除不需统计的数据
      DELETE
        FROM T_PLN_LINE_EFF_TMP_G TG
       WHERE EXISTS (SELECT 1 FROM T_PLN_LG_ORDER_HEAD H
                      WHERE H.ORDER_HEAD_ID = TG.ORDER_HEAD_ID
                        AND (H.ORDER_HEAD_STATE NOT IN ('2225', '20', '1455', '679', '381') OR
                            EXISTS (SELECT 1 FROM CIMS.T_PLN_ORDER_TYPE T
                              WHERE H.ORDER_TYPE_ID = T.ORDER_TYPE_ID
                                AND T.SOURCE_ORDER_TYPE_ID = 1
                                AND NVL(T.IS_BUSINESS_CONTROL, '_') IN ('pro_order',
                                    'share_ship_order', 'COMPENSATION', 'RELET_ORDER')) OR
                            EXISTS (SELECT 1 FROM CIMS.T_PLN_ORDER_TYPE T
                              WHERE H.ORDER_TYPE_ID = T.ORDER_TYPE_ID
                                AND T.SOURCE_ORDER_TYPE_ID <> 1)
                            )
                        );
      
      --获取未评审完毕订单明细
      V_STEP := '获取未评审完毕订单明细';
      INSERT INTO T_PLN_LINE_EFFECTIVE_TMP
        (DATE_TYPE,
         ENTITY_ID,
         ORDER_LINE_ID,
         TO_CHECKUP_DATE,
         ACCOUNT_ID,
         ITEM_ID,
         UNMET_QTY,
         UNMET_QTY_BEFORE,
         AGENT_STOCK_QTY,
         SKU_INVSALE_STANDARD,
         DEMAND_QTY,
         AFFIRMED_QTY,
         DEMAND_STANDARD,
         CREATED_BY,
         CREATION_DATE)
        SELECT 'UNMET',
               HL.ENTITY_ID,
               HL.ORDER_LINE_ID,
               HL.TO_CHECKUP_DATE,
               HL.ACCOUNT_ID,
               HL.ITEM_ID,
               (CASE
                 WHEN HL.ORDER_HEAD_STATE IN ('2225', '20', '1455') THEN
                   HL.QUANTITY
                 WHEN HL.ORDER_HEAD_STATE IN ('679', '381') THEN
                   HL.CENTER_AFFIRM_QUANTITY
               END - NVL(HL.AFFIRMED_QUANTITY, 0) - NVL(HL.CANCEL_QTY, 0)) UNMET_QTY,
               NULL,
               HL.AGENT_STOCK_QTY,
               HL.SKU_INVSALE_STANDARD,
               NVL(MP.MONTH_PLAN_QTY, 0) MONTH_PLAN_QTY,
               NULL,
               IP.DEMAND_FORECAST_STANDARD,
               'P_UPDATE_LG_LINE_EFFECTIVE',
               SYSDATE
          FROM (SELECT H.ENTITY_ID,
                       H.ACCOUNT_ID,
                       H.ORDER_HEAD_STATE,
                       H.ORDER_TYPE_ID,
                       L.ORDER_LINE_ID,
                       L.ITEM_ID,
                       L.QUANTITY,
                       L.CENTER_AFFIRM_QUANTITY,
                       L.AFFIRMED_QUANTITY,
                       L.CANCEL_QTY,
                       L.AGENT_STOCK_QTY,
                       L.SKU_INVSALE_STANDARD,
                       L.COLLECT_ORDER_LINE_FLAG,
                       L.ORDER_LINE_STATE,
                       H.TO_CHECKUP_DATE
                  FROM T_PLN_LG_ORDER_HEAD H,
                       T_PLN_LG_ORDER_LINE L,
                       T_PLN_LINE_EFF_TMP_G TG
                 WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
                   AND H.ORDER_HEAD_ID = TG.ORDER_HEAD_ID) HL,
               T_PLN_ITEM_PROPERTY IP,
               (SELECT PH.ENTITY_ID,
                       PH.ACCOUNT_ID,
                       PL.ITEM_ID,
                       OP.BEGIN_DATE,
                       OP.END_DATE,
                       SUM(PL.MONTH_PLAN_QTY) MONTH_PLAN_QTY
                  FROM T_STP_MONTH_PLAN_HEAD PH,
                       T_STP_MONTH_PLAN_LINES PL,
                       T_PLN_ORDER_PERIOD OP,
                       T_PLN_ORDER_TYPE OT
                 WHERE PH.MONTH_PLAN_HEAD_ID = PL.MONTH_PLAN_HEAD_ID
                   AND PH.PLAN_PERIOD = OP.PERIOD_ID
                   AND PH.PLAN_TYPE = OT.ORDER_TYPE_ID
                   AND OT.ORDER_TYPE_NAME IN ('月预测计划(M+1)', '三月滚动预测')
                   AND PH.ACCOUNT_ID IS NOT NULL
                   AND PH.ENTITY_ID = V_ENTITY_ID
                   AND PH.PLAN_STATUS = '04'
                   AND OP.BEGIN_DATE BETWEEN V_BEGIN_DATE_CURR_MONTH AND V_END_DATE
                 GROUP BY PH.ENTITY_ID,
                       PH.ACCOUNT_ID,
                       PL.ITEM_ID,
                       OP.BEGIN_DATE,
                       OP.END_DATE) MP
         WHERE HL.ENTITY_ID = V_ENTITY_ID
           AND HL.ENTITY_ID = IP.ENTITY_ID(+)
           AND HL.ITEM_ID = IP.ITEM_ID(+)
           AND HL.ENTITY_ID = MP.ENTITY_ID(+)
           AND HL.ACCOUNT_ID = MP.ACCOUNT_ID(+)
           AND HL.ITEM_ID = MP.ITEM_ID(+)
           AND NVL(HL.ORDER_LINE_STATE, 'NORMAL') <> 'CLOSED'
           AND NVL(HL.COLLECT_ORDER_LINE_FLAG, 'N') = 'N'
           AND CASE
                 WHEN HL.ORDER_HEAD_STATE IN ('2225', '20', '1455') THEN
                   HL.QUANTITY
                 WHEN HL.ORDER_HEAD_STATE IN ('679', '381') THEN
                   HL.CENTER_AFFIRM_QUANTITY
               END - NVL(HL.AFFIRMED_QUANTITY, 0) - NVL(HL.CANCEL_QTY, 0) > 0;
      
      --更新超存销比标准数据
      V_STEP := '更新超存销比标准数据';
      UPDATE T_PLN_LINE_EFFECTIVE_TMP T
         SET T.INVSALE_RATIO_PROMPT = '超存销比，请加快分销',
             T.LINE_EFFECTIVE_FLAG = 'N'
       WHERE T.AGENT_STOCK_QTY > T.SKU_INVSALE_STANDARD
         AND T.DATE_TYPE = 'UNMET'
         AND T.ENTITY_ID = V_ENTITY_ID;
      
      --获取本月订单已评数量
      V_STEP := '获取本月订单已评数量';
      INSERT INTO T_PLN_LINE_EFFECTIVE_TMP
        (DATE_TYPE,
         ENTITY_ID,
         ACCOUNT_ID,
         ITEM_ID,
         AFFIRMED_QTY,
         CREATED_BY,
         CREATION_DATE)
       SELECT 'MONTH_CHECK',
              OH.ENTITY_ID,
              OH.ACCOUNT_ID,
              OL.ITEM_ID, 
             SUM(NVL(OL.CENTER_AFFIRMED_QTY, 0) + NVL(OL.HQ_AFFIRMED_QTY, 0) +
             DECODE(OL.MAKE_ORDER_LINE_FLAG, 'Y', NVL(OL.TO_PLN_QTY, 0), NVL(OL.PLN_AFFIRMED_QTY, 0))) AFFIRMED_QTY,
             'admin',
             sysdate
        FROM T_PLN_LG_ORDER_HEAD OH, T_PLN_LG_ORDER_LINE OL
       WHERE OH.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
         AND OH.ENTITY_ID = V_ENTITY_ID
         AND OH.TO_CHECKUP_DATE BETWEEN V_BEGIN_DATE_CURR_MONTH AND V_END_DATE + 1
         AND EXISTS (SELECT 1 FROM CIMS.T_PLN_ORDER_TYPE T
                WHERE OH.ORDER_TYPE_ID = T.ORDER_TYPE_ID
                  AND T.SOURCE_ORDER_TYPE_ID = 1
                  AND NVL(T.IS_BUSINESS_CONTROL, '_') NOT IN ('pro_order', 'COMPENSATION', 'RELET_ORDER'))
       GROUP BY OH.ENTITY_ID,
              OH.ACCOUNT_ID,
              OL.ITEM_ID;
      
      UPDATE T_PLN_LINE_EFFECTIVE_TMP T
         SET T.AFFIRMED_QTY = 
             NVL((SELECT SUM(NVL(ET.AFFIRMED_QTY, 0))
                FROM T_PLN_LINE_EFFECTIVE_TMP ET
               WHERE T.ACCOUNT_ID = ET.ACCOUNT_ID
                 AND T.ITEM_ID = ET.ITEM_ID
                 AND T.ENTITY_ID = ET.ENTITY_ID
                 AND ET.DATE_TYPE = 'MONTH_CHECK'), 0)
       WHERE T.DATE_TYPE = 'UNMET'
         AND T.ENTITY_ID = V_ENTITY_ID;
      
      --更新
      V_STEP := '更新之前送审数量';
      update T_PLN_LINE_EFFECTIVE_TMP t
         set t.unmet_qty_before =
             NVL((Select sum(et.unmet_qty)
                   From T_PLN_LINE_EFFECTIVE_TMP et
                  Where et.date_type = 'UNMET'
                    and et.entity_id = t.entity_id
                    and et.account_id = t.account_id
                    and et.item_id = t.item_id
                    And et.To_Checkup_Date < t.To_Checkup_Date), 0)
       where t.date_type = 'UNMET'
         AND T.ENTITY_ID = V_ENTITY_ID;
     
      --更新预测需求提示信息
      V_STEP := '更新预测需求提示信息';
      UPDATE T_PLN_LINE_EFFECTIVE_TMP T
         SET T.DEMAND_FORECAST_PROMPT = '超月度需求预测，交期待定',
             T.LINE_EFFECTIVE_FLAG = 'N' 
       WHERE T.DATE_TYPE = 'UNMET'
         AND T.ENTITY_ID = V_ENTITY_ID
         AND NVL(T.UNMET_QTY, 0) + NVL(T.UNMET_QTY_BEFORE, 0) >
             NVL(T.DEMAND_QTY, 0) * T.DEMAND_STANDARD / 100 - NVL(T.AFFIRMED_QTY, 0);
      
      --新品标识为有效
      V_STEP := '新品标识为有效';
      UPDATE T_PLN_LINE_EFFECTIVE_TMP T
         SET T.DEMAND_FORECAST_PROMPT = NULL,
             T.LINE_EFFECTIVE_FLAG = NULL
       WHERE T.DATE_TYPE = 'UNMET'
         AND T.ENTITY_ID = V_ENTITY_ID
         AND EXISTS (SELECT 1 FROM T_PLN_ITEM_PROPERTY P
                      WHERE P.ENTITY_ID = T.ENTITY_ID
                        AND P.ITEM_ID = T.ITEM_ID
                        AND P.NEW_PRODUCT_FLAG = 'Y');
      
      --更新订单行数据
      V_STEP := '更新订单行数据';
      UPDATE T_PLN_LG_ORDER_LINE L
         SET (L.INVSALE_RATIO_PROMPT, L.DEMAND_FORECAST_PROMPT, L.LINE_EFFECTIVE_FLAG, L.DEMAND_FORECAST_RATIO) =
             (SELECT ET.INVSALE_RATIO_PROMPT, ET.DEMAND_FORECAST_PROMPT, ET.LINE_EFFECTIVE_FLAG, ET.DEMAND_STANDARD
                FROM T_PLN_LINE_EFFECTIVE_TMP ET
               WHERE ET.ENTITY_ID = L.ENTITY_ID
                 AND ET.DATE_TYPE = 'UNMET'
                 AND ET.ORDER_LINE_ID = L.ORDER_LINE_ID),
             L.LAST_UPDATE_DATE = SYSDATE
       WHERE EXISTS (SELECT 1 FROM T_PLN_LINE_EFFECTIVE_TMP T
                      WHERE T.ENTITY_ID = V_ENTITY_ID
                        AND T.ENTITY_ID = L.ENTITY_ID
                        AND T.DATE_TYPE = 'UNMET'
                        AND T.ORDER_LINE_ID = L.ORDER_LINE_ID);
      
      DELETE FROM T_PLN_LINE_EFFECTIVE_TMP T WHERE T.ENTITY_ID = V_ENTITY_ID;
      COMMIT;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      Rollback;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'P_UPDATE_LG_LINE_EFFECTIVE',
                                  p_Error_Msg            => '更新订单行有效性：' || V_STEP || sqlerrm,
                                  p_Source_Order_Head_Id => NULL,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
      commit;
  END P_UPDATE_LG_LINE_EFFECTIVE;
  
  ------------------------------------------------------------------------------------------------
  -- Author  : hejy3
  -- Created : 2018-09-29
  -- Purpose : 更新订单行齐套交付日期
  ------------------------------------------------------------------------------------------------
  PROCEDURE P_UPD_LGLINE_CONSIGNMENT_STAGE(IN_ENTITY_ID IN NUMBER DEFAULT -1)
  IS
    V_CURRENT_TIME DATE;
    V_LAST_UPDATE_TIME DATE;
    V_SHIP_QTY NUMBER;
    V_CURRENT_ENTITY_ID NUMBER;
    V_MAX_CONSIGNMENT_DATE DATE;
    V_CURR_CONSIGNMENT_DATE DATE;
    V_UPDATED BOOLEAN := FALSE;
    V_SUM_QTY NUMBER := 0;
    V_LINE_IDS VARCHAR2(500);
    V_UPDATE_SQL VARCHAR2(4000);
    V_MANTISSA_DAYS NUMBER;
    V_DEFAULT_ONWAY_DAY NUMBER;
    V_PERIOD_DAY NUMBER;
  BEGIN
    V_CURRENT_TIME := SYSDATE;
    FOR R_ENTITY IN (
      SELECT BE.entity_id
        FROM V_BD_ENTITY BE
       WHERE (BE.entity_id = IN_ENTITY_ID OR IN_ENTITY_ID = -1)
      ) LOOP
      V_CURRENT_ENTITY_ID := R_ENTITY.ENTITY_ID;
      --获取上次更新时间
      BEGIN
        SELECT TO_DATE(pkg_bd.F_GET_PARAMETER_VALUE('PLN_CONSIGNMENT_STAGE_LAST_DATE',
                                                    V_CURRENT_ENTITY_ID,
                                                    NULL,
                                                    NULL),
                       'YYYY-MM-DD HH24:MI:SS')
          INTO V_LAST_UPDATE_TIME
          FROM dual;
      EXCEPTION
        WHEN OTHERS THEN
          V_LAST_UPDATE_TIME := V_CURRENT_TIME - 1;
      END;
      
      --获取起运批量
      BEGIN
        V_SHIP_QTY := pkg_bd.F_GET_PARAMETER_VALUE('PLN_LG_ORDER_SHIP_QTY',
                                                    V_CURRENT_ENTITY_ID,
                                                    NULL,
                                                    NULL);
      EXCEPTION
        WHEN OTHERS THEN
          V_SHIP_QTY := 250;
      END;
      
      --获取清尾天数
      BEGIN
        V_MANTISSA_DAYS := pkg_bd.F_GET_PARAMETER_VALUE('PLN_MANTISSA_DAYS',
                                                    V_CURRENT_ENTITY_ID,
                                                    NULL,
                                                    NULL);
      EXCEPTION
        WHEN OTHERS THEN
          V_MANTISSA_DAYS := 3;
      END;
      
      --取默认在途天数
      BEGIN
        SELECT TO_NUMBER(pkg_bd.F_GET_PARAMETER_VALUE('PLN_LG_DEFAULT_ONWAY_DAY',
                                                      V_CURRENT_ENTITY_ID,
                                                      NULL,
                                                      NULL))
          INTO V_DEFAULT_ONWAY_DAY
          FROM dual;
      EXCEPTION
        WHEN OTHERS THEN
          V_DEFAULT_ONWAY_DAY := 7;
      END;
      
      --获取T+3周期天数
      BEGIN
        SELECT TO_NUMBER(pkg_bd.F_GET_PARAMETER_VALUE('PLN_ORDER_PERIOD_TN',
                                                      V_CURRENT_ENTITY_ID,
                                                      NULL,
                                                      NULL))
          INTO V_PERIOD_DAY
          FROM dual;
      EXCEPTION
        WHEN OTHERS THEN
          V_PERIOD_DAY := 3;
      END;
      
      FOR R_LG_ORDER IN
        (SELECT H.ORDER_HEAD_ID,
                H.CONSIGNEE_ADDR_CODE,
                SUM(OL.CENTER_AFFIRM_QUANTITY - NVL(OL.AFFIRMED_QUANTITY, 0) - NVL(OL.CANCEL_QTY, 0)) NO_AFFIRM_QTY
           FROM T_PLN_LG_ORDER_HEAD H, T_PLN_LG_ORDER_LINE OL
          WHERE H.ORDER_HEAD_ID = OL.ORDER_HEAD_ID
            AND H.ENTITY_ID = V_CURRENT_ENTITY_ID
            AND H.ORDER_HEAD_STATE IN ('679', '381')
            --有效订单行或无效已结转订单
            AND ((NVL(OL.LINE_EFFECTIVE_FLAG, 'Y') = 'Y' AND OL.LAST_WALKTHROUGH_DATE IS NOT NULL) OR NVL(OL.MAKE_ORDER_LINE_FLAG, 'N') = 'Y')
            AND EXISTS (SELECT 1
                    FROM T_PLN_ORDER_TYPE T
                   WHERE T.ORDER_TYPE_ID = H.ORDER_TYPE_ID
                     AND T.SOURCE_ORDER_TYPE_ID = 1
                     AND UPPER(NVL(T.IS_BUSINESS_CONTROL, '_')) NOT IN ('PRO_ORDER', 'SHARE_SHIP_ORDER', 'COMPENSATION', 'SC_LG_ORDER')) --提货订单
             --上次更新时间后有更新过的提货订单
             AND EXISTS (SELECT 1
                    FROM T_PLN_LG_ORDER_LINE L
                   WHERE L.ORDER_HEAD_ID = H.ORDER_HEAD_ID
                     --未发货完毕
                     AND L.CENTER_AFFIRM_QUANTITY - NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0) > 0
                     AND L.LAST_UPDATE_DATE >= V_LAST_UPDATE_TIME
                     AND L.LAST_UPDATE_DATE <= V_CURRENT_TIME)
           GROUP BY H.ORDER_HEAD_ID, H.CONSIGNEE_ADDR_CODE)
      LOOP
        V_MAX_CONSIGNMENT_DATE := NULL;
        V_SUM_QTY := 0;
        V_LINE_IDS := NULL;
        --合计未发数量小于起运批量，取最晚的交付日期
        IF R_LG_ORDER.NO_AFFIRM_QTY < V_SHIP_QTY THEN
          SELECT MAX(DECODE(L.MAKE_ORDER_LINE_FLAG,
                            'Y',
                            (SELECT OP.END_DATE
                               FROM T_PLN_LG_RELATION  R,
                                    T_PLN_ORDER_HEAD   OH,
                                    T_PLN_ORDER_PERIOD OP
                              WHERE R.ORDER_HEAD_ID = OH.ORDER_HEAD_ID
                                AND OH.PERIOD_ID = OP.PERIOD_ID
                                AND R.LG_ORDER_LINE_ID = L.ORDER_LINE_ID),
                            L.LAST_WALKTHROUGH_DATE) + V_MANTISSA_DAYS +
                     NVL((SELECT TLL.scatte_transport_days
                                FROM Table(pkg_pln_report.f_Get_Lg_Transport_Line_New((select pa.district_code from T_PLN_PRODUCING_AREA PA
                                                                                        where pA.PRODUCING_AREA_ID = L.PRODUCING_AREA_ID),
                                                                                      R_LG_ORDER.CONSIGNEE_ADDR_CODE,
                                                                                      V_CURRENT_ENTITY_ID)) tll),
                             V_DEFAULT_ONWAY_DAY)
                     )
            INTO V_MAX_CONSIGNMENT_DATE
            FROM T_PLN_LG_ORDER_LINE L
           WHERE L.ORDER_HEAD_ID = R_LG_ORDER.ORDER_HEAD_ID
             AND ((NVL(L.LINE_EFFECTIVE_FLAG, 'Y') = 'Y' AND L.LAST_WALKTHROUGH_DATE IS NOT NULL) OR NVL(L.MAKE_ORDER_LINE_FLAG, 'N') = 'Y')
             AND L.CENTER_AFFIRM_QUANTITY - NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0) > 0;
             
          UPDATE T_PLN_LG_ORDER_LINE L
             SET L.QT_CONSIGNMENT_DATE = V_MAX_CONSIGNMENT_DATE
           WHERE L.ORDER_HEAD_ID = R_LG_ORDER.ORDER_HEAD_ID
             AND ((NVL(L.LINE_EFFECTIVE_FLAG, 'Y') = 'Y' AND L.LAST_WALKTHROUGH_DATE IS NOT NULL) OR NVL(L.MAKE_ORDER_LINE_FLAG, 'N') = 'Y')
             AND L.CENTER_AFFIRM_QUANTITY - NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0) > 0;
        ELSE
          FOR R_LINE IN
            (SELECT L.*
               FROM T_PLN_LG_ORDER_LINE L
              WHERE L.ORDER_HEAD_ID = R_LG_ORDER.ORDER_HEAD_ID
                AND ((NVL(L.LINE_EFFECTIVE_FLAG, 'Y') = 'Y' AND L.LAST_WALKTHROUGH_DATE IS NOT NULL) OR NVL(L.MAKE_ORDER_LINE_FLAG, 'N') = 'Y')
                AND L.CENTER_AFFIRM_QUANTITY - NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0) > 0
              ORDER BY L.CENTER_AFFIRM_QUANTITY - NVL(L.AFFIRMED_QUANTITY, 0) - NVL(L.CANCEL_QTY, 0) DESC)
          LOOP
            IF V_UPDATED THEN
              V_MAX_CONSIGNMENT_DATE := NULL;
              V_SUM_QTY := 0;
              V_LINE_IDS := NULL;
              V_UPDATED := FALSE;
            END IF;
            
            V_SUM_QTY := V_SUM_QTY + R_LINE.CENTER_AFFIRM_QUANTITY - NVL(R_LINE.AFFIRMED_QUANTITY, 0) - NVL(R_LINE.CANCEL_QTY, 0);
            IF V_LINE_IDS IS NULL THEN
              V_LINE_IDS := R_LINE.ORDER_LINE_ID;
            ELSE
              V_LINE_IDS := V_LINE_IDS || ',' || R_LINE.ORDER_LINE_ID;
            END IF;
            
            IF R_LINE.MAKE_ORDER_LINE_FLAG = 'Y' THEN
              SELECT OP.END_DATE + V_MANTISSA_DAYS +
                     NVL((SELECT TLL.scatte_transport_days
                            FROM Table(pkg_pln_report.f_Get_Lg_Transport_Line_New((select pa.district_code from T_PLN_PRODUCING_AREA PA
                                                                                    where pA.PRODUCING_AREA_ID = R_LINE.PRODUCING_AREA_ID),
                                                                                  R_LG_ORDER.CONSIGNEE_ADDR_CODE,
                                                                                  V_CURRENT_ENTITY_ID)) tll),
                         V_DEFAULT_ONWAY_DAY)
                INTO V_CURR_CONSIGNMENT_DATE
                FROM T_PLN_LG_RELATION  R,
                     T_PLN_ORDER_HEAD   OH,
                     T_PLN_ORDER_PERIOD OP
               WHERE R.ORDER_HEAD_ID = OH.ORDER_HEAD_ID
                 AND OH.PERIOD_ID = OP.PERIOD_ID
                 AND R.LG_ORDER_LINE_ID = R_LINE.ORDER_LINE_ID;
            ELSE
              SELECT R_LINE.LAST_WALKTHROUGH_DATE + V_MANTISSA_DAYS +
                     NVL((SELECT TLL.scatte_transport_days

                            FROM Table(pkg_pln_report.f_Get_Lg_Transport_Line_New((select pa.district_code from T_PLN_PRODUCING_AREA PA
                                                                                    where pA.PRODUCING_AREA_ID = R_LINE.PRODUCING_AREA_ID),
                                                                                  R_LG_ORDER.CONSIGNEE_ADDR_CODE,
                                                                                  V_CURRENT_ENTITY_ID)) tll),
                         V_DEFAULT_ONWAY_DAY)
                INTO V_CURR_CONSIGNMENT_DATE
                FROM DUAL;
            END IF;
            
            IF V_CURR_CONSIGNMENT_DATE > V_MAX_CONSIGNMENT_DATE OR V_MAX_CONSIGNMENT_DATE IS NULL THEN
              V_MAX_CONSIGNMENT_DATE := V_CURR_CONSIGNMENT_DATE;
            END IF;
            
            --超过起运批量则更新
            IF V_SUM_QTY > V_SHIP_QTY THEN
              V_UPDATE_SQL := 'UPDATE T_PLN_LG_ORDER_LINE L SET L.QT_CONSIGNMENT_DATE = :1 WHERE L.ORDER_LINE_ID IN (' ||
                              V_LINE_IDS || ')';
              Execute Immediate V_UPDATE_SQL
                Using V_MAX_CONSIGNMENT_DATE;
              V_MAX_CONSIGNMENT_DATE := NULL;
              V_SUM_QTY := 0;
              V_LINE_IDS := NULL;
              V_UPDATED := TRUE;
            END IF;
          END LOOP;
          
          --循环完后还有数据
          IF V_SUM_QTY > 0 AND V_LINE_IDS IS NOT NULL THEN
            V_UPDATE_SQL := 'UPDATE T_PLN_LG_ORDER_LINE L SET L.QT_CONSIGNMENT_DATE = :1 WHERE L.ORDER_LINE_ID IN (' ||
                            V_LINE_IDS || ')';
            Execute Immediate V_UPDATE_SQL
              Using V_MAX_CONSIGNMENT_DATE;
            V_MAX_CONSIGNMENT_DATE := NULL;
            V_SUM_QTY := 0;
            V_LINE_IDS := NULL;
            V_UPDATED := TRUE;
          END IF;
        END IF;
        
        --插入发送接口表
        insert into intf_pln_lg_consignment_stage
          (intf_id,
           order_head_id,
           order_number,
           order_line_id,
           source_line_id,
           consignment_stage,
           created_by,
           creation_date,
           last_updated_by,
           last_update_date,
           trx_no,
           intf_status)
          SELECT s_intf_pln_consignment_stage.nextval,
                 LG.ORDER_HEAD_ID,
                 LG.ORDER_NUMBER,
                 LG.ORDER_LINE_ID,
                 LG.SOURCE_LINE_ID,
                 case
                   when ceil(to_number(to_char(LG.CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY) >=
                     trunc(to_number(to_char(last_day(LG.CONSIGNMENT_DATE), 'dd')) / V_PERIOD_DAY) then
                     to_char(LG.CONSIGNMENT_DATE, 'yyyy') || '年' ||
                     to_char(LG.CONSIGNMENT_DATE, 'mm') || '月' ||
                     lpad(to_char((trunc(to_number(to_char(last_day(LG.CONSIGNMENT_DATE), 'dd')) / V_PERIOD_DAY)-1) * V_PERIOD_DAY + 1), 2, '0') || '日到' ||
                     lpad(to_char(last_day(LG.CONSIGNMENT_DATE), 'dd'), 2, '0') || '日'
                   when mod(to_number(to_char(LG.CONSIGNMENT_DATE, 'dd')), V_PERIOD_DAY) = 0 then
                     to_char(LG.CONSIGNMENT_DATE, 'yyyy') || '年' ||
                     to_char(LG.CONSIGNMENT_DATE, 'mm') || '月' ||
                     lpad(to_char((trunc(to_number(to_char(LG.CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY)-1) * V_PERIOD_DAY + 1), 2, '0') || '日到' ||
                     lpad(to_char(trunc(to_number(to_char(LG.CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY) * V_PERIOD_DAY), 2, '0') || '日'
                   else
                     to_char(LG.CONSIGNMENT_DATE, 'yyyy') || '年' ||
                     to_char(LG.CONSIGNMENT_DATE, 'mm') || '月' ||
                     lpad(to_char(trunc(to_number(to_char(LG.CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY) * V_PERIOD_DAY + 1), 2, '0') || '日到' ||
                     lpad(to_char(trunc(to_number(to_char(LG.CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY) * V_PERIOD_DAY + V_PERIOD_DAY), 2, '0') || '日'
                 end consignment_stage,
                 'admin',
                 sysdate,
                 'admin',
                 sysdate,
                 null,
                 'N'
            FROM (select L.ORDER_HEAD_ID,
                         H.ORDER_NUMBER,
                         L.ORDER_LINE_ID,
                         L.SOURCE_LINE_ID,
                         L.QT_CONSIGNMENT_DATE CONSIGNMENT_DATE,
                         L.ESTIMATE_CONSIGNMENT_STAGE
                    from T_PLN_LG_ORDER_LINE L, T_PLN_LG_ORDER_HEAD H
                   where L.ORDER_HEAD_ID = H.ORDER_HEAD_ID
                     AND L.ORDER_HEAD_ID = R_LG_ORDER.ORDER_HEAD_ID
                     AND H.SYS_SOURCE = 'CCS'
                     AND (NVL(L.LINE_EFFECTIVE_FLAG, 'Y') = 'Y'
                         OR NVL(L.MAKE_ORDER_LINE_FLAG, 'N') = 'Y')) LG
           WHERE LG.CONSIGNMENT_DATE IS NOT NULL
             AND NVL(LG.ESTIMATE_CONSIGNMENT_STAGE, '_') <>
                 case
                   when ceil(to_number(to_char(LG.CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY) >=
                     trunc(to_number(to_char(last_day(LG.CONSIGNMENT_DATE), 'dd')) / V_PERIOD_DAY) then
                     to_char(LG.CONSIGNMENT_DATE, 'yyyy') || '年' ||
                     to_char(LG.CONSIGNMENT_DATE, 'mm') || '月' ||
                     lpad(to_char((trunc(to_number(to_char(last_day(LG.CONSIGNMENT_DATE), 'dd')) / V_PERIOD_DAY)-1) * V_PERIOD_DAY + 1), 2, '0') || '日到' ||
                     lpad(to_char(last_day(LG.CONSIGNMENT_DATE), 'dd'), 2, '0') || '日'
                   when mod(to_number(to_char(LG.CONSIGNMENT_DATE, 'dd')), V_PERIOD_DAY) = 0 then
                     to_char(LG.CONSIGNMENT_DATE, 'yyyy') || '年' ||
                     to_char(LG.CONSIGNMENT_DATE, 'mm') || '月' ||
                     lpad(to_char((trunc(to_number(to_char(LG.CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY)-1) * V_PERIOD_DAY + 1), 2, '0') || '日到' ||
                     lpad(to_char(trunc(to_number(to_char(LG.CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY) * V_PERIOD_DAY), 2, '0') || '日'
                   else
                     to_char(LG.CONSIGNMENT_DATE, 'yyyy') || '年' ||
                     to_char(LG.CONSIGNMENT_DATE, 'mm') || '月' ||
                     lpad(to_char(trunc(to_number(to_char(LG.CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY) * V_PERIOD_DAY + 1), 2, '0') || '日到' ||
                     lpad(to_char(trunc(to_number(to_char(LG.CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY) * V_PERIOD_DAY + V_PERIOD_DAY), 2, '0') || '日'
                 end
             ;
        
        --更新交期
        UPDATE T_PLN_LG_ORDER_LINE L
           SET L.ESTIMATE_CONSIGNMENT_STAGE = 
               case
                 when ceil(to_number(to_char(L.QT_CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY) >=
                   trunc(to_number(to_char(last_day(L.QT_CONSIGNMENT_DATE), 'dd')) / V_PERIOD_DAY) then
                   to_char(L.QT_CONSIGNMENT_DATE, 'yyyy') || '年' ||
                   to_char(L.QT_CONSIGNMENT_DATE, 'mm') || '月' ||
                   lpad(to_char((trunc(to_number(to_char(last_day(L.Qt_Consignment_Date), 'dd')) / V_PERIOD_DAY)-1) * V_PERIOD_DAY + 1), 2, '0') || '日到' ||
                   lpad(to_char(last_day(L.QT_CONSIGNMENT_DATE), 'dd'), 2, '0') || '日'
                 when mod(to_number(to_char(L.QT_CONSIGNMENT_DATE, 'dd')), V_PERIOD_DAY) = 0 then
                   to_char(L.QT_CONSIGNMENT_DATE, 'yyyy') || '年' ||
                   to_char(L.QT_CONSIGNMENT_DATE, 'mm') || '月' ||
                   lpad(to_char((trunc(to_number(to_char(L.QT_CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY)-1) * V_PERIOD_DAY + 1), 2, '0') || '日到' ||
                   lpad(to_char(trunc(to_number(to_char(L.QT_CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY) * V_PERIOD_DAY), 2, '0') || '日'
                 else
                   to_char(L.QT_CONSIGNMENT_DATE, 'yyyy') || '年' ||
                   to_char(L.QT_CONSIGNMENT_DATE, 'mm') || '月' ||
                   lpad(to_char(trunc(to_number(to_char(L.QT_CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY) * V_PERIOD_DAY + 1), 2, '0') || '日到' ||
                   lpad(to_char(trunc(to_number(to_char(L.QT_CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY) * V_PERIOD_DAY + V_PERIOD_DAY), 2, '0') || '日'
               end
         WHERE L.ORDER_HEAD_ID = R_LG_ORDER.ORDER_HEAD_ID
           AND L.QT_CONSIGNMENT_DATE IS NOT NULL
           AND (NVL(L.LINE_EFFECTIVE_FLAG, 'Y') = 'Y' OR NVL(L.MAKE_ORDER_LINE_FLAG, 'N') = 'Y')
           AND NVL(L.ESTIMATE_CONSIGNMENT_STAGE, '_') <> 
               case
                 when ceil(to_number(to_char(L.QT_CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY) >=
                   trunc(to_number(to_char(last_day(L.QT_CONSIGNMENT_DATE), 'dd')) / V_PERIOD_DAY) then
                   to_char(L.QT_CONSIGNMENT_DATE, 'yyyy') || '年' ||
                   to_char(L.QT_CONSIGNMENT_DATE, 'mm') || '月' ||
                   lpad(to_char((trunc(to_number(to_char(last_day(l.qt_consignment_date), 'dd')) / V_PERIOD_DAY)-1) * V_PERIOD_DAY + 1), 2, '0') || '日到' ||
                   lpad(to_char(last_day(L.QT_CONSIGNMENT_DATE), 'dd'), 2, '0') || '日'
                 when mod(to_number(to_char(L.QT_CONSIGNMENT_DATE, 'dd')), V_PERIOD_DAY) = 0 then
                   to_char(L.QT_CONSIGNMENT_DATE, 'yyyy') || '年' ||
                   to_char(L.QT_CONSIGNMENT_DATE, 'mm') || '月' ||
                   lpad(to_char((trunc(to_number(to_char(L.QT_CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY)-1) * V_PERIOD_DAY + 1), 2, '0') || '日到' ||
                   lpad(to_char(trunc(to_number(to_char(L.QT_CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY) * V_PERIOD_DAY), 2, '0') || '日'
                 else
                   to_char(L.QT_CONSIGNMENT_DATE, 'yyyy') || '年' ||
                   to_char(L.QT_CONSIGNMENT_DATE, 'mm') || '月' ||
                   lpad(to_char(trunc(to_number(to_char(L.QT_CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY) * V_PERIOD_DAY + 1), 2, '0') || '日到' ||
                   lpad(to_char(trunc(to_number(to_char(L.QT_CONSIGNMENT_DATE, 'dd')) / V_PERIOD_DAY) * V_PERIOD_DAY + V_PERIOD_DAY), 2, '0') || '日'
               end;
        commit;
      END LOOP;
      
      UPDATE T_BD_PARAM_ENTITY E
         SET E.ENTITY_VALUE = TO_CHAR(V_CURRENT_TIME, 'YYYY-MM-DD HH24:MI:SS')
       WHERE E.ENTITY_ID = V_CURRENT_ENTITY_ID
         AND E.PARAM_LIST_ID =
             (SELECT L.PARAM_LIST_ID
                FROM T_BD_PARAM_LIST L
               WHERE L.PARAM_CODE = 'PLN_CONSIGNMENT_STAGE_LAST_DATE');
      commit;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      Rollback;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'P_UPD_LGLINE_CONSIGNMENT_STAGE',
                                  p_Error_Msg            => '更新订单行齐套交付日期：' || sqlerrm,
                                  p_Source_Order_Head_Id => NULL,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
      commit;
  END P_UPD_LGLINE_CONSIGNMENT_STAGE;
  
------------------------------------------------------------------------------------------------
-- AUTHOR  : CHENYJ8
-- CREATED : 2018-09-18
-- PURPOSE : 客户订单逾期报表
------------------------------------------------------------------------------------------------
PROCEDURE P_PLN_LG_CUST_OVERDUE(IN_ENTITY_ID IN NUMBER, --主体
                                P_RESULT     IN OUT NUMBER, --返回错误ID
                                P_ERR_MSG    IN OUT VARCHAR2 --返回错误信息
                                ) IS
  V_INFO_ID         NUMBER; --批次号
  V_RATE_YEAR       NUMBER; --年费率
  V_CNT             NUMBER; --临时计数
  V_CAN_SHIP_AMOUNT NUMBER; --账户可提货金额
  V_AMOUNT_TEMP     NUMBER; --临时变量
  V_OVERDUE_FLAG    VARCHAR(2); --判定是否逾期
  V_CREDIT_GROUP_ID NUMBER; --额度组ID
BEGIN
  P_RESULT  := 0;
  P_ERR_MSG := 'SUCCESS';
  --取年费率
  BEGIN
    V_RATE_YEAR := TO_NUMBER(PKG_BD.F_GET_PARAMETER_VALUE('PLN_CUST_OVERDUE_RAT',
                                                          IN_ENTITY_ID,
                                                          NULL,
                                                          NULL));
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -1;
      P_ERR_MSG := 'PLN_CUST_OVERDUE_RAT 主体参数,主体:' || IN_ENTITY_ID ||
                   '的参数设置异常，请检查。' || SQLERRM;
      RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
  END;

  --批次号
  V_INFO_ID := S_PLN_CUST_OVERDUE.NEXTVAL;
  --PKG_CREDIT_TOOLS.P_GET_AMOUNT
  INSERT INTO T_PLN_CUST_OVERDUE_HIS
    (INFO_ID,
     ENTITY_ID,
     CUSTOMER_ID,
     CUSTOMER_CODE,
     CUSTOMER_NAME,
     ACCOUNT_ID,
     ACCOUNT_CODE,
     ORDER_NUMBER,
     ORDER_DATE,
     END_SUPPLY_DATE,
     NO_AFFIRM_AMOUNT,
     CHECK_DATE,
     BATCH_ID,
     RATE_YEAR,
     CREATED_BY,
     LAST_UPDATED_BY,
     ORDER_HEAD_ID,
     SALES_MAIN_TYPE,
     SALES_CENTER_ID,
     SALES_CENTER_CODE,
     SALES_CENTER_NAME
     )
    SELECT S_PLN_CUST_OVERDUE_HIS.NEXTVAL,
           IN_ENTITY_ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           CUSTOMER_NAME,
           ACCOUNT_ID,
           ACCOUNT_CODE,
           ORDER_NUMBER,
           ORDER_DATE,
           END_SUPPLY_DATE,
           NO_AFFIRM_AMOUNT,
           SYSDATE,
           V_INFO_ID,
           V_RATE_YEAR,
           'JOB',
           'JOB',
           ORDER_HEAD_ID,
           SALES_MAIN_TYPE,
           SALES_CENTER_ID,
           SALES_CENTER_CODE,
           SALES_CENTER_NAME
      FROM (SELECT H.ORDER_HEAD_ID,
                   H.CUSTOMER_ID,
                   H.CUSTOMER_NAME,
                   H.CUSTOMER_CODE,
                   H.ACCOUNT_ID,
                   H.ACCOUNT_CODE,
                   H.ORDER_NUMBER,
                   H.ORDER_DATE,
                   ROUND((SELECT SUM((NVL(OL.CENTER_AFFIRM_QUANTITY, 0) -
                                    NVL(OL.CANCEL_QTY, 0) -
                                    NVL(OL.AFFIRMED_QUANTITY, 0) -
                                    (NVL(OL.DIRECT_TRANSPORT_QTY, 0) -
                                    NVL(OL.ALREADY_DIRECT_TRANSPORT_QTY, 0))) *
                                    DECODE(OL.PROJECT_ORDER_LINE_ID,
                                           NULL,
                                           OL.LIST_PRICE *
                                           (100 -
                                           NVL(OL.ORDERED_DISCOUNT_RATE, 0) -
                                           NVL(OL.DISCOUNT_RATE, 0)) / 100,
                                           OL.APPLY_LIST_PRICE *
                                           (100 -
                                           NVL(OL.ORDERED_DISCOUNT_RATE, 0) -
                                           NVL(OL.APPLY_DISCOUNT_RATE, 0)) / 100))
                           FROM CIMS.T_PLN_LG_ORDER_LINE OL
                          WHERE OL.ORDER_HEAD_ID = H.ORDER_HEAD_ID
                                AND OL.MAKE_ORDER_LINE_FLAG = 'Y'
                            AND NVL(OL.ORDER_LINE_STATE, 'NORMAL') !=
                                'CLOSED'),
                         2) NO_AFFIRM_AMOUNT,
                   
                   (SELECT MAX(PL.END_SUPPLY_DATE)
                      FROM CIMS.T_PLN_LG_RELATION LR,
                           CIMS.T_PLN_ORDER_LINE  PL
                     WHERE LR.ORDER_LINE_ID = PL.ORDER_LINE_ID
                       AND LR.LG_ORDER_HEAD_ID = H.ORDER_HEAD_ID
                       AND PL.END_SUPPLY_DATE < SYSDATE
                      ) END_SUPPLY_DATE,
                   H.SALES_MAIN_TYPE,
                   H.SALES_CENTER_ID,
                   H.SALES_CENTER_CODE,
                   H.SALES_CENTER_NAME
              FROM CIMS.T_PLN_LG_ORDER_HEAD H
             WHERE H.ORDER_HEAD_STATE NOT IN ('23', '304')
               AND H.NEAT_SET_LINE = 100
               AND EXISTS (SELECT 1
                      FROM CIMS.T_PLN_LG_RELATION LR,
                           CIMS.T_PLN_ORDER_HEAD  OH
                     WHERE H.ORDER_HEAD_ID = LR.LG_ORDER_HEAD_ID
                       AND LR.ORDER_HEAD_ID = OH.ORDER_HEAD_ID)
               AND EXISTS (SELECT 1
                      FROM CIMS.T_PLN_ORDER_TYPE T
                     WHERE T.ORDER_TYPE_ID = H.ORDER_TYPE_ID
                       AND T.SOURCE_ORDER_TYPE_ID = 1)
               AND H.ENTITY_ID = IN_ENTITY_ID
               AND H.ORDER_DATE > ADD_MONTHS(SYSDATE, -15))
     WHERE NO_AFFIRM_AMOUNT > 0;

  --计算逾期利息
  FOR R_ACCOUNT IN (SELECT DISTINCT T.CUSTOMER_ID, T.ACCOUNT_ID
                      FROM T_PLN_CUST_OVERDUE_HIS T
                     WHERE T.BATCH_ID = V_INFO_ID) LOOP
  
    BEGIN
      PKG_CREDIT_TOOLS.P_GET_AMOUNT(IN_ENTITY_ID               => IN_ENTITY_ID, --主体ID，不能为空
                                    IN_CUSTOMER_ID             => R_ACCOUNT.CUSTOMER_ID, --客户ID，不能为空
                                    IN_ACCOUNT_ID              => R_ACCOUNT.ACCOUNT_ID, --账户ID，可以为空
                                    IS_SALES_MAIN_TYPE         => NULL, --营销大类，可以为空
                                    IN_CREDIT_GROUP_ID         => NULL, --额度组ID，可以为空
                                    ON_PICKUP_AMOUNT           => V_CAN_SHIP_AMOUNT, --返回可提货金额
                                    ON_AVL_RCV_AMOUNT          => V_CNT, --返回可用到款金额
                                    ON_RCV_BALANCE_AMOUNT      => V_CNT, --返回到款余额
                                    ON_AVL_DISCOUNT_AMOUNT     => V_CNT, --返回可用折让余额
                                    ON_DISCOUNT_BALANCE_AMOUNT => V_CNT --返回折让余额
                                    );
      --按账户更新可提货金额
      UPDATE T_PLN_CUST_OVERDUE_HIS T
         SET T.CAN_SHIP_AMOUNT = V_CAN_SHIP_AMOUNT
       WHERE T.CUSTOMER_ID = R_ACCOUNT.CUSTOMER_ID
         AND T.ACCOUNT_ID = R_ACCOUNT.ACCOUNT_ID
         AND T.BATCH_ID = V_INFO_ID;
    
      --没有可提货金额，全部订单算逾期
      IF V_CAN_SHIP_AMOUNT <= 0 THEN
        UPDATE T_PLN_CUST_OVERDUE_HIS T
           SET T.PROCESS_FLAG = 'Y', T.OVERDUE_FLAG = 'Y'
         WHERE T.BATCH_ID = V_INFO_ID
           AND T.ACCOUNT_ID = R_ACCOUNT.ACCOUNT_ID;
        COMMIT;
        CONTINUE;
      END IF;
    
      --订单金额大于可用提货的一律算逾期
      UPDATE T_PLN_CUST_OVERDUE_HIS T
         SET T.PROCESS_FLAG = 'Y', T.OVERDUE_FLAG = 'Y'
       WHERE T.BATCH_ID = V_INFO_ID
         AND T.ACCOUNT_ID = R_ACCOUNT.ACCOUNT_ID
         AND T.NO_AFFIRM_AMOUNT > V_CAN_SHIP_AMOUNT;
    
      --按订单金额从小到大核销可提货金额
      FOR R_OVERDUE IN (SELECT *
                          FROM T_PLN_CUST_OVERDUE_HIS T
                         WHERE T.BATCH_ID = V_INFO_ID
                           AND T.ACCOUNT_ID = R_ACCOUNT.ACCOUNT_ID
                           AND NVL(T.PROCESS_FLAG, 'N') = 'N'
                         ORDER BY T.NO_AFFIRM_AMOUNT ASC) LOOP
        IF R_OVERDUE.NO_AFFIRM_AMOUNT > V_CAN_SHIP_AMOUNT THEN
          V_CAN_SHIP_AMOUNT := V_CAN_SHIP_AMOUNT -
                               R_OVERDUE.NO_AFFIRM_AMOUNT;
          UPDATE T_PLN_CUST_OVERDUE_HIS T
             SET T.PROCESS_FLAG = 'Y', T.OVERDUE_FLAG = 'Y'
           WHERE T.INFO_ID = R_OVERDUE.INFO_ID;
        ELSE
          --按大类核销
          FOR R_ORDER_LINE IN (SELECT SALES_MAIN_TYPE,
                                      ROUND(NO_AMOUNT, 2) NO_AMOUNT
                                 FROM (SELECT OL.SALES_MAIN_TYPE,
                                              SUM((NVL(OL.CENTER_AFFIRM_QUANTITY,
                                                       0) -
                                                  NVL(OL.CANCEL_QTY, 0) -
                                                  NVL(OL.AFFIRMED_QUANTITY,
                                                       0) -
                                                  (NVL(OL.DIRECT_TRANSPORT_QTY,
                                                        0) -
                                                  NVL(OL.ALREADY_DIRECT_TRANSPORT_QTY,
                                                        0))) *
                                                  DECODE(OL.PROJECT_ORDER_LINE_ID,
                                                         NULL,
                                                         OL.LIST_PRICE *
                                                         (100 - NVL(OL.ORDERED_DISCOUNT_RATE,
                                                                    0) -
                                                         NVL(OL.DISCOUNT_RATE,
                                                              0)) / 100,
                                                         OL.APPLY_LIST_PRICE *
                                                         (100 - NVL(OL.ORDERED_DISCOUNT_RATE,
                                                                    0) -
                                                         NVL(OL.APPLY_DISCOUNT_RATE,
                                                              0)) / 100)) NO_AMOUNT
                                         FROM CIMS.T_PLN_LG_ORDER_LINE OL
                                        WHERE OL.ORDER_HEAD_ID =
                                              R_OVERDUE.ORDER_HEAD_ID
                                              AND OL.MAKE_ORDER_LINE_FLAG = 'Y'
                                          AND NVL(OL.ORDER_LINE_STATE,
                                                  'NORMAL') != 'CLOSED'
                                        GROUP BY OL.SALES_MAIN_TYPE)
                                WHERE NO_AMOUNT > 0) LOOP
          
          --先取大类对应的额度组,再取额度组可用余额
          V_CREDIT_GROUP_ID := PKG_CREDIT_TOOLS.FUN_GET_CREDITGROUPID(IN_ENTITY_ID,
                               R_ACCOUNT.CUSTOMER_ID,
                               R_ORDER_LINE.SALES_MAIN_TYPE,
                               R_ACCOUNT.ACCOUNT_ID);
            PKG_CREDIT_TOOLS.P_GET_AMOUNT(IN_ENTITY_ID               => IN_ENTITY_ID, --主体ID，不能为空
                                          IN_CUSTOMER_ID             => R_ACCOUNT.CUSTOMER_ID, --客户ID，不能为空
                                          IN_ACCOUNT_ID              => R_ACCOUNT.ACCOUNT_ID, --账户ID，可以为空
                                          IS_SALES_MAIN_TYPE         => NULL, --营销大类，可以为空
                                          IN_CREDIT_GROUP_ID         => V_CREDIT_GROUP_ID, --额度组ID，可以为空
                                          ON_PICKUP_AMOUNT           => V_AMOUNT_TEMP, --返回可提货金额
                                          ON_AVL_RCV_AMOUNT          => V_CNT, --返回可用到款金额
                                          ON_RCV_BALANCE_AMOUNT      => V_CNT, --返回到款余额
                                          ON_AVL_DISCOUNT_AMOUNT     => V_CNT, --返回可用折让余额
                                          ON_DISCOUNT_BALANCE_AMOUNT => V_CNT --返回折让余额
                                          );
            --某个大类订单额度大于可用提货额度，直接逾期并跳出循环，否则继续核销账户总金额
            IF R_ORDER_LINE.NO_AMOUNT > V_AMOUNT_TEMP THEN
              UPDATE T_PLN_CUST_OVERDUE_HIS T
                 SET T.PROCESS_FLAG = 'Y', T.OVERDUE_FLAG = 'Y'
               WHERE T.INFO_ID = R_OVERDUE.INFO_ID;
              EXIT;
            ELSE
              V_CAN_SHIP_AMOUNT := V_CAN_SHIP_AMOUNT - R_ORDER_LINE.NO_AMOUNT;
            END IF;
            IF V_CAN_SHIP_AMOUNT < 0 THEN
              UPDATE T_PLN_CUST_OVERDUE_HIS T
                 SET T.PROCESS_FLAG = 'Y', T.OVERDUE_FLAG = 'Y'
               WHERE T.INFO_ID = R_OVERDUE.INFO_ID;
              EXIT;
            END IF;
          
          END LOOP;
        
        END IF;
      
      END LOOP;
    
    EXCEPTION
      WHEN OTHERS THEN
        P_RESULT  := -1;
        P_ERR_MSG := '处理逾期账户异常，账户ID[' || R_ACCOUNT.ACCOUNT_ID || '],客户ID[' ||
                     R_ACCOUNT.CUSTOMER_ID || '],' ||
                     SUBSTR(SQLERRM, 1, 1000);
      
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
      
    END;
  END LOOP;

  --计算利息
  UPDATE T_PLN_CUST_OVERDUE_HIS T
     SET T.OVERDUE_TIME   = ROUND(TO_NUMBER(T.CHECK_DATE - T.END_SUPPLY_DATE),
                                  2),
         T.OVERDUE_AMOUNT = ROUND(T.RATE_YEAR / 100 / 365 *
                            ROUND(TO_NUMBER(T.CHECK_DATE - T.END_SUPPLY_DATE),
                                  2) * T.NO_AFFIRM_AMOUNT,2)
   WHERE T.BATCH_ID = V_INFO_ID
     AND T.OVERDUE_FLAG = 'Y';
  --清空正式表逾期
  --DELETE FROM CIMS.T_PLN_CUST_OVERDUE T WHERE T.ENTITY_ID = IN_ENTITY_ID;
  --插入本次运算逾期数据
  INSERT INTO T_PLN_CUST_OVERDUE
    (INFO_ID,
     ENTITY_ID,
     CUSTOMER_ID,
     CUSTOMER_CODE,
     CUSTOMER_NAME,
     ACCOUNT_ID,
     ACCOUNT_CODE,
     ORDER_NUMBER,
     ORDER_DATE,
     END_SUPPLY_DATE,
     NO_AFFIRM_AMOUNT,
     CHECK_DATE,
     BATCH_ID,
     RATE_YEAR,
     CREATED_BY,
     LAST_UPDATED_BY,
     ORDER_HEAD_ID,
     OVERDUE_TIME,
     OVERDUE_AMOUNT,
     OVERDUE_FLAG,
     CAN_SHIP_AMOUNT,
     SALES_MAIN_TYPE,
     SALES_CENTER_ID,
     SALES_CENTER_CODE,
     SALES_CENTER_NAME
     )
    SELECT S_PLN_CUST_OVERDUE.NEXTVAL,
           IN_ENTITY_ID,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           CUSTOMER_NAME,
           ACCOUNT_ID,
           ACCOUNT_CODE,
           ORDER_NUMBER,
           ORDER_DATE,
           END_SUPPLY_DATE,
           NO_AFFIRM_AMOUNT,
           CHECK_DATE,
           BATCH_ID,
           RATE_YEAR,
           CREATED_BY,
           LAST_UPDATED_BY,
           ORDER_HEAD_ID,
           OVERDUE_TIME,
           OVERDUE_AMOUNT,
           OVERDUE_FLAG,
           CAN_SHIP_AMOUNT,
           SALES_MAIN_TYPE,
           SALES_CENTER_ID,
           SALES_CENTER_CODE,
           SALES_CENTER_NAME
      FROM CIMS.T_PLN_CUST_OVERDUE_HIS T
     WHERE T.ENTITY_ID = IN_ENTITY_ID
       AND T.BATCH_ID = V_INFO_ID;
       
 --计算到账时间
 update cims.T_PLN_CUST_OVERDUE lastTime
    set lastTime.countTime = lastTime.Check_Date
  where lastTime.Batch_Id = (select max(mx.batch_id) max_id
                               from cims.T_PLN_CUST_OVERDUE mx
                              where mx.entity_id = IN_ENTITY_ID
                                and mx.Batch_Id < V_INFO_ID)
    and not exists
  (select 1
           from cims.T_PLN_CUST_OVERDUE thisTime
          where thisTime.Batch_Id = V_INFO_ID
            and lastTime.Order_Number = thisTime.Order_Number);
 
 update cims.T_PLN_CUST_OVERDUE lastTime
    set lastTime.countTime = lastTime.Check_Date
  where lastTime.Batch_Id = (select max(mx.batch_id) max_id
                               from cims.T_PLN_CUST_OVERDUE mx
                              where mx.entity_id = IN_ENTITY_ID
                                and mx.Batch_Id < V_INFO_ID)
    and lastTime.Overdue_Flag = 'Y'
    and exists
  (select 1
           from cims.T_PLN_CUST_OVERDUE thisTime
          where thisTime.Batch_Id = V_INFO_ID
            and thisTime.Overdue_Flag = 'N'
            and lastTime.Order_Number = thisTime.Order_Number
            );
            

EXCEPTION
  WHEN OTHERS THEN
    P_RESULT  := -1;
    P_ERR_MSG := P_ERR_MSG || ',处理逾期账户异常,' || SUBSTR(SQLERRM, 1, 500);
    PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'PLN',
                                P_PROCEDURE_NAME       => 'P_PLN_LG_CUST_OVERDUE',
                                P_ERROR_MSG            => P_ERR_MSG,
                                P_SOURCE_ORDER_HEAD_ID => NULL,
                                P_SOURCE_ORDER_LINE_ID => NULL,
                                P_ITEM_ID              => NULL,
                                P_INVENTORY_ID         => NULL,
                                P_QUANTITY             => NULL);
END;

  ------------------------------------------------------------------------------------------------
  -- Author  : hejy3
  -- Created : 2018-12-26
  -- Purpose : 订单状态变更信息写入接口
  ------------------------------------------------------------------------------------------------
  PROCEDURE P_FREEZE_LG_ORDER_STATE(IN_ENTITY_ID IN NUMBER DEFAULT -1 --主体
                                    )
  IS
    V_CURRENT_TIME DATE;
    V_LAST_UPDATE_TIME DATE;
    V_CURRENT_ENTITY_ID NUMBER;
    V_NEED_PUSH_FLAG BOOLEAN := FALSE; --是否需要推送
    
    --上次推送数据
    V_LAST_HEAD_STATE T_PLN_LG_ORDER_HEAD.ORDER_HEAD_STATE%TYPE;
    V_LAST_PUSH_STATE VARCHAR2(100);
    V_LAST_CLOSED_LINE_COUNT NUMBER;
    V_LAST_HQ_AFFIRMED_QTY NUMBER;
    V_LAST_PLN_AFFIRMED_QTY NUMBER;
    V_LAST_FACT_SHIP_QTY NUMBER;
    
    --当前数据
    V_CURR_HEAD_STATE T_PLN_LG_ORDER_HEAD.ORDER_HEAD_STATE%TYPE;
    V_CURR_HEAD_STATE_NAME T_PLN_FLOW_TYPE_STATUS.STATUS_CODE%type;
    V_CURR_PUSH_STATE VARCHAR2(100);
    V_CURR_CLOSED_LINE_COUNT NUMBER;
    V_CURR_HQ_AFFIRMED_QTY NUMBER;
    V_CURR_PLN_AFFIRMED_QTY NUMBER;
    V_CURR_FACT_SHIP_QTY NUMBER;
    V_CURR_AFFIEMED_QTY NUMBER;
    
    V_LINE_STATE_CHG_FLAG VARCHAR2(2) := 'N';
    V_COUNT NUMBER;
  BEGIN
    V_CURRENT_TIME := SYSDATE;
    FOR R_ENTITY IN (
      SELECT BE.entity_id
        FROM V_BD_ENTITY BE
       WHERE (BE.entity_id = IN_ENTITY_ID OR IN_ENTITY_ID = -1)
      ) LOOP
      V_CURRENT_ENTITY_ID := R_ENTITY.ENTITY_ID;
      --获取上次更新时间
      BEGIN
        SELECT TO_DATE(pkg_bd.F_GET_PARAMETER_VALUE('PLN_ORDER_STATE_LAST_DATE',
                                                    V_CURRENT_ENTITY_ID,
                                                    NULL,
                                                    NULL),
                       'YYYY-MM-DD HH24:MI:SS')
          INTO V_LAST_UPDATE_TIME
          FROM dual;
      EXCEPTION
        WHEN OTHERS THEN
          V_LAST_UPDATE_TIME := V_CURRENT_TIME - 1;
      END;
      
      --取上次更新时间后有更新过的提货订单
      FOR R_LG IN
        (SELECT H.ENTITY_ID,
                H.ORDER_HEAD_ID,
                H.SUBMIT_TO_HQ_FLAG,
                H.ORDER_NUMBER,
                H.SOURCE_ORDER_NUMBER,
                H.CUSTOMER_ID,
                H.CUSTOMER_CODE,
                H.CUSTOMER_NAME
           FROM T_PLN_LG_ORDER_HEAD H
          WHERE H.ENTITY_ID = V_CURRENT_ENTITY_ID
            AND H.ORDER_HEAD_STATE IN ('679', '381', '23', '415', '304')
            AND H.SYS_SOURCE = 'CCS'
            AND H.LAST_UPDATE_DATE >= V_LAST_UPDATE_TIME
            AND H.LAST_UPDATE_DATE <= V_CURRENT_TIME
         UNION
         SELECT H.ENTITY_ID,
                H.ORDER_HEAD_ID,
                H.SUBMIT_TO_HQ_FLAG,
                H.ORDER_NUMBER,
                H.SOURCE_ORDER_NUMBER,
                H.CUSTOMER_ID,
                H.CUSTOMER_CODE,
                H.CUSTOMER_NAME
           FROM T_PLN_LG_ORDER_HEAD H
          WHERE H.ENTITY_ID = V_CURRENT_ENTITY_ID
            AND H.ORDER_HEAD_STATE IN ('679', '381', '23', '415', '304')
            AND H.SYS_SOURCE = 'CCS'
            AND EXISTS (SELECT 1 FROM T_PLN_LG_ORDER_LINE L
                         WHERE L.ORDER_HEAD_ID = H.ORDER_HEAD_ID
                           AND L.LAST_UPDATE_DATE >= V_LAST_UPDATE_TIME
                           AND L.LAST_UPDATE_DATE <= V_CURRENT_TIME)
         UNION
         SELECT H.ENTITY_ID,
                H.ORDER_HEAD_ID,
                H.SUBMIT_TO_HQ_FLAG,
                H.ORDER_NUMBER,
                H.SOURCE_ORDER_NUMBER,
                H.CUSTOMER_ID,
                H.CUSTOMER_CODE,
                H.CUSTOMER_NAME
           FROM T_PLN_LG_ORDER_HEAD H
          WHERE H.ENTITY_ID = V_CURRENT_ENTITY_ID
            AND H.ORDER_HEAD_STATE IN ('679', '381', '23', '415', '304')
            AND H.SYS_SOURCE = 'CCS'
            AND EXISTS (SELECT 1 FROM T_LG_SHIP_DOC_LINE DL
                         WHERE NVL(DL.ORIGIN_ORIGIN_HEAD_ID, DL.ORIGIN_ORDER_ID) = H.ORDER_HEAD_ID
                           AND (DL.ORIGIN_ORIGIN_TYPE = '02' OR DL.ORIGIN_TYPE = '02')
                           AND DL.FACT_SHIP_DATE >= V_LAST_UPDATE_TIME
                           AND DL.FACT_SHIP_DATE <= V_CURRENT_TIME))
      LOOP
        V_NEED_PUSH_FLAG := FALSE;
        V_LINE_STATE_CHG_FLAG := 'N';
        --获取上次推送数据
        BEGIN
          SELECT ORDER_HEAD_STATE,
                 PUSH_STATE,
                 CLOSED_LINE_COUNT,
                 LINE_HQ_AFFIRMED_QTY,
                 LINE_PLN_AFFIRMED_QTY,
                 LINE_FACT_SHIP_QTY
            INTO V_LAST_HEAD_STATE,
                 V_LAST_PUSH_STATE,
                 V_LAST_CLOSED_LINE_COUNT,
                 V_LAST_HQ_AFFIRMED_QTY,
                 V_LAST_PLN_AFFIRMED_QTY,
                 V_LAST_FACT_SHIP_QTY
            FROM (SELECT S.ORDER_HEAD_STATE,
                         S.PUSH_STATE,
                         S.CLOSED_LINE_COUNT,
                         S.LINE_HQ_AFFIRMED_QTY,
                         S.LINE_PLN_AFFIRMED_QTY,
                         S.LINE_FACT_SHIP_QTY
                    FROM INTF_LG_ORDER_STATE S
                   WHERE S.ENTITY_ID = R_LG.ENTITY_ID
                     AND S.ORDER_HEAD_ID = R_LG.ORDER_HEAD_ID
                   ORDER BY S.CREATION_DATE DESC)
           WHERE ROWNUM = 1;
        EXCEPTION
          WHEN OTHERS THEN
            V_LAST_HEAD_STATE := v_Null;
            V_LAST_PUSH_STATE := v_Null;
            V_LAST_CLOSED_LINE_COUNT := 0;
            V_LAST_HQ_AFFIRMED_QTY := 0;
            V_LAST_PLN_AFFIRMED_QTY := 0;
            V_LAST_FACT_SHIP_QTY := 0;
        END;
        
        --当前单据状态
        SELECT H.ORDER_HEAD_STATE,
               S.STATUS_CODE,
               SUM(DECODE(L.ORDER_LINE_STATE, 'CLOSED', 1, 0)),
               SUM(NVL(L.HQ_AFFIRMED_QTY, 0)),
               SUM(NVL(L.PLN_AFFIRMED_QTY, 0)),
               SUM(NVL(L.AFFIRMED_QUANTITY, 0)),
               SUM(NVL(SD.FACT_SHIP_QTY, 0))
          INTO V_CURR_HEAD_STATE,
               V_CURR_HEAD_STATE_NAME,
               V_CURR_CLOSED_LINE_COUNT,
               V_CURR_HQ_AFFIRMED_QTY,
               V_CURR_PLN_AFFIRMED_QTY,
               V_CURR_AFFIEMED_QTY,
               V_CURR_FACT_SHIP_QTY
          FROM T_PLN_LG_ORDER_HEAD H,
               T_PLN_LG_ORDER_LINE L,
               T_PLN_FLOW_TYPE_STATUS S,
               (SELECT NVL(DL.ORIGIN_ORIGIN_LINE_ID, DL.ORIGIN_LINE_ID) ORIGIN_LINE_ID,
                       SUM(NVL(DL.FACT_SHIP_QTY, 0)) FACT_SHIP_QTY
                  FROM T_LG_SHIP_DOC_LINE DL
                 WHERE (DL.ORIGIN_ORIGIN_TYPE = '02' OR DL.ORIGIN_TYPE = '02')
                 GROUP BY NVL(DL.ORIGIN_ORIGIN_LINE_ID, DL.ORIGIN_LINE_ID)) SD
         WHERE H.ORDER_HEAD_ID = L.ORDER_HEAD_ID
           AND H.ORDER_HEAD_STATE = S.STATUS_ID
           AND L.ORDER_LINE_ID = SD.ORIGIN_LINE_ID(+)
           AND H.ORDER_HEAD_ID = R_LG.ORDER_HEAD_ID
         GROUP BY H.ORDER_HEAD_STATE,
                  S.STATUS_CODE;
        
        --当前单据推送状态
        IF R_LG.SUBMIT_TO_HQ_FLAG = 'Y' OR V_CURR_HEAD_STATE in ('679', '381') THEN
          V_CURR_PUSH_STATE := V_PUSH_STATE_CENTER_CHECK;
        END IF;
        
        IF V_CURR_HQ_AFFIRMED_QTY > 0 /*AND V_CURR_HQ_AFFIRMED_QTY > V_LAST_HQ_AFFIRMED_QTY*/ THEN
          V_CURR_PUSH_STATE := V_PUSH_STATE_INV_AFFIRM;
        END IF;
        
        SELECT COUNT(1)
          INTO V_COUNT
          FROM T_PLN_ORDER_HEAD H, T_PLN_LG_RELATION R
         WHERE H.ORDER_HEAD_ID = R.ORDER_HEAD_ID
           AND R.LG_ORDER_HEAD_ID = R_LG.ORDER_HEAD_ID
           AND H.FORM_STATE IN ('32', '306');
        
        IF V_COUNT > 0 THEN
          V_CURR_PUSH_STATE := V_PUSH_STATE_PRODUCE;
        END IF;
        
        IF V_CURR_PLN_AFFIRMED_QTY > 0 /*AND V_CURR_PLN_AFFIRMED_QTY > V_LAST_PLN_AFFIRMED_QTY*/ THEN
          V_CURR_PUSH_STATE := V_PUSH_STATE_PLN_AFFIRM;
        END IF;
        
        IF V_CURR_FACT_SHIP_QTY > 0 /*AND V_CURR_FACT_SHIP_QTY > V_LAST_FACT_SHIP_QTY*/ THEN
          V_CURR_PUSH_STATE := V_PUSH_STATE_SHIP_AFFIRM;
        END IF;
        
        IF V_CURR_HEAD_STATE = '304' AND (V_CURR_PUSH_STATE IS NULL OR V_CURR_PUSH_STATE = V_PUSH_STATE_CENTER_CHECK
          OR (V_CURR_PUSH_STATE = V_PUSH_STATE_PRODUCE AND V_CURR_AFFIEMED_QTY = 0)) THEN
          V_CURR_PUSH_STATE := V_PUSH_STATE_CLOSED;
        END IF;
        
        IF V_CURR_HEAD_STATE = '415' THEN
          V_CURR_PUSH_STATE := V_PUSH_STATE_REJECT;
        END IF;
        
        --是否需写接口
        IF V_CURR_HEAD_STATE <> V_LAST_HEAD_STATE OR
          V_CURR_PUSH_STATE <> V_LAST_PUSH_STATE OR
          V_CURR_CLOSED_LINE_COUNT > V_LAST_CLOSED_LINE_COUNT THEN
          IF V_CURR_CLOSED_LINE_COUNT > V_LAST_CLOSED_LINE_COUNT THEN
            V_LINE_STATE_CHG_FLAG := 'Y';
          END IF;
          V_NEED_PUSH_FLAG := TRUE;
        END IF;
        
        --插入接口表
        IF V_NEED_PUSH_FLAG THEN
          insert into intf_lg_order_state
            (intf_id,
             stat_date,
             entity_id,
             order_head_id,
             order_number,
             source_order_number,
             customer_id,
             customer_code,
             customer_name,
             order_head_state,
             order_head_state_name,
             line_state_chg_flag,
             push_state,
             closed_line_count,
             line_hq_affirmed_qty,
             line_pln_affirmed_qty,
             line_fact_ship_qty,
             trx_no,
             intf_status,
             error_flag,
             error_msg,
             post_date,
             created_by,
             creation_date)
          values
            (s_intf_lg_order_state.nextval,
             trunc(sysdate),
             r_lg.Entity_Id,
             r_lg.order_head_id,
             r_lg.order_number,
             r_lg.source_order_number,
             r_lg.customer_id,
             r_lg.customer_code,
             r_lg.customer_name,
             V_CURR_HEAD_STATE,
             V_CURR_HEAD_STATE_NAME,
             V_LINE_STATE_CHG_FLAG,
             V_CURR_PUSH_STATE,
             V_CURR_CLOSED_LINE_COUNT,
             V_CURR_HQ_AFFIRMED_QTY,
             V_CURR_PLN_AFFIRMED_QTY,
             V_CURR_FACT_SHIP_QTY,
             NULL,
             'N',
             'N',
             NULL,
             NULL,
             'job',
             sysdate);
        END IF;
      END LOOP;
      
      UPDATE T_BD_PARAM_ENTITY E
         SET E.ENTITY_VALUE = TO_CHAR(V_CURRENT_TIME, 'YYYY-MM-DD HH24:MI:SS')
       WHERE E.ENTITY_ID = V_CURRENT_ENTITY_ID
         AND E.PARAM_LIST_ID =
             (SELECT L.PARAM_LIST_ID
                FROM T_BD_PARAM_LIST L
               WHERE L.PARAM_CODE = 'PLN_ORDER_STATE_LAST_DATE');
    END LOOP;
    commit;
  EXCEPTION
    WHEN OTHERS THEN
      Rollback;
      Pkg_Pln_Pub.p_Write_Job_Log(p_Module_Code          => 'PLN',
                                  p_Procedure_Name       => 'P_FREEZE_LG_ORDER_STATE',
                                  p_Error_Msg            => '订单状态变更信息写入接口：' || sqlerrm,
                                  p_Source_Order_Head_Id => NULL,
                                  p_Source_Order_Line_Id => Null,
                                  p_Item_Id              => Null,
                                  p_Inventory_Id         => Null,
                                  p_Quantity             => Null);
      commit;
  END P_FREEZE_LG_ORDER_STATE;
  
 ------------------------------------------------------------------------------------------------
 -- AUTHOR  : CHENYJ8
 -- CREATED : 2019-02-23
 -- PURPOSE : 网批订单发货完成和差异处理完成写入接口
 ------------------------------------------------------------------------------------------------
 PROCEDURE P_WP_ECM_ORDER_SO(IN_ENTITY_ID        IN NUMBER DEFAULT -1, --主体
                             IN_DELAY_DAY        IN NUMBER DEFAULT 0, --配置的数据更新范围，单位：天
                             IN_DELAY_DELETE_DAY IN NUMBER DEFAULT 30 --配置的接口数据删除范围，单位：天
                             ) IS
   V_CNT              NUMBER;
   V_HEAD_ID          NUMBER;
   V_LAST_UPDATE_TIME DATE; --最后推送的更新时间
   V_CURRENT_TIME     DATE;
 BEGIN
   V_CURRENT_TIME := SYSDATE;
   --清楚历史数据
   DELETE FROM CIMS.INTF_ECM_ORDER_SO_LINE T
    WHERE T.CREATION_DATE < SYSDATE - IN_DELAY_DELETE_DAY;
   DELETE FROM CIMS.INTF_ECM_ORDER_SO_HEAD T
    WHERE T.CREATION_DATE < SYSDATE - IN_DELAY_DELETE_DAY;
   COMMIT;
   --重推失败记录
   UPDATE CIMS.INTF_ECM_ORDER_SO_HEAD T
      SET T.INTF_STATUS = 'N'
    WHERE T.INTF_STATUS = 'E'
      AND T.CREATION_DATE > SYSDATE - 1 - IN_DELAY_DAY;
   --获取上次更新时间
   BEGIN
   
     SELECT MAX(T.CREATION_DATE)
       INTO V_LAST_UPDATE_TIME
       FROM CIMS.INTF_ECM_ORDER_SO_HEAD T
      WHERE T.SEND_TYPE = -1;
   EXCEPTION
     WHEN OTHERS THEN
       V_LAST_UPDATE_TIME := V_CURRENT_TIME - 2;
   END;
 
   IF V_LAST_UPDATE_TIME IS NULL THEN
     V_LAST_UPDATE_TIME := V_CURRENT_TIME - 2;
   END IF;
   --减去配置时间范围
   V_LAST_UPDATE_TIME := V_LAST_UPDATE_TIME - IN_DELAY_DAY;
 
   INSERT INTO INTF_ECM_ORDER_SO_HEAD
     (INFO_ID, SEND_TYPE, CREATION_DATE)
   VALUES
     (S_INTF_ECM_ORDER_SO_HEAD.NEXTVAL, -1, SYSDATE);
   BEGIN
     --写入发货完成的产品，ECM要求按产品维度统计推送ECM
     FOR R_DOC_LINE IN (SELECT DISTINCT DOC.ENTITY_ID,
                                        DOC.SHIP_DOC_ID,
                                        NVL(DL.ORIGIN_ORIGIN_DOC_CODE,
                                            DL.ORIGIN_ORDER_NUM) ORDER_NUM,
                                        DL.ITEM_CODE
                          FROM CIMS.T_LG_SHIP_DOC      DOC,
                               CIMS.T_LG_SHIP_DOC_LINE DL
                         WHERE DOC.DOC_STATUS = '00'
                           AND DOC.CUSTOMER_CHANNEL_TYPE = '15'
                           AND DOC.LAST_UPDATE_DATE > V_LAST_UPDATE_TIME
                           AND DL.SHIP_DOC_ID = DOC.SHIP_DOC_ID
                           AND DOC.VEHICLE_NUM IS NOT NULL
                           AND DOC.CUSTOMER_CODE = 'E0115801'
                           /*AND DL.ITEM_QTY - NVL(DL.FACT_SHIP_QTY, 0) -
                               NVL(DL.CANCEL_QTY, 0) = 0*/
                        
                        ) LOOP
       V_HEAD_ID := S_INTF_ECM_ORDER_SO_HEAD.NEXTVAL;
       --插入头表
       INSERT INTO INTF_ECM_ORDER_SO_HEAD
         (INFO_ID, ENTITY_ID, ORDER_NUMBER, SEND_TYPE, INTF_STATUS)
         SELECT V_HEAD_ID,
                R_DOC_LINE.ENTITY_ID,
                R_DOC_LINE.ORDER_NUM,
                1,
                'N'
           FROM DUAL;
       --插入行表
       INSERT INTO INTF_ECM_ORDER_SO_LINE
         (HEAD_INFO_ID,
          INFO_ID,
          BIZ_SRC_BILL_TYPE_CODE,
          SO_NUM,
          ORIG_SO_NUM,
          SO_LINE_ID,
          ITEM_CODE,
          ITEM_NAME,
          ITEM_QTY,
          RECEIVED_QTY)
         SELECT V_HEAD_ID,
                S_INTF_ECM_ORDER_SO_LINE.NEXTVAL,
                SH.BIZ_SRC_BILL_TYPE_CODE,
                SH.SO_NUM,
                SH.SRC_BILL_NUM,
                SL.SO_LINE_ID,
                SL.ITEM_CODE,
                SL.ITEM_NAME,
                SL.ITEM_QTY,
                SL.RECEIVED_QTY
           FROM CIMS.T_SO_HEADER SH, CIMS.T_SO_LINE SL
          WHERE SH.SO_HEADER_ID = SL.SO_HEADER_ID
            AND SH.SHIP_DOC_ID = R_DOC_LINE.SHIP_DOC_ID
            AND SL.ITEM_CODE = R_DOC_LINE.ITEM_CODE
            AND SH.BIZ_SRC_BILL_TYPE_CODE = '1001';
       COMMIT;
     END LOOP;
   EXCEPTION
     WHEN OTHERS THEN
     
       PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'PLN',
                                   P_PROCEDURE_NAME       => 'P_WP_ECM_ORDER_SO',
                                   P_ERROR_MSG            => '网批订单发货完成写入接口：' ||
                                                             SUBSTR(SQLERRM,
                                                                    1,
                                                                    1000),
                                   P_SOURCE_ORDER_HEAD_ID => NULL,
                                   P_SOURCE_ORDER_LINE_ID => NULL,
                                   P_ITEM_ID              => NULL,
                                   P_INVENTORY_ID         => NULL,
                                   P_QUANTITY             => NULL);
   END;
   BEGIN
     --推送发货完且差异处理完的数据，根据销售单的更新时间
     FOR R_SO IN (SELECT DISTINCT DOC.ENTITY_ID,
                                  DOC.SHIP_DOC_ID,
                                  NVL(DL.ORIGIN_ORIGIN_DOC_CODE,
                                      DL.ORIGIN_ORDER_NUM) ORDER_NUM,
                                  DL.ITEM_CODE
                    FROM CIMS.T_LG_SHIP_DOC      DOC,
                         CIMS.T_LG_SHIP_DOC_LINE DL,
                         CIMS.T_SO_HEADER        SH
                   WHERE DOC.DOC_STATUS = '00'
                     AND DOC.CUSTOMER_CHANNEL_TYPE = '15'
                     AND SH.LAST_UPDATE_DATE > V_LAST_UPDATE_TIME
                     AND DL.SHIP_DOC_ID = DOC.SHIP_DOC_ID
                     /*AND DL.ITEM_QTY - NVL(DL.FACT_SHIP_QTY, 0) -
                         NVL(DL.CANCEL_QTY, 0) = 0*/
                     AND DOC.SHIP_DOC_ID = SH.SHIP_DOC_ID
                     AND SH.CUSTOMER_CODE = 'E0115801'
                     /*AND NOT EXISTS
                   (SELECT 1
                            FROM CIMS.T_LG_CONTRACT      C,
                                 CIMS.T_LG_CONTRACT_LINE CL
                           WHERE C.BILLS_STATUS <> '02'
                             AND C.CONTRACT_ID = CL.CONTRACT_ID
                             AND CL.SHIP_DOC_LINE_ID = DL.SHIP_DOC_LINE_ID
                             AND CL.SO_DOC_ID = SH.SO_HEADER_ID)*/
                  /*UNION ALL
                  SELECT DISTINCT SH.ENTITY_ID,
                                  NULL SHIP_DOC_ID,
                                  SH.ORIGIN_ORIGIN_ORDER_CODE ORDER_NUM,
                                  NULL ITEM_CODE
                    FROM CIMS.T_SO_HEADER SH
                   WHERE SH.LAST_UPDATE_DATE > V_LAST_UPDATE_TIME
                     AND SH.RAW_SRC_TYPE = '31'
                     AND SH.SHIP_DOC_ID IS NULL
                     AND EXISTS
                   (SELECT 1
                            FROM CIMS.T_PLN_LG_ORDER_HEAD OH
                           WHERE OH.ORDER_NUMBER =
                                 SH.ORIGIN_ORIGIN_ORDER_CODE
                             AND OH.CUSTOMER_CHANNEL_TYPE = '15')*/) LOOP
       V_HEAD_ID := S_INTF_ECM_ORDER_SO_HEAD.NEXTVAL;
       --插入头表
       INSERT INTO INTF_ECM_ORDER_SO_HEAD
         (INFO_ID, ENTITY_ID, ORDER_NUMBER, SEND_TYPE, INTF_STATUS)
         SELECT V_HEAD_ID, R_SO.ENTITY_ID, R_SO.ORDER_NUM, 2, 'N'
           FROM DUAL;
       IF R_SO.SHIP_DOC_ID IS NOT NULL THEN
         --插入行表,有通知单
         INSERT INTO INTF_ECM_ORDER_SO_LINE
           (HEAD_INFO_ID,
            INFO_ID,
            BIZ_SRC_BILL_TYPE_CODE,
            SO_NUM,
            ORIG_SO_NUM,
            SO_LINE_ID,
            ITEM_CODE,
            ITEM_NAME,
            ITEM_QTY,
            RECEIVED_QTY)
           SELECT V_HEAD_ID,
                  S_INTF_ECM_ORDER_SO_LINE.NEXTVAL,
                  SH.BIZ_SRC_BILL_TYPE_CODE,
                  SH.SO_NUM,
                  SH.SRC_BILL_NUM,
                  SL.SO_LINE_ID,
                  SL.ITEM_CODE,
                  SL.ITEM_NAME,
                  SL.ITEM_QTY,
                  SL.RECEIVED_QTY
             FROM CIMS.T_SO_HEADER SH, CIMS.T_SO_LINE SL
            WHERE SH.SO_HEADER_ID = SL.SO_HEADER_ID
              AND SH.SHIP_DOC_ID = R_SO.SHIP_DOC_ID
              AND SL.ITEM_CODE = R_SO.ITEM_CODE;
       ELSE
         --插入行表,没有通知单
         INSERT INTO INTF_ECM_ORDER_SO_LINE
           (HEAD_INFO_ID,
            INFO_ID,
            BIZ_SRC_BILL_TYPE_CODE,
            SO_NUM,
            ORIG_SO_NUM,
            SO_LINE_ID,
            ITEM_CODE,
            ITEM_NAME,
            ITEM_QTY,
            RECEIVED_QTY)
           SELECT V_HEAD_ID,
                  S_INTF_ECM_ORDER_SO_LINE.NEXTVAL,
                  SH.BIZ_SRC_BILL_TYPE_CODE,
                  SH.SO_NUM,
                  SH.ORIG_SO_NUM,
                  SL.SO_LINE_ID,
                  SL.ITEM_CODE,
                  SL.ITEM_NAME,
                  SL.ITEM_QTY,
                  SL.RECEIVED_QTY
             FROM CIMS.T_SO_HEADER SH, CIMS.T_SO_LINE SL
            WHERE SH.SO_HEADER_ID = SL.SO_HEADER_ID
              AND SH.ORIGIN_ORIGIN_ORDER_CODE = R_SO.ORDER_NUM;
       
       END IF;
     
       COMMIT;
     END LOOP;
   
   EXCEPTION
     WHEN OTHERS THEN
       PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'PLN',
                                   P_PROCEDURE_NAME       => 'P_WP_ECM_ORDER_SO',
                                   P_ERROR_MSG            => '网批订单差异处理完成写入接口：' ||
                                                             SUBSTR(SQLERRM,
                                                                    1,
                                                                    1000),
                                   P_SOURCE_ORDER_HEAD_ID => NULL,
                                   P_SOURCE_ORDER_LINE_ID => NULL,
                                   P_ITEM_ID              => NULL,
                                   P_INVENTORY_ID         => NULL,
                                   P_QUANTITY             => NULL);
   END;
 EXCEPTION
   WHEN OTHERS THEN
   
     PKG_PLN_PUB.P_WRITE_JOB_LOG(P_MODULE_CODE          => 'PLN',
                                 P_PROCEDURE_NAME       => 'P_WP_ECM_ORDER_SO',
                                 P_ERROR_MSG            => '网批订单写入接口：' ||
                                                           SUBSTR(SQLERRM,
                                                                  1,
                                                                  1000),
                                 P_SOURCE_ORDER_HEAD_ID => NULL,
                                 P_SOURCE_ORDER_LINE_ID => NULL,
                                 P_ITEM_ID              => NULL,
                                 P_INVENTORY_ID         => NULL,
                                 P_QUANTITY             => NULL);
   
 END P_WP_ECM_ORDER_SO;
End Pkg_Pln_Job;
/

