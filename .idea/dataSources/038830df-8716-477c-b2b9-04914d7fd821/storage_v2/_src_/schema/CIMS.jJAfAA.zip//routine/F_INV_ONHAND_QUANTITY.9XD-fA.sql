create FUNCTION f_inv_onhand_quantity
(
	in_inventory_id			NUMBER,		--仓库ID
	in_item_id			NUMBER,		--产品ID
	in_entity_id			NUMBER		--经营实体ID
)
	return number
AS
	on_value		NUMBER;	--信息的具体说明（返回值）
BEGIN
	IF in_inventory_id IS NULL OR in_item_id IS NULL OR in_entity_id IS NULL THEN
		on_value := -1;
	END IF;

	SELECT QUANTITY into on_value
	FROM T_INV_ONHAND
	WHERE entity_id = in_entity_id and inventory_id = in_inventory_id and item_id = in_item_id ;

	RETURN on_value;
EXCEPTION
	WHEN NO_DATA_FOUND THEN
		on_value := -1;
		RETURN on_value;
END ;
/

