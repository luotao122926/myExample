create Package Body      Pkg_Pln_Inv_Occupy Is
  /*----------------------------------------------------------------
  *         包：PKG_PLN_INV_OCCUPY
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的定制机库存占用增加及占用减少
  *             订单库存占用重算
  *
  *   过程成功：P_RESULT = 0
  *             P_ERR_MSG = 'SUCCESS';
  *
  *   过程失败：P_RESULT < -20000;
  *             P_ERR_MSG = 过程异常失败的提示信息
  *
  */ ----------------------------------------------------------------

  v_Nl      Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Result  Constant Number := 0; --成功返回
  v_Success Constant Varchar2(10) := 'SUCCESS';
  v_Base_Exception Exception; --自定义异常
  v_Occupytype_Affirm        Constant Varchar2(2) := '01'; --01:库存评审
  v_Occupytype_Wiptransfer   Constant Varchar2(2) := '02'; --02:中转入库
  v_Occupytype_Salesorder    Constant Varchar2(2) := '03'; --03:销售开单
  --特殊占用类型
  v_Occupytype_Trontransfer  Constant Varchar2(2) := '41'; --41:破损调拨
  v_Occupytype_Makeinvof     Constant Varchar2(2) := '42'; --42:盘盈亏
  v_Occupytype_Procurereturn Constant Varchar2(2) := '43'; --43:采购退货
  v_Occupytype_Others        Constant Varchar2(2) := '44'; --43:其它

  -------------------------------------------------------------------------------
  /*
   *  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的定制机库存占用减少，
  *             该过程只处理散件，如果传入的商品为套件则使用递归算法
  *             P_SOURCE开头的参数只做历史记录查询
  *             P_ORIGIN开头的参数占用数据来源单据，占用数据计算条件
  */
  -------------------------------------------------------------------------------
  Procedure p_Occupy_Stocks(p_Inventory_Id      In Number, --仓库ID
                            p_Item_Id           In Number, --产品ID
                            p_Occupy_Qty        In Number, --占用数量
                            p_Match_Pln_To_Wip  In Varchar2, --工单与订单完全匹配标志
                            p_Operation_Type    In Varchar2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                            p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                            p_Entity_Id         In Number, --主体ID
                            p_Origin_Type       In Varchar2, --来源类型
                            p_Origin_Head_Id    In Number, --来源头ID
                            p_Origin_Number     In Varchar2, --来源头编码
                            p_Origin_Line_Id    In Number, --来源行ID
                            p_Source_Order_Type In Varchar2, --事务来源单据类型
                            p_Source_Head_Id    In Number, --事务来源头ID
                            p_Source_Number     In Varchar2, --事务来源头编码
                            p_Source_Line_Id    In Number, --事务来源行ID
                            p_User_Code         In Varchar2, --用户ID
                            p_Result            In Out Number, --返回错误ID
                            p_Err_Msg           In Out Varchar2 --返回错误信息
                            ) Is
    v_Count              Number; --统计数量
    v_Status             Varchar2(1000); --状态
    v_Stock_Affirm_Qty   Number; --库存评审数量
    v_Supply_Qty         Number; --中转采购入库数量
    v_So_Order_Qty       Number; --销售开单数量
    v_Sundry_Qty         Number; --杂项数量
    v_Current_Occupy_Qty Number; --当前入库数量
    v_Sign_Flag          Number;
    Cursor c_Inv_Occupy Is
      Select *
        From t_Pln_Order_Inv_Occupy
       Where Item_Id = p_Item_Id
         And Inventory_Id = p_Inventory_Id
         And Entity_Id = p_Entity_Id
         For Update Nowait;
  Begin

    --初始值
    p_Result  := v_Result;
    p_Err_Msg := v_Success;

    --检查是否锁定记录 防止重复操作
    Begin
      Open c_Inv_Occupy;
      Close c_Inv_Occupy;
    Exception
      When Others Then
        p_Result  := -21000;
        p_Err_Msg := '库存占用出错：当前记录已被锁定，可能正被其他用户操作，请稍候再试！' || v_Nl || Sqlerrm;
    End;

    If p_Result = v_Result Then
      --检查数量，为0则不处理
      If p_Occupy_Qty <> 0 Then
        --检查条件是否满足
        --检查是否存在对应的库存占用信息
        v_Status := '检查是否存在对应的库存占用信息(' || p_Origin_Type || ',' ||
                    To_Char(p_Origin_Line_Id) || ',' ||
                    To_Char(p_Inventory_Id) || ',' || To_Char(p_Item_Id) || ')';
        Select Count(*)
          Into v_Count
          From t_Pln_Order_Inv_Occupy Oio
         Where Oio.Origin_Line_Id = p_Origin_Line_Id
           And Oio.Origin_Type = p_Origin_Type
           And Oio.Inventory_Id = p_Inventory_Id
           And Oio.Item_Id = p_Item_Id;
        If v_Count = 0 Then
          --不存在 新增
          If p_Occupy_Qty < 0 Then
            p_Result  := -21000;
            p_Err_Msg := '占用数量不能为负数!（' || To_Char(p_Occupy_Qty) || '）';
            Raise v_Base_Exception;
          Else
            v_Status := '新增库存占用表';
            Insert Into t_Pln_Order_Inv_Occupy
              (Entity_Id, --主体ID
               Origin_Type, --来源类型
               Origin_Head_Id, --来源头ID
               Origin_Number, --来源单据单号
               Origin_Line_Id, --来源行ID
               Item_Id, --产品ID
               Inventory_Id, --仓库ID
               Stock_Affirm_Qty, --库存评审数量
               Supply_Qty, --中转采购入库数量
               So_Order_Qty, --销售开单数量
               Sundry_Qty, --杂项数量
               Sundry_Type, --杂项类型
               Created_By,
               Creation_Date,
               Last_Updated_By,
               Last_Update_Date,
               Reamrk,
               Pre_Field_01,
               Pre_Field_02,
               Pre_Field_03,
               Pre_Field_04,
               Pre_Field_05,
               Pre_Field_06)
              Select p_Entity_Id,
                     p_Origin_Type, --来源类型
                     p_Origin_Head_Id, --来源头ID
                     p_Origin_Number, --来源单据单号
                     p_Origin_Line_Id, --来源行ID
                     p_Item_Id, --产品ID
                     p_Inventory_Id, --仓库ID
                     --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                     Decode(p_Operation_Type, v_Occupytype_Affirm, p_Occupy_Qty, 0), --STOCK_AFFIRM_QTY,  --库存评审数量
                     Decode(p_Operation_Type, v_Occupytype_Wiptransfer, p_Occupy_Qty, 0), --SUPPLY_QTY, --中转采购入库数量
                     Decode(p_Operation_Type, v_Occupytype_Salesorder, p_Occupy_Qty, 0), --SO_ORDER_QTY, --销售开单数量
                     Decode(p_Operation_Type,
                            v_Occupytype_Trontransfer,
                            p_Occupy_Qty,
                            v_Occupytype_Makeinvof,
                            p_Occupy_Qty,
                            v_Occupytype_Procurereturn,
                            p_Occupy_Qty,
                            v_Occupytype_Others,
                            p_Occupy_Qty,
                            0), --SUNDRY_QTY,             --杂项数量
                     Decode(p_Operation_Type,
                            v_Occupytype_Trontransfer,
                            p_Operation_Type,
                            v_Occupytype_Makeinvof,
                            p_Operation_Type,
                            v_Occupytype_Procurereturn,
                            p_Operation_Type,
                            v_Occupytype_Others,
                            p_Operation_Type,
                            Null), --SUNDRY_TYPE,       --杂项类型
                     p_User_Code,
                     Sysdate,
                     p_User_Code,
                     Sysdate,
                     Null Reamrk,
                     Null Pre_Field_01,
                     Null Pre_Field_02,
                     Null Pre_Field_03,
                     Null Pre_Field_04,
                     Null Pre_Field_05,
                     Null Pre_Field_06
                From Dual;
          End If;
        Else
          --存在 更新
          If p_Result = v_Result Then
            v_Status := '检查库存占用数量(' || p_Origin_Type || ',' ||
                        To_Char(p_Origin_Line_Id) || ',' ||
                        To_Char(p_Inventory_Id) || ',' ||
                        To_Char(p_Item_Id) || ')';

            Select Oio.Stock_Affirm_Qty,
                   Oio.Supply_Qty,
                   Oio.So_Order_Qty,
                   Oio.Sundry_Qty,
                   --销售红冲，破损调损，盘点单，采购退货：红冲时入库数必需为负数，检查占用量时把负数专成正数
                   Case
                     When p_Operation_Type In
                          (v_Occupytype_Salesorder,
                           v_Occupytype_Trontransfer,
                           v_Occupytype_Makeinvof,
                           v_Occupytype_Procurereturn,
                           v_Occupytype_Others) Then
                      -1 * p_Occupy_Qty
                     Else
                      p_Occupy_Qty
                   End
              Into v_Stock_Affirm_Qty,
                   v_Supply_Qty,
                   v_So_Order_Qty,
                   v_Sundry_Qty,
                   v_Current_Occupy_Qty
              From t_Pln_Order_Inv_Occupy Oio
             Where Oio.Origin_Type = p_Origin_Type
               And Oio.Origin_Line_Id = p_Origin_Line_Id
               And Oio.Inventory_Id = p_Inventory_Id
               And Oio.Item_Id = p_Item_Id;
            --检查：库存占用表可用库存 + 本次占用库存   是否小于0
            If v_Stock_Affirm_Qty + v_Supply_Qty - v_So_Order_Qty -
               v_Sundry_Qty + v_Current_Occupy_Qty < 0 Then
              p_Result  := -21000;
              p_Err_Msg := v_Status || v_Nl || '库存占用数量不能为负数!（库存已占用数量（' ||
                           To_Char(v_Stock_Affirm_Qty + v_Supply_Qty) ||
                           '） + 本次占用数量（' || To_Char(v_Current_Occupy_Qty) ||
                           ') - 库存占用已出库数量（' ||
                           To_Char(v_So_Order_Qty + v_Sundry_Qty) || '））';
              Raise v_Base_Exception;
            End If;
          End If;
          --以上条件都满足，则继续,更新库存占用数量
          If p_Result = v_Result Then
            --更新库存占用数量
            v_Status := '更新库存占用数量';
            --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
            Update t_Pln_Order_Inv_Occupy Oio
               Set Oio.Stock_Affirm_Qty = Nvl(Oio.Stock_Affirm_Qty, 0) +
                                          Decode(p_Operation_Type,
                                                 v_Occupytype_Affirm,
                                                 p_Occupy_Qty,
                                                 0),
                   Oio.Supply_Qty       = Nvl(Oio.Supply_Qty, 0) +
                                          Decode(p_Operation_Type,
                                                 v_Occupytype_Wiptransfer,
                                                 p_Occupy_Qty,
                                                 0),
                   Oio.So_Order_Qty     = Nvl(Oio.So_Order_Qty, 0) +
                                          Decode(p_Operation_Type,
                                                 v_Occupytype_Salesorder,
                                                 p_Occupy_Qty,
                                                 0),
                   Oio.Sundry_Qty       = Nvl(Oio.Sundry_Qty, 0) +
                                          Decode(p_Operation_Type,
                                                 v_Occupytype_Trontransfer,
                                                 p_Occupy_Qty,
                                                 v_Occupytype_Makeinvof,
                                                 p_Occupy_Qty,
                                                 v_Occupytype_Procurereturn,
                                                 p_Occupy_Qty,
                                                 v_Occupytype_Others,
                                                 p_Occupy_Qty,
                                                 0),
                   Oio.Sundry_Type      = Decode(p_Operation_Type,
                                                 v_Occupytype_Trontransfer,
                                                 p_Operation_Type,
                                                 v_Occupytype_Makeinvof,
                                                 p_Operation_Type,
                                                 v_Occupytype_Procurereturn,
                                                 p_Operation_Type,
                                                 v_Occupytype_Others,
                                                 p_Operation_Type,
                                                 Oio.Sundry_Type),
                   Last_Updated_By      = p_User_Code,
                   Last_Update_Date     = Sysdate
             Where Origin_Type = p_Origin_Type
               And Origin_Line_Id = p_Origin_Line_Id
               And Inventory_Id = p_Inventory_Id
               And Item_Id = p_Item_Id;
          End If;
        End If;

        If p_Result = v_Result Then
          --更新表T_LG_ORDER_STOCKS_HISTORY
          v_Status := '更新库存占用历史';
          Insert Into t_Pln_Order_Inv_Occupy_His
            (Entity_Id, --主体ID
             Inv_Occupy_His_Id, --库存占用历史表ID
             Origin_Type, --来源类型
             Origin_Head_Id, --来源头ID
             Origin_Number, --来源单据单号
             Origin_Line_Id, --来源行ID
             Source_Order_Type, --事务来源单据类型
             Source_Order_Head_Id, --事务来源单据头ID
             Source_Order_Number, --事务来源单据单号
             Source_Order_Line_Id, --事务来源单据行ID
             Operation_Type, --操作类型
             Action_Desc, --单据操作描述
             Item_Id, --产品ID
             Inventory_Id, --仓库ID
             Stock_Affirm_Qty, --库存评审数量
             Supply_Qty, --中转采购入库数量
             So_Order_Qty, --销售开单数量
             Sundry_Qty, --杂项数量
             Sundry_Type, --杂项类型
             Created_By,
             Creation_Date,
             Last_Updated_By,
             Last_Update_Date,
             Reamrk,
             Pre_Field_01,
             Pre_Field_02,
             Pre_Field_03,
             Pre_Field_04,
             Pre_Field_05,
             Pre_Field_06)
            Select p_Entity_Id,
                   s_Pln_Order_Inv_Occupy_His.Nextval,
                   p_Origin_Type, --来源类型
                   p_Origin_Head_Id, --来源头ID
                   p_Origin_Number, --来源单据单号
                   p_Origin_Line_Id, --来源行ID
                   p_Source_Order_Type, --事务来源单据类型
                   p_Source_Head_Id, --事务来源单据头ID
                   p_Source_Number, --事务来源单据单号
                   p_Source_Line_Id, --事务来源单据行ID
                   p_Operation_Type, --操作类型
                   p_Action_Desc, --单据操作描述
                   p_Item_Id, --产品ID
                   p_Inventory_Id, --仓库ID
                   --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                   Decode(p_Operation_Type, v_Occupytype_Affirm, p_Occupy_Qty, 0), --STOCK_AFFIRM_QTY,  --库存评审数量
                   Decode(p_Operation_Type, v_Occupytype_Wiptransfer, p_Occupy_Qty, 0), --SUPPLY_QTY, --中转采购入库数量
                   Decode(p_Operation_Type, v_Occupytype_Salesorder, p_Occupy_Qty, 0), --SO_ORDER_QTY, --销售开单数量
                   Decode(p_Operation_Type,
                          v_Occupytype_Trontransfer,
                          p_Occupy_Qty,
                          v_Occupytype_Makeinvof,
                          p_Occupy_Qty,
                          v_Occupytype_Procurereturn,
                          p_Occupy_Qty,
                          v_Occupytype_Others,
                          p_Occupy_Qty,
                          0), --SUNDRY_QTY,--杂项数量
                   Decode(p_Operation_Type,
                          v_Occupytype_Trontransfer,
                          p_Operation_Type,
                          v_Occupytype_Makeinvof,
                          p_Operation_Type,
                          v_Occupytype_Procurereturn,
                          p_Operation_Type,
                          v_Occupytype_Others,
                          p_Operation_Type,
                          Null), --SUNDRY_TYPE,--杂项类型
                   p_User_Code,
                   Sysdate,
                   p_User_Code,
                   Sysdate,
                   Null Reamrk,
                   Null Pre_Field_01,
                   Null Pre_Field_02,
                   Null Pre_Field_03,
                   Null Pre_Field_04,
                   Null Pre_Field_05,
                   Null Pre_Field_06
              From Dual;
        End If;
      End If;
    End If;
  Exception
    When v_Base_Exception Then
      p_Result  := -21000;
      p_Err_Msg := '库存占用失败，' || replace(p_Err_Msg, v_Success, '');
    When Others Then
      p_Result  := -21000;
      p_Err_Msg := '库存占用失败，' || replace(p_Err_Msg, v_Success, '') || v_Nl || Sqlerrm;
  End p_Occupy_Stocks;

  -------------------------------------------------------------------------------
  /*
   *  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的定制机库存占用减少，
  *             该过程只处理散件
  *             P_SOURCE开头的参数只做历史记录查询
  *             P_ORIGIN开头的参数占用数据来源单据，占用数据计算条件
  */
  -------------------------------------------------------------------------------
  Procedure p_Unoccupy_Stocks(p_Inventory_Id      In Number, --仓库ID
                              p_Item_Id           In Number, --产品ID
                              p_Occupy_Qty        In Number, --占用数量
                              p_Match_Pln_To_Wip  In Varchar2, --工单与订单完全匹配标志
                              p_Operation_Type    In Varchar2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                              p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                              p_Entity_Id         In Number, --主体ID
                              p_Origin_Type       In Varchar2, --来源类型
                              p_Origin_Head_Id    In Number, --来源头ID
                              p_Origin_Number     In Varchar2, --来源头编码
                              p_Origin_Line_Id    In Number, --来源行ID
                              p_Source_Order_Type In Varchar2, --事务来源单据类型
                              p_Source_Head_Id    In Number, --事务来源头ID
                              p_Source_Number     In Varchar2, --事务来源头编码
                              p_Source_Line_Id    In Number, --事务来源行ID
                              p_User_Code         In Varchar2, --用户ID
                              p_Allow_No_Occupy   In Varchar2, --是否允许没有库存占用（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                              p_Result            In Out Number, --返回错误ID
                              p_Err_Msg           In Out Varchar2 --返回错误信息
                              ) Is
    v_Count              Number; --统计数量
    v_Stock_Affirm_Qty   Number; --库存评审数量
    v_Supply_Qty         Number; --中转采购入库数量
    v_So_Order_Qty       Number; --销售开单数量
    v_Sundry_Qty         Number; --杂项数量
    v_Status             Varchar2(1000);
    v_Current_Occupy_Qty Number; --当前入库数量
    Cursor c_Inv_Occupy Is
      Select *
        From t_Pln_Order_Inv_Occupy
       Where Item_Id = p_Item_Id
         And Inventory_Id = p_Inventory_Id
         And Entity_Id = p_Entity_Id
         For Update Nowait;
  Begin
    --初始数据
    p_Result  := v_Result;
    p_Err_Msg := v_Success;

    --检查是否锁定记录 防止重复操作
    Begin
      Open c_Inv_Occupy;
      Close c_Inv_Occupy;
    Exception
      When Others Then
        p_Result  := -21000;
        p_Err_Msg := '库存占用减少数量时出错：当前记录已被锁定，可能正被其他用户操作，请稍候再试！' || v_Nl ||
                     Sqlerrm;
        Raise v_Base_Exception;
    End;
    If p_Result = v_Result Then
      --检查是否已存在对应的库存占用信息
      v_Status := '检查是否已存在对应的库存占用信息(' || p_Origin_Type || ',' ||
                  To_Char(p_Origin_Line_Id) || ',' ||
                  To_Char(p_Inventory_Id) || ',' || To_Char(p_Item_Id) || ')';

      Select Count(*)
        Into v_Count
        From t_Pln_Order_Inv_Occupy Oio
       Where Oio.Origin_Type = p_Origin_Type
         And Oio.Origin_Line_Id = p_Origin_Line_Id
         And Oio.Inventory_Id = p_Inventory_Id
         And Oio.Item_Id = p_Item_Id;

      If v_Count = 0 And p_Allow_No_Occupy = 'N' Then
        --不存在对应的信息，提示错误信息
        p_Result  := -21000;
        p_Err_Msg := v_Status || '，减少库存占用资料不存在。';
        Raise v_Base_Exception;
      End If;

      If v_Count <> 0 Then
        If p_Result = v_Result Then
          --存在对应的数据，则继续
          --检查库存占用数量
          v_Status := '检查库存占用数量(' || p_Origin_Type || ',' ||
                      To_Char(p_Origin_Line_Id) || ',' ||
                      To_Char(p_Inventory_Id) || ',' || To_Char(p_Item_Id) || ')';

          Select Oio.Stock_Affirm_Qty,
                 Oio.Supply_Qty,
                 Oio.So_Order_Qty,
                 Oio.Sundry_Qty,
                 --库存评审、采购中转入库：红冲时入库数必需为负数，检查占用量时把负数专成正数
                 Case
                   When p_Operation_Type In (v_Occupytype_Affirm, v_Occupytype_Wiptransfer) Then
                    -1 * p_Occupy_Qty
                   Else
                    p_Occupy_Qty
                 End
            Into v_Stock_Affirm_Qty,
                 v_Supply_Qty,
                 v_So_Order_Qty,
                 v_Sundry_Qty,
                 v_Current_Occupy_Qty
            From t_Pln_Order_Inv_Occupy Oio
           Where Oio.Origin_Type = p_Origin_Type
             And Oio.Origin_Line_Id = p_Origin_Line_Id
             And Oio.Inventory_Id = p_Inventory_Id
             And Oio.Item_Id = p_Item_Id;

          If v_So_Order_Qty + v_Sundry_Qty + v_Current_Occupy_Qty < 0 Then
            p_Result  := -21000;
            p_Err_Msg := '库存取消点用数量不能为负数(已取消占用数量(' ||
                         To_Char(v_So_Order_Qty + v_Sundry_Qty) ||
                         ') + 本次取消占用数量(' || To_Char(v_Current_Occupy_Qty) || '))';
            Raise v_Base_Exception;
          End If;
          --检查库存占用数量
          If p_Result = v_Result Then
            If v_Stock_Affirm_Qty + v_Supply_Qty <
               v_So_Order_Qty + v_Sundry_Qty + v_Current_Occupy_Qty Then
              p_Result  := -21000;
              p_Err_Msg := '库存取消占用数量不能大于库存占用数量(占用入库数量(' ||
                           To_Char(v_Stock_Affirm_Qty + v_Supply_Qty) ||
                           ') < 占用出库数量(' ||
                           To_Char(v_So_Order_Qty + v_Sundry_Qty) ||
                           ')  + 本次占用出库数量(' ||
                           To_Char(v_Current_Occupy_Qty) || '))';
              Raise v_Base_Exception;
            End If;
          End If;
        End If;
        --以上检查通过，执行更新操作
        If p_Result = v_Result Then
          --更新库存占用数量
          v_Status := '更新库存占用数量';
          Update t_Pln_Order_Inv_Occupy Oio
             Set Oio.Stock_Affirm_Qty = Nvl(Oio.Stock_Affirm_Qty, 0) +
                                        Decode(p_Operation_Type,
                                               v_Occupytype_Affirm,
                                               p_Occupy_Qty,
                                               0),
                 Oio.Supply_Qty       = Nvl(Oio.Supply_Qty, 0) +
                                        Decode(p_Operation_Type,
                                               v_Occupytype_Wiptransfer,
                                               p_Occupy_Qty,
                                               0),
                 Oio.So_Order_Qty     = Nvl(Oio.So_Order_Qty, 0) +
                                        Decode(p_Operation_Type,
                                               v_Occupytype_Salesorder,
                                               p_Occupy_Qty,
                                               0),
                 Oio.Sundry_Qty       = Nvl(Oio.Sundry_Qty, 0) +
                                        Decode(p_Operation_Type,
                                               v_Occupytype_Trontransfer,
                                               p_Occupy_Qty,
                                               v_Occupytype_Makeinvof,
                                               p_Occupy_Qty,
                                               v_Occupytype_Procurereturn,
                                               p_Occupy_Qty,
                                               v_Occupytype_Others,
                                               p_Occupy_Qty,
                                               0),
                 Oio.Sundry_Type      = Decode(p_Operation_Type,
                                               v_Occupytype_Trontransfer,
                                               p_Operation_Type,
                                               v_Occupytype_Makeinvof,
                                               p_Operation_Type,
                                               v_Occupytype_Procurereturn,
                                               p_Operation_Type,
                                               v_Occupytype_Others,
                                               p_Operation_Type,
                                               Oio.Sundry_Type),
                 Last_Updated_By      = p_User_Code,
                 Last_Update_Date     = Sysdate
           Where Oio.Origin_Type = p_Origin_Type
             And Oio.Origin_Line_Id = p_Origin_Line_Id
             And Oio.Inventory_Id = p_Inventory_Id
             And Oio.Item_Id = p_Item_Id;
        End If;

        If p_Result = v_Result Then
          --更新表T_LG_ORDER_STOCKS_HISTORY
          v_Status := '更新库存占用历史';
          Insert Into t_Pln_Order_Inv_Occupy_His
            (Entity_Id, --主体ID
             Inv_Occupy_His_Id, --库存占用历史表ID
             Origin_Type, --来源类型
             Origin_Head_Id, --来源头ID
             Origin_Number, --来源单据单号
             Origin_Line_Id, --来源行ID
             Source_Order_Type, --事务来源单据类型
             Source_Order_Head_Id, --事务来源单据头ID
             Source_Order_Number, --事务来源单据单号
             Source_Order_Line_Id, --事务来源单据行ID
             Operation_Type, --操作类型
             Action_Desc, --单据操作描述
             Item_Id, --产品ID
             Inventory_Id, --仓库ID
             Stock_Affirm_Qty, --库存评审数量
             Supply_Qty, --中转采购入库数量
             So_Order_Qty, --销售开单数量
             Sundry_Qty, --杂项数量
             Sundry_Type, --杂项类型
             Created_By,
             Creation_Date,
             Last_Updated_By,
             Last_Update_Date,
             Reamrk,
             Pre_Field_01,
             Pre_Field_02,
             Pre_Field_03,
             Pre_Field_04,
             Pre_Field_05,
             Pre_Field_06)
            Select p_Entity_Id,
                   s_Pln_Order_Inv_Occupy_His.Nextval,
                   p_Origin_Type, --来源类型
                   p_Origin_Head_Id, --来源头ID
                   p_Origin_Number, --来源单据单号
                   p_Origin_Line_Id, --来源行ID
                   p_Source_Order_Type, --事务来源单据类型
                   p_Source_Head_Id, --事务来源单据头ID
                   p_Source_Number, --事务来源单据单号
                   p_Source_Line_Id, --事务来源单据行ID
                   p_Operation_Type, --操作类型
                   p_Action_Desc, --单据操作描述
                   p_Item_Id, --产品ID
                   p_Inventory_Id, --仓库ID
                   --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                   Decode(p_Operation_Type, v_Occupytype_Affirm, p_Occupy_Qty, 0), --STOCK_AFFIRM_QTY,  --库存评审数量
                   Decode(p_Operation_Type, v_Occupytype_Wiptransfer, p_Occupy_Qty, 0), --SUPPLY_QTY, --中转采购入库数量
                   Decode(p_Operation_Type, v_Occupytype_Salesorder, p_Occupy_Qty, 0), --SO_ORDER_QTY, --销售开单数量
                   Decode(p_Operation_Type,
                          v_Occupytype_Trontransfer,
                          p_Occupy_Qty,
                          v_Occupytype_Makeinvof,
                          p_Occupy_Qty,
                          v_Occupytype_Procurereturn,
                          p_Occupy_Qty,
                          v_Occupytype_Others,
                          p_Occupy_Qty,
                          0), --SUNDRY_QTY,--杂项数量
                   Decode(p_Operation_Type,
                          v_Occupytype_Trontransfer,
                          p_Operation_Type,
                          v_Occupytype_Makeinvof,
                          p_Operation_Type,
                          v_Occupytype_Procurereturn,
                          p_Operation_Type,
                          v_Occupytype_Others,
                          p_Operation_Type,
                          Null), --SUNDRY_TYPE,--杂项类型
                   p_User_Code,
                   Sysdate,
                   p_User_Code,
                   Sysdate,
                   Null Reamrk,
                   Null Pre_Field_01,
                   Null Pre_Field_02,
                   Null Pre_Field_03,
                   Null Pre_Field_04,
                   Null Pre_Field_05,
                   Null Pre_Field_06
              From Dual;
        End If;
      End If;
    End If;
  Exception
    When v_Base_Exception Then
      p_Result  := -21000;
      p_Err_Msg := '库存占用失败，' || replace(p_Err_Msg, v_Success, '') || v_Nl || Sqlerrm;
    When Others Then
      p_Result  := -21000;
      p_Err_Msg := '库存占用失败，' || replace(p_Err_Msg, v_Success, '') || v_Nl || Sqlerrm;
  End p_Unoccupy_Stocks;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的定制机库存占用增加
  *             该过程只处理散件，如果传入的商品为套件则使用递归算法
  *             P_SOURCE开头的参数只做历史记录查询
  *             P_ORIGIN开头的参数占用数据来源单据，占用数据计算条件
  *
  *    过程成功：P_RESULT = 0
  *              P_ERR_MSG = 'SUCCESS';
  */
  -------------------------------------------------------------------------------
  Procedure p_Into_Occupy_Stocks(p_Inventory_Id      In Number, --仓库ID
                                 p_Item_Id           In Number, --产品ID
                                 p_Occupy_Qty        In Number, --占用数量
                                 p_Match_Pln_To_Wip  In Varchar2, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                 p_Operation_Type    In Varchar2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                 p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                 p_Entity_Id         In Number, --主体ID
                                 p_Origin_Type       In Varchar2, --来源类型
                                 p_Origin_Head_Id    In Number, --来源头ID
                                 p_Origin_Number     In Varchar2, --来源头编码
                                 p_Origin_Line_Id    In Number, --来源行ID
                                 p_Source_Order_Type In Varchar2, --事务来源单据类型
                                 p_Source_Head_Id    In Number, --事务来源头ID
                                 p_Source_Number     In Varchar2, --事务来源头编码
                                 p_Source_Line_Id    In Number, --事务来源行ID
                                 p_User_Code         In Varchar2, --用户ID
                                 p_Result            In Out Number, --返回错误ID
                                 p_Err_Msg           In Out Varchar2 --返回错误信息
                                 ) Is
    v_Return  Number;
    v_Err_Msg Varchar2(2000);
  Begin
    p_Result  := v_Result;
    p_Err_Msg := v_Success;
    --套散件必需先打散后，再做库存占用
    For r_Ass In (Select Ias.Item_Id, Nvl(Ias.Quantity, 1) Quantity
                    From t_Bd_Item_Assemblies     Bia,
                         t_Bd_Item_Assemblies_Sub Ias
                   Where Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
                     And Bia.Entity_Id = Ias.Entity_Id
                     And Trunc(Sysdate) Between Bia.Begin_Date And
                         Nvl(Bia.End_Date, Sysdate)
                     And Trunc(Sysdate) Between Ias.Begin_Date And
                         Nvl(Ias.End_Date, Trunc(Sysdate))
                        --And Nvl(Ias.Fittings_Flag, 'N') = 'N'
                     And Bia.Item_Id = p_Item_Id
                  Union All
                  --非套件产品
                  Select Tbi.Item_Id, 1 Quantity
                    From t_Bd_Item Tbi
                   Where Tbi.Item_Id = p_Item_Id
                     And Not Exists
                   (Select 1
                            From t_Bd_Item_Assemblies Bia
                           Where Bia.Item_Id = Tbi.Item_Id
                             And Trunc(Sysdate) Between Bia.Begin_Date And
                                 Nvl(Bia.End_Date, Sysdate))) Loop
      If p_Match_Pln_To_Wip = 'Y' Then
        p_Occupy_Stocks(p_Inventory_Id, --仓库ID
                        r_Ass.Item_Id, --散行产品ID
                        p_Occupy_Qty * r_Ass.Quantity, --占用数量
                        p_Match_Pln_To_Wip, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                        p_Operation_Type, --操作类型(1：库存评审  2：中转入库  3：销售开单  4：杂项(含：破损调拨、盘盈亏、采购退货))
                        p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                        p_Entity_Id, --主体ID
                        '订单与工单完全匹配', --来源类型
                        p_Origin_Head_Id, --来源头ID
                        p_Origin_Number, --来源头编码
                        p_Origin_Line_Id, --来源行ID
                        p_Source_Order_Type, --事务来源单据类型
                        p_Source_Head_Id, --事务来源头ID
                        p_Source_Number, --事务来源头编码
                        p_Source_Line_Id, --事务来源行ID
                        p_User_Code, --用户ID
                        v_Return, --返回错误ID
                        v_Err_Msg --返回错误信息
                        );
        If v_Return <> v_Result Then
          p_Result  := v_Return;
          p_Err_Msg := v_Err_Msg;
          Raise v_Base_Exception;
        End If;
      Elsif p_Match_Pln_To_Wip = 'N' Then
        --定制机匹配，工单与工单为随机匹配，按系统给定规则
        p_Occupy_Stocks(p_Inventory_Id, --仓库ID
                        r_Ass.Item_Id, --散行产品ID
                        p_Occupy_Qty * r_Ass.Quantity, --占用数量
                        p_Match_Pln_To_Wip, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配 O:其它模块占用
                        p_Operation_Type, --操作类型(1：库存评审  2：中转入库  3：销售开单  4：杂项(含：破损调拨、盘盈亏、采购退货))
                        p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                        p_Entity_Id, --主体ID
                        '订单与工单按规则匹配', --来源类型
                        p_Origin_Head_Id, --来源头ID
                        p_Origin_Number, --来源头编码
                        '-9999', --来源行ID
                        p_Source_Order_Type, --事务来源单据类型
                        p_Source_Head_Id, --事务来源头ID
                        p_Source_Number, --事务来源头编码
                        p_Source_Line_Id, --事务来源行ID
                        p_User_Code, --用户ID
                        v_Return, --返回错误ID
                        v_Err_Msg --返回错误信息
                        );
        If v_Return <> v_Result Then
          p_Result  := v_Return;
          p_Err_Msg := v_Err_Msg;
          Raise v_Base_Exception;
        End If;
      Else
        --其它模块使用库存占用功能
        p_Occupy_Stocks(p_Inventory_Id, --仓库ID
                        r_Ass.Item_Id, --散行产品ID
                        p_Occupy_Qty * r_Ass.Quantity, --占用数量
                        p_Match_Pln_To_Wip, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配 O:其它模块占用
                        p_Operation_Type, --操作类型(1：库存评审  2：中转入库  3：销售开单  4：杂项(含：破损调拨、盘盈亏、采购退货))
                        p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                        p_Entity_Id, --主体ID
                        p_Origin_Type, --来源类型
                        p_Origin_Head_Id, --来源头ID
                        p_Origin_Number, --来源头编码
                        p_Origin_Line_Id, --来源行ID
                        p_Source_Order_Type, --事务来源单据类型
                        p_Source_Head_Id, --事务来源头ID
                        p_Source_Number, --事务来源头编码
                        p_Source_Line_Id, --事务来源行ID
                        p_User_Code, --用户ID
                        v_Return, --返回错误ID
                        v_Err_Msg --返回错误信息
                        );
        If v_Return <> v_Result Then
          p_Result  := v_Return;
          p_Err_Msg := v_Err_Msg;
          Raise v_Base_Exception;
        End If;
      End If;
    End Loop;
  Exception
    When v_Base_Exception Then
      p_Result  := -20000;
      p_Err_Msg := '库存占用过程PKG_PLN_INV_OCCUPY.P_INTO_OCCUPY_STOCKS失败。' || v_Nl ||
                   p_Err_Msg;
      Rollback;
    When Others Then
      p_Result  := -20000;
      p_Err_Msg := '库存占用过程PKG_PLN_INV_OCCUPY.P_INTO_OCCUPY_STOCKS失败。' || v_Nl ||
                   p_Err_Msg;
      Rollback;
  End;

  -------------------------------------------------------------------------------
  /*
   *  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的定制机库存占用减少，
  *             该过程只处理散件，如果传入的商品为套件则使用递归算法
  *             P_SOURCE开头的参数只做历史记录查询
  *             P_ORIGIN开头的参数占用数据来源单据，占用数据计算条件
  */
  -------------------------------------------------------------------------------
  Procedure p_Into_Unoccupy_Stocks(p_Inventory_Id      In Number, --仓库ID
                                   p_Item_Id           In Number, --产品ID
                                   p_Occupy_Qty        In Number, --占用数量
                                   p_Match_Pln_To_Wip  In Varchar2, --工单与订单完全匹配标志
                                   p_Operation_Type    In Varchar2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                   p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                   p_Entity_Id         In Number, --主体ID
                                   p_Origin_Type       In Varchar2, --来源类型
                                   p_Origin_Head_Id    In Number, --来源头ID
                                   p_Origin_Number     In Varchar2, --来源头编码
                                   p_Origin_Line_Id    In Number, --来源行ID
                                   p_Source_Order_Type In Varchar2, --事务来源单据类型
                                   p_Source_Head_Id    In Number, --事务来源头ID
                                   p_Source_Number     In Varchar2, --事务来源头编码
                                   p_Source_Line_Id    In Number, --事务来源行ID
                                   p_User_Code         In Varchar2, --用户ID
                                   p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                   p_Result            In Out Number, --返回错误ID
                                   p_Err_Msg           In Out Varchar2 --返回错误信息
                                   ) Is
    v_Return  Number;
    v_Err_Msg Varchar2(2000);
  Begin
    p_Result  := v_Result;
    p_Err_Msg := v_Success;
    --套散件必需先打散后，再做库存占用
    For r_Ass In (Select Ias.Item_Id, Nvl(Ias.Quantity, 1) Quantity
                    From t_Bd_Item_Assemblies     Bia,
                         t_Bd_Item_Assemblies_Sub Ias
                   Where Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
                     And Bia.Entity_Id = Ias.Entity_Id
                     And Trunc(Sysdate) Between Bia.Begin_Date And
                         Nvl(Bia.End_Date, Sysdate)
                     And Trunc(Sysdate) Between Ias.Begin_Date And
                         Nvl(Ias.End_Date, Trunc(Sysdate))
                        --And Nvl(Ias.Fittings_Flag, 'N') = 'N'
                     And Bia.Item_Id = p_Item_Id
                  Union All
                  --非套件产品
                  Select Tbi.Item_Id, 1 Quantity
                    From t_Bd_Item Tbi
                   Where Tbi.Item_Id = p_Item_Id
                     And Not Exists
                   (Select 1
                            From t_Bd_Item_Assemblies Bia
                           Where Bia.Item_Id = Tbi.Item_Id
                             And Trunc(Sysdate) Between Bia.Begin_Date And
                                 Nvl(Bia.End_Date, Sysdate))) Loop
      If p_Match_Pln_To_Wip = 'Y' Then
        p_Unoccupy_Stocks(p_Inventory_Id, --仓库ID
                          r_Ass.Item_Id, --产品ID
                          p_Occupy_Qty * r_Ass.Quantity, --占用数量
                          p_Match_Pln_To_Wip, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                          p_Operation_Type, --操作类型(1：库存评审  2：中转入库  3：销售开单  4：杂项(含：破损调拨、盘盈亏、采购退货))
                          p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                          p_Entity_Id, --主体ID
                          '订单与工单完全匹配', --来源类型
                          p_Origin_Head_Id, --来源头ID
                          p_Origin_Number, --来源头编码
                          p_Origin_Line_Id, --来源行ID
                          p_Source_Order_Type, --事务来源单据类型
                          p_Source_Head_Id, --事务来源头ID
                          p_Source_Number, --事务来源头编码
                          p_Source_Line_Id, --事务来源行ID
                          p_User_Code, --用户ID
                          p_Allow_No_Occupy, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                          v_Return, --返回错误ID
                          v_Err_Msg --返回错误信息
                          );
        If v_Return <> v_Result Then
          p_Result  := v_Return;
          p_Err_Msg := v_Err_Msg;
          Raise v_Base_Exception;
        End If;
      Elsif p_Match_Pln_To_Wip = 'N' Then
        --定制机匹配，工单与工单为随机匹配，按系统给定规则
        p_Unoccupy_Stocks(p_Inventory_Id, --仓库ID
                          r_Ass.Item_Id, --散行产品ID
                          p_Occupy_Qty * r_Ass.Quantity, --占用数量
                          p_Match_Pln_To_Wip, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配 O:其它模块占用
                          p_Operation_Type, --操作类型(1：库存评审  2：中转入库  3：销售开单  4：杂项(含：破损调拨、盘盈亏、采购退货))
                          p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                          p_Entity_Id, --主体ID
                          '订单与工单按规则匹配', --来源类型
                          p_Origin_Head_Id, --来源头ID
                          p_Origin_Number, --来源头编码
                          '-9999', --来源行ID
                          p_Source_Order_Type, --事务来源单据类型
                          p_Source_Head_Id, --事务来源头ID
                          p_Source_Number, --事务来源头编码
                          p_Source_Line_Id, --事务来源行ID
                          p_User_Code, --用户ID
                          p_Allow_No_Occupy, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                          v_Return, --返回错误ID
                          v_Err_Msg --返回错误信息
                          );
        If v_Return <> v_Result Then
          p_Result  := v_Return;
          p_Err_Msg := v_Err_Msg;
          Raise v_Base_Exception;
        End If;
      Else
        --其它模块使用库存占用功能
        p_Unoccupy_Stocks(p_Inventory_Id, --仓库ID
                          r_Ass.Item_Id, --散行产品ID
                          p_Occupy_Qty * r_Ass.Quantity, --占用数量
                          p_Match_Pln_To_Wip, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配 O:其它模块占用
                          p_Operation_Type, --操作类型(1：库存评审  2：中转入库  3：销售开单  4：杂项(含：破损调拨、盘盈亏、采购退货))
                          p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                          p_Entity_Id, --主体ID
                          p_Origin_Type, --来源类型
                          p_Origin_Head_Id, --来源头ID
                          p_Origin_Number, --来源头编码
                          p_Origin_Line_Id, --来源行ID
                          p_Source_Order_Type, --事务来源单据类型
                          p_Source_Head_Id, --事务来源头ID
                          p_Source_Number, --事务来源头编码
                          p_Source_Line_Id, --事务来源行ID
                          p_User_Code, --用户ID
                          p_Allow_No_Occupy, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                          v_Return, --返回错误ID
                          v_Err_Msg --返回错误信息
                          );
        If v_Return <> v_Result Then
          p_Result  := v_Return;
          p_Err_Msg := v_Err_Msg;
          Raise v_Base_Exception;
        End If;
      End If;
    End Loop;
  Exception
    When v_Base_Exception Then
      p_Result  := -20000;
      p_Err_Msg := '库存占用过程PKG_PLN_INV_OCCUPY.P_INTO_UNOCCUPY_STOCKS失败。' || v_Nl ||
                   p_Err_Msg;
      Rollback;
    When Others Then
      p_Result  := -20000;
      p_Err_Msg := '库存占用过程PKG_PLN_INV_OCCUPY.P_INTO_UNOCCUPY_STOCKS失败。' || v_Nl ||
                   p_Err_Msg;
      Rollback;
  End;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的库存评审定制机库存占用增加
  */
  -------------------------------------------------------------------------------
  Procedure p_Affirm_Occupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                   p_Item_Id          In Number, --产品ID
                                   p_Occupy_Qty       In Number, --占用数量
                                   p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                   --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                   p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                   p_Entity_Id         In Number, --主体ID
                                   p_Origin_Type       In Varchar2, --来源类型
                                   p_Origin_Head_Id    In Number, --来源头ID
                                   p_Origin_Number     In Varchar2, --来源头编码
                                   p_Origin_Line_Id    In Number, --来源行ID
                                   p_Source_Order_Type In Varchar2, --事务来源单据类型
                                   p_Source_Head_Id    In Number, --事务来源头ID
                                   p_Source_Number     In Varchar2, --事务来源头编码
                                   p_Source_Line_Id    In Number, --事务来源行ID
                                   p_User_Code         In Varchar2, --用户ID
                                   p_Result            In Out Number, --返回错误ID
                                   p_Err_Msg           In Out Varchar2 --返回错误信息
                                   ) Is
  Begin
    p_Into_Occupy_Stocks(p_Inventory_Id      => p_Inventory_Id, --仓库ID
                         p_Item_Id           => p_Item_Id, --产品ID
                         p_Occupy_Qty        => p_Occupy_Qty, --占用数量
                         p_Match_Pln_To_Wip  => p_Match_Pln_To_Wip, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                         p_Operation_Type    => v_Occupytype_Affirm, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                         p_Action_Desc       => p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                         p_Entity_Id         => p_Entity_Id, --主体ID
                         p_Origin_Type       => p_Origin_Type, --来源类型
                         p_Origin_Head_Id    => p_Origin_Head_Id, --来源头ID
                         p_Origin_Number     => p_Origin_Number, --来源头编码
                         p_Origin_Line_Id    => p_Origin_Line_Id, --来源行ID
                         p_Source_Order_Type => p_Source_Order_Type, --事务来源单据类型
                         p_Source_Head_Id    => p_Source_Head_Id, --事务来源头ID
                         p_Source_Number     => p_Source_Number, --事务来源头编码
                         p_Source_Line_Id    => p_Source_Line_Id, --事务来源行ID
                         p_User_Code         => p_User_Code, --用户ID
                         p_Result            => p_Result, --返回错误ID
                         p_Err_Msg           => p_Err_Msg --返回错误信息
                         );
  End;

  -------------------------------------------------------------------------------
  /*  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的取消库存评审定制机库存占用减少，
  */ -----------------------------------------------------------------------------
  Procedure p_Affirm_Unoccupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                     p_Item_Id          In Number, --产品ID
                                     p_Occupy_Qty       In Number, --占用数量
                                     p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                     --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                     p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                     p_Entity_Id         In Number, --主体ID
                                     p_Origin_Type       In Varchar2, --来源类型
                                     p_Origin_Head_Id    In Number, --来源头ID
                                     p_Origin_Number     In Varchar2, --来源头编码
                                     p_Origin_Line_Id    In Number, --来源行ID
                                     p_Source_Order_Type In Varchar2, --事务来源单据类型
                                     p_Source_Head_Id    In Number, --事务来源头ID
                                     p_Source_Number     In Varchar2, --事务来源头编码
                                     p_Source_Line_Id    In Number, --事务来源行ID
                                     p_User_Code         In Varchar2, --用户ID
                                     p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                     p_Result            In Out Number, --返回错误ID
                                     p_Err_Msg           In Out Varchar2 --返回错误信息
                                     ) Is
  Begin
    p_Into_Unoccupy_Stocks(p_Inventory_Id      => p_Inventory_Id, --仓库ID
                           p_Item_Id           => p_Item_Id, --产品ID
                           p_Occupy_Qty        => -1 * p_Occupy_Qty, --占用数量
                           p_Match_Pln_To_Wip  => p_Match_Pln_To_Wip, --工单与订单完全匹配标志
                           p_Operation_Type    => v_Occupytype_Affirm, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                           p_Action_Desc       => p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                           p_Entity_Id         => p_Entity_Id, --主体ID
                           p_Origin_Type       => p_Origin_Type, --来源类型
                           p_Origin_Head_Id    => p_Origin_Head_Id, --来源头ID
                           p_Origin_Number     => p_Origin_Number, --来源头编码
                           p_Origin_Line_Id    => p_Origin_Line_Id, --来源行ID
                           p_Source_Order_Type => p_Source_Order_Type, --事务来源单据类型
                           p_Source_Head_Id    => p_Source_Head_Id, --事务来源头ID
                           p_Source_Number     => p_Source_Number, --事务来源头编码
                           p_Source_Line_Id    => p_Source_Line_Id, --事务来源行ID
                           p_User_Code         => p_User_Code, --用户ID
                           p_Allow_No_Occupy   => p_Allow_No_Occupy, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                           p_Result            => p_Result, --返回错误ID
                           p_Err_Msg           => p_Err_Msg --返回错误信息
                           );
  End;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的采购中转入库定制机库存占用增加
  */
  -------------------------------------------------------------------------------
  Procedure p_Supply_Occupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                   p_Item_Id          In Number, --产品ID
                                   p_Occupy_Qty       In Number, --占用数量
                                   p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                   --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                   p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                   p_Entity_Id         In Number, --主体ID
                                   p_Origin_Type       In Varchar2, --来源类型
                                   p_Origin_Head_Id    In Number, --来源头ID
                                   p_Origin_Number     In Varchar2, --来源头编码
                                   p_Origin_Line_Id    In Number, --来源行ID
                                   p_Source_Order_Type In Varchar2, --事务来源单据类型
                                   p_Source_Head_Id    In Number, --事务来源头ID
                                   p_Source_Number     In Varchar2, --事务来源头编码
                                   p_Source_Line_Id    In Number, --事务来源行ID
                                   p_User_Code         In Varchar2, --用户ID
                                   p_Result            In Out Number, --返回错误ID
                                   p_Err_Msg           In Out Varchar2 --返回错误信息
                                   ) Is
  Begin
    p_Into_Occupy_Stocks(p_Inventory_Id      => p_Inventory_Id, --仓库ID
                         p_Item_Id           => p_Item_Id, --产品ID
                         p_Occupy_Qty        => p_Occupy_Qty, --占用数量
                         p_Match_Pln_To_Wip  => p_Match_Pln_To_Wip, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                         p_Operation_Type    => v_Occupytype_Wiptransfer, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                         p_Action_Desc       => p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                         p_Entity_Id         => p_Entity_Id, --主体ID
                         p_Origin_Type       => p_Origin_Type, --来源类型
                         p_Origin_Head_Id    => p_Origin_Head_Id, --来源头ID
                         p_Origin_Number     => p_Origin_Number, --来源头编码
                         p_Origin_Line_Id    => p_Origin_Line_Id, --来源行ID
                         p_Source_Order_Type => p_Source_Order_Type, --事务来源单据类型
                         p_Source_Head_Id    => p_Source_Head_Id, --事务来源头ID
                         p_Source_Number     => p_Source_Number, --事务来源头编码
                         p_Source_Line_Id    => p_Source_Line_Id, --事务来源行ID
                         p_User_Code         => p_User_Code, --用户ID
                         p_Result            => p_Result, --返回错误ID
                         p_Err_Msg           => p_Err_Msg --返回错误信息
                         );
  End;

  -------------------------------------------------------------------------------
  /*  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的采购中转红冲定制机库存占用减少，
  */ -----------------------------------------------------------------------------
  Procedure p_Supply_Unoccupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                     p_Item_Id          In Number, --产品ID
                                     p_Occupy_Qty       In Number, --占用数量
                                     p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                     --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                     p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                     p_Entity_Id         In Number, --主体ID
                                     p_Origin_Type       In Varchar2, --来源类型
                                     p_Origin_Head_Id    In Number, --来源头ID
                                     p_Origin_Number     In Varchar2, --来源头编码
                                     p_Origin_Line_Id    In Number, --来源行ID
                                     p_Source_Order_Type In Varchar2, --事务来源单据类型
                                     p_Source_Head_Id    In Number, --事务来源头ID
                                     p_Source_Number     In Varchar2, --事务来源头编码
                                     p_Source_Line_Id    In Number, --事务来源行ID
                                     p_User_Code         In Varchar2, --用户ID
                                     p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                     p_Result            In Out Number, --返回错误ID
                                     p_Err_Msg           In Out Varchar2 --返回错误信息
                                     ) Is
  Begin
    p_Into_Unoccupy_Stocks(p_Inventory_Id      => p_Inventory_Id, --仓库ID
                           p_Item_Id           => p_Item_Id, --产品ID
                           p_Occupy_Qty        => -1 * p_Occupy_Qty, --占用数量
                           p_Match_Pln_To_Wip  => p_Match_Pln_To_Wip, --工单与订单完全匹配标志
                           p_Operation_Type    => v_Occupytype_Wiptransfer, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                           p_Action_Desc       => p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                           p_Entity_Id         => p_Entity_Id, --主体ID
                           p_Origin_Type       => p_Origin_Type, --来源类型
                           p_Origin_Head_Id    => p_Origin_Head_Id, --来源头ID
                           p_Origin_Number     => p_Origin_Number, --来源头编码
                           p_Origin_Line_Id    => p_Origin_Line_Id, --来源行ID
                           p_Source_Order_Type => p_Source_Order_Type, --事务来源单据类型
                           p_Source_Head_Id    => p_Source_Head_Id, --事务来源头ID
                           p_Source_Number     => p_Source_Number, --事务来源头编码
                           p_Source_Line_Id    => p_Source_Line_Id, --事务来源行ID
                           p_User_Code         => p_User_Code, --用户ID
                           p_Allow_No_Occupy   => p_Allow_No_Occupy, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                           p_Result            => p_Result, --返回错误ID
                           p_Err_Msg           => p_Err_Msg --返回错误信息
                           );
  End;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的销售红冲单定制机库存占用增加
  */
  -------------------------------------------------------------------------------
  Procedure p_Soorder_Occupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                    p_Item_Id          In Number, --产品ID
                                    p_Occupy_Qty       In Number, --占用数量
                                    p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                    --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                    p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                    p_Entity_Id         In Number, --主体ID
                                    p_Origin_Type       In Varchar2, --来源类型
                                    p_Origin_Head_Id    In Number, --来源头ID
                                    p_Origin_Number     In Varchar2, --来源头编码
                                    p_Origin_Line_Id    In Number, --来源行ID
                                    p_Source_Order_Type In Varchar2, --事务来源单据类型
                                    p_Source_Head_Id    In Number, --事务来源头ID
                                    p_Source_Number     In Varchar2, --事务来源头编码
                                    p_Source_Line_Id    In Number, --事务来源行ID
                                    p_User_Code         In Varchar2, --用户ID
                                    p_Result            In Out Number, --返回错误ID
                                    p_Err_Msg           In Out Varchar2 --返回错误信息
                                    ) Is
  Begin
    p_Into_Occupy_Stocks(p_Inventory_Id      => p_Inventory_Id, --仓库ID
                         p_Item_Id           => p_Item_Id, --产品ID
                         p_Occupy_Qty        => -1 * p_Occupy_Qty, --占用数量
                         p_Match_Pln_To_Wip  => p_Match_Pln_To_Wip, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                         p_Operation_Type    => v_Occupytype_Salesorder, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                         p_Action_Desc       => p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                         p_Entity_Id         => p_Entity_Id, --主体ID
                         p_Origin_Type       => p_Origin_Type, --来源类型
                         p_Origin_Head_Id    => p_Origin_Head_Id, --来源头ID
                         p_Origin_Number     => p_Origin_Number, --来源头编码
                         p_Origin_Line_Id    => p_Origin_Line_Id, --来源行ID
                         p_Source_Order_Type => p_Source_Order_Type, --事务来源单据类型
                         p_Source_Head_Id    => p_Source_Head_Id, --事务来源头ID
                         p_Source_Number     => p_Source_Number, --事务来源头编码
                         p_Source_Line_Id    => p_Source_Line_Id, --事务来源行ID
                         p_User_Code         => p_User_Code, --用户ID
                         p_Result            => p_Result, --返回错误ID
                         p_Err_Msg           => p_Err_Msg --返回错误信息
                         );
  End;

  -------------------------------------------------------------------------------
  /*  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的销售单定制机库存占用减少，
  */ -----------------------------------------------------------------------------
  Procedure p_Soorder_Unoccupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                      p_Item_Id          In Number, --产品ID
                                      p_Occupy_Qty       In Number, --占用数量
                                      p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                      --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                      p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                      p_Entity_Id         In Number, --主体ID
                                      p_Origin_Type       In Varchar2, --来源类型
                                      p_Origin_Head_Id    In Number, --来源头ID
                                      p_Origin_Number     In Varchar2, --来源头编码
                                      p_Origin_Line_Id    In Number, --来源行ID
                                      p_Source_Order_Type In Varchar2, --事务来源单据类型
                                      p_Source_Head_Id    In Number, --事务来源头ID
                                      p_Source_Number     In Varchar2, --事务来源头编码
                                      p_Source_Line_Id    In Number, --事务来源行ID
                                      p_User_Code         In Varchar2, --用户ID
                                      p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                      p_Result            In Out Number, --返回错误ID
                                      p_Err_Msg           In Out Varchar2 --返回错误信息
                                      ) Is
  Begin
    p_Into_Unoccupy_Stocks(p_Inventory_Id      => p_Inventory_Id, --仓库ID
                           p_Item_Id           => p_Item_Id, --产品ID
                           p_Occupy_Qty        => p_Occupy_Qty, --占用数量
                           p_Match_Pln_To_Wip  => p_Match_Pln_To_Wip, --工单与订单完全匹配标志
                           p_Operation_Type    => v_Occupytype_Salesorder, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                           p_Action_Desc       => p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                           p_Entity_Id         => p_Entity_Id, --主体ID
                           p_Origin_Type       => p_Origin_Type, --来源类型
                           p_Origin_Head_Id    => p_Origin_Head_Id, --来源头ID
                           p_Origin_Number     => p_Origin_Number, --来源头编码
                           p_Origin_Line_Id    => p_Origin_Line_Id, --来源行ID
                           p_Source_Order_Type => p_Source_Order_Type, --事务来源单据类型
                           p_Source_Head_Id    => p_Source_Head_Id, --事务来源头ID
                           p_Source_Number     => p_Source_Number, --事务来源头编码
                           p_Source_Line_Id    => p_Source_Line_Id, --事务来源行ID
                           p_User_Code         => p_User_Code, --用户ID
                           p_Allow_No_Occupy   => p_Allow_No_Occupy, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                           p_Result            => p_Result, --返回错误ID
                           p_Err_Msg           => p_Err_Msg --返回错误信息
                           );
  End;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的破损调拨单戏冲定制机库存占用增加
  */
  -------------------------------------------------------------------------------
  Procedure p_Torn_Transfer_Occupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                          p_Item_Id          In Number, --产品ID
                                          p_Occupy_Qty       In Number, --占用数量
                                          p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                          --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                          p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                          p_Entity_Id         In Number, --主体ID
                                          p_Origin_Type       In Varchar2, --来源类型
                                          p_Origin_Head_Id    In Number, --来源头ID
                                          p_Origin_Number     In Varchar2, --来源头编码
                                          p_Origin_Line_Id    In Number, --来源行ID
                                          p_Source_Order_Type In Varchar2, --事务来源单据类型
                                          p_Source_Head_Id    In Number, --事务来源头ID
                                          p_Source_Number     In Varchar2, --事务来源头编码
                                          p_Source_Line_Id    In Number, --事务来源行ID
                                          p_User_Code         In Varchar2, --用户ID
                                          p_Result            In Out Number, --返回错误ID
                                          p_Err_Msg           In Out Varchar2 --返回错误信息
                                          ) Is
  Begin
    p_Into_Occupy_Stocks(p_Inventory_Id      => p_Inventory_Id, --仓库ID
                         p_Item_Id           => p_Item_Id, --产品ID
                         p_Occupy_Qty        => p_Occupy_Qty, --占用数量
                         p_Match_Pln_To_Wip  => p_Match_Pln_To_Wip, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                         p_Operation_Type    => v_Occupytype_Trontransfer, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                         p_Action_Desc       => p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                         p_Entity_Id         => p_Entity_Id, --主体ID
                         p_Origin_Type       => p_Origin_Type, --来源类型
                         p_Origin_Head_Id    => p_Origin_Head_Id, --来源头ID
                         p_Origin_Number     => p_Origin_Number, --来源头编码
                         p_Origin_Line_Id    => p_Origin_Line_Id, --来源行ID
                         p_Source_Order_Type => p_Source_Order_Type, --事务来源单据类型
                         p_Source_Head_Id    => p_Source_Head_Id, --事务来源头ID
                         p_Source_Number     => p_Source_Number, --事务来源头编码
                         p_Source_Line_Id    => p_Source_Line_Id, --事务来源行ID
                         p_User_Code         => p_User_Code, --用户ID
                         p_Result            => p_Result, --返回错误ID
                         p_Err_Msg           => p_Err_Msg --返回错误信息
                         );
  End;

  -------------------------------------------------------------------------------
  /*  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的破损调拨单确认定制机库存占用减少，
  */ -----------------------------------------------------------------------------
  Procedure p_Torn_Tf_Unoccupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                      p_Item_Id          In Number, --产品ID
                                      p_Occupy_Qty       In Number, --占用数量
                                      p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                      --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                      p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                      p_Entity_Id         In Number, --主体ID
                                      p_Origin_Type       In Varchar2, --来源类型
                                      p_Origin_Head_Id    In Number, --来源头ID
                                      p_Origin_Number     In Varchar2, --来源头编码
                                      p_Origin_Line_Id    In Number, --来源行ID
                                      p_Source_Order_Type In Varchar2, --事务来源单据类型
                                      p_Source_Head_Id    In Number, --事务来源头ID
                                      p_Source_Number     In Varchar2, --事务来源头编码
                                      p_Source_Line_Id    In Number, --事务来源行ID
                                      p_User_Code         In Varchar2, --用户ID
                                      p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                      p_Result            In Out Number, --返回错误ID
                                      p_Err_Msg           In Out Varchar2 --返回错误信息
                                      ) Is
  Begin
    p_Into_Unoccupy_Stocks(p_Inventory_Id      => p_Inventory_Id, --仓库ID
                           p_Item_Id           => p_Item_Id, --产品ID
                           p_Occupy_Qty        => -1 * p_Occupy_Qty, --占用数量
                           p_Match_Pln_To_Wip  => p_Match_Pln_To_Wip, --工单与订单完全匹配标志
                           p_Operation_Type    => v_Occupytype_Trontransfer, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                           p_Action_Desc       => p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                           p_Entity_Id         => p_Entity_Id, --主体ID
                           p_Origin_Type       => p_Origin_Type, --来源类型
                           p_Origin_Head_Id    => p_Origin_Head_Id, --来源头ID
                           p_Origin_Number     => p_Origin_Number, --来源头编码
                           p_Origin_Line_Id    => p_Origin_Line_Id, --来源行ID
                           p_Source_Order_Type => p_Source_Order_Type, --事务来源单据类型
                           p_Source_Head_Id    => p_Source_Head_Id, --事务来源头ID
                           p_Source_Number     => p_Source_Number, --事务来源头编码
                           p_Source_Line_Id    => p_Source_Line_Id, --事务来源行ID
                           p_User_Code         => p_User_Code, --用户ID
                           p_Allow_No_Occupy   => p_Allow_No_Occupy, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                           p_Result            => p_Result, --返回错误ID
                           p_Err_Msg           => p_Err_Msg --返回错误信息
                           );
  End;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的库存盘点定制机库存占用 特殊占用增加
  */
  -------------------------------------------------------------------------------
  Procedure p_Makeinvof_Occupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                      p_Item_Id          In Number, --产品ID
                                      p_Occupy_Qty       In Number, --占用数量
                                      p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                      --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                      p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                      p_Entity_Id         In Number, --主体ID
                                      p_Origin_Type       In Varchar2, --来源类型
                                      p_Origin_Head_Id    In Number, --来源头ID
                                      p_Origin_Number     In Varchar2, --来源头编码
                                      p_Origin_Line_Id    In Number, --来源行ID
                                      p_Source_Order_Type In Varchar2, --事务来源单据类型
                                      p_Source_Head_Id    In Number, --事务来源头ID
                                      p_Source_Number     In Varchar2, --事务来源头编码
                                      p_Source_Line_Id    In Number, --事务来源行ID
                                      p_User_Code         In Varchar2, --用户ID
                                      p_Result            In Out Number, --返回错误ID
                                      p_Err_Msg           In Out Varchar2 --返回错误信息
                                      ) Is
  Begin
    p_Into_Occupy_Stocks(p_Inventory_Id      => p_Inventory_Id, --仓库ID
                         p_Item_Id           => p_Item_Id, --产品ID
                         p_Occupy_Qty        => p_Occupy_Qty, --占用数量
                         p_Match_Pln_To_Wip  => p_Match_Pln_To_Wip, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                         p_Operation_Type    => v_Occupytype_Makeinvof, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                         p_Action_Desc       => p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                         p_Entity_Id         => p_Entity_Id, --主体ID
                         p_Origin_Type       => p_Origin_Type, --来源类型
                         p_Origin_Head_Id    => p_Origin_Head_Id, --来源头ID
                         p_Origin_Number     => p_Origin_Number, --来源头编码
                         p_Origin_Line_Id    => p_Origin_Line_Id, --来源行ID
                         p_Source_Order_Type => p_Source_Order_Type, --事务来源单据类型
                         p_Source_Head_Id    => p_Source_Head_Id, --事务来源头ID
                         p_Source_Number     => p_Source_Number, --事务来源头编码
                         p_Source_Line_Id    => p_Source_Line_Id, --事务来源行ID
                         p_User_Code         => p_User_Code, --用户ID
                         p_Result            => p_Result, --返回错误ID
                         p_Err_Msg           => p_Err_Msg --返回错误信息
                         );
  End;

  -------------------------------------------------------------------------------
  /*  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的库存盘点单定制机库存占用 特殊占用减少，
  */ -----------------------------------------------------------------------------
  Procedure p_Makeinvof_Unoccupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                        p_Item_Id          In Number, --产品ID
                                        p_Occupy_Qty       In Number, --占用数量
                                        p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                        --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                        p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                        p_Entity_Id         In Number, --主体ID
                                        p_Origin_Type       In Varchar2, --来源类型
                                        p_Origin_Head_Id    In Number, --来源头ID
                                        p_Origin_Number     In Varchar2, --来源头编码
                                        p_Origin_Line_Id    In Number, --来源行ID
                                        p_Source_Order_Type In Varchar2, --事务来源单据类型
                                        p_Source_Head_Id    In Number, --事务来源头ID
                                        p_Source_Number     In Varchar2, --事务来源头编码
                                        p_Source_Line_Id    In Number, --事务来源行ID
                                        p_User_Code         In Varchar2, --用户ID
                                        p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                        p_Result            In Out Number, --返回错误ID
                                        p_Err_Msg           In Out Varchar2 --返回错误信息
                                        ) Is
  Begin
    p_Into_Unoccupy_Stocks(p_Inventory_Id      => p_Inventory_Id, --仓库ID
                           p_Item_Id           => p_Item_Id, --产品ID
                           p_Occupy_Qty        => -1 * p_Occupy_Qty, --占用数量
                           p_Match_Pln_To_Wip  => p_Match_Pln_To_Wip, --工单与订单完全匹配标志
                           p_Operation_Type    => v_Occupytype_Makeinvof, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                           p_Action_Desc       => p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                           p_Entity_Id         => p_Entity_Id, --主体ID
                           p_Origin_Type       => p_Origin_Type, --来源类型
                           p_Origin_Head_Id    => p_Origin_Head_Id, --来源头ID
                           p_Origin_Number     => p_Origin_Number, --来源头编码
                           p_Origin_Line_Id    => p_Origin_Line_Id, --来源行ID
                           p_Source_Order_Type => p_Source_Order_Type, --事务来源单据类型
                           p_Source_Head_Id    => p_Source_Head_Id, --事务来源头ID
                           p_Source_Number     => p_Source_Number, --事务来源头编码
                           p_Source_Line_Id    => p_Source_Line_Id, --事务来源行ID
                           p_User_Code         => p_User_Code, --用户ID
                           p_Allow_No_Occupy   => p_Allow_No_Occupy, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                           p_Result            => p_Result, --返回错误ID
                           p_Err_Msg           => p_Err_Msg --返回错误信息
                           );
  End;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的采购退货单 定制机库存占用 特殊占用数量增加
  */
  -------------------------------------------------------------------------------
  Procedure p_Procure_Return_Occupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                           p_Item_Id          In Number, --产品ID
                                           p_Occupy_Qty       In Number, --占用数量
                                           p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                           --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                           p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                           p_Entity_Id         In Number, --主体ID
                                           p_Origin_Type       In Varchar2, --来源类型
                                           p_Origin_Head_Id    In Number, --来源头ID
                                           p_Origin_Number     In Varchar2, --来源头编码
                                           p_Origin_Line_Id    In Number, --来源行ID
                                           p_Source_Order_Type In Varchar2, --事务来源单据类型
                                           p_Source_Head_Id    In Number, --事务来源头ID
                                           p_Source_Number     In Varchar2, --事务来源头编码
                                           p_Source_Line_Id    In Number, --事务来源行ID
                                           p_User_Code         In Varchar2, --用户ID
                                           p_Result            In Out Number, --返回错误ID
                                           p_Err_Msg           In Out Varchar2 --返回错误信息
                                           ) Is
  Begin
    p_Into_Occupy_Stocks(p_Inventory_Id      => p_Inventory_Id, --仓库ID
                         p_Item_Id           => p_Item_Id, --产品ID
                         p_Occupy_Qty        => p_Occupy_Qty, --占用数量
                         p_Match_Pln_To_Wip  => p_Match_Pln_To_Wip, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                         p_Operation_Type    => v_Occupytype_Procurereturn, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                         p_Action_Desc       => p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                         p_Entity_Id         => p_Entity_Id, --主体ID
                         p_Origin_Type       => p_Origin_Type, --来源类型
                         p_Origin_Head_Id    => p_Origin_Head_Id, --来源头ID
                         p_Origin_Number     => p_Origin_Number, --来源头编码
                         p_Origin_Line_Id    => p_Origin_Line_Id, --来源行ID
                         p_Source_Order_Type => p_Source_Order_Type, --事务来源单据类型
                         p_Source_Head_Id    => p_Source_Head_Id, --事务来源头ID
                         p_Source_Number     => p_Source_Number, --事务来源头编码
                         p_Source_Line_Id    => p_Source_Line_Id, --事务来源行ID
                         p_User_Code         => p_User_Code, --用户ID
                         p_Result            => p_Result, --返回错误ID
                         p_Err_Msg           => p_Err_Msg --返回错误信息
                         );
  End;

  -------------------------------------------------------------------------------
  /*  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的采购退货红冲单定制机库存占用 特殊占用数量减少，
  */ -----------------------------------------------------------------------------
  Procedure p_Procreturn_Unoccupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                         p_Item_Id          In Number, --产品ID
                                         p_Occupy_Qty       In Number, --占用数量
                                         p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                         --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                         p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                         p_Entity_Id         In Number, --主体ID
                                         p_Origin_Type       In Varchar2, --来源类型
                                         p_Origin_Head_Id    In Number, --来源头ID
                                         p_Origin_Number     In Varchar2, --来源头编码
                                         p_Origin_Line_Id    In Number, --来源行ID
                                         p_Source_Order_Type In Varchar2, --事务来源单据类型
                                         p_Source_Head_Id    In Number, --事务来源头ID
                                         p_Source_Number     In Varchar2, --事务来源头编码
                                         p_Source_Line_Id    In Number, --事务来源行ID
                                         p_User_Code         In Varchar2, --用户ID
                                         p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                         p_Result            In Out Number, --返回错误ID
                                         p_Err_Msg           In Out Varchar2 --返回错误信息
                                         ) Is
  Begin
    p_Into_Unoccupy_Stocks(p_Inventory_Id      => p_Inventory_Id, --仓库ID
                           p_Item_Id           => p_Item_Id, --产品ID
                           p_Occupy_Qty        => -1 * p_Occupy_Qty, --占用数量
                           p_Match_Pln_To_Wip  => p_Match_Pln_To_Wip, --工单与订单完全匹配标志
                           p_Operation_Type    => v_Occupytype_Procurereturn, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                           p_Action_Desc       => p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                           p_Entity_Id         => p_Entity_Id, --主体ID
                           p_Origin_Type       => p_Origin_Type, --来源类型
                           p_Origin_Head_Id    => p_Origin_Head_Id, --来源头ID
                           p_Origin_Number     => p_Origin_Number, --来源头编码
                           p_Origin_Line_Id    => p_Origin_Line_Id, --来源行ID
                           p_Source_Order_Type => p_Source_Order_Type, --事务来源单据类型
                           p_Source_Head_Id    => p_Source_Head_Id, --事务来源头ID
                           p_Source_Number     => p_Source_Number, --事务来源头编码
                           p_Source_Line_Id    => p_Source_Line_Id, --事务来源行ID
                           p_User_Code         => p_User_Code, --用户ID
                           p_Allow_No_Occupy   => p_Allow_No_Occupy, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                           p_Result            => p_Result, --返回错误ID
                           p_Err_Msg           => p_Err_Msg --返回错误信息
                           );
  End;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-09-24
  *     创建者：李振
  *   功能说明：处理特殊占用 其它单据占用方式 特殊占用数量增加
  */
  -------------------------------------------------------------------------------
  Procedure p_Others_Occupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                   p_Item_Id          In Number, --产品ID
                                   p_Occupy_Qty       In Number, --占用数量
                                   p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                                   --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                   p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                   p_Entity_Id         In Number, --主体ID
                                   p_Origin_Type       In Varchar2, --来源类型
                                   p_Origin_Head_Id    In Number, --来源头ID
                                   p_Origin_Number     In Varchar2, --来源头编码
                                   p_Origin_Line_Id    In Number, --来源行ID
                                   p_Source_Order_Type In Varchar2, --事务来源单据类型
                                   p_Source_Head_Id    In Number, --事务来源头ID
                                   p_Source_Number     In Varchar2, --事务来源头编码
                                   p_Source_Line_Id    In Number, --事务来源行ID
                                   p_User_Code         In Varchar2, --用户ID
                                   p_Result            In Out Number, --返回错误ID
                                   p_Err_Msg           In Out Varchar2 --返回错误信息
                                   ) Is
  Begin
    p_Into_Occupy_Stocks(p_Inventory_Id      => p_Inventory_Id, --仓库ID
                         p_Item_Id           => p_Item_Id, --产品ID
                         p_Occupy_Qty        => p_Occupy_Qty, --占用数量
                         p_Match_Pln_To_Wip  => p_Match_Pln_To_Wip, --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                         p_Operation_Type    => v_Occupytype_Others, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                         p_Action_Desc       => p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                         p_Entity_Id         => p_Entity_Id, --主体ID
                         p_Origin_Type       => p_Origin_Type, --来源类型
                         p_Origin_Head_Id    => p_Origin_Head_Id, --来源头ID
                         p_Origin_Number     => p_Origin_Number, --来源头编码
                         p_Origin_Line_Id    => p_Origin_Line_Id, --来源行ID
                         p_Source_Order_Type => p_Source_Order_Type, --事务来源单据类型
                         p_Source_Head_Id    => p_Source_Head_Id, --事务来源头ID
                         p_Source_Number     => p_Source_Number, --事务来源头编码
                         p_Source_Line_Id    => p_Source_Line_Id, --事务来源行ID
                         p_User_Code         => p_User_Code, --用户ID
                         p_Result            => p_Result, --返回错误ID
                         p_Err_Msg           => p_Err_Msg --返回错误信息
                         );
  End;

  -------------------------------------------------------------------------------
  /*  创建日期：2014-09-24
  *     创建者：李振
  *   功能说明：处理特殊占用 其它单据占用方式 特殊占用数量减少，
  */ -----------------------------------------------------------------------------
  Procedure p_Others_Unoccupy_Stocks(p_Inventory_Id     In Number, --仓库ID
                                     p_Item_Id          In Number, --产品ID
                                     p_Occupy_Qty       In Number, --占用数量
                                     p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                     --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                     p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                     p_Entity_Id         In Number, --主体ID
                                     p_Origin_Type       In Varchar2, --来源类型
                                     p_Origin_Head_Id    In Number, --来源头ID
                                     p_Origin_Number     In Varchar2, --来源头编码
                                     p_Origin_Line_Id    In Number, --来源行ID
                                     p_Source_Order_Type In Varchar2, --事务来源单据类型
                                     p_Source_Head_Id    In Number, --事务来源头ID
                                     p_Source_Number     In Varchar2, --事务来源头编码
                                     p_Source_Line_Id    In Number, --事务来源行ID
                                     p_User_Code         In Varchar2, --用户ID
                                     p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                     p_Result            In Out Number, --返回错误ID
                                     p_Err_Msg           In Out Varchar2 --返回错误信息
                                     ) Is
  Begin
    p_Into_Unoccupy_Stocks(p_Inventory_Id      => p_Inventory_Id, --仓库ID
                           p_Item_Id           => p_Item_Id, --产品ID
                           p_Occupy_Qty        => -1 * p_Occupy_Qty, --占用数量
                           p_Match_Pln_To_Wip  => p_Match_Pln_To_Wip, --工单与订单完全匹配标志
                           p_Operation_Type    => v_Occupytype_Others, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                           p_Action_Desc       => p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                           p_Entity_Id         => p_Entity_Id, --主体ID
                           p_Origin_Type       => p_Origin_Type, --来源类型
                           p_Origin_Head_Id    => p_Origin_Head_Id, --来源头ID
                           p_Origin_Number     => p_Origin_Number, --来源头编码
                           p_Origin_Line_Id    => p_Origin_Line_Id, --来源行ID
                           p_Source_Order_Type => p_Source_Order_Type, --事务来源单据类型
                           p_Source_Head_Id    => p_Source_Head_Id, --事务来源头ID
                           p_Source_Number     => p_Source_Number, --事务来源头编码
                           p_Source_Line_Id    => p_Source_Line_Id, --事务来源行ID
                           p_User_Code         => p_User_Code, --用户ID
                           p_Allow_No_Occupy   => p_Allow_No_Occupy, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                           p_Result            => p_Result, --返回错误ID
                           p_Err_Msg           => p_Err_Msg --返回错误信息
                           );
  End;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的提货订单、调拨申请定制机库存占用增加
  */
  -------------------------------------------------------------------------------
  Procedure p_Lgorder_Occupy_Stocks(p_Inventory_Id      In Number, --仓库ID
                                    p_Item_Id           In Number, --产品ID
                                    p_Occupy_Qty        In Number, --占用数量
                                    p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                    p_Entity_Id         In Number, --主体ID
                                    p_Origin_Type       In Varchar2, --来源类型
                                    p_Origin_Head_Id    In Number, --来源头ID
                                    p_Origin_Number     In Varchar2, --来源头编码
                                    p_Origin_Line_Id    In Number, --来源行ID
                                    p_Source_Order_Type In Varchar2, --事务来源单据类型
                                    p_Source_Head_Id    In Number, --事务来源头ID
                                    p_Source_Number     In Varchar2, --事务来源头编码
                                    p_Source_Line_Id    In Number, --事务来源行ID
                                    p_User_Code         In Varchar2, --用户ID
                                    p_Result            In Out Number, --返回错误ID
                                    p_Err_Msg           In Out Varchar2 --返回错误信息
                                    ) Is
  Begin
    p_Into_Occupy_Stocks(p_Inventory_Id      => p_Inventory_Id, --仓库ID
                         p_Item_Id           => p_Item_Id, --产品ID
                         p_Occupy_Qty        => -1 * p_Occupy_Qty, --占用数量
                         p_Match_Pln_To_Wip  => 'A', --工单与订单完全匹配标志 Y:完全匹配  N:非完全匹配
                         p_Operation_Type    => v_Occupytype_Salesorder, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                         p_Action_Desc       => p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                         p_Entity_Id         => p_Entity_Id, --主体ID
                         p_Origin_Type       => p_Origin_Type, --来源类型
                         p_Origin_Head_Id    => p_Origin_Head_Id, --来源头ID
                         p_Origin_Number     => p_Origin_Number, --来源头编码
                         p_Origin_Line_Id    => p_Origin_Line_Id, --来源行ID
                         p_Source_Order_Type => p_Source_Order_Type, --事务来源单据类型
                         p_Source_Head_Id    => p_Source_Head_Id, --事务来源头ID
                         p_Source_Number     => p_Source_Number, --事务来源头编码
                         p_Source_Line_Id    => p_Source_Line_Id, --事务来源行ID
                         p_User_Code         => p_User_Code, --用户ID
                         p_Result            => p_Result, --返回错误ID
                         p_Err_Msg           => p_Err_Msg --返回错误信息
                         );
  End;

  -------------------------------------------------------------------------------
  /*  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：处理订单管理的提货订单、调拨申请定定制机库存占用减少，
  */ -----------------------------------------------------------------------------
  Procedure p_Lgorder_Unoccupy_Stocks(p_Inventory_Id In Number, --仓库ID
                                      p_Item_Id      In Number, --产品ID
                                      p_Occupy_Qty   In Number, --占用数量
                                      --p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                      --P_OPERATION_TYPE    IN VARCHAR2, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                                      p_Action_Desc       In Varchar2, --单据操作描述 例：中转单据执行、中转红冲单执行
                                      p_Entity_Id         In Number, --主体ID
                                      p_Origin_Type       In Varchar2, --来源类型
                                      p_Origin_Head_Id    In Number, --来源头ID
                                      p_Origin_Number     In Varchar2, --来源头编码
                                      p_Origin_Line_Id    In Number, --来源行ID
                                      p_Source_Order_Type In Varchar2, --事务来源单据类型
                                      p_Source_Head_Id    In Number, --事务来源头ID
                                      p_Source_Number     In Varchar2, --事务来源头编码
                                      p_Source_Line_Id    In Number, --事务来源行ID
                                      p_User_Code         In Varchar2, --用户ID
                                      p_Allow_No_Occupy   In Varchar2, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                                      p_Result            In Out Number, --返回错误ID
                                      p_Err_Msg           In Out Varchar2 --返回错误信息
                                      ) Is
  Begin
    p_Into_Unoccupy_Stocks(p_Inventory_Id      => p_Inventory_Id, --仓库ID
                           p_Item_Id           => p_Item_Id, --产品ID
                           p_Occupy_Qty        => p_Occupy_Qty, --占用数量
                           p_Match_Pln_To_Wip  => 'A', --工单与订单完全匹配标志
                           p_Operation_Type    => v_Occupytype_Salesorder, --操作类型(01:库存评审  02:中转入库  03:销售开单  04:杂项(含：41:破损调拨、42:盘盈亏、43:采购退货、44:其它))
                           p_Action_Desc       => p_Action_Desc, --单据操作描述 例：中转单据执行、中转红冲单执行
                           p_Entity_Id         => p_Entity_Id, --主体ID
                           p_Origin_Type       => p_Origin_Type, --来源类型
                           p_Origin_Head_Id    => p_Origin_Head_Id, --来源头ID
                           p_Origin_Number     => p_Origin_Number, --来源头编码
                           p_Origin_Line_Id    => p_Origin_Line_Id, --来源行ID
                           p_Source_Order_Type => p_Source_Order_Type, --事务来源单据类型
                           p_Source_Head_Id    => p_Source_Head_Id, --事务来源头ID
                           p_Source_Number     => p_Source_Number, --事务来源头编码
                           p_Source_Line_Id    => p_Source_Line_Id, --事务来源行ID
                           p_User_Code         => p_User_Code, --用户ID
                           p_Allow_No_Occupy   => p_Allow_No_Occupy, --是否允许没有锁定（Y/N，Y则对于没找到对应的锁定记录则不作任何处理）
                           p_Result            => p_Result, --返回错误ID
                           p_Err_Msg           => p_Err_Msg --返回错误信息
                           );
  End;

  -------------------------------------------------------------------------------
  /*
   *  CreateDate：2015-03-10
  *   Author： 李振
  *   Purpose：返回散件的中转入库红冲单已开单未执行的数量
  */
  -------------------------------------------------------------------------------
  Function f_Get_Item_Read_Wip_Qty(p_Inventory_Id  Number,
                                   p_Sub_Item_Id   Number, --散件产品ID
                                   p_Entity_Id     Number, --主体ID
                                   p_Order_Line_Id Number --计划订单行ID
                                   ) Return Number Is
    v_Read_Po_Wip_Qty Number;
  Begin
    --add by lizhen 2015-03-09 增加占用数量扣减未执行红冲单
    Begin
      Select Sum(Decode(o.Po_Status,
                        10,
                        Nvl(Pld.Billed_Qty, 0),
                        Nvl(Pld.Shipped_Qty, 0)))
        Into v_Read_Po_Wip_Qty
        From t_Inv_Po_Headers        o,
             t_Inv_Po_Lines          l,
             t_Inv_Po_Lines_Detail   Pld,
             t_Inv_Bill_Types        t,
             t_Inv_Inventories       i,
             t_Inv_Bill_Types        Ibt,
             t_Inv_Transaction_Types Itt
       Where t.Bill_Type_Id = o.Po_Type_Id
         And t.Entity_Id = o.Entity_Id
         And l.Po_Id = o.Po_Id
         And i.Inventory_Id = o.Inv_Finance_Id
         And i.Entity_Id = o.Entity_Id
         And o.po_id = Pld.Po_Head_Id
         And l.po_line_id = Pld.Po_Line_Id
         And Pld.Order_Line_Id = p_Order_Line_Id
         And Trunc(o.Billed_Date) >= Trunc(Sysdate - 60)
         And Nvl(o.Source_Type, '_') = '工单入库'
         And Nvl(o.close_flag, 'N') != 'Y'  --ADD BY LIZHEN 2015-03-26 已关闭的不算红冲
         And o.Po_Status = '21' --发货确认
         And o.Entity_Id = p_Entity_Id
         And i.Inventory_Id = p_Inventory_Id
         And l.Item_Id = p_Sub_Item_Id
         --采购单红冲出库的单据才纳入现有量计算
         And Ibt.Transaction_Type_Id = Itt.Transaction_Type_Id
         And Itt.Action_Type = '02'
         And Ibt.Bill_Type_Id = o.Po_Type_Id
       Group By l.Item_Id;
    Exception
      When No_Data_Found Then
        v_Read_Po_Wip_Qty := 0;
      When Others Then
        Return Null;
    End;
    Return v_Read_Po_Wip_Qty;
  Exception
    When Others Then
      Return Null;
  End;

  -------------------------------------------------------------------------------
  /*
   *  创建日期：2014-06-27
  *     创建者：李振
  *   功能说明：返回套件或者散件的仓库占用数量
  *             如果是套件则按最小占用量的散件来配套
  */
  -------------------------------------------------------------------------------
  Function f_Item_Ass_Occupy_Qty(p_Inventory_Id     In Number, --仓库ID
                                 p_Item_Id          In Number, --产品ID
                                 p_Match_Pln_To_Wip In Varchar2, --工单与订单完全匹配标志
                                 p_Entity_Id        In Number, --主体ID
                                 p_Origin_Line_Id   In Number, --来源行ID
                                 p_Origin_Type      In Varchar2 Default '_' --库存占用来源类型
                                 ) Return Number Is
    v_Occupy_Qty        Number := 0;
    v_Result_Occupy_Qty Number := 9999999999;
    v_Item_Occupy_Qty   Number := 0;
    v_Read_Po_Wip_Qty   Number := 0;
  Begin
    For r_Ass In (Select Ias.Item_Id, Ias.Quantity
                    From t_Bd_Item_Assemblies     Bia,
                         t_Bd_Item_Assemblies_Sub Ias
                   Where Bia.Item_Assembly_Id = Ias.Item_Assembly_Id
                     And Bia.Entity_Id = Ias.Entity_Id
                     And Trunc(Sysdate) Between Bia.Begin_Date And
                         Nvl(Bia.End_Date, Sysdate)
                     And Trunc(Sysdate) Between Ias.Begin_Date And
                         Nvl(Ias.End_Date, Trunc(Sysdate))
                        --And Nvl(Ias.Fittings_Flag, 'N') = 'N'
                     And Bia.Item_Id = p_Item_Id
                  Union All
                  --非套件产品
                  Select Tbi.Item_Id, 1 Quantity
                    From t_Bd_Item Tbi
                   Where Tbi.Item_Id = p_Item_Id
                     And Not Exists
                   (Select 1
                            From t_Bd_Item_Assemblies Bia
                           Where Bia.Item_Id = Tbi.Item_Id
                             And Trunc(Sysdate) Between Bia.Begin_Date And
                                 Nvl(Bia.End_Date, Sysdate))) Loop
      Begin
        Select Nvl(Oio.Stock_Affirm_Qty, 0) + Nvl(Oio.Supply_Qty, 0) -
               Nvl(Oio.So_Order_Qty, 0) - Nvl(Oio.Sundry_Qty, 0)
          Into v_Occupy_Qty
          From t_Pln_Order_Inv_Occupy Oio
         Where Oio.Entity_Id = p_Entity_Id
           And Oio.Item_Id = r_Ass.Item_Id
           And Oio.Inventory_Id = p_Inventory_Id
           And ((p_Match_Pln_To_Wip = 'Y' And Oio.Origin_Type = '订单与工单完全匹配') Or
               (p_Match_Pln_To_Wip = 'N' And
               Oio.Origin_Type = '订单与工单按规则匹配') Or
               (p_Match_Pln_To_Wip Not In ('Y', 'N') And
               Oio.Origin_Type = p_Origin_Type))
           And Oio.Origin_Line_Id = p_Origin_Line_Id;
      Exception
        When Others Then
          Return 0;
      End;
      --add by lizhen 2015-03-10 取中转入库红冲未执行数量
      v_Read_Po_Wip_Qty := f_Get_Item_Read_Wip_Qty(p_Inventory_Id => p_Inventory_Id,
                                                   p_Sub_Item_Id => r_Ass.Item_id,
                                                   p_Entity_Id => p_Entity_Id,
                                                   p_Order_Line_Id => p_Origin_Line_Id);
      If v_Read_Po_Wip_Qty Is Null Then
        Return 0;
      End If;
      --取散件最小数量配套
      v_Result_Occupy_Qty := Least(v_Result_Occupy_Qty, v_Occupy_Qty - Nvl(v_Read_Po_Wip_Qty, 0));
      v_Item_Occupy_Qty   := v_Result_Occupy_Qty;
    End Loop;
    --返回最后的配套占用数量
    If v_Item_Occupy_Qty < 0 Then
      v_Item_Occupy_Qty := 0;
    End If;
    Return v_Item_Occupy_Qty;
  Exception
    When v_Base_Exception Then
      Return 0;
    When Others Then
      Return 0;
  End f_Item_Ass_Occupy_Qty;

  -------------------------------------------------------------------------------
  /*
  *  创建日期：2014-06-27
  *     创建者：李振
  *   功能说明：返回套件或者散件的仓库占用数量
  *             如果是套件则按最小占用量的散件来配套
  */
  -------------------------------------------------------------------------------
  Function f_Get_Item_Occupy_Qty(p_Inventory_Id     In Number, --仓库id
                                 p_Item_Id          In Number, --产品id
                                 p_Entity_Id        In Number, --主体id
                                 p_Match_Pln_To_Wip In Varchar2 Default 'A' --工单与订单完全匹配标志
                                 ) Return Number Is
    v_Item_Occupy_Qty Number := 0;
  Begin
    For r_Occupy In (Select Oic.Entity_Id,
                            Oic.Origin_Type,
                            Oic.Origin_Line_Id,
                            Oic.Item_Id
                       From t_Pln_Order_Inv_Occupy Oic
                      Where Oic.Inventory_Id = p_Inventory_Id
                        And Oic.Item_Id = p_Item_Id
                        And Oic.Entity_Id = p_Entity_Id
                        And ((p_Match_Pln_To_Wip = 'Y' And
                            Oic.Origin_Type = '订单与工单完全匹配') Or
                            (p_Match_Pln_To_Wip = 'N' And
                            Oic.Origin_Type = '订单与工单按规则匹配') Or
                            (p_Match_Pln_To_Wip Not In ('Y', 'N')))
                        And oic.stock_affirm_qty + oic.supply_qty - oic.so_order_qty - oic.sundry_qty > 0
                      Group By Oic.Entity_Id,
                               Oic.Origin_Type,
                               Oic.Origin_Line_Id,
                               Oic.Item_Id
                      Order By Oic.Entity_Id,
                               Oic.Origin_Line_Id,
                               Oic.Item_Id) Loop
      v_Item_Occupy_Qty := v_Item_Occupy_Qty +
                           f_Item_Ass_Occupy_Qty(p_Inventory_Id,
                                                 p_Item_Id,
                                                 'A',
                                                 p_Entity_Id,
                                                 r_Occupy.Origin_Line_Id,
                                                 r_Occupy.Origin_Type);
    End Loop;
    Return v_Item_Occupy_Qty;
  Exception
    When Others Then
      Return 0;
  End;

  -------------------------------------------------------------------------------
  /*
   *  创建日期：2014-06-24
  *     创建者：李振
  *   功能说明：特殊库存占用信息记录，
  *             该过程只处理散件
  *             p_Sign_Type: 1：占用  -1：释放
  */
  -------------------------------------------------------------------------------
  Procedure p_Dispose_Special_Occupy(p_Inventory_Id         In Number, --仓库ID
                                     p_Item_Id              In Number, --产品ID
                                     p_Trans_Date           In Date,   --事务日期
                                     p_Sign_Type            In Number, --处理标识  1：占用  -1：释放
                                     p_Trans_Qty            In Number, --占用数量
                                     p_Special_Type         In Varchar2, --特殊占用类型(含：41:破损调拨、42:盘盈亏、43:采购退货))
                                     p_Entity_Id            In Number, --主体ID
                                     p_Origin_Order_Type_Id In Varchar2, --来源类型
                                     p_Origin_Head_Id       In Number, --来源头ID
                                     p_Origin_Order_Number  In Varchar2, --来源头编码
                                     p_Origin_Line_Id       In Number, --来源行ID
                                     p_Source_Order_Type    In Varchar2, --事务来源单据类型
                                     p_Source_Head_Id       In Number, --事务来源头ID
                                     p_Source_Order_Number  In Varchar2, --事务来源头编码
                                     p_Source_Line_Id       In Number, --事务来源行ID
                                     p_User_Code            In Varchar2, --用户ID
                                     p_Result               Out Varchar2 --返回错误信息, 成功返回“SUCCESS”
                                     ) Is
    v_Value           Varchar2(2000);
    v_Sp_Occupy_Qty   Number;
    v_Order_Type_Name Varchar2(240);
  Begin
    p_Result := v_Success;
    v_Value  := v_Success;
    If p_Sign_Type Not In (1, -1) Then
      v_Value := '占用标识参数错误，该参数只接受：1、-1两个参数。';
      Raise v_Base_Exception;
    End If;
    If p_Trans_Qty < 0 Then
      v_Value := '特殊占用数量不可为负数，特殊占用数量：' || To_Char(p_Trans_Qty);
    Elsif p_Trans_Qty = 0 Then
      --占用数量为0，不处理，直接退出
      Return;
    End If;
    Begin
      v_Value := '获取来源单据类型失败，单据类型ID：' || p_Origin_Order_Type_Id;
      Select Ot.Order_Type_Name
        Into v_Order_Type_Name
        From t_Pln_Order_Type Ot
       Where Ot.Order_Type_Id = p_Origin_Order_Type_Id
         And Ot.Entity_Id = p_Entity_Id;
    Exception
      When No_Data_Found Then
        Begin
          Select Bt.Bill_Type_Name
            Into v_Order_Type_Name
            From t_Inv_Bill_Types Bt
           Where Bt.Bill_Type_Id = p_Origin_Order_Type_Id
             And Bt.Entity_Id = p_Entity_Id;
        Exception
          When Others Then
            Raise v_Base_Exception;
        End;
      When Others Then
        Raise v_Base_Exception;
    End;
    --释放占用时，检查待释放数量是否满足本次需求
    If p_Sign_Type = -1 Then
      Select Sum(Nvl(Iso.Occupy_Qty, 0) - Nvl(Iso.Release_Qty, 0))
        Into v_Sp_Occupy_Qty
        From t_Pln_Inv_Special_Occupy Iso
       Where Iso.Transaction_Date = Trunc(p_Trans_Date)
         And Iso.Inventory_Id = p_Inventory_Id
         And Iso.Item_Id = p_Item_Id
         And Iso.Origin_Line_Id = p_Origin_Line_Id
         And Iso.Origin_Order_Type_Id = p_Origin_Order_Type_Id
         And Iso.Entity_Id = p_Entity_Id;
      If p_Trans_Qty > v_Sp_Occupy_Qty Then
        v_Value := '特殊占用信息释放失败，可释放数量（' || To_Char(v_Sp_Occupy_Qty) ||
                   '）<本次需释入数量（' || To_Char(p_Trans_Qty) || '）';
        Raise v_Base_Exception;
      End If;
    End If;

    Begin
      Update t_Pln_Inv_Special_Occupy Iso
         Set Iso.Occupy_Qty       = Nvl(Iso.Occupy_Qty, 0) +
                                    Decode(p_Sign_Type, 1, p_Trans_Qty, 0),
             Iso.Release_Qty      = Nvl(Iso.Release_Qty, 0) +
                                    Decode(p_Sign_Type, -1, p_Trans_Qty, 0),
             Iso.Last_Updated_By  = p_User_Code,
             Iso.Last_Update_Date = Sysdate
       Where Iso.Transaction_Date = Trunc(p_Trans_Date)
         And Iso.Inventory_Id = p_Inventory_Id
         And Iso.Item_Id = p_Item_Id
         And Iso.Origin_Line_Id = p_Origin_Line_Id
         And Iso.Origin_Order_Type_Id = p_Origin_Order_Type_Id
         And Iso.Entity_Id = p_Entity_Id;
      If Sql%Notfound Then
        v_Value := '插入特殊占用信息表数据失败。';
        Insert Into t_Pln_Inv_Special_Occupy
          (Special_Occupy_Id, --解锁历史ID
           Entity_Id, --主体ID
           Transaction_Date, --占用日期
           Inventory_Id, --仓库ID
           Item_Id, --产品ID
           Occupy_Qty, --特殊占用数量
           Release_Qty, --特殊占用释放数量
           Compelete_Flag, --完成标志
           Origin_Order_Type_Id, --来源类型
           Origin_Order_Type_Name, --
           Origin_Head_Id, --来源头ID
           Origin_Order_Number, --来源头编码
           Origin_Line_Id, --来源行ID
           Special_Type, --41:破损调拨、42:盘盈亏、43:采购退货
           Created_By, --创建人
           Creation_Date, --创建日期
           Last_Updated_By, --最后修改人
           Last_Update_Date --最后修改日期
           )
        Values
          (s_Pln_Inv_Special_Occupy.Nextval, --SPECIAL_OCCUPY_ID, --解锁历史ID
           p_Entity_Id, --ENTITY_ID, --主体ID
           Trunc(p_Trans_Date), --TRANSACTION_DATE, --占用日期
           p_Inventory_Id, --INVENTORY_ID, --仓库ID
           p_Item_Id, --ITEM_ID, --产品ID
           p_Trans_Qty, --OCCUPY_QTY, --特殊占用数量
           0, --RELEASE_QTY, --特殊占用释放数量
           'N', --COMPELETE_FLAG, --完成标志
           p_Origin_Order_Type_Id, --ORIGIN_ORDER_TYPE_ID, --来源类型
           v_Order_Type_Name, --ORIGIN_ORDER_TYPE_NAME, --
           p_Origin_Head_Id, --ORIGIN_HEAD_ID, --来源头ID
           p_Origin_Order_Number, --ORIGIN_ORDER_NUMBER, --来源头编码
           p_Origin_Line_Id, --ORIGIN_LINE_ID, --来源行ID
           p_Special_Type, --SPECIAL_TYPE, --41:破损调拨、42:盘盈亏、43:采购退货
           p_User_Code, --CREATED_BY, --创建人
           Sysdate, --CREATION_DATE, --创建日期
           p_User_Code, --LAST_UPDATED_BY, --最后修改人
           Sysdate --LAST_UPDATE_DATE, --最后修改日期
           );
      End If;
      --更新特殊占用是否完成释放标志 N:未完全释放, Y:完全释放  E：释放数大于占用数
      Update t_Pln_Inv_Special_Occupy Iso
         Set Iso.Compelete_Flag = Decode(Sign(Nvl(Iso.Occupy_Qty, 0) -
                                              Nvl(Iso.Release_Qty, 0)),
                                         1,
                                         'N',
                                         0,
                                         'Y',
                                         'E')
       Where Iso.Transaction_Date = Trunc(p_Trans_Date)
         And Iso.Inventory_Id = p_Inventory_Id
         And Iso.Item_Id = p_Item_Id
         And Iso.Origin_Line_Id = p_Origin_Line_Id
         And Iso.Origin_Order_Type_Id = p_Origin_Order_Type_Id
         And Iso.Entity_Id = p_Entity_Id;
    Exception
      When Others Then
        v_Value := v_Value || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    Begin
      v_Value := '插入特殊占用历史表信息失败。';
      Insert Into t_Pln_Inv_Special_Occupy_His
        (His_Id, --解锁历史ID
         Entity_Id, --主体ID
         Transaction_Type, --事务类型
         Transaction_Date, --占用日期
         Inventory_Id, --仓库ID
         Item_Id, --产品ID
         Transaction_Qty, --本次事务数量
         Origin_Order_Type_Id, --来源单据类型ID
         Origin_Order_Type_Name, --
         Origin_Head_Id, --来源头ID
         Origin_Order_Number, --来源头编码
         Origin_Line_Id, --来源行ID
         Special_Type, --41:破损调拨、42:盘盈亏、43:采购退货
         Source_Order_Type, --事务来源单据类型
         Source_Head_Id, --事务来源单据头ID
         Source_Order_Number, --事务来源单据编码
         Source_Line_Id, --事务来源单据行ID
         Created_By, --创建人
         Creation_Date, --创建日期
         Last_Updated_By, --最后修改人
         Last_Update_Date --最后修改日期
         )
      Values
        (s_Pln_Inv_Special_Occupy_His.Nextval, --HIS_ID,  --解锁历史ID
         p_Entity_Id, --ENTITY_ID,  --主体ID
         Decode(p_Sign_Type, 1, '占用', -1, '释放', Null), --transaction_type,--事务类型
         Trunc(p_Trans_Date), --TRANSACTION_DATE,  --占用日期
         p_Inventory_Id, --INVENTORY_ID,  --仓库ID
         p_Item_Id, --ITEM_ID,  --产品ID
         p_Trans_Qty, --TRANSACTION_QTY,  --本次事务数量
         p_Origin_Order_Type_Id, --ORIGIN_ORDER_TYPE_ID,  --来源单据类型ID
         v_Order_Type_Name, --ORIGIN_ORDER_TYPE_NAME,  --
         p_Origin_Head_Id, --ORIGIN_HEAD_ID,  --来源头ID
         p_Origin_Order_Number, --ORIGIN_ORDER_NUMBER,  --来源头编码
         p_Origin_Line_Id, --ORIGIN_LINE_ID,  --来源行ID
         p_Special_Type, --SPECIAL_TYPE,  --41:破损调拨、42:盘盈亏、43:采购退货
         p_Source_Order_Type, --SOURCE_ORDER_TYPE,  --事务来源单据类型
         p_Source_Head_Id, --SOURCE_HEAD_ID,  --事务来源单据头ID
         p_Source_Order_Number, --SOURCE_ORDER_NUMBER,  --事务来源单据编码
         p_Source_Line_Id, --SOURCE_LINE_ID,  --事务来源单据行ID
         p_User_Code, --CREATED_BY,  --创建人
         Sysdate, --CREATION_DATE,  --创建日期
         p_User_Code, --LAST_UPDATED_BY,  --最后修改人
         Sysdate --LAST_UPDATE_DATE,  --最后修改日期
         );
    Exception
      When Others Then
        v_Value := v_Value || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
    End;
    /*If v_Value <> v_Success Then
      Rollback;
      p_Result := v_Value;
    End If;*/
  Exception
    When v_Base_Exception Then
      Rollback;
      p_Result := v_Value;
    When Others Then
      Rollback;
      p_Result := v_Value || v_Nl || Sqlerrm;
  End;

   -------------------------------------------------------------------------------
  /*
   *  创建日期：2014-11-24
  *   创建者：李振
  *   功能说明：重算库存占用数据的JOB
  */
  -------------------------------------------------------------------------------
  Procedure P_Atuo_Recalulation_Job Is
  Begin
    Begin
      --家用空调计划订单库存占用重算
      p_Auto_Recalculation_Occupy(10, 'Y');
    Exception
      When Others Then
        Null;
    End;
    Begin
      --add by lizhen 2014-12-29
      --家用空调提货订单、调拨申请库存占用重算
      p_Auto_Recalculation_Occupy(10, 'A');
    Exception
      When Others Then
        Null;
    End;
    Begin
      --厨电计划订单库存占用重算
      p_Auto_Recalculation_Occupy(14, 'Y');
    Exception
      When Others Then
        Null;
    End;
    Begin
      --add by lizhen 2014-12-29
      --厨电提货订单、调拨申请库存占用重算
      p_Auto_Recalculation_Occupy(14, 'A');
    Exception
      When Others Then
        Null;
    End;

    Begin
      --生活电器计划订单库存占用重算
      p_Auto_Recalculation_Occupy(15, 'Y');
    Exception
      When Others Then
        Null;
    End;
    Begin
      --add by lizhen 2014-12-29
      --生活电器提货订单、调拨申请库存占用重算
      p_Auto_Recalculation_Occupy(15, 'A');
    Exception
      When Others Then
        Null;
    End;
    Begin
      --环电计划订单库存占用重算
      p_Auto_Recalculation_Occupy(16, 'Y');
    Exception
      When Others Then
        Null;
    End;
    Begin
      --add by lizhen 2014-12-29
      --环电提货订单、调拨申请库存占用重算
      p_Auto_Recalculation_Occupy(16, 'A');
    Exception
      When Others Then
        Null;
    End;
    Begin
      --热水器计划订单库存占用重算
      p_Auto_Recalculation_Occupy(17, 'Y');
    Exception
      When Others Then
        Null;
    End;
    Begin
      --add by lizhen 2014-12-29
      --热水器提货订单、调拨申请库存占用重算
      p_Auto_Recalculation_Occupy(17, 'A');
    Exception
      When Others Then
        Null;
    End;
  Exception
    When Others Then
      Null;
  End;

  -------------------------------------------------------------------------------
  /*
   *  创建日期：2014-11-24
  *   创建者：李振
  *   功能说明：重算库存占用数据，重算时只重算当前未释放完的占用行
  *             该功能只重算订单相关的数据，
  */
  -------------------------------------------------------------------------------
  Procedure p_Auto_Recalculation_Occupy(p_Entity_Id         In Number,
                                        p_Pln_Wip_Ord_Match In Varchar2) Is
    v_Recalculation_Diff_Qty Number; --重算后差异
    v_Pln_Wip_Ord_Match      Varchar2(3);
    v_Value                  Varchar2(2000);
    v_Err_Num                Number;
  Begin
    /*v_Pln_Wip_Ord_Match := Pkg_Bd.f_Get_Parameter_Value('PLN_WIP_ORD_MATCH',
    p_Entity_Id);*/
    If p_Pln_Wip_Ord_Match = 'Y' Then
      v_Value := v_Success;
      For r_Occupy In (Select *
                         From t_Pln_Order_Inv_Occupy Oio
                        Where Nvl(Oio.Stock_Affirm_Qty, 0) +
                              Nvl(Oio.Supply_Qty, 0) -
                              Nvl(Oio.So_Order_Qty, 0) -
                              Nvl(Oio.Sundry_Qty, 0) <> 0
                          And Oio.Entity_Id = p_Entity_Id
                          And p_Pln_Wip_Ord_Match = 'Y'
                          And Oio.Origin_Type = '订单与工单完全匹配') Loop
        --计算库存评数量
        --库存评审数量 = 订单库评数量 + 调拨单接收数量（接收后占用库存评审数量）
        For r_Inv_Affirm In (Select *
                               From (Select Oio.Item_Id,
                                            Bi.Item_Code,
                                            Bi.Item_Name,
                                            Bi.Defaultunit,
                                            Oio.Inventory_Id,
                                            Ii.Inventory_Code,
                                            Ii.Inventory_Name,
                                            Nvl((Select Sum(Nvl(Oir.Affirm_Qty,
                                                               0) *
                                                           Nvl(Pkg_Pln_Pub.f_Get_Item_Assembly_Base(Oir.Item_Id,
                                                                                                    Oio.Item_Id),
                                                               1))
                                                  From t_Pln_Order_Inv_Review Oir
                                                 Where Oir.Inventory_Id = Oio.Inventory_Id
                                                   And Oir.Order_Line_Id = Oio.Origin_Line_Id),
                                                0) Inv_Review_Qty,
                                            --调拨单接收
                                            Nvl((Select Sum(LEAST((Nvl(Told.Rcv_Qty, 0) + Nvl(Told.Damaged_Qty, 0)), NVL(TOL.BILLED_QTY, 0)) *
                                                           Decode(Ibt.Cancel_Flag,
                                                                  'Y',
                                                                  -1,
                                                                  1))
                                                  From t_Inv_Trsf_Order             Ito,
                                                       t_Inv_Trsf_Order_Line        Tol,
                                                       t_Inv_Trsf_Order_Line_Detail Told,
                                                       t_Inv_Bill_Types             Ibt,
                                                       t_inv_transaction_types      Itt
                                                 Where Ito.Trsf_Order_Id = Tol.Trsf_Order_Id
                                                   And Told.Trsf_Order_Line_Id = Tol.Trsf_Order_Line_Id
                                                   And Told.Trsf_Order_Id = Ito.Trsf_Order_Id
                                                   And Tol.Order_Line_Id_Orig = Oio.Origin_Line_Id
                                                   And Told.Item_Id = Oio.Item_Id
                                                   And Ito.Consignee_Inv_Id = Oio.Inventory_Id
                                                   And Ibt.Bill_Type_Id = Ito.Bill_Type_Id
                                                   And Ito.Orig_Order_Type = '01' --add by lizhen 2016-01-06
                                                   And Ito.Orig_Order_Id = Oio.Origin_Head_Id --add by lizhen 2016-01-06
                                                   --add by lizhen 2015-01-18 接收仓只算蓝单
                                                   --因为红单为蓝单接收之前生成
                                                   And Nvl(Ibt.Cancel_Flag, 'N') = 'N'
                                                   --ADD BY LIZHEN 2015-01-28 特殊占用不包含在正常的重算中
                                                   And Nvl(Ibt.Special_Occupy_Flag, 'N') = 'N'
                                                   And Ito.Trsf_Order_Status = '13'
                                                   And Itt.Transaction_Type_Id = Ibt.Transaction_Type_Id
                                                   --And Ibt.Transaction_Type_Id = 17 --modi by lizhen 2015-09-18
                                                   And Itt.Transaction_Type_Code = '1017'
                                                   AND tol.lg_order_head_id IS NULL --非中心备货提货订单
                                                   ),
                                                0) Rrsf_Review_Qty,
                                            Oio.Stock_Affirm_Qty,
                                            Oio.Origin_Type,
                                            Oio.Origin_Head_Id,
                                            Oio.Origin_Number,
                                            Oio.Origin_Line_Id
                                       From Cims.t_Pln_Order_Inv_Occupy Oio,
                                            Cims.t_Bd_Item              Bi,
                                            Cims.t_Inv_Inventories      Ii
                                      Where Bi.Item_Id = Oio.Item_Id
                                        And Ii.Inventory_Id = Oio.Inventory_Id
                                        And Oio.Item_Id = r_Occupy.Item_Id
                                        And Oio.Inventory_Id = r_Occupy.Inventory_Id
                                        And Oio.Entity_Id = p_Entity_Id
                                        And Oio.Origin_Type = r_Occupy.Origin_Type)
                              Where Nvl(Inv_Review_Qty, 0) + Nvl(Rrsf_Review_Qty, 0) !=
                                    Nvl(Stock_Affirm_Qty, 0)) Loop
          v_Recalculation_Diff_Qty := Nvl(r_Inv_Affirm.Inv_Review_Qty, 0) +
                                      Nvl(r_Inv_Affirm.Rrsf_Review_Qty, 0) -
                                      Nvl(r_Inv_Affirm.Stock_Affirm_Qty, 0);
          If v_Recalculation_Diff_Qty > 0 Then
            p_Affirm_Occupy_Stocks(p_Inventory_Id      => r_Inv_Affirm.Inventory_Id,
                                   p_Item_Id           => r_Inv_Affirm.Item_Id,
                                   p_Occupy_Qty        => Abs(v_Recalculation_Diff_Qty),
                                   p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match,
                                   p_Action_Desc       => '重算库存占用，库存评审数量大于库存占用库存评审数量',
                                   p_Entity_Id         => p_Entity_Id,
                                   p_Origin_Type       => r_Inv_Affirm.Origin_Type,
                                   p_Origin_Head_Id    => r_Inv_Affirm.Origin_Head_Id,
                                   p_Origin_Number     => r_Inv_Affirm.Origin_Number,
                                   p_Origin_Line_Id    => r_Inv_Affirm.Origin_Line_Id,
                                   p_Source_Order_Type => '重算库存占用',
                                   p_Source_Head_Id    => r_Inv_Affirm.Origin_Head_Id,
                                   p_Source_Number     => r_Inv_Affirm.Origin_Number,
                                   p_Source_Line_Id    => r_Inv_Affirm.Origin_Line_Id,
                                   p_User_Code         => 'p_Auto_Recalculation_Occupy',
                                   p_Result            => v_Err_Num,
                                   p_Err_Msg           => v_Value);
          Else
            p_Affirm_Unoccupy_Stocks(p_Inventory_Id      => r_Inv_Affirm.Inventory_Id,
                                     p_Item_Id           => r_Inv_Affirm.Item_Id,
                                     p_Occupy_Qty        => Abs(v_Recalculation_Diff_Qty),
                                     p_Match_Pln_To_Wip  => v_Pln_Wip_Ord_Match,
                                     p_Action_Desc       => '重算库存占用，库存评审数量小于库存占用库存评审数量',
                                     p_Entity_Id         => p_Entity_Id,
                                     p_Origin_Type       => r_Inv_Affirm.Origin_Type,
                                     p_Origin_Head_Id    => r_Inv_Affirm.Origin_Head_Id,
                                     p_Origin_Number     => r_Inv_Affirm.Origin_Number,
                                     p_Origin_Line_Id    => r_Inv_Affirm.Origin_Line_Id,
                                     p_Source_Order_Type => '重算库存占用',
                                     p_Source_Head_Id    => r_Inv_Affirm.Origin_Head_Id,
                                     p_Source_Number     => r_Inv_Affirm.Origin_Number,
                                     p_Source_Line_Id    => r_Inv_Affirm.Origin_Line_Id,
                                     p_User_Code         => 'p_Auto_Recalculation_Occupy',
                                     p_Allow_No_Occupy   => 'N',
                                     p_Result            => v_Err_Num,
                                     p_Err_Msg           => v_Value);
          End If;
          If v_Value != v_Success Then
            Rollback;
            Pkg_Pln_Pub.p_Write_Job_Log('PLN',
                                        'Pkg_Pln_Inv_Occupy.p_Auto_Recalculation_Occupy',
                                        '重算库存占用，库存评审数量不等于库存占用库存评审数量。' || v_Nl ||
                                        v_Value,
                                        r_Inv_Affirm.Origin_Head_Id,
                                        r_Inv_Affirm.Origin_Line_Id,
                                        r_Inv_Affirm.Item_Id,
                                        r_Inv_Affirm.Inventory_Id,
                                        v_Recalculation_Diff_Qty);
            Commit;
          End If;
        End Loop;
        --中转入库单
        For r_Po_Supply In (Select *
                              From (Select Oio.Item_Id,
                                           Bi.Item_Code,
                                           Bi.Item_Name,
                                           Bi.Defaultunit,
                                           Oio.Inventory_Id,
                                           Ii.Inventory_Code,
                                           Ii.Inventory_Name,
                                           Nvl((Select Sum(Pld.Executed_Qty *
                                                          Decode(Itt.Action_Type,
                                                                 '01',
                                                                 1,
                                                                 '02',
                                                                 -1,
                                                                 0)) Exceuted_Qty
                                                 From Cims.t_Inv_Po_Headers        Iph,
                                                      Cims.t_Inv_Po_Lines          Ipl,
                                                      Cims.t_Inv_Po_Lines_Detail   Pld,
                                                      Cims.t_Inv_Bill_Types        Ibt,
                                                      Cims.t_Inv_Transaction_Types Itt
                                                Where Iph.Po_Id = Ipl.Po_Id
                                                  And Ipl.Po_Line_Id = Pld.Po_Line_Id
                                                  And Iph.Po_Id = Pld.Po_Head_Id
                                                  And Ibt.Bill_Type_Id = Iph.Po_Type_Id
                                                  And Itt.Transaction_Type_Id = Ibt.Transaction_Type_Id
                                                  And Pld.Order_Line_Id = Oio.Origin_Line_Id
                                                  And Pld.Order_Header_Id = Oio.Origin_Head_Id --add by lizhen 2016-01-06
                                                  And Pld.Item_Id = Oio.Item_Id
                                                  And Nvl(Iph.Close_Flag, 'N') = 'N'
                                                  --ADD BY LIZHEN 2015-01-28 特殊占用不包含在正常的重算中
                                                  And Nvl(Ibt.Special_Occupy_Flag, 'N') = 'N'
                                                  And Iph.Inv_Finance_Id = Oio.Inventory_Id
                                                  And Nvl(Iph.Source_Type, '_') = '工单入库'
                                                  And ((Iph.Po_Status = '14' And Itt.Action_Type = '01')
                                                  --modi by lizhen 2015-03-17 中转单必须为已执行
                                                   Or (iph.po_status In (/*'21',*/ '14') And itt.action_type = '02')) --已执行
                                               ),
                                               0) Po_Executed_Qty,
                                           Oio.Supply_Qty,
                                           Oio.Origin_Type,
                                           Oio.Origin_Head_Id,
                                           Oio.Origin_Number,
                                           Oio.Origin_Line_Id
                                      From Cims.t_Pln_Order_Inv_Occupy Oio,
                                           Cims.t_Bd_Item              Bi,
                                           Cims.t_Inv_Inventories      Ii
                                     Where Bi.Item_Id = Oio.Item_Id
                                       And Ii.Inventory_Id = Oio.Inventory_Id
                                       And Oio.Entity_Id = p_Entity_Id
                                       And Oio.Item_Id = r_Occupy.Item_Id
                                       And Oio.Inventory_Id = r_Occupy.Inventory_Id
                                       And Oio.Origin_Type = r_Occupy.Origin_Type
                                       And Oio.Origin_Line_Id = r_Occupy.Origin_Line_Id)
                             Where Nvl(Supply_Qty, 0) != Nvl(Po_Executed_Qty, 0)) Loop
          v_Recalculation_Diff_Qty := Nvl(r_Po_Supply.Po_Executed_Qty, 0) -
                                      Nvl(r_Po_Supply.Supply_Qty, 0);
          If Nvl(v_Recalculation_Diff_Qty, 0) > 0 Then
            p_Supply_Occupy_Stocks(p_Inventory_Id      => r_Po_Supply.Inventory_Id,
                                   p_Item_Id           => r_Po_Supply.Item_Id,
                                   p_Occupy_Qty        => Abs(v_Recalculation_Diff_Qty),
                                   p_Match_Pln_To_Wip  => p_Pln_Wip_Ord_Match,
                                   p_Action_Desc       => '重算库存占用，采购中转入库数量大于库存占用采购入库数量',
                                   p_Entity_Id         => p_Entity_Id,
                                   p_Origin_Type       => r_Po_Supply.Origin_Type,
                                   p_Origin_Head_Id    => r_Po_Supply.Origin_Head_Id,
                                   p_Origin_Number     => r_Po_Supply.Origin_Number,
                                   p_Origin_Line_Id    => r_Po_Supply.Origin_Line_Id,
                                   p_Source_Order_Type => '重算库存占用',
                                   p_Source_Head_Id    => r_Po_Supply.Origin_Head_Id,
                                   p_Source_Number     => r_Po_Supply.Origin_Number,
                                   p_Source_Line_Id    => r_Po_Supply.Origin_Line_Id,
                                   p_User_Code         => 'p_Auto_Recalculation_Occupy',
                                   p_Result            => v_Err_Num,
                                   p_Err_Msg           => v_Value);
          Else
            p_Supply_Unoccupy_Stocks(p_Inventory_Id      => r_Po_Supply.Inventory_Id,
                                     p_Item_Id           => r_Po_Supply.Item_Id,
                                     p_Occupy_Qty        => Abs(v_Recalculation_Diff_Qty),
                                     p_Match_Pln_To_Wip  => p_Pln_Wip_Ord_Match,
                                     p_Action_Desc       => '重算库存占用，采购中转入库数量小于库存占用采购入库数量',
                                     p_Entity_Id         => p_Entity_Id,
                                     p_Origin_Type       => r_Po_Supply.Origin_Type,
                                     p_Origin_Head_Id    => r_Po_Supply.Origin_Head_Id,
                                     p_Origin_Number     => r_Po_Supply.Origin_Number,
                                     p_Origin_Line_Id    => r_Po_Supply.Origin_Line_Id,
                                     p_Source_Order_Type => '重算库存占用',
                                     p_Source_Head_Id    => r_Po_Supply.Origin_Head_Id,
                                     p_Source_Number     => r_Po_Supply.Origin_Number,
                                     p_Source_Line_Id    => r_Po_Supply.Origin_Line_Id,
                                     p_User_Code         => 'p_Auto_Recalculation_Occupy',
                                     p_Allow_No_Occupy   => 'N',
                                     p_Result            => v_Err_Num,
                                     p_Err_Msg           => v_Value);
          End If;
          If v_Value != v_Success Then
            Rollback;
            Pkg_Pln_Pub.p_Write_Job_Log('PLN',
                                        'Pkg_Pln_Inv_Occupy.p_Auto_Recalculation_Occupy',
                                        '重算库存占用，采购中转入库数量不等于库存占用采购入库数量。' || v_Nl ||
                                        v_Value,
                                        r_Po_Supply.Origin_Head_Id,
                                        r_Po_Supply.Origin_Line_Id,
                                        r_Po_Supply.Item_Id,
                                        r_Po_Supply.Inventory_Id,
                                        v_Recalculation_Diff_Qty);
            Commit;
          End If;
        End Loop;
        --销售单据
        For r_So_Order In (Select *
                             From (Select Oio.Item_Id,
                                          Bi.Item_Code,
                                          Bi.Item_Name,
                                          Bi.Defaultunit,
                                          Oio.Inventory_Id,
                                          Ii.Inventory_Code,
                                          Ii.Inventory_Name,
                                          Nvl((Select Sum(Ste.Applied_Plus_Minus_Flag *
                                                         Sld.Component_Qty)
                                                From t_So_Header      Tsh,
                                                     t_So_Line        Tsl,
                                                     t_So_Line_Detail Sld,
                                                     v_So_Bill_Type   Sbt,
                                                     t_So_Type_Extend Ste
                                               Where Tsh.So_Header_Id = Tsl.So_Header_Id
                                                 And Tsh.So_Header_Id = Sld.So_Header_Id
                                                 And Tsl.So_Line_Id = Sld.So_Line_Id
                                                 And Sbt.Bill_Type_Id = Tsh.Bill_Type_Id
                                                 And Tsh.Raw_Src_Type In ('01')
                                                 And Ste.Bill_Type_Id = Tsh.Bill_Type_Id
                                                 And Tsl.Raw_Src_Line_Id = Oio.Origin_Line_Id
                                                 And Tsh.Raw_Src_Bill_Id = Oio.Origin_Head_Id  --add by lizhen 2016-01-06
                                                 And Sld.Component_Id = Oio.Item_Id
                                                 And Tsh.Ship_Inv_Id = Oio.Inventory_Id
                                                 --add by lizhen 2016-02-25 T+3提货订单的销售红冲单据不需要解锁，重算时不计入锁定数量
                                                 And (Nvl(Sbt.Reversal_Bill_Flag, 'N') = 'N' Or
                                                     (Nvl(Sbt.Reversal_Bill_Flag, 'N') = 'Y' And
                                                     (Nvl(Tsh.Origin_Origin_Type, '_') != '02' And
                                                     Instr(Tsh.Remark, '本单据为差异签收产生的红冲单') = 0) Or
                                                     (Nvl(Tsh.Origin_Origin_Type, '_') = '02' And Exists
                                                      (Select 1
                                                           From Cims.t_Pln_Lg_Order_Head Loh, Cims.t_Pln_Order_Type Pot
                                                          Where Loh.Order_Type_Id = Pot.Order_Type_Id
                                                            And Nvl(Pot.Is_Business_Control, '_') = 'share_ship_order'
                                                            And Loh.Order_Head_Id = Tsh.Origin_Origin_Head_Id))))),
                                              0) So_Soorder_Qty,
                                          --调拨审核出库
                                          Nvl((Select Sum(Nvl(Told.Billed_Qty, 0) *
                                                         Decode(Ibt.Cancel_Flag,
                                                                'Y',
                                                                Decode(Ito.Trsf_Order_Status, 13, -1, 0),
                                                                1))
                                                From t_Inv_Trsf_Order             Ito,
                                                     t_Inv_Trsf_Order_Line        Tol,
                                                     t_Inv_Trsf_Order_Line_Detail Told,
                                                     t_Inv_Bill_Types             Ibt,
                                                     t_Inv_Transaction_Types      Itt
                                               Where Ito.Trsf_Order_Id = Tol.Trsf_Order_Id
                                                 And Told.Trsf_Order_Line_Id = Tol.Trsf_Order_Line_Id
                                                 And Told.Trsf_Order_Id = Ito.Trsf_Order_Id
                                                 And Tol.Order_Line_Id_Orig = Oio.Origin_Line_Id
                                                 And Told.Item_Id = Oio.Item_Id
                                                 And Ito.Ship_Inv_Id = Oio.Inventory_Id
                                                 And Ibt.Bill_Type_Id = Ito.Bill_Type_Id
                                                 And Ito.Orig_Order_Type = '01' --add by lizhen 2016-01-06
                                                 And Ito.Orig_Order_Id = Oio.Origin_Head_Id --add by lizhen 2016-01-06
                                                 --ADD BY LIZHEN 2015-01-28 特殊占用不包含在正常的重算中
                                                 And Nvl(Ibt.Special_Occupy_Flag, 'N') = 'N'
                                                 And Ito.Trsf_Order_Status <> '10'
                                                 --And Ibt.Transaction_Type_Id = 17 --modi by lizhen 2015-09-18
                                                 And Itt.Transaction_Type_Id = Ibt.Transaction_Type_Id
                                                 And Itt.Transaction_Type_Code = '1017'
                                                 AND (tol.lg_order_head_id IS NULL OR (tol.lg_order_line_id IS NOT NULL AND nvl(ibt.cancel_flag, 'N') = 'N'))
                                                 ),
                                              0) Rrsf_Order_Qty,
                                          Oio.So_Order_Qty,
                                          Oio.Origin_Type,
                                          Oio.Origin_Head_Id,
                                          Oio.Origin_Number,
                                          Oio.Origin_Line_Id
                                     From Cims.t_Pln_Order_Inv_Occupy Oio,
                                          Cims.t_Bd_Item              Bi,
                                          Cims.t_Inv_Inventories      Ii
                                    Where Bi.Item_Id = Oio.Item_Id
                                      And Ii.Inventory_Id = Oio.Inventory_Id
                                      And Oio.Entity_Id = p_Entity_Id
                                      And Oio.Origin_Type = r_Occupy.Origin_Type
                                      And Oio.Origin_Head_Id = r_Occupy.Origin_Head_Id
                                      And Oio.Origin_Line_Id = r_Occupy.Origin_Line_Id)
                            Where Nvl(So_Order_Qty, 0) !=
                                  Nvl(So_Soorder_Qty, 0) +
                                  Nvl(Rrsf_Order_Qty, 0)) Loop
          v_Recalculation_Diff_Qty := Nvl(r_So_Order.So_Soorder_Qty, 0) +
                                      Nvl(r_So_Order.Rrsf_Order_Qty, 0) -
                                      Nvl(r_So_Order.So_Order_Qty, 0);
          If Nvl(v_Recalculation_Diff_Qty, 0) > 0 Then
            p_Soorder_Unoccupy_Stocks(p_Inventory_Id      => r_So_Order.Inventory_Id,
                                      p_Item_Id           => r_So_Order.Item_Id,
                                      p_Occupy_Qty        => Abs(v_Recalculation_Diff_Qty),
                                      p_Match_Pln_To_Wip  => p_Pln_Wip_Ord_Match,
                                      p_Action_Desc       => '重算库存占用，销售出库数量大于库存占用销售出库数量',
                                      p_Entity_Id         => p_Entity_Id,
                                      p_Origin_Type       => r_So_Order.Origin_Type,
                                      p_Origin_Head_Id    => r_So_Order.Origin_Head_Id,
                                      p_Origin_Number     => r_So_Order.Origin_Number,
                                      p_Origin_Line_Id    => r_So_Order.Origin_Line_Id,
                                      p_Source_Order_Type => '重算库存占用',
                                      p_Source_Head_Id    => r_So_Order.Origin_Head_Id,
                                      p_Source_Number     => r_So_Order.Origin_Number,
                                      p_Source_Line_Id    => r_So_Order.Origin_Line_Id,
                                      p_User_Code         => 'p_Auto_Recalculation_Occupy',
                                      p_Allow_No_Occupy   => 'N',
                                      p_Result            => v_Err_Num,
                                      p_Err_Msg           => v_Value);
          Else
            p_Soorder_Occupy_Stocks(p_Inventory_Id      => r_So_Order.Inventory_Id,
                                    p_Item_Id           => r_So_Order.Item_Id,
                                    p_Occupy_Qty        => Abs(v_Recalculation_Diff_Qty),
                                    p_Match_Pln_To_Wip  => p_Pln_Wip_Ord_Match,
                                    p_Action_Desc       => '重算库存占用，销售出库数量小于库存占用销售出库数量',
                                    p_Entity_Id         => p_Entity_Id,
                                    p_Origin_Type       => r_So_Order.Origin_Type,
                                    p_Origin_Head_Id    => r_So_Order.Origin_Head_Id,
                                    p_Origin_Number     => r_So_Order.Origin_Number,
                                    p_Origin_Line_Id    => r_So_Order.Origin_Line_Id,
                                    p_Source_Order_Type => '重算库存占用',
                                    p_Source_Head_Id    => r_So_Order.Origin_Head_Id,
                                    p_Source_Number     => r_So_Order.Origin_Number,
                                    p_Source_Line_Id    => r_So_Order.Origin_Line_Id,
                                    p_User_Code         => 'p_Auto_Recalculation_Occupy',
                                    p_Result            => v_Err_Num,
                                    p_Err_Msg           => v_Value);
          End If;
          If v_Value != v_Success Then
            Rollback;
            Pkg_Pln_Pub.p_Write_Job_Log('PLN',
                                        'Pkg_Pln_Inv_Occupy.p_Auto_Recalculation_Occupy',
                                        '重算库存占用，销售出库数量不等于库存占用销售出库数量。' || v_Nl ||
                                        v_Value,
                                        r_So_Order.Origin_Head_Id,
                                        r_So_Order.Origin_Line_Id,
                                        r_So_Order.Item_Id,
                                        r_So_Order.Inventory_Id,
                                        v_Recalculation_Diff_Qty);
            Commit;
          End If;
        End Loop;
        ----特殊占用
        For r_Special In (Select *
                            From (Select Oio.Item_Id,
                                         Bi.Item_Code,
                                         Bi.Item_Name,
                                         Bi.Defaultunit,
                                         Oio.Inventory_Id,
                                         Ii.Inventory_Code,
                                         Ii.Inventory_Name,
                                         Nvl((Select Sum(Nvl(Iso.Occupy_Qty, 0) -
                                                        Nvl(Iso.Release_Qty, 0))
                                               From t_Pln_Inv_Special_Occupy Iso
                                              Where Iso.Origin_Line_Id = Oio.Origin_Line_Id
                                                And Iso.Inventory_Id = Oio.Inventory_Id
                                                And Iso.Item_Id = Oio.Item_Id),
                                             0) Special_Occupy_Qty,
                                         --取消订单数量
                                         Nvl((Select Sum(Nvl(Osh.Quantity, 0) *
                                                        Nvl(Pkg_Pln_Pub.f_Get_Item_Assembly_Base(Osh.Item_Id,
                                                                                                 Oio.Item_Id),
                                                            0))
                                               From t_Pln_Order_Share_History Osh
                                              Where Osh.Inventory_From_Id = Oio.Inventory_Id
                                                And Osh.Order_Line_Id = Oio.Origin_Line_Id
                                                And Osh.Option_Type = '取消订单数量'),
                                             0) Cancel_Order_Qty,
                                         Oio.Sundry_Qty,
                                         Oio.Origin_Type,
                                         Oio.Origin_Head_Id,
                                         Oio.Origin_Number,
                                         Oio.Origin_Line_Id
                                    From Cims.t_Pln_Order_Inv_Occupy Oio,
                                         Cims.t_Bd_Item              Bi,
                                         Cims.t_Inv_Inventories      Ii
                                   Where Bi.Item_Id = Oio.Item_Id
                                     And Ii.Inventory_Id = Oio.Inventory_Id
                                     And Oio.Entity_Id = p_Entity_Id
                                     And Oio.Origin_Type = r_Occupy.Origin_Type
                                     And Oio.Item_Id = r_Occupy.Item_Id
                                     And Oio.Inventory_Id = r_Occupy.Inventory_Id
                                     And Oio.Origin_Line_Id = r_Occupy.Origin_Line_Id)
                           Where Nvl(Sundry_Qty, 0) !=
                                 Nvl(Cancel_Order_Qty, 0) +
                                 Nvl(Special_Occupy_Qty, 0)) Loop
          v_Recalculation_Diff_Qty := Nvl(r_Special.Cancel_Order_Qty, 0) +
                                      Nvl(r_Special.Special_Occupy_Qty, 0) -
                                      Nvl(r_Special.Sundry_Qty, 0);
          Begin
            If Nvl(v_Recalculation_Diff_Qty, 0) > 0 Then
              p_Others_Occupy_Stocks(p_Inventory_Id      => r_Special.Inventory_Id,
                                     p_Item_Id           => r_Special.Item_Id,
                                     p_Occupy_Qty        => Abs(v_Recalculation_Diff_Qty),
                                     p_Match_Pln_To_Wip  => p_Pln_Wip_Ord_Match,
                                     p_Action_Desc       => '重算库存占用，特殊占用数量大于库存占用特殊占用数量',
                                     p_Entity_Id         => p_Entity_Id,
                                     p_Origin_Type       => r_Special.Origin_Type,
                                     p_Origin_Head_Id    => r_Special.Origin_Head_Id,
                                     p_Origin_Number     => r_Special.Origin_Number,
                                     p_Origin_Line_Id    => r_Special.Origin_Line_Id,
                                     p_Source_Order_Type => '重算库存占用',
                                     p_Source_Head_Id    => r_Special.Origin_Head_Id,
                                     p_Source_Number     => r_Special.Origin_Number,
                                     p_Source_Line_Id    => r_Special.Origin_Line_Id,
                                     p_User_Code         => 'p_Auto_Recalculation_Occupy',
                                     p_Result            => v_Err_Num,
                                     p_Err_Msg           => v_Value);
            Else
              p_Others_Unoccupy_Stocks(p_Inventory_Id      => r_Special.Inventory_Id,
                                       p_Item_Id           => r_Special.Item_Id,
                                       p_Occupy_Qty        => Abs(v_Recalculation_Diff_Qty),
                                       p_Match_Pln_To_Wip  => p_Pln_Wip_Ord_Match,
                                       p_Action_Desc       => '重算库存占用，特殊占用数量小于库存占用特殊占用数量',
                                       p_Entity_Id         => p_Entity_Id,
                                       p_Origin_Type       => r_Special.Origin_Type,
                                       p_Origin_Head_Id    => r_Special.Origin_Head_Id,
                                       p_Origin_Number     => r_Special.Origin_Number,
                                       p_Origin_Line_Id    => r_Special.Origin_Line_Id,
                                       p_Source_Order_Type => '重算库存占用',
                                       p_Source_Head_Id    => r_Special.Origin_Head_Id,
                                       p_Source_Number     => r_Special.Origin_Number,
                                       p_Source_Line_Id    => r_Special.Origin_Line_Id,
                                       p_User_Code         => 'p_Auto_Recalculation_Occupy',
                                       p_Allow_No_Occupy   => 'N',
                                       p_Result            => v_Err_Num,
                                       p_Err_Msg           => v_Value);
            End If;
            If v_Value != v_Success Then
              Rollback;
              Pkg_Pln_Pub.p_Write_Job_Log('PLN',
                                          'Pkg_Pln_Inv_Occupy.p_Auto_Recalculation_Occupy',
                                          '重算库存占用，特殊占用数量不等于库存占用特殊占用数量。' || v_Nl ||
                                          v_Value,
                                          r_Special.Origin_Head_Id,
                                          r_Special.Origin_Line_Id,
                                          r_Special.Item_Id,
                                          r_Special.Inventory_Id,
                                          v_Recalculation_Diff_Qty);
              Commit;
            End If;
          End;
        End Loop;
        Commit;
      End Loop;
    Elsif p_Pln_Wip_Ord_Match Not In ('Y', 'N') Then
      --ADD BY LIZHEN 该部份重计只支持提货订单、调拨申请单据类型
      For r_Occupy In (Select Oio.*
                        From t_Pln_Order_Inv_Occupy Oio,
                             t_Pln_Lg_Order_Head    Loh,
                             t_Pln_Order_Type       Pot
                       Where (Nvl(Oio.Stock_Affirm_Qty, 0) + Nvl(Oio.Supply_Qty, 0) -
                             Nvl(Oio.So_Order_Qty, 0) - Nvl(Oio.Sundry_Qty, 0) <> 0
                           /*Or pkg_inv_pub.f_Get_Item_Inv_Qoh(p_Entity_Id => p_Entity_Id,
                                                             p_Inventory_Id => Oio.Inventory_Id,
                                                             p_Item_Id => Oio.Item_Id,
                                                             p_User_Code => 'admin',
                                                             p_get_qoh_type => 2) < 0*/)
                         --And oio.origin_head_id = 35
                         And Oio.Entity_Id = p_Entity_Id
                         And p_Pln_Wip_Ord_Match Not In ('Y', 'N')
                         And Oio.Origin_Head_Id = Loh.Order_Head_Id
                         And Loh.Order_Type_Id = Pot.Order_Type_Id
                         And Pot.Source_Order_Type_Id In (1, 3) --提货订单、调拨申请
                         And Oio.Origin_Type Not In
                             ('订单与工单按规则匹配', '订单与工单完全匹配')
                         and (oio.origin_type <> (select bt.bill_type_name
                                       from t_inv_bill_types bt
                                      where source_type_id =
                                            (select source_type_id
                                               from t_inv_source_types
                                              where source_type_code = '1009'
                                                and entity_id = p_Entity_Id
                                             )
                                        and bt.erp_trancation = '10'
                                        and bt.entity_id =p_Entity_Id))
                             )Loop
      --计算库存评数量
      --库存评审数量 = 订单库评数量 + 调拨单接收数量（接收后占用库存评审数量）
      --hejy3 增加提货订单预占用数量重算
      For r_Inv_Affirm In (Select *
                             From (Select Oio.Item_Id,
                                          Bi.Item_Code,
                                          Bi.Item_Name,
                                          Bi.Defaultunit,
                                          Oio.Inventory_Id,
                                          Ii.Inventory_Code,
                                          Ii.Inventory_Name,
                                          Nvl((Select Sum(Nvl(Ori.Affirm_Qty, 0) *
                                                      Nvl(Pkg_Pln_Pub.f_Get_Item_Assembly_Base(Ori.Item_Id,
                                                                                               Oio.Item_Id),
                                                          1))
                                             From t_pln_order_review_info Ori
                                            Where Ori.Send_Inventory_Id = Oio.Inventory_Id
                                              And Ori.Origin_Order_Line_Id = Oio.Origin_Line_Id
                                              AND oio.origin_type not in ('提货订单预占用', '二次发运')),
                                           0) +
                                          --预占用库存
                                          nvl((SELECT SUM(nvl(ioh.quantity, 0) *
                                                         Nvl(Pkg_Pln_Pub.f_Get_Item_Assembly_Base(ioh.Item_Id,
                                                                                                  Oio.Item_Id),
                                                          1))
                                                FROM T_PLN_LG_PRE_INV_OCC_HIS ioh
                                               WHERE ioh.order_line_id = oio.origin_line_id
                                                 AND ioh.inv_id = oio.inventory_id
                                                 AND oio.origin_type in ('提货订单预占用', '二次发运')),0) Inv_Review_Qty,
                                          Oio.Stock_Affirm_Qty,
                                          Oio.Origin_Type,
                                          Oio.Origin_Head_Id,
                                          Oio.Origin_Number,
                                          Oio.Origin_Line_Id
                                     From Cims.t_Pln_Order_Inv_Occupy Oio,
                                          Cims.t_Bd_Item              Bi,
                                          Cims.t_Inv_Inventories      Ii
                                    Where Bi.Item_Id = Oio.Item_Id
                                      And Ii.Inventory_Id = Oio.Inventory_Id
                                      And Oio.Item_Id = r_Occupy.Item_Id
                                      And Oio.Inventory_Id = r_Occupy.Inventory_Id
                                      And Oio.Entity_Id = p_Entity_Id
                                      And Oio.Origin_Type = r_Occupy.Origin_Type)
                            Where Nvl(Inv_Review_Qty, 0) !=
                                  Nvl(Stock_Affirm_Qty, 0)) Loop
        v_Recalculation_Diff_Qty := Nvl(r_Inv_Affirm.Inv_Review_Qty, 0) -
                                    Nvl(r_Inv_Affirm.Stock_Affirm_Qty, 0);
        If v_Recalculation_Diff_Qty > 0 Then
          p_Affirm_Occupy_Stocks(p_Inventory_Id      => r_Inv_Affirm.Inventory_Id,
                                 p_Item_Id           => r_Inv_Affirm.Item_Id,
                                 p_Occupy_Qty        => Abs(v_Recalculation_Diff_Qty),
                                 p_Match_Pln_To_Wip  => 'A',
                                 p_Action_Desc       => '重算库存占用，库存评审数量大于库存占用库存评审数量',
                                 p_Entity_Id         => p_Entity_Id,
                                 p_Origin_Type       => r_Inv_Affirm.Origin_Type,
                                 p_Origin_Head_Id    => r_Inv_Affirm.Origin_Head_Id,
                                 p_Origin_Number     => r_Inv_Affirm.Origin_Number,
                                 p_Origin_Line_Id    => r_Inv_Affirm.Origin_Line_Id,
                                 p_Source_Order_Type => '重算库存占用',
                                 p_Source_Head_Id    => r_Inv_Affirm.Origin_Head_Id,
                                 p_Source_Number     => r_Inv_Affirm.Origin_Number,
                                 p_Source_Line_Id    => r_Inv_Affirm.Origin_Line_Id,
                                 p_User_Code         => 'p_Auto_Recalculation_Occupy',
                                 p_Result            => v_Err_Num,
                                 p_Err_Msg           => v_Value);
        Else
          p_Affirm_Unoccupy_Stocks(p_Inventory_Id      => r_Inv_Affirm.Inventory_Id,
                                   p_Item_Id           => r_Inv_Affirm.Item_Id,
                                   p_Occupy_Qty        => Abs(v_Recalculation_Diff_Qty),
                                   p_Match_Pln_To_Wip  => 'A',
                                   p_Action_Desc       => '重算库存占用，库存评审数量小于库存占用库存评审数量',
                                   p_Entity_Id         => p_Entity_Id,
                                   p_Origin_Type       => r_Inv_Affirm.Origin_Type,
                                   p_Origin_Head_Id    => r_Inv_Affirm.Origin_Head_Id,
                                   p_Origin_Number     => r_Inv_Affirm.Origin_Number,
                                   p_Origin_Line_Id    => r_Inv_Affirm.Origin_Line_Id,
                                   p_Source_Order_Type => '重算库存占用',
                                   p_Source_Head_Id    => r_Inv_Affirm.Origin_Head_Id,
                                   p_Source_Number     => r_Inv_Affirm.Origin_Number,
                                   p_Source_Line_Id    => r_Inv_Affirm.Origin_Line_Id,
                                   p_User_Code         => 'p_Auto_Recalculation_Occupy',
                                   p_Allow_No_Occupy   => 'N',
                                   p_Result            => v_Err_Num,
                                   p_Err_Msg           => v_Value);
        End If;
        If v_Value != v_Success Then
          Rollback;
          Pkg_Pln_Pub.p_Write_Job_Log('PLN',
                                      'Pkg_Pln_Inv_Occupy.p_Auto_Recalculation_Occupy',
                                      '重算库存占用，库存评审数量不等于库存占用库存评审数量。' || v_Nl ||
                                      v_Value,
                                      r_Inv_Affirm.Origin_Head_Id,
                                      r_Inv_Affirm.Origin_Line_Id,
                                      r_Inv_Affirm.Item_Id,
                                      r_Inv_Affirm.Inventory_Id,
                                      v_Recalculation_Diff_Qty);
          Commit;
        End If;
      End Loop;

      --销售单据
      For r_So_Order In (Select *
                           From (Select Oio.Item_Id,
                                        Bi.Item_Code,
                                        Bi.Item_Name,
                                        Bi.Defaultunit,
                                        Oio.Inventory_Id,
                                        Ii.Inventory_Code,
                                        Ii.Inventory_Name,
                                        Nvl((Select Sum(Ste.Applied_Plus_Minus_Flag *
                                                       Sld.Component_Qty)
                                              From t_So_Header      Tsh,
                                                   t_So_Line        Tsl,
                                                   t_So_Line_Detail Sld,
                                                   v_So_Bill_Type   Sbt,
                                                   t_So_Type_Extend Ste
                                             Where Tsh.So_Header_Id = Tsl.So_Header_Id
                                               And Tsh.So_Header_Id = Sld.So_Header_Id
                                               And Tsl.So_Line_Id = Sld.So_Line_Id
                                               And Sbt.Bill_Type_Id = Tsh.Bill_Type_Id
                                               And Tsh.Raw_Src_Type In ('02', '03')
                                               And Ste.Bill_Type_Id = Tsh.Bill_Type_Id
                                               And Tsl.Raw_Src_Line_Id = Oio.Origin_Line_Id
                                               And Tsh.Raw_Src_Bill_Id = Oio.Origin_Head_Id --modi by lizhen 2016-01-06
                                               And Sld.Component_Id = Oio.Item_Id
                                               And Tsh.Ship_Inv_Id = Oio.Inventory_Id
                                               --add by lizhen 2016-02-27 提货订单的红冲单据不计入重算
                                               And Nvl(Sbt.REVERSAL_BILL_FLAG, 'N') <> 'Y'
                                               ),
                                            0) So_Soorder_Qty,
                                        --调拨审核出库
                                        Nvl((Select Sum(Nvl(Told.Billed_Qty, 0) *
                                                       Decode(Ibt.Cancel_Flag,
                                                              'Y',
                                                              Decode(Ito.Trsf_Order_Status, 13, -1, 0),
                                                              1))
                                              From t_Inv_Trsf_Order             Ito,
                                                   t_Inv_Trsf_Order_Line        Tol,
                                                   t_Inv_Trsf_Order_Line_Detail Told,
                                                   t_Inv_Bill_Types             Ibt,
                                                   t_Inv_Transaction_Types      Itt
                                             Where Ito.Trsf_Order_Id = Tol.Trsf_Order_Id
                                               And Told.Trsf_Order_Line_Id = Tol.Trsf_Order_Line_Id
                                               And Told.Trsf_Order_Id = Ito.Trsf_Order_Id
                                               And Tol.Order_Line_Id_Orig = Oio.Origin_Line_Id
                                               And Told.Item_Id = Oio.Item_Id
                                               And Ito.Ship_Inv_Id = Oio.Inventory_Id
                                               And Ibt.Bill_Type_Id = Ito.Bill_Type_Id
                                               --And Ito.Orig_Order_Type = '03'
                                               AND ito.orig_order_type IN ('02', '03')
                                               And Ito.Trsf_Order_Status <> '10'
                                               and nvl(ibt.CANCEL_FLAG, 'N') = 'N' --20180322 hejy3 取非红冲单
                                               --And Ibt.Transaction_Type_Id = 17 --modi by lizhen 2015-09-18
                                               And Itt.Transaction_Type_Id = Ibt.Transaction_Type_Id
                                               And Itt.Transaction_Type_Code = '1017'
                                               ),
                                            0) Rrsf_Order_Qty,
                                        --add by lizhen 2015-08-13 推广物料发放领用数量
                                        Nvl((Select Sum(Nvl(csl.rcv_qty, 0))
                                          From t_Pmt_Collar_Send_Head Csh, t_Pmt_Collar_Send_Line Csl
                                         Where Csh.Collar_Send_Head_Id = Csl.Collar_Send_Head_Id
                                           And Nvl(Csh.Source_Type, '_') = '01'
                                           And Csl.Origin_Order_Id = Oio.Origin_Head_Id
                                           And Csl.Origin_Line_Id = Oio.Origin_Line_Id
                                           And Csl.Pmt_Id = Oio.Item_Id
                                           And Csh.Ship_Inventory_Id = Oio.Inventory_Id), 0) Pmt_Collar_Send_Qty,
                                        Oio.So_Order_Qty,
                                        Oio.Origin_Type,
                                        Oio.Origin_Head_Id,
                                        Oio.Origin_Number,
                                        Oio.Origin_Line_Id
                                   From Cims.t_Pln_Order_Inv_Occupy Oio,
                                        Cims.t_Bd_Item              Bi,
                                        Cims.t_Inv_Inventories      Ii
                                  Where Bi.Item_Id = Oio.Item_Id
                                    And Ii.Inventory_Id = Oio.Inventory_Id
                                    And Oio.Entity_Id = p_Entity_Id
                                    And Oio.Origin_Type = r_Occupy.Origin_Type
                                    And Oio.Origin_Head_Id = r_Occupy.Origin_Head_Id
                                    And Oio.Origin_Line_Id = r_Occupy.Origin_Line_Id
                                    AND OIO.ORIGIN_TYPE not in ('提货订单预占用', '二次发运'))
                          Where Nvl(So_Order_Qty, 0) != Nvl(So_Soorder_Qty, 0) +
                                Nvl(Rrsf_Order_Qty, 0) + Nvl(Pmt_Collar_Send_Qty, 0)) Loop
        --add by lizhen 2015-08-13 推广物料发放领用数量
        v_Recalculation_Diff_Qty := Nvl(r_So_Order.So_Soorder_Qty, 0) +
                                    Nvl(r_So_Order.Rrsf_Order_Qty, 0) +
                                    Nvl(r_So_Order.Pmt_Collar_Send_Qty, 0) -
                                    Nvl(r_So_Order.So_Order_Qty, 0);
        If Nvl(v_Recalculation_Diff_Qty, 0) > 0 Then
          p_Soorder_Unoccupy_Stocks(p_Inventory_Id      => r_So_Order.Inventory_Id,
                                    p_Item_Id           => r_So_Order.Item_Id,
                                    p_Occupy_Qty        => Abs(v_Recalculation_Diff_Qty),
                                    p_Match_Pln_To_Wip  => 'A',
                                    p_Action_Desc       => '重算库存占用，销售出库数量大于库存占用销售出库数量',
                                    p_Entity_Id         => p_Entity_Id,
                                    p_Origin_Type       => r_So_Order.Origin_Type,
                                    p_Origin_Head_Id    => r_So_Order.Origin_Head_Id,
                                    p_Origin_Number     => r_So_Order.Origin_Number,
                                    p_Origin_Line_Id    => r_So_Order.Origin_Line_Id,
                                    p_Source_Order_Type => '重算库存占用',
                                    p_Source_Head_Id    => r_So_Order.Origin_Head_Id,
                                    p_Source_Number     => r_So_Order.Origin_Number,
                                    p_Source_Line_Id    => r_So_Order.Origin_Line_Id,
                                    p_User_Code         => 'p_Auto_Recalculation_Occupy',
                                    p_Allow_No_Occupy   => 'N',
                                    p_Result            => v_Err_Num,
                                    p_Err_Msg           => v_Value);
        Else
          p_Soorder_Occupy_Stocks(p_Inventory_Id      => r_So_Order.Inventory_Id,
                                  p_Item_Id           => r_So_Order.Item_Id,
                                  p_Occupy_Qty        => Abs(v_Recalculation_Diff_Qty),
                                  p_Match_Pln_To_Wip  => 'A',
                                  p_Action_Desc       => '重算库存占用，销售出库数量小于库存占用销售出库数量',
                                  p_Entity_Id         => p_Entity_Id,
                                  p_Origin_Type       => r_So_Order.Origin_Type,
                                  p_Origin_Head_Id    => r_So_Order.Origin_Head_Id,
                                  p_Origin_Number     => r_So_Order.Origin_Number,
                                  p_Origin_Line_Id    => r_So_Order.Origin_Line_Id,
                                  p_Source_Order_Type => '重算库存占用',
                                  p_Source_Head_Id    => r_So_Order.Origin_Head_Id,
                                  p_Source_Number     => r_So_Order.Origin_Number,
                                  p_Source_Line_Id    => r_So_Order.Origin_Line_Id,
                                  p_User_Code         => 'p_Auto_Recalculation_Occupy',
                                  p_Result            => v_Err_Num,
                                  p_Err_Msg           => v_Value);
        End If;
        If v_Value != v_Success Then
          Rollback;
          Pkg_Pln_Pub.p_Write_Job_Log('PLN',
                                      'Pkg_Pln_Inv_Occupy.p_Auto_Recalculation_Occupy',
                                      '重算库存占用，销售出库数量不等于库存占用销售出库数量。' || v_Nl ||
                                      v_Value,
                                      r_So_Order.Origin_Head_Id,
                                      r_So_Order.Origin_Line_Id,
                                      r_So_Order.Item_Id,
                                      r_So_Order.Inventory_Id,
                                      v_Recalculation_Diff_Qty);
          Commit;
        End If;
      End Loop;
      Commit;
    End Loop;

    --add by lizhen 2016-02-27 推广物料旧流程已停用，旧的锁定重算也停用
    /*
      --add by lizhen 2015/5/21 增加推广物料重算
      For r_Occupy In (Select Oio.*
                        From t_Pln_Order_Inv_Occupy Oio,
                             cims.t_pmt_collar_requis_head Loh,
                             cims.t_pmt_collar_requis_line l
                            -- t_Pln_Lg_Order_Head    Loh,
                            -- t_Pln_Order_Type       Pot
                       Where (Nvl(Oio.Stock_Affirm_Qty, 0) + Nvl(Oio.Supply_Qty, 0) -
                             Nvl(Oio.So_Order_Qty, 0) - Nvl(Oio.Sundry_Qty, 0)) <> 0
                         And Oio.Entity_Id = p_Entity_Id
                         And p_Pln_Wip_Ord_Match Not In ('Y', 'N')
                         And Oio.Origin_Head_Id = Loh.Collar_Requis_Head_Id
                         And Oio.Origin_Line_Id = l.collar_requis_line_id
                         and Loh.Status = '03'
                         And Oio.Origin_Type=(
                          select bt.bill_type_name
                           from t_inv_bill_types bt
                          where source_type_id =
                                (select source_type_id
                                   from t_inv_source_types
                                  where source_type_code = '1009'
                                    and entity_id = p_Entity_Id
                                 )
                            and bt.erp_trancation = '10'
                            and bt.entity_id =p_Entity_Id
                         )
                        -- And Loh.Order_Type_Id = l.
                         \*And Oio.Origin_Type Not In
                             ('订单与工单按规则匹配', '订单与工单完全匹配')*\
                             )Loop
      --计算库存评数量
      --库存评审数量 = 订单库评数量 + 调拨单接收数量（接收后占用库存评审数量）
      For r_Inv_Affirm In (Select *
                             From (Select Oio.Item_Id,
                                          Bi.Item_Code,
                                          Bi.Item_Name,
                                          Bi.Defaultunit,
                                          Oio.Inventory_Id,
                                          Ii.Inventory_Code,
                                          Ii.Inventory_Name,
                                          Nvl((Select l.Audit_Qty
                                                  From Cims.t_Pmt_Collar_Requis_Head h,
                                                       Cims.t_Pmt_Collar_Requis_Line l
                                                 Where h.Collar_Requis_Head_Id = l.Collar_Requis_Head_Id
                                                   And h.Entity_Id =oio.entity_id
                                                   And l.Collar_Requis_Line_Id = oio.Origin_Line_Id
                                                   And l.Collar_Requis_Head_Id =oio.Origin_Head_Id
                                                   AND h.status='03'
                                                   and l.pmt_id=bi.item_id
                                                   and ii.inventory_id=h.ship_inventory_id
                                                   ),0)
                                          Inv_Review_Qty,
                                          Oio.Stock_Affirm_Qty,
                                          Oio.Origin_Type,
                                          Oio.Origin_Head_Id,
                                          Oio.Origin_Number,
                                          Oio.Origin_Line_Id
                                     From Cims.t_Pln_Order_Inv_Occupy Oio,
                                          Cims.t_Bd_Item              Bi,
                                          Cims.t_Inv_Inventories      Ii
                                    Where Bi.Item_Id = Oio.Item_Id
                                      And Ii.Inventory_Id = Oio.Inventory_Id
                                      And Oio.Item_Id = r_Occupy.Item_Id
                                      And Oio.Inventory_Id = r_Occupy.Inventory_Id
                                      And Oio.Entity_Id = p_Entity_Id
                                      And Oio.Origin_Type = r_Occupy.Origin_Type
                                      AND oio.origin_head_id=r_occupy.origin_head_id
                                      AND oio.origin_line_id=r_occupy.origin_line_id)
                            Where Nvl(Inv_Review_Qty, 0) !=
                                  Nvl(Stock_Affirm_Qty, 0)) Loop
        v_Recalculation_Diff_Qty := Nvl(r_Inv_Affirm.Inv_Review_Qty, 0) -
                                    Nvl(r_Inv_Affirm.Stock_Affirm_Qty, 0);
        If v_Recalculation_Diff_Qty > 0 Then
          p_Affirm_Occupy_Stocks(p_Inventory_Id      => r_Inv_Affirm.Inventory_Id,
                                 p_Item_Id           => r_Inv_Affirm.Item_Id,
                                 p_Occupy_Qty        => Abs(v_Recalculation_Diff_Qty),
                                 p_Match_Pln_To_Wip  => 'A',
                                 p_Action_Desc       => '重算库存占用，库存评审数量大于库存占用库存评审数量',
                                 p_Entity_Id         => p_Entity_Id,
                                 p_Origin_Type       => r_Inv_Affirm.Origin_Type,
                                 p_Origin_Head_Id    => r_Inv_Affirm.Origin_Head_Id,
                                 p_Origin_Number     => r_Inv_Affirm.Origin_Number,
                                 p_Origin_Line_Id    => r_Inv_Affirm.Origin_Line_Id,
                                 p_Source_Order_Type => '重算库存占用',
                                 p_Source_Head_Id    => r_Inv_Affirm.Origin_Head_Id,
                                 p_Source_Number     => r_Inv_Affirm.Origin_Number,
                                 p_Source_Line_Id    => r_Inv_Affirm.Origin_Line_Id,
                                 p_User_Code         => 'p_Auto_Recalculation_Occupy',
                                 p_Result            => v_Err_Num,
                                 p_Err_Msg           => v_Value);
        Else
          p_Affirm_Unoccupy_Stocks(p_Inventory_Id      => r_Inv_Affirm.Inventory_Id,
                                   p_Item_Id           => r_Inv_Affirm.Item_Id,
                                   p_Occupy_Qty        => Abs(v_Recalculation_Diff_Qty),
                                   p_Match_Pln_To_Wip  => 'A',
                                   p_Action_Desc       => '重算库存占用，库存评审数量小于库存占用库存评审数量',
                                   p_Entity_Id         => p_Entity_Id,
                                   p_Origin_Type       => r_Inv_Affirm.Origin_Type,
                                   p_Origin_Head_Id    => r_Inv_Affirm.Origin_Head_Id,
                                   p_Origin_Number     => r_Inv_Affirm.Origin_Number,
                                   p_Origin_Line_Id    => r_Inv_Affirm.Origin_Line_Id,
                                   p_Source_Order_Type => '重算库存占用',
                                   p_Source_Head_Id    => r_Inv_Affirm.Origin_Head_Id,
                                   p_Source_Number     => r_Inv_Affirm.Origin_Number,
                                   p_Source_Line_Id    => r_Inv_Affirm.Origin_Line_Id,
                                   p_User_Code         => 'p_Auto_Recalculation_Occupy',
                                   p_Allow_No_Occupy   => 'N',
                                   p_Result            => v_Err_Num,
                                   p_Err_Msg           => v_Value);
        End If;
        If v_Value != v_Success Then
          Rollback;
          Pkg_Pln_Pub.p_Write_Job_Log('PLN',
                                      'Pkg_Pln_Inv_Occupy.p_Auto_Recalculation_Occupy',
                                      '重算库存占用，库存评审数量不等于库存占用库存评审数量。' || v_Nl ||
                                      v_Value,
                                      r_Inv_Affirm.Origin_Head_Id,
                                      r_Inv_Affirm.Origin_Line_Id,
                                      r_Inv_Affirm.Item_Id,
                                      r_Inv_Affirm.Inventory_Id,
                                      v_Recalculation_Diff_Qty);
          Commit;
        End If;
      End Loop;

      --销售单据
      For r_So_Order In (Select *
                           From (Select Oio.Item_Id,
                                        Bi.Item_Code,
                                        Bi.Item_Name,
                                        Bi.Defaultunit,
                                        Oio.Inventory_Id,
                                        Ii.Inventory_Code,
                                        Ii.Inventory_Name,
                                        Nvl((
                                            select sum(nvl(tpl.rcv_qty,0)) from
                                            t_pmt_collar_send_head tph,
                                            t_pmt_collar_send_line tpl
                                            where tph.pmt_order_num=Oio.Origin_Number
                                            and tph.collar_send_head_id=tpl.collar_send_head_id
                                            and tpl.pmt_id=oio.item_id
                                            and tph.entity_id=p_Entity_Id
                                            and tph.ship_inventory_id=oio.inventory_id
                                            ),
                                            0) So_Soorder_Qty,
                                        --调拨审核出库
                                        0 Rrsf_Order_Qty,
                                        Oio.So_Order_Qty,
                                        Oio.Origin_Type,
                                        Oio.Origin_Head_Id,
                                        Oio.Origin_Number,
                                        Oio.Origin_Line_Id
                                   From Cims.t_Pln_Order_Inv_Occupy Oio,
                                        Cims.t_Bd_Item              Bi,
                                        Cims.t_Inv_Inventories      Ii
                                  Where Bi.Item_Id = Oio.Item_Id
                                    And Ii.Inventory_Id = Oio.Inventory_Id
                                    And Oio.Entity_Id = p_Entity_Id
                                    And Oio.Origin_Type = r_Occupy.Origin_Type
                                    And Oio.Origin_Head_Id = r_Occupy.Origin_Head_Id
                                    And Oio.Origin_Line_Id = r_Occupy.Origin_Line_Id)
                          Where Nvl(So_Order_Qty, 0) != Nvl(So_Soorder_Qty, 0) +
                                Nvl(Rrsf_Order_Qty, 0)) Loop
        v_Recalculation_Diff_Qty := Nvl(r_So_Order.So_Soorder_Qty, 0) +
                                    Nvl(r_So_Order.Rrsf_Order_Qty, 0) -
                                    Nvl(r_So_Order.So_Order_Qty, 0);
        If Nvl(v_Recalculation_Diff_Qty, 0) > 0 Then
          p_Soorder_Unoccupy_Stocks(p_Inventory_Id      => r_So_Order.Inventory_Id,
                                    p_Item_Id           => r_So_Order.Item_Id,
                                    p_Occupy_Qty        => Abs(v_Recalculation_Diff_Qty),
                                    p_Match_Pln_To_Wip  => 'A',
                                    p_Action_Desc       => '重算库存占用，销售出库数量大于库存占用销售出库数量',
                                    p_Entity_Id         => p_Entity_Id,
                                    p_Origin_Type       => r_So_Order.Origin_Type,
                                    p_Origin_Head_Id    => r_So_Order.Origin_Head_Id,
                                    p_Origin_Number     => r_So_Order.Origin_Number,
                                    p_Origin_Line_Id    => r_So_Order.Origin_Line_Id,
                                    p_Source_Order_Type => '重算库存占用',
                                    p_Source_Head_Id    => r_So_Order.Origin_Head_Id,
                                    p_Source_Number     => r_So_Order.Origin_Number,
                                    p_Source_Line_Id    => r_So_Order.Origin_Line_Id,
                                    p_User_Code         => 'p_Auto_Recalculation_Occupy',
                                    p_Allow_No_Occupy   => 'N',
                                    p_Result            => v_Err_Num,
                                    p_Err_Msg           => v_Value);
        Else
          p_Soorder_Occupy_Stocks(p_Inventory_Id      => r_So_Order.Inventory_Id,
                                  p_Item_Id           => r_So_Order.Item_Id,
                                  p_Occupy_Qty        => Abs(v_Recalculation_Diff_Qty),
                                  p_Match_Pln_To_Wip  => 'A',
                                  p_Action_Desc       => '重算库存占用，销售出库数量小于库存占用销售出库数量',
                                  p_Entity_Id         => p_Entity_Id,
                                  p_Origin_Type       => r_So_Order.Origin_Type,
                                  p_Origin_Head_Id    => r_So_Order.Origin_Head_Id,
                                  p_Origin_Number     => r_So_Order.Origin_Number,
                                  p_Origin_Line_Id    => r_So_Order.Origin_Line_Id,
                                  p_Source_Order_Type => '重算库存占用',
                                  p_Source_Head_Id    => r_So_Order.Origin_Head_Id,
                                  p_Source_Number     => r_So_Order.Origin_Number,
                                  p_Source_Line_Id    => r_So_Order.Origin_Line_Id,
                                  p_User_Code         => 'p_Auto_Recalculation_Occupy',
                                  p_Result            => v_Err_Num,
                                  p_Err_Msg           => v_Value);
        End If;
        If v_Value != v_Success Then
          Rollback;
          Pkg_Pln_Pub.p_Write_Job_Log('PLN',
                                      'Pkg_Pln_Inv_Occupy.p_Auto_Recalculation_Occupy',
                                      '重算库存占用，销售出库数量不等于库存占用销售出库数量。' || v_Nl ||
                                      v_Value,
                                      r_So_Order.Origin_Head_Id,
                                      r_So_Order.Origin_Line_Id,
                                      r_So_Order.Item_Id,
                                      r_So_Order.Inventory_Id,
                                      v_Recalculation_Diff_Qty);
          Commit;
        End If;
      End Loop;
      Commit;
    End Loop;
    */
    End If;
    Commit;
  Exception
    When Others Then
      Null;
  End;
End Pkg_Pln_Inv_Occupy;
/

