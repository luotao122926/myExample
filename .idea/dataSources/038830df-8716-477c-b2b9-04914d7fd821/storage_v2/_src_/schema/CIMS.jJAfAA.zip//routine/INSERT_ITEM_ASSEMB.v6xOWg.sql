create PROCEDURE insert_item_assemb  (
   P_MAIN_CODE    t_bd_item.item_code%type  --套件编码
   )
 IS

   rowid number;
   ln_cnt number;
   ln_assembly_id number;
   ls_sub_code   varchar(100);
   ln_qty  number;

   cursor itemCur is
     select m.*
      from t_bd_item m where m.item_code = P_MAIN_CODE ;

   item_main itemCur%ROWTYPE;
   item_sub itemCur%ROWTYPE;

  BEGIN

  --1、读取配套关系接口表 LOOP循环
   OPEN itemCur;
    LOOP
      FETCH itemCur
        INTO item_main;
      EXIT WHEN itemCur%NOTFOUND;
      --2、判断头表中是否存在，如果不存在则插入至配套头表
      select count(1) into ln_cnt from t_bd_item_assemblies sm where sm.item_code = item_main.item_code ;
      if (ln_cnt=0) then
        select seq_bd_row_id.nextval into ln_assembly_id from dual;
        insert into t_bd_item_assemblies
          (item_assembly_id, item_id, item_code, item_name, priority,
            begin_date, end_date, created_by, creation_date, last_updated_by, last_update_date,
            entity_id, active_flag)
        values
          (ln_assembly_id, item_main.item_id, item_main.item_code , item_main.item_name, ln_assembly_id*10,
           to_date('2015-01-01','yyyy-mm-dd'), null, 'admin', sysdate, 'admin', sysdate,
            10, 'Y');
      --3.1、插入配套明细表
        FOR CUR_SUB IN (select distinct ss.item_code,ss.qty
                              from intf_bd_item_assemblies ss
                             where ss.parent_item_code = item_main.item_code and ss.change_type = 'ADDED'
                             ) LOOP
            ls_sub_code := CUR_SUB.ITEM_CODE;
            ln_qty := CUR_SUB.qty;
            select * into item_sub from t_bd_item where item_code = ls_sub_code;
            --if (v_cnt = 0) then
            --  continue;
            --end if;
            insert into t_bd_item_assemblies_sub
              (item_subassembly_id, item_assembly_id, item_id, item_code, item_name,
              quantity, value_scale, fittings_flag, begin_date, end_date,
              created_by, creation_date, last_updated_by, last_update_date,
               entity_id, can_export_erp, item_uom, active_flag)
            values
              (seq_bd_row_id.nextval, ln_assembly_id, item_sub.item_id, ls_sub_code, item_sub.item_name,
              ln_qty, decode(item_sub.productform,'INDOOR_PRODUCT',60,'OUTDOOR_PRODUCT',40,null) , decode(item_sub.productform,'INDOOR_PRODUCT','N','OUTDOOR_PRODUCT','N','Y'),  to_date('2015-01-01','yyyy-mm-dd'), null,
              'admin', sysdate, 'admin', sysdate,
              10, 'Y', item_sub.defaultunit, 'Y');

        END LOOP;


      else
       --3.2、如果存在套件头，插入配套明细表
        select sm.item_assembly_id into ln_assembly_id from t_bd_item_assemblies sm where sm.item_code = item_main.item_code ;
        FOR CUR_SUB IN (select distinct ss.item_code,ss.qty
                              from intf_bd_item_assemblies ss
                             where ss.parent_item_code = item_main.item_code and ss.change_type = 'ADDED'
                             ) LOOP
            ls_sub_code := CUR_SUB.ITEM_CODE;
            ln_qty := CUR_SUB.qty;
            select * into item_sub from t_bd_item where item_code = ls_sub_code;
            select count(1) into ln_cnt from t_bd_item_assemblies_sub sb where sb.item_assembly_id=ln_assembly_id and sb.item_code=ls_sub_code;
            if (ln_cnt > 0) then
              continue;
            end if;
            insert into t_bd_item_assemblies_sub
              (item_subassembly_id, item_assembly_id, item_id, item_code, item_name,
              quantity, value_scale, fittings_flag, begin_date, end_date,
              created_by, creation_date, last_updated_by, last_update_date,
               entity_id, can_export_erp, item_uom, active_flag)
            values
              (seq_bd_row_id.nextval, ln_assembly_id, item_sub.item_id, ls_sub_code, item_sub.item_name,
              ln_qty, decode(item_sub.productform,'INDOOR_PRODUCT',60,'OUTDOOR_PRODUCT',40,null) , decode(item_sub.productform,'INDOOR_PRODUCT','N','OUTDOOR_PRODUCT','N','Y'),  to_date('2015-01-01','yyyy-mm-dd'), null,
              'admin', sysdate, 'admin', sysdate,
              10, 'Y', item_sub.defaultunit, 'Y');

        END LOOP;
      end if;

    END LOOP;
    CLOSE itemCur;

    commit;
  END;

/

