create package      PKG_PLN_SC_INV_DETAIL is

  PROCEDURE P_GET_SC_INV_DETAIL(P_DATE      IN DATE,
                                P_ENTITY_ID IN NUMBER);

end PKG_PLN_SC_INV_DETAIL;
/

