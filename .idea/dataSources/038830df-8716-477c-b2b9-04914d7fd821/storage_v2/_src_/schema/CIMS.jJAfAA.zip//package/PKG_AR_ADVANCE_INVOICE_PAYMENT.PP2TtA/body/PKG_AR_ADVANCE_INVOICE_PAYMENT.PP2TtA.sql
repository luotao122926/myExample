create PACKAGE BODY PKG_AR_ADVANCE_INVOICE_PAYMENT IS

  /*
  * 生成甲方客户提前开票汇总报表
  * 说明：
  *    1、查询提前开票台账信息表，获取数据
  *    2、根据主体、OU、客户编码、客户名称、营销中心，分别自动计算开票金额、到款金额、3个月内开票金额、3个月以上开票金额、3个月以内开票未回款、3个月以上开票未回款
  *    3、提前开票台账信息表        T_AR_ADVANCE_BILLING_INFO
  *    4、超三个月提前开票未回款信息表   T_AR_NO_INVOICE_PAYMENT_INFO
  *    5、提前开票台账信息状态：00-未确认；01-已确认；02-已执行；码表SELECT * FROM CIMS.UP_CODELIST U WHERE U.CODETYPE = 'LG_BILLS_STATUS';
  */
  PROCEDURE P_THREE_MON_INVOICE_PAY_REPORT(P_MESSAGE OUT VARCHAR2) IS
    V_COUNT                        NUMBER; --记录数
    V_THREE_NO_TRX_PAY_AMOUNT      NUMBER; --三个月以内开票未回款
    V_OVER_THREE_NO_TRX_PAY_AMOUNT NUMBER; --三个月以上开票未回款
    V_NO_INVOICE_PAY_INFO_ID       NUMBER; --提前开票汇总报表主键ID序列
    V_OVER_THREE_NO_PAY_FLAG       VARCHAR2(2); --超三个月开票未回款标志（Y/N）
    V_CUSTOMER_CODE                V_CUSTOMER_ACCOUNT_SALECENTER.CUSTOMER_CODE%TYPE; --客户编码
    V_CUSTOMER_NAME                V_CUSTOMER_ACCOUNT_SALECENTER.CUSTOMER_NAME%TYPE; --客户名称
    V_SALES_CENTER_CODE            V_CUSTOMER_ACCOUNT_SALECENTER.SALES_CENTER_CODE%TYPE; --营销中心编码
    V_SALES_CENTER_NAME            V_CUSTOMER_ACCOUNT_SALECENTER.SALES_CENTER_NAME%TYPE; --营销中心名称
    V_ERP_OU_NAME                  UP_CODELIST.CODE_VALUE%TYPE; --经营组织名称
    V_ENTITY_NAME                  V_BD_ENTITY.ENTITY_NAME%TYPE; --主体名称
    V_ACCOUNT_CODE                 V_CUSTOMER_ACCOUNT_SALECENTER.ACCOUNT_CODE%TYPE; --账户编码
    --提前开票台账信息
    CURSOR C_BILLING_INFO IS
      SELECT T.ENTITY_ID,
             T.ERP_OU_ID,
             T.CUSTOMER_ID,
             T.SALES_CENTER_ID,
             T.ACCOUNT_ID,
             --累计到款金额
             NVL(SUM(FUNDS_AMOUNT), 0) FUNDS_AMOUNT,
             --累计开票金额
             NVL(SUM(TRX_AMOUNT), 0) TRX_AMOUNT,
             --累计开票未回款
             NVL((SUM(TRX_AMOUNT) - SUM(FUNDS_AMOUNT)), 0) NO_INVOICE_PAYMENT_AMOUNT,
             --3个月内开票金额
             NVL(SUM(THREE_MONTHS_TRX_AMOUNT), 0) THREE_MONTHS_TRX_AMOUNT,
             --3个月以上开票金额
             NVL(SUM(OVER_THREE_MONTHS_TRX_AMOUNT), 0) OVER_THREE_MONTHS_TRX_AMOUNT
        FROM (
              --开票金额
              SELECT I.ENTITY_ID,
                      I.ERP_OU_ID,
                      I.CUSTOMER_ID,
                      I.SALES_CENTER_ID,
                      I.ACCOUNT_ID,
                      0 FUNDS_AMOUNT,
                      -- 累计开票金额（税价合计）
                      SUM(I.TAX_TRX_ACCOUNT) TRX_AMOUNT,
                      0 THREE_MONTHS_TRX_AMOUNT,
                      0 OVER_THREE_MONTHS_TRX_AMOUNT
                FROM CIMS.T_AR_ADVANCE_BILLING_INFO I
               WHERE I.STATUS = '00'
                 AND NVL(I.IS_GENERATE_REPORT, 'N') = 'N'
                 AND I.TRX_DATE <= TRUNC(LAST_DAY(ADD_MONTHS(SYSDATE, -1)))
               GROUP BY I.ENTITY_ID,
                         I.ERP_OU_ID,
                         I.CUSTOMER_ID,
                         I.SALES_CENTER_ID,
                         I.ACCOUNT_ID
              UNION ALL
              --到款金额
              SELECT I.ENTITY_ID,
                      I.ERP_OU_ID,
                      I.CUSTOMER_ID,
                      I.SALES_CENTER_ID,
                      I.ACCOUNT_ID,
                      --累计到款金额（3-已确认/非冲销，5-已审核，6-已汇）
                      SUM(H.AMOUNT) FUNDS_AMOUNT,
                      0 TRX_AMOUNT,
                      0 THREE_MONTHS_TRX_AMOUNT,
                      0 OVER_THREE_MONTHS_TRX_AMOUNT
                FROM CIMS.T_AR_ADVANCE_BILLING_INFO I,
                      CIMS.T_AR_CASH_RECEIPT_HEADERS H
               WHERE I.STATUS = '00'
                 AND NVL(I.IS_GENERATE_REPORT, 'N') = 'N'
                 AND I.TRX_DATE <= TRUNC(LAST_DAY(ADD_MONTHS(SYSDATE, -1)))
                 AND I.ENTITY_ID = H.ENTITY_ID
                 AND I.CUSTOMER_ID = H.CUSTOMER_ID
                 AND I.SALES_CENTER_ID = H.SALES_CENTER_ID
                 AND I.ACCOUNT_ID = H.ACCOUNT_ID
                 AND H.RECEIPT_STATUS_ID IN (3, 5, 6)
                 AND H.WRITEOFF_RECEIPT_CODE IS NULL
               GROUP BY I.ENTITY_ID,
                         I.ERP_OU_ID,
                         I.CUSTOMER_ID,
                         I.SALES_CENTER_ID,
                         I.ACCOUNT_ID
              UNION ALL
              --3个月内开票金额
              SELECT I.ENTITY_ID,
                      I.ERP_OU_ID,
                      I.CUSTOMER_ID,
                      I.SALES_CENTER_ID,
                      I.ACCOUNT_ID,
                      0                 FUNDS_AMOUNT,
                      0                 TRX_AMOUNT,
                      -- 累计开票金额（税价合计）
                      SUM(I.TAX_TRX_ACCOUNT) THREE_MONTHS_TRX_AMOUNT,
                      0 OVER_THREE_MONTHS_TRX_AMOUNT
                FROM CIMS.T_AR_ADVANCE_BILLING_INFO I
               WHERE I.STATUS = '00'
                 AND NVL(I.IS_GENERATE_REPORT, 'N') = 'N'
                 AND I.TRX_DATE <= TRUNC(LAST_DAY(ADD_MONTHS(SYSDATE, -1)))
                 AND I.TRX_DATE > TRUNC(LAST_DAY(ADD_MONTHS(SYSDATE, -4)))
               GROUP BY I.ENTITY_ID,
                         I.ERP_OU_ID,
                         I.CUSTOMER_ID,
                         I.SALES_CENTER_ID,
                         I.ACCOUNT_ID
              UNION ALL
              --3个月以上开票金额
              SELECT I.ENTITY_ID,
                      I.ERP_OU_ID,
                      I.CUSTOMER_ID,
                      I.SALES_CENTER_ID,
                      I.ACCOUNT_ID,
                      0                 FUNDS_AMOUNT,
                      0                 TRX_AMOUNT,
                      0                 THREE_MONTHS_TRX_AMOUNT,
                      -- 累计开票金额（税价合计）
                      SUM(I.TAX_TRX_ACCOUNT) OVER_THREE_MONTHS_TRX_AMOUNT
                FROM CIMS.T_AR_ADVANCE_BILLING_INFO I
               WHERE I.STATUS = '00'
                 AND NVL(I.IS_GENERATE_REPORT, 'N') = 'N'
                 AND I.TRX_DATE <= TRUNC(LAST_DAY(ADD_MONTHS(SYSDATE, -4)))
               GROUP BY I.ENTITY_ID,
                         I.ERP_OU_ID,
                         I.CUSTOMER_ID,
                         I.SALES_CENTER_ID,
                         I.ACCOUNT_ID) T
       GROUP BY T.ENTITY_ID,
                T.ERP_OU_ID,
                T.CUSTOMER_ID,
                T.SALES_CENTER_ID,
                T.ACCOUNT_ID;

    INFO_ROW C_BILLING_INFO%ROWTYPE;

  BEGIN
    V_COUNT   := 0;
    P_MESSAGE := 'SUCCESS';
    FOR INFO_ROW IN C_BILLING_INFO LOOP
      V_COUNT := V_COUNT + 1;
      --3个月以内开票未回款：如果累计开票未回款＜=0，系统取值0；如果累计开票未回款＞0，系统取累计开票未回款和3个月内开票金额最小值
      --3个月以上开票未回款：如果累计开票未回款＜=0，系统取值0；如果累计开票未回款＞0，系统取值累计开票未回款—3个月以内开票未回款
      IF INFO_ROW.NO_INVOICE_PAYMENT_AMOUNT <= 0 THEN
        --三个月以内开票未回款
        V_THREE_NO_TRX_PAY_AMOUNT := 0;
        --三个月以上开票未回款
        V_OVER_THREE_NO_TRX_PAY_AMOUNT := 0;
      ELSE
        V_THREE_NO_TRX_PAY_AMOUNT      := LEAST(INFO_ROW.NO_INVOICE_PAYMENT_AMOUNT,
                                                INFO_ROW.THREE_MONTHS_TRX_AMOUNT);
        V_OVER_THREE_NO_TRX_PAY_AMOUNT := INFO_ROW.NO_INVOICE_PAYMENT_AMOUNT -
                                          V_THREE_NO_TRX_PAY_AMOUNT;
      END IF;
      --超三个月开票未回款标志
      IF V_OVER_THREE_NO_TRX_PAY_AMOUNT > 0 THEN
        V_OVER_THREE_NO_PAY_FLAG := 'Y';
      ELSE
        V_OVER_THREE_NO_PAY_FLAG := 'N';
      END IF;

      --校验主体、OU是否对应
      P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_ENTITY_OU(INFO_ROW.ENTITY_ID,
                                                      INFO_ROW.ERP_OU_ID);
      IF P_MESSAGE = 'SUCCESS' THEN
        --获取客户、中心
        BEGIN
          SELECT V.CUSTOMER_CODE,
                 V.CUSTOMER_NAME,
                 V.SALES_CENTER_CODE,
                 V.SALES_CENTER_NAME,
                 V.ACCOUNT_CODE
            INTO V_CUSTOMER_CODE,
                 V_CUSTOMER_NAME,
                 V_SALES_CENTER_CODE,
                 V_SALES_CENTER_NAME,
                 V_ACCOUNT_CODE
            FROM CIMS.V_CUSTOMER_ACCOUNT_SALECENTER V
           WHERE V.ENTITY_ID = INFO_ROW.ENTITY_ID
             AND V.CUSTOMER_ID = INFO_ROW.CUSTOMER_ID
             AND V.SALES_CENTER_ID = INFO_ROW.SALES_CENTER_ID
             AND V.ACCOUNT_ID = INFO_ROW.ACCOUNT_ID;
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := '根据主体（' || INFO_ROW.ENTITY_ID || '）、客户ID（' ||
                         INFO_ROW.CUSTOMER_ID || '）、中心ID（' ||
                         INFO_ROW.SALES_CENTER_ID || '）、账户ID（' ||
                         INFO_ROW.ACCOUNT_ID ||
                         '），获取客户编码/客户名称/中心编码/中心名称/账户编码异常，请联系管理员！';
        END;
      END IF;

      IF P_MESSAGE = 'SUCCESS' THEN
        --校验主体、客户、中心、账户是否对应，且有效
        P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_CUST_CENTER_ACC(INFO_ROW.ENTITY_ID,
                                                              V_CUSTOMER_CODE,
                                                              V_SALES_CENTER_CODE,
                                                              V_ACCOUNT_CODE);
      END IF;

      IF P_MESSAGE = 'SUCCESS' THEN
        --2016-02-24 tianmzh修改，校验客户是否为提前开票客户（应收发票配置中，是否提前开票Y/N）
        P_MESSAGE := PKG_AR_COMMON.F_VALIDATE_IS_ADVANCE_CUSTOMER(INFO_ROW.ENTITY_ID,
                                                                  INFO_ROW.CUSTOMER_ID,
                                                                  INFO_ROW.SALES_CENTER_ID);
      END IF;

      IF P_MESSAGE = 'SUCCESS' THEN
        --获取OU名称
        BEGIN
          SELECT U.CODE_NAME
            INTO V_ERP_OU_NAME
            FROM CIMS.UP_CODELIST U
           WHERE U.CODETYPE = 'ar_ou_id'
             AND U.CODE_VALUE = INFO_ROW.ERP_OU_ID;
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := '获取OU名称为空，请联系管理员！';
        END;
      END IF;
      IF P_MESSAGE = 'SUCCESS' THEN
        --获取主体名称
        BEGIN
          SELECT E.ENTITY_NAME
            INTO V_ENTITY_NAME
            FROM CIMS.V_BD_ENTITY E
           WHERE E.entity_id = INFO_ROW.ENTITY_ID;
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := '获取主体名称为空，请联系管理员！';
        END;
      END IF;

      IF P_MESSAGE = 'SUCCESS' THEN
        --获取主键序列
        BEGIN
          SELECT S_AR_NO_INVOICE_PAYMENT_INFO.NEXTVAL
            INTO V_NO_INVOICE_PAY_INFO_ID
            FROM DUAL;
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := '获取提前开票未回款台账信息汇总表主键序列异常，请联系管理员！';
        END;
      END IF;

      IF P_MESSAGE = 'SUCCESS' THEN
        --生成提前开票报表数据
        BEGIN
          INSERT INTO T_AR_NO_INVOICE_PAYMENT_INFO
            (NO_INVOICE_PAY_INFO_ID,
             FIRST_CUSTOMER_INFO_ID,
             FREE_CHECK_CUSTOMER_ID,
             ENTITY_ID,
             ENTITY_NAME,
             CUSTOMER_ID,
             ACCOUNT_ID,
             ACCOUNT_CODE,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             STATUS,
             SALES_CENTER_ID,
             SALES_CENTER_CODE,
             SALES_CENTER_NAME,
             ERP_OU_ID,
             ERP_OU_NAME,
             TRX_AMOUNT,
             FUNDS_AMOUNT,
             NO_INVOICE_PAYMENT_AMOUNT,
             THREE_MONTHS_TRX_AMOUNT,
             OVER_THREE_MONTHS_TRX_AMOUNT,
             THREE_NO_TRX_PAY_AMOUNT,
             OVER_THREE_NO_TRX_PAY_AMOUNT,
             FUNDS_FREE_CHECK_AMOUNT,
             REBATE_FREE_CHECK_AMOUNT,
             TOTAL_DEDUCTIONS_AMOUNT,
             LAST_TOTAL_DEDUCTIONS_AMOUNT,
             THIS_PRIOR_DEDUCTIONS,
             THIS_MONTH_DEDUCT_REBATE,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             OVER_THREE_NO_PAY_FLAG,
             VERSION_NUM)
          VALUES
            (
             --超三个月提前开票未回款信息ID
             V_NO_INVOICE_PAY_INFO_ID,
             --甲方客户提前开票汇总表ID
             NULL,
             --免考核客户信息ID
             NULL,
             --主体ID
             INFO_ROW.ENTITY_ID,
             --主体名称
             V_ENTITY_NAME,
             --客户ID
             INFO_ROW.CUSTOMER_ID,
             --账户ID
             INFO_ROW.ACCOUNT_ID,
             --账户编码
             V_ACCOUNT_CODE,
             --客户编码
             V_CUSTOMER_CODE,
             --客户名称
             V_CUSTOMER_NAME,
             --状态（默认未确认）
             '00',
             --营销中心ID
             INFO_ROW.SALES_CENTER_ID,
             --营销中心编码
             V_SALES_CENTER_CODE,
             --营销中心
             V_SALES_CENTER_NAME,
             --经营单位ID
             INFO_ROW.ERP_OU_ID,
             --经营单位名称
             V_ERP_OU_NAME,
             --发票金额
             INFO_ROW.TRX_AMOUNT,
             --到款金额
             INFO_ROW.FUNDS_AMOUNT,
             --开票未回款
             INFO_ROW.NO_INVOICE_PAYMENT_AMOUNT,
             --3个月内开票金额
             INFO_ROW.THREE_MONTHS_TRX_AMOUNT,
             --3个月以上开票金额
             INFO_ROW.OVER_THREE_MONTHS_TRX_AMOUNT,
             --3个月以内开票未回款
             V_THREE_NO_TRX_PAY_AMOUNT,
             --3个月以上开票未回款
             V_OVER_THREE_NO_TRX_PAY_AMOUNT,
             --有效计到款担保免考核金额
             NULL,
             --有效计扣返利免考核金额
             NULL,
             --累计应暂扣到款
             NULL,
             --至上期累计扣款
             NULL,
             --本期扣款
             NULL,
             --本月应扣返利
             NULL,
             --创建人
             'system',
             --创建日期
             SYSDATE,
             --最后修改人
             'system',
             --最后修改日期
             SYSDATE,
             --超三个月开票未回款标志（Y/N）
             V_OVER_THREE_NO_PAY_FLAG,
             0);
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := '插入提前开票信息汇总表异常，请联系管理员！';
            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_BOND.F_VALIDATE_RECEIPT_SOLUPAY',
                                                SQLCODE,
                                                P_MESSAGE ||
                                                SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,
                                                       1,
                                                       100) || SQLERRM);
        END;
        --根据主体、OU、客户、中心、账户、日期返查台账信息表，同时更新表中汇总报表ID、是否生成报表、错误信息字段
        BEGIN
          UPDATE CIMS.T_AR_ADVANCE_BILLING_INFO T
             SET T.IS_GENERATE_REPORT     = 'Y',
                 T.NO_INVOICE_PAY_INFO_ID = V_NO_INVOICE_PAY_INFO_ID,
                 T.ERROR_INFO             = P_MESSAGE,
                 T.VERSION_NUM            = NVL(T.VERSION_NUM,0) + 1
           WHERE T.ENTITY_ID = INFO_ROW.ENTITY_ID
             AND T.ERP_OU_ID = INFO_ROW.ERP_OU_ID
             AND T.CUSTOMER_ID = INFO_ROW.CUSTOMER_ID
             AND T.SALES_CENTER_ID = INFO_ROW.SALES_CENTER_ID
             AND T.ACCOUNT_ID = INFO_ROW.ACCOUNT_ID
             AND T.TRX_DATE <= TRUNC(LAST_DAY(ADD_MONTHS(SYSDATE, -1)))
             AND NVL(T.IS_GENERATE_REPORT, 'N') <> 'Y';
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := '更新提前开票台账信息表异常，请联系管理员！';
            RAISE V_BIZ_EXCEPTION;
        END;
      ELSE
        --根据主体、OU、客户、中心、账户、日期返查台账信息表，同时更新表中汇总报表ID、是否生成报表、错误信息字段
        P_MESSAGE := to_char(sysdate,'yyyy-mm-dd HH24:MI:SS') || P_MESSAGE;
        BEGIN
          UPDATE CIMS.T_AR_ADVANCE_BILLING_INFO T
             SET T.IS_GENERATE_REPORT     = 'N',
                 T.NO_INVOICE_PAY_INFO_ID = V_NO_INVOICE_PAY_INFO_ID,
                 T.ERROR_INFO             = SUBSTR(P_MESSAGE,0,500),
                 T.VERSION_NUM            = NVL(T.VERSION_NUM,0) + 1
           WHERE T.ENTITY_ID = INFO_ROW.ENTITY_ID
             AND NVL(T.ERP_OU_ID,0) = NVL(INFO_ROW.ERP_OU_ID,0)
             AND T.CUSTOMER_ID = INFO_ROW.CUSTOMER_ID
             AND T.SALES_CENTER_ID = INFO_ROW.SALES_CENTER_ID
             AND NVL(T.ACCOUNT_ID,0) = NVL(INFO_ROW.ACCOUNT_ID,0)
             AND T.TRX_DATE <= TRUNC(LAST_DAY(ADD_MONTHS(SYSDATE, -1)))
             AND NVL(T.IS_GENERATE_REPORT, 'N') <> 'Y';
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := '更新提前开票台账信息表异常，请联系管理员！';
            RAISE V_BIZ_EXCEPTION;
        END;
      END IF;

    END LOOP;

    --提交事物
    COMMIT;

    IF V_COUNT < 1 THEN
      P_MESSAGE := '获取提前开票台账信息表数据为空，请联系管理员！';
      RAISE V_BIZ_EXCEPTION;
    END IF;
  EXCEPTION
    WHEN V_BIZ_EXCEPTION THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ADVANCE_INVOICE_PAYMENT.P_THREE_MON_INVOICE_PAY_REPORT',
                                          SQLCODE,
                                          P_MESSAGE ||
                                          SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,
                                                 1,
                                                 100) || SQLERRM);
    WHEN OTHERS THEN
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_ADVANCE_INVOICE_PAYMENT.P_THREE_MON_INVOICE_PAY_REPORT',
                                          SQLCODE,
                                          P_MESSAGE ||
                                          SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,
                                                 1,
                                                 100) || SQLERRM);
  END;
END PKG_AR_ADVANCE_INVOICE_PAYMENT;
/

