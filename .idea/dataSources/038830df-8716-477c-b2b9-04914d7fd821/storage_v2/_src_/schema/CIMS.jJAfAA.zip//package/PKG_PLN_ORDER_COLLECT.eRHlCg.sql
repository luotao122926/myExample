create Package Pkg_Pln_Order_Collect Is

  -- Author  : NICRO.LI
  -- Created : 2014-09-04 10:05:42
  -- Purpose : 订单汇总功能

  -----------------------------------------------------------------------------
  ---- AUTHOR  : 李振
  -- CREATED : 2014-07-16 11:05:52
  -- PURPOSE : 执行订单操作
  -----------------------------------------------------------------------------
  Procedure p_Execute_Order_Operate(p_Collect_Head_Id  In Number, ----订单ID
                                    p_Operation_Action In Varchar2, --当前单据动作
                                    p_Next_State       In Varchar2, --下一状态值
                                    p_User_Code        In Varchar2, ----用户ID
                                    p_Result           In Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                                    );

  -----------------------------------------------------------------------------
  ---- AUTHOR  : 吴泽军
  -- CREATED : 2014-08-07 11:05:52
  -- PURPOSE : 汇总总部确认
  -----------------------------------------------------------------------------
  Procedure p_Hq_Confirm_Order(p_Collect_Head_Id  In Number, ----订单ID
                              p_Operation_Action In Varchar2, --当前单据动作
                              p_User_Code        In Varchar2, ----用户ID
                              p_Result           Out Varchar2 --返回结果：成功返回"SUCCESS"，失败返回原因
                              );

  -----------------------------------------------------------------------------
  --AUTHOR :张楚材
  --create :2014-10-18
  -- 模具产能占用
  -----------------------------------------------------------------------------
  Procedure p_Occupy_Mode_Productivity(p_Order_Type_Id In Number, --订单类型Id
                                       p_Period_Id     In Number, -- 周期Id
                                       p_user_Code     varchar2,---操作用户
                                       p_Entity_Id     In Number --主体Id
                                       );
  -----------------------------------------------------------------------------
  --AUTHOR :张楚材
  --create :2014-10-18
  -- 总装产能占用
  -----------------------------------------------------------------------------
  Procedure p_Occupy_Total_Productivity(p_Order_Type_Id In Number, --订单类型Id
                                        p_Period_Id     In Number, -- 周期Id
                                        p_user_code     varchar2,   --操作用户
                                        p_Entity_Id     In Number --主体Id
                                        );
  -----------------------------------------------------------------------------
  --AUTHOR :张楚材
  --create :2014-10-18
  -- 退回汇总订单头
  -----------------------------------------------------------------------------
  Procedure p_return_order_collect(p_Order_Type_Id In Number, --订单类型Id
                                        p_Period_Id     In Number, -- 周期Id
                                        p_batch_id      In number,--批次
                                        p_main_type     varchar2,-- 营销大类
                                        p_sub_type      varchar2,--营销小类
                                        p_main_type_sys varchar2,--营销大类参数
                                        p_sub_type_sys  varchar2,--营销小类参数
                                        p_user_code     varchar2,   --操作用户
                                        p_Entity_Id     In Number --主体Id
                                        );
 -----------------------------------------------------------------------------
  --AUTHOR :张楚材
  --create :2015-01-07
  -- 订单汇总
  Procedure p_order_colldet(
                            p_order_type_id In number,--订单类型Id
                            p_period_id in number,    --周期Id
                            p_batch_id in number,--批次
                            p_sales_main_type in varchar2, -- 营销大类
                            p_sales_sub_type  in varchar2,--营销小类
                            p_user_code  in varchar2,--操作用户
                            p_entity_id in number, --主体Id
                            p_form_state in varchar2, -- 汇总订单状态
                            p_result    out varchar2 -- 返回结果
    );
  -----------------------------------------------------------------------------
  --AUTHOR :张楚材
  --create :2015-01-07
  -- 汇总订单库存评审更新show 表
  Procedure p_up_inv_collect_show(
                            p_order_collect_head_id in number,--汇总订单头id
                            p_order_collect_show_id in number,--show Id
                            p_item_id               in number,-- 产品Id
                            p_entity_id in number, --主体Id
                            p_user_code  in varchar2,--操作用户
                            p_result    out varchar2 -- 返回结果
    );
 -----------------------------------------------------------------------------
  --AUTHOR :张楚材
  --create :2015-01-07
  -- 汇总订单总装产能更新show 表
  Procedure p_up_total_collect_show(
                            p_order_collect_head_id in number,--汇总订单头id
                            p_order_collect_show_id in number,--show Id
                            p_item_id               in number,-- 产品Id
                            p_entity_id in number, --主体Id
                            p_user_code  in varchar2,--操作用户
                            p_result    out varchar2 -- 返回结果
    );
  -----------------------------------------------------------------------------
  --AUTHOR :张楚材
  --create :2015-01-07
  -- 汇总订单模具产能更新show 表
  Procedure p_up_mould_collect_show(
                            p_order_collect_id in number , -- 订单汇总头Id
                            p_mould_id      in number, -- 模具Id
                            p_entity_id in number, --主体Id
                            p_sales_main_type in varchar2,--营销大类
                            p_sales_sub_type in varchar2, --营销小类
                            p_user_code  in varchar2,--操作用户
                            p_result    out varchar2 -- 返回结果
    );
  -----------------------------------------------------------------------------
  --AUTHOR :张楚材
  --create :2015-01-07
  -- 汇总订单模具产能更新show 表
  procedure check_item_cyc_life(
     p_order_collect_head_id in number ,--汇总订单头Id
     p_entity_id in number ,
     p_user_code in varchar2,
     p_result     out varchar2
    );

  ----------------------------------------------------------------------------------
  --Author: Nicro.Li
  --CreateDate: 2015-04-20
  --Purpose: 汇总订单库存评审更新汇总行库存可用量
  ----------------------------------------------------------------------------------
  Procedure p_Upd_Inv_Qoh_Coolect_Show(p_Order_Collect_Id In Number,
                                       p_Entity_Id        In Number,
                                       p_User_Code        In Varchar2,
                                       p_Result           Out Varchar2);
  
  ----------------------------------------------------------------------------------
  --Author: hejy3
  --CreateDate: 2016-08-27
  --Purpose: 汇总订单完成订单承诺更新承诺日期
  ----------------------------------------------------------------------------------
  Procedure p_Upd_Pln_Lg_Promise_Date(p_Order_Collect_Id In Number,
                                      p_Entity_Id        In Number,
                                      p_User_Code        In Varchar2,
                                      p_Result           Out Varchar2);
End Pkg_Pln_Order_Collect;
/

