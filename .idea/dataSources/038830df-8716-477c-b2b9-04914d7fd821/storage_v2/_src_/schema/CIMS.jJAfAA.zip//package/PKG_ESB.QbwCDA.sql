create PACKAGE PKG_ESB  AS

  --通用ESB异步返回结果处理
  procedure P_ESB_RESULT_BATCH_DEAL
  (
     P_MOD         IN  NUMBER,
     P_MOD_REM     IN  NUMBER,
     P_RETURN_CODE out varchar2, --返回编码
     P_RETURN_MSG  out varchar2  --返回信息
   );

  --通用ESB异步返回结果处理
  procedure P_ESB_RESULT_DEAL
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_DATA_SOURCE  in  varchar2, --数据来源（接口编码）
   P_RETURN_CODE out varchar2, --返回编码
   P_RETURN_MSG  out varchar2  --返回信息
   );

  --廖丽章 ERP销售SO订单生成回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_1(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               );

  --廖丽章 ERP销售SO订单挑库回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_2(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               );

  --廖丽章 ERP销售SO订单日期变更、价格调整回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_3(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               );

  --廖丽章 ERP销售SO订单发运确认回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_4(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               );

  --廖丽章 ERP销售SO挑库、发运确认（拉式）回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_5(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               );

  --廖丽章 ERP RMA生成回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_6(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               );

  --廖丽章  ERP RMA接收回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_7(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               );

  --廖丽章  ERP销售折让订单生成、折让证明订单生成回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_8(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               );

  --廖丽章  ERP销售折让订单登记、折让证明订单登记回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_9(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               );

  --廖丽章  ERP销售折让红冲单登记、折让证明红冲单登记回调处理过程
  PROCEDURE P_ESB_RESULT_DEAL_10(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                 P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                 P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                 P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                                );

  --收款
  procedure P_ESB_RESULT_DEAL_13
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   );

   --收款冲销
  procedure P_ESB_RESULT_DEAL_15
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   );

   --应收发票
  procedure P_ESB_RESULT_DEAL_17
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   );

  --账户别名处理
    procedure P_ESB_RESULT_DEAL_22
    (
     P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
     P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
     P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
     P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
     );

  --子库存转移
    procedure P_ESB_RESULT_DEAL_23
    (
     P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
     P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
     P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
     P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
     );

  --组织间转移
    procedure P_ESB_RESULT_DEAL_24
    (
     P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
     P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
     P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
     P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
     );
  --推广物料
  procedure P_ESB_RESULT_DEAL_25
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   );

  --物料成本
  procedure P_ESB_RESULT_DEAL_26
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   );

   --采购订单接收
    procedure P_ESB_RESULT_DEAL_27
    (
     P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
     P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
     P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
     P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
     );

   --采购订单退订
    procedure P_ESB_RESULT_DEAL_28
    (
     P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
     P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
     P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
     P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
     );
     
  
  
    --关联物流订单回调
  PROCEDURE P_ESB_RESULT_DEAL_51(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               );   
     
       --关联订单回调
  PROCEDURE P_ESB_RESULT_DEAL_58(P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
                                P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
                                P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
                                P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
                               );

   --在途资金确认（纸票在途核销）
  procedure P_ESB_RESULT_DEAL_60
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   );

   --核销关系（到款-发票）
  procedure P_ESB_RESULT_DEAL_61
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   );

      --核销关系（到款-发票）
  procedure P_ESB_RESULT_DEAL_61_1
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   );

   --采购订单生成
  procedure P_ESB_RESULT_DEAL_63
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   );

   --核销关系（发票-发票）
  procedure P_ESB_RESULT_DEAL_74
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   );

      --核销关系（发票-发票）
  procedure P_ESB_RESULT_DEAL_74_1
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   );

     --核销关系（收款发票核销 冲销  ）
  procedure P_ESB_RESULT_DEAL_75
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   );


  --核销关系（正负 发票核销 冲销  ）
  procedure P_ESB_RESULT_DEAL_76
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   );
   
      --关联交易开票的接口
  procedure P_ESB_RESULT_DEAL_77
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   );
   
     --关联交易开票  税控的接口
  procedure P_ESB_RESULT_DEAL_78
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   );
   
     --关联交易弹性域更新AR的接口
  procedure P_ESB_RESULT_DEAL_79
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   );
   
      --关联交易弹性域更新MMT的接口
  procedure P_ESB_RESULT_DEAL_80
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) ;

      --NC采购单、盘点单回调接口处理
  procedure P_ESB_RESULT_DEAL_81
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   ) ;

  ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2017-04-25
  *     创建者：周建刚
  *   功能说明：销售成本NC接口,异步回调结果处理
  */
  ------------------------------------------------------------------------------- 
  PROCEDURE P_ESB_RESULT_DEAL_82
  (
   P_REQUEST_ID  IN  VARCHAR2, --请求ID（交易流水号）
   P_SOURCE_ID1  IN  VARCHAR2, --单据来源ID或编码
   P_RETURN_CODE OUT VARCHAR2, --返回编码,成功：SUCCESS，失败：FAILED
   P_RETURN_MSG  OUT VARCHAR2  --返回信息，成功：执行成功，失败：具体失败信息
   ) ;
   
  ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2017-04-25
  *     创建者：周建刚
  *   功能说明：销售收入凭证NC接口,异步回调结果处理
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ESB_RESULT_DEAL_83
  (
   P_REQUEST_ID  IN  VARCHAR2, --请求ID（交易流水号）
   P_SOURCE_ID1  IN  VARCHAR2, --单据来源ID或编码
   P_RETURN_CODE OUT VARCHAR2, --返回编码,成功：SUCCESS，失败：FAILED
   P_RETURN_MSG  OUT VARCHAR2  --返回信息，成功：执行成功，失败：具体失败信息
   );
  -------------------------------------------------------------------------------
  
   --关联交易订单、关联交易物流
  procedure P_ESB_RESULT_DEAL_CIMS
  (
   P_REQUEST_ID  in  varchar2, --请求ID（交易流水号）
   P_SOURCE_ID1  in  varchar2, --单据来源ID或编码
   P_RETURN_CODE out varchar2, --返回编码,成功：success，失败：failed
   P_RETURN_MSG  out varchar2  --返回信息，成功：执行成功，失败：具体失败信息
   );
    
  ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2017-05-09
  *     创建者：tianmzh
  *   功能说明：财务转款凭证NC接口,异步回调结果处理
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ESB_RESULT_DEAL_84
  (
   P_REQUEST_ID  IN  VARCHAR2, --请求ID（交易流水号）
   P_SOURCE_ID1  IN  VARCHAR2, --单据来源ID或编码
   P_RETURN_CODE OUT VARCHAR2, --返回编码,成功：SUCCESS，失败：FAILED
   P_RETURN_MSG  OUT VARCHAR2  --返回信息，成功：执行成功，失败：具体失败信息
   );
   
   
  ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2017-06-08
  *     创建者：guibr
  *   功能说明：NC退款申请状态更新
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ESB_RESULT_DEAL_85
  (
   P_REQUEST_ID  IN  VARCHAR2, --请求ID（交易流水号）
   P_SOURCE_ID1  IN  VARCHAR2, --单据来源ID或编码
   P_RETURN_CODE OUT VARCHAR2, --返回编码,成功：SUCCESS，失败：FAILED
   P_RETURN_MSG  OUT VARCHAR2  --返回信息，成功：执行成功，失败：具体失败信息
   );
   
     ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2017-06-18
  *     创建者：guibr
  *   功能说明：NC收款状态更新
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_ESB_RESULT_DEAL_86
  (
     P_REQUEST_ID  IN  VARCHAR2, --请求ID（交易流水号）
     P_SOURCE_ID1  IN  VARCHAR2, --单据来源ID或编码
     P_RETURN_CODE OUT VARCHAR2, --返回编码,成功：SUCCESS，失败：FAILED
     P_RETURN_MSG  OUT VARCHAR2  --返回信息，成功：执行成功，失败：具体失败信息
   );
   
  ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2018-05-25
  *   创建者：huanghb12
  *   功能说明：异步推送产品编码至ERP接口成功回调
  */
  -------------------------------------------------------------------------------
   PROCEDURE P_ESB_RESULT_DEAL_87
  (
     P_REQUEST_ID  IN  VARCHAR2, --请求ID（交易流水号）
     P_SOURCE_ID1  IN  VARCHAR2, --单据来源ID或编码
     P_RETURN_CODE OUT VARCHAR2, --返回编码,成功：SUCCESS，失败：FAILED
     P_RETURN_MSG  OUT VARCHAR2  --返回信息，成功：执行成功，失败：具体失败信息
   );
   
   ------------------------------------------------------------------------------- 
  /*
  *   创建日期：2019-05-25
  *   创建者：LILH6
  *   功能说明：提货订单OEM产品触发送货通知接口成功回调
  */
  -------------------------------------------------------------------------------
   PROCEDURE P_ESB_RESULT_DEAL_88
  (
     P_REQUEST_ID  IN  VARCHAR2, --请求ID（交易流水号）
     P_SOURCE_ID1  IN  VARCHAR2, --单据来源ID或编码
     P_RETURN_CODE OUT VARCHAR2, --返回编码,成功：SUCCESS，失败：FAILED
     P_RETURN_MSG  OUT VARCHAR2  --返回信息，成功：执行成功，失败：具体失败信息
   );
   
   
END PKG_ESB;
/

