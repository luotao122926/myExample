create Package      Pkg_Trx Is

  --错误类型，返回值
  Err_Ok                       Constant Varchar2(10) := 'OK';
  Err_Yes                      Constant Varchar2(10) := 'Y';
  Err_No                       Constant Varchar2(10) := 'N';
  Err_Param_Err                Constant Varchar2(50) := '参数不在允许的范围内';
  Err_Unknow                   Constant Varchar2(50) := '不明错误：';
  Err_Dup_Queue                Constant Varchar2(50) := '重复的打印队列';
  Err_Trx_In_Queue             Constant Varchar2(50) := '发票已在队列中';
  Err_Trx_Not_In_Queue         Constant Varchar2(50) := '发票不在队列中';
  Err_Trx_Cannt_Printed        Constant Varchar2(50) := '发票不能打印';
  Err_Trx_Cannt_Cancel_Printed Constant Varchar2(50) := '发票不能取消打印';
  Err_Trx_Printed              Constant Varchar2(50) := '此发票项已经打印';
  Err_Trx_No_Found             Constant Varchar2(50) := '发票找不到';
  Err_Trx_Cannt_Disable        Constant Varchar2(50) := '发票不能失效/禁止打印';
  Err_Order_No_Found           Constant Varchar2(50) := '销售单找不到';
  Err_Trx_Not_Cancelable       Constant Varchar2(50) := '发票不能作废';
  v_Nl                         Constant Varchar2(2) := Chr(13) || Chr(10); --换行
  v_Null                       Constant Varchar2(4) := 'null'; --空值

  Ea_Report2adm      Constant Varchar2(50) := '出错，请找系统管理员。';
  Tpt_Commontaxpayer Constant Varchar2(50) := 'GeneralTaxpayer'; --一般纳税人
  --SmallScaleTaxpayers

  Unlimit_Trxamount Constant Number := 10000000000;

  Handle_By_Discount_Union Constant Varchar2(100) := 'DISCOUNT_UNION'; --'产生专门用于发票打印的汇总的折扣折让行';
  Handle_By_Discount_Line  Constant Varchar2(100) := 'DISCOUNT_LINE'; --'产生用于商品正负间隔的折扣折让行';

  --Trx State 发票状态
  Ts_Unknow      Constant Varchar2(40) := 'TS_UNKNOW';
  Ts_Not_Printed Constant Varchar2(40) := 'TS_NOT_PRINTED';
  Ts_In_Queue    Constant Varchar2(40) := 'TS_IN_QUEUE';
  Ts_Printed     Constant Varchar2(40) := 'TS_PRINTED';
  Ts_Unprintable Constant Varchar2(40) := 'TS_UNPRINTABLE';
  Ts_Outport     Constant Varchar2(40) := 'TS_OUTPORT';
  Ts_Locked      Constant Varchar2(40) := 'TS_LOCKED';

  --Trans_type 转换方式
  Tt_Normal             Constant Varchar2(40) := 'NORMAL'; --普通方式合并
  Tt_Ignore_Discount    Constant Varchar2(40) := 'IGNORE_DISCOUNT'; --忽略折扣合并
  Tt_Single_Batch_Row   Constant Varchar2(40) := 'SINGLE_BATCH_ROW'; --单虚拟商品合并
  Tt_Hide_Discount_Line Constant Varchar2(40) := 'HIDE_DISCOUNT_LINE'; --保存时不产生虚拟折扣行

  --备注常量
  Mc_Trx_Header_Code Constant Varchar2(50) := '[TRX_HEADER_CODE]';



  --得到发票折扣率
  Function Get_Trx_Discount_Amount(p_Trx_Id t_So_Trx_Headers.Idtrx_Id%Type --发票ID
                                   ) Return Number;

  --发票作废和（针对一个发票池头进行作废）
  Procedure Cancel_So_Trx(p_Trx_Id  In t_So_Trx_Headers.Idtrx_Id%Type --作废的发票号码
                         ,
                          p_User_Id In t_So_Trx_Headers.Created_By%Type
                          --用户ID
                         ,
                          p_Result Out Varchar2
                          --返回值
                          );

  /*
  过程描述：用于检查发票状态是否可进行相关操作
  参数说明：
  P_TRX_ID   发票头ID
  CHECK_TYPE 检查类型（此检查用于什么操作）
  P_RESULT 反回参数，如果返回值不为 ERR_OK 则表示检查失败
  */
  Procedure p_Check_Status(p_Trx_Id   In Number,
                           Check_Type In Varchar2,
                           p_Result   In Out Varchar2);

End Pkg_Trx;
/

