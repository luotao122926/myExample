create PACKAGE BODY      PKG_INV_NC AS
  
  -----------------------------------------------------------------------------
  --处理存货单据保存接口推送NC
  -----------------------------------------------------------------------------
  PROCEDURE P_INSERT_INTF_NC
  (
    BIll_TYPE              IN     INTF_NC_INV_HEADER.BIll_TYPE%TYPE,--单据类型
    SOURCE_HEADER_ID       IN NUMBER,--单据头ID
    P_RESULT               IN OUT NUMBER, --返回错误ID
    P_ERR_MSG              IN OUT VARCHAR2 --返回错误信息
  ) IS
  
  BEGIN
     --初始返回值
    P_RESULT  := 0;
    P_ERR_MSG := 'SUCCESS';
     
    IF BIll_TYPE = 'PO_ORDER' THEN--采购单
      P_INSERT_INTF_PO_ORDER(SOURCE_HEADER_ID, P_RESULT, P_ERR_MSG);
    ELSIF BIll_TYPE = 'CHECK_ORDER' THEN--盘点单
      P_INSERT_INTF_CHECK_ORDER(SOURCE_HEADER_ID, P_RESULT, P_ERR_MSG);
    ELSIF BIll_TYPE = 'PMT_ORDER' THEN--推广物料发放单
      P_INSERT_INTF_PMT_ORDER(SOURCE_HEADER_ID, P_RESULT, P_ERR_MSG);
    END IF;
    
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -1;
      P_ERR_MSG := '插入NC接口表出错,单据头ID：' || SOURCE_HEADER_ID || ',单据类型：' || BIll_TYPE || ',出错原因：' || SUBSTR(SQLERRM,1,100);
  END;
  
  -----------------------------------------------------------------------------
  --保存采购单到接口表
  -----------------------------------------------------------------------------
  PROCEDURE P_INSERT_INTF_PO_ORDER
  (
    SOURCE_HEADER_ID       IN NUMBER,--单据头ID
    P_RESULT               IN OUT NUMBER, --返回错误ID
    P_ERR_MSG              IN OUT VARCHAR2 --返回错误信息
  )IS
  V_T_INV_PO_HEADERS            T_INV_PO_HEADERS%ROWTYPE;--采购单头表
  V_INTF_ID                     NUMBER;
  V_TRANSIACTION_TYPE           INTF_NC_INV_HEADER.TRANSIACTION_TYPE%TYPE;
  V_NC_ORG_CODE                 VARCHAR2(100);
  V_INV_STOCK_TYPE              T_INV_INVENTORIES.STOCK_TYPE%TYPE;--存货类型，区别成品和推广物料
  V_ENTITY_ID                    NUMBER;
  V_ENTITY_ENABLE                VARCHAR2(100);--主体配置推广物料是否引NC
  V_REMARK                       VARCHAR2(2000);--备注
  
    --销售单据头
    R_SO_HEADER                 T_SO_HEADER%ROWTYPE;
    V_INTF_STATUS               INTF_NC_INV_HEADER.INTF_STATUS%TYPE;
    V_PO_INTF_CONTROL_FLAG      VARCHAR2(2) := 'N';
    V_CNT                       NUMBER;
  BEGIN
    --初始返回值
    P_RESULT  := 0;
    P_ERR_MSG := 'SUCCESS';
    V_NC_ORG_CODE := NULL;
    V_REMARK      := ' ';
    V_INTF_STATUS := 'N';
    SELECT * INTO V_T_INV_PO_HEADERS FROM T_INV_PO_HEADERS HEAD WHERE HEAD.PO_ID = SOURCE_HEADER_ID;
    
    V_ENTITY_ID := V_T_INV_PO_HEADERS.ENTITY_ID;
    SELECT STOCK_TYPE INTO V_INV_STOCK_TYPE FROM T_INV_INVENTORIES INV WHERE INV.INVENTORY_ID = V_T_INV_PO_HEADERS.INV_FINANCE_ID;
    IF V_INV_STOCK_TYPE = '11' THEN--11:推广物料不写NC,根据主体配置
       V_ENTITY_ENABLE := PKG_BD.F_GET_PARAMETER_VALUE('PMT_MATERIAL_NC_IMPORT_ENABLE', V_ENTITY_ID, NULL, NULL);
       IF V_ENTITY_ENABLE = 'N' THEN
          RETURN;
       END IF;
    END IF;
    
    SELECT DECODE(TT.ACTION_TYPE,'01','IN','02','OUT',TT.ACTION_TYPE) INTO V_TRANSIACTION_TYPE FROM 
      CIMS.T_INV_PO_HEADERS PH, CIMS.T_INV_BILL_TYPES BT, CIMS.T_INV_TRANSACTION_TYPES TT  WHERE 
      PH.PO_TYPE_ID = BT.BILL_TYPE_ID  
      AND BT.TRANSACTION_TYPE_ID = TT.TRANSACTION_TYPE_ID
      AND PH.PO_ID = SOURCE_HEADER_ID AND ROWNUM=1;

    --获取NC 组织
    SELECT INV.ORGANIZATION_CODE
      INTO V_NC_ORG_CODE
      FROM CIMS.T_INV_INVENTORIES INV
     WHERE INV.ENTITY_ID = V_T_INV_PO_HEADERS.ENTITY_ID
       AND V_T_INV_PO_HEADERS.INV_FINANCE_ID = INV.INVENTORY_ID;
       
    PKG_AR_COMMON.P_GET_NCORG_BY_CODE(V_T_INV_PO_HEADERS.ENTITY_ID,
                                      V_NC_ORG_CODE,
                                      V_NC_ORG_CODE,
                                      P_ERR_MSG);
    
    --销售转采购：总部销售单结算后销司PO单才引入NC控制标识
    BEGIN
      PKG_BD.P_GET_PARAMETER_VALUE(PKG_SO_TO_POX.V_NC_PO_INTF_CONTROL_FLAG,
                                   V_T_INV_PO_HEADERS.ENTITY_ID,
                                   NULL,
                                   NULL,
                                   V_PO_INTF_CONTROL_FLAG);
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_MSG := 'SO_TO_PO_NC_PO_INTF_CONTROL_FLAG 主体参数,主体:' ||
                     V_T_INV_PO_HEADERS.ENTITY_ID || '的参数设置异常，请检查。' ||
                     SQLERRM;
        RAISE PKG_SO_PUB.V_BIZ_EXCEPTION;
    END;
    IF V_T_INV_PO_HEADERS.SOURCE_ORDER_NUM IS NOT NULL THEN
        V_REMARK := '[来源单号:' || V_T_INV_PO_HEADERS.SOURCE_ORDER_NUM || ']';
    END IF;
    IF (V_PO_INTF_CONTROL_FLAG = PKG_SO_PUB.V_YES) THEN
      --备注转采购单号
      IF V_T_INV_PO_HEADERS.SOURCE_ORDER_NUM IS NOT NULL THEN
        
        SELECT H.*
          INTO R_SO_HEADER
          FROM T_SO_HEADER H
         WHERE H.TO_SUPP_FLAG = PKG_SO_PUB.V_YES
           AND H.SO_NUM = V_T_INV_PO_HEADERS.SOURCE_ORDER_NUM;
        IF (R_SO_HEADER.SO_STATUS = PKG_SO_PUB.V_AUDITED) THEN
          V_INTF_STATUS := PKG_SO_TO_POX.V_PO_NC_INV_INTF_STATUS_WAIT;
        END IF;
      
      END IF;
    
      --采购退货，如果有总部退货申请单号，则判断总部退货申请对应的退货单是否结算否则不引入NC
      IF V_T_INV_PO_HEADERS.SCHED_ORDER_NUM IS NOT NULL AND
         V_TRANSIACTION_TYPE = 'OUT' AND V_INV_STOCK_TYPE = '10' THEN
        SELECT COUNT(1)
          INTO V_CNT
          FROM CIMS.T_SO_HEADER SH
         WHERE 1 = 1
           AND SH.SO_STATUS = PKG_SO_PUB.V_SETTLED
           AND EXISTS
         (SELECT *
                  FROM CIMS.T_SO_RETURN_APPLY_HEADER AH
                 WHERE AH.BILL_NUM = V_T_INV_PO_HEADERS.SCHED_ORDER_NUM
                   AND AH.BILL_NUM = SH.SRC_BILL_NUM);
        IF V_CNT > 0 THEN
          V_INTF_STATUS := 'N';
        ELSE
          V_INTF_STATUS := PKG_SO_TO_POX.V_PO_NC_INV_INTF_STATUS_WAIT;
        END IF;
      END IF;
    
      --红冲单，看原单是否等待，原单等待，冲单也要设置为等待
      IF V_T_INV_PO_HEADERS.RED_ORDER_FLAG = 'Y' THEN
        SELECT COUNT(1)
          INTO V_CNT
          FROM CIMS.INTF_NC_INV_HEADER T
         WHERE T.ORDER_NUM = V_T_INV_PO_HEADERS.OLD_PO_NUM
           AND T.INTF_STATUS = PKG_SO_TO_POX.V_PO_NC_INV_INTF_STATUS_WAIT;
        IF V_CNT > 0 THEN
          V_INTF_STATUS := PKG_SO_TO_POX.V_PO_NC_INV_INTF_STATUS_WAIT;
        ELSE
          V_INTF_STATUS := 'N';
        END IF;
      END IF;
    END IF;
    
    V_INTF_ID := S_INTF_NC_INV_HEADER.NEXTVAL;
    

    --保存头表
    INSERT INTO INTF_NC_INV_HEADER(
      INTF_ID,
      ENTITY_ID,
      ORG_ID,
      INVENTORY_CODE,
      BUSINESS_TYPE,
      BIll_TYPE,
      SOURCE_HEADER_ID,
      ORDER_NUM,
      REMARK,
      VENDOR_CODE,
      OPERATING_UNIT,
      ACCOUNT_PERIOD,
      BILL_DATE,
      TRANSIACTION_TYPE,
      INTF_STATUS,
      SOURCE_NUM,
      SOURCE_CODE,
      INTF_DATA_SOURCE,
      CREATED_BY,
      LAST_UPDATED_BY,
      CREATION_DATE,
      LAST_UPDATE_DATE
    ) VALUES(
      V_INTF_ID,
      V_T_INV_PO_HEADERS.ENTITY_ID,
      V_NC_ORG_CODE,--NC组织
      V_T_INV_PO_HEADERS.INV_FINANCE_CODE,
      V_T_INV_PO_HEADERS.PO_TYPE,--单据类型编码
      'PO_ORDER',
      V_T_INV_PO_HEADERS.PO_ID,
      V_T_INV_PO_HEADERS.PO_NUM,
      V_REMARK,
      V_T_INV_PO_HEADERS.VENDOR_CODE,
      V_NC_ORG_CODE,--NC组织
      V_T_INV_PO_HEADERS.EXEC_DATE,
      V_T_INV_PO_HEADERS.EXEC_DATE,
      V_TRANSIACTION_TYPE,
      V_INTF_STATUS,
      V_T_INV_PO_HEADERS.OLD_PO_NUM,--红单对应的蓝单号
      'CIMS',
      'CIMS-NC-002',
      V_T_INV_PO_HEADERS.CREATED_BY,
      V_T_INV_PO_HEADERS.LAST_UPDATED_BY,
      V_T_INV_PO_HEADERS.CREATION_DATE,
      V_T_INV_PO_HEADERS.LAST_UPDATE_DATE
    );
    
    --保存行表,推广物料取散件表数据
    IF V_INV_STOCK_TYPE = '11' THEN 
      
      INSERT INTO INTF_NC_INV_LINE(
        INTF_LINE_ID,
        INTF_ID,
        SOURCE_HEADER_ID,
        ITEM_CODE,
        ITEM_QTY,
        ITEM_UNIT,
        ITEM_PRICE,
        BILL_DATE)
      SELECT 
        S_INTF_NC_INV_LINE.NEXTVAL,
        V_INTF_ID,
        V_T_INV_PO_HEADERS.PO_ID,
        ITEM_CODE,
        BILLED_QTY,
        UOM_CODE,
        round(ITEM_PRICE, 4),
        V_T_INV_PO_HEADERS.EXEC_DATE 
      FROM T_INV_PO_LINES POL WHERE POL.PO_ID = SOURCE_HEADER_ID;
    ELSE 
       --成品取套机表数据
      INSERT INTO INTF_NC_INV_LINE(
        INTF_LINE_ID,
        INTF_ID,
        SOURCE_HEADER_ID,
        ITEM_CODE,
        ITEM_QTY,
        ITEM_UNIT,
        ITEM_PRICE,
        BILL_DATE)
      SELECT 
        S_INTF_NC_INV_LINE.NEXTVAL,
        V_INTF_ID,
        V_T_INV_PO_HEADERS.PO_ID,
        ITEM_CODE,
        NVL(SHIPPED_QTY, ITEM_QTY),
        ITEM_UOM_CODE,
        round(LIST_PRICE, 4),
        V_T_INV_PO_HEADERS.EXEC_DATE 
      FROM T_INV_PO_ASSEMBLE_LINES PAL WHERE PAL.PO_HEADER_ID = SOURCE_HEADER_ID
         AND NVL(SHIPPED_QTY, ITEM_QTY) > 0;
    END IF;
    

  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -1;
      P_ERR_MSG := '保存采购单接口表出错,单据头ID：' || SOURCE_HEADER_ID || ',出错原因：' || SUBSTR(SQLERRM,1,100);
      ROLLBACK;
  END;

  -----------------------------------------------------------------------------
  --保存盘点单到接口表
  -----------------------------------------------------------------------------
  PROCEDURE P_INSERT_INTF_CHECK_ORDER
  (
    SOURCE_HEADER_ID       IN NUMBER,--单据头ID
    P_RESULT               IN OUT NUMBER, --返回错误ID
    P_ERR_MSG              IN OUT VARCHAR2 --返回错误信息
  ) IS

  V_T_INV_CHECK_ORDERS          T_INV_CHECK_ORDERS%ROWTYPE;--盘点单头表
  V_INTF_ID                     NUMBER;
  V_TRANSIACTION_TYPE           INTF_NC_INV_HEADER.TRANSIACTION_TYPE%TYPE;
  V_NC_ORG_CODE                 VARCHAR2(100);
  V_INV_STOCK_TYPE              T_INV_INVENTORIES.STOCK_TYPE%TYPE;--存货类型，区别成品和推广物料
  V_ENTITY_ID                    NUMBER;
  V_ENTITY_ENABLE                VARCHAR2(100);

  BEGIN
    --初始返回值
    P_RESULT  := 0;
    P_ERR_MSG := 'SUCCESS';
    V_NC_ORG_CODE := NULL;
    
    SELECT * INTO V_T_INV_CHECK_ORDERS FROM T_INV_CHECK_ORDERS HEAD WHERE HEAD.CHECK_ORDER_ID = SOURCE_HEADER_ID;
    V_ENTITY_ID := V_T_INV_CHECK_ORDERS.ENTITY_ID;
    SELECT STOCK_TYPE INTO V_INV_STOCK_TYPE FROM T_INV_INVENTORIES INV WHERE INV.INVENTORY_ID = V_T_INV_CHECK_ORDERS.INV_ID;
    IF V_INV_STOCK_TYPE = '11' THEN--11:推广物料不写NC,根据主体配置
       V_ENTITY_ENABLE := PKG_BD.F_GET_PARAMETER_VALUE('PMT_MATERIAL_NC_IMPORT_ENABLE', V_ENTITY_ID, NULL, NULL);
       IF V_ENTITY_ENABLE = 'N' THEN
          RETURN;
       END IF;
    END IF;
    
    SELECT DECODE(TT.ACTION_TYPE,'01','IN','02','OUT',TT.ACTION_TYPE) INTO V_TRANSIACTION_TYPE FROM 
      CIMS.T_INV_CHECK_ORDERS CO, CIMS.T_INV_BILL_TYPES BT, CIMS.T_INV_TRANSACTION_TYPES TT  WHERE 
      CO.CHECK_ORDER_TYPE_ID = BT.BILL_TYPE_ID  
      AND BT.TRANSACTION_TYPE_ID = TT.TRANSACTION_TYPE_ID
      AND CO.CHECK_ORDER_ID = SOURCE_HEADER_ID AND ROWNUM=1;

    --获取NC 组织
    SELECT INV.ORGANIZATION_CODE INTO V_NC_ORG_CODE FROM CIMS.T_INV_INVENTORIES INV WHERE 
     INV.ENTITY_ID = V_T_INV_CHECK_ORDERS.ENTITY_ID AND V_T_INV_CHECK_ORDERS.INV_ID = INV.INVENTORY_ID; 
    PKG_AR_COMMON.P_GET_NCORG_BY_CODE(V_T_INV_CHECK_ORDERS.ENTITY_ID, V_NC_ORG_CODE,V_NC_ORG_CODE,P_ERR_MSG);
    

    V_INTF_ID := S_INTF_NC_INV_HEADER.NEXTVAL;

    --保存头表
    INSERT INTO INTF_NC_INV_HEADER(
      INTF_ID,
      ENTITY_ID,
      ORG_ID,
      INVENTORY_CODE,
      BUSINESS_TYPE,
      BIll_TYPE,
      SOURCE_HEADER_ID,
      ORDER_NUM,
      REMARK,
      VENDOR_CODE,
      OPERATING_UNIT,
      ACCOUNT_PERIOD,
      BILL_DATE,
      TRANSIACTION_TYPE,
      INTF_STATUS,
      SOURCE_NUM,
      SOURCE_CODE,
      INTF_DATA_SOURCE,
      CREATED_BY,
      LAST_UPDATED_BY,
      CREATION_DATE,
      LAST_UPDATE_DATE
    ) VALUES(
      V_INTF_ID,
      V_T_INV_CHECK_ORDERS.ENTITY_ID,
      V_NC_ORG_CODE,--NC组织
      V_T_INV_CHECK_ORDERS.INV_CODE,
      V_T_INV_CHECK_ORDERS.CHECK_ORDER_TYPE,--单据类型编码
      'CHECK_ORDER',
      V_T_INV_CHECK_ORDERS.CHECK_ORDER_ID,
      V_T_INV_CHECK_ORDERS.CHECK_ORDER_NUM,
      ' ',
      NULL,
      V_NC_ORG_CODE,--NC组织
      V_T_INV_CHECK_ORDERS.EXEC_DATE,
      V_T_INV_CHECK_ORDERS.EXEC_DATE,
      V_TRANSIACTION_TYPE,
      'N',
      NULL,--红单对应的蓝单号
      'CIMS',
      'CIMS-NC-004',
      V_T_INV_CHECK_ORDERS.CREATED_BY,
      V_T_INV_CHECK_ORDERS.LAST_UPDATED_BY,
      V_T_INV_CHECK_ORDERS.CREATION_DATE,
      V_T_INV_CHECK_ORDERS.LAST_UPDATE_DATE
    );
    
    --保存行表
    INSERT INTO INTF_NC_INV_LINE(
      INTF_LINE_ID,
      INTF_ID,
      SOURCE_HEADER_ID,
      ITEM_CODE,
      ITEM_QTY,
      ITEM_UNIT,
      ITEM_PRICE,
      BILL_DATE)
    SELECT 
      S_INTF_NC_INV_LINE.NEXTVAL,
      V_INTF_ID,
      V_T_INV_CHECK_ORDERS.CHECK_ORDER_ID,
      ITEM_CODE,
      BILLED_QTY,
      UOM_CODE,
      COST_PRICE,
      V_T_INV_CHECK_ORDERS.EXEC_DATE 
    FROM T_INV_CHECK_ORDER_ASSEMBLE OL WHERE OL.CHECK_ORDER_ID = SOURCE_HEADER_ID;

    
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -1;
      P_ERR_MSG := '保存盘点单接口表出错,单据头ID：' || SOURCE_HEADER_ID || ',出错原因：' || SUBSTR(SQLERRM,1,100);
      ROLLBACK;
  END;

  -----------------------------------------------------------------------------
  --保存盘点单到接口表
  -----------------------------------------------------------------------------
  PROCEDURE P_INSERT_INTF_PMT_ORDER(SOURCE_HEADER_ID IN NUMBER, --单据头ID
                                    P_RESULT         IN OUT NUMBER, --返回错误ID
                                    P_ERR_MSG        IN OUT VARCHAR2 --返回错误信息
                                    ) IS
  
    VT_PMT_SEND_HEAD      T_PMT_COLLAR_SEND_HEAD%ROWTYPE; --头表
    V_INTF_ID           NUMBER;
    V_TRANSIACTION_TYPE INTF_NC_INV_HEADER.TRANSIACTION_TYPE%TYPE;
    V_NC_ORG_CODE       VARCHAR2(100);
    --V_INV_STOCK_TYPE              T_INV_INVENTORIES.STOCK_TYPE%TYPE;--存货类型，区别成品和推广物料
    V_ENTITY_ID     NUMBER;
    V_ENTITY_ENABLE VARCHAR2(100);
  
  BEGIN
    --初始返回值
    P_RESULT      := 0;
    P_ERR_MSG     := 'SUCCESS';
    V_NC_ORG_CODE := NULL;
  
    SELECT *
      INTO VT_PMT_SEND_HEAD
      FROM T_PMT_COLLAR_SEND_HEAD HEAD
     WHERE HEAD.COLLAR_SEND_HEAD_ID = SOURCE_HEADER_ID;
    V_ENTITY_ID := VT_PMT_SEND_HEAD.ENTITY_ID;
  
    V_ENTITY_ENABLE := PKG_BD.F_GET_PARAMETER_VALUE('PMT_MATERIAL_NC_IMPORT_ENABLE',
                                                    V_ENTITY_ID,
                                                    NULL,
                                                    NULL);
    IF V_ENTITY_ENABLE = 'N' THEN
      RETURN;
    END IF;
  
    SELECT DECODE(TT.ACTION_TYPE, '01', 'IN', '02', 'OUT', TT.ACTION_TYPE)
      INTO V_TRANSIACTION_TYPE
      FROM T_INV_BILL_TYPES        BT,
           T_INV_TRANSACTION_TYPES TT
     WHERE BT.TRANSACTION_TYPE_ID = TT.TRANSACTION_TYPE_ID
     AND BT.BILL_TYPE_ID = VT_PMT_SEND_HEAD.BILL_TYPE_ID
       AND ROWNUM = 1;
  
    --获取NC 组织
    SELECT INV.ORGANIZATION_CODE
      INTO V_NC_ORG_CODE
      FROM CIMS.T_INV_INVENTORIES INV
     WHERE INV.ENTITY_ID = VT_PMT_SEND_HEAD.ENTITY_ID
       AND VT_PMT_SEND_HEAD.SHIP_INVENTORY_ID = INV.INVENTORY_ID;
    PKG_AR_COMMON.P_GET_NCORG_BY_CODE(VT_PMT_SEND_HEAD.ENTITY_ID,
                                      V_NC_ORG_CODE,
                                      V_NC_ORG_CODE,
                                      P_ERR_MSG);
  
    V_INTF_ID := S_INTF_NC_INV_HEADER.NEXTVAL;
  
    --保存头表
    INSERT INTO INTF_NC_INV_HEADER
      (INTF_ID,
       ENTITY_ID,
       ORG_ID,
       INVENTORY_CODE,
       BUSINESS_TYPE,
       BIll_TYPE,
       SOURCE_HEADER_ID,
       ORDER_NUM,
       REMARK,
       VENDOR_CODE,
       OPERATING_UNIT,
       ACCOUNT_PERIOD,
       BILL_DATE,
       TRANSIACTION_TYPE,
       INTF_STATUS,
       SOURCE_NUM,
       SOURCE_CODE,
       INTF_DATA_SOURCE,
       CREATED_BY,
       LAST_UPDATED_BY,
       CREATION_DATE,
       LAST_UPDATE_DATE)
    VALUES
      (V_INTF_ID,
       VT_PMT_SEND_HEAD.ENTITY_ID,
       V_NC_ORG_CODE, --NC组织
       VT_PMT_SEND_HEAD.SHIP_INVENTORY_CODE,
       VT_PMT_SEND_HEAD.BILL_TYPE_CODE, --单据类型编码
       'PMT_ORDER',
       VT_PMT_SEND_HEAD.COLLAR_SEND_HEAD_ID,
       VT_PMT_SEND_HEAD.PMT_SEND_NUM-- || '_' || VT_PMT_SEND_HEAD.PMT_ORDER_NUM,
       ,' ',--VT_PMT_SEND_HEAD
       NULL,
       V_NC_ORG_CODE, --NC组织
       VT_PMT_SEND_HEAD.SEND_DATE,
       VT_PMT_SEND_HEAD.SEND_DATE,
       V_TRANSIACTION_TYPE,
       'N',
       NULL, --红单对应的蓝单号
       'CIMS',
       'CIMS-NC-004',
       VT_PMT_SEND_HEAD.CREATED_BY,
       VT_PMT_SEND_HEAD.LAST_UPDATED_BY,
       VT_PMT_SEND_HEAD.CREATION_DATE,
       VT_PMT_SEND_HEAD.LAST_UPDATED_DATE);
  
    --保存行表
    INSERT INTO INTF_NC_INV_LINE
      (INTF_LINE_ID,
       INTF_ID,
       SOURCE_HEADER_ID,
       ITEM_CODE,
       ITEM_QTY,
       ITEM_UNIT,
       ITEM_PRICE,
       BILL_DATE)
      SELECT S_INTF_NC_INV_LINE.NEXTVAL,
             V_INTF_ID,
             VT_PMT_SEND_HEAD.COLLAR_SEND_HEAD_ID,
             OL.PMT_CODE,
             OL.RCV_QTY,
             OL.UNIT,
             OL.PRICE,
             VT_PMT_SEND_HEAD.SEND_DATE
        FROM T_PMT_COLLAR_SEND_LINE OL
       WHERE OL.COLLAR_SEND_HEAD_ID = SOURCE_HEADER_ID;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_RESULT  := -1;
      P_ERR_MSG := '保存发放单接口表出错,单据头ID：' || SOURCE_HEADER_ID || ',出错原因：' ||
                   SUBSTR(SQLERRM, 1, 100);
      ROLLBACK;
  END;

END PKG_INV_NC;
/

