create Package Body      PKG_SO_INTF_CHECK Is

-----------------------------------------------------------------------------
  --  检测没生成SO变更记录原因                                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_SO_NOCHANGE_CHECK(
     IS_SO_NUM         IN   VARCHAR2  --主体
    ,IS_ENTITY_ID      IN   VARCHAR2  --主体
    ,S_USER_ACCOUNT    IN   VARCHAR2  --用户账号
    ,OS_MESSAGE        OUT  VARCHAR2  --成功则返回“OK”，否则返回出错信息
  ) IS
     S_ORIG_SO_NUM               VARCHAR2(100);
     S_ORDER_NUMBER              VARCHAR2(100);
     S_ERP_LOGIST_HEADER_ID      VARCHAR2(100);
     S_IS_MATERIAL               VARCHAR2(100);
     S_BIZ_SRC_BILL_TYPE_CODE    VARCHAR2(100);
     S_PULL_MODE                 VARCHAR2(100);
     S_LOGIST_STATUS             VARCHAR2(100);
     S_ERP_LOGIST_STATUS         VARCHAR2(100);
     S_SQL                       VARCHAR2(4000);
     S_CHECK_INFO                VARCHAR2(4000);
     S_USER_ID               VARCHAR2(4000);
     N_COUNT                     NUMBER;
     TYPE mycur IS REF CURSOR;
     v_cur               mycur;
     N_ENTITY_ID          NUMBER;
     N_REQ_HEADER_ID      NUMBER;
     S_LOGIT_ERROR_INFO   VARCHAR2(10000);
  BEGIN
      OS_MESSAGE := 'OK';
      S_SQL    := 'SELECT
		       I.ORDER_NUMBER
		       ,H.ENTITY_ID
		    FROM
		       INTF_OE_HEADERS_IFACE_ALL I,T_SO_HEADER H
		    WHERE
		         H.SO_NUM = I.ORDER_NUMBER
                     AND H.SO_STATUS=12
		     AND I.UPDATE_TRX_STATUS IS NULL ';
        IF IS_SO_NUM IS NOT NULL THEN
            S_SQL :=S_SQL||' AND I.ORDER_NUMBER='||IS_SO_NUM;
	    DELETE FROM T_SO_NOCHANGE_CAUSE where so_num=IS_SO_NUM;
        elsif   IS_ENTITY_ID IS NOT NULL THEN
            S_SQL :=S_SQL||' AND H.ENTITY_ID='||IS_ENTITY_ID;
	    DELETE FROM T_SO_NOCHANGE_CAUSE where ENTITY_ID=IS_ENTITY_ID;
        else
             DELETE FROM T_SO_NOCHANGE_CAUSE;
        END IF;
         S_USER_ID :='admin';
	  IF  S_USER_ACCOUNT IS NOT NULL THEN
            S_USER_ID := S_USER_ACCOUNT;
	  END IF;

      OPEN v_cur FOR S_SQL;

       LOOP
            FETCH
	       v_cur
	    INTO
               S_ORDER_NUMBER,N_ENTITY_ID;
	    EXIT WHEN v_cur%NOTFOUND;
          BEGIN
               S_CHECK_INFO:= null;
               S_LOGIST_STATUS:='S';
               SELECT (CASE
                         WHEN A.BIZ_SRC_BILL_TYPE_CODE = '1002' THEN --如果是红冲单看蓝单号
                          A.ORIG_SO_NUM
                         WHEN A.BIZ_SRC_BILL_TYPE_CODE = '1003' AND --如果是退货，而且是有源退货，看源单号
                              NVL(A.RETURN_MODE, '1') = '2' THEN
                          A.RETURN_ORIG_SO_NUM
                         WHEN A.BIZ_SRC_BILL_TYPE_CODE = '1003' AND --如果是退货，但无源，则为反向销售
                              NVL(A.RETURN_MODE, '1') = '3' THEN
                          '反向销售'
                         ELSE
                          '错误'
                       END) AS ORIG_SO_NUM
                      ,A.ERP_LOGIST_HEADER_ID
                      ,NVL(A.IS_MATERIAL, 'N') IS_MATERIAL
                      ,A.BIZ_SRC_BILL_TYPE_CODE
                      ,PKG_SO_PUB.F_PULL_MODE_BY_HEADERID(A.SO_HEADER_ID) PULL_MODE
               INTO
                   S_ORIG_SO_NUM
                  ,S_ERP_LOGIST_HEADER_ID
                  ,S_IS_MATERIAL
                  ,S_BIZ_SRC_BILL_TYPE_CODE
                  ,S_PULL_MODE
               FROM T_SO_HEADER A
               where A.SO_NUM = S_ORDER_NUMBER;

               IF S_BIZ_SRC_BILL_TYPE_CODE IN('1002', '1003')  --红冲，退货
                 and S_PULL_MODE  IN  (2, 3, 4) --红冲、有源退货、反向销售
                 and S_IS_MATERIAL = 'N' --非推广物料
               THEN
                   BEGIN
                        SELECT
                           (CASE WHEN RESPONSETYPE_1 in('W','E') and STATUS_SOURCE='P'  then 'E' when RESPONSETYPE_1='N' and STATUS_SOURCE='P'  then 'S' else STATUS_SOURCE end) STATUS
                        INTO
                           S_LOGIST_STATUS
                        FROM
                           INTF_CUX_ICP_LOGIST_REQ_HEADER
                        WHERE
                           REQUIREMENT_ORDER_NUM= S_ORDER_NUMBER;
                        IF S_LOGIST_STATUS <>'S' THEN
                             S_CHECK_INFO :=S_CHECK_INFO||'关联物流接口错误;';
                        END IF;
                   EXCEPTION
                       WHEN NO_DATA_FOUND THEN
                              SELECT
                                 COUNT(1) --已经生成RMA接收标记
                              INTO
                                 N_COUNT
                              FROM
                                 INTF_OE_HEADERS_IFACE_ALL C
                              WHERE
                                   C.RMA_RECEIVE_TRX_STATUS = 'S'
                              AND C.ORDER_NUMBER = S_ORDER_NUMBER;
                              IF N_COUNT = 0 THEN
                                  S_CHECK_INFO :=S_CHECK_INFO||'RMA接收接口错误;';
                              END IF;

                              IF S_ORIG_SO_NUM<>'反向销售' THEN
                                 SELECT
                                     COUNT(1)
                                  INTO
                                     N_COUNT
                                 FROM
                                     INTF_CUX_ICP_LOGIST_REQ_HEADER B2
                                 WHERE B2.REQUIREMENT_ORDER_NUM = S_ORIG_SO_NUM
                                  AND  B2.X_ICP_SEQ_ID IS NOT NULL;
                                 IF N_COUNT=0 THEN
                                    S_CHECK_INFO :=S_CHECK_INFO||'源单关联物流X_ICP_SEQ_ID为空或不存在;';
                                 END IF;
                              END IF;
                   END;
               END IF;

               IF S_ERP_LOGIST_HEADER_ID IS NULL THEN
                  S_CHECK_INFO :=S_CHECK_INFO||'单据ERP_LOGIST_HEADER_ID为空;';
               END IF;

                BEGIN
                   SELECT
                      B.STATUS||''
                   ,REQ_HEADER_ID
                   INTO
                      S_ERP_LOGIST_STATUS
                      ,N_REQ_HEADER_ID
                   FROM
                      CIMS.CUX_ICP_LOGIST_REQ_HEADERS_V B
                   WHERE B.REQUIREMENT_ORDER_TYPE = 'CIMS-SEND'
                     AND B.ORDER_STATUS = 'RECEIVE_CONFIRM'
                     AND B.REQUIREMENT_ORDER_NUM = S_ORDER_NUMBER||'';
                   IF S_ERP_LOGIST_STATUS<>'5' THEN
                       FOR V_CUX_ICP_ERRMSG_ROW IN (
                         select
                           distinct error_message
                         from
                           apps.CUX_ICP_ERRMSG_V@mdims2mderp a
                         where a.req_header_id =N_REQ_HEADER_ID
                        )LOOP
                          BEGIN
                            S_LOGIT_ERROR_INFO := S_LOGIT_ERROR_INFO||V_CUX_ICP_ERRMSG_ROW.error_message;
                          END;
                        END LOOP;
                        S_LOGIT_ERROR_INFO := substr(S_LOGIT_ERROR_INFO, 1, 2000);
                        S_CHECK_INFO :=S_CHECK_INFO||'ERP系统中关联物流订单状态错误:'||S_ERP_LOGIST_STATUS||S_LOGIT_ERROR_INFO||';';
                   END IF;
                EXCEPTION
                       WHEN NO_DATA_FOUND THEN
                          S_CHECK_INFO :=S_CHECK_INFO||'ERP系统中关联物流订单不存在;';
                END;

               IF S_CHECK_INFO  is not null THEN
	         OS_MESSAGE := S_CHECK_INFO;
                 INSERT
                  INTO
                  T_SO_NOCHANGE_CAUSE(
                    CAUSE_ID
                    ,SO_NUM
                    ,CAUSE_INFO
                    ,CREATED_BY
                    ,CREATION_DATE
                    ,LAST_UPDATED_BY
                    ,LAST_UPDATE_DATE
		    ,ENTITY_ID
                  )values(
                     S_SO_NOCHANGE_CAUSE.NEXTVAL
                    ,S_ORDER_NUMBER
                    ,S_CHECK_INFO
                    ,S_USER_ID
                    ,sysdate
                    ,S_USER_ID
                    ,sysdate
		    ,N_ENTITY_ID
                  );
               END IF;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              NULL;
          END;
      END LOOP;

      IF v_cur%ISOPEN = TRUE
      THEN
          CLOSE v_cur;
      END IF;
      --提交
      COMMIT;
  EXCEPTION
     WHEN OTHERS THEN
       OS_MESSAGE := SUBSTR(SQLERRM(SQLCODE), 1, 256);
       IF v_cur%ISOPEN = TRUE
       THEN
           CLOSE v_cur;
       END IF;
       ROLLBACK;
  END P_SO_NOCHANGE_CHECK;

END PKG_SO_INTF_CHECK;
/

