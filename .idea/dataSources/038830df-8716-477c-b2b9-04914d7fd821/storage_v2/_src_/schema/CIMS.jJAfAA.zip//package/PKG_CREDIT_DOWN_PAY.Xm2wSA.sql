create package PKG_CREDIT_DOWN_PAY is

  -- Author  : LIANGYM2
  -- Created : 2016/8/29 11:56:49
  -- Purpose :订金锁定、订单提货额度锁定、订金释放、订单提货额度释放

  V_SUCCESS_MSG VARCHAR2(1000) := 'SUCCESS'; --成功返回信息
  
  V_SEC_RESULT CONSTANT NUMBER := 0; --成功返回
  V_SUCCESS    CONSTANT VARCHAR2(10) := 'SUCCESS';

  V_NL CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行

  V_BASE_EXCEPTION EXCEPTION; --自定义异常

  /**
  *订金锁定，用于动作标识1/29
  *1适用于锁款类型为送审锁款的订单送审或评审时（也是送审锁款类型）调整差额为正数
  *的场景（还有锁款类型为发货锁款的订单评审的场景，但不锁订金）
  *29表示取消发货通知单时，如果是做过T+3订单评审的订单
  *，或者是订单已关闭，且是送审锁款的订单，须进行解锁款项锁订金的操作
  **/
  PROCEDURE P_LOCK_DOWN_PAY_AMOUNT(IN_ORDER_ID        IN NUMBER, --提货订单ID
                                   IS_ORDER_TYPE      IN VARCHAR2, --提货订单单据类型
                                   IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                   IN_LOCK_AMOUNT     IN NUMBER, --锁定金额
                                   IN_ENTITY_ID       IN NUMBER, --主体ID
                                   IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                   IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                   IN_DOWN_PAY_RATE   IN NUMBER, --订金比例
                                   IS_ACTION_TYPE     IN VARCHAR2, --动作标识
                                   IS_USER_ACCOUNT    IN VARCHAR2, --用户账号
                                   OS_MESSAGE         OUT VARCHAR2, --成功返回SUCCESS，失败返回出错信息
                                   IS_DISCOUNT_TYPE    IN VARCHAR2 DEFAULT NULL--折让方式
                                   );

  /**
  *折扣订金锁定，用于动作标识1/29
  *1适用于锁款类型为送审锁款的订单送审或评审时（也是送审锁款类型）调整差额为正数
  *的场景（还有锁款类型为发货锁款的订单评审的场景，但不锁订金）
  *29表示取消发货通知单时，如果是做过T+3订单评审的订单
  *，或者是订单已关闭，且是送审锁款的订单，须进行解锁款项锁订金的操作
  **/
  PROCEDURE P_LOCK_DP_DIS_AMOUNT(IN_ORDER_ID        IN NUMBER, --提货订单ID
                                   IS_ORDER_TYPE      IN VARCHAR2, --提货订单单据类型
                                   IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                   IN_LOCK_AMOUNT     IN NUMBER, --锁定金额
                                   IN_ENTITY_ID       IN NUMBER, --主体ID
                                   IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                   IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                   IN_DOWN_PAY_RATE   IN NUMBER, --订金比例
                                   IS_ACTION_TYPE     IN VARCHAR2, --动作标识
                                   IS_USER_ACCOUNT    IN VARCHAR2, --用户账号
                                   OS_MESSAGE         OUT VARCHAR2, --成功返回SUCCESS，失败返回出错信息
                                   IS_DISCOUNT_TYPE    IN VARCHAR2 DEFAULT NULL--折让方式
                                   );

  /**
  *订单提货额度锁定、对于动作标识1，调用锁订金或锁款成功之后，调用
  **/
  PROCEDURE P_LOCK_ORDER_AMOUNT(IN_ORDER_ID     IN NUMBER, --提货订单ID
                                IS_ORDER_TYPE   IN VARCHAR2, --提货订单单据类型
                                IN_LOCK_AMOUNT  IN NUMBER, --锁定金额
                                IN_ENTITY_ID    IN NUMBER, --主体ID
                                IN_CUSTOMER_ID  IN NUMBER, --客户ID
                                IN_ACCOUNT_ID   IN NUMBER, --账户ID
                                IS_USER_ACCOUNT IN VARCHAR2, --用户账号
                                OS_MESSAGE      OUT VARCHAR2 --成功返回SUCCESS，失败返回出错信息
                                );

  /**
  *订单提货额度锁定释放
  *发货通知单进行确认生成销售单时，或者提货订单驳回、关闭时，对订单提货额度的占用进行释放
  **/
  PROCEDURE P_UNLOCK_ORDER_AMOUNT(IN_ORDER_ID   IN NUMBER, --提货订单ID，或发货通知单来源与提货订单的计划订单ID
                                  IS_ORDER_TYPE IN VARCHAR2,
                                  --提货订单单据类型，或发货通知单来源与提货订单的计划订单类型
                                  IN_UNLOCK_AMOUNT IN NUMBER, --释放金额
                                  IS_USER_ACCOUNT  IN VARCHAR2, --用户账号
                                  OS_MESSAGE       OUT VARCHAR2 --成功返回SUCCESS，失败返回出错信息
                                  );

  /**
  *订金释放，用于动作标识2/28
  **/
  PROCEDURE P_UNLOCK_DOWN_PAY_AMOUNT(IN_ORDER_ID        IN NUMBER, --提货订单ID
                                     IS_ORDER_TYPE      IN VARCHAR2, --提货订单单据类型
                                     IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                     IN_UNLOCK_AMOUNT   IN NUMBER, --锁定金额
                                     IN_ENTITY_ID       IN NUMBER, --主体ID
                                     IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                     IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                     IN_DOWN_PAY_RATE   IN NUMBER, --订金比例
                                     IS_ACTION_TYPE     IN VARCHAR2, --动作标识
                                     IS_USER_ACCOUNT    IN VARCHAR2, --用户账号
                                     OS_MESSAGE         OUT VARCHAR2, --成功返回SUCCESS，失败返回出错信息
                                     IS_DISCOUNT_TYPE    IN VARCHAR2 DEFAULT NULL--折让方式
                                     );

  /**
  *折扣订金释放，用于动作标识2/28
  
  **/
  PROCEDURE P_UNLOCK_DP_DIS_AMOUNT(IN_ORDER_ID        IN NUMBER, --提货订单ID
                                     IS_ORDER_TYPE      IN VARCHAR2, --提货订单单据类型
                                     IS_SALES_MAIN_TYPE IN VARCHAR2, --营销大类
                                     IN_UNLOCK_AMOUNT   IN NUMBER, --锁定金额
                                     IN_ENTITY_ID       IN NUMBER, --主体ID
                                     IN_CUSTOMER_ID     IN NUMBER, --客户ID
                                     IN_ACCOUNT_ID      IN NUMBER, --账户ID
                                     IN_DOWN_PAY_RATE   IN NUMBER, --订金比例
                                     IS_ACTION_TYPE     IN VARCHAR2, --动作标识
                                     IS_USER_ACCOUNT    IN VARCHAR2, --用户账号
                                     OS_MESSAGE         OUT VARCHAR2, --成功返回SUCCESS，失败返回出错信息
                                     IS_DISCOUNT_TYPE    IN VARCHAR2 DEFAULT NULL--折让方式
                                     );

  /***
  *客户订单提货额度校验
  */
  PROCEDURE PRC_ORDER_AMOUNT_VERIFICATION(IN_ENTITY_ID         IN NUMBER, --主体ID
                                          IN_ACTION_TYPE       IN NUMBER, --动作标示
                                          IN_CUSTOMER_ID       IN NUMBER, --客户ID
                                          IN_ACCOUNT_ID        IN NUMBER, --账户ID
                                          IN_SETTLEMENT_AMOUNT IN NUMBER, --结算金额
                                          ON_RESULT            IN OUT NUMBER, --返回错误ID
                                          OS_ERR_MSG           IN OUT VARCHAR2 --返回错误信息
                                          );

  PROCEDURE PRC_DOWN_PAY_VERIFICATION(IN_ENTITY_ID            IN NUMBER, --主体ID
                                      IN_ACTION_TYPE          IN NUMBER, --动作标示
                                      IN_CUSTOMER_ID          IN NUMBER, --客户ID
                                      IN_ACCOUNT_ID           IN NUMBER, --账户ID
                                      IN_SETTLEMENT_AMOUNT    IN NUMBER, --结算金额
                                      IN_DISCOUNT_AMOUNT      IN NUMBER, --折扣金额
                                      IN_AMOUNT_SUM           IN NUMBER, --金额控制金额
                                      IN_DISCOUNT_SUM         IN NUMBER, --折扣控制金额
                                      IS_DISCOUNT_CTRL_FLAG   IN VARCHAR2, --折扣控制方式
                                      IN_CHK_DIS_AMOUNT       IN NUMBER, --合并折让余额
                                      IN_DOWN_PAY_SCALE       IN NUMBER, --订金比例
                                      IN_SRC_ORDER_ID         IN NUMBER,--单据ID
                                      IS_SRC_ORDER_NUM        IN VARCHAR2,--单据号
                                      IS_SRC_ORDER_TYPE       IN VARCHAR2,--单据类型
                                      IN_DOWN_PAY_AMOUNT      IN NUMBER,--订金
                                      IN_DP_DIS_AMOUNT        IN NUMBER,--折扣订金
                                      IN_LOCK_RECEIVED_AMOUNT IN NUMBER, --锁定到款金额
                                      IN_LOCK_DISCOUNT_AMOUNT IN NUMBER, --锁定折扣金额
                                      IN_ORDER_VERIFY_FLAG    IN NUMBER, -- 订单提货额度检查 1检查提货额度以及订金 2检查提货额度、不检查订金 3检查订金、不检查提货额度
                                      ON_RESULT               IN OUT NUMBER, --返回错误ID
                                      OS_ERR_MSG              IN OUT VARCHAR2 --返回错误信息
                                      );

  /**
  *
  */
  PROCEDURE PRC_CREDIT_LIMIT_HAVE_PARAM(IN_ENTITY_ID          IN NUMBER, --主体ID
                                        IN_CUSTOMER_ID        IN NUMBER, --客户ID
                                        IN_ACCOUNT_ID         IN NUMBER, --账户ID
                                        ON_DOWN_PAY_RATIO_E   OUT NUMBER,
                                        ON_ORDER_TOP_AMOUNT_E OUT NUMBER,
                                        ON_DOWN_PAY_RATIO     OUT NUMBER,
                                        ON_ORDER_TOP_AMOUNT   OUT NUMBER,
                                        OS_MESSAGE            OUT VARCHAR2);

  /**
  *客户账户额度重算(订单可提货金额上限、订金比例)
  */
  PROCEDURE PRC_CREDIT_ACC_LIMIT_RERUN(IN_ENTITY_ID  IN NUMBER, --主体ID
                                       ID_NOW_STAMP  IN DATE,
                                       IN_UPDATED_BY IN VARCHAR2, --
                                       OS_MESSAGE    OUT VARCHAR2,
    IN_CUSTOMER_ID IN  NUMBER DEFAULT NULL,--客户ID，可以为空
    IN_ACCOUNT_ID  IN  NUMBER DEFAULT NULL--账户ID，可以为空
                                       );

  FUNCTION FUN_JUDGE_OCCUPY_ORDER_AMOUNT
  --确定提货订单是否需要占用提货额度
  (P_ORDER_ID   NUMBER, --提货订单ID 可以为空 P_ORDER_ID、P_ORDER_HEAD不可以都为空
   P_ORDER_HEAD T_PLN_LG_ORDER_HEAD%ROWTYPE DEFAULT NULL --提货订单ROW 可以为空 P_ORDER_ID、P_ORDER_HEAD不可以都为空
   ) RETURN NUMBER; --返回1需要占用提货额度

  /*
  *确定相应主体的订单类型是否需要占用提货额度，需要返回1，否则返回0
  */
  FUNCTION FUN_JUDGE_OCCUPY_ORDER_LIMIT(IN_ENTITY_ID       NUMBER, --主体ID
                                        IS_ORDER_TYPE_CODE VARCHAR2 --订单类型编码
                                        ) RETURN NUMBER;

  /**
  *客户信用等级、账户修改时更新客户账户额度（或插入）
  */
  PROCEDURE PRC_CREDIT_ACC_LIMIT_UPDATE(IN_ENTITY_ID   NUMBER, --主体ID
                                        IN_CUSTOMER_ID NUMBER, --客户ID
                                        IN_ACCOUNT_ID  NUMBER, --账户ID
                                        IN_UPDATED_BY  VARCHAR2, --修改人
                                        OS_MESSAGE     OUT VARCHAR2, --客户ID
                                        IN_ONLY_UPDATE IN  NUMBER DEFAULT NULL);

  PROCEDURE PRC_UP_ORDER_USED_UNSO_AMOUNT
  --获取并更新账户的订单已使用提货额度（未生成销售单），如果有变化，记录历史
  (IN_ENTITY_ID        IN NUMBER, --主体ID
   IN_CUSTOMER_ID      IN NUMBER, --客户ID
   IN_ACCOUNT_ID       IN NUMBER, --账户ID
   IN_USED_UNSO_AMOUNT IN NUMBER, --更新前的订单已使用提货额度，可以为空
   IN_UPDATED_BY       IN VARCHAR2, --修改人
   ON_USED_UNSO_AMOUNT OUT NUMBER --更新后的订单已使用提货额度
   );

  FUNCTION FUN_GET_ORDER_S_UNSHIP_AMOUNT
  --获取账户的订单已使用提货额度（已送审未评审）
  (IN_ENTITY_ID   NUMBER, --主体ID
   IN_CUSTOMER_ID NUMBER, --客户ID
   IN_ACCOUNT_ID  NUMBER --账户ID
   ) RETURN NUMBER;

  FUNCTION FUN_GET_ORDER_SHIP_UNSO_AMOUNT
  --获取账户的订单已使用提货额度（已评审（发货）、未生成销售单）
  (IN_ENTITY_ID   NUMBER, --主体ID
   IN_CUSTOMER_ID NUMBER, --客户ID
   IN_ACCOUNT_ID  NUMBER --账户ID
   ) RETURN NUMBER;

end PKG_CREDIT_DOWN_PAY;
/

