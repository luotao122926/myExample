create view V_CASH_TURNFEE_SALES_AMOUNT as
select sum(t1.amount) as amount
              ,t3.sales_main_type_id                  --转出营销大类ID
              ,t3.sales_main_type_code                --转出营销大类编码
              ,t3.sales_main_type_name                --转出营销大类名称
       from  T_SO_ORDER_RECEIPT              t1       --核销表
            ,T_AR_CASH_RECEIPT_HEADERS       t2       --收款头表
            ,T_AR_CASH_RECEIPT_LINES         t3       --收款行表
      where t1.cash_receipt_id = t2.cash_receipt_id
       and t2.cash_receipt_id = t3.cash_receipt_id
       and t1.to_erp_flag='N'
       group by
            t3.sales_main_type_id
           ,t3.sales_main_type_code
           ,t3.sales_main_type_name
/

