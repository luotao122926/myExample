create Package Body PKG_BD Is

  V_NL      CONSTANT VARCHAR2(2) := CHR(13) || CHR(10); --换行
  V_SUCCESS CONSTANT VARCHAR2(10) := 'SUCCESS';
  V_BASE_EXCEPTION EXCEPTION; --自定义异常
  ----------------------------------------
  /*数据权限通用策略 add by xiongpl*/
  /*
   SALES_ORG_ID  组织ID    v_bd_user_org_priv
   CUSTOMER_ID  客户ID    v_bd_user_cust_priv
   ACCOUNT_ID  账户ID      v_bd_user_acc_priv
   INV_ID  仓库ID          v_bd_user_inv_priv
   PRODUCING_AREA_ID  产地ID   v_bd_user_prodarea_priv
   SALES_MAIN_TYPE    产品大类Code   v_bd_user_itemtype_priv
   BILL_TYPE_ID      单据类型ID  v_bd_user_billtype_priv
  */
  ----------------------------------------
  function F_VPD_FOR_ALL(p_schema in varchar2 default NULL,
                       p_object in varchar2 default NULL)
    RETURN varchar2 AS
    l_mod  varchar2(48) := sys_context('userenv', 'module');             --模块
    l_table  varchar2(32) := sys_context('userenv', 'action');           --操作，一般为表名
    l_userAccountOrEntityId varchar2(64) := sys_context('userenv', 'client_identifier');  --自定义参数，一般为用户编码与主体ID
    l_userAccount varchar2(64) := ''; --用户编码
    l_UE PKG_BD_UTIL.T_VARRAY;
    l_entityId varchar2(64) := ''; --主体ID
    l_column_type  varchar2(48) := '';     --权限字段类型，如客户、仓库
    l_column_code  varchar2(48) := '';     --具体表的权限字段名，如销售单客户ID
    l_filterSql    varchar2(2500) := ' 1=1';
    --受控字段列表游标
    cursor configDetail is
      select dcd.column_type,dcd.column_code
        from t_bd_datapriv_config dc,t_bd_datapriv_config_detail dcd
       where dcd.priv_config_id = dc.priv_config_id
         and dc.table_code=l_table;
         --and dc.table_code='t_bd_price_cust_config';
    privColumn configDetail%ROWTYPE ;

  BEGIN
    --INSERT INTO T_BD_VPD_LOG VALUES( '日志时间：'||sysdate||'---传参信息10---'||l_mod||';'|| l_table || '; '||l_userAccountOrEntityId||'---拼出SQL---'||l_filterSql);
    if( l_mod ='vpdmodulename') then
      IF (l_table is null or l_table='' or l_userAccountOrEntityId is null  or  l_userAccountOrEntityId='') THEN
        l_filterSql := '1 = 2';
        --INSERT INTO T_BD_VPD_LOG VALUES( '日志时间：'||sysdate||'---传参信息11---'||l_mod||';'|| l_table || '; '||l_userAccountOrEntityId||'---拼出SQL---'||l_filterSql);
        return l_filterSql;
      END IF;

      l_UE :=PKG_BD_UTIL.str_split(l_userAccountOrEntityId,';');
      l_userAccount :=  l_UE(1);
      l_entityId := l_UE(2);


    --LOOP循环判断

     OPEN configDetail;
      LOOP
        FETCH configDetail
          INTO privColumn;
        EXIT WHEN configDetail%NOTFOUND;
        if (privColumn.column_type = 'CUSTOMER_ID') THEN
        --如果是客户 v_bd_user_cust_priv
          l_filterSql :=l_filterSql||' and '|| privColumn.column_code||' in (select customer_id from v_bd_user_cust_priv  where user_code='''|| l_userAccount ||'''and entity_id='''||l_entityId||''')';
        elsif (privColumn.column_type = 'ACCOUNT_ID') THEN
        --如果是账户 v_bd_user_acc_priv
          l_filterSql :=l_filterSql||' and '|| privColumn.column_code||' in (select account_id from v_bd_user_acc_priv  where user_code='''|| l_userAccount ||'''and entity_id='''||l_entityId||''')';
        elsif (privColumn.column_type='INV_ID') THEN
        --如果是仓库 v_bd_user_inv_priv
          l_filterSql :=l_filterSql||' and '|| privColumn.column_code||' in (select inventory_id from v_bd_user_inv_priv  where user_code='''|| l_userAccount ||'''and entity_id='''||l_entityId||''')';
        elsif (privColumn.column_type='PRODUCING_AREA_ID') THEN
        --如果是产地ID  v_bd_user_prodarea_priv
          l_filterSql :=l_filterSql||' and '|| privColumn.column_code||' in (select producing_area_id from v_bd_user_prodarea_priv  where user_code='''|| l_userAccount ||'''and entity_id='''||l_entityId||''')';
        elsif (privColumn.column_type = 'SALES_MAIN_TYPE') THEN
        --如果是产品大类 v_bd_user_itemtype_priv
          l_filterSql :=l_filterSql||' and '|| privColumn.column_code||' in (select class_code from v_bd_user_itemtype_priv  where user_code='''|| l_userAccount ||'''and entity_id='''||l_entityId||''')';
        elsif (privColumn.column_type = 'BILL_TYPE_ID') THEN
        --如果是单据类型 v_bd_user_billtype_priv
          l_filterSql :=l_filterSql||' and '|| privColumn.column_code||' in (select bill_type_id from v_bd_user_billtype_priv  where user_code='''|| l_userAccount ||'''and entity_id='''||l_entityId||''')';
        END IF;


      END LOOP;
      CLOSE configDetail;
      --INSERT INTO T_BD_VPD_LOG VALUES( '日志时间：'||sysdate||'---传参信息22---'||l_mod||';'|| l_table || '; '||l_userAccountOrEntityId||'---拼出SQL---'||l_filterSql);
      return l_filterSql;
    ELSE
      return '1=1';
    end if;


  END;

  procedure P_UPD_FULL_NAME
  --更新full_name值,去除字符串最后的'-'
  (P_TABLE_CODE      in varchar2, --表名
   P_FULLNAME_COLUMN in varchar2, --全称字段列
   P_ROWID_COLUMN    in varchar2, --row_id字段列
   P_FILTER_SQL      in varchar2, --过滤SQL
   P_RETURN_CODE     out varchar2, --返回编码
   P_RETURN_MSG      out varchar2) --返回提示信息
   is
    --查找下级节点

    type TYP_CHD_NODE is ref cursor;

    LC_CHD_NODE TYP_CHD_NODE;

    LL_CHD_NODE_ID   number(16);
    LS_FULL_NAME varchar2(1000);
    LS_PREFIX varchar2(32);

    LS_RETURN_CODE varchar2(32);
    LS_RETURN_MSG  varchar2(2000);

    LS_SELECT varchar2(1000);
    LS_UPDATE varchar2(1000);
    LS_LAST_CHAR varchar2(20);

  begin

    LS_SELECT := 'SELECT  ' || P_ROWID_COLUMN || ', ' || P_FULLNAME_COLUMN ||
                   ' from ' || P_TABLE_CODE || ' '||P_FILTER_SQL;
    open LC_CHD_NODE for LS_SELECT;

    loop
      fetch LC_CHD_NODE
        into LL_CHD_NODE_ID, LS_FULL_NAME;
      exit when LC_CHD_NODE%notfound;
      --去除最后'-'字符
      LS_LAST_CHAR := substr(LS_FULL_NAME,length(LS_FULL_NAME),1);
      if LS_LAST_CHAR='-' then
        LS_FULL_NAME :=  substr(LS_FULL_NAME,1,length(LS_FULL_NAME)-1);
      end if;
      LS_PREFIX := substr(LS_FULL_NAME,1,5);
      if LS_PREFIX<>LS_FULL_NAME and (LS_PREFIX='美的集团-' or LS_PREFIX='行政区域-' ) then
         LS_FULL_NAME := substr(LS_FULL_NAME,6);
      end if;
      if P_TABLE_CODE='t_bd_district' then
         LS_FULL_NAME := replace(LS_FULL_NAME,'西北大区','');
         LS_FULL_NAME := replace(LS_FULL_NAME,'中南大区','');
         LS_FULL_NAME := replace(LS_FULL_NAME,'华北大区','');
         LS_FULL_NAME := replace(LS_FULL_NAME,'华东大区','');
         LS_FULL_NAME := replace(LS_FULL_NAME,'东北大区','');
         LS_FULL_NAME := replace(LS_FULL_NAME,'西南大区','');
         LS_FULL_NAME := replace(LS_FULL_NAME,'-','');
      end if;

      LS_UPDATE := 'update ' || P_TABLE_CODE ||
                   ' set '||P_FULLNAME_COLUMN||' = ''' || LS_FULL_NAME || '''' ||
                   ' where ' || P_ROWID_COLUMN || ' = ' || LL_CHD_NODE_ID;
      execute immediate LS_UPDATE;
    end loop;
    close LC_CHD_NODE;
    commit;

    P_RETURN_CODE := 'success';
    P_RETURN_MSG  := '执行成功';
  exception
    when others then
      P_RETURN_CODE := 'failed';
      --P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('P_UPD_FULL_NAME',
      --                                                   sqlcode,
      --                                                   sqlerrm);
  end;

  procedure P_UPD_LEVEL_NUM_PARENT
  --当前节点作为父节点，更新其所有下级节点的分片值level_seq, level_num
  (P_TABLE_CODE      in varchar2, --表名
   P_NAME_COLUMN     in varchar2, --名称字段列
   P_FULLNAME_COLUMN in varchar2, --全称字段列
   P_ROWID_COLUMN    in varchar2, --row_id字段列
   P_PARROWID_COLUMN in varchar2, --上级ID字段列
   P_PAR_ROW_ID      in number, --上级记录ID
   P_FILTER_SQL      in varchar2, --过滤SQL
   P_RETURN_CODE     out varchar2, --返回编码
   P_RETURN_MSG      out varchar2) --返回提示信息
   as
    --查找下级节点

    type TYP_CHD_NODE is ref cursor;

    LC_CHD_NODE TYP_CHD_NODE;

    LL_CHD_NODE_ID   number(16);
    LS_CHD_NODE_NAME varchar(100);

    LL_PAR_LEVEL_SEQ number(3);
    LS_PAR_LEVEL_NUM varchar2(255);
    LS_PAR_FULL_NAME varchar2(1000);

    LL_LEVEL_SEQ number(3);
    LS_LEVEL_NUM varchar2(255);
    LS_FULL_NAME varchar2(1000);

    LS_RETURN_CODE varchar2(32);
    LS_RETURN_MSG  varchar2(2000);

    LS_SELECT varchar2(1000);
    LS_UPDATE varchar2(1000);

    LL_SQL_HANDLE integer;
    LS_SQL_STAT   varchar2(200);
    LL_RTN        integer;

    LS_LAST_CHAR varchar2(2);

  begin
/*    if P_PAR_ROW_ID = -1 then
       P_PAR_ROW_ID := null;
    end if;*/
    if P_PAR_ROW_ID is not null then

      begin

        --取父节点的分片号
        LS_SQL_STAT := 'select LEVEL_SEQ,LEVEL_NUM , '||P_FULLNAME_COLUMN||' from ' ||
                       P_TABLE_CODE || ' where ' || P_ROWID_COLUMN || ' = ' ||
                       P_PAR_ROW_ID || P_FILTER_SQL;
        execute immediate LS_SQL_STAT
          into LL_PAR_LEVEL_SEQ, LS_PAR_LEVEL_NUM, LS_PAR_FULL_NAME;

      exception
        when others then
          LS_RETURN_MSG    := sqlerrm;
          LL_PAR_LEVEL_SEQ := 0;
          LS_PAR_LEVEL_NUM := '';
          LS_PAR_FULL_NAME := '';
      end;
    end if;

    if P_PAR_ROW_ID is null then

      LS_SELECT := 'SELECT  ' || P_ROWID_COLUMN || ', ' || P_NAME_COLUMN ||
                   ' from ' || P_TABLE_CODE || ' CHD ' || 'where  ( CHD.' ||
                   P_PARROWID_COLUMN || ' is null  ) ' || P_FILTER_SQL;
    else

      LS_SELECT := 'SELECT   ' || P_ROWID_COLUMN || ', ' || P_NAME_COLUMN ||
                   ' from ' || P_TABLE_CODE || ' CHD ' || 'where CHD.' ||
                   P_PARROWID_COLUMN || ' = ' || P_PAR_ROW_ID || P_FILTER_SQL;
    end if;

    open LC_CHD_NODE for LS_SELECT;

    loop
      fetch LC_CHD_NODE
        into LL_CHD_NODE_ID, LS_CHD_NODE_NAME;
      exit when LC_CHD_NODE%notfound;

      --设置本级节点分片值
      if P_PAR_ROW_ID is not null then
        begin
          LL_LEVEL_SEQ := LL_PAR_LEVEL_SEQ + 1;
          LS_LEVEL_NUM := LS_PAR_LEVEL_NUM || LTRIM(TO_CHAR(LL_CHD_NODE_ID)) || '.';
          LS_FULL_NAME := LS_PAR_FULL_NAME || LS_CHD_NODE_NAME || '-';
        exception
          when others then
            LL_LEVEL_SEQ := 1;
            LS_LEVEL_NUM := TO_CHAR(LL_CHD_NODE_ID) || '.';
            LS_FULL_NAME := LS_CHD_NODE_NAME || '-';
        end;
      else
        LL_LEVEL_SEQ := 1;
        LS_LEVEL_NUM := TO_CHAR(LL_CHD_NODE_ID) || '.';
        LS_FULL_NAME := LS_CHD_NODE_NAME || '-';
      end if;

      if LL_LEVEL_SEQ > 12 then
        RAISE_APPLICATION_ERROR(-20001, '级次太深，超过12级！');
      end if;
      --更新当前节点分片值
      LS_UPDATE := 'update ' || P_TABLE_CODE || --
                   ' set LEVEL_SEQ = ' || LL_LEVEL_SEQ || ',' || --
                   ' LEVEL_NUM = ''' || LS_LEVEL_NUM || ''',' || --
                   ' '||P_FULLNAME_COLUMN||' = ''' || LS_FULL_NAME || '''' || --
                   ' where ' || P_ROWID_COLUMN || ' = ' || LL_CHD_NODE_ID;
      execute immediate LS_UPDATE;

      --LS_RETURN_MSG := PKG_BD.F_ADD_ERROR_LOG('P_UPD_LEVEL_NUM_PARENT',
      --                                                   LL_CHD_NODE_ID,
      --                                                   '');

      commit;
      --当前节点作为父节点，更新其所有下级节点的分片值
      P_UPD_LEVEL_NUM_PARENT(P_TABLE_CODE,
                               P_NAME_COLUMN,
                               P_FULLNAME_COLUMN,
                               P_ROWID_COLUMN,
                               P_PARROWID_COLUMN,
                               LL_CHD_NODE_ID,
                               P_FILTER_SQL,
                               LS_RETURN_CODE,
                               LS_RETURN_MSG);
      if LS_RETURN_CODE <> 'success' then
        RAISE_APPLICATION_ERROR(-20001,
                                '更新下级节点分片号出错。' || LS_RETURN_MSG);
      end if;
    end loop;
    close LC_CHD_NODE;

    P_RETURN_CODE := 'success';
    P_RETURN_MSG  := '执行成功';
    --commit;
  exception
    when others then
      P_RETURN_CODE := 'failed';
      --P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('P_UPD_LEVEL_NUM_PARENT',
      --                                                   sqlcode,
      --                                                   sqlerrm);
      --rollback;
  end;

  procedure P_UPD_LEVEL_NUM_SELF
  --更新当前节点以及下级节点分片值level_seq, level_num
  (P_TABLE_CODE     in varchar2, --表名
   P_NAME_COLUMN    in varchar2, --名称字段
   P_FULLNAME_COLUMN in varchar2, --全称字段列
   P_ROWID_COLUMN    in varchar2, --row_id字段列名
   P_PARROWID_COLUMN in varchar2, --上级ID字段列名
   P_CURRENT_ROW_ID in out number, --本记录ID
   P_FILTER_SQL      in varchar2, --过滤SQL
   P_RETURN_CODE    out varchar2, --返回码
   P_RETURN_MSG     out varchar2) --返回提示信息
   as
    --查找下级节点
    L_PAR_ROW_ID number(16);

    LL_PAR_LEVEL_SEQ number(3);
    LS_PAR_LEVEL_NUM varchar2(255);
    LS_PAR_FULL_NAME varchar2(1000);

    LL_LEVEL_SEQ number(3);
    LS_LEVEL_NUM varchar2(255);
    LS_FULL_NAME varchar2(255);

    LS_RETURN_CODE varchar2(32);
    LS_RETURN_MSG  varchar2(2000);

    LS_SELECT varchar2(1000);
    LS_UPDATE varchar2(1000);

  begin
    --取当前行值
    LS_SELECT := 'select '||P_PARROWID_COLUMN||',  ' || P_NAME_COLUMN || ' from ' ||
                 P_TABLE_CODE || ' where '||P_ROWID_COLUMN||' = ' || P_CURRENT_ROW_ID
                 || P_FILTER_SQL;
    execute immediate LS_SELECT
      into L_PAR_ROW_ID, LS_FULL_NAME;

    if L_PAR_ROW_ID is not null and L_PAR_ROW_ID != -1 then
      LS_SELECT := 'select LEVEL_SEQ,LEVEL_NUM , '||P_FULLNAME_COLUMN||' from ' ||
                   P_TABLE_CODE || ' where '||P_ROWID_COLUMN||' = ' || L_PAR_ROW_ID
                   || P_FILTER_SQL;
      --取上级节点值,并计算本级节点值
      execute immediate LS_SELECT
        into LL_PAR_LEVEL_SEQ, LS_PAR_LEVEL_NUM, LS_PAR_FULL_NAME;
      LL_LEVEL_SEQ := LL_PAR_LEVEL_SEQ + 1;
      LS_LEVEL_NUM := LS_PAR_LEVEL_NUM || LTRIM(TO_CHAR(P_CURRENT_ROW_ID)) || '.';
      LS_FULL_NAME := LS_PAR_FULL_NAME || LS_FULL_NAME || '-';
    else
      LL_LEVEL_SEQ := 1;
      LS_LEVEL_NUM := TO_CHAR(P_CURRENT_ROW_ID) || '.';
      LS_FULL_NAME := LS_FULL_NAME || '-';

    end if;

    if LL_LEVEL_SEQ > 12 then
      RAISE_APPLICATION_ERROR(-20001, '级次太深，超过12级！');
    end if;

    --更新当前节点分片值
    LS_UPDATE := 'update ' || P_TABLE_CODE || --
                 ' set LEVEL_SEQ = ' || LL_LEVEL_SEQ || ',' || --
                 ' LEVEL_NUM = ''' || LS_LEVEL_NUM || ''',' || --
                 ' '||P_FULLNAME_COLUMN||' = ''' || LS_FULL_NAME || '''' || --
                 ' where '||P_ROWID_COLUMN||' = ' || P_CURRENT_ROW_ID;
    execute immediate LS_UPDATE;

    if L_PAR_ROW_ID = -1 then
      L_PAR_ROW_ID := null;
    end if;

    P_UPD_LEVEL_NUM_PARENT(P_TABLE_CODE,
                             P_NAME_COLUMN,
                             P_FULLNAME_COLUMN,
                             P_ROWID_COLUMN,
                             P_PARROWID_COLUMN,
                             P_CURRENT_ROW_ID,
                             P_FILTER_SQL,
                             LS_RETURN_CODE,
                             LS_RETURN_MSG);
    if LS_RETURN_CODE <> 'success' then
      RAISE_APPLICATION_ERROR(-20001, LS_RETURN_MSG);
    end if;
    P_RETURN_CODE := 'success';
    P_RETURN_MSG  := '执行成功';
  exception
    when others then
      P_RETURN_CODE := 'failed';
      --P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('P_UPD_LEVEL_NUM_SELF',
      --                                                   sqlcode,
      --                                                   sqlerrm);

  end;

  procedure P_UPD_ORG_UNIT
  --更新up_org_unit扩展字段内容, add by xiongpl
  (P_FILTER_SQL      in varchar2, --过滤SQL
   P_RETURN_CODE     out varchar2, --返回编码
   P_RETURN_MSG      out varchar2) --返回提示信息
   is
    --查找下级节点

    LS_RETURN_CODE varchar2(32);
    LS_RETURN_MSG  varchar2(2000);
    L_UNIT_ID number;

    cursor entity_cur is
      select u.unit_id, u.name, u.level_num, u.full_name
        from up_org_unit u
       where u.type_code = 'BU';
    entiry_row entity_cur%ROWTYPE ;

  begin
    L_UNIT_ID := 1;
    --更新单位上级ID
    update up_org_unit u1
       set u1.par_unit_id = (select u2.unit_id
                               from up_org_dimension_unit du1,
                                    up_org_dimension_unit du2,
                                    up_org_unit           u2
                              where du1.unit_id = u1.id
                                and du1.parent_dimension_unit_id = du2.dimension_unit_id
                                and du2.unit_id = u2.id);
    update up_org_unit u1
       set u1.type_code = (select ut1.code
                             from up_org_unit_type ut1
                            where ut1.id = u1.type_id);
    commit;
    --更新单位层级信息
    P_UPD_LEVEL_NUM_SELF('up_org_unit','name','full_name','unit_id','par_unit_id',L_UNIT_ID,null,P_RETURN_CODE,P_RETURN_MSG);

    P_UPD_FULL_NAME('up_org_unit','full_name','unit_id',null,P_RETURN_CODE,P_RETURN_MSG);
   --更新单位对应主体ID
   OPEN entity_cur;
    LOOP
      FETCH entity_cur
        INTO entiry_row;
      EXIT WHEN entity_cur%NOTFOUND;

      update up_org_unit u set u.entity_id = entiry_row.unit_id
             where u.entity_id is null and u.level_num like entiry_row.level_num||'%';

    END LOOP;
    CLOSE entity_cur;
    commit;

    if P_RETURN_CODE <> 'success' then
      RAISE_APPLICATION_ERROR(-20001, P_RETURN_MSG);
    end if;

  exception
    when others then
       rollback;
       P_RETURN_CODE := 'failed';
       P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('PKG_BD.P_UPD_ORG_UNIT',
                                                         sqlcode,
                                                         '组织刷新失败：'||sqlerrm);

  end;


  procedure P_UPD_DISTINCT
  --更新t_bd_district扩展字段内容, add by xiongpl
  (P_FILTER_SQL      in varchar2, --过滤SQL
   P_RETURN_CODE     out varchar2, --返回编码
   P_RETURN_MSG      out varchar2) --返回提示信息
   is
    --查找下级节点

    LS_RETURN_CODE varchar2(32);
    LS_RETURN_MSG  varchar2(2000);

    cursor distinct_cur is
      select u.row_id
        from t_bd_district u
       where u.par_row_id= -1;
    distinct_row distinct_cur%ROWTYPE ;

  begin

   OPEN distinct_cur;
    LOOP
      FETCH distinct_cur
        INTO distinct_row;
      EXIT WHEN distinct_cur%NOTFOUND;
        --更新行政区域层级信息
        P_UPD_LEVEL_NUM_SELF('t_bd_district','district_name','full_name','row_id','par_row_id',distinct_row.row_id,null,P_RETURN_CODE,P_RETURN_MSG);

    END LOOP;
    CLOSE distinct_cur;
    P_UPD_FULL_NAME('t_bd_district','full_name','row_id',null,P_RETURN_CODE,P_RETURN_MSG);
    commit;

    if P_RETURN_CODE <> 'success' then
      RAISE_APPLICATION_ERROR(-20001, P_RETURN_MSG);
    end if;

  exception
    when others then
       rollback;
       P_RETURN_CODE := 'failed';
       P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('PKG_BD.P_UPD_DISTINCT',
                                                         sqlcode,
                                                         '行政区域刷新失败：'||sqlerrm);

  end;

  function FUN_GET_BILL_NO
  -- --取单据号  add by xiongpl
  (
   P_BILL_TYPE    T_BD_CODE_RULE.CODE_NO%type,  --编码编号CODE
   P_PREFIX_ADD   T_BD_CODE_RULE_DETAIL.DICT_CODE_VALUE%type, --动态附加前缀,除特别说明，一般为空
   P_ENTITY_ID    up_org_unit.ENTITY_ID%type, --业务主体ID
   P_USER_ID      up_org_user.user_id%type, --登录用户ID
   P_WAIT_BY      NUMBER DEFAULT NULL--
   ) --
   return varchar2 is

    LD_RULE_ID t_bd_code_rule.code_rule_id%type;
    LS_ENTITY_FLAG  t_bd_code_rule.entity_flag%type;

    LS_PREFIX_CODE     T_BD_CODE_RULE_DETAIL.DICT_CODE_VALUE%type; --固定前缀
    LS_DYN_PREFIX_CODE T_BD_CODE_RULE_DETAIL.DICT_CODE_VALUE%type; --动态前缀
    L_CURRENT_DATE        date; --当前日期
    LS_CURRENT_PERIOD     varchar2(32); --当前归零期间
    LS_SEQ_NAME   varchar2(32); --生成流水号的sequence
    LS_SERIAL_FORMAT varchar2(32); --流水号格式
    LD_VALUE        number; --流水值
    LS_RENO_CODE varchar2(100) ; --单据号重新编码串
    LS_COMBI_CODE varchar2(100) ; --单据号组合串
    L_BILL_NO varchar2(32);

    v_p1 varchar2(200);
    v_p2 varchar2(200);
    v_sql varchar2(3000);
    TYPE cur_type IS REF CURSOR;
    ruleDetail_cur   cur_type;
/*    --规则明细游标
    cursor ruleDetail_cur is
      select rd.*
        from t_bd_code_rule r,t_bd_code_rule_detail rd
       where r.code_rule_id=rd.code_rule_id
           and r.code_no = P_BILL_TYPE
           and r.active_flag = 'Y'
           and rd.active_flag = 'Y'
           order by rd.serialno;  */
    ruleDetail t_bd_code_rule_detail%ROWTYPE ;
    VN_WAIT_BY NUMBER;

  begin
    VN_WAIT_BY := P_WAIT_BY;

   if (P_BILL_TYPE is null or P_BILL_TYPE = '') then
     /*L_BILL_NO := null;
     return L_BILL_NO;*/

     RAISE_APPLICATION_ERROR(-20002, '编码为'||P_BILL_TYPE||'的编码规则没找到');

   end if;

   SELECT code_rule_id,nvl(entity_flag,'N') entity_flag into LD_RULE_ID,LS_ENTITY_FLAG from t_bd_code_rule where code_no = P_BILL_TYPE and active_flag='Y';
   v_p1 := '''' || P_BILL_TYPE || '''';
   v_p2 := '''' || P_ENTITY_ID || '''';
   if (LS_ENTITY_FLAG = 'Y') then
     v_sql := 'select rd.* from t_bd_code_rule r, t_bd_code_rule_entity re, t_bd_code_rule_detail rd  where r.code_rule_id = re.code_rule_id and r.code_no = '||v_p1||' and re.entity_id ='||v_p2||' and re.code_rule_id = rd.code_rule_id  and rd.code_rule_entity_id = re.code_rule_entity_id and r.active_flag = ''Y'' and re.active_flag = ''Y'' and rd.active_flag = ''Y'' and nvl(r.entity_flag, ''N'') = ''Y'' order by rd.serialno';
   else
     v_sql := 'select rd.* from t_bd_code_rule r, t_bd_code_rule_detail rd  where r.code_rule_id = rd.code_rule_id and r.code_no = '||v_p1||' and r.active_flag = ''Y'' and rd.active_flag = ''Y'' and nvl(r.entity_flag, ''N'') = ''N'' and rd.code_rule_entity_id is null order by rd.serialno';
   end if;

   LS_RENO_CODE :=''; --重新编码前缀
   LS_COMBI_CODE  :=''; --单据号组合串
   --查找对应的单据号规则配置
   OPEN ruleDetail_cur FOR v_sql;
   --OPEN ruleDetail_cur;
    LOOP
      FETCH ruleDetail_cur
        INTO ruleDetail;
      EXIT WHEN ruleDetail_cur%NOTFOUND;
      /*
        1  固定字符串
        2  动态前缀
        3  日期
        4  流水号
      */
      if (ruleDetail.dict_code_id = '1') THEN  --1  固定字符串
        LS_PREFIX_CODE := ruleDetail.dict_code_value;
        if ruleDetail.rockback_flag = 'Y' then
           LS_RENO_CODE := LS_RENO_CODE||LS_PREFIX_CODE;
        end if;
        LS_COMBI_CODE := LS_COMBI_CODE||LS_PREFIX_CODE;
      elsif (ruleDetail.dict_code_id = '2') THEN  --2  动态前缀
        if ruleDetail.Dict_Code_Value = '事业部编码' then
           LS_DYN_PREFIX_CODE := P_ENTITY_ID;
        else
           LS_DYN_PREFIX_CODE := P_PREFIX_ADD;
        end if ;
        if ruleDetail.rockback_flag = 'Y' then
           LS_RENO_CODE := LS_RENO_CODE||LS_DYN_PREFIX_CODE;
        end if;
        LS_COMBI_CODE := LS_COMBI_CODE||LS_DYN_PREFIX_CODE;
      elsif (ruleDetail.dict_code_id = '3') THEN   --3  日期
         /* MMdd、yyMM、yyyyMMdd、yyMMdd、yyyy、yyyyMM  */
        L_CURRENT_DATE := sysdate;
        LS_CURRENT_PERIOD := TO_CHAR(L_CURRENT_DATE, ruleDetail.dict_code_value);
        if ruleDetail.rockback_flag = 'Y' then
           LS_RENO_CODE := LS_RENO_CODE||LS_CURRENT_PERIOD;
        end if;
        LS_COMBI_CODE := LS_COMBI_CODE||LS_CURRENT_PERIOD;
      elsif (ruleDetail.dict_code_id = '4') THEN    --4  流水号
        if ruleDetail.dict_code_value > 0 then
          LS_SERIAL_FORMAT := RTRIM(LTRIM(LPAD('0', ruleDetail.dict_code_value, '0')));
        else
          LS_SERIAL_FORMAT := '0';
        end if;
        LS_SEQ_NAME := ruleDetail.Seq_Name; --生成流水号的sequence
      END IF;

    END LOOP;
    CLOSE ruleDetail_cur;

    if (LS_RENO_CODE = '' or LS_RENO_CODE is null) then
        LS_RENO_CODE :='NULL';
    end if ;

    begin
       if ( LS_SEQ_NAME is null) then
       --通过自已记录产生流水号
       IF VN_WAIT_BY IS NULL THEN
         BEGIN
           --如果传入FOR Update 超时参数为空，获取系统参数
            P_GET_PARAMETER_VALUE('BD_FOR_UPDATE_WAIT_CODE_CURRENT',
                                         P_ENTITY_ID,
                                         NULL,
                                         NULL,
                                         VN_WAIT_BY);
          EXCEPTION
            WHEN OTHERS THEN
              VN_WAIT_BY := NULL; --默认值
          END;
       END IF;
       IF VN_WAIT_BY IS NULL OR VN_WAIT_BY <= 0 THEN
          select current_code
            into LD_VALUE
            from t_bd_code_current
           where rockback_com = LS_RENO_CODE and
                 code_rule_id = LD_RULE_ID
             for update;
       ELSE
         execute immediate 'select current_code from t_bd_code_current where rockback_com = :v1'
         || ' and code_rule_id = :v2 for update wait ' || VN_WAIT_BY
           into LD_VALUE
           using LS_RENO_CODE,LD_RULE_ID--,VN_WAIT_BY-- OUT LD_VALUE
           ;
         
       END IF;

          LD_VALUE := LD_VALUE + 1;
          update t_bd_code_current
               set current_code  = LD_VALUE
             where rockback_com = LS_RENO_CODE and
                   code_rule_id =  LD_RULE_ID;
       else
       --如果是通过序列生成流水号
          execute immediate 'select '||LS_SEQ_NAME||'.nextval from dual'  into LD_VALUE;
          --dbms_output.put_line(LS_SEQ_NAME ||'的seq值：'||to_char(LD_VALUE));
       end if;

    exception
      when NO_DATA_FOUND then

            LD_VALUE := 1;
            insert into t_bd_code_current
              (code_current_id,
               code_rule_id,
               rockback_com,
               combi_code,
               current_code,
               active_flag)
            values
              (seq_bd_row_id.nextval,
               LD_RULE_ID,
               LS_RENO_CODE,
               LS_COMBI_CODE,
               LD_VALUE,
               'Y');
    end;
    --commit;
    --dbms_lock.sleep(2);--休眠X秒 压力测试使用
    --单据号
    L_BILL_NO := LS_COMBI_CODE||RTRIM(LTRIM(TO_CHAR(LD_VALUE, LS_SERIAL_FORMAT)));
    return L_BILL_NO;

  end FUN_GET_BILL_NO;

  function F_GET_BILL_NO
  -- --取单据号  add by xiongpl
  (P_BILL_TYPE  T_BD_CODE_RULE.CODE_NO%type, --编码编号CODE
   P_PREFIX_ADD T_BD_CODE_RULE_DETAIL.DICT_CODE_VALUE%type, --动态附加前缀,除特别说明，一般为空
   P_ENTITY_ID  up_org_unit.ENTITY_ID%type, --业务主体ID
   P_USER_ID    up_org_user.user_id%type, --登录用户ID
   P_WAIT_BY    NUMBER DEFAULT NULL --
   ) --
   return varchar2 is
  BEGIN
    BEGIN
      RETURN FUN_GET_BILL_NO(P_BILL_TYPE,
                             P_PREFIX_ADD,
                             P_ENTITY_ID,
                             P_USER_ID,
                             P_WAIT_BY);
    
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        RETURN FUN_GET_BILL_NO(P_BILL_TYPE,
                               P_PREFIX_ADD,
                               P_ENTITY_ID,
                               P_USER_ID,
                               NVL(P_WAIT_BY,2));
      WHEN OTHERS THEN
        IF SQLCODE IN (-51,-54,-30006) THEN
          IF 0 < P_WAIT_BY THEN
            BEGIN
              RETURN FUN_GET_BILL_NO(P_BILL_TYPE,
                                     P_PREFIX_ADD,
                                     P_ENTITY_ID,
                                     P_USER_ID, 2 * P_WAIT_BY);
            EXCEPTION
              WHEN TIMEOUT_ON_RESOURCE THEN
                RETURN FUN_GET_BILL_NO(P_BILL_TYPE,
                                       P_PREFIX_ADD,
                                       P_ENTITY_ID,
                                       P_USER_ID);
            END;
          ELSE
            --如果定义系统参数，也可能发生超时
            RETURN FUN_GET_BILL_NO(P_BILL_TYPE,
                                   P_PREFIX_ADD,
                                   P_ENTITY_ID,
                                   P_USER_ID);
          END IF;
        END IF;
    END;
  end F_GET_BILL_NO;

  --取系统参数值
  function F_GET_PARAMETER_VALUE
  (
   P_CONFIG_CODE    t_bd_param_list.param_code%type,  --参数配置编码
   P_ENTITY_ID      up_org_unit.ENTITY_ID%type, --业务主体ID
   P_UNIT_ID        up_org_unit.Unit_Id%type default null, --中心ID
   P_CUSTOMER_ID    t_customer_header.customer_id%type default null --客户ID
   ) --
   return varchar2 is

    LS_PARAM_VALUE t_bd_param_list.default_value%type;
    paramList t_bd_param_list%ROWTYPE ;
    paramEntity t_bd_param_entity%ROWTYPE ;
    entityDetail t_bd_param_entity_detail%ROWTYPE ;
    LSE_NUM number;--记录是否查询到系统参数

  begin
    select count(*) into LSE_NUM from t_bd_param_list pl where pl.param_code=P_CONFIG_CODE and pl.active_flag='Y';

    if LSE_NUM = 0 then
        RAISE_APPLICATION_ERROR(-20001, '编码为'||P_CONFIG_CODE||'的系统参数没找到');
    end if;

    select pl.* into paramList from t_bd_param_list pl where pl.param_code=P_CONFIG_CODE and pl.active_flag='Y';

    --1、如果与主体无关，取默认值
    if (paramList.Entity_Flag is null or paramList.Entity_Flag = 'N') then
      LS_PARAM_VALUE := paramList.Default_Value;
      return LS_PARAM_VALUE;
    end if;

    --2、如果与主体相关，但与中心客户无关，取主体参数值
    begin
      select pe.* into paramEntity from t_bd_param_entity pe
         where pe.param_list_id=paramList.Param_List_Id
            and pe.entity_id = P_ENTITY_ID
            and pe.active_flag='Y';
      if (paramEntity.Org_Cust_Flag is null or paramEntity.Org_Cust_Flag = 'N') then
        LS_PARAM_VALUE := paramEntity.Entity_Value;
        return LS_PARAM_VALUE;
      end if;
    exception
        when NO_DATA_FOUND then
        LS_PARAM_VALUE := paramList.Default_Value;
        return LS_PARAM_VALUE;
    end;

    --3、如果与主体相关，且与中心客户有关，取中心客户参数值
    --3.1 如果参数中既传了中心，又传了客户
    if (P_UNIT_ID is not null and P_CUSTOMER_ID is not null) then

      begin
        select ed.* into entityDetail from t_bd_param_entity_detail ed
           where ed.param_entity_id=paramEntity.Param_Entity_Id
              and ed.entity_id =  P_ENTITY_ID
              and ed.sales_center_id = P_UNIT_ID
              and ed.customer_id = P_CUSTOMER_ID
              and ed.active_flag = 'Y';
      exception
        when NO_DATA_FOUND Then
          Begin
        --3.1.1 如果没找到，则找中心的配置
          select ed.* into entityDetail from t_bd_param_entity_detail ed
           where ed.param_entity_id=paramEntity.Param_Entity_Id
              and ed.entity_id =  P_ENTITY_ID
              and ed.sales_center_id = P_UNIT_ID
              And ed.customer_id Is Null
              and ed.active_flag = 'Y';
          Exception
            when NO_DATA_FOUND Then
              --3.1.1.1中心配置也没有找到，找主体配置 lilh6 2018-10-16
              begin
                select pe.* into paramEntity from t_bd_param_entity pe
                   where pe.param_list_id=paramList.Param_List_Id
                      and pe.entity_id = P_ENTITY_ID
                      and pe.active_flag='Y';
                LS_PARAM_VALUE := paramEntity.Entity_Value;
                return LS_PARAM_VALUE;
              exception
                  when NO_DATA_FOUND then
                  LS_PARAM_VALUE := paramList.Default_Value;
                  return LS_PARAM_VALUE;
              end;
          End;
      end;
      LS_PARAM_VALUE := entityDetail.Param_Value;

    else
    --3.2 如果参数中只传了中心
      begin
        select ed.* into entityDetail from t_bd_param_entity_detail ed
         where ed.param_entity_id=paramEntity.Param_Entity_Id
            and ed.entity_id =  P_ENTITY_ID
            and ed.sales_center_id = P_UNIT_ID
            and ed.active_flag = 'Y'
            and ed.customer_id is null;
      exception
        when NO_DATA_FOUND Then
          --3.2.1 中心配置也没有找到，找主体配置 lilh6 2018-10-16
          begin
            select pe.* into paramEntity from t_bd_param_entity pe
               where pe.param_list_id=paramList.Param_List_Id
                  and pe.entity_id = P_ENTITY_ID
                  and pe.active_flag='Y';
            LS_PARAM_VALUE := paramEntity.Entity_Value;
            return LS_PARAM_VALUE;
          exception
              when NO_DATA_FOUND then
              LS_PARAM_VALUE := paramList.Default_Value;
              return LS_PARAM_VALUE;
          end;          
      End;
      LS_PARAM_VALUE := entityDetail.Param_Value;
    end if;

    return LS_PARAM_VALUE;

/*    exception
       when others then
        LS_PARAM_VALUE := 'error';
  */
  END;

  procedure P_GET_BILL_NO
  -- --取单据号
  (
   P_BILL_TYPE    T_BD_CODE_RULE.CODE_NO%type,  --编码编号CODE
   P_PREFIX_ADD   T_BD_CODE_RULE_DETAIL.DICT_CODE_VALUE%type, --动态附加前缀,除特别说明，一般为空
   P_ENTITY_ID    up_org_unit.ENTITY_ID%type, --业务主体ID
   P_USER_ID      up_org_user.user_id%type, --登录用户ID
   P_BILL_NO      out varchar2, --返回的单据号
   P_WAIT_BY      IN NUMBER DEFAULT NULL--
   )

   is

  begin
    P_BILL_NO := F_GET_BILL_NO(P_BILL_TYPE, P_PREFIX_ADD, P_ENTITY_ID, P_USER_ID, P_WAIT_BY);
  end;


  procedure P_GET_PARAMETER_VALUE
  --取系统参数值
  (
   P_CONFIG_CODE    t_bd_param_list.param_code%type,  --参数配置编码
   P_ENTITY_ID      up_org_unit.ENTITY_ID%type, --业务主体ID
   P_UNIT_ID        up_org_unit.Unit_Id%type default null, --中心ID
   P_CUSTOMER_ID    t_customer_header.customer_id%type default null, --客户ID
   P_PARAM_VALUE      out varchar2 --返回的单据号
   )   is

  begin
    P_PARAM_VALUE := F_GET_PARAMETER_VALUE(P_CONFIG_CODE, P_ENTITY_ID, P_UNIT_ID, P_CUSTOMER_ID);
  end;

  function F_ADD_ERROR_LOG
  ----后台运行错误日志记录
  (P_ERROR_FROM  in varchar2, --错误发生来源
   P_ERROR_CODE in varchar2, --错误代码
   P_ERROR_DESC in varchar2) --错误信息
   return varchar2
  --
   is
    L_RETURN_MSG varchar2(255);
    pragma autonomous_transaction;

  begin

    --启用独立事务
    begin
      --插入错误日志
      insert into T_BD_ERROR_LOG
        (ROW_ID,
         ERROR_CODE,
         ERROR_FROM,
         ERROR_DATE,
         ERROR_DESC,
         CREATED_DATE)
        select S_BD_EEROR_LOG.NEXTVAL,
               SUBSTRB(P_ERROR_CODE, 1, 50),
               SUBSTRB(P_ERROR_FROM, 1, 300),
               sysdate,
               SUBSTRB(P_ERROR_DESC, 1, 4000),
               sysdate
          from DUAL;
      commit;

    exception
      when others then
        rollback;
    end;

    if UPPER(P_ERROR_DESC) like 'ORA-%' then
      L_RETURN_MSG := SUBSTRB(SUBSTRB(P_ERROR_DESC, INSTRB(P_ERROR_DESC, ':') + 2), 1, 254);
    else
      L_RETURN_MSG := SUBSTRB(P_ERROR_DESC, 1, 254);
    end if;
    return L_RETURN_MSG;
  end;

  procedure P_MONTH_ITEM_COST
  -- 生成指定月份的销售成本

  --工厂人工 = 材料成本*（1+工费率）
  --销售成本 = 材料成本 + 制造费用 + 工厂人工

  (
   P_MONTH         in varchar2,  --年月：如:201407
  -- P_UPDATE_CNT     out number,
   P_RETURN_CODE     out varchar2, --返回编码
   P_RETURN_MSG      out varchar2) --返回提示信息
   is
    TEMP_ITEM_CODE t_bd_item_cost.item_code%type;--临时变量，产品编码
    TEMP_ITEM_ID t_bd_item_cost.item_id%TYPE;--临时变量，产品ID
    TEMP_ITEM_NAME t_bd_item_cost.item_name%TYPE;--临时变量，产品名称
    TEMP_ITEM_UOM t_bd_item.defaultunit%TYPE;----临时变量，产品单位
    TEMP_MTL_COST t_bd_item_cost.item_cost%type; --临时变量，材料成本
    TEMP_MANUFACTURE_COST t_bd_price_cost_rate.manufacture_cost%type; --临时变量，材料成本
    TEMP_EXPECT_RATE t_bd_price_cost_rate.expect_rate%type; --临时变量，预计工费率
    TEMP_ACTUAL_RATE t_bd_price_cost_rate.actual_rate%type;--临时变量，实际工费率

    TEMP_PRICE_COST_NUM number;--查找当月已生成销售成本的记录
    TEMP_ITEM_COST_NUM number; --通过判断指定月份是否配置工费率
    RT_UPDATE_NUM number;--update记录条数
    RT_INSERT_NUM number;--update记录条数

    --查询产品成本游标
    cursor c_item_cost is
      select ic.*
        from t_bd_item_cost ic;
     TEMP_ITEM_COST_ROW c_item_cost%ROWTYPE;--临时变量，记录成本表一条记录

  BEGIN
    RT_UPDATE_NUM := 0 ;
    RT_INSERT_NUM := 0 ;
    --1、判断是否维护当月工费率
    SELECT count(1) into TEMP_ITEM_COST_NUM from (select distinct(bi.sales_sub_type) from T_BD_ITEM_COST bic,t_bd_item bi where bi.item_code=bic.item_code
                                      MINUS
                                      select pcr.sales_sub_type from T_BD_PRICE_COST_RATE pcr where pcr.cost_month=P_MONTH and pcr.active_flag='Y');
    if (TEMP_ITEM_COST_NUM > 0) THEN --如果没有维护
        P_RETURN_CODE := 'failed';
        P_RETURN_MSG  := '没有维护'||P_MONTH||'月份的工费率';
        return;
    END IF;


    --2、判断该产品是否已有生成当月销售成本
    BEGIN

    OPEN c_item_cost;    --打开游标
    LOOP
    FETCH c_item_cost INTO TEMP_ITEM_COST_ROW;
    EXIT WHEN c_item_cost%NOTFOUND;

    --获取该产品编码
    TEMP_ITEM_CODE := TEMP_ITEM_COST_ROW.ITEM_CODE;
    --获取该产品编码的材料成本、制造费用、预计工费率、实际工费率
    select item.item_id,item.item_name,item.defaultunit,nvl(ic.item_cost,0),nvl(pcr.manufacture_cost,0),nvl(pcr.expect_rate,0),nvl(pcr.actual_rate,0) INTO TEMP_ITEM_ID,TEMP_ITEM_NAME,TEMP_ITEM_UOM, TEMP_MTL_COST,TEMP_MANUFACTURE_COST,TEMP_EXPECT_RATE,TEMP_ACTUAL_RATE from  t_bd_item_cost ic, t_bd_item item, t_bd_price_cost_rate pcr where item.item_code = ic.item_code and item.sales_sub_type = pcr.sales_sub_type and item.item_code = TEMP_ITEM_CODE and pcr.cost_month = P_MONTH;


    select count(2) INTO TEMP_PRICE_COST_NUM from dual where exists(SELECT * FROM t_bd_price_cost pc WHERE pc.item_code=TEMP_ITEM_CODE);

    IF TEMP_PRICE_COST_NUM >0 THEN
      RT_UPDATE_NUM :=RT_UPDATE_NUM +1;
      --2.1如果已生成，则更新
      UPDATE T_BD_PRICE_COST pc SET
         pc.uom_code=TEMP_ITEM_UOM,
         pc.MTL_COST = TEMP_MTL_COST,
         pc.manufacture_cost = TEMP_MANUFACTURE_COST,
         pc.EXPECT_RATE = TEMP_EXPECT_RATE,
         pc.ACTUAL_RATE = TEMP_ACTUAL_RATE,
         pc.expect_work_cost = TEMP_MTL_COST*(1+TEMP_EXPECT_RATE),
         pc.actual_work_cost = TEMP_MTL_COST*(1+TEMP_ACTUAL_RATE),
         pc.expect_price =TEMP_MTL_COST+TEMP_MANUFACTURE_COST+TEMP_MTL_COST*(1+TEMP_EXPECT_RATE),
         pc.actual_price =TEMP_MTL_COST+TEMP_MANUFACTURE_COST+TEMP_MTL_COST*(1+TEMP_ACTUAL_RATE)
      where pc.cost_month = P_MONTH and pc.item_code = TEMP_ITEM_CODE;

    ELSE
      RT_INSERT_NUM :=RT_INSERT_NUM +1;
      --2.2 如果没有生成，则插入
      insert into T_BD_PRICE_COST
      (PRICE_COST_ID,
       ITEM_ID,
       ITEM_CODE,
       ITEM_NAME,
       UOM_CODE，--产品单位
       MTL_COST,       --材料成本
       MANUFACTURE_COST, --制造费用
       COST_MONTH,     --成本月
       EXPECT_RATE,    --预计工费率
       ACTUAL_RATE,    --实际工费率
       EXPECT_WORK_COST, --预计人工成本
       ACTUAL_WORK_COST,--实际人工成本
       EXPECT_PRICE,--预计销售成本
       ACTUAL_PRICE --实际销售成本
       )
       VALUES
       (
       seq_bd_row_id.nextval,
       TEMP_ITEM_ID,
       TEMP_ITEM_CODE,
       TEMP_ITEM_NAME,
       TEMP_ITEM_UOM，
       TEMP_MTL_COST,
       TEMP_MANUFACTURE_COST,
       P_MONTH,
       TEMP_EXPECT_RATE,
       TEMP_ACTUAL_RATE,
       TEMP_MTL_COST*(1+TEMP_EXPECT_RATE),
       TEMP_MTL_COST*(1+TEMP_ACTUAL_RATE),
       TEMP_MTL_COST+TEMP_MANUFACTURE_COST+TEMP_MTL_COST*(1+TEMP_EXPECT_RATE),
       TEMP_MTL_COST+TEMP_MANUFACTURE_COST+TEMP_MTL_COST*(1+TEMP_ACTUAL_RATE)
       );
    END IF;

    END LOOP;
    commit;
    CLOSE c_item_cost; --关闭游标

   END;
    P_RETURN_CODE := 'succesed';
    P_RETURN_MSG :='成功引入销售成本：新增' ||RT_INSERT_NUM||'条，修改'||RT_UPDATE_NUM||'条';
   exception
      when others then
       rollback;
       P_RETURN_CODE := 'failed';
       P_RETURN_MSG  := PKG_BD.F_ADD_ERROR_LOG('PKG_BD.P_MONTH_ITEM_COST',
                                                         sqlcode,
                                                         '销售成本计算失败'||sqlerrm);

 END;

  --取打印抬头
  /* 涉及模块
    仓储：  发货确认，调拨打印，盘点单制单打印
    物流：  运输合同、发货通知单
    销售：  销售单、退货单、折让单
  */
  function F_GET_PRINT_TITLE
  (
   P_INV_ID        t_inv_inventories.inventory_id%type  --仓库ID
   ) --
   return varchar2 is
    --BD_OU_100910_TITLE    广东美的制冷设备有限公司
    --BD_OU_101002_TITLE    广东美的集团芜湖制冷设备
    ls_ou_code t_inv_organization.operating_unit_code%type;
    ls_print_title varchar(500);
  begin
    /*--1、根据仓库ID取OU
    select g.operating_unit_code into ls_ou_code
      from t_inv_inventories v, t_inv_organization g
     where v.organization_id = g.organization_id
        and v.inventory_id = P_INV_ID;
    --2、根据OU取配置的打印抬头
    if (ls_ou_code = '100910') then
       ls_print_title :=pkg_bd.F_GET_PARAMETER_VALUE('BD_OU_100910_TITLE',null);
    elsif (ls_ou_code = '101002') then
       ls_print_title :=pkg_bd.F_GET_PARAMETER_VALUE('BD_OU_101002_TITLE',null);
    else
       ls_print_title :='广东美的制冷设备有限公司';
    end if;

    return ls_print_title;
    */
    select g.print_header into ls_print_title
      from t_inv_inventories v, t_bd_print_header g
     where v.organization_code = g.organization_code
           and v.entity_id =g.entity_id
        and v.inventory_id = P_INV_ID;
     if (ls_print_title is null ) then
          ls_print_title :='库存组织没有维护打印标题，请联系管理员！';
     end if;
       return ls_print_title;

    exception
       when others then
        ls_print_title := 'error';

  end;

  -----------------------------------------------------------------------------
  --将行政区域接口表写正式表（不允许出错）
  -----------------------------------------------------------------------------
  PROCEDURE P_INTF_TO_DISTRICT_NO_ERR
  (
    IN_BATCH_ID   NUMBER   --批次ID
  )
  IS
  BEGIN
    --更新要修改的行政区域
    UPDATE
      T_BD_DISTRICT D
    SET
      (DISTRICT_NAME,AREA_NUM,ZIP_CODE,PAR_ROW_ID,ACTIVE_FLAG,LAST_UPD_BY,LAST_UPD_DATE) = 
      (
        SELECT
          REGION_NAME DISTRICT_NAME
          ,AREA_CODE AREA_NUM
          ,ZIP_CODE
          ,(
            SELECT
              NVL(D.ROW_ID,-1)
            FROM
              T_BD_DISTRICT D 
            WHERE
              D.DISTRICT_CODE = I.PREGION_CODE
          ) PAR_ROW_ID
          ,DECODE(USABLE,1,'Y','N') ACTIVE_FLAG --1表示有效
          ,'program' LAST_UPD_BY
          ,SYSDATE LAST_UPD_DATE
        FROM
          INTF_BD_DISTRICT I
        WHERE
          I.INTF_BATCH = IN_BATCH_ID
          AND I.REGION_CODE = D.DISTRICT_CODE
      )
    WHERE
      EXISTS(
        SELECT
          1
        FROM
          INTF_BD_DISTRICT I
        WHERE
          I.INTF_BATCH = IN_BATCH_ID
          AND I.REGION_CODE = D.DISTRICT_CODE
      );
      
    --新增行政区域，需按树结构顺序插入，否则可能会找不到父节点
    --按层级循环插入数据
    FOR R_INTF IN
    (
      SELECT DISTINCT
        AREA_LEVEL
      FROM
        INTF_BD_DISTRICT I
      WHERE
        INTF_BATCH = IN_BATCH_ID
        AND USABLE = 1
        AND NOT EXISTS(
          SELECT
            1
          FROM
            T_BD_DISTRICT D
          WHERE
            D.DISTRICT_CODE = I.REGION_CODE
        )
      ORDER BY
        AREA_LEVEL
    )
    LOOP
      INSERT INTO T_BD_DISTRICT
      (
        ROW_ID
        ,DISTRICT_CODE
        ,DISTRICT_NAME
        ,PAR_ROW_ID
        ,AREA_NUM
        ,ZIP_CODE
        ,CREATED_BY
        ,CREATED_DATE
        ,LAST_UPD_BY
        ,LAST_UPD_DATE
        ,ACTIVE_FLAG
      )
      SELECT
        SEQ_BD_ROW_ID.NEXTVAL ROW_ID
        ,REGION_CODE DISTRICT_CODE
        ,REGION_NAME DISTRICT_NAME
        ,(
          SELECT
            NVL(D.ROW_ID,-1)
          FROM
            T_BD_DISTRICT D 
          WHERE
            D.DISTRICT_CODE = I.PREGION_CODE
        ) PAR_ROW_ID
        ,AREA_CODE AREA_NUM
        ,ZIP_CODE
        ,CREATED_BY
        ,SYSDATE CREATED_DATE
        ,LAST_UPDATED_BY LAST_UPD_BY
        ,SYSDATE LAST_UPD_DATE
        ,'Y' ACTIVE_FLAG
      FROM
        INTF_BD_DISTRICT I
      WHERE
        INTF_BATCH = IN_BATCH_ID
        AND AREA_LEVEL = R_INTF.AREA_LEVEL
        AND NOT EXISTS(
          SELECT
            1
          FROM
            T_BD_DISTRICT D
          WHERE
            D.DISTRICT_CODE = I.REGION_CODE
        );
    END LOOP;
    
  END P_INTF_TO_DISTRICT_NO_ERR;

  -----------------------------------------------------------------------------
  --将行政区域接口表写正式表（允许出错，出错信息写接口表）
  -----------------------------------------------------------------------------
  PROCEDURE P_INTF_TO_DISTRICT_AL_ERR
  (
    IN_BATCH_ID   NUMBER   --批次ID
  )
  IS
    S_MESSAGE VARCHAR2(400);
  BEGIN
    --更新接口表状态
    UPDATE
      INTF_BD_DISTRICT
    SET
      OPERSTATUS = '2'
    WHERE
      INTF_BATCH = IN_BATCH_ID;
    
    --更新要修改的行政区域
    FOR R_INTF IN
    (
      SELECT
        INTF_ID
        ,REGION_CODE DISTRICT_CODE
        ,REGION_NAME DISTRICT_NAME
        ,AREA_CODE AREA_NUM
        ,ZIP_CODE
        ,DECODE(USABLE,1,'Y','N') ACTIVE_FLAG --1表示有效
        ,(
          SELECT
            NVL(D.ROW_ID,-1)
          FROM
            T_BD_DISTRICT D 
          WHERE
            D.DISTRICT_CODE = I.PREGION_CODE
        ) PAR_ROW_ID
      FROM
        INTF_BD_DISTRICT I
      WHERE
        INTF_BATCH = IN_BATCH_ID
    )
    LOOP
      BEGIN
        --更新数据
        UPDATE
          T_BD_DISTRICT
        SET
          DISTRICT_NAME = R_INTF.DISTRICT_NAME
          ,AREA_NUM = R_INTF.AREA_NUM
          ,ZIP_CODE = R_INTF.ZIP_CODE
          ,PAR_ROW_ID = R_INTF.PAR_ROW_ID
          ,ACTIVE_FLAG = R_INTF.ACTIVE_FLAG
          ,LAST_UPD_BY = 'program'
          ,LAST_UPD_DATE = SYSDATE
        WHERE
          DISTRICT_CODE = R_INTF.DISTRICT_CODE;
        --更新接口表
        UPDATE
          INTF_BD_DISTRICT
        SET
          OPERSTATUS = '0' 
        WHERE
          INTF_ID = R_INTF.INTF_ID;
      EXCEPTION
        WHEN OTHERS THEN
          --出错信息更新接口表
          S_MESSAGE := SUBSTRB(SQLERRM,1,400);
          UPDATE
            INTF_BD_DISTRICT
          SET
            OPERSTATUS = '1' 
            ,ERROR_MSG = S_MESSAGE
            ,ERROR_TIMES = NVL(ERROR_TIMES,0)+1
          WHERE
            INTF_ID = R_INTF.INTF_ID;
      END;
    END LOOP;
      
    --新增行政区域，需按树结构顺序插入，否则可能会找不到父节点
    --按层级循环插入数据
    FOR R_LEVEL IN
    (
      SELECT DISTINCT
        AREA_LEVEL
      FROM
        INTF_BD_DISTRICT I
      WHERE
        INTF_BATCH = IN_BATCH_ID
        AND USABLE = 1
        AND NOT EXISTS(
          SELECT
            1
          FROM
            T_BD_DISTRICT D
          WHERE
            D.DISTRICT_CODE = I.REGION_CODE
        )
      ORDER BY
        AREA_LEVEL
    )
    LOOP
      FOR R_INTF IN
      (
        SELECT
          INTF_ID
          ,REGION_CODE DISTRICT_CODE
          ,REGION_NAME DISTRICT_NAME
          ,(
            SELECT
              NVL(D.ROW_ID,-1)
            FROM
              T_BD_DISTRICT D 
            WHERE
              D.DISTRICT_CODE = I.PREGION_CODE
          ) PAR_ROW_ID
          ,AREA_CODE AREA_NUM
          ,ZIP_CODE
          ,AREA_LEVEL LEVEL_SEQ
          ,CREATED_BY
          ,LAST_UPDATED_BY
        FROM
          INTF_BD_DISTRICT I
        WHERE
          INTF_BATCH = IN_BATCH_ID
          AND AREA_LEVEL = R_LEVEL.AREA_LEVEL
          AND USABLE = 1
          AND NOT EXISTS(
            SELECT
              1
            FROM
              T_BD_DISTRICT D
            WHERE
              D.DISTRICT_CODE = I.REGION_CODE
          )
      )
      LOOP
        BEGIN
          --插入数据
          INSERT INTO T_BD_DISTRICT
          (
            ROW_ID
            ,DISTRICT_CODE
            ,DISTRICT_NAME
            ,PAR_ROW_ID
            ,AREA_NUM
            ,ZIP_CODE
            ,CREATED_BY
            ,CREATED_DATE
            ,LAST_UPD_BY
            ,LAST_UPD_DATE
            ,ACTIVE_FLAG
          )
          SELECT
            SEQ_BD_ROW_ID.NEXTVAL ROW_ID
            ,R_INTF.DISTRICT_CODE
            ,R_INTF.DISTRICT_NAME
            ,R_INTF.PAR_ROW_ID
            ,R_INTF.AREA_NUM
            ,R_INTF.ZIP_CODE
            ,R_INTF.CREATED_BY
            ,SYSDATE CREATED_DATE
            ,R_INTF.LAST_UPDATED_BY LAST_UPD_BY
            ,SYSDATE LAST_UPD_DATE
            ,'Y' ACTIVE_FLAG
          FROM
            DUAL;
          --更新接口表
          UPDATE
            INTF_BD_DISTRICT
          SET
            OPERSTATUS = '0' 
          WHERE
            INTF_ID = R_INTF.INTF_ID;
        EXCEPTION
          WHEN OTHERS THEN
            --出错信息更新接口表
            S_MESSAGE := SUBSTRB(SQLERRM,1,400);
            UPDATE
              INTF_BD_DISTRICT
            SET
              OPERSTATUS = '1' 
              ,ERROR_MSG = S_MESSAGE
              ,ERROR_TIMES = NVL(ERROR_TIMES,0)+1
            WHERE
              INTF_ID = R_INTF.INTF_ID;
        END;
      END LOOP;
    END LOOP;
    
  END P_INTF_TO_DISTRICT_AL_ERR;

  -----------------------------------------------------------------------------
  --将行政区域接口表写正式表
  -----------------------------------------------------------------------------
  PROCEDURE P_INTF_TO_DISTRICT
  (
    IN_BATCH_ID   NUMBER   --批次ID
    ,IS_ALLOW_ERR VARCHAR2 --是否允许出错，Y：允许（将出错记录接口表中）；N：不允许（全部回滚，性能较佳）
    ,OS_MESSAGE   OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  )
  IS
    S_OPERSTATUS VARCHAR2(2);
    S_STEP VARCHAR2(40);
  BEGIN
    SAVEPOINT SP_INTF_TO_DISTRICT; 
    
    --锁接口表（只取一条记录，以优化性能）
    S_STEP := '锁接口表';
    BEGIN
      SELECT
        OPERSTATUS
      INTO
        S_OPERSTATUS
      FROM
        INTF_BD_DISTRICT
      WHERE
        INTF_BATCH = IN_BATCH_ID
        AND ROWNUM = 1
      FOR UPDATE NOWAIT;      
      OS_MESSAGE := 'OK';
    EXCEPTION
      WHEN OTHERS THEN
        OS_MESSAGE := '锁定接口表不成功！请稍后再试。';
    END;
    
    --更新要修改的行政区域
    IF OS_MESSAGE = 'OK' THEN
      IF IS_ALLOW_ERR = 'Y' THEN
        --允许出错
        S_STEP := '写正式表(允许出错)';
        P_INTF_TO_DISTRICT_AL_ERR(IN_BATCH_ID);
      ELSE
        --不允许出错
        S_STEP := '写正式表(不允许出错)';
        P_INTF_TO_DISTRICT_NO_ERR(IN_BATCH_ID);
      END IF;
      
      --由于CMDM没有中国层级，暂时先将空的上级改为中国，CMDM改好程序后要取消该处理
      UPDATE
        T_BD_DISTRICT
      SET
        PAR_ROW_ID = 11383431
        ,LAST_UPD_DATE = SYSDATE
      WHERE
        PAR_ROW_ID IS NULL
        AND DISTRICT_CODE LIKE '1%';
      
      --更新行政区域相关信息
      S_STEP := '更新行政区域相关信息';
      P_UPDATE_DISTRICT_INFO;
    END IF;
    
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO SAVEPOINT SP_INTF_TO_DISTRICT;
      OS_MESSAGE := SUBSTRB(S_STEP || ' 出错：' || SQLERRM, 1, 400);
  END P_INTF_TO_DISTRICT;

  -----------------------------------------------------------------------------
  --根据树形结构关系新全称、层级等信息
  -----------------------------------------------------------------------------
  PROCEDURE P_UPDATE_DISTRICT_INFO
  IS
    S_LEVEL_NUM VARCHAR2(100);
    S_FULL_NAME VARCHAR2(200);
    TYPE T_VARRAY IS VARRAY(6) OF VARCHAR2(200);
    V_DISTRICT_NAME T_VARRAY := T_VARRAY('','','','','','');
    V_FULL_NAME T_VARRAY := T_VARRAY('','','','','','');
    V_LEVEL_NUM T_VARRAY := T_VARRAY('','','','','','');
  BEGIN
    FOR R_D IN
    (
      SELECT
        ROW_ID
        ,DISTRICT_NAME
        ,FULL_NAME
        ,LEVEL_NUM
        ,LEVEL_SEQ
        ,LEVEL
      FROM
        T_BD_DISTRICT
      WHERE
        ACTIVE_FLAG = 'Y'
      CONNECT BY PRIOR 
        ROW_ID = PAR_ROW_ID
      START WITH
        PAR_ROW_ID = -1
    )
    LOOP
      IF (R_D.LEVEL = 1) THEN
        --第一层，则直使用名称
        S_LEVEL_NUM := TO_CHAR(R_D.ROW_ID) || '.';
        S_FULL_NAME := R_D.DISTRICT_NAME;
        V_DISTRICT_NAME(1) := R_D.DISTRICT_NAME;
        V_FULL_NAME(1) := S_FULL_NAME;
        V_LEVEL_NUM(1) := S_LEVEL_NUM;
      ELSE
        V_DISTRICT_NAME(R_D.LEVEL) := R_D.DISTRICT_NAME;
        --与上级名称不相同，采用上级的值加上本级，否则直接用上级名称
        IF V_DISTRICT_NAME(R_D.LEVEL-1) = R_D.DISTRICT_NAME THEN
          S_FULL_NAME := V_FULL_NAME(R_D.LEVEL-1);
        ELSIF R_D.LEVEL = 2 THEN
          S_FULL_NAME := R_D.DISTRICT_NAME; --第二层时直接取名称（不需要记录“中国”）
        ELSE
          S_FULL_NAME := V_FULL_NAME(R_D.LEVEL-1) || R_D.DISTRICT_NAME;
        END IF;
        V_FULL_NAME(R_D.LEVEL) := S_FULL_NAME;
        S_LEVEL_NUM := V_LEVEL_NUM(R_D.LEVEL-1) || TO_CHAR(R_D.ROW_ID) || '.';
        V_LEVEL_NUM(R_D.LEVEL) := S_LEVEL_NUM;
      END IF;
      IF S_FULL_NAME  <> NVL(R_D.FULL_NAME,'NULL') OR R_D.LEVEL <> NVL(R_D.LEVEL_SEQ,0) OR S_LEVEL_NUM <> NVL(R_D.LEVEL_NUM,'0') THEN
        UPDATE
          T_BD_DISTRICT
        SET
          FULL_NAME = S_FULL_NAME
          ,LEVEL_SEQ = R_D.LEVEL
          ,LEVEL_NUM = S_LEVEL_NUM
          ,LAST_UPD_DATE = SYSDATE
          ,LAST_UPD_BY = 'program'
        WHERE
          ROW_ID = R_D.ROW_ID;
      END IF;
    END LOOP;
  END P_UPDATE_DISTRICT_INFO;

  --取系统参数值(按范围取旧值表)
  function F_GET_OLD_PARAM_VALUE
  (
   P_CONFIG_CODE    t_bd_param_list.param_code%type,  --参数配置编码
   P_ENTITY_ID      up_org_unit.ENTITY_ID%type, --业务主体ID
   P_UNIT_ID        up_org_unit.Unit_Id%type default null, --中心ID
   P_CUSTOMER_ID    t_customer_header.customer_id%type default null, --客户ID, --中心ID
   IN_SCOPE         number default 0 --取旧值表范围，0取中心、客户旧值表
   ) --
   return varchar2 is

    LS_PARAM_VALUE t_bd_param_list.default_value%type;
    paramList t_bd_param_list%ROWTYPE ;
    paramEntity t_bd_param_entity%ROWTYPE ;
    entityDetail T_BD_PARAM_ENTITY_OLD_DETAIL%ROWTYPE ;
    LSE_NUM number;--记录是否查询到系统参数

  begin
    select count(0) into LSE_NUM from t_bd_param_list pl where pl.param_code=P_CONFIG_CODE and pl.active_flag='Y';

    if LSE_NUM = 0 then
        RAISE_APPLICATION_ERROR(-20001, '编码为'||P_CONFIG_CODE||'的系统参数没找到');
    end if;

    select pl.* into paramList from t_bd_param_list pl where pl.param_code=P_CONFIG_CODE and pl.active_flag='Y';

    --1、如果与主体无关，取默认值
    if (paramList.Entity_Flag is null or paramList.Entity_Flag = 'N') then
      LS_PARAM_VALUE := paramList.Default_Value;
      return LS_PARAM_VALUE;
    end if;

    --2、如果与主体相关，但与中心客户无关，取主体参数值
    begin
      select pe.* into paramEntity from t_bd_param_entity pe
         where pe.param_list_id=paramList.Param_List_Id
            and pe.entity_id = P_ENTITY_ID
            and pe.active_flag='Y';
      if (paramEntity.Org_Cust_Flag is null or paramEntity.Org_Cust_Flag = 'N') then
        LS_PARAM_VALUE := paramEntity.Entity_Value;
        return LS_PARAM_VALUE;
      end if;
    exception
        when NO_DATA_FOUND then
        LS_PARAM_VALUE := paramList.Default_Value;
        return LS_PARAM_VALUE;
    end;

    --3、如果与主体相关，且与中心客户有关，取中心客户参数值
    --3.1 如果参数中既传了中心，又传了客户
    if (P_UNIT_ID is not null and P_CUSTOMER_ID is not null) then

      begin
        select ed.* into entityDetail from T_BD_PARAM_ENTITY_OLD_DETAIL ed
           where ed.param_entity_id=paramEntity.Param_Entity_Id
              and ed.entity_id =  P_ENTITY_ID
              and ed.sales_center_id = P_UNIT_ID
              and ed.customer_id = P_CUSTOMER_ID
              and ed.active_flag = 'Y';
      exception
        when NO_DATA_FOUND then
        --3.1.1 如果没找到，则找中心的配置
        BEGIN
          select ed.* into entityDetail from T_BD_PARAM_ENTITY_OLD_DETAIL ed
             where ed.param_entity_id=paramEntity.Param_Entity_Id
                and ed.entity_id =  P_ENTITY_ID
                and ed.sales_center_id = P_UNIT_ID
                and (ed.customer_id is null or ed.customer_id <= 0)
                and ed.active_flag = 'Y';
        EXCEPTION WHEN NO_DATA_FOUND THEN
           LS_PARAM_VALUE := paramEntity.Entity_Value;
           return LS_PARAM_VALUE;
        END ;
      end;
      LS_PARAM_VALUE := entityDetail.Param_Value;

    else
    --3.2 如果参数中只传了中心
      BEGIN
        select ed.* into entityDetail from T_BD_PARAM_ENTITY_OLD_DETAIL ed
           where ed.param_entity_id=paramEntity.Param_Entity_Id
              and ed.entity_id =  P_ENTITY_ID
              and ed.sales_center_id = P_UNIT_ID
              and ed.active_flag = 'Y'
              and (ed.customer_id is null or ed.customer_id <= 0);
        LS_PARAM_VALUE := entityDetail.Param_Value;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        LS_PARAM_VALUE := paramEntity.Entity_Value;
        return LS_PARAM_VALUE;
      END;
    end if;

    return LS_PARAM_VALUE;

/*    exception
       when others then
        LS_PARAM_VALUE := 'error';
  */
  END F_GET_OLD_PARAM_VALUE;
  
  --取系统参数值(找不到就返回主体系统参数)
  function F_GET_PARAM_VALUE_ENTITY_PRIOR(P_CONFIG_CODE t_bd_param_list.param_code%type, --参数配置编码
                                          P_ENTITY_ID   up_org_unit.ENTITY_ID%type, --业务主体ID
                                          P_UNIT_ID     up_org_unit.Unit_Id%type default null, --中心ID
                                          P_CUSTOMER_ID t_customer_header.customer_id%type default null --客户ID
                                          ) --
   return varchar2 is

    LS_PARAM_VALUE t_bd_param_list.default_value%type;
    paramList      t_bd_param_list%ROWTYPE;
    paramEntity    t_bd_param_entity%ROWTYPE;
    entityDetail   t_bd_param_entity_detail%ROWTYPE;
    LSE_NUM        number; --记录是否查询到系统参数

  begin
    select count(0)
      into LSE_NUM
      from t_bd_param_list pl
     where pl.param_code = P_CONFIG_CODE
       and pl.active_flag = 'Y';

    if LSE_NUM = 0 then
      RAISE_APPLICATION_ERROR(-20001,
                              '编码为' || P_CONFIG_CODE || '的系统参数没找到');
    end if;

    select pl.*
      into paramList
      from t_bd_param_list pl
     where pl.param_code = P_CONFIG_CODE
       and pl.active_flag = 'Y';

    --1、如果与主体无关，取默认值
    if (paramList.Entity_Flag is null or paramList.Entity_Flag = 'N') then
      LS_PARAM_VALUE := paramList.Default_Value;
      return LS_PARAM_VALUE;
    end if;

    --2、如果与主体相关，但与中心客户无关，取主体参数值
    begin
      select pe.*
        into paramEntity
        from t_bd_param_entity pe
       where pe.param_list_id = paramList.Param_List_Id
         and pe.entity_id = P_ENTITY_ID
         and pe.active_flag = 'Y';
      if (paramEntity.Org_Cust_Flag is null or
         paramEntity.Org_Cust_Flag = 'N') then
        LS_PARAM_VALUE := paramEntity.Entity_Value;
        return LS_PARAM_VALUE;
      end if;
    exception
      when NO_DATA_FOUND then
        LS_PARAM_VALUE := paramList.Default_Value;
        return LS_PARAM_VALUE;
    end;

    --3、如果与主体相关，且与中心客户有关，取中心客户参数值
    --3.1 如果参数中既传了中心，又传了客户
    if (P_UNIT_ID is not null and P_CUSTOMER_ID is not null) then
    
      begin
        select ed.*
          into entityDetail
          from t_bd_param_entity_detail ed
         where ed.param_entity_id = paramEntity.Param_Entity_Id
           and ed.entity_id = P_ENTITY_ID
           and ed.sales_center_id = P_UNIT_ID
           and ed.customer_id = P_CUSTOMER_ID
           and ed.active_flag = 'Y';
      exception
        when NO_DATA_FOUND then
          --3.1.1 如果没找到，则找中心的配置
          BEGIN
            select ed.*
              into entityDetail
              from t_bd_param_entity_detail ed
             where ed.param_entity_id = paramEntity.Param_Entity_Id
               and ed.entity_id = P_ENTITY_ID
               and ed.sales_center_id = P_UNIT_ID
               and (ed.customer_id is null or ed.customer_id <= 0)
               and ed.active_flag = 'Y';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              LS_PARAM_VALUE := paramEntity.Entity_Value;
              return LS_PARAM_VALUE;
          END;
      end;
      LS_PARAM_VALUE := entityDetail.Param_Value;
    
    else
      --3.2 如果参数中只传了中心
      BEGIN
        select ed.*
          into entityDetail
          from t_bd_param_entity_detail ed
         where ed.param_entity_id = paramEntity.Param_Entity_Id
           and ed.entity_id = P_ENTITY_ID
           and ed.sales_center_id = P_UNIT_ID
           and ed.active_flag = 'Y'
           and (ed.customer_id is null or ed.customer_id <= 0);
        LS_PARAM_VALUE := entityDetail.Param_Value;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LS_PARAM_VALUE := paramEntity.Entity_Value;
          return LS_PARAM_VALUE;
      END;
    end if;

    return LS_PARAM_VALUE;

    /*    exception
         when others then
          LS_PARAM_VALUE := 'error';
    */
  END F_GET_PARAM_VALUE_ENTITY_PRIOR;

  procedure P_GET_PARAM_VALUE_ENTITY_PRIOR
  --取系统参数值
  (
   P_CONFIG_CODE    t_bd_param_list.param_code%type,  --参数配置编码
   P_ENTITY_ID      up_org_unit.ENTITY_ID%type, --业务主体ID
   P_UNIT_ID        up_org_unit.Unit_Id%type default null, --中心ID
   P_CUSTOMER_ID    t_customer_header.customer_id%type default null, --客户ID
   P_PARAM_VALUE      out varchar2 --返回的单据号
   )   is

  begin
    P_PARAM_VALUE := F_GET_PARAM_VALUE_ENTITY_PRIOR(P_CONFIG_CODE, P_ENTITY_ID, P_UNIT_ID, P_CUSTOMER_ID);
  end P_GET_PARAM_VALUE_ENTITY_PRIOR;
  -----------------------------------------------------------------------------
  -- AUTHOR  : lilh6
  -- CREATED : 2018-11-2
  -- PURPOSE : 根据收货地点编码获取4级地址返回。
  ------------------------------------------------------------------------------------                              
 Procedure p_Full_District_Code(p_Addr_Code     In Varchar2, --地点编码
                                p_Result        Out Varchar2, --返回结果
                                p_Province_Code Out Varchar2, --省
                                p_City_Code     Out Varchar2, --市
                                p_District_Code Out Varchar2, --区
                                p_Town_Code     Out Varchar2 --镇
                                ) Is
   v_Level_Seq Number;
 
 Begin
   p_Result := v_Success;
 
   If p_Addr_Code Is Null Then
     p_Result := '传入的地点编码不能为空！';
     Raise v_Base_Exception;
   End If;
 
   Begin
     Select t.Level_Seq
       Into v_Level_Seq
       From t_Bd_District t
      Where t.District_Code = p_Addr_Code;
   Exception
     When Others Then
       p_Result := '地点编码：' || p_Addr_Code || '不存在！';
       Raise v_Base_Exception;
   End;
   
   If v_Level_Seq = 6 Then
     --5级地址 也是取到4级地址，到镇
     Select T2.District_Code,
            T3.District_Code,
            T4.District_Code,
            T5.District_Code
       Into p_Town_Code, p_District_Code, p_City_Code, p_Province_Code
       From t_Bd_District T1,
            t_Bd_District T2,
            t_Bd_District T3,
            t_Bd_District T4,
            t_bd_district t5
      Where T1.Par_Row_Id = T2.Row_Id
        And T2.Par_Row_Id = T3.Row_Id
        And T3.Par_Row_Id = T4.Row_Id
        And t4.par_row_id = t5.row_id
        And T1.District_Code = p_Addr_Code;
   Elsif v_Level_Seq = 5 Then
     --4级地址 到镇
     Select T1.District_Code,
            T2.District_Code,
            T3.District_Code,
            T4.District_Code
       Into p_Town_Code, p_District_Code, p_City_Code, p_Province_Code
       From t_Bd_District T1,
            t_Bd_District T2,
            t_Bd_District T3,
            t_Bd_District T4
      Where T1.Par_Row_Id = T2.Row_Id
        And T2.Par_Row_Id = T3.Row_Id
        And T3.Par_Row_Id = T4.Row_Id
        And T1.District_Code = p_Addr_Code;
   Elsif v_Level_Seq = 4 Then
     --三级地址 到区
     Select T1.District_Code, T2.District_Code, T3.District_Code
       Into p_District_Code, p_City_Code, p_Province_Code
       From t_Bd_District T1, t_Bd_District T2, t_Bd_District T3
      Where T1.Par_Row_Id = T2.Row_Id
        And T2.Par_Row_Id = T3.Row_Id
        And T1.District_Code = p_Addr_Code;
   Elsif v_Level_Seq = 3 Then
     --二级地址 到市
     Select T1.District_Code, T2.District_Code
       Into p_City_Code, p_Province_Code
       From t_Bd_District T1, t_Bd_District T2
      Where T1.Par_Row_Id = T2.Row_Id
        And T1.District_Code = p_Addr_Code;
   Elsif v_Level_Seq = 2 Then
     --一级地址 到省
     p_Province_Code := p_Addr_Code;
   End If;
 Exception
   When v_Base_Exception Then
     p_Result := '分解行政区域失败！失败信息：' || p_Result || v_Nl || '系统提示：' || Sqlerrm;
 End p_Full_District_Code;
 
 
  --------------------------------------------------------------------------
  --Author: guibr
  --Created: 2020-01-01
  --日志表清理
  --------------------------------------------------------------------------                              
  Procedure P_SYSTEM_LOG_DELETE(OS_MESSAGE OUT VARCHAR2) IS  
     TYPE type_table_rowid IS TABLE OF ROWID INDEX BY BINARY_INTEGER;
     table_rowid type_table_rowid;
     CURSOR cur_tmp IS
       select rowid
          from cims.INTF_POL_INV_CURRENT
       where CREATION_DATE <= sysdate - 93;
  BEGIN
     OS_MESSAGE:='OK';
     BEGIN
        OPEN cur_tmp;
        LOOP
          FETCH cur_tmp BULK COLLECT
            INTO table_rowid LIMIT 5000;
          FORALL i IN 1 .. table_rowid.COUNT()
            delete from cims.INTF_POL_INV_CURRENT where ROWID = table_rowid(i);
          COMMIT;
          EXIT WHEN cur_tmp%NOTFOUND;
        END LOOP;
        COMMIT;
        CLOSE cur_tmp;
     END;   
  END P_SYSTEM_LOG_DELETE;
 
End PKG_BD;
/

