create view V_CUSTOMER_SALES_MAIN_TYPE as
select "SALES_MAIN_TYPE_ID","ENTITY_ID","CUSTOM_ID","CUSTOM_CODE","DEPT_ID","DEPT_CODE","SALES_MAIN_TYPE_CODE","SALES_MAIN_TYPE_NAME","CUSTOM_LEVEL","CUSTOM_CREDIT_LEVEL","CREDIT_LINE","COOPERATION_MODEL_ID","ACTIVE_FLAG","CREATED_BY","CREATION_DATE","LAST_UPDATE_DATE","LAST_UPDATE_BY","LAST_INTERFACE_DATE","SIEBEL_PRODUCT_ID","SIEBEL_CUSTOMER_ID","PRE_FIELD_01","PRE_FIELD_02","PRE_FIELD_03","PRE_FIELD_04","PRE_FIELD_05","PRE_FIELD_06","NET_BATCH_FLAG","NN" from (
  select Sales_Main_Type_Id,
         Entity_Id,
         Custom_Id,
         Custom_Code,
         Dept_Id,
         Dept_Code,
         Sales_Main_Type_Code,
         Sales_Main_Type_Name,
         Custom_Level,
         Custom_Credit_Level,
         Credit_Line,
         Cooperation_Model_Id,
         Active_Flag,
         Created_By,
         Creation_Date,
         Last_Update_Date,
         Last_Update_By,
         Last_Interface_Date,
         Siebel_Product_Id,
         Siebel_Customer_Id,
         Pre_Field_01,
         Pre_Field_02,
         Pre_Field_03,
         Pre_Field_04,
         Pre_Field_05,
         Pre_Field_06,
         Net_Batch_Flag,
         (rank() Over(Partition By entity_Id, Custom_Id, Sales_Main_Type_Code, Active_Flag Order By Sales_Main_Type_Id)) nn
   from (
    Select Csa.Sales_Main_Type_Id,
           Csa.Entity_Id,
           Csa.Custom_Id,
           Csa.Custom_Code,
           Csa.Dept_Id,
           Csa.Dept_Code,
           Nvl((select cr.hq_item_class_code
                 from (select icr.sc_entity_id, icr.sc_item_class_code, icr.hq_item_class_code
                         from t_Bd_Item_Class_Relation Icr
                        where icr.sale_type = 'M'
                          and sysdate between icr.begin_date and nvl(icr.end_date, sysdate + 1)
                        order by decode(icr.default_flag, 'Y', 0, 1)) cr
                where cr.sc_entity_id = csa.entity_id
                  and cr.sc_item_class_code = csa.sales_main_type_code
                  and rownum=1), Csa.Sales_Main_Type_Code) Sales_Main_Type_Code,
           Nvl((select cr.hq_item_class_name
                 from (select icr.sc_entity_id, icr.sc_item_class_code, icr.hq_item_class_name
                         from t_Bd_Item_Class_Relation Icr
                        where icr.sale_type = 'M'
                          and sysdate between icr.begin_date and nvl(icr.end_date, sysdate + 1)
                        order by decode(icr.default_flag, 'Y', 0, 1)) cr
                where cr.sc_entity_id = csa.entity_id
                  and cr.sc_item_class_code = csa.sales_main_type_code
                  and rownum=1), Csa.Sales_Main_Type_Name) Sales_Main_Type_Name,
           Csa.Custom_Level,
           Csa.Custom_Credit_Level,
           Csa.Credit_Line,
           Csa.Cooperation_Model_Id,
           Csa.Active_Flag,
           Csa.Created_By,
           Csa.Creation_Date,
           Csa.Last_Update_Date,
           Csa.Last_Update_By,
           Csa.Last_Interface_Date,
           Csa.Siebel_Product_Id,
           Csa.Siebel_Customer_Id,
           Csa.Pre_Field_01,
           Csa.Pre_Field_02,
           Csa.Pre_Field_03,
           Csa.Pre_Field_04,
           Csa.Pre_Field_05,
           Csa.Pre_Field_06,
           Csa.Net_Batch_Flag
      From t_Customer_Sales_Main_Type Csa/*,
           (Select Icr.Sc_Entity_Id,
                   Icr.Sc_Item_Class_Id,
                   Icr.Sc_Item_Class_Code,
                   Icr.Sc_Item_Class_Name,
                   Icr.Hq_Entity_Id,
                   Icr.Hq_Item_Class_Id,
                   Icr.Hq_Item_Class_Code,
                   Icr.Hq_Item_Class_Name
              From t_Bd_Item_Class_Relation Icr
             where icr.sale_type = 'M'
               --AND ICR.DEFAULT_FLAG = 'Y'
             order by decode(icr.default_flag, 'Y', 0, 1)) Bic*/
    /*Where Csa.Entity_Id = Bic.Sc_Entity_Id(+)
       And Csa.Sales_Main_Type_Code = Bic.Sc_Item_Class_Code(+)*/
   )
) where nn = 1
With Read Only
/

comment on table V_CUSTOMER_SALES_MAIN_TYPE is '客户经营产品品牌视图'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.SALES_MAIN_TYPE_ID is '营销大类ID'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.ENTITY_ID is '主体ID'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.CUSTOM_ID is '客户ID'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.CUSTOM_CODE is '客户编码'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.DEPT_ID is '事业部ID'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.DEPT_CODE is '事业部编码'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.SALES_MAIN_TYPE_CODE is '营销大类(微波/厨具/吸尘器/整体橱柜/商橱)'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.SALES_MAIN_TYPE_NAME is '营销大类(微波/厨具/吸尘器/整体橱柜/商橱)'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.CUSTOM_LEVEL is '客户等级'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.CUSTOM_CREDIT_LEVEL is '客户信用等级'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.CREDIT_LINE is '信用额度'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.COOPERATION_MODEL_ID is '合作类型(代理商/直营商/直销商/OEM商/销售公司)'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.ACTIVE_FLAG is '是否有效(Y/N)'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.CREATED_BY is '创建人'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.CREATION_DATE is '创建日期'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.LAST_UPDATE_DATE is '最后修改时间'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.LAST_UPDATE_BY is '最后修改人'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.LAST_INTERFACE_DATE is '最后同步时间'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.SIEBEL_PRODUCT_ID is '主数据客户经营产品ID'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.SIEBEL_CUSTOMER_ID is '主数据客户ID'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.PRE_FIELD_01 is '预留字段1'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.PRE_FIELD_02 is '预留字段2'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.PRE_FIELD_03 is '预留字段3'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.PRE_FIELD_04 is '预留字段4'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.PRE_FIELD_05 is '预留字段5'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.PRE_FIELD_06 is '预留字段6'
/

comment on column V_CUSTOMER_SALES_MAIN_TYPE.NET_BATCH_FLAG is '网批标识'
/

