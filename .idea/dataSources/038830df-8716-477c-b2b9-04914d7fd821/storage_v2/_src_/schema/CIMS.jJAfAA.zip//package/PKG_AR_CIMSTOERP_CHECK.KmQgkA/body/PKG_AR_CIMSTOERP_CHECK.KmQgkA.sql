create PACKAGE BODY PKG_AR_CIMSTOERP_CHECK IS

  -- CIMS与ERPAR对账
  PROCEDURE P_CIMSTOERP_CHECK(P_MESSAGE out varchar2 --成功则返回“SUCCESS”，否则返回出错信息
                              ) is
    --PRAGMA AUTONOMOUS_TRANSACTION;
    --获取CIMS待对账的数据
    CURSOR C_CIMSDATA IS
      SELECT t.* ,b.erp_receipt_method_id,b.receipt_method_name
        FROM T_AR_CASH_RECEIPT_HEADERS t,T_AR_RECEIPT_METHODS b
       WHERE t.into_erp_status = 0
         AND t.receipt_method_id = b.receipt_method_id
         AND b.into_erp_flag = 'Y'
         AND t.RECEIPT_STATUS_ID not in (0,1,2,10,12,19)
         AND t.writeoff_receipt_code is null
         AND t.cash_receipt_code not in (select trx_number_cims from T_AR_CIMSTOERP_DETAILS);
    
    CIMSDATA_ROW C_CIMSDATA%ROWTYPE; --CIMS收款头表游标行数据
    V_TRX_NUMBER_ERP   VARCHAR2(100); --ERP方单据号
    V_AMOUNT_ERP       NUMBER;        --ERP方金额
    V_RECEIPT_METHOD_ID_ERP  NUMBER;        --ERP方收款方法ID
    V_GLDATE_PERIOD_ERP  DATE; --ERP方GL_DATE期间
    V_STATUS_ERP         VARCHAR2(20); --ERP方状态，冲销固定值‘REV’
    V_COUNT1           NUMBER;        --判断到款、冲销数据在ERP中是否存在
    V_COUNT2           NUMBER;        --判断发票数据在ERP中是否存在
    
    BEGIN
    P_MESSAGE := '执行处理,无对账数据';
    
    FOR CIMSDATA_ROW IN C_CIMSDATA LOOP
      if (CIMSDATA_ROW.Amount > 0) then  --正数16为冲销,其他为收款
         --校验数据在ERP是否存在，或有多条
         SELECT COUNT(*)
           INTO V_COUNT1
           FROM apps.AR_CASH_RECEIPTS_all@mdims2mderp acr, 
                apps.AR_CASH_RECEIPT_HISTORY_ALL@mdims2mderp acrh
          WHERE acr.CASH_RECEIPT_ID = acrh.CASH_RECEIPT_ID  
            AND acrh.FIRST_POSTED_RECORD_FLAG = 'Y'
            AND acr.RECEIPT_NUMBER = CIMSDATA_ROW.Cash_Receipt_Code --参数：单据号
            AND acr.org_id = CIMSDATA_ROW.Erp_Ou_Id; --参数：OU ID

         if (CIMSDATA_ROW.RECEIPT_STATUS_ID = 16) then   --16为冲销      
            if (V_COUNT1 = 0) then   -- 0为数据在ERP不存在
               BEGIN
                --数据插入AR对账明细表
                INSERT INTO T_AR_CIMSTOERP_DETAILS
                  (DETAILS_ID, --主键
                   CHECK_TYPE, --对账业务类型：发票、收款、冲销
                   CHECK_STATUS, --对账状态:成功、失败
                   CHECK_MESSAGE, --对账信息
                   TRX_NUMBER_CIMS, --CIMS方单据号
                   AMOUNT_CIMS, --CIMS方金额
                   CUSTOMER_ID_CIMS, --CIMS方客户ID
                   CUSTOMER_CODE_CIMS, --CIMS方客户编码
                   CUSTOMER_NAME_CIMS, --CIMS方客户名称
                   RECEIPT_METHOD_ID_CIMS, --CIMS方收款方法ID
                   RECEIPT_METHOD_NAME_CIMS, --CIMS方收款方法名称
                   GLDATE_PERIOD_CIMS, --CIMS方GL_DATE期间
                   TRX_NUMBER_ERP, --ERP方单据号
                   AMOUNT_ERP, --ERP方金额
                   RECEIPT_METHOD_ID_ERP,    --ERP方收款方法ID
                   GLDATE_PERIOD_ERP, --ERP方GL_DATE期间
                   CHECK_DATE --对账时间
                   ）
                VALUES
                  (S_AR_CIMSTOERP_DETAILS.NEXTVAL, 
                   '冲销',
                   '失败',
                   '单据'|| CIMSDATA_ROW.Cash_Receipt_Code ||'在ERP系统不存在',
                   CIMSDATA_ROW.Cash_Receipt_Code,
                   CIMSDATA_ROW.Amount,
                   CIMSDATA_ROW.Customer_Id,
                   CIMSDATA_ROW.Customer_Code,
                   CIMSDATA_ROW.Customer_Name,
                   CIMSDATA_ROW.Receipt_Method_Id,
                   CIMSDATA_ROW.Receipt_Method_Name,
                   to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM'),
                   null,
                   null,
                   null,
                   null,
                   sysdate
                   );
               P_MESSAGE := '插入AR对账明细表成功';
              EXCEPTION
                WHEN OTHERS THEN
                  P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                                     SQLCODE,
                                                     '插入AR对账明细表失败！：' ||
                                                     SQLERRM);
              END;
            elsif (V_COUNT1 = 1) then  --数据正常
              SELECT acr.RECEIPT_NUMBER, acr.AMOUNT, acrh.GL_DATE, acr.STATUS,acr.RECEIPT_METHOD_ID 
                INTO V_TRX_NUMBER_ERP,V_AMOUNT_ERP,V_GLDATE_PERIOD_ERP,V_STATUS_ERP,V_RECEIPT_METHOD_ID_ERP
                FROM apps.AR_CASH_RECEIPTS_ALL@mdims2mderp acr, 
                     apps.AR_CASH_RECEIPT_HISTORY_ALL@mdims2mderp acrh
               WHERE acr.CASH_RECEIPT_ID = acrh.CASH_RECEIPT_ID  
                 AND acrh.CURRENT_RECORD_FLAG = 'Y'
                 AND acr.RECEIPT_NUMBER = CIMSDATA_ROW.Cash_Receipt_Code --参数：单据号
                 AND acr.org_id = CIMSDATA_ROW.Erp_Ou_Id; --参数：OU ID
              
              if (V_AMOUNT_ERP = CIMSDATA_ROW.Amount) then
                 if (to_char(V_GLDATE_PERIOD_ERP,'YYYY-MM') = to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM')) then
                    --if (V_RECEIPT_METHOD_ID_ERP = CIMSDATA_ROW.Erp_Receipt_Method_Id) then
                       if (V_STATUS_ERP = 'REV') then
                         BEGIN
                         --数据插入AR对账明细表
                         INSERT INTO T_AR_CIMSTOERP_DETAILS
                            (DETAILS_ID, --主键
                             CHECK_TYPE, --对账业务类型：发票、收款、冲销
                             CHECK_STATUS, --对账状态:成功、失败
                             CHECK_MESSAGE, --对账信息
                             TRX_NUMBER_CIMS, --CIMS方单据号
                             AMOUNT_CIMS, --CIMS方金额
                             CUSTOMER_ID_CIMS, --CIMS方客户ID
                             CUSTOMER_CODE_CIMS, --CIMS方客户编码
                             CUSTOMER_NAME_CIMS, --CIMS方客户名称
                             RECEIPT_METHOD_ID_CIMS, --CIMS方收款方法ID
                             RECEIPT_METHOD_NAME_CIMS, --CIMS方收款方法名称
                             GLDATE_PERIOD_CIMS, --CIMS方GL_DATE期间
                             TRX_NUMBER_ERP, --ERP方单据号
                             AMOUNT_ERP, --ERP方金额
                             RECEIPT_METHOD_ID_ERP,    --ERP方收款方法ID
                             GLDATE_PERIOD_ERP, --ERP方GL_DATE期间
                             CHECK_DATE --对账时间
                             ）
                         VALUES
                            (S_AR_CIMSTOERP_DETAILS.NEXTVAL, 
                             '冲销',
                             '成功',
                             '单据'|| CIMSDATA_ROW.Cash_Receipt_Code ||'在ERP系统对账成功',
                             CIMSDATA_ROW.Cash_Receipt_Code,
                             CIMSDATA_ROW.Amount,
                             CIMSDATA_ROW.Customer_Id,
                             CIMSDATA_ROW.Customer_Code,
                             CIMSDATA_ROW.Customer_Name,
                             CIMSDATA_ROW.Receipt_Method_Id,
                             CIMSDATA_ROW.Receipt_Method_Name,
                             to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM'),
                             V_TRX_NUMBER_ERP,
                             V_AMOUNT_ERP,
                             V_RECEIPT_METHOD_ID_ERP,
                             to_char(V_GLDATE_PERIOD_ERP,'YYYY-MM'),
                             sysdate
                             );
                         P_MESSAGE := '插入AR对账明细表成功';
                         EXCEPTION
                            WHEN OTHERS THEN
                              P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                                               SQLCODE,
                                                               '插入AR对账明细表失败！：' ||
                                                               SQLERRM);
                         END;
                         
                       else
                        BEGIN
                        --数据插入AR对账明细表
                        INSERT INTO T_AR_CIMSTOERP_DETAILS
                          (DETAILS_ID, --主键
                           CHECK_TYPE, --对账业务类型：发票、收款、冲销
                           CHECK_STATUS, --对账状态:成功、失败
                           CHECK_MESSAGE, --对账信息
                           TRX_NUMBER_CIMS, --CIMS方单据号
                           AMOUNT_CIMS, --CIMS方金额
                           CUSTOMER_ID_CIMS, --CIMS方客户ID
                           CUSTOMER_CODE_CIMS, --CIMS方客户编码
                           CUSTOMER_NAME_CIMS, --CIMS方客户名称
                           RECEIPT_METHOD_ID_CIMS, --CIMS方收款方法ID
                           RECEIPT_METHOD_NAME_CIMS, --CIMS方收款方法名称
                           GLDATE_PERIOD_CIMS, --CIMS方GL_DATE期间
                           TRX_NUMBER_ERP, --ERP方单据号
                           AMOUNT_ERP, --ERP方金额
                           RECEIPT_METHOD_ID_ERP,    --ERP方收款方法ID
                           GLDATE_PERIOD_ERP, --ERP方GL_DATE期间
                           CHECK_DATE --对账时间
                           ）
                        VALUES
                          (S_AR_CIMSTOERP_DETAILS.NEXTVAL, 
                           '冲销',
                           '失败',
                           '单据'|| CIMSDATA_ROW.Cash_Receipt_Code ||'在ERP系统STATUS值不是REV',
                           CIMSDATA_ROW.Cash_Receipt_Code,
                           CIMSDATA_ROW.Amount,
                           CIMSDATA_ROW.Customer_Id,
                           CIMSDATA_ROW.Customer_Code,
                           CIMSDATA_ROW.Customer_Name,
                           CIMSDATA_ROW.Receipt_Method_Id,
                           CIMSDATA_ROW.Receipt_Method_Name,
                           to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM'),
                           V_TRX_NUMBER_ERP,
                           V_AMOUNT_ERP,
                           V_RECEIPT_METHOD_ID_ERP,
                           to_char(V_GLDATE_PERIOD_ERP,'YYYY-MM'),
                           sysdate
                           );
                        P_MESSAGE := '插入AR对账明细表成功';
                        EXCEPTION
                          WHEN OTHERS THEN
                            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                                             SQLCODE,
                                                             '插入AR对账明细表失败！：' ||
                                                             SQLERRM);
                        END;
                       end if;
                       
                    /*else
                        BEGIN
                        --数据插入AR对账明细表
                        INSERT INTO T_AR_CIMSTOERP_DETAILS
                          (DETAILS_ID, --主键
                           CHECK_TYPE, --对账业务类型：发票、收款、冲销
                           CHECK_STATUS, --对账状态:成功、失败
                           CHECK_MESSAGE, --对账信息
                           TRX_NUMBER_CIMS, --CIMS方单据号
                           AMOUNT_CIMS, --CIMS方金额
                           CUSTOMER_ID_CIMS, --CIMS方客户ID
                           CUSTOMER_CODE_CIMS, --CIMS方客户编码
                           CUSTOMER_NAME_CIMS, --CIMS方客户名称
                           RECEIPT_METHOD_ID_CIMS, --CIMS方收款方法ID
                           RECEIPT_METHOD_NAME_CIMS, --CIMS方收款方法名称
                           GLDATE_PERIOD_CIMS, --CIMS方GL_DATE期间
                           TRX_NUMBER_ERP, --ERP方单据号
                           AMOUNT_ERP, --ERP方金额
                           RECEIPT_METHOD_ID_ERP,    --ERP方收款方法ID
                           GLDATE_PERIOD_ERP, --ERP方GL_DATE期间
                           CHECK_DATE --对账时间
                           ）
                        VALUES
                          (S_AR_CIMSTOERP_DETAILS.NEXTVAL, 
                           '冲销',
                           '失败',
                           '单据'|| CIMSDATA_ROW.Cash_Receipt_Code ||'在ERP系统收款方法ID不一致',
                           CIMSDATA_ROW.Cash_Receipt_Code,
                           CIMSDATA_ROW.Amount,
                           CIMSDATA_ROW.Customer_Id,
                           CIMSDATA_ROW.Customer_Code,
                           CIMSDATA_ROW.Customer_Name,
                           CIMSDATA_ROW.Receipt_Method_Id,
                           CIMSDATA_ROW.Receipt_Method_Name,
                           to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM'),
                           V_TRX_NUMBER_ERP,
                           V_AMOUNT_ERP,
                           V_RECEIPT_METHOD_ID_ERP,
                           to_char(V_GLDATE_PERIOD_ERP,'YYYY-MM'),
                           sysdate
                           );
                        P_MESSAGE := '插入AR对账明细表成功';
                        EXCEPTION
                          WHEN OTHERS THEN
                            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                                             SQLCODE,
                                                             '插入AR对账明细表失败！：' ||
                                                             SQLERRM);
                        END;
                    end if;*/
                 else 
                    BEGIN
                    --数据插入AR对账明细表
                    INSERT INTO T_AR_CIMSTOERP_DETAILS
                      (DETAILS_ID, --主键
                       CHECK_TYPE, --对账业务类型：发票、收款、冲销
                       CHECK_STATUS, --对账状态:成功、失败
                       CHECK_MESSAGE, --对账信息
                       TRX_NUMBER_CIMS, --CIMS方单据号
                       AMOUNT_CIMS, --CIMS方金额
                       CUSTOMER_ID_CIMS, --CIMS方客户ID
                       CUSTOMER_CODE_CIMS, --CIMS方客户编码
                       CUSTOMER_NAME_CIMS, --CIMS方客户名称
                       RECEIPT_METHOD_ID_CIMS, --CIMS方收款方法ID
                       RECEIPT_METHOD_NAME_CIMS, --CIMS方收款方法名称
                       GLDATE_PERIOD_CIMS, --CIMS方GL_DATE期间
                       TRX_NUMBER_ERP, --ERP方单据号
                       AMOUNT_ERP, --ERP方金额
                       RECEIPT_METHOD_ID_ERP,    --ERP方收款方法ID
                       GLDATE_PERIOD_ERP, --ERP方GL_DATE期间
                       CHECK_DATE --对账时间
                       ）
                    VALUES
                      (S_AR_CIMSTOERP_DETAILS.NEXTVAL, 
                       '冲销',
                       '失败',
                       '单据'|| CIMSDATA_ROW.Cash_Receipt_Code ||'在ERP系统GL会计期间不一致',
                       CIMSDATA_ROW.Cash_Receipt_Code,
                       CIMSDATA_ROW.Amount,
                       CIMSDATA_ROW.Customer_Id,
                       CIMSDATA_ROW.Customer_Code,
                       CIMSDATA_ROW.Customer_Name,
                       CIMSDATA_ROW.Receipt_Method_Id,
                       CIMSDATA_ROW.Receipt_Method_Name,
                       to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM'),
                       V_TRX_NUMBER_ERP,
                       V_AMOUNT_ERP,
                       V_RECEIPT_METHOD_ID_ERP,
                       to_char(V_GLDATE_PERIOD_ERP,'YYYY-MM'),
                       sysdate
                       );
                    P_MESSAGE := '插入AR对账明细表成功';
                    EXCEPTION
                      WHEN OTHERS THEN
                        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                                         SQLCODE,
                                                         '插入AR对账明细表失败！：' ||
                                                         SQLERRM);
                    END;
                 end if;
              
              else
                BEGIN
                --数据插入AR对账明细表
                INSERT INTO T_AR_CIMSTOERP_DETAILS
                  (DETAILS_ID, --主键
                   CHECK_TYPE, --对账业务类型：发票、收款、冲销
                   CHECK_STATUS, --对账状态:成功、失败
                   CHECK_MESSAGE, --对账信息
                   TRX_NUMBER_CIMS, --CIMS方单据号
                   AMOUNT_CIMS, --CIMS方金额
                   CUSTOMER_ID_CIMS, --CIMS方客户ID
                   CUSTOMER_CODE_CIMS, --CIMS方客户编码
                   CUSTOMER_NAME_CIMS, --CIMS方客户名称
                   RECEIPT_METHOD_ID_CIMS, --CIMS方收款方法ID
                   RECEIPT_METHOD_NAME_CIMS, --CIMS方收款方法名称
                   GLDATE_PERIOD_CIMS, --CIMS方GL_DATE期间
                   TRX_NUMBER_ERP, --ERP方单据号
                   AMOUNT_ERP, --ERP方金额
                   RECEIPT_METHOD_ID_ERP,    --ERP方收款方法ID
                   GLDATE_PERIOD_ERP, --ERP方GL_DATE期间
                   CHECK_DATE --对账时间
                   ）
                VALUES
                  (S_AR_CIMSTOERP_DETAILS.NEXTVAL, 
                   '冲销',
                   '失败',
                   '单据'|| CIMSDATA_ROW.Cash_Receipt_Code ||'在ERP系统金额不一致',
                   CIMSDATA_ROW.Cash_Receipt_Code,
                   CIMSDATA_ROW.Amount,
                   CIMSDATA_ROW.Customer_Id,
                   CIMSDATA_ROW.Customer_Code,
                   CIMSDATA_ROW.Customer_Name,
                   CIMSDATA_ROW.Receipt_Method_Id,
                   CIMSDATA_ROW.Receipt_Method_Name,
                   to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM'),
                   V_TRX_NUMBER_ERP,
                   V_AMOUNT_ERP,
                   V_RECEIPT_METHOD_ID_ERP,
                   to_char(V_GLDATE_PERIOD_ERP,'YYYY-MM'),
                   sysdate
                   );
                P_MESSAGE := '插入AR对账明细表成功';
                EXCEPTION
                  WHEN OTHERS THEN
                    P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                                     SQLCODE,
                                                     '插入AR对账明细表失败！：' ||
                                                     SQLERRM);
                END;
              end if;
            
            else     -->1为数据在ERP中超过1条记录
              BEGIN
                --数据插入AR对账明细表
                INSERT INTO T_AR_CIMSTOERP_DETAILS
                  (DETAILS_ID, --主键
                   CHECK_TYPE, --对账业务类型：发票、收款、冲销
                   CHECK_STATUS, --对账状态:成功、失败
                   CHECK_MESSAGE, --对账信息
                   TRX_NUMBER_CIMS, --CIMS方单据号
                   AMOUNT_CIMS, --CIMS方金额
                   CUSTOMER_ID_CIMS, --CIMS方客户ID
                   CUSTOMER_CODE_CIMS, --CIMS方客户编码
                   CUSTOMER_NAME_CIMS, --CIMS方客户名称
                   RECEIPT_METHOD_ID_CIMS, --CIMS方收款方法ID
                   RECEIPT_METHOD_NAME_CIMS, --CIMS方收款方法名称
                   GLDATE_PERIOD_CIMS, --CIMS方GL_DATE期间
                   TRX_NUMBER_ERP, --ERP方单据号
                   AMOUNT_ERP, --ERP方金额
                   RECEIPT_METHOD_ID_ERP,    --ERP方收款方法ID
                   GLDATE_PERIOD_ERP, --ERP方GL_DATE期间
                   CHECK_DATE --对账时间
                   ）
                VALUES
                  (S_AR_CIMSTOERP_DETAILS.NEXTVAL, 
                   '冲销',
                   '失败',
                   '单据'|| CIMSDATA_ROW.Cash_Receipt_Code ||'在ERP系统中有'|| V_COUNT1 ||  '条',
                   CIMSDATA_ROW.Cash_Receipt_Code,
                   CIMSDATA_ROW.Amount,
                   CIMSDATA_ROW.Customer_Id,
                   CIMSDATA_ROW.Customer_Code,
                   CIMSDATA_ROW.Customer_Name,
                   CIMSDATA_ROW.Receipt_Method_Id,
                   CIMSDATA_ROW.Receipt_Method_Name,
                   to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM'),
                   null,
                   null,
                   null,
                   null,
                   sysdate
                   );
                P_MESSAGE := '插入AR对账明细表成功';
              EXCEPTION
                WHEN OTHERS THEN
                  P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                                     SQLCODE,
                                                     '插入AR对账明细表失败！：' ||
                                                     SQLERRM);
              END;
            
            end if;
         
         else  --其他为收款
            if (V_COUNT1 = 0) then   -- 0为数据在ERP不存在
               BEGIN
                --数据插入AR对账明细表
                INSERT INTO T_AR_CIMSTOERP_DETAILS
                  (DETAILS_ID, --主键
                   CHECK_TYPE, --对账业务类型：发票、收款、冲销
                   CHECK_STATUS, --对账状态:成功、失败
                   CHECK_MESSAGE, --对账信息
                   TRX_NUMBER_CIMS, --CIMS方单据号
                   AMOUNT_CIMS, --CIMS方金额
                   CUSTOMER_ID_CIMS, --CIMS方客户ID
                   CUSTOMER_CODE_CIMS, --CIMS方客户编码
                   CUSTOMER_NAME_CIMS, --CIMS方客户名称
                   RECEIPT_METHOD_ID_CIMS, --CIMS方收款方法ID
                   RECEIPT_METHOD_NAME_CIMS, --CIMS方收款方法名称
                   GLDATE_PERIOD_CIMS, --CIMS方GL_DATE期间
                   TRX_NUMBER_ERP, --ERP方单据号
                   AMOUNT_ERP, --ERP方金额
                   RECEIPT_METHOD_ID_ERP,    --ERP方收款方法ID
                   GLDATE_PERIOD_ERP, --ERP方GL_DATE期间
                   CHECK_DATE --对账时间
                   ）
                VALUES
                  (S_AR_CIMSTOERP_DETAILS.NEXTVAL, 
                   '收款',
                   '失败',
                   '单据'|| CIMSDATA_ROW.Cash_Receipt_Code ||'在ERP系统不存在',
                   CIMSDATA_ROW.Cash_Receipt_Code,
                   CIMSDATA_ROW.Amount,
                   CIMSDATA_ROW.Customer_Id,
                   CIMSDATA_ROW.Customer_Code,
                   CIMSDATA_ROW.Customer_Name,
                   CIMSDATA_ROW.Receipt_Method_Id,
                   CIMSDATA_ROW.Receipt_Method_Name,
                   to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM'),
                   null,
                   null,
                   null,
                   null,
                   sysdate
                   );
               P_MESSAGE := '插入AR对账明细表成功';
              EXCEPTION
                WHEN OTHERS THEN
                  P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                                     SQLCODE,
                                                     '插入AR对账明细表失败！：' ||
                                                     SQLERRM);
              END;
            elsif (V_COUNT1 = 1) then  --数据正常
              SELECT acr.RECEIPT_NUMBER, acr.AMOUNT, acrh.GL_DATE, acr.RECEIPT_METHOD_ID
                INTO V_TRX_NUMBER_ERP,V_AMOUNT_ERP,V_GLDATE_PERIOD_ERP,V_RECEIPT_METHOD_ID_ERP
                FROM apps.AR_CASH_RECEIPTS_ALL@mdims2mderp acr, 
                     apps.AR_CASH_RECEIPT_HISTORY_ALL@mdims2mderp acrh
               WHERE acr.CASH_RECEIPT_ID = acrh.CASH_RECEIPT_ID  
                 AND acrh.FIRST_POSTED_RECORD_FLAG = 'Y'
                 AND acr.RECEIPT_NUMBER = CIMSDATA_ROW.Cash_Receipt_Code --参数：单据号
                 AND acr.org_id = CIMSDATA_ROW.Erp_Ou_Id; --参数：OU ID
              
              if (V_AMOUNT_ERP = CIMSDATA_ROW.Amount) then
                 if (to_char(V_GLDATE_PERIOD_ERP,'YYYY-MM') = to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM')) then
                    --if (V_RECEIPT_METHOD_ID_ERP = CIMSDATA_ROW.Erp_Receipt_Method_Id) then
                       BEGIN
                       --数据插入AR对账明细表
                       INSERT INTO T_AR_CIMSTOERP_DETAILS
                          (DETAILS_ID, --主键
                           CHECK_TYPE, --对账业务类型：发票、收款、冲销
                           CHECK_STATUS, --对账状态:成功、失败
                           CHECK_MESSAGE, --对账信息
                           TRX_NUMBER_CIMS, --CIMS方单据号
                           AMOUNT_CIMS, --CIMS方金额
                           CUSTOMER_ID_CIMS, --CIMS方客户ID
                           CUSTOMER_CODE_CIMS, --CIMS方客户编码
                           CUSTOMER_NAME_CIMS, --CIMS方客户名称
                           RECEIPT_METHOD_ID_CIMS, --CIMS方收款方法ID
                           RECEIPT_METHOD_NAME_CIMS, --CIMS方收款方法名称
                           GLDATE_PERIOD_CIMS, --CIMS方GL_DATE期间
                           TRX_NUMBER_ERP, --ERP方单据号
                           AMOUNT_ERP, --ERP方金额
                           RECEIPT_METHOD_ID_ERP,    --ERP方收款方法ID
                           GLDATE_PERIOD_ERP, --ERP方GL_DATE期间
                           CHECK_DATE --对账时间
                           ）
                       VALUES
                          (S_AR_CIMSTOERP_DETAILS.NEXTVAL, 
                           '收款',
                           '成功',
                           '单据'|| CIMSDATA_ROW.Cash_Receipt_Code ||'在ERP系统对账成功',
                           CIMSDATA_ROW.Cash_Receipt_Code,
                           CIMSDATA_ROW.Amount,
                           CIMSDATA_ROW.Customer_Id,
                           CIMSDATA_ROW.Customer_Code,
                           CIMSDATA_ROW.Customer_Name,
                           CIMSDATA_ROW.Receipt_Method_Id,
                           CIMSDATA_ROW.Receipt_Method_Name,
                           to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM'),
                           V_TRX_NUMBER_ERP,
                           V_AMOUNT_ERP,
                           V_RECEIPT_METHOD_ID_ERP,
                           to_char(V_GLDATE_PERIOD_ERP,'YYYY-MM'),
                           sysdate
                           );
                       P_MESSAGE := '插入AR对账明细表成功';
                       EXCEPTION
                          WHEN OTHERS THEN
                            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                                             SQLCODE,
                                                             '插入AR对账明细表失败！：' ||
                                                             SQLERRM);
                       END;
                    /*else
                        BEGIN
                        --数据插入AR对账明细表
                        INSERT INTO T_AR_CIMSTOERP_DETAILS
                          (DETAILS_ID, --主键
                           CHECK_TYPE, --对账业务类型：发票、收款、冲销
                           CHECK_STATUS, --对账状态:成功、失败
                           CHECK_MESSAGE, --对账信息
                           TRX_NUMBER_CIMS, --CIMS方单据号
                           AMOUNT_CIMS, --CIMS方金额
                           CUSTOMER_ID_CIMS, --CIMS方客户ID
                           CUSTOMER_CODE_CIMS, --CIMS方客户编码
                           CUSTOMER_NAME_CIMS, --CIMS方客户名称
                           RECEIPT_METHOD_ID_CIMS, --CIMS方收款方法ID
                           RECEIPT_METHOD_NAME_CIMS, --CIMS方收款方法名称
                           GLDATE_PERIOD_CIMS, --CIMS方GL_DATE期间
                           TRX_NUMBER_ERP, --ERP方单据号
                           AMOUNT_ERP, --ERP方金额
                           RECEIPT_METHOD_ID_ERP,    --ERP方收款方法ID
                           GLDATE_PERIOD_ERP, --ERP方GL_DATE期间
                           CHECK_DATE --对账时间
                           ）
                        VALUES
                          (S_AR_CIMSTOERP_DETAILS.NEXTVAL, 
                           '收款',
                           '失败',
                           '单据'|| CIMSDATA_ROW.Cash_Receipt_Code ||'在ERP系统收款方法ID不一致',
                           CIMSDATA_ROW.Cash_Receipt_Code,
                           CIMSDATA_ROW.Amount,
                           CIMSDATA_ROW.Customer_Id,
                           CIMSDATA_ROW.Customer_Code,
                           CIMSDATA_ROW.Customer_Name,
                           CIMSDATA_ROW.Receipt_Method_Id,
                           CIMSDATA_ROW.Receipt_Method_Name,
                           to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM'),
                           V_TRX_NUMBER_ERP,
                           V_AMOUNT_ERP,
                           V_RECEIPT_METHOD_ID_ERP,
                           to_char(V_GLDATE_PERIOD_ERP,'YYYY-MM'),
                           sysdate
                           );
                        P_MESSAGE := '插入AR对账明细表成功';
                        EXCEPTION
                          WHEN OTHERS THEN
                            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                                             SQLCODE,
                                                             '插入AR对账明细表失败！：' ||
                                                             SQLERRM);
                        END;
                    end if;*/
                 else 
                    BEGIN
                    --数据插入AR对账明细表
                    INSERT INTO T_AR_CIMSTOERP_DETAILS
                      (DETAILS_ID, --主键
                       CHECK_TYPE, --对账业务类型：发票、收款、冲销
                       CHECK_STATUS, --对账状态:成功、失败
                       CHECK_MESSAGE, --对账信息
                       TRX_NUMBER_CIMS, --CIMS方单据号
                       AMOUNT_CIMS, --CIMS方金额
                       CUSTOMER_ID_CIMS, --CIMS方客户ID
                       CUSTOMER_CODE_CIMS, --CIMS方客户编码
                       CUSTOMER_NAME_CIMS, --CIMS方客户名称
                       RECEIPT_METHOD_ID_CIMS, --CIMS方收款方法ID
                       RECEIPT_METHOD_NAME_CIMS, --CIMS方收款方法名称
                       GLDATE_PERIOD_CIMS, --CIMS方GL_DATE期间
                       TRX_NUMBER_ERP, --ERP方单据号
                       AMOUNT_ERP, --ERP方金额
                       RECEIPT_METHOD_ID_ERP,    --ERP方收款方法ID
                       GLDATE_PERIOD_ERP, --ERP方GL_DATE期间
                       CHECK_DATE --对账时间
                       ）
                    VALUES
                      (S_AR_CIMSTOERP_DETAILS.NEXTVAL, 
                       '收款',
                       '失败',
                       '单据'|| CIMSDATA_ROW.Cash_Receipt_Code ||'在ERP系统GL会计期间不一致',
                       CIMSDATA_ROW.Cash_Receipt_Code,
                       CIMSDATA_ROW.Amount,
                       CIMSDATA_ROW.Customer_Id,
                       CIMSDATA_ROW.Customer_Code,
                       CIMSDATA_ROW.Customer_Name,
                       CIMSDATA_ROW.Receipt_Method_Id,
                       CIMSDATA_ROW.Receipt_Method_Name,
                       to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM'),
                       V_TRX_NUMBER_ERP,
                       V_AMOUNT_ERP,
                       V_RECEIPT_METHOD_ID_ERP,
                       to_char(V_GLDATE_PERIOD_ERP,'YYYY-MM'),
                       sysdate
                       );
                    P_MESSAGE := '插入AR对账明细表成功';
                    EXCEPTION
                      WHEN OTHERS THEN
                        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                                         SQLCODE,
                                                         '插入AR对账明细表失败！：' ||
                                                         SQLERRM);
                    END;
                 end if;
              
              else
                BEGIN
                --数据插入AR对账明细表
                INSERT INTO T_AR_CIMSTOERP_DETAILS
                  (DETAILS_ID, --主键
                   CHECK_TYPE, --对账业务类型：发票、收款、冲销
                   CHECK_STATUS, --对账状态:成功、失败
                   CHECK_MESSAGE, --对账信息
                   TRX_NUMBER_CIMS, --CIMS方单据号
                   AMOUNT_CIMS, --CIMS方金额
                   CUSTOMER_ID_CIMS, --CIMS方客户ID
                   CUSTOMER_CODE_CIMS, --CIMS方客户编码
                   CUSTOMER_NAME_CIMS, --CIMS方客户名称
                   RECEIPT_METHOD_ID_CIMS, --CIMS方收款方法ID
                   RECEIPT_METHOD_NAME_CIMS, --CIMS方收款方法名称
                   GLDATE_PERIOD_CIMS, --CIMS方GL_DATE期间
                   TRX_NUMBER_ERP, --ERP方单据号
                   AMOUNT_ERP, --ERP方金额
                   RECEIPT_METHOD_ID_ERP,    --ERP方收款方法ID
                   GLDATE_PERIOD_ERP, --ERP方GL_DATE期间
                   CHECK_DATE --对账时间
                   ）
                VALUES
                  (S_AR_CIMSTOERP_DETAILS.NEXTVAL, 
                   '收款',
                   '失败',
                   '单据'|| CIMSDATA_ROW.Cash_Receipt_Code ||'在ERP系统金额不一致',
                   CIMSDATA_ROW.Cash_Receipt_Code,
                   CIMSDATA_ROW.Amount,
                   CIMSDATA_ROW.Customer_Id,
                   CIMSDATA_ROW.Customer_Code,
                   CIMSDATA_ROW.Customer_Name,
                   CIMSDATA_ROW.Receipt_Method_Id,
                   CIMSDATA_ROW.Receipt_Method_Name,
                   to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM'),
                   V_TRX_NUMBER_ERP,
                   V_AMOUNT_ERP,
                   V_RECEIPT_METHOD_ID_ERP,
                   to_char(V_GLDATE_PERIOD_ERP,'YYYY-MM'),
                   sysdate
                   );
                P_MESSAGE := '插入AR对账明细表成功';
                EXCEPTION
                  WHEN OTHERS THEN
                    P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                                     SQLCODE,
                                                     '插入AR对账明细表失败！：' ||
                                                     SQLERRM);
                END;
              end if;
            
            else     -->1为数据在ERP中超过1条记录
              BEGIN
                --数据插入AR对账明细表
                INSERT INTO T_AR_CIMSTOERP_DETAILS
                  (DETAILS_ID, --主键
                   CHECK_TYPE, --对账业务类型：发票、收款、冲销
                   CHECK_STATUS, --对账状态:成功、失败
                   CHECK_MESSAGE, --对账信息
                   TRX_NUMBER_CIMS, --CIMS方单据号
                   AMOUNT_CIMS, --CIMS方金额
                   CUSTOMER_ID_CIMS, --CIMS方客户ID
                   CUSTOMER_CODE_CIMS, --CIMS方客户编码
                   CUSTOMER_NAME_CIMS, --CIMS方客户名称
                   RECEIPT_METHOD_ID_CIMS, --CIMS方收款方法ID
                   RECEIPT_METHOD_NAME_CIMS, --CIMS方收款方法名称
                   GLDATE_PERIOD_CIMS, --CIMS方GL_DATE期间
                   TRX_NUMBER_ERP, --ERP方单据号
                   AMOUNT_ERP, --ERP方金额
                   RECEIPT_METHOD_ID_ERP,    --ERP方收款方法ID
                   GLDATE_PERIOD_ERP, --ERP方GL_DATE期间
                   CHECK_DATE --对账时间
                   ）
                VALUES
                  (S_AR_CIMSTOERP_DETAILS.NEXTVAL, 
                   '收款',
                   '失败',
                   '单据'|| CIMSDATA_ROW.Cash_Receipt_Code ||'在ERP系统中有'|| V_COUNT1 ||  '条',
                   CIMSDATA_ROW.Cash_Receipt_Code,
                   CIMSDATA_ROW.Amount,
                   CIMSDATA_ROW.Customer_Id,
                   CIMSDATA_ROW.Customer_Code,
                   CIMSDATA_ROW.Customer_Name,
                   CIMSDATA_ROW.Receipt_Method_Id,
                   CIMSDATA_ROW.Receipt_Method_Name,
                   to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM'),
                   null,
                   null,
                   null,
                   null,
                   sysdate
                   );
                P_MESSAGE := '插入AR对账明细表成功';
              EXCEPTION
                WHEN OTHERS THEN
                  P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                                     SQLCODE,
                                                     '插入AR对账明细表失败！：' ||
                                                     SQLERRM);
              END;
            
            end if;
         
         end if;
      
      else  --CIMSDATA_ROW.Amount < =0 负数类型为发票
        SELECT COUNT(*)  
          INTO V_COUNT2
          FROM apps.RA_CUSTOMER_TRX_ALL@mdims2mderp ct,
               apps.RA_CUST_TRX_LINE_GL_DIST_ALL@mdims2mderp gd,
               apps.RA_CUSTOMER_TRX_LINES_ALL@mdims2mderp ctl
         WHERE ct.customer_trx_id = ctl.customer_trx_id
           AND ct.customer_trx_id = gd.customer_trx_id
           AND 'REC' = GD.ACCOUNT_CLASS
           AND 'Y' = GD.LATEST_REC_FLAG
           AND ct.org_id = CIMSDATA_ROW.Erp_Ou_Id --参数：OU ID
           AND ct.trx_number = CIMSDATA_ROW.Cash_Receipt_Code; --参数：发票编号
      
        if (V_COUNT2 = 0) then   -- 0为数据在ERP不存在
               BEGIN
                --数据插入AR对账明细表
                INSERT INTO T_AR_CIMSTOERP_DETAILS
                  (DETAILS_ID, --主键
                   CHECK_TYPE, --对账业务类型：发票、收款、冲销
                   CHECK_STATUS, --对账状态:成功、失败
                   CHECK_MESSAGE, --对账信息
                   TRX_NUMBER_CIMS, --CIMS方单据号
                   AMOUNT_CIMS, --CIMS方金额
                   CUSTOMER_ID_CIMS, --CIMS方客户ID
                   CUSTOMER_CODE_CIMS, --CIMS方客户编码
                   CUSTOMER_NAME_CIMS, --CIMS方客户名称
                   RECEIPT_METHOD_ID_CIMS, --CIMS方收款方法ID
                   RECEIPT_METHOD_NAME_CIMS, --CIMS方收款方法名称
                   GLDATE_PERIOD_CIMS, --CIMS方GL_DATE期间
                   TRX_NUMBER_ERP, --ERP方单据号
                   AMOUNT_ERP, --ERP方金额
                   RECEIPT_METHOD_ID_ERP,    --ERP方收款方法ID
                   GLDATE_PERIOD_ERP, --ERP方GL_DATE期间
                   CHECK_DATE --对账时间
                   ）
                VALUES
                  (S_AR_CIMSTOERP_DETAILS.NEXTVAL, 
                   '发票',
                   '失败',
                   '单据'|| CIMSDATA_ROW.Cash_Receipt_Code ||'在ERP系统不存在',
                   CIMSDATA_ROW.Cash_Receipt_Code,
                   CIMSDATA_ROW.Amount,
                   CIMSDATA_ROW.Customer_Id,
                   CIMSDATA_ROW.Customer_Code,
                   CIMSDATA_ROW.Customer_Name,
                   CIMSDATA_ROW.Receipt_Method_Id,
                   CIMSDATA_ROW.Receipt_Method_Name,
                   to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM'),
                   null,
                   null,
                   null,
                   null,
                   sysdate
                   );
               P_MESSAGE := '插入AR对账明细表成功';
              EXCEPTION
                WHEN OTHERS THEN
                  P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                                     SQLCODE,
                                                     '插入AR对账明细表失败！：' ||
                                                     SQLERRM);
              END;
            
            else  --数据正常
               
              SELECT ct.trx_number, sum(ctl.EXTENDED_AMOUNT) EXTENDED_AMOUNT, gd.GL_DATE
                INTO V_TRX_NUMBER_ERP,V_AMOUNT_ERP,V_GLDATE_PERIOD_ERP
                FROM apps.RA_CUSTOMER_TRX_ALL@mdims2mderp ct,
                     apps.RA_CUST_TRX_LINE_GL_DIST_ALL@mdims2mderp gd,
                     apps.RA_CUSTOMER_TRX_LINES_ALL@mdims2mderp ctl
               WHERE ct.customer_trx_id = ctl.customer_trx_id
                 AND ct.customer_trx_id = gd.customer_trx_id
                 AND 'REC' = GD.ACCOUNT_CLASS
                 AND 'Y' = GD.LATEST_REC_FLAG
                 AND ct.org_id = CIMSDATA_ROW.Erp_Ou_Id --参数：OU ID
                 AND ct.trx_number = CIMSDATA_ROW.Cash_Receipt_Code --参数：发票编号
                 group by ct.trx_number, gd.GL_DATE;
              
              if (V_AMOUNT_ERP = -1*CIMSDATA_ROW.Amount) then
                 if (to_char(V_GLDATE_PERIOD_ERP,'YYYY-MM') = to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM')) then
                    BEGIN
                       --数据插入AR对账明细表
                       INSERT INTO T_AR_CIMSTOERP_DETAILS
                          (DETAILS_ID, --主键
                           CHECK_TYPE, --对账业务类型：发票、收款、冲销
                           CHECK_STATUS, --对账状态:成功、失败
                           CHECK_MESSAGE, --对账信息
                           TRX_NUMBER_CIMS, --CIMS方单据号
                           AMOUNT_CIMS, --CIMS方金额
                           CUSTOMER_ID_CIMS, --CIMS方客户ID
                           CUSTOMER_CODE_CIMS, --CIMS方客户编码
                           CUSTOMER_NAME_CIMS, --CIMS方客户名称
                           RECEIPT_METHOD_ID_CIMS, --CIMS方收款方法ID
                           RECEIPT_METHOD_NAME_CIMS, --CIMS方收款方法名称
                           GLDATE_PERIOD_CIMS, --CIMS方GL_DATE期间
                           TRX_NUMBER_ERP, --ERP方单据号
                           AMOUNT_ERP, --ERP方金额
                           RECEIPT_METHOD_ID_ERP,    --ERP方收款方法ID
                           GLDATE_PERIOD_ERP, --ERP方GL_DATE期间
                           CHECK_DATE --对账时间
                           ）
                       VALUES
                          (S_AR_CIMSTOERP_DETAILS.NEXTVAL, 
                           '发票',
                           '成功',
                           '单据'|| CIMSDATA_ROW.Cash_Receipt_Code ||'在ERP系统对账成功',
                           CIMSDATA_ROW.Cash_Receipt_Code,
                           CIMSDATA_ROW.Amount,
                           CIMSDATA_ROW.Customer_Id,
                           CIMSDATA_ROW.Customer_Code,
                           CIMSDATA_ROW.Customer_Name,
                           CIMSDATA_ROW.Receipt_Method_Id,
                           CIMSDATA_ROW.Receipt_Method_Name,
                           to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM'),
                           V_TRX_NUMBER_ERP,
                           V_AMOUNT_ERP,
                           null,
                           to_char(V_GLDATE_PERIOD_ERP,'YYYY-MM'),
                           sysdate
                           );
                       P_MESSAGE := '插入AR对账明细表成功';
                       EXCEPTION
                          WHEN OTHERS THEN
                            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                                             SQLCODE,
                                                             '插入AR对账明细表失败！：' ||
                                                             SQLERRM);
                       END;
                 else 
                    BEGIN
                    --数据插入AR对账明细表
                    INSERT INTO T_AR_CIMSTOERP_DETAILS
                      (DETAILS_ID, --主键
                       CHECK_TYPE, --对账业务类型：发票、收款、冲销
                       CHECK_STATUS, --对账状态:成功、失败
                       CHECK_MESSAGE, --对账信息
                       TRX_NUMBER_CIMS, --CIMS方单据号
                       AMOUNT_CIMS, --CIMS方金额
                       CUSTOMER_ID_CIMS, --CIMS方客户ID
                       CUSTOMER_CODE_CIMS, --CIMS方客户编码
                       CUSTOMER_NAME_CIMS, --CIMS方客户名称
                       RECEIPT_METHOD_ID_CIMS, --CIMS方收款方法ID
                       RECEIPT_METHOD_NAME_CIMS, --CIMS方收款方法名称
                       GLDATE_PERIOD_CIMS, --CIMS方GL_DATE期间
                       TRX_NUMBER_ERP, --ERP方单据号
                       AMOUNT_ERP, --ERP方金额
                       RECEIPT_METHOD_ID_ERP,    --ERP方收款方法ID
                       GLDATE_PERIOD_ERP, --ERP方GL_DATE期间
                       CHECK_DATE --对账时间
                       ）
                    VALUES
                      (S_AR_CIMSTOERP_DETAILS.NEXTVAL, 
                       '发票',
                       '失败',
                       '单据'|| CIMSDATA_ROW.Cash_Receipt_Code ||'在ERP系统GL会计期间不一致',
                       CIMSDATA_ROW.Cash_Receipt_Code,
                       CIMSDATA_ROW.Amount,
                       CIMSDATA_ROW.Customer_Id,
                       CIMSDATA_ROW.Customer_Code,
                       CIMSDATA_ROW.Customer_Name,
                       CIMSDATA_ROW.Receipt_Method_Id,
                       CIMSDATA_ROW.Receipt_Method_Name,
                       to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM'),
                       V_TRX_NUMBER_ERP,
                       V_AMOUNT_ERP,
                       null,
                       to_char(V_GLDATE_PERIOD_ERP,'YYYY-MM'),
                       sysdate
                       );
                    P_MESSAGE := '插入AR对账明细表成功';
                    EXCEPTION
                      WHEN OTHERS THEN
                        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                                         SQLCODE,
                                                         '插入AR对账明细表失败！：' ||
                                                         SQLERRM);
                    END;
                 end if;
              
              else
                BEGIN
                --数据插入AR对账明细表
                INSERT INTO T_AR_CIMSTOERP_DETAILS
                  (DETAILS_ID, --主键
                   CHECK_TYPE, --对账业务类型：发票、收款、冲销
                   CHECK_STATUS, --对账状态:成功、失败
                   CHECK_MESSAGE, --对账信息
                   TRX_NUMBER_CIMS, --CIMS方单据号
                   AMOUNT_CIMS, --CIMS方金额
                   CUSTOMER_ID_CIMS, --CIMS方客户ID
                   CUSTOMER_CODE_CIMS, --CIMS方客户编码
                   CUSTOMER_NAME_CIMS, --CIMS方客户名称
                   RECEIPT_METHOD_ID_CIMS, --CIMS方收款方法ID
                   RECEIPT_METHOD_NAME_CIMS, --CIMS方收款方法名称
                   GLDATE_PERIOD_CIMS, --CIMS方GL_DATE期间
                   TRX_NUMBER_ERP, --ERP方单据号
                   AMOUNT_ERP, --ERP方金额
                   RECEIPT_METHOD_ID_ERP,    --ERP方收款方法ID
                   GLDATE_PERIOD_ERP, --ERP方GL_DATE期间
                   CHECK_DATE --对账时间
                   ）
                VALUES
                  (S_AR_CIMSTOERP_DETAILS.NEXTVAL, 
                   '发票',
                   '失败',
                   '单据'|| CIMSDATA_ROW.Cash_Receipt_Code ||'在ERP系统金额不一致',
                   CIMSDATA_ROW.Cash_Receipt_Code,
                   CIMSDATA_ROW.Amount,
                   CIMSDATA_ROW.Customer_Id,
                   CIMSDATA_ROW.Customer_Code,
                   CIMSDATA_ROW.Customer_Name,
                   CIMSDATA_ROW.Receipt_Method_Id,
                   CIMSDATA_ROW.Receipt_Method_Name,
                   to_char(CIMSDATA_ROW.Gl_Date,'YYYY-MM'),
                   V_TRX_NUMBER_ERP,
                   V_AMOUNT_ERP,
                   null,
                   to_char(V_GLDATE_PERIOD_ERP,'YYYY-MM'),
                   sysdate
                   );
                P_MESSAGE := '插入AR对账明细表成功';
                EXCEPTION
                  WHEN OTHERS THEN
                    P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                                     SQLCODE,
                                                     '插入AR对账明细表失败！：' ||
                                                     SQLERRM);
                END;
              end if;
            
            end if;
         
      end if;
    
      P_MESSAGE := 'SUCCESS';
      COMMIT;
    
    END LOOP;
    
    EXCEPTION
      WHEN OTHERS THEN
      
      --记录出错信息
      P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CIMSTOERP_CHECK.P_CIMSTOERP_CHECK',
                                          SQLCODE,
                                          '：' || SQLERRM);
      COMMIT;
    
    END;



END PKG_AR_CIMSTOERP_CHECK;
/

