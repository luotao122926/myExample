create FUNCTION F_GET_CREDIT_AMOUNT(IN_ENTITY_ID       NUMBER, --主体ID，不能为空
                                               IN_CUSTOMER_ID     NUMBER, --客户ID，不能为空
                                               IN_ACCOUNT_ID      NUMBER, --账户ID，可以为空
                                               IS_SALES_MAIN_TYPE VARCHAR2, --营销大类，可以为空
                                               IN_CREDIT_GROUP_ID NUMBER, --额度组ID，可以为空,
                                               IN_FLAG            NUMBER, --1 可用到款金额；2 可用折让金额；3 可提货额度；4 到款余额
                                               IS_DISCOUNT_TYPE   VARCHAR2 DEFAULT 'ALL' --ALL代表常规、折让合并 空或COMMON代表常规 其他代表折让到款
                                               ) RETURN NUMBER IS
  ----------------------------------------------------------------------
  -- Author  : liangym2
  -- Created : 2018-11-16
  -- Purpose : 查询客户款项可提货金额、可用到款金额、到款余额、折让余额、可用折让余额
  ----------------------------------------------------------------------
  VN_PICKUP_AMOUNT           NUMBER; --返回可提货金额
  VN_AVL_RCV_AMOUNT          NUMBER; --返回可用到款金额
  VN_RCV_BALANCE_AMOUNT      NUMBER; --返回到款余额
  VN_AVL_DISCOUNT_AMOUNT     NUMBER; --返回可用折让余额
  VN_DISCOUNT_BALANCE_AMOUNT NUMBER; --返回折让余额
BEGIN
  PKG_CREDIT_TOOLS.P_GET_AMOUNT(IN_ENTITY_ID,
                                IN_CUSTOMER_ID,
                                IN_ACCOUNT_ID,
                                IS_SALES_MAIN_TYPE,
                                IN_CREDIT_GROUP_ID,
                                VN_PICKUP_AMOUNT,
                                VN_AVL_RCV_AMOUNT,
                                VN_RCV_BALANCE_AMOUNT,
                                VN_AVL_DISCOUNT_AMOUNT,
                                VN_DISCOUNT_BALANCE_AMOUNT,
                                IS_DISCOUNT_TYPE);
  IF 1 = IN_FLAG THEN
    RETURN VN_AVL_RCV_AMOUNT;
  ELSIF 2 = IN_FLAG THEN
    RETURN VN_AVL_DISCOUNT_AMOUNT;
  ELSIF 3 = IN_FLAG THEN
    RETURN VN_PICKUP_AMOUNT;
  ELSIF 4 = IN_FLAG THEN
    RETURN VN_RCV_BALANCE_AMOUNT;
  END IF;
END F_GET_CREDIT_AMOUNT;
/

