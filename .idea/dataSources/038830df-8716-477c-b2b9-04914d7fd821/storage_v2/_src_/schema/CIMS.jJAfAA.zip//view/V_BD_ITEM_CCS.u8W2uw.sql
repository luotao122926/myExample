create view V_BD_ITEM_CCS as
select item_id,
       item_code,            --产品编码
       item_name,            --产品名称
       --english_name,
       productModel,         --产品型号
       marketModel,          --市场型号
       productDesc,          --产品描述
       --english_desc,
       defaultunit UOM_CODE, --基本计量单位
       ( select um.uom_name from t_bd_uom um where um.uom_code = defaultunit) UOM_NAME,
       --midPrdType,
       --purchflag,
       --productTemplate,
       productStat,          --产品状态
       --encoding_class,
       controlMode,          --控制方式
       productType,          --产品类别
       --salesTo,
       brandType,            --品牌类型
       brand,                --品牌
       powerType,            --电源类型
       voltageType,          --电压类型
       supplyFrequency,      --电源频率
       abilityName,          --能力名称
       abilityNumber,        --能力数值
       abilityUnit,          --能力单位
       energyEffRatiing,     --能效等级
       productForm,          --产品形态
       --orderType,
       productPositioning,   --产品定位
       frequencyType,        --变频/定频
       listingDate,          --上市日期
       --productRDCls,
       productNumberingCls,  --产品编码分类
       productFinancialCls,  --产品财务分类
       --productSaleCls,
       productShortName,     --产品简称
       --clientModel,
       bodyLength,           --机身尺寸(长)
       bodyWidth,            --机身尺寸(宽)
       bodyHeight,           --机身尺寸(高)
       bodySize,             --机身体积
       grossWeight,          --毛重
       netWeight,            --净重
       packingLength,        --外包装尺寸(长)
       packingWidth,         --外包装尺寸(宽)
       packingHeight,        --外包装尺寸(高)
       packingSize,          --外包装体积
       productSeries,        --产品系列
       --productModelCode,
       commodityBarCode,     --商品条形码
       packingType,          --包装类型
       packingAmount,        --包装数量
       productCertReqest,    --产品认证
       --climateType,
       --devProjectId,
       strategyProductFlag,  --是否战略产品
       --referenceCode,
       energySaving,         --节能产品
       viceBrand,            --副品牌
       eliminationFlag,      --淘汰标示
       cryogen,              --制冷剂
       stackLayers,          --码放层数
       loadingCapacity,      --装柜量
       policy,               --国家政策标识
       --exemptionFlag,
       productPhase,         --生命周期
       distributionChannel,  --销售渠道
       --planTime,
       productionType,       --投产鉴定时间
       bodyColor,            --机身颜色
       --drawNumber,
       currentType,          --电流类型
       --productLifecycle,
       --projects,
       --projectsStatus,
       --productManager,
       --productPlatform,
       --derivedDesc,
       is_rounding,          --是否凑整
       rounding_cnt,         --凑整数据
       corporation,          --制造商主体
       sales_main_type,      --产品大类
       sales_sub_type,       --产品小类
       purchase_flag,        --采购使用标志
       sale_flag,            --销售使用标志
       plan_flag,            --计划使用标志
       invstran_flag,        --库存事务使用标志
       invoice_flag,         --发票使用标志
       is_specialfor,        --是否专供
       decode(ENTITY_ID,
              28,
              decode(sales_main_type, 'KT_TG', 10, ENTITY_ID),
              29,
              decode(sales_main_type, 'BX_TG', 12, ENTITY_ID),
              ENTITY_ID) ENTITY_ID,            --主体ID
       created_by,　　　　   --创建人
       creation_date,        --创建时间
       last_updated_by,      --修改人
       last_update_date ,     --修改时间
       active_flag,   --是否有效，Y有效
       is_material --物料值：W物料、Y推广物料、N产品
       ,(select c.code_name from t_bd_item_codelist c where c.codetype = 'GE_MPL_BRAND' and c.code_value = brand) brand_name --品牌名称
       ,ENCODING_CLASS
       ,C2M_CUSTOMIZED_FLAG --是否C2M定制
       ,item_plot_ratio --正品产品占用面积
       ,non_item_plot_ratio ---非正品产品占用面积
       ,tt.catalog_attribute01
       ,tt.catalog_attribute02
       ,tt.catalog_attribute03
       ,tt.catalog_attribute09 TUISONG_CCS
  from T_BD_ITEM tt
/

