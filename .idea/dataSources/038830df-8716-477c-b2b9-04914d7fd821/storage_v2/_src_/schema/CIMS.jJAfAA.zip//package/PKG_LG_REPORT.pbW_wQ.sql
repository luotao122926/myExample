create PACKAGE      PKG_LG_REPORT AS

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-02-05
  -- PURPOSE : 基地发运汇总
  ----------------------------------------------------------------------
  PROCEDURE P_LG_AREA_SHIP_COLLECT(O_RESULT     OUT VARCHAR2, --返回错误码
                                   O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                   );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-02-05
  -- PURPOSE : 基地发运明细
  ----------------------------------------------------------------------
  PROCEDURE P_LG_AREA_SHIP_DETAIL(O_RESULT     OUT VARCHAR2, --返回错误码
                                  O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                  );

END PKG_LG_REPORT;
/

