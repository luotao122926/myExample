create view V_CUSTOMER_CHANNEL_TYPE as
select CHANNEL_TYPE_ID,
       ENTITY_ID,
       CUSTOMER_ID,
       CUSTOMER_CODE,
       DEPT_ID,
       DEPT_CODE,
       INDUSTRY_TYPE,
       ACTIVE_FLAG,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATE_DATE,
       LAST_UPDATE_BY,
       LAST_INTERFACE_DATE,
       SIEBEL_CUSTOMER_ID,
       SIEBEL_CHANNEL_TYPE_ID,
       PRE_FIELD_01,
       PRE_FIELD_02,
       PRE_FIELD_03,
       PRE_FIELD_04,
       PRE_FIELD_05,
       PRE_FIELD_06
  from T_CUSTOMER_CHANNEL_TYPE with read only
/

comment on column V_CUSTOMER_CHANNEL_TYPE.CHANNEL_TYPE_ID is '业态渠道类型ID'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.ENTITY_ID is '主体ID'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.CUSTOMER_ID is '客户ID'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.CUSTOMER_CODE is '客户编码'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.DEPT_ID is '事业部ID'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.DEPT_CODE is '事业部编码'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.INDUSTRY_TYPE is '业态类型(渠道客户/工程客户/零售客户/纯电商客户)'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.ACTIVE_FLAG is '是否有效(Y/N)'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.CREATED_BY is '创建人'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.CREATION_DATE is '创建日期'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.LAST_UPDATE_DATE is '最后修改时间'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.LAST_UPDATE_BY is '最后修改人'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.LAST_INTERFACE_DATE is '最后同步时间'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.SIEBEL_CUSTOMER_ID is '主数据客户ID'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.SIEBEL_CHANNEL_TYPE_ID is '主数据业态类型ID'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.PRE_FIELD_01 is '预留字段1'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.PRE_FIELD_02 is '预留字段2'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.PRE_FIELD_03 is '预留字段3'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.PRE_FIELD_04 is '预留字段4'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.PRE_FIELD_05 is '预留字段5'
/

comment on column V_CUSTOMER_CHANNEL_TYPE.PRE_FIELD_06 is '预留字段6'
/

