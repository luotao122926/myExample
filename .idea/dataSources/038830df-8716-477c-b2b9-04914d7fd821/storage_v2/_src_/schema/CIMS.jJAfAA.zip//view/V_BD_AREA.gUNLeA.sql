create view V_BD_AREA as
select uou."ID",uou."NAME",uou."DESCRIPTION",uou."CODE",uou."TYPE_ID",uou."TIME_BEGIN",uou."TIME_END",uou."IS_ENABLED",uou."CREATED_BY",uou."CREATION_DATE",uou."LAST_UPDATED_BY",uou."LAST_UPDATE_DATE",uou."DELETION_DATE",uou."ACTIVE_FLAG",uou."UNIT_ID",
       (select decode(ut.code,
                      'BU',
                      ou.Unit_Id,
                      (select uu.unit_id
                         from up_org_dimension_unit du,
                              up_org_dimension_unit odu,
                              up_org_unit uu
                        where du.dimension_unit_id =
                              u.parent_dimension_unit_id
                          and odu.dimension_unit_id =
                              du.parent_dimension_unit_id
                          and uu.id = odu.unit_id))
          from up_org_dimension_unit du, up_org_unit ou, up_org_unit_type ut
         where du.dimension_unit_id = u.parent_dimension_unit_id
           and du.unit_id = ou.id
           and ut.id = ou.type_id) entity_id,
      (select decode(ut.code,
                      'SR',
                      ou.unit_id,
                      null)
          from up_org_dimension_unit du, up_org_unit ou, up_org_unit_type ut
         where du.dimension_unit_id = u.parent_dimension_unit_id
           and du.unit_id = ou.id
           and ut.id = ou.type_id) area_id
  from up_org_unit uou, up_org_dimension_unit u
 where u.unit_id = uou.id
   and uou.type_id in
       (select ut.id from up_org_unit_type ut where ut.code = 'SR')
 start with u.parent_dimension_unit_id = '-1'
connect by prior u.dimension_unit_id = u.parent_dimension_unit_id
/

