create view UP_ORG_ASSIGNABLE_UNIT_USER as
select t.user_id || t.entity_id ID,
         t.up_user_id USER_ID,
         (select u.id from up_org_unit u where u.unit_id = t.entity_id) UNIT_ID,
         'init' CREATED_BY,
         sysdate CREATION_DATE,
         'init' LAST_UPDATED_BY,
         sysdate LAST_UPDATE_DATE
    from v_up_user_entity t
   where t.entity_id is not null
/

