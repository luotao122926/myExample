create PACKAGE BODY PKG_CUSTOMER_PUB IS
  FUNCTION F_CHECK_CUST_HAVE_FREEZING
  --检查客户集团、事业部、中心、账户是否冻结
  (P_ACTION_FLAG     varchar2, --功能冻结标识：01信用铺底02提货订单03收款04销售05政策，不能为空，为空是返回-1
   P_CUSTOMER_ID     number, --客户ID，不能为空，为空是返回-1
   P_ENTITY_ID       number, --事业部对应的主体ID，不能为空，为空是返回-1 建议传入前台cookie的主体ID
   P_SALES_CENTER_ID number, --中心ID，可以为空，不为空时不判断账户是否冻结
   P_ACCOUNT_ID      number --账户ID，可以为空
   --，不为空时判断账户或者账户所挂的中心是否冻结，但不检查所挂中心ID是否与P_SALES_CENTER_ID一致
   ) return number
  --0成功（无冻结状态）
    --1客户头（集团）冻结
    --2事业部冻结
    --3账户所挂中心冻结
    --4账户非有效（冻结、失效）
    --5传入中心冻结
    --负1传入参数不合法
    ---2传入账户ID对应的账户或账户中心关系、客户中心关系不存在
    ---3传入账户对应的客户id或主体id与传入的客户id或主体id不一致
   IS
    P_RESULT        NUMBER;
    V_CNT           NUMBER;
    V_FREEZING      VARCHAR2(30) := 'Freezing';
    V_R_ACC         T_CUSTOMER_ACCOUNT%ROWTYPE;
    V_R_ACC_ORG_REL T_CUSTOMER_ACC_ORG_RELATION%ROWTYPE;
    V_ORG_STATUS    T_CUSTOMER_ORG.ACTIVE_FLAG%TYPE;
  BEGIN
    P_RESULT := 0;
    IF P_ACTION_FLAG IS NULL OR P_CUSTOMER_ID IS NULL OR 0 >= P_CUSTOMER_ID OR
       P_ENTITY_ID IS NULL OR 0 >= P_ENTITY_ID THEN
      P_RESULT := -1;
      RETURN P_RESULT;
    END IF;
    --
    SELECT COUNT(0)
      INTO V_CNT
      FROM T_CUSTOMER_HEADER H
     WHERE H.CUSTOMER_ID = P_CUSTOMER_ID
       AND H.CUSTOMER_STATUS = V_FREEZING -- AND H.ACTIVE_FLAG = 'Active'
       AND NOT EXISTS (SELECT 1
              FROM T_CUSTOMER_HEADER T
             WHERE T.CUSTOMER_ID = H.CUSTOMER_ID
               AND 'Active' = T.CUSTOMER_STATUS);
    IF V_CNT > 0 THEN
      P_RESULT := 1;
      RETURN P_RESULT;
    END IF;
    --
    SELECT COUNT(0)
      INTO V_CNT
      FROM T_CUSTOMER_DEPT H
     WHERE H.CUSTOMER_ID = P_CUSTOMER_ID
       AND H.DEPT_ID = P_ENTITY_ID
       AND H.DEPT_CUSTOMER_STATUS = V_FREEZING -- AND H.ACTIVE_FLAG = 'Active'
       AND NOT EXISTS
     (SELECT 1
              FROM T_CUSTOMER_DEPT T
             WHERE T.CUSTOMER_ID = H.CUSTOMER_ID
               AND T.DEPT_ID = H.DEPT_ID
               AND 'Active' = T.DEPT_CUSTOMER_STATUS);
    IF V_CNT > 0 THEN
      P_RESULT := 2;
      RETURN P_RESULT;
    END IF;
    --
    IF 0 < P_ACCOUNT_ID THEN
      BEGIN
        SELECT *
          INTO V_R_ACC
          FROM T_CUSTOMER_ACCOUNT T
         WHERE T.ACCOUNT_ID = P_ACCOUNT_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_RESULT := -2;
          RETURN P_RESULT;
      END;
      IF V_R_ACC.CUSTOMER_ID <> P_CUSTOMER_ID OR
         P_ENTITY_ID <> V_R_ACC.ENTITY_ID THEN
        P_RESULT := -3;
        RETURN P_RESULT;
      END IF;
      BEGIN
        SELECT *
          INTO V_R_ACC_ORG_REL
          FROM T_CUSTOMER_ACC_ORG_RELATION T
         WHERE T.ACCOUNT_ID = P_ACCOUNT_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_RESULT := -2;
          RETURN P_RESULT;
      END;
      SELECT (SELECT T.ACTIVE_FLAG
                FROM T_CUSTOMER_ORG T
               WHERE T.CUSTOMER_ORG_ID = V_R_ACC_ORG_REL.CUSTOMER_ORG_ID)
        INTO V_ORG_STATUS
        FROM DUAL;
      IF V_ORG_STATUS IS NULL THEN
        P_RESULT := -2;
        RETURN P_RESULT;
      END IF;
      IF V_ORG_STATUS = V_FREEZING THEN
        P_RESULT := 3;
        RETURN P_RESULT;
      END IF;
      IF V_R_ACC.ACTIVE_FLAG <> 'Y' OR V_R_ACC.ACCOUNT_STATUS <> '1' THEN
        P_RESULT := 4;
        RETURN P_RESULT;
      END IF;
    END IF;
    --
    IF 0 >= NVL(P_ACCOUNT_ID, 0) AND 0 < P_SALES_CENTER_ID THEN
      SELECT COUNT(0)
        INTO V_CNT
        FROM T_CUSTOMER_ORG H
       WHERE H.CUSTOMER_ID = P_CUSTOMER_ID
         AND H.ENTITY_ID = P_ENTITY_ID
         AND H.SALES_CENTER_ID = P_SALES_CENTER_ID
         AND H.ACTIVE_FLAG = V_FREEZING
         AND NOT EXISTS (SELECT 1
                FROM T_CUSTOMER_ORG T
               WHERE T.CUSTOMER_ID = H.CUSTOMER_ID
                 AND T.ENTITY_ID = H.ENTITY_ID
                 AND T.SALES_CENTER_ID = H.SALES_CENTER_ID
                 AND 'Active' = T.ACTIVE_FLAG);
      IF V_CNT > 0 THEN
        P_RESULT := 5;
        RETURN P_RESULT;
      END IF;
    END IF;
    RETURN P_RESULT;
  END F_CHECK_CUST_HAVE_FREEZING;

  FUNCTION F_CHECK_CUST_HAVE_STATUS
  --检查客户集团、事业部、中心、账户的状态是否是P_STATUS指定的状态
  (P_CUSTOMER_ID     number, --客户ID，不能为空，为空是返回-1
   P_ENTITY_ID       number, --事业部对应的主体ID，不能为空，为空是返回-1 建议传入前台cookie的主体ID
   P_SALES_CENTER_ID number, --中心ID，可以为空，不为空时不判断账户的状态是否是P_STATUS指定的状态
   P_ACCOUNT_ID      number, --账户ID，可以为空
   --，不为空时判断账户或者账户所挂的中心的状态是否是P_STATUS指定的状态，但不检查所挂中心ID是否与P_SALES_CENTER_ID一致
   P_STATUS VARCHAR2 DEFAULT 'Inactive') return number
  --0成功（无P_STATUS指定的状态）
    --1客户头（集团）处于P_STATUS指定的状态
    --2事业部处于P_STATUS指定的状态
    --3账户所挂中心处于P_STATUS指定的状态
    --4账户非有效（冻结、失效）
    --5传入中心处于P_STATUS指定的状态
    --负1传入参数不合法:P_STATUS必须是Freezing或Inactive
    ---2传入账户ID对应的账户或账户中心关系、客户中心关系不存在
    ---3传入账户对应的客户id或主体id与传入的客户id或主体id不一致
   IS
    P_RESULT        NUMBER;
    V_CNT           NUMBER;
    V_R_ACC         T_CUSTOMER_ACCOUNT%ROWTYPE;
    V_R_ACC_ORG_REL T_CUSTOMER_ACC_ORG_RELATION%ROWTYPE;
    V_ORG_STATUS    T_CUSTOMER_ORG.ACTIVE_FLAG%TYPE;
  BEGIN
    P_RESULT := 0;
    IF P_CUSTOMER_ID IS NULL OR 0 >= P_CUSTOMER_ID OR P_ENTITY_ID IS NULL OR
       0 >= P_ENTITY_ID OR P_STATUS NOT IN ('Freezing','Inactive') THEN
      P_RESULT := -1;
      RETURN P_RESULT;
    END IF;
    --
    SELECT COUNT(0)
      INTO V_CNT
      FROM T_CUSTOMER_HEADER H
     WHERE H.CUSTOMER_ID = P_CUSTOMER_ID
       AND H.CUSTOMER_STATUS = P_STATUS -- AND H.ACTIVE_FLAG = 'Active'
       AND NOT EXISTS (SELECT 1
              FROM T_CUSTOMER_HEADER T
             WHERE T.CUSTOMER_ID = H.CUSTOMER_ID
               AND 'Active' = T.CUSTOMER_STATUS);
    IF V_CNT > 0 THEN
      P_RESULT := 1;
      RETURN P_RESULT;
    END IF;
    --
    SELECT COUNT(0)
      INTO V_CNT
      FROM T_CUSTOMER_DEPT H
     WHERE H.CUSTOMER_ID = P_CUSTOMER_ID
       AND H.DEPT_ID = P_ENTITY_ID
       AND H.DEPT_CUSTOMER_STATUS = P_STATUS -- AND H.ACTIVE_FLAG = 'Active'
       AND NOT EXISTS
     (SELECT 1
              FROM T_CUSTOMER_DEPT T
             WHERE T.CUSTOMER_ID = H.CUSTOMER_ID
               AND T.DEPT_ID = H.DEPT_ID
               AND 'Active' = T.DEPT_CUSTOMER_STATUS);
    IF V_CNT > 0 THEN
      P_RESULT := 2;
      RETURN P_RESULT;
    END IF;
    --
    IF 0 < P_ACCOUNT_ID THEN
      BEGIN
        SELECT *
          INTO V_R_ACC
          FROM T_CUSTOMER_ACCOUNT T
         WHERE T.ACCOUNT_ID = P_ACCOUNT_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_RESULT := -2;
          RETURN P_RESULT;
      END;
      IF V_R_ACC.CUSTOMER_ID <> P_CUSTOMER_ID OR
         P_ENTITY_ID <> V_R_ACC.ENTITY_ID THEN
        P_RESULT := -3;
        RETURN P_RESULT;
      END IF;
      BEGIN
        SELECT *
          INTO V_R_ACC_ORG_REL
          FROM T_CUSTOMER_ACC_ORG_RELATION T
         WHERE T.ACCOUNT_ID = P_ACCOUNT_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_RESULT := -2;
          RETURN P_RESULT;
      END;
      SELECT (SELECT T.ACTIVE_FLAG
                FROM T_CUSTOMER_ORG T
               WHERE T.CUSTOMER_ORG_ID = V_R_ACC_ORG_REL.CUSTOMER_ORG_ID)
        INTO V_ORG_STATUS
        FROM DUAL;
      IF V_ORG_STATUS IS NULL THEN
        P_RESULT := -2;
        RETURN P_RESULT;
      END IF;
      IF V_ORG_STATUS = P_STATUS THEN
        P_RESULT := 3;
        RETURN P_RESULT;
      END IF;
      IF ('Inactive' = P_STATUS AND V_R_ACC.ACCOUNT_STATUS = '2')
         OR ('Freezing' = P_STATUS AND
         (V_R_ACC.ACTIVE_FLAG <> 'Y' OR V_R_ACC.ACCOUNT_STATUS <> '1')) THEN
        P_RESULT := 4;
        RETURN P_RESULT;
      END IF;
    END IF;
    --
    IF 0 >= NVL(P_ACCOUNT_ID, 0) AND 0 < P_SALES_CENTER_ID THEN
      SELECT COUNT(0)
        INTO V_CNT
        FROM T_CUSTOMER_ORG H
       WHERE H.CUSTOMER_ID = P_CUSTOMER_ID
         AND H.ENTITY_ID = P_ENTITY_ID
         AND H.SALES_CENTER_ID = P_SALES_CENTER_ID
         AND H.ACTIVE_FLAG = P_STATUS
         AND NOT EXISTS (SELECT 1
                FROM T_CUSTOMER_ORG T
               WHERE T.CUSTOMER_ID = H.CUSTOMER_ID
                 AND T.ENTITY_ID = H.ENTITY_ID
                 AND T.SALES_CENTER_ID = H.SALES_CENTER_ID
                 AND 'Active' = T.ACTIVE_FLAG);
      IF V_CNT > 0 THEN
        P_RESULT := 5;
        RETURN P_RESULT;
      END IF;
    END IF;
    RETURN P_RESULT;
  END F_CHECK_CUST_HAVE_STATUS;

  FUNCTION F_CHECK_CUST_HAVE_FREEZING_MSG
  --检查客户集团、事业部、中心、账户是否冻结
  (P_ACTION_FLAG     varchar2, --功能冻结标识：01信用铺底02提货订单03收款04销售05政策，不能为空，为空是返回-1
   P_CUSTOMER_ID     number, --客户ID，不能为空，为空是返回-1
   P_ENTITY_ID       number, --事业部对应的主体ID，不能为空，为空是返回-1 建议传入前台cookie的主体ID
   P_SALES_CENTER_ID number, --中心ID，可以为空，不为空时不判断账户是否冻结
   P_ACCOUNT_ID      number --账户ID，可以为空
   --，不为空时判断账户或者账户所挂的中心是否冻结，但不检查所挂中心ID是否与P_SALES_CENTER_ID一致
   ) return varchar2
  --0成功（无冻结状态）
    --1客户头（集团）冻结
    --2事业部冻结
    --3账户所挂中心冻结
    --4账户非有效（冻结、失效）
    --5传入中心冻结
    --负1传入参数不合法
    ---2传入账户ID对应的账户或账户中心关系、客户中心关系不存在
    ---3传入账户对应的客户id或主体id与传入的客户id或主体id不一致
   IS
    P_RESULT       NUMBER;
    V_FREEZING_MSG VARCHAR2(300);
  BEGIN
    SELECT F_CHECK_CUST_HAVE_FREEZING(P_ACTION_FLAG,
                                      P_CUSTOMER_ID,
                                      P_ENTITY_ID,
                                      P_SALES_CENTER_ID,
                                      P_ACCOUNT_ID)
      INTO P_RESULT
      FROM DUAL;
    V_FREEZING_MSG := NULL;
    IF -1 = P_RESULT THEN
      V_FREEZING_MSG := '传入参数不合法';
    ELSIF -2 = P_RESULT THEN
      V_FREEZING_MSG := '传入账户ID对应的账户或账户中心关系、客户中心关系不存在';
    ELSIF -3 = P_RESULT THEN
      V_FREEZING_MSG := '传入账户对应的客户id或主体id与传入的客户id或主体id不一致';
    ELSIF 0 = P_RESULT THEN
      V_FREEZING_MSG := 'SUCCESS';
    ELSIF 1 = P_RESULT THEN
      V_FREEZING_MSG := '客户在集团已冻结[customerID=' || P_CUSTOMER_ID || ']';
    ELSIF 2 = P_RESULT THEN
      V_FREEZING_MSG := '客户在事业部已冻结[customerID=' || P_CUSTOMER_ID ||
                        'entityID=' || P_ENTITY_ID || ']';
    ELSIF 3 = P_RESULT THEN
      V_FREEZING_MSG := '客户账户所挂中心已冻结[customerID=' || P_CUSTOMER_ID ||
                        'entityID=' || P_ENTITY_ID || 'accountID=' ||
                        P_ACCOUNT_ID || ']';
    ELSIF 4 = P_RESULT THEN
      V_FREEZING_MSG := '客户账户已冻结或失效[customerID=' || P_CUSTOMER_ID ||
                        'entityID=' || P_ENTITY_ID || 'accountID=' ||
                        P_ACCOUNT_ID || ']';
    ELSIF 5 = P_RESULT THEN
      V_FREEZING_MSG := '客户中心已冻结[customerID=' || P_CUSTOMER_ID ||
                        'entityID=' || P_ENTITY_ID || 'salesCenterID=' ||
                        P_SALES_CENTER_ID || ']';
    END IF;
    RETURN V_FREEZING_MSG;
  END F_CHECK_CUST_HAVE_FREEZING_MSG;

  FUNCTION F_CHECK_CUST_H_UNDO_SHIP
  --检查账户是否存在未完成的发货通知单，如果存在，返回非空的字符串，否则返回空
  (IN_ENTITY_ID    number, --主体ID
   IN_ACCOUNT_ID   NUMBER, --账户ID，可以为空，为空时取IS_ACCOUNT_CODE进行查询，不为空时关联账户表得到账户编码
   IS_ACCOUNT_CODE VARCHAR2 --账户编码，可以为空，不为空时忽略IN_ACCOUNT_ID，为空时IN_ACCOUNT_ID关联账户表得到账户编码
   ) RETURN VARCHAR2 IS
    V_CNT NUMBER;
  BEGIN
    IF IN_ACCOUNT_ID IS NULL THEN
      SELECT SUM(A.FLAG)
        INTO V_CNT
        FROM (SELECT COUNT(0) FLAG
                FROM T_LG_SHIP_DOC D, T_LG_SHIP_DOC_LINE L
               WHERE D.SHIP_DOC_ID = L.SHIP_DOC_ID
                 AND D.ENTITY_ID = IN_ENTITY_ID
                 AND (L.ITEM_QTY - L.FACT_SHIP_QTY - L.CANCEL_QTY) > 0
                 AND D.ACCOUNT_CODE = IS_ACCOUNT_CODE
                 AND D.DOC_STATUS = '00'
              UNION ALL
              SELECT COUNT(0) FLAG
                FROM T_LG_SHIP_PLAN P
               WHERE P.ENTITY_ID = IN_ENTITY_ID
                 AND P.ACCOUNT_CODE = IS_ACCOUNT_CODE
                 AND P.STATUS = '00') A;
    ELSE
      WITH AT AS
       (SELECT NVL(ACCOUNT_CODE, IS_ACCOUNT_CODE) AS ACCOUNT_CODE
          FROM DUAL
          LEFT JOIN T_CUSTOMER_ACCOUNT
            ON (ACCOUNT_ID = IN_ACCOUNT_ID))
      SELECT SUM(A.FLAG)
        INTO V_CNT
        FROM (SELECT COUNT(0) FLAG
                FROM T_LG_SHIP_DOC D, T_LG_SHIP_DOC_LINE L
               WHERE D.SHIP_DOC_ID = L.SHIP_DOC_ID
                 AND D.ENTITY_ID = IN_ENTITY_ID
                 AND (L.ITEM_QTY - L.FACT_SHIP_QTY - L.CANCEL_QTY) > 0
                 AND D.ACCOUNT_CODE =
                     (SELECT A.ACCOUNT_CODE
                        FROM T_CUSTOMER_ACCOUNT A
                       WHERE (A.ACCOUNT_ID = IN_ACCOUNT_ID))
                 AND D.DOC_STATUS = '00'
              UNION ALL
              SELECT COUNT(0) FLAG
                FROM T_LG_SHIP_PLAN P
               WHERE P.ENTITY_ID = IN_ENTITY_ID
                 AND P.STATUS = '00'
                 AND P.ACCOUNT_CODE =
                     (SELECT A.ACCOUNT_CODE
                        FROM T_CUSTOMER_ACCOUNT A
                       WHERE (A.ACCOUNT_ID = IN_ACCOUNT_ID))) A;
    END IF;
    IF 0 < V_CNT THEN
      RETURN '存在未完成*';
    END IF;
    RETURN NULL;
  END F_CHECK_CUST_H_UNDO_SHIP;

END PKG_CUSTOMER_PUB;
/

