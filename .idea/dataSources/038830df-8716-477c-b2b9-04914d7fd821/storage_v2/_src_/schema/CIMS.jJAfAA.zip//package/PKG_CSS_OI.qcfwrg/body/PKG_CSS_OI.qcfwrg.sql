create PACKAGE BODY PKG_CSS_OI IS

  procedure p_synchro_install(p_entity_id number) is
    v_synchro_date date;
    v_next_date    date;
    v_end_date     date;
    v_message      varchar2(400);
  
  begin
    --取昨天的日期作为最后要同步的日期
    v_end_date := trunc(sysdate) - 1;
  
    --取出上次同步日期+1作为开始同步日期
    for c_sd in (select be.entity_id,
                        be.param_entity_id,
                        to_date(be.entity_value, 'yyyy-mm-dd') + 1 begin_date
                   from T_BD_PARAM_LIST bl, T_BD_PARAM_ENTITY be

                  where bl.param_list_id = be.param_list_id
                    and bl.param_code = 'css_synchro_date'
                    and to_date(be.entity_value, 'yyyy-mm-dd') <= 
                        v_end_date
                    and be.entity_id = p_entity_id)  
  
                   
      loop
      begin
        v_synchro_date := c_sd.begin_date;
        v_synchro_date := sysdate;
      
        --删除已存在的数据
        delete from intf_pol_css_install_card_sum
         where install_card_date >= v_synchro_date
           and entity_id = c_sd.entity_id;
      
        --接日期循环同步数据
        while (v_synchro_date <= v_end_date) loop
          v_next_date := v_synchro_date + 1;
        
          --写安装卡统计表
          insert into intf_pol_css_install_card_sum
            (install_card_date,
             css_center_code,
             material_code,
             quantity,
             entity_id)
            select pub_create_date install_card_date,
                   sparent_unit_id css_center_code,
                   sprod_id material_code,
                   count(*) quantity,
                   p_entity_id entity_id
              from CSS_OI_IMS_INSTALL
             where pub_create_date >= v_synchro_date
               and pub_create_date < v_next_date
               and sprod_id is not null
             group by pub_create_date,sparent_unit_id, sprod_id;
        
          --更新客户id、商品id
          update intf_pol_css_install_card_sum s
             set customer_id =
                 (select r.customer_id
                    from t_pol_oi_customer_css_rela r
                   where r.css_center_code = s.css_center_code),
                 material_id =
                 (select m.item_id
                    from t_bd_item m
                   where m.item_code = s.material_code
                     and m.entity_id = c_sd.entity_id)
           where install_card_date = v_synchro_date
             and entity_id = c_sd.entity_id;
        
          v_synchro_date := v_synchro_date + 1;
        end loop;
      exception
        when others then
          begin
            rollback;
            --记录出错信息
            v_message := PKG_BD.F_ADD_ERROR_LOG('PKG_CSS_OI.p_synchro_install',
                                                                       sqlcode,
                                                                       '同步安装卡失败：'||sqlerrm);              
          
            commit;
          end;
      end;
    
      --记录同步日期
      if (v_synchro_date > v_end_date) then
         update t_bd_param_entity be
          set be.entity_value = to_char(v_end_date, 'yyyy-mm-dd')
          where be.param_entity_id = c_sd.param_entity_id;
      
        commit;
      end if;
    end loop;
  exception
    when others then
      begin
        rollback;
        --记录出错信息
        v_message := PKG_BD.F_ADD_ERROR_LOG('PKG_CSS_OI.p_synchro_install',
                                                                       sqlcode,
                                                                       '同步安装卡失败：'||sqlerrm);
      
        commit;
      end;
  end p_synchro_install;
  
  PROCEDURE GET_PG_DETAIL_FROM_CSS(p_entity_id number)
    IS
   v_synchro_date date;
    v_next_date    date;
    v_end_date     date;
    v_message      varchar2(400);
  
  begin
    --取昨天的日期作为最后要同步的日期
    v_end_date := trunc(sysdate) - 1;
    
        --删除已存在的数据
    delete from t_pg_business_detail pd
      where pd.entity_id = p_entity_id;
  
     --取出上次同步日期+1作为开始同步日期
     for pro_cur in (SELECT PB.ENTITY_ID, PB.BUSINESS_ID, PB.PROJECT_CODE
                         FROM T_PG_BUSINESS PB,T_BD_PARAM_LIST bl, T_BD_PARAM_ENTITY be
                                      where bl.param_list_id = be.param_list_id
                    and bl.param_code = 'css_synchro_date'
                    and pb.entity_id = p_entity_id
                    and pb.status = '2'
                    and pb.entity_id = be.entity_id
                    AND PB.LOGIN_TIME >= to_date(BE.ENTITY_VALUE, 'yyyy-mm-dd'))  
  
                   
      loop
        --根据销售单产生开单、安装明细
        insert into t_pg_business_detail
          (business_detail_id, entity_id, business_id, project_code, item_id, item_code, 
          item_desc, uom_code, requis_qty, so_order_qty, item_settle_price, item_settle_amount, 
          install_qty, created_by, creation_date, last_updated_by, last_update_date)
        SELECT S_PG_BUSINESS_DETAIL.Nextval,
                pro_cur.entity_id,
                PB.BUSINESS_ID,
                pro_cur.project_code,
                PL.ITEM_ID,
                PL.ITEM_CODE,
                PL.ITEM_DESC,
                PL.UOM_CODE,
                PL.REQUIS_QTY,
                0,
                0,
                0,
                0,--install_qty
                0,
                SYSDATE,
                0,
                SYSDATE                        
          FROM T_PG_BUSINESS PB,
               T_PG_BUSINESS_LINE PL
          WHERE PB.PROJECT_CODE = pro_cur.project_code
            AND PB.ENTITY_ID = pro_cur.entity_id
            AND PB.BUSINESS_ID = PL.BUSINESS_ID(+);
         
        --根据销售单更新开单数
         UPDATE t_pg_business_detail PD
           SET (PD.SO_ORDER_QTY, PD.ITEM_SETTLE_PRICE, PD.ITEM_SETTLE_AMOUNT) = 
           (SELECT SUM(SL.ITEM_QTY), MAX(SL.ITEM_SETTLE_PRICE), SUM(SL.ITEM_SETTLE_AMOUNT)
               FROM T_SO_HEADER SH,
                     T_SO_LINE SL
                WHERE SH.ENTITY_ID = pro_cur.entity_id
                  AND SH.PROJ_REG_CODE = pro_cur.project_code
                  AND SH.SO_HEADER_ID = SL.SO_HEADER_ID(+)
                  AND SL.ITEM_ID = PD.ITEM_ID
                 GROUP BY SL.ITEM_ID)
          WHERE PD.BUSINESS_ID = pro_cur.Business_Id;
          
        --根据销售单产生开单、安装明细
        insert into t_pg_business_detail
          (business_detail_id, entity_id, business_id, project_code, item_id, item_code, 
          item_desc, uom_code, requis_qty, so_order_qty, item_settle_price, item_settle_amount, 
          install_qty, created_by, creation_date, last_updated_by, last_update_date)
        SELECT S_PG_BUSINESS_DETAIL.Nextval,
                pro_cur.entity_id,
                pro_cur.BUSINESS_ID,
                pro_cur.project_code,
                PA.ITEM_ID,
                PA.ITEM_CODE,
                PA.ITEM_NAME,
                PA.ITEM_UOM,
                0,
                PA.SUM_ITEM_QTY, 
                PA.SUM_ITEM_SETTLE_PRICE, 
                PA.SUM_ITEM_SETTLE_AMOUNT,
                0,--install_qty
                0,
                SYSDATE,
                0,
                SYSDATE                     
            FROM  (     
          SELECT 
                SL.ITEM_ID,
                SL.ITEM_CODE,
                SL.ITEM_NAME,
                SL.ITEM_UOM,     
                SUM(SL.ITEM_QTY) SUM_ITEM_QTY, 
                MAX(SL.ITEM_SETTLE_PRICE) SUM_ITEM_SETTLE_PRICE, 
                SUM(SL.ITEM_SETTLE_AMOUNT) SUM_ITEM_SETTLE_AMOUNT         
          FROM  T_SO_HEADER SH,
                T_SO_LINE SL
          WHERE SH.ENTITY_ID = pro_cur.entity_id
            AND SH.PROJ_REG_CODE = pro_cur.project_code
            AND SH.SO_HEADER_ID = SL.SO_HEADER_ID(+)
            AND NOT EXISTS (SELECT 1 FROM t_pg_business_detail PD WHERE PD.ITEM_ID = SL.ITEM_ID)
            GROUP BY SL.ITEM_ID, SL.ITEM_CODE, SL.ITEM_NAME, SL.ITEM_UOM
            ) PA
            ;
            
        --根据安装卡更新安装数量  
        UPDATE T_PG_BUSINESS_DETAIL PD
           SET PD.INSTALL_QTY =
               (SELECT COUNT(SPROD_ID)
                  FROM css_oi_ims_install CI
                 WHERE CI.SENGINEER_ID = pro_cur.project_code
                   AND CI.SPROD_ID = PD.ITEM_CODE)
         WHERE PD.PROJECT_CODE = pro_cur.project_code;
                 
                --根据销售单产生开单、安装明细
        insert into t_pg_business_detail
          (business_detail_id, entity_id, business_id, project_code, item_id, item_code, 
          item_desc, uom_code, requis_qty, so_order_qty, item_settle_price, item_settle_amount, 
          install_qty, created_by, creation_date, last_updated_by, last_update_date)
        SELECT S_PG_BUSINESS_DETAIL.Nextval,
                pro_cur.entity_id,
                pro_cur.BUSINESS_ID,
                pro_cur.project_code, 
                0,
                PA.SPROD_ID,
                '',
                '',
                0,
                0,
                0,
                0,     
                PA.INS_QTY, 
                0,
                SYSDATE,
                0,
                SYSDATE  
             FROM   (
          SELECT 
                CI.SENGINEER_ID,
                CI.SPROD_ID,
                COUNT(CI.SENGINEER_ID) INS_QTY   
          FROM  css_oi_ims_install CI
          WHERE CI.SENGINEER_ID = pro_cur.project_code
            AND NOT EXISTS (SELECT 1 FROM t_pg_business_detail PD WHERE PD.ITEM_CODE = CI.SPROD_ID)
            GROUP BY CI.SENGINEER_ID, CI.SPROD_ID 
            ) PA
            ;
      
      UPDATE t_pg_business_detail PD
         SET (PD.ITEM_ID, PD.ITEM_DESC, PD.UOM_CODE) =
             (SELECT BI.ITEM_ID, BI.ITEM_NAME, BI.DEFAULTUNIT
                FROM T_BD_ITEM BI
               WHERE BI.ITEM_CODE = PD.ITEM_CODE
                 AND BI.ENTITY_ID = pro_cur.entity_id)
       WHERE PD.PROJECT_CODE = pro_cur.project_code
         AND PD.ITEM_ID = 0;
      
      --记录同步日期, 此段以后再启用
      /*if (v_synchro_date > v_end_date) then
         update t_bd_param_entity be
          set be.entity_value = to_char(v_end_date, 'yyyy-mm-dd')
          where be.param_entity_id = c_sd.param_entity_id;
      
        commit;
      end if;*/
    end loop;
    

  exception
    when others then
      begin
        rollback;
        --记录出错信息
        v_message := PKG_BD.F_ADD_ERROR_LOG('PKG_CSS_OI.p_synchro_install',
                                                                       sqlcode,
                                                                       '同步安装卡失败：'||sqlerrm);
      
        commit;
      end;    
  END GET_PG_DETAIL_FROM_CSS;
  
  
  PROCEDURE GET_PG_DETAIL_FROM_CSS_JOB
      IS 
      
  BEGIN
    for entity_cur in (SELECT be.entity_id
                          from T_BD_PARAM_LIST bl, T_BD_PARAM_ENTITY be
                                      where bl.param_list_id = be.param_list_id
                    and bl.param_code = 'css_synchro_date') 
                    
    loop
      GET_PG_DETAIL_FROM_CSS(entity_cur.entity_id);
    end loop;
    
  END GET_PG_DETAIL_FROM_CSS_JOB; 
END PKG_CSS_OI;
/

