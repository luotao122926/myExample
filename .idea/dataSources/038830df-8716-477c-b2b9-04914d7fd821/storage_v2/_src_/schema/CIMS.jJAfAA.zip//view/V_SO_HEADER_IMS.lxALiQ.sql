create view V_SO_HEADER_IMS as
SELECT HD.ENTITY_ID, --主体ID
       HD.SO_HEADER_ID, --销售单据头ID
       HD.BILL_TYPE_ID, --单据类型ID
       HD.BILL_TYPE_CODE, --单据类型编码
       HD.BILL_TYPE_NAME, --单据类型名称
       HD.BIZ_SRC_BILL_TYPE_ID, --单据源类型ID
       HD.BIZ_SRC_BILL_TYPE_NAME, --单据源类型名称
       HD.SO_NUM, --单据号
       HD.SO_STATUS, --单据状态
       HD.SO_DATE, --单据日期
       DECODE(HD.BIZ_SRC_BILL_TYPE_CODE, '1002', HD.ORIG_SO_NUM, '1004', HD.ORIG_SO_NUM, NULL) ORIG_SO_NUM, --原单（蓝单）号
       HD.SALES_MAIN_TYPE, --营销大类
       HD.SALES_MAIN_TYPE_NAME, --营销大类名称
       HD.CUSTOMER_ID, --客户ID
       HD.CUSTOMER_CODE, --客户编码
       HD.CUSTOMER_NAME, --客户名称
       HD.ACCOUNT_ID, --账户ID
       HD.ACCOUNT_CODE, --账户编号
       HD.ACCOUNT_NAME, --账户名称
       HD.SALES_CENTER_ID, --营销中心ID
       HD.SALES_CENTER_CODE, --营销中心编码
       HD.SALES_CENTER_NAME, --营销中心名称
       HD.PROJECT_TYPE_CODE, --批文类型编码
       HD.PROJECT_NUM, --批文单号
       HD.DIRECT_SHIP_FLAG, --直发标识
       HD.SELF_PICK_FLAG, --自提标识
       NVL(HD.SHIP_INV_ID, HD.CONSIGNEE_INV_ID) AS SHIP_INV_ID, --发货仓库或收货仓库ID
       NVL(HD.SHIP_INV_CODE, HD.CONSIGNEE_INV_CODE) AS SHIP_INV_CODE, --发货仓库或收货仓库编码
       NVL(HD.SHIP_INV_NAME, HD.CONSIGNEE_INV_NAME) AS SHIP_INV_NAME, --发货仓库或收货仓库名称
       HD.SHIP_WAY_NAME, --发运方式
       HD.CONTRACT_CODE, --运输合同编号
       HD.VEHICLE_NUM, --排车好
       HD.SHIP_FLAG, --发货标记
       HD.SHIP_DATE, --发货日期
       HD.CONSIGNEE_ADDRESS, --收货地址
       HD.RECEIVE_FLAG, --收货标记
       HD.RECEIVE_DATE, --收货日期
       HD.AUDIT_FLAG, --审核标记
       HD.AUDIT_DATE, --审核日期
       HD.CHECKED_ACCOUNT_FLAG, --对账标记
       HD.CHECKED_ACCOUNT_DATE, --对账日期
       HD.APPLIED_FLAG, --核销标记
       HD.APPLIED_DATE, --核销日期
       HD.SETTLE_FLAG, --结算标记
       HD.SETTLE_DATE, --结算日期
       HD.INVOICE_NUM_LIST, --发票号串（以逗号分隔）
       HD.INVOICE_DATE, --发票开票日期
       HD.CUST_ORDER_NUM, --客户订单号
       HD.REMARK, --备注
       HD.RAW_SRC_TYPE,
       HD.RAW_SRC_BILL_ID,
       HD.RAW_SRC_BILL_NUM,
       HD.ORIGIN_ORIGIN_TYPE,
       HD.ORIGIN_ORIGIN_HEAD_ID,
       HD.ORIGIN_ORIGIN_ORDER_CODE,
       STE.REVERSAL_BILL_FLAG, --红冲单标识
       STE.RETURN_BILL_FLAG, --退货单标识
       HD.CONSIGNEE_PROVINCE_CODE,
       HD.CONSIGNEE_CITY_CODE,
       HD.CONSIGNEE_DISTRICT_CODE,
       (CASE
         WHEN (HD.BIZ_SRC_BILL_TYPE_CODE IN ('1001', '1004')) THEN
          1
         ELSE
          -1
       END) AS DIRECTION_FLAG, --方向：1出库，-1入库
       HD.CREATED_BY, --创建人账号
       DECODE(OU.NAME, NULL, HD.CREATED_BY, OU.NAME) AS CREATED_BY_NAME --创建人名称
  FROM T_SO_HEADER HD
  LEFT JOIN V_SO_BILL_TYPE_EXTEND STE
    ON STE.BILL_TYPE_ID = HD.BILL_TYPE_ID
  LEFT JOIN UP_ORG_USER OU
    ON OU.ACCOUNT = HD.CREATED_BY
--1001销售单、1002销售红冲单、1003退货单、1004退货红冲单
 WHERE STE.SRC_TYPE_CODE IN ('1001', '1002', '1003', '1004')
      --过滤制单状态的销售单
   AND HD.SO_STATUS != '10'
   AND HD.SALES_MAIN_TYPE_NAME <> '推广物料'
   AND (HD.SO_DATE <> TO_DATE('2015-12-30','YYYY-MM-DD') OR HD.ENTITY_ID NOT IN (12,24))
WITH READ ONLY
/

