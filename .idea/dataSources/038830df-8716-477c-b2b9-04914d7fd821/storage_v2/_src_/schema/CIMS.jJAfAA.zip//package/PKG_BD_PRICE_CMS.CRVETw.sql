create PACKAGE PKG_BD_PRICE_CMS AS
  -----------------------------------------------------------------------------
  --    定制价格列表插入到接口头表    --add by liangym2
  -----------------------------------------------------------------------------
  PROCEDURE PRC_LIST_TO_INTF(IN_ENTITY_ID     IN NUMBER, --主体ID
                             IN_PRICE_LIST_ID IN NUMBER, --价格列表ID
                             IN_PRICE_ADJ_ID  IN OUT NUMBER, --价格调整ID
                             IS_SOURCE_TYPE   IN VARCHAR2, --价格调整来源类型 空 价格列表通过 0 价格列表调整通过 1 多价格列表批量调整通过 -1全量同步
                             OS_MESSAGE       OUT VARCHAR2, --返回提示信息
                             OS_PRE_FIELD01   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD02   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD03   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD04   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD05   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD06   OUT VARCHAR2);
  -----------------------------------------------------------------------------
  --    定制价格列表插入到接口行表    --add by liangym2
  -----------------------------------------------------------------------------
  PROCEDURE PRC_LINE_TO_INTF(IN_ENTITY_ID     IN NUMBER, --主体ID
                             IN_PRICE_LIST_ID IN NUMBER, --价格列表ID
                             IN_PRICE_ADJ_ID  IN NUMBER, --价格调整ID
                             IS_SOURCE_TYPE   IN VARCHAR2, --价格调整来源类型
                             OS_MESSAGE       OUT VARCHAR2, --返回提示信息
                             OS_PRE_FIELD01   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD02   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD03   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD04   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD05   OUT VARCHAR2, --预留参数
                             OS_PRE_FIELD06   OUT VARCHAR2);
END PKG_BD_PRICE_CMS;
/

