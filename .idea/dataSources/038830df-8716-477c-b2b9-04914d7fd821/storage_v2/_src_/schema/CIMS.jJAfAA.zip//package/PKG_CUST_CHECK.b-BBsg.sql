create PACKAGE      PKG_CUST_CHECK is

  -- Author  : WMANG
  -- Crated : 2015/1/15 9:56:03e
  PROCEDURE PKG_CUST_ACC_CHECK(P_ENTITY_ID          IN NUMBER, --主体ID
                               P_CUSTOMER_ID        IN NUMBER, --客户ID
                               P_ACCOUNT_ID         IN NUMBER, --账户ID
                               P_SELESMAINTYPE_CODE IN VARCHAR2, --营销大类编码
                               P_MESSAGE            OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                               );
                               
  -- Author  : WMANG
  -- Crated : 2015/3/25 9:56:03e
  PROCEDURE PKG_AR_UPDATE_ORDER(P_ENTITY_ID       IN NUMBER, --主体ID
                                P_ORDER_HEADER_ID IN NUMBER, --客户ID
                                P_MESSAGE         OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                );

END PKG_CUST_CHECK;
/

