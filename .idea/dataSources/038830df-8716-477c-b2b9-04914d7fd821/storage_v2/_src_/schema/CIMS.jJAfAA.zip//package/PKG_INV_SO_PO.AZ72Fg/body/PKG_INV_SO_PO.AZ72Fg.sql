create Package Body Pkg_Inv_So_Po Is

  v_Base_Exception Exception; --自定义异常
  v_Success Constant varchar2(10) := 'SUCCESS';
  v_Nl Constant varchar2(2) := Chr(13) || Chr(10); --换行

  ----------------------------------------------------------------------
  -- AUTHOR  : sushu
  -- CREATED : 2015-7-30
  -- PURPOSE : 根据销售单插入接口表INTF_INV_PO_HEADERS_SOURCE
  ----------------------------------------------------------------------

  Procedure p_so_create_to_intf(p_So_Head_Id In Number, --销售单头ID
                                p_User_Code In varchar2, --账户编码
                                p_Intf_Head_Id     Out varchar2,   --生成的接口头ID
                                p_Result     Out varchar2) Is --返回的结果

    v_So_Entity_Id Number; --销售单主体ID
    v_So_Customer_Id Number; --销售单客户ID
    v_So_Ship_Inv_Id Number; --销售单发货仓库ID
    v_So_Ship_Inv_Code varchar2(100); --销售单发货仓库编码
    v_So_Consignee_Inv_Id Number; --销售单收货仓库ID
    v_So_Consignee_Inv_Code varchar2(100); --销售单收货仓库编码
    v_So_Sales_Main_Type varchar2(32); --销售单产品大类
    v_So_Ship_Inv_To_Ou Number; --销售单头上的发货仓库对应的OU
    v_So_Bill_Type_Id Number; --销售单头上的单据类型ID
    v_So_Bill_Type_Code varchar2(100); --销售单头上的单据类型编码
    v_So_Num varchar2(32); --销售单号
    v_So_Count Number;
    v_Biz_Src_Bill_Type_Code varchar2(100); --销售单的源类型

    v_Po_Head_Id Number; --待生成中转单头ID
    v_Po_Entity_Id Number; --待生成的中转单的主体ID
    v_Po_Type_Id Number; --待生成的中转单的单据类型ID
    v_Po_Type Varchar2(40); --待生成的中转单据类型编码
    v_Po_Num varchar2(32); --待生成的中转单编号
    v_Po_Sales_Main_Type Varchar2(32); --待生成的中转单产品大类
    v_Po_Inv_Finance_id Number; --待生成的中转单财务仓ID
    v_Po_Inv_Finance_Code varchar2(100); --待生成的中转单的财务仓编码
    v_Po_Inv_Finance_Name varchar2(100); --待生成的中转单的财务仓名称
    v_Po_Vendor_Id Number; --待生成的中转单的供应商ID
    v_Po_Vendor_Code varchar2(100); --待生成的中转单的供应商编码
    v_Po_Vendor_Name Varchar2(100); --待生成的中转单的供应商名称
    v_Po_Sales_Center_Id Number; -- 待生成中转单的营销中心ID
    v_Po_Sales_Center_Code Varchar2(100); --待生成中转单的营销中心编码
    v_Po_Sales_Center_Name Varchar2(100); --待生成中转单的营销中心名称
    v_Po_Price_List_Id Number; -- 待生成中转单的价格列表ID
    v_Po_Finance_Operating_Id Number; --待生成中转单的财务仓经营单位ID
    v_Po_Finance_Oraganization_Id Number; --待生成的中转单的财务仓组织ID
    v_Po_Vendor_Operating_Id Number; --待生成中转单的供应商经营单位ID
    v_Po_Vendor_Organization_Id Number; --待生成中转单的供应商组织ID
    v_Po_Red_Order_Flag varchar2(2); --中转单据类型是否红冲标识
    v_Po_Remark varchar2(500); --备注
    v_Po_Bill_Action_Type varchar2(100); --单据类型出入库方式，01入库，02出库
    v_Po_Count Number := 0;
    v_Po_Line_Num Number := 0; --中转单行编码
    v_Po_Item_Id Number;
    v_Po_Item_Name varchar2(240);


    v_price              Number := 0; --返回价格
    v_discount           Number := 0; --返回折扣率
    v_month_discount     Number := 0; --返回月返
    v_cx_flag            Varchar2(10); --返回是否促销机
    v_Item_Onhand_Qty    Number := 0; --库存现有量
    v_Item_Occupy_Qty    Number := 0; --产品总占用量
    v_Usable_Qoh_Qty     Number := 0; --产品可用量
    v_Value            Varchar2(2000);
    V_TRX_RATE         t_So_Supplier_Require_Entity.Trx_Rate%type;

/*    --获取销售单头信息
    Cursor c_so_head Is
    Select * From t_so_header t Where t.so_header_id = p_So_Head_Id;

    r_so_head c_so_head%Rowtype;*/

    --获取销售单散件信息
    Cursor c_so_lines Is
    Select * From t_so_line_detail t Where t.so_header_id = p_So_Head_Id;

    r_so_line c_so_lines%Rowtype;

    --pragma Autonomous_Transaction;
    Begin
      p_Result := v_Success;

      --校验参数销售单头ID是否为空
      If(p_So_Head_Id Is Null) Then
        p_Result := '无效参数，销售单据头ID为空';
        Raise v_Base_Exception;
      End If;

      --校验销售单头信息是否存在
      Begin
/*        Open c_so_head;
        Fetch c_so_head Into r_so_head;
        If c_so_head%Notfound Then
          p_Result := '获取销售单头信息失败，销售单头ID：' || to_char(p_So_Head_Id);
          Raise v_Base_Exception;
        End If;
        Close c_so_head;*/
        Select Count(*)
          Into v_So_Count
          From t_So_Header t
         Where t.So_Header_Id = p_So_Head_Id;
         If v_So_Count = 0 Then
           p_Result := '获取销售单头信息失败，销售单头ID：' || to_char(p_So_Head_Id);
           Raise v_Base_Exception;
         End If;
      End;

      --获取销售单的源类型
      Begin
        Select t.Biz_Src_Bill_Type_Code
          Into v_Biz_Src_Bill_Type_Code
          From t_So_Header t
         Where t.So_Header_Id = p_So_Head_Id;
      Exception
        When Others Then
        p_Result := '获取销售单的源类型编码失败，' || v_Nl ||
                    '销售单头ID：'|| p_So_Head_Id || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End;
      If v_Biz_Src_Bill_Type_Code Is Null Then
        p_Result := '销售单的源类型编码为空，' || v_Nl ||
                      '销售单头ID：'|| p_So_Head_Id || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      --根据销售单的源类型，获取销售单头的信息，主体ID，客户ID，发货仓库ID，产品大类，以及OU信息
      Begin
        Select t.Entity_Id,
               t.Customer_Id,
               t.Ship_Inv_Id,
               t.Ship_Inv_Code,
               t.consignee_inv_id,
               t.consignee_inv_code,
               t.Sales_Main_Type,
               t.Bill_Type_Id,
               t.Bill_Type_Code,
               t.So_Num,
               t.Remark,
               t.erp_ou_id    --By sushu 2016-03-23  取OU
          Into v_So_Entity_Id,
               v_So_Customer_Id,
               v_So_Ship_Inv_Id,
               v_So_Ship_Inv_Code,
               v_So_Consignee_Inv_Id,
               v_So_Consignee_Inv_Code,
               v_Po_Sales_Main_Type,
               v_So_Bill_Type_Id,
               v_So_Bill_Type_Code,
               v_So_Num,
               v_Po_Remark,
               v_So_Ship_Inv_To_Ou   --By sushu 2016-03-23  取OU
          From t_So_Header t
         Where t.So_Header_Id = p_So_Head_Id;
      Exception
        When Others Then
          p_Result := '销售单插入接口表失败，' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;

      --销售单1001，销售红冲1002，退货单1003，退货红冲1004   by sushu 2016-03-23 直接在销售头上取OU，不用根据仓库取
/*      If(v_Biz_Src_Bill_Type_Code = '1001' Or v_Biz_Src_Bill_Type_Code = '1002') Then
        --校验销售单头上财务仓是否为空
        If v_So_Ship_Inv_Id Is Null Then
          p_Result := '销售单头上的发货仓库为空：' || v_Nl ||
                      '销售单头ID：' || p_So_Head_Id || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        End If;
      Else --If(v_Biz_Src_Bill_Type_Code = '1003' Or v_Biz_Src_Bill_Type_Code = '1004') Then
        v_So_Ship_Inv_Id := v_So_Consignee_Inv_Id;
        v_So_Ship_Inv_Code := v_So_Consignee_Inv_Code;
        --校验销售单头上财务仓是否为空
        If v_So_Ship_Inv_Id Is Null Then
          p_Result := '销售单头上的收货仓库为空：' || v_Nl || '销售单头ID：' || p_So_Head_Id || v_Nl ||
                      Sqlerrm;
          Raise v_Base_Exception;
        End If;
      End If;*/


      --根据销售单头上的发货仓库获取发货仓对应的OU   by sushu 2016-03-23 直接在销售头上取OU，不用根据仓库取
/*      Begin
        Select Io.Operating_Unit
          Into v_So_Ship_Inv_To_Ou
          From t_Inv_Inventories Ii, t_Inv_Organization Io
         Where Ii.Inventory_Id = v_So_Ship_Inv_Id
           And Ii.Organization_Id = Io.Organization_Id
           And Ii.Entity_Id = Io.Entity_Id
           And Trunc(Sysdate) Between trunc(Ii.Begin_Date) And
               Trunc(Nvl(Ii.End_Date, Sysdate))
           And Trunc(Sysdate) Between
               Trunc(Nvl(Io.User_Definition_Enable_Date, Sysdate)) And
               Trunc(Nvl(Io.Disable_Date, Sysdate));
      Exception
        When too_many_rows Then
          p_Result := '根据销售单头上的发货仓库获取对应OU信息多条。' || v_Nl ||
                      '销售单头ID：' || p_So_Head_Id || v_Nl ||
                      '发货仓库编码：' || v_So_Ship_Inv_Code || v_Nl ||Sqlerrm;
          Raise v_Base_Exception;
        When no_data_found Then
          p_Result := '根据销售单头上的发货仓库获取不到对应的OU信息。' || v_Nl ||
                      '销售头ID：' || p_So_Head_Id || v_Nl ||
                      '发货仓库编码：' || v_So_Ship_Inv_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When Others Then
          p_Result := '根据销售单头上的发货仓库获取对应的OU信息失败。' || v_Nl ||
                      '销售头ID：' || p_So_Head_Id || v_Nl ||
                      '发货仓库编码：' || v_So_Ship_Inv_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;*/

      --根据销售单头上的客户ID、发货仓对应的OU、主体ID获取对应表T_SO_SUPPLIER_REQUIRE_ENTITY
      --里相应的仓库、OU、IO、主体、供应商信息信息
      Begin
       Select Distinct t.Requirement_Entity_Id,
                       t.Requirement_Ou_Id,
                       t.Requirement_Organization_Id,
                       t.Requirement_Inventory_Id,
                       t.Requirement_Inventory_Code,
                       t.Requirement_Inventory_Name,
                       t.Supplier_Vendor_Id,
                       t.Supplier_Vendor_Code,
                       t.Supplier_Vendor_Name,
                       --t3.operating_unit,
                       --t3.organization_id,
                       T2.Unit_Id,
                       T2.Code,
                       T2.Name,
                       t.TRX_RATE
         Into v_Po_Entity_Id,
              v_Po_Finance_Operating_Id,
              v_Po_Finance_Oraganization_Id,
              v_Po_Inv_Finance_Id,
              v_Po_Inv_Finance_Code,
              v_Po_Inv_Finance_Name,
              v_Po_Vendor_Id,
              v_Po_Vendor_Code,
              v_Po_Vendor_Name,
              --v_Po_Vendor_Operating_Id,
              --v_Po_Vendor_Organization_Id,
              v_Po_Sales_Center_Id,
              v_Po_Sales_Center_Code,
              v_Po_Sales_Center_Name,
              V_TRX_RATE --税率
         From t_So_Supplier_Require_Entity t,
              t_Inv_Inventories            T1,
              Up_Org_Unit                  T2,
              t_Inv_Vendor_Organization    T3
        Where t.Requirement_Customer_Id = v_So_Customer_Id
          And t.Supplier_Entity_Id = v_So_Entity_Id
          And t.Supplier_Ou_Id = v_So_Ship_Inv_To_Ou
          And t.Requirement_Inventory_Id = T1.Inventory_Id
          And t.Requirement_Organization_Id = T1.Organization_Id
          And Trunc(Sysdate) Between Trunc(T1.Begin_Date) And
              Trunc(Nvl(T1.End_Date, Sysdate))
          And T1.Unit_Id = T2.Unit_Id
          And T2.Is_Enabled = 'T'
          And t.Supplier_Vendor_Id = T3.Vendor_Id(+);
          
          V_TRX_RATE := (V_TRX_RATE/100) + 1;  --折算后税率 
      Exception
        When too_many_rows Then
          p_Result := '根据销售单头上的客户ID、发货仓对应的OU、主体ID获取待生成中转单的' || v_Nl ||
                      '财务仓以及主体、供应商信息多条。' || v_Nl ||
                      '销售单头ID：' || p_So_Head_Id || v_Nl ||
                      '客户ID：' || to_char(v_So_Customer_Id) || v_Nl ||
                      '发货仓对应的OU：' || v_So_Ship_Inv_To_Ou || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When no_data_found Then
          p_Result := '根据销售单头上的客户ID、发货仓对应的OU、主体ID获取不到待生成中转单的' || v_Nl ||
                      '财务仓以及主体、供应商信息。' || v_Nl ||
                      '销售单头ID：' || p_So_Head_Id || v_Nl ||
                      '客户ID：' || v_So_Customer_Id || v_Nl ||
                      '发货仓对应的OU：' || v_So_Ship_Inv_To_Ou || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When Others Then
          p_Result := '根据销售单头上的客户ID、发货仓对应的OU、主体ID获取待生成中转单的' || v_Nl ||
                      '财务仓以及主体、供应商信息失败。' || v_Nl ||
                      '销售单头ID：' || p_So_Head_Id || v_Nl ||
                      '客户ID：' || v_So_Customer_Id || v_Nl ||
                      '发货仓对应的OU：' || v_So_Ship_Inv_To_Ou || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;



      --根据销售单头上的主体ID和单据类型ID获取T_SO_MAP_BILLTYPE对应生成的中转单的单据类型
      Begin
        Select Mb.To_Type_Id,
               Mb.To_Type_Code,
               Bt.Cancel_Flag,
               Tt.Action_Type
          Into v_Po_Type_Id,
               v_Po_Type,
               v_Po_Red_Order_Flag,
               v_Po_Bill_Action_Type
          From t_So_Map_Billtype       Mb,
               t_Inv_Bill_Types        Bt,
               t_Inv_Transaction_Types Tt
         Where Mb.From_Entity_Id = v_So_Entity_Id
           and mb.to_entity_id = v_Po_Entity_Id
           And Mb.From_Type_Id = v_So_Bill_Type_Id
           And Trunc(Sysdate) Between Trunc(Nvl(Mb.Begin_Date, Sysdate)) And
               Trunc(Nvl(Mb.End_Date, Sysdate))
           And Mb.To_Type_Id = Bt.Bill_Type_Id
           And Trunc(Sysdate) Between Trunc(Bt.Begin_Date) And
               Trunc(Nvl(Bt.End_Date, Sysdate))
           And Bt.Transaction_Type_Id = Tt.Transaction_Type_Id
           And Trunc(Sysdate) Between Trunc(Tt.Begin_Date) And
               Trunc(Nvl(Tt.End_Date, Sysdate));
      Exception
        When too_many_rows Then
          p_Result := '根据销售单头上的主体ID和单据类型获取待生成中转单的单据类型信息多条。' || v_Nl ||
                      '销售单头ID：' || p_So_Head_Id || v_Nl ||
                      '主体ID：' || v_So_Entity_Id || v_Nl ||
                      '单据类型编码：' || v_So_Bill_Type_Code || v_Nl || Sqlerrm;
          Raise v_base_exception;
        When no_data_found Then
          p_Result := '根据销售单头上的主体ID和单据类型获取不到待生成中转单的单据类型信息。' || v_Nl ||
                      '销售单头ID：' || p_So_Head_Id || v_Nl ||
                      '主体ID：' ||v_So_Entity_Id || v_Nl ||
                      '单据类型编码：' || v_So_Bill_Type_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When Others Then
          p_Result := '根据销售单头上的主体ID和单据类型获取待生成中转单的单据类型信息失败。' || v_Nl ||
                      '销售单头ID：' || p_So_Head_Id || v_Nl ||
                      '主体ID：' || v_So_Entity_Id || v_Nl ||
                      '单据类型编码：' || v_So_Bill_Type_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;

      If v_Po_Bill_Action_Type Is Null Then
        p_Result := '根据销售单头上的主体ID和单据类型获取待生成中转单的单据类型出入库方式为空' || v_Nl ||
                    '销售单头ID' || p_So_Head_Id || v_Nl ||
                    '主体ID：' || v_So_Entity_Id || v_Nl ||
                    '单据类型编码：' || v_So_Bill_Type_Code || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

/*--不需要校验价格信息，价格来自销售单
      --获取供应商的价格
      Begin
        Select t.Price_List_Id
          Into v_Po_Price_List_Id
          From t_Bd_Vendor_Pricelist t
         Where t.Vendor_Id = v_Po_Vendor_Id
           And t.Active_Flag = 'Y'
           And t.Type_Code = 'TRANSIT_TYPE';
      Exception
        When too_many_rows Then
          p_Result := '根据供应商获取供应商价格信息多条。' || v_Nl ||
                      '供应商编码：' || v_Po_Vendor_Code || v_Nl ||Sqlerrm;
          Raise v_Base_Exception;
        When no_data_found Then
          p_Result := '根据供应商获取不到供应商价格信息。' || v_Nl ||
                      '供应商编码：' || v_Po_Vendor_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When Others Then
          p_Result := '根据供应商获取供应商价格失败。' || v_Nl ||
                      '供应商编码：' || v_Po_Vendor_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
*/
      --校验待生成中转单字段是否为空
      If v_Po_Entity_Id Is Null Then
        p_Result := '主体ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If v_Po_Type_Id Is Null Then
        p_Result := '单据类型ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If v_Po_Inv_Finance_id Is Null Then
        p_Result := '财务仓ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If v_Po_Vendor_Id Is Null Then
        p_Result := '供应商ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If v_Po_Price_List_Id Is Null Then
         v_Po_Price_List_Id := 0;
        --p_Result := '价格列表ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
       --Raise v_Base_Exception;
      End If;

      If v_Po_Sales_Center_Id Is Null Then
        p_Result := '营销中心ID为空，生成中转单失败。' || v_Nl ||Sqlerrm;
        Raise v_Base_Exception;
      End If;

      --插入中转单头接口表
      If(p_Result = v_Success) Then
        Begin
          --中转单头ID
          select S_INTF_INV_PO_HEADERS_SOURCE.nextval Into v_Po_Head_Id from dual;

          Insert Into INTF_INV_PO_HEADERS_SOURCE
          (HEAD_ID, --采购单据ID
           Entity_Id, --经营主体ID
           Po_Type_Id, --单据类型ID
           Po_Type, --单据类型
           --Sales_Main_Type, --营销大类
           Inv_Finance_Id, --财务仓ID
           Inv_Finance_Code, --财务仓编码
           Inv_Finance_Name, --财务仓名称
           Vendor_Id, --供应商ID
           Vendor_Code, --供应商编码
           Vendor_Name, --供应商名称
           Sales_Center_Id, --营销中心ID
           Sales_Center_Code, --营销中心编码
           Sales_Center_Name, --营销中心名称
           Price_List_Id, --价格列表ID
           Remark, --备注
           Last_Updated_By, --更新者
           Last_Update_Date, --更新日期
           SCHED_ORDER_NUM, --来源单号
           Source_Type, --来源代号(工单入库)
           vendor_operating_id,
           vendor_organization_id,
           Finance_Operating_id,
           Finance_Organization_id,
           STATUS,
           SOURCE_NUM
           )
           Values
           (
           v_Po_Head_Id,
           v_Po_Entity_Id,
           v_Po_Type_Id,
           v_Po_Type,
           --v_Po_Sales_Main_Type,
           v_Po_Inv_Finance_id,
           v_Po_Inv_Finance_Code,
           v_Po_Inv_Finance_Name,
           v_Po_Vendor_Id,
           v_Po_Vendor_Code,
           v_Po_Vendor_Name,
           v_Po_Sales_Center_Id,
           v_Po_Sales_Center_Code,
           v_Po_Sales_Center_Name,
           v_Po_Price_List_Id,
           v_Po_Remark,
           p_User_Code,
           Sysdate,
           'G' || v_So_Num,
           '销售单',
           v_Po_Vendor_Operating_Id,
           v_Po_Vendor_Organization_Id,
           v_Po_Finance_Operating_Id,
           v_Po_Finance_Oraganization_Id,
           'N',
           v_So_Num
           );
        Exception
          When Others Then
            p_Result := '插入中转单头接口表失败：' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;

/*      --检查是否生成多张中转单接口头
      If(p_Result = v_Success) Then
        Select Count(*)
          Into v_Po_Count
          From INTF_INV_PO_HEADERS_SOURCE t
         Where t.Po_Num = To_Char(v_Po_Head_Id)
           And t.Entity_Id = v_Po_Entity_Id;
        If v_Po_Count = 0 Then
          p_Result := '未生成中转单';
          Raise v_Base_Exception;
        End If;
        If v_Po_Count > 1 Then
          p_Result := '生成多张中转单头信息，请检查';
          Raise v_Base_Exception;
        End If;
      End If;*/

      --插入行表
      If(p_Result = v_Success) Then
/*        Open c_so_lines;
        Fetch c_so_lines Into r_so_line;
        If c_so_lines%Notfound Then
          p_Result := '获取销售单行信息失败，销售单头ID：' || to_char(p_So_Head_Id) || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        End If;
        Close c_so_lines;*/
        Select Count(*)
          Into v_So_Count
          From t_So_Line_Detail t
         Where t.so_header_id = p_So_Head_Id;
        If v_So_Count = 0 Then
          p_Result := '取销售单行信息失败，销售单头ID：' || To_Char(p_So_Head_Id);
          Raise v_Base_Exception;
        End If;

        For r_line In c_so_lines Loop

          --获取产品有效信息
          Begin
            Select t.Item_Id,
                   t.Item_Name
              Into v_Po_Item_Id,
                   v_Po_Item_Name
              From t_Bd_Item t
             Where t.Item_Code = r_Line.Component_Code
               And t.Entity_Id = v_Po_Entity_Id
               And t.Active_Flag = 'Y';
          Exception
            When no_data_found Then
              p_Result := '根据产品编码获取不到有效的产品信息。' || v_Nl ||
                          '产品编码(散件)：' || r_line.Component_Code || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
            When Others Then
              p_Result := '根据产品编码获取产品信息失败。' || v_Nl ||
                          '产品编码(散件)：' || r_line.Component_Code || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;

          Begin
          /*
          pkg_bd_price.p_Get_Price(p_Acc_Id         => Null, --账户ID
                                   p_Item_Code      => r_line.Component_Code, --产品ID
                                   p_Bill_Date      => To_Char(Sysdate, 'YYYYMMDD'), --单据日期
                                   p_Price_List_Id  => v_Po_Price_List_Id, --价格列表ID
                                   p_Entity_Id      => v_Po_Entity_Id, --业务主体ID
                                   p_Price          => v_Price, --返回价格
                                   p_Discount       => v_Discount, --返回折扣率
                                   p_Month_Discount => v_Month_Discount, --返回月返
                                   p_Cx_Flag        => v_Cx_Flag --返回是否促销机
                                   );
             */
             --chenyj8,2017-09-12 价格改为取关联交易的价格
             select icpLine.Item_Price / V_TRX_RATE
               into v_Price
               from intf_cux_icp_logist_req_lines icpLine
              where icpLine.Source_Header = 'G' || v_So_Num
                and icpLine.Supplier_Item_Num = r_line.Component_Code
                and rownum = 1;
          Exception
            When Others Then
              p_Result := '获取产品价格失败，产品编码：' || r_line.Component_Code || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
          If v_price Is Null Then
            p_Result := '获取产品的价格为空，产品编码：' || r_line.Component_Code || v_Nl ||
                        '价格列表ID：' || v_Po_Price_List_Id || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
          End If;
/*不需要校验库存现有量，发货确认、执行时可以校验
          --出库校验库存是否足够，01入库。02出库
          If(v_Po_Bill_Action_Type = '02') Then
            Begin
              Pkg_Inv_Pub.p_Get_Item_Inv_Qoh(p_Entity_Id         => v_Po_Entity_Id,
                                             p_Inventory_Id      => v_Po_Inv_Finance_id,
                                             p_Item_Id           => v_Po_Item_Id,
                                             p_User_Code         => p_User_Code,
                                             p_Qoh_Qty           => v_Item_Onhand_Qty,
                                             p_Usable_Qoh_Qty    => v_Usable_Qoh_Qty,
                                             p_Occupy_Qty        => v_Item_Occupy_Qty,
                                             p_Result            => v_Value);
              If v_Value != v_Success Then
                p_Result := '获取库存可用量失败。';
                Raise v_Base_Exception;
              End If;
            Exception
              When no_data_found Then
                v_Usable_Qoh_Qty := 0;
              When Others Then
                p_Result := v_Value || '错误信息：' || p_Result || Sqlerrm;
                Raise v_Base_Exception;
            End;
            --校验库存是否足够
            If(r_line.item_qty > v_Usable_Qoh_Qty) Then
              p_Result := '产品库存不足，销售单头ID：' || p_So_Head_Id || v_Nl ||
                          '本次出库的产品编码：' || r_line.item_code || v_Nl ||
                          '本次出库的数量：' || r_line.item_qty || v_Nl ||
                          '库存可用量：' || v_Usable_Qoh_Qty || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
            End If;
          End If;
*/
          Begin
            --汇总散件
            select count(*)
              into v_So_Count
              from INTF_INV_PO_LINES_SOURCE pls
             where pls.head_id = v_Po_Head_Id
               and pls.item_id = v_Po_Item_Id;
            if v_So_Count > 0 then
              update INTF_INV_PO_LINES_SOURCE pls
                 set pls.billed_qty = nvl(pls.billed_qty, 0) +
                                      r_line.Component_qty
               where pls.head_id = v_Po_Head_Id
                 and pls.item_id = v_Po_Item_Id;
            else
              Insert Into INTF_INV_PO_LINES_SOURCE
                (LINE_ID, --采购单行ID
                 HEAD_ID, --采购单ID
                 Item_Id, --产品ID
                 Item_Code, --产品编码，即销售码
                 Item_Name, --产品名称
                 Item_Bar_Code, --产品标识
                 Uom_Code, --产品单位
                 Item_Price, --产品价格
                 Billed_Qty, --开单数量
                 order_id_orig, --销售当明细IS
                 Last_Updated_By, --更新者
                 Last_Update_Date --更新日期
                 )
                Select S_INTF_INV_PO_LINES_SOURCE.Nextval,
                       v_Po_Head_Id,
                       v_Po_Item_Id, --产品ID
                       r_line.Component_Code, --产品编码，即销售码
                       v_Po_Item_Name, --产品名称
                       bi.barcode, --产品标识
                       r_line.Component_uom, --产品单位
                       v_Price, --产品价格
                       r_line.Component_qty, --开单数量
                       r_line.so_line_detail_id, --销售单明细ID
                       p_User_Code,
                       Sysdate
                  From t_bd_item bi
                 Where bi.item_id = r_line.item_id;
            end if;
          Exception
            When Others Then
              p_Result := '生成中转单接口行失败。' || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
        End Loop;
      End If;

      if(p_Result = v_Success) Then
        p_Intf_Head_Id := v_Po_Head_Id;
        --Commit;
      End If;



    Exception
      When v_Base_Exception Then
        p_Result := '销售单插入中转单接口表失败，' || p_Result;
        p_Intf_Head_Id := -1;
        --Rollback;
      When Others Then
        p_Result := '销售单插入中转单接口失败' || v_Nl || Sqlerrm;
        p_Intf_Head_Id := -1;
        --Rollback;
    End;



  ----------------------------------------------------------------------
  -- AUTHOR  : sushu
  -- CREATED : 2015-8-11
  -- PURPOSE : 根据接口表INTF_INV_PO_HEADERS_SOURCE生成中转单
  ----------------------------------------------------------------------
  Procedure p_intf_create_to_po(p_Intf_Head_Id In Number, --接口表头ID
                                p_User_Code    In varchar2, --账户编码
                                p_Po_Num       Out varchar2, --生成的中转单号
                                p_Po_Head_Id   Out varchar2,  --生成的中转单ID
                                p_Result       Out varchar2) Is --返回的结果


    v_Po_Head_Id Number; --待生成中转单头ID
    v_Po_Entity_Id Number; --待生成的中转单的主体ID
    v_Po_Type_Id Number; --待生成的中转单的单据类型ID
    v_Po_Type Varchar2(40); --待生成的中转单据类型编码
    v_Po_Num varchar2(32); --待生成的中转单编号
    v_Po_Sales_Main_Type Varchar2(32); --待生成的中转单产品大类
    v_Po_Inv_Finance_id Number; --待生成的中转单财务仓ID
    v_Po_Inv_Finance_Code varchar2(100); --待生成的中转单的财务仓编码
    v_Po_Inv_Finance_Name varchar2(100); --待生成的中转单的财务仓名称
    v_Po_Inv_Logistics_Id Number; --待生成中转单的实体仓ID
    v_Po_Inv_Logistics_Code varchar2(100); --待生成中转单的实体仓编码
    v_Po_Inv_Logistics_Name varchar2(100); --待生成中转单的实体仓名称
    v_Po_Vendor_Id Number; --待生成的中转单的供应商ID
    v_Po_Vendor_Code varchar2(100); --待生成的中转单的供应商编码
    v_Po_Vendor_Name Varchar2(100); --待生成的中转单的供应商名称
    v_Po_Workshop_Inv_Code varchar2(100); --待生成中转单的车间仓
    v_Po_Cleared_Inv_Code varchar2(100); --待生成中转单的结算仓
    v_Po_Sales_Center_Id Number; -- 待生成中转单的营销中心ID
    v_Po_Sales_Center_Code Varchar2(100); --待生成中转单的营销中心编码
    v_Po_Sales_Center_Name Varchar2(100); --待生成中转单的营销中心名称
    v_Po_Price_List_Id Number; -- 待生成中转单的价格列表ID
    v_Po_Item_Back_Type varchar2(40); --来源订单类型
    v_Po_Order_Head_Id Number; --来源订单头ID
    v_Po_Sched_Order_Num varchar2(32); --来源订单号
    v_Po_Source_Type Varchar2(32); --来源代号
    v_Po_Roping_Flag varchar2(2); --入库拉运标识
    v_Po_Finance_Operating_Id Number; --待生成中转单的财务仓经营单位ID
    v_Po_Finance_Oraganization_Id Number; --待生成的中转单的财务仓组织ID
    v_Po_Vendor_Operating_Id Number; --待生成中转单的供应商经营单位ID
    v_Po_Vendor_Organization_Id Number; --待生成中转单的供应商组织ID
    v_Po_Red_Order_Flag varchar2(2); --中转单据类型是否红冲标识
    v_Po_Vendor_Site_Code varchar2(128); --供应商地点编码
    v_Po_Bill_Action_Type varchar2(100); --单据类型出入库方式，01入库，02出库
    v_Po_Bill_Control_Type varchar2(100); --单据类型对应的控制供应商的类型
    v_Po_Vendor_Main_Type varchar2(4); --供应商控制类型
    v_Po_Producing_Area_Id Number; --产地ID
    v_Po_Producing_Area_Code varchar2(32); --产地编码
    v_Po_Producing_Area_Name varchar2(100); --产地名称
    v_Po_Remark Varchar2(240); --备注信息
    v_Po_Count Number := 0;
    v_Po_Line_Num Number := 0; --中转单行编码
    v_Po_Item_Id Number; --产品ID
    v_Po_Item_Name Varchar2(240); --产品名称
    v_Po_Item_Bar_Code varchar2(100); --产品标识
    v_Po_Uom_Code Varchar2(20); --产品单位


    v_Source_num varchar2(32); --来源单号

    v_price              Number := 0; --返回价格
    v_discount           Number := 0; --返回折扣率
    v_month_discount     Number := 0; --返回月返
    v_cx_flag            Varchar2(10); --返回是否促销机
    v_Item_Onhand_Qty    Number := 0; --库存现有量
    v_Item_Occupy_Qty    Number := 0; --产品总占用量
    v_Usable_Qoh_Qty     Number := 0; --产品可用量
    v_Value            Varchar2(2000);
    v_Sales_Main_Type varchar2(32); --当前产品对应的产品大类
    v_Intf_Count Number;
    v_Erp_Trancation varchar2(100);
    v_Input_Num varchar2(32); --A3入库单号
    v_Can_Produce_Qty Number; --订单明细上可生产数量
    v_Cancel_Qty Number; --订单明细上已取消数量
    v_Po_Qty Number; --中转单上退货占用数量
    v_Po_Cancel_Qty Number; --中转单上退货红冲占用数量
    v_Stock_Fin_Type varchar2(100); --财务仓的存货类型
    v_Stock_Inv_type varchar2(100); --车间仓的存货类型

    --获取接口表头信息
/*    Cursor c_intf_head Is
    Select * From intf_inv_po_headers_source t Where t.head_id = p_Intf_Head_Id;

    r_intf_head c_intf_head%Rowtype;*/

    --获取接口散件信息
    Cursor c_intf_lines Is
    Select * From intf_inv_po_lines_source t Where t.head_id = p_Intf_Head_Id;

    r_intf_line c_intf_lines%Rowtype;


    Begin
      p_Result := v_Success;

      --校验参数头ID是否为空
      If(p_Intf_Head_Id Is Null) Then
        p_Result := '无效参数';
        Raise v_Base_Exception;
      End If;

      --校验接口表头信息是否存在
      Begin
/*        Open c_intf_head;
        Fetch c_intf_head Into r_intf_head;
        If c_intf_head%Notfound Then
          p_Result := '获取接口表头信息失败，头ID：' || to_char(p_Intf_Head_Id);
          Raise v_Base_Exception;
        End If;
        Close c_intf_head;*/
        Select Count(*)
          Into v_Intf_Count
          From Intf_Inv_Po_Headers_Source t
         Where t.Head_Id = p_Intf_Head_Id;
         If v_Intf_Count = 0 Then
           p_Result := '获取接口表头信息失败，头ID：' || to_char(p_Intf_Head_Id);
           Raise v_Base_Exception;
         End If;
      End;

      --获取接口表头的信息
      Begin
        Select t.Entity_Id,
               t.Po_Type_Id,
               t.Po_Type,
               t.Sales_Main_Type,
               t.Inv_Finance_Id,
               t.Inv_Finance_Code,
               t.Inv_Finance_Name,
               t.Inv_Logistics_Id,
               t.Inv_Logistics_Code,
               t.Inv_Logistics_Name,
               t.Vendor_Id,
               t.Vendor_Code,
               t.Vendor_Name,
               t.Workshop_Inv_Code,
               t.Cleared_Inv_Code,
               t.Sales_Center_Id,
               t.Sales_Center_Code,
               t.Sales_Center_Name,
               t.Price_List_Id,
               t.Item_Back_Type,
               t.Order_Header_Id,
               t.Sched_Order_Num,
               t.Source_Type,
               t.Roping_Flag,
               t.Vendor_Operating_Id,
               t.Vendor_Organization_Id,
               t.Finance_Operating_Id,
               t.Finance_Organization_Id,
               t.source_num,
               t.remark,
               t.producing_area_code
          Into v_Po_Entity_Id,
               v_Po_Type_Id,
               v_Po_Type,
               v_Po_Sales_Main_Type,
               v_Po_Inv_Finance_Id,
               v_Po_Inv_Finance_Code,
               v_Po_Inv_Finance_Name,
               v_Po_Inv_Logistics_Id,
               v_Po_Inv_Logistics_Code,
               v_Po_Inv_Logistics_Name,
               v_Po_Vendor_Id,
               v_Po_Vendor_Code,
               v_Po_Vendor_Name,
               v_Po_Workshop_Inv_Code,
               v_Po_Cleared_Inv_Code,
               v_Po_Sales_Center_Id,
               v_Po_Sales_Center_Code,
               v_Po_Sales_Center_Name,
               v_Po_Price_List_Id,
               v_Po_Item_Back_Type,
               v_Po_Order_Head_Id,
               v_Po_Sched_Order_Num,
               v_Po_Source_Type,
               v_Po_Roping_Flag,
               v_Po_Vendor_Operating_Id,
               v_Po_Vendor_Organization_Id,
               v_Po_Finance_Operating_Id,
               v_Po_Finance_Oraganization_Id,
               v_Source_num,
               v_Po_Remark,
               v_Po_Producing_Area_Code
          From Intf_Inv_Po_Headers_Source t
         Where t.Head_Id = p_Intf_Head_Id;
      Exception
        When Others Then
          p_Result := '获取接口头表的信息失败，' || v_Nl ||Sqlerrm;
          Raise v_Base_Exception;
      End;


      --根据单据类型ID获取对应单据类型以及出入库方式、供应商控制类型信息
      Begin
        Select Bt.Bill_Type_Id,
               Bt.Cancel_Flag,
               Bt.Control_Type,
               Tt.Action_Type,
               Decode(Bt.Control_Type, '10', '00', '11', '01', '12', '02')
          Into v_Po_Type_Id,
               v_Po_Red_Order_Flag,
               v_Po_Bill_Control_Type,
               v_Po_Bill_Action_Type,
               v_Po_Vendor_Main_Type
          From t_Inv_Bill_Types Bt, t_Inv_Transaction_Types Tt
         Where Bt.Bill_Type_Code = v_Po_Type
           And Bt.Entity_Id = v_Po_Entity_Id
           And Trunc(Sysdate) Between Trunc(Bt.Begin_Date) And
               Trunc(Nvl(Bt.End_Date, Sysdate))
           And Bt.Transaction_Type_Id = Tt.Transaction_Type_Id
           And Trunc(Sysdate) Between Trunc(Tt.Begin_Date) And
               Trunc(Nvl(Tt.End_Date, Sysdate));
      Exception
        When too_many_rows Then
          p_Result := '根据单据类型编码获取对应单据类型信息以及出入库方式信息多条。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '单据类型编码：' || v_Po_Type || v_Nl || Sqlerrm;
          Raise v_base_exception;
        When no_data_found Then
          p_Result := '根据单据类型编码获取不到对应单据类型信息以及出入库方式信息。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '单据类型编码：' || v_Po_Type || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When Others Then
          p_Result := '根据单据类型编码获取对应单据类型信息以及出入库方式信息失败。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '单据类型编码：' || v_Po_Type || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;

      If v_Po_Bill_Action_Type Is Null Then
        p_Result := '根据单据类型编码获取对应单据类型出入库方式为空。' || v_Nl ||
                    '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                    '单据类型编码：' || v_Po_Type || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If v_Po_Bill_Control_Type Is Null Then
        p_Result := '根据单据类型编码获取对应的控制类型（10：内部供应商，11：外部供应商，12：内外部皆可）' || v_Nl ||
                    '为空，请先维护' || v_Nl ||
                    '接口头ID；' || p_Intf_Head_Id || v_Nl ||
                    '单据类型编码：' || v_Po_Type || v_Nl || Sqlerrm;
      End If;


      --校验仓库信息是否有效以及获取对应的组织信息以及营销中心信息
      Begin
        Select Ii.Inventory_Id,
               Ii.Inventory_Name,
               Io.Operating_Unit,
               Ii.Organization_Id,
               Ou.Unit_Id,
               Ou.Code,
               Ou.Name,
               ii.stock_type
          Into v_Po_Inv_Finance_Id,
               v_Po_Inv_Finance_Name,
               v_Po_Finance_Operating_Id,
               v_Po_Finance_Oraganization_Id,
               v_Po_Sales_Center_Id,
               v_Po_Sales_Center_Code,
               v_Po_Sales_Center_Name,
               v_Stock_Fin_Type
          From t_Inv_Inventories Ii, t_Inv_Organization Io, Up_Org_Unit Ou
         Where Ii.Inventory_Code = v_Po_Inv_Finance_Code
           And Ii.Entity_Id = v_Po_Entity_Id
           And Trunc(Sysdate) Between Trunc(Ii.Begin_Date) And
               Trunc(Nvl(Ii.End_Date, Sysdate))
           And Ii.Organization_Id = Io.Organization_Id
           And Ii.Entity_Id = Io.Entity_Id
           And Trunc(Sysdate) Between
               Trunc(Nvl(Io.User_Definition_Enable_Date, Sysdate)) And
               Trunc(Nvl(Io.Disable_Date, Sysdate))
           And Ii.Unit_Id = Ou.Unit_Id
           And Ii.Entity_Id = Ou.Entity_Id
           And Ou.Is_Enabled = 'T';
      Exception
        When too_many_rows Then
          p_Result := '根据接口表财务仓编码获取财务仓以及所属的组织、营销中心信息多条。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '财务仓编码：' || v_Po_Inv_Finance_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When no_data_found Then
          p_Result := '根据接口表财务仓编码获取不到财务仓以及所属的组织、营销中心信息。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '财务仓编码：' || v_Po_Inv_Finance_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When Others Then
          p_Result := '根据接口表财务仓编码获取财务仓以及所属的组织、营销中心信息失败。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '财务仓编码：' || v_Po_Inv_Finance_Code || Sqlerrm;
          Raise v_Base_Exception;
      End;


      --校验供应商是否有效
      Begin
       Select Distinct t.Vendor_Id,
              t.Vendor_Name,
              --t.Operating_Unit,
              --t.Organization_Id,
              t.Vendor_Site_Code
         Into v_Po_Vendor_Id,
              v_Po_Vendor_Name,
             -- v_Po_Vendor_Operating_Id,
             -- v_Po_Vendor_Organization_Id,
              v_Po_Vendor_Site_Code
         From v_Inv_Vendor_View t
        Where t.Entity_Id = v_Po_Entity_Id
          And t.Vendor_Code = v_Po_Vendor_Code
          And t.Vendor_Site_Operating_Unit =
              Decode(v_Po_Finance_Operating_Id,
                     Null,
                     t.Vendor_Site_Operating_Unit,
                     v_Po_Finance_Operating_Id)
          And Nvl(t.Vendor_Site_Code, '地点') Not In
              ('非贸易型', '押金质保金')
          And t.Vendor_Main_Type =
              Decode(v_Po_Vendor_Main_Type,
                     '02',
                     t.Vendor_Main_Type,
                     v_Po_Vendor_Main_Type);
      Exception
        When too_many_rows Then
          p_Result := '根据接口表供应商编码获取供应商以及所属的组织信息多条。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '供应商编码：' || v_Po_Vendor_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When no_data_found Then
          p_Result := '根据接口表供应商编码获取不到供应商以及所属的组织信息。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '供应商编码：' || v_Po_Vendor_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When Others Then
          p_Result := '根据接口表供应商编码获取供应商以及所属的组织信息失败。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '供应商编码：' || v_Po_Vendor_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;

      --大物流，需要根据产地获取供应商组织、经营单位
      If(v_Po_Source_Type = '大物流') Then
        If v_Po_Order_Head_Id Is Null Then
          p_Result := '来源订单头ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        Else
          Select nvl(t.Virtual_Producing_Area_Code,t.producing_area_code)
            Into v_Po_Producing_Area_Code
            From t_Pln_Order_Head t
           Where t.Order_Head_Id = v_Po_Order_Head_Id;
        End If;
        If v_Po_Producing_Area_Code Is Null Then
          p_Result := '产地编码不能为空。' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        Else
          Begin
            Select Io.Operating_Unit, Pa.Mrp_Org_Id
              Into v_Po_Vendor_Operating_Id, v_Po_Vendor_Organization_Id
              From t_Pln_Producing_Area Pa, t_Inv_Organization Io
             Where Pa.Producing_Area_Code = v_Po_Producing_Area_Code
               And Pa.Entity_Id = v_Po_Entity_Id
               And Pa.Mrp_Org_Id = Io.Organization_Id
               And Pa.Entity_Id = Io.Entity_Id
               And Trunc(Sysdate) Between
                   Trunc(Nvl(Pa.Begin_Date, Sysdate)) And
                   Trunc(Nvl(Pa.End_Date, Sysdate))
               And Trunc(Sysdate) Between
                   Trunc(Nvl(Io.User_Definition_Enable_Date, Sysdate)) And
                   Trunc(Nvl(Io.Disable_Date, Sysdate));
          Exception
            When Too_Many_Rows Then
              p_Result := '根据产地编码获取对应的库存组织以及OU信息多条。' || v_Nl || '产地编码：' ||
                          v_Po_Producing_Area_Code || v_Nl || '接口头ID：' ||
                          p_Intf_Head_Id || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
            When No_Data_Found Then
              p_Result := '根据产地编码获取不到对应的库存组织以及OU信息。' || v_Nl || '产地编码：' ||
                          v_Po_Producing_Area_Code || v_Nl || '接口头ID：' ||
                          p_Intf_Head_Id || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
            When Others Then
              p_Result := '根据产地编码获取对应的库存组织以及OU信息失败。' || v_Nl || '产地编码：' ||
                          v_Po_Producing_Area_Code || v_Nl || '接口头ID：' ||
                          p_Intf_Head_Id || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
        End If;
      End If;

      --获取产地信息
      If(v_Po_Producing_Area_Code Is Not Null) Then
        Begin
          Select t.Producing_Area_Id, t.Producing_Area_Name
            Into v_Po_Producing_Area_Id, v_Po_Producing_Area_Name
            From t_Pln_Producing_Area t
           Where t.Producing_Area_Code = v_Po_Producing_Area_Code
             And t.Entity_Id = v_Po_Entity_Id;
        Exception
          When Others Then
            p_Result := '获取产地信息失败' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;


/*
      --校验供应商的价格列表信息
      Begin
        Select t.Price_List_Id
          Into v_Po_Price_List_Id
          From t_Bd_Vendor_Pricelist t
         Where t.Vendor_Id = v_Po_Vendor_Id
           And t.Price_List_Id = v_Po_Price_List_Id
           And t.Active_Flag = 'Y'
           And t.Type_Code = 'TRANSIT_TYPE';
      Exception
        When too_many_rows Then
          p_Result := '根据供应商以及价格列表ID获取有效供应商价格数据信息多条。' || v_Nl ||
                      '供应商编码：' || v_Po_Vendor_Code || v_Nl ||
                      '价格列表ID：' || v_Po_Price_List_Id || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When no_data_found Then
          p_Result := '根据供应商以及价格列表获取不到有效供应商价格数据信息。' || v_Nl ||
                      '供应商编码：' || v_Po_Vendor_Code || v_Nl ||
                      '价格列表ID：' || v_Po_Price_List_Id || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When Others Then
          p_Result := '根据供应商以及价格列表获取有效供应商价格数据信息失败。' || v_Nl ||
                      '供应商编码：' || v_Po_Vendor_Code || v_Nl ||
                      '价格列表ID：' || v_Po_Price_List_Id || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
*/

      --如果实体仓编码不为空的话，则获取实体仓的信息
      If v_Po_Inv_Logistics_Code Is Not Null Then
        Begin
          Select Si.Storage_Id, Si.Storage_Name, Si.Storage_Tran_Flag
            Into v_Po_Inv_Logistics_Id,
                 v_Po_Inv_Logistics_Name,
                 v_Po_Roping_Flag
            From t_Inv_Storage_Info Si
           Where Si.Status = 'T'
             And Si.Entity_Id = v_Po_Entity_Id
             And Si.Storage_Code = v_Po_Inv_Logistics_Code
             And Si.Producing_Area_Id In
                 (Select Pa.Producing_Area_Id
                    From t_Pln_Producing_Area Pa
                   Where Pa.Mrp_Org_Id =
                         Decode(v_Po_Vendor_Organization_Id,
                                Null,
                                Pa.Mrp_Org_Id,
                                v_Po_Vendor_Organization_Id))
             And Trunc(Sysdate) Between Trunc(Nvl(Si.Active_Date, Sysdate)) And
                 Trunc(Nvl(Si.Invalid_Date, Sysdate))
             And Si.Status = 'T';
        Exception
          When too_many_rows Then
            p_Result := '根据接口表实体仓编码获取实体仓信息多条。' || v_Nl ||
                        '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                        '实体仓编码：' || v_Po_Inv_Logistics_Code || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
          When no_data_found Then
            p_Result := '根据接口表实体仓编码获取不到实体仓信息。' || v_Nl ||
                        '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                        '实体仓编码：' || v_Po_Inv_Logistics_Code || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
          When Others Then
            p_Result := '根据接口表实体仓编码获取实体仓信息失败。' || v_Nl ||
                        '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                        '实体仓编码：' || v_Po_Inv_Logistics_Code || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;



      --校验待生成中转单字段是否为空
      If v_Po_Entity_Id Is Null Then
        p_Result := '主体ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If v_Po_Type_Id Is Null Then
        p_Result := '单据类型ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If v_Po_Inv_Finance_id Is Null Then
        p_Result := '财务仓ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If v_Po_Vendor_Id Is Null Then
        p_Result := '供应商ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If v_Po_Price_List_Id Is Null Then
        p_Result := '价格列表ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If v_Po_Sales_Center_Id Is Null Then
        p_Result := '营销中心ID为空，生成中转单失败。' || v_Nl ||Sqlerrm;
        Raise v_Base_Exception;
      End If;

      --大物流，车间仓、结算仓、退货类型、来源订单头ID、来源订单号不能为空
      If(v_Po_Source_Type = '大物流' And v_Po_Workshop_Inv_Code Is Null) Then
        p_Result := '车间仓为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      --校验车间仓数据是否正确以及存在，同时校验和财务仓的存货类型是否一致
      If(v_Po_Source_Type = '大物流') Then
        Begin
          Select Count(*), t.Stock_Type
            Into v_Intf_Count, v_Stock_Inv_Type
            From t_Inv_Vendor_Mrpii_Inv t
           Where t.Inv_Inout_Type = 'OUT'
             And t.Organization_Id = v_Po_Vendor_Organization_Id
             And t.Entity_Id = v_Po_Entity_Id
             And t.workshop_inv_code = v_Po_Workshop_Inv_Code
             And Nvl(t.Disable_Date, Sysdate + 1) > Sysdate
           Group By t.Stock_Type;
           --车间仓信息不存在
           If(v_Intf_Count = 0) Then
             p_Result := '车间仓信息不存在' || v_Nl || Sqlerrm;
             Raise v_Base_Exception;
           End If;
           --校验车间仓和财务仓的存货类型是否一致
           If(v_Stock_Fin_Type != v_Stock_Inv_type) Then
             p_Result := '车间仓的存货类型和财务仓的存货类型不一致' || v_Nl || Sqlerrm;
             Raise v_Base_Exception;
           End If;
        Exception
          When Others Then
            p_result := p_result || '获取车间仓信息失败' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;

      --测试用，暂时去掉
/*      If(v_Po_Source_Type = '大物流' And v_Po_Cleared_Inv_Code Is Null) Then
        p_Result := '结算仓为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;*/

      If(v_Po_Source_Type = '大物流' And v_Po_Item_Back_Type Is Null) Then
        p_Result := '退货类型为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If(v_Po_Source_Type = '大物流' And v_Po_Order_Head_Id Is Null) Then
        p_Result := '来源订单头ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If(v_Po_Source_Type = '大物流' And v_Po_Sched_Order_Num Is Null) Then
        p_Result := '来源订单号为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      --获取ERP_TRANCATION事务处理
      If(v_Po_Source_Type = '销售单') Then
        v_Erp_Trancation := '11';
      Elsif(v_Po_Source_Type = '大物流') Then
        Begin
          Select Pa.Erp_Inv_Trans_Po
            Into v_Erp_Trancation
            From t_Pln_Producing_Area Pa
           Where Pa.Producing_Area_Id = v_Po_Producing_Area_Id;
        Exception
          When Others Then
            p_Result := '根据产地获取ERP事务处理失败' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;

      If(v_Po_Source_Type = '大物流') Then
        v_Input_Num := v_Source_num;
      End If;

      --插入中转单头表
      If(p_Result = v_Success) Then
        Begin
          --中转单头ID
          select S_INV_PO_HEADERS.nextval Into v_Po_Head_Id from dual;

          Insert Into t_inv_po_headers
          (Po_Id, --采购单据ID
           Entity_Id, --经营主体ID
           Po_Type_Id, --单据类型ID
           Po_Type, --单据类型
           Po_Num, --采购单据编号
           Billed_Date, --单据日期
           Po_Status, --单据状态
           Sales_Main_Type, --营销大类
           Inv_Finance_Id, --财务仓ID
           Inv_Finance_Code, --财务仓编码
           Inv_Finance_Name, --财务仓名称
           INV_LOGISTICS_ID, --实体仓ID
           INV_LOGISTICS_CODE, --实体仓编码
           INV_LOGISTICS_NAME, --实体仓名称
           Vendor_Id, --供应商ID
           Vendor_Code, --供应商编码
           Vendor_Name, --供应商名称
           WORKSHOP_INV_CODE, --车间仓
           CLEARED_INV_CODE, --结算仓
           Sales_Center_Id, --营销中心ID
           Sales_Center_Code, --营销中心编码
           Sales_Center_Name, --营销中心名称
           Price_List_Id, --价格列表ID
           ITEM_BACK_TYPE, --来源订单类型
           ORDER_HEADER_ID, --来源订单头ID
           SCHED_ORDER_NUM, --来源订单号
           Created_By, --创建者
           Creation_Date, --创建日期
           ship_by, --发货人
           ship_time, --发货时间
           ship_date, --发货日期
           Remark, --备注
           Close_Flag,  --关闭标志
           Last_Updated_By, --更新者
           Last_Update_Date, --更新日期
           Source_Type, --来源代号(工单入库)
           ROPING_FLAG, --入库拉运标识
           Red_Order_Flag, --红冲标识
           vendor_operating_id,
           vendor_organization_id,
           Finance_Operating_id,
           Finance_Organization_id,
           PRODUCING_AREA_ID,
           PRODUCING_AREA_CODE,
           PRODUCING_AREA_NAME,
           ERP_TRANCATION,
           INPUT_NUM
           )
           Values
           (
           v_Po_Head_Id,
           v_Po_Entity_Id,
           v_Po_Type_Id,
           v_Po_Type,
           to_char(v_Po_Head_Id),
           trunc(Sysdate),
           '10',
           v_Po_Sales_Main_Type,
           v_Po_Inv_Finance_id,
           v_Po_Inv_Finance_Code,
           v_Po_Inv_Finance_Name,
           v_Po_Inv_Logistics_Id,
           v_Po_Inv_Logistics_Code,
           v_Po_Inv_Logistics_Name,
           v_Po_Vendor_Id,
           v_Po_Vendor_Code,
           v_Po_Vendor_Name,
           v_Po_Workshop_Inv_Code,
           v_Po_Cleared_Inv_Code,
           v_Po_Sales_Center_Id,
           v_Po_Sales_Center_Code,
           v_Po_Sales_Center_Name,
           v_Po_Price_List_Id,
           v_Po_Item_Back_Type,
           v_Po_Order_Head_Id,
           v_Po_Sched_Order_Num,
           p_User_Code,
           Sysdate,
           p_User_Code,
           Sysdate,
           trunc(Sysdate),
           v_Po_Remark || '，' || v_Po_Source_Type || '：' || v_Source_num,
           'N',
           p_User_Code,
           Sysdate,
           v_Po_Source_Type,
           v_Po_Roping_Flag,
           v_Po_Red_Order_Flag,
           v_Po_Vendor_Operating_Id,
           v_Po_Vendor_Organization_Id,
           v_Po_Finance_Operating_Id,
           v_Po_Finance_Oraganization_Id,
           v_Po_Producing_Area_Id,
           v_Po_Producing_Area_Code,
           v_Po_Producing_Area_Name,
           v_Erp_Trancation,
           v_Input_Num
           );
        Exception
          When Others Then
            p_Result := '插入中转单头表失败：' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;

      --检查是否生成多张中转单头
      If(p_Result = v_Success) Then
        Select Count(*)
          Into v_Po_Count
          From t_Inv_Po_Headers t
         Where t.Po_Num = To_Char(v_Po_Head_Id)
           And t.Entity_Id = v_Po_Entity_Id;
        If v_Po_Count = 0 Then
          p_Result := '未生成中转单';
          Raise v_Base_Exception;
        End If;
        If v_Po_Count > 1 Then
          p_Result := '生成多张中转单头信息，请检查';
          Raise v_Base_Exception;
        End If;
      End If;

      --插入行表
      If(p_Result = v_Success) Then
/*        Open c_intf_lines;
        Fetch c_intf_lines Into r_intf_line;
        If c_intf_lines%Notfound Then
          p_Result := '获取接口行信息失败，接口头ID：' || to_char(p_Intf_Head_Id) || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        End If;
        Close c_intf_lines;*/
        Select Count(*)
          Into v_Intf_Count
          From Intf_Inv_Po_Lines_Source t
         Where t.head_id = p_Intf_Head_Id;
        If v_Intf_Count = 0 Then
          p_Result := '获取接口行信息失败，接口头ID：' || To_Char(p_Intf_Head_Id);
          Raise v_Base_Exception;
        End If;


        For r_line In c_intf_lines Loop

          v_Po_Line_Num := v_Po_Line_Num + 1;

          --获取产品有效信息
          Begin
            Select t.Item_Id,
                   t.Item_Name,
                   t.Barcode,
                   t.Defaultunit,
                   t.Sales_Main_Type
              Into v_Po_Item_Id,
                   v_Po_Item_Name,
                   v_Po_Item_Bar_Code,
                   v_Po_Uom_Code,
                   v_Sales_Main_Type
              From t_Bd_Item t
             Where t.Item_Code = r_Line.Item_Code
               And t.Entity_Id = v_Po_Entity_Id
               And t.Active_Flag = 'Y';
          Exception
            When no_data_found Then
              p_Result := '根据产品编码获取不到有效的产品信息。' || v_Nl ||
                          '产品编码：' || r_line.item_code || v_Nl ||
                          '接口头ID：' || p_Intf_Head_Id ||  v_Nl || Sqlerrm;
              Raise v_Base_Exception;
            When Others Then
              p_Result := '根据产品编码获取产品信息失败。' || v_Nl ||
                          '产品编码：' || r_line.item_code || v_Nl ||
                          '接口头ID：' || p_Intf_Head_Id || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;

          If(v_Po_Sales_Main_Type Is Null) Then
            v_Po_Sales_Main_Type := v_Sales_Main_Type;
          Else
            If(v_Po_Sales_Main_Type != v_Sales_Main_Type And v_Po_Source_Type = '大物流') Then
              p_Result := '本次生成中转单的产品大类不相同，请确认。' || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
            End If;
          End If;

          If(v_Po_Sales_Main_Type Is Null And v_Po_Source_Type = '大物流') Then
            p_Result := '产品大类为空，请确认。' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
          End If;

          If(v_Po_Source_Type = '大物流') Then
            --校验来源单行ID是否存在以及是否正确
            If(r_line.order_id_orig Is Null) Then
              p_Result := '产品' || r_line.item_code || '来源单行ID为空，请确认' || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
            Else
              Begin
                Select Count(*),
                       Nvl(t.Can_Produce_Qty, 0),
                       Nvl(t.Cancel_Qty, 0)
                  Into v_Po_Count, v_Can_Produce_Qty, v_Cancel_Qty
                  From t_Pln_Order_Detail t
                 Where t.Item_Code = r_Line.Item_Code
                   And t.Order_Detail_Id = r_Line.Order_Id_Orig
                 Group By t.Can_Produce_Qty, t.Cancel_Qty;
                 If v_Po_Count <> 1 Then
                   p_Result := '产品' || r_line.item_code || '来源单行ID不正确，请确认' || v_Nl || Sqlerrm;
                   Raise v_Base_Exception;
                 End If;
              Exception
                When Others Then
                  p_Result := '产品' || r_line.item_code || '来源单行ID不正确，请确认' || v_Nl || Sqlerrm;
                  Raise v_Base_Exception;
              End;
            End If;
          End If;

          --大物流，校验订单的可退货数量是否足够
          If(v_Po_Source_Type = '大物流') Then
            --获取中转单退货占用的数量以及退货红冲占用的数量差
            --获取中转单上退货占用的数量
            Begin
              Select Nvl(Sum(Pl.Billed_Qty), 0)
                Into v_Po_Qty
                From t_Inv_Po_Lines Pl
               Where Pl.Item_Code = r_Line.Item_Code
                 And Pl.Po_Id In
                     (Select Ph.Po_Id
                        From t_Inv_Po_Headers Ph
                       Where Ph.Sched_Order_Num = v_Po_Sched_Order_Num
                         And Ph.Po_Type = v_Po_Type
                         And Ph.Close_Flag = 'N'
                         And Ph.Entity_Id = v_Po_Entity_Id)
                 And Pl.Pln_Order_Detail_Id = r_Line.Order_Id_Orig;
            Exception
              When Others Then
                p_Result := '产品' || r_line.item_code || '获取中转单上退货被占用的数量报错' || v_Nl || Sqlerrm;
                Raise v_Base_Exception;
            End;

            --获取中转单上退货红冲占用的数量
            Begin
              Select Nvl(Sum(Pl.Billed_Qty), 0)
                Into v_Po_Cancel_Qty
                From t_Inv_Po_Lines Pl
               Where Pl.Item_Code = r_Line.Item_Code
                 And Pl.Po_Id In
                     (Select Ph.Po_Id
                        From t_Inv_Po_Headers Ph
                       Where Ph.Sched_Order_Num = v_Po_Sched_Order_Num
                         And Ph.Po_Type In
                             (Select Bt.Bill_Type_Code
                                From t_Inv_Bill_Types Bt
                               Where Bt.Blue_Bill_Type_Id = v_Po_Type_Id)
                         And Ph.Po_Status = '14'
                         And Ph.Entity_Id = v_Po_Entity_Id)
                 And Pl.Pln_Order_Detail_Id = r_Line.Order_Id_Orig;
            Exception
              When Others Then
                p_Result := '产品' || r_line.item_code || '获取中转单上退货红冲被占用的数量报错' || v_Nl || Sqlerrm;
                Raise v_Base_Exception;
            End;

            --订单上的生产数量-已取消数量-（中转退货占用的数量-中转退货红冲占用的数量）为本次可退的最多数量
            If((v_Can_Produce_Qty - v_Cancel_Qty - v_Po_Qty + v_Po_Cancel_Qty) < r_line.billed_qty) Then
              p_Result := '产品' || r_line.item_code || '本次退货的数量已超过订单上可退货的数量' || v_Nl ||
                          '订单明细行ID:' || r_line.order_id_orig || v_Nl ||
                          '订单上生产数量：' || v_Can_Produce_Qty || v_Nl ||
                          '订单上已取消数量：' || v_Cancel_Qty || v_Nl ||
                          '中转单退货占用的数量：' || v_Po_Qty || v_Nl ||
                          '中转退货红冲占用的数量：' || v_Po_Cancel_Qty || v_Nl ||
                          '本次退货的数量：' || r_line.billed_qty || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
            End If;

          End If;
/*
          Begin
          pkg_bd_price.p_Get_Price(p_Acc_Id         => Null, --账户ID
                                   p_Item_Code      => r_line.item_code, --产品ID
                                   p_Bill_Date      => To_Char(Sysdate, 'YYYYMMDD'), --单据日期
                                   p_Price_List_Id  => v_Po_Price_List_Id, --价格列表ID
                                   p_Entity_Id      => v_Po_Entity_Id, --业务主体ID
                                   p_Price          => v_Price, --返回价格
                                   p_Discount       => v_Discount, --返回折扣率
                                   p_Month_Discount => v_Month_Discount, --返回月返
                                   p_Cx_Flag        => v_Cx_Flag --返回是否促销机
                                   );
          Exception
            When Others Then
              p_Result := '获取产品价格失败，产品编码：' || r_line.item_code || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
*/        
          --取接口表价格，来自销售单不含税价
          v_price := r_line.item_price;
          
          If v_price Is Null Then
            p_Result := '生成中转单，获取产品的价格为空，可能是供方散件未维护价格，产品编码：' || r_line.item_code || v_Nl ||
                        '价格列表ID：' || v_Po_Price_List_Id || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
          End If;

          --出库校验库存是否足够，01入库。02出库
          If(v_Po_Bill_Action_Type = '02') Then
            Begin
              Pkg_Inv_Pub.p_Get_Item_Inv_Qoh(p_Entity_Id         => v_Po_Entity_Id,
                                             p_Inventory_Id      => v_Po_Inv_Finance_id,
                                             p_Item_Id           => v_Po_Item_Id,
                                             p_User_Code         => p_User_Code,
                                             p_Qoh_Qty           => v_Item_Onhand_Qty,
                                             p_Usable_Qoh_Qty    => v_Usable_Qoh_Qty,
                                             p_Occupy_Qty        => v_Item_Occupy_Qty,
                                             p_Result            => v_Value);
              If v_Value != v_Success Then
                p_Result := '获取库存可用量失败。';
                Raise v_Base_Exception;
              End If;
            Exception
              When no_data_found Then
                v_Usable_Qoh_Qty := 0;
              When Others Then
                p_Result := v_Value || '错误信息：' || p_Result || Sqlerrm;
                Raise v_Base_Exception;
            End;
            --校验库存是否足够
            If(r_line.billed_qty > v_Usable_Qoh_Qty) Then
              p_Result := '产品库存不足，接口头ID：' || p_Intf_Head_Id || v_Nl ||
                          '本次出库的产品编码：' || r_line.item_code || v_Nl ||
                          '本次出库的数量：' || r_line.billed_qty || v_Nl ||
                          '库存可用量：' || v_Usable_Qoh_Qty || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
            End If;
          End If;

          Begin
            Insert Into t_inv_po_lines
              (Po_Line_Id, --采购单行ID
               Po_Id, --采购单ID
               Po_Line_Num, --采购单行编码
               Item_Id, --产品ID
               Item_Code, --产品编码，即销售码
               Item_Name, --产品名称
               Item_Bar_Code, --产品标识
               Uom_Code, --产品单位
               Item_Price, --产品价格
               Billed_Qty, --开单数量
               shipped_qty, --发货数量
               order_id_orig, --来源明细IS
               Created_By, --创建者
               Creation_Date, --创建日期
               Last_Updated_By, --更新者
               Last_Update_Date, --更新日期
               PLN_ORDER_DETAIL_ID
               )
              Values
              (s_Inv_Po_Lines.Nextval,
               v_Po_Head_Id,
               v_Po_Line_Num,
               v_Po_Item_Id, --产品ID
               r_line.item_code, --产品编码，即销售码
               v_Po_Item_Name, --产品名称
               v_Po_Item_Bar_Code, --产品标识
               v_Po_Uom_Code, --产品单位
               v_Price, --产品价格
               r_line.billed_qty, --开单数量
               r_line.billed_qty, --发货数量
               r_line.order_id_orig, --来源单明细ID
               p_User_Code,
               Sysdate,
               p_User_Code,
               Sysdate,
               r_line.order_id_orig);
          Exception
            When Others Then
              p_Result := '生成中转单行失败。' || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
        End Loop;
      End If;

      --获取中转单号
      If(p_Result = v_Success) Then
        Begin
          v_Po_Num := Pkg_Bd.f_Get_Bill_No('invPONum',
                                                   '',
                                           v_Po_Entity_Id,
                                           '');
          If (v_Po_Num = '' Or v_Po_Num Is Null) Then
            p_Result := '生成的中转单号为空，请确认单号生成规则是否正确，单号规则：invPONum' || v_Nl ||Sqlerrm;
            Raise v_Base_Exception;
          End If;
        Exception
          When Others Then
            p_Result := '获取中转单单号失败，单据号生成规则：invPONum。' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
        --更新中转单编号
        Update t_Inv_Po_Headers t
           Set t.Po_Num = v_Po_Num, t.sales_main_type = v_Po_Sales_Main_Type
         Where t.Po_Id = v_Po_Head_Id;
        p_Po_Num := v_Po_Num;
        p_Po_Head_Id := v_Po_Head_Id;

        --更新接口表
        If(p_Result = v_Success) Then
          Update Intf_Inv_Po_Headers_Source t
             Set t.Status = 'Y'
           Where t.Head_Id = p_Intf_Head_Id;
        End If;
      End If;



    Exception
      When v_Base_Exception Then
        p_Result := '生成中转单失败，' || p_Result;
/*        Update Intf_Inv_Po_Headers_Source t
           Set t.Status = 'E', t.Err_Msg = p_Result
         Where t.Head_Id = p_Intf_Head_Id;*/
        --自治事务，更新接口表的状态以及错误信息
        p_Result := p_Result || F_ADD_ERROR_LOG(p_Intf_Head_Id,p_Result);
      When Others Then
        p_Result := '生成中转单失败' || v_Nl || Sqlerrm;
/*        Update Intf_Inv_Po_Headers_Source t
           Set t.Status = 'E', t.Err_Msg = p_Result
         Where t.Head_Id = p_Intf_Head_Id;*/
        --自治事务，更新接口表的状态以及错误信息
        p_Result := p_Result || F_ADD_ERROR_LOG(p_Intf_Head_Id,p_Result);
    End;



  --------------------------------------------------------------------------
  --Author: sushu
  -- Created : 2015-09-16
  --Purpose:自治事务，更新接口表的状态以及错误信息
  --------------------------------------------------------------------------
  function F_ADD_ERROR_LOG(p_Intf_Head_Id  in varchar2, --接口头ID
                           p_Result in varchar2) --错误信息
    Return Varchar2
    Is

    l_Return_Msg varchar2(255);
    pragma autonomous_transaction;
    Begin
      --启动独立事务
      Begin
        Update Intf_Inv_Po_Headers_Source t
           Set t.Status = 'E', t.Err_Msg = p_Result
         Where t.Head_Id = p_Intf_Head_Id;
         Commit;
      Exception
        When Others Then
          l_Return_Msg := substr(Sqlerrm,1,254);
      End;
      Return l_Return_Msg;

    End;



  --------------------------------------------------------------------------
  --Author: sushu
  -- Created : 2015-10-26
  --Purpose:大物流接口表触发生成中转单，区分推式、拉式
  --------------------------------------------------------------------------
  Procedure p_intf_logis_create_to_po(p_Intf_Head_Id In Number, --接口表头ID
                                      p_User_Code    In varchar2, --账户编码
                                      p_Po_Num       Out varchar2, --生成的中转单号
                                      p_Po_Head_Id   Out varchar2,  --生成的中转单ID
                                      p_Result       Out varchar2) Is --返回的结果


    v_Po_Type varchar2(40);  --单据类型
    v_Value varchar2(240); --返回值
    v_Erp_Inv_trans_Po varchar2(100); --订单头ID  01组织间转移  02子库转移  03关联交易

    Begin
      p_Result := v_Success;

      --校验参数头ID是否为空
      If(p_Intf_Head_Id Is Null) Then
        p_Result := '无效参数';
        Raise v_Base_Exception;
      End If;

      --检验接口头信息是否存在
      Begin
        Select t.Po_Type, Pa.Erp_Inv_Trans_Po
          Into v_Po_Type, v_Erp_Inv_Trans_Po
          From Intf_Inv_Po_Headers_Source t,
               t_Pln_Order_Head           Ph,
               t_Pln_Producing_Area       Pa
         Where t.Head_Id = p_Intf_Head_Id
           And t.Order_Header_Id = Ph.Order_Head_Id
           And Nvl(Ph.Virtual_Producing_Area_Id, Ph.Producing_Area_Id) =
               Pa.Producing_Area_Id;
      Exception
        When too_many_rows Then
          p_Result := '根据接口头ID获取单据类型信息多条' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || Sqlerrm;
          Raise v_Base_Exception;
        When no_data_found Then
          p_Result := '根据接口头ID获取不到单据类型信息' || v_Nl ||
                      '接口头ID:' || p_Intf_Head_Id || Sqlerrm;
          Raise v_Base_Exception;
        When Others Then
          p_Result := '根据接口头ID获取单据类型信息失败' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || Sqlerrm;
          Raise v_Base_Exception;
      End;

      --根据单据类型区分是推式还是拉式，生成中转单方法不一样，推式需要找原单
      If(v_Erp_Inv_trans_Po = '01' Or v_Erp_Inv_trans_Po = '02') Then
        Begin
          Pkg_Inv_So_Po.p_intf_create_to_po(p_Intf_Head_Id   => p_Intf_Head_Id,
                                            p_User_Code      => p_User_Code,
                                            p_Po_Num         => p_Po_Num,
                                            p_Po_Head_Id     => p_Po_Head_Id,
                                            p_Result         => v_Value);
          If(v_Value != v_Success) Then
            p_Result := v_Value;
            Raise v_Base_Exception;
          End If;
        Exception
          When Others Then
             p_Result := v_Value || '错误信息：' || p_Result || Sqlerrm;
             Raise v_Base_Exception;
        End;
      Elsif(v_Erp_Inv_trans_Po = '03') Then
        Begin
          Pkg_Inv_So_Po.p_find_order_create_to_po(p_Intf_Head_Id   => p_Intf_Head_Id,
                                                  p_User_Code      => p_User_Code,
                                                  p_Po_Num         => p_Po_Num,
                                                  p_Po_Head_Id     => p_Po_Head_Id,
                                                  p_Result         => v_Value);
          If(v_Value != v_Success) Then
            p_Result := v_Value;
            Raise v_Base_Exception;
          End If;
        Exception
          When Others Then
             p_Result := v_Value || '错误信息：' || p_Result || Sqlerrm;
             Raise v_Base_Exception;
        End;
      End If;

    Exception
      When v_Base_Exception Then
        p_Result := '生成中转单失败，' || p_Result;
      When Others Then
        p_Result := '生成中转单失败' || v_Nl || Sqlerrm;
    End;



  --------------------------------------------------------------------------
  --Author: sushu
  -- Created : 2015-10-26
  --Purpose:大物流接口表触发生成中转单，推式需要找原单的
  --------------------------------------------------------------------------
  Procedure p_find_order_create_to_po(p_Intf_Head_Id In Number, --接口表头ID
                                      p_User_Code    In varchar2, --账户编码
                                      p_Po_Num       Out varchar2, --生成的中转单号
                                      p_Po_Head_Id   Out varchar2,  --生成的中转单ID
                                      p_Result       Out varchar2) is --返回的结果


    v_Intf_count Number;
    v_Po_Head_Id1 Number; --待生成中转单头ID，找到原单的
    v_Po_Head_Id2 Number; --待生成中转单头ID，没找到原单的
    v_Po_Num varchar2(32); --待生成的中转单编号
    v_Po_Num1 varchar2(32) := 0; --待生成的中转单编号，找到原单的
    v_Po_Num2 varchar2(32) := 0; --待生成的中转单编号，没找到原单的
    v_Po_Entity_Id Number; --待生成的中转单的主体ID
    v_Po_Type_Id Number; --待生成的中转单的单据类型ID
    v_Po_Type Varchar2(40); --待生成的中转单据类型编码
    v_Po_Sales_Main_Type Varchar2(32); --待生成的中转单产品大类
    v_Po_Inv_Finance_id Number; --待生成的中转单财务仓ID
    v_Po_Inv_Finance_Code varchar2(100); --待生成的中转单的财务仓编码
    v_Po_Inv_Finance_Name varchar2(100); --待生成的中转单的财务仓名称
    v_Po_Inv_Logistics_Id Number; --待生成中转单的实体仓ID
    v_Po_Inv_Logistics_Code varchar2(100); --待生成中转单的实体仓编码
    v_Po_Inv_Logistics_Name varchar2(100); --待生成中转单的实体仓名称
    v_Po_Vendor_Id Number; --待生成的中转单的供应商ID
    v_Po_Vendor_Code varchar2(100); --待生成的中转单的供应商编码
    v_Po_Vendor_Name Varchar2(100); --待生成的中转单的供应商名称
    v_Po_Workshop_Inv_Code varchar2(100); --待生成中转单的车间仓
    v_Po_Cleared_Inv_Code varchar2(100); --待生成中转单的结算仓
    v_Po_Sales_Center_Id Number; -- 待生成中转单的营销中心ID
    v_Po_Sales_Center_Code Varchar2(100); --待生成中转单的营销中心编码
    v_Po_Sales_Center_Name Varchar2(100); --待生成中转单的营销中心名称
    v_Po_Price_List_Id Number; -- 待生成中转单的价格列表ID
    v_Po_Item_Back_Type varchar2(40); --来源订单类型
    v_Po_Order_Head_Id Number; --来源订单头ID
    v_Po_Sched_Order_Num varchar2(32); --来源订单号
    v_Po_Source_Type Varchar2(32); --来源代号
    v_Po_Roping_Flag varchar2(2); --入库拉运标识
    v_Po_Finance_Operating_Id Number; --待生成中转单的财务仓经营单位ID
    v_Po_Finance_Oraganization_Id Number; --待生成的中转单的财务仓组织ID
    v_Po_Vendor_Operating_Id Number; --待生成中转单的供应商经营单位ID
    v_Po_Vendor_Organization_Id Number; --待生成中转单的供应商组织ID
    v_Po_Red_Order_Flag varchar2(2); --中转单据类型是否红冲标识
    v_Po_Vendor_Site_Code varchar2(128); --供应商地点编码
    v_Po_Bill_Action_Type varchar2(100); --单据类型出入库方式，01入库，02出库
    v_Po_Bill_Control_Type varchar2(100); --单据类型对应的控制供应商的类型
    v_Po_Vendor_Main_Type varchar2(4); --供应商控制类型
    v_Po_Producing_Area_Id Number; --产地ID
    v_Po_Producing_Area_Code varchar2(32); --产地编码
    v_Po_Producing_Area_Name varchar2(100); --产地名称
    v_Po_Remark Varchar2(240); --备注信息
    v_Po_Count Number := 0;
    v_Po_Line_Num1 Number := 0; --中转单行编码，找到原单的
    v_Po_Line_Num2 Number := 0; --中转单行编码，没找到原单的
    v_Po_Item_Id Number; --产品ID
    v_Po_Item_Name Varchar2(240); --产品名称
    v_Po_Item_Bar_Code varchar2(100); --产品标识
    v_Po_Uom_Code Varchar2(20); --产品单位


    v_Source_num varchar2(32); --来源单号

    v_price              Number := 0; --返回价格
    v_discount           Number := 0; --返回折扣率
    v_month_discount     Number := 0; --返回月返
    v_cx_flag            Varchar2(10); --返回是否促销机
    v_Item_Onhand_Qty    Number := 0; --库存现有量
    v_Item_Occupy_Qty    Number := 0; --产品总占用量
    v_Usable_Qoh_Qty     Number := 0; --产品可用量
    v_Value            Varchar2(2000);
    v_Sales_Main_Type varchar2(32); --当前产品对应的产品大类

    v_Billed_Qty_Old Number :=0; --原单的数量
    v_Canceled_Qty_Old Number :=0; --原单的红冲数量
    v_Compensate_Qty_Old Number :=0; --原单的全赔数量
    v_Po_Back_Qty_Old Number :=0; --原单的退货数量
    v_Erp_Order_Header_Id Number; --关联订单号
    v_Erp_Order_Line_Id Number; --关联订单行号
    v_Erp_Logist_Line_Id Number; --关联物流行ID
    v_Can_Qty Number :=0; --退货找原单，原单的可退数量
    v_Po_Line_Id_Old Number; --原单行的id
    v_Can_Produce_Qty Number; --订单明细上可生产数量
    v_Cancel_Qty Number; --订单明细上已取消数量
    v_Po_Qty Number; --中转单上退货占用数量
    v_Po_Cancel_Qty Number; --中转单上退货红冲占用数量
    v_Stock_Fin_Type varchar2(100); --财务仓的存货类型
    v_Stock_Wor_Type varchar2(100); --车间仓的存货类型
    v_Stock_Cle_Type varchar2(100); --结算仓的存货类型

    --获取接口散件信息
    Cursor c_intf_lines Is
    Select * From intf_inv_po_lines_source t Where t.head_id = p_Intf_Head_Id;

    r_intf_line c_intf_lines%Rowtype;

    Begin
      p_Result := v_Success;

      --校验参数头ID是否为空
      If(p_Intf_Head_Id Is Null) Then
        p_Result := '无效参数';
        Raise v_Base_Exception;
      End If;

      --校验接口表头信息是否存在
      Begin
        Select Count(*)
          Into v_Intf_Count
          From Intf_Inv_Po_Headers_Source t
         Where t.Head_Id = p_Intf_Head_Id;
         If v_Intf_Count = 0 Then
           p_Result := '获取接口表头信息失败，头ID：' || to_char(p_Intf_Head_Id);
           Raise v_Base_Exception;
         End If;
      End;

      --获取接口表头的信息
      Begin
        Select t.Entity_Id,
               t.Po_Type_Id,
               t.Po_Type,
               t.Sales_Main_Type,
               t.Inv_Finance_Id,
               t.Inv_Finance_Code,
               t.Inv_Finance_Name,
               t.Inv_Logistics_Id,
               t.Inv_Logistics_Code,
               t.Inv_Logistics_Name,
               t.Vendor_Id,
               t.Vendor_Code,
               t.Vendor_Name,
               t.Workshop_Inv_Code,
               t.Cleared_Inv_Code,
               t.Sales_Center_Id,
               t.Sales_Center_Code,
               t.Sales_Center_Name,
               t.Price_List_Id,
               t.Item_Back_Type,
               t.Order_Header_Id,
               t.Sched_Order_Num,
               t.Source_Type,
               t.Roping_Flag,
               t.Vendor_Operating_Id,
               t.Vendor_Organization_Id,
               t.Finance_Operating_Id,
               t.Finance_Organization_Id,
               t.source_num,
               t.remark,
               t.producing_area_code
          Into v_Po_Entity_Id,
               v_Po_Type_Id,
               v_Po_Type,
               v_Po_Sales_Main_Type,
               v_Po_Inv_Finance_Id,
               v_Po_Inv_Finance_Code,
               v_Po_Inv_Finance_Name,
               v_Po_Inv_Logistics_Id,
               v_Po_Inv_Logistics_Code,
               v_Po_Inv_Logistics_Name,
               v_Po_Vendor_Id,
               v_Po_Vendor_Code,
               v_Po_Vendor_Name,
               v_Po_Workshop_Inv_Code,
               v_Po_Cleared_Inv_Code,
               v_Po_Sales_Center_Id,
               v_Po_Sales_Center_Code,
               v_Po_Sales_Center_Name,
               v_Po_Price_List_Id,
               v_Po_Item_Back_Type,
               v_Po_Order_Head_Id,
               v_Po_Sched_Order_Num,
               v_Po_Source_Type,
               v_Po_Roping_Flag,
               v_Po_Vendor_Operating_Id,
               v_Po_Vendor_Organization_Id,
               v_Po_Finance_Operating_Id,
               v_Po_Finance_Oraganization_Id,
               v_Source_num,
               v_Po_Remark,
               v_Po_Producing_Area_Code
          From Intf_Inv_Po_Headers_Source t
         Where t.Head_Id = p_Intf_Head_Id;
      Exception
        When Others Then
          p_Result := '获取接口头表的信息失败，' || v_Nl ||Sqlerrm;
          Raise v_Base_Exception;
      End;

      --根据单据类型ID获取对应单据类型以及出入库方式、供应商控制类型信息
      Begin
        Select Bt.Bill_Type_Id,
               Bt.Cancel_Flag,
               Bt.Control_Type,
               Tt.Action_Type,
               Decode(Bt.Control_Type, '10', '00', '11', '01', '12', '02')
          Into v_Po_Type_Id,
               v_Po_Red_Order_Flag,
               v_Po_Bill_Control_Type,
               v_Po_Bill_Action_Type,
               v_Po_Vendor_Main_Type
          From t_Inv_Bill_Types Bt, t_Inv_Transaction_Types Tt
         Where Bt.Bill_Type_Code = v_Po_Type
           And Bt.Entity_Id = v_Po_Entity_Id
           And Trunc(Sysdate) Between Trunc(Bt.Begin_Date) And
               Trunc(Nvl(Bt.End_Date, Sysdate))
           And Bt.Transaction_Type_Id = Tt.Transaction_Type_Id
           And Trunc(Sysdate) Between Trunc(Tt.Begin_Date) And
               Trunc(Nvl(Tt.End_Date, Sysdate));
      Exception
        When too_many_rows Then
          p_Result := '根据单据类型编码获取对应单据类型信息以及出入库方式信息多条。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '单据类型编码：' || v_Po_Type || v_Nl || Sqlerrm;
          Raise v_base_exception;
        When no_data_found Then
          p_Result := '根据单据类型编码获取不到对应单据类型信息以及出入库方式信息。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '单据类型编码：' || v_Po_Type || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When Others Then
          p_Result := '根据单据类型编码获取对应单据类型信息以及出入库方式信息失败。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '单据类型编码：' || v_Po_Type || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;

      --校验仓库信息是否有效以及获取对应的组织信息以及营销中心信息
      Begin
        Select Ii.Inventory_Id,
               Ii.Inventory_Name,
               Io.Operating_Unit,
               Ii.Organization_Id,
               Ou.Unit_Id,
               Ou.Code,
               Ou.Name,
               ii.stock_type
          Into v_Po_Inv_Finance_Id,
               v_Po_Inv_Finance_Name,
               v_Po_Finance_Operating_Id,
               v_Po_Finance_Oraganization_Id,
               v_Po_Sales_Center_Id,
               v_Po_Sales_Center_Code,
               v_Po_Sales_Center_Name,
               v_Stock_Fin_Type
          From t_Inv_Inventories Ii, t_Inv_Organization Io, Up_Org_Unit Ou
         Where Ii.Inventory_Code = v_Po_Inv_Finance_Code
           And Ii.Entity_Id = v_Po_Entity_Id
           And Trunc(Sysdate) Between Trunc(Ii.Begin_Date) And
               Trunc(Nvl(Ii.End_Date, Sysdate))
           And Ii.Organization_Id = Io.Organization_Id
           And Ii.Entity_Id = Io.Entity_Id
           And Trunc(Sysdate) Between
               Trunc(Nvl(Io.User_Definition_Enable_Date, Sysdate)) And
               Trunc(Nvl(Io.Disable_Date, Sysdate))
           And Ii.Unit_Id = Ou.Unit_Id
           And Ii.Entity_Id = Ou.Entity_Id
           And Ou.Is_Enabled = 'T';
      Exception
        When too_many_rows Then
          p_Result := '根据接口表财务仓编码获取财务仓以及所属的组织、营销中心信息多条。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '财务仓编码：' || v_Po_Inv_Finance_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When no_data_found Then
          p_Result := '根据接口表财务仓编码获取不到财务仓以及所属的组织、营销中心信息。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '财务仓编码：' || v_Po_Inv_Finance_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When Others Then
          p_Result := '根据接口表财务仓编码获取财务仓以及所属的组织、营销中心信息失败。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '财务仓编码：' || v_Po_Inv_Finance_Code || Sqlerrm;
          Raise v_Base_Exception;
      End;

      --校验供应商是否有效
      Begin
       Select Distinct t.Vendor_Id,
              t.Vendor_Name,
              --t.Operating_Unit,
              --t.Organization_Id,
              t.Vendor_Site_Code
         Into v_Po_Vendor_Id,
              v_Po_Vendor_Name,
             -- v_Po_Vendor_Operating_Id,
             -- v_Po_Vendor_Organization_Id,
              v_Po_Vendor_Site_Code
         From v_Inv_Vendor_View t
        Where t.Entity_Id = v_Po_Entity_Id
          And t.Vendor_Code = v_Po_Vendor_Code
          And t.Vendor_Site_Operating_Unit =
              Decode(v_Po_Finance_Operating_Id,
                     Null,
                     t.Vendor_Site_Operating_Unit,
                     v_Po_Finance_Operating_Id)
          And Nvl(t.Vendor_Site_Code, '地点') Not In
              ('非贸易型', '押金质保金')
          And t.Vendor_Main_Type =
              Decode(v_Po_Vendor_Main_Type,
                     '02',
                     t.Vendor_Main_Type,
                     v_Po_Vendor_Main_Type);
      Exception
        When too_many_rows Then
          p_Result := '根据接口表供应商编码获取供应商以及所属的组织信息多条。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '供应商编码：' || v_Po_Vendor_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When no_data_found Then
          p_Result := '根据接口表供应商编码获取不到供应商以及所属的组织信息。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '供应商编码：' || v_Po_Vendor_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When Others Then
          p_Result := '根据接口表供应商编码获取供应商以及所属的组织信息失败。' || v_Nl ||
                      '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                      '供应商编码：' || v_Po_Vendor_Code || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;

      --根据订单获取产地
      If v_Po_Order_Head_Id Is Null Then
        p_Result := '来源订单头ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      Else
        Select nvl(t.Virtual_Producing_Area_Code,t.producing_area_code)
          Into v_Po_Producing_Area_Code
          From t_Pln_Order_Head t
         Where t.Order_Head_Id = v_Po_Order_Head_Id;
      End If;

      --根据产地获取供应商组织、经营单位、产地信息
      If v_Po_Producing_Area_Code Is Null Then
        p_Result := '产地编码不能为空。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      Else
        Begin
          Select Io.Operating_Unit,
                 Pa.Mrp_Org_Id,
                 Pa.Producing_Area_Id,
                 Pa.Producing_Area_Name
            Into v_Po_Vendor_Operating_Id,
                 v_Po_Vendor_Organization_Id,
                 v_Po_Producing_Area_Id,
                 v_Po_Producing_Area_Name
            From t_Pln_Producing_Area Pa, t_Inv_Organization Io
           Where Pa.Producing_Area_Code = v_Po_Producing_Area_Code
             And Pa.Entity_Id = v_Po_Entity_Id
             And Pa.Mrp_Org_Id = Io.Organization_Id
             And Pa.Entity_Id = Io.Entity_Id
             And Trunc(Sysdate) Between Trunc(Nvl(Pa.Begin_Date, Sysdate)) And
                 Trunc(Nvl(Pa.End_Date, Sysdate))
             And Trunc(Sysdate) Between
                 Trunc(Nvl(Io.User_Definition_Enable_Date, Sysdate)) And
                 Trunc(Nvl(Io.Disable_Date, Sysdate));
        Exception
          When Too_Many_Rows Then
            p_Result := '根据产地编码获取对应的库存组织以及OU信息多条。' || v_Nl || '产地编码：' ||
                        v_Po_Producing_Area_Code || v_Nl || '接口头ID：' ||
                        p_Intf_Head_Id || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
          When No_Data_Found Then
            p_Result := '根据产地编码获取不到对应的库存组织以及OU信息。' || v_Nl || '产地编码：' ||
                        v_Po_Producing_Area_Code || v_Nl || '接口头ID：' ||
                        p_Intf_Head_Id || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
          When Others Then
            p_Result := '根据产地编码获取对应的库存组织以及OU信息失败。' || v_Nl || '产地编码：' ||
                        v_Po_Producing_Area_Code || v_Nl || '接口头ID：' ||
                        p_Intf_Head_Id || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;

      --校验供应商的价格列表信息
      Begin
        Select t.Price_List_Id
          Into v_Po_Price_List_Id
          From t_Bd_Vendor_Pricelist t
         Where t.Vendor_Id = v_Po_Vendor_Id
           And t.Price_List_Id = v_Po_Price_List_Id
           And t.Active_Flag = 'Y'
           And t.Type_Code = 'TRANSIT_TYPE';
      Exception
        When too_many_rows Then
          p_Result := '根据供应商以及价格列表ID获取有效供应商价格数据信息多条。' || v_Nl ||
                      '供应商编码：' || v_Po_Vendor_Code || v_Nl ||
                      '价格列表ID：' || v_Po_Price_List_Id || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When no_data_found Then
          p_Result := '根据供应商以及价格列表获取不到有效供应商价格数据信息。' || v_Nl ||
                      '供应商编码：' || v_Po_Vendor_Code || v_Nl ||
                      '价格列表ID：' || v_Po_Price_List_Id || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        When Others Then
          p_Result := '根据供应商以及价格列表获取有效供应商价格数据信息失败。' || v_Nl ||
                      '供应商编码：' || v_Po_Vendor_Code || v_Nl ||
                      '价格列表ID：' || v_Po_Price_List_Id || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;


      --如果实体仓编码不为空的话，则获取实体仓的信息
      If v_Po_Inv_Logistics_Code Is Not Null Then
        Begin
          Select Si.Storage_Id, Si.Storage_Name, Si.Storage_Tran_Flag
            Into v_Po_Inv_Logistics_Id,
                 v_Po_Inv_Logistics_Name,
                 v_Po_Roping_Flag
            From t_Inv_Storage_Info Si
           Where Si.Status = 'T'
             And Si.Entity_Id = v_Po_Entity_Id
             And Si.Storage_Code = v_Po_Inv_Logistics_Code
             And Si.Producing_Area_Id In
                 (Select Pa.Producing_Area_Id
                    From t_Pln_Producing_Area Pa
                   Where Pa.Mrp_Org_Id =
                         Decode(v_Po_Vendor_Organization_Id,
                                Null,
                                Pa.Mrp_Org_Id,
                                v_Po_Vendor_Organization_Id))
             And Trunc(Sysdate) Between Trunc(Nvl(Si.Active_Date, Sysdate)) And
                 Trunc(Nvl(Si.Invalid_Date, Sysdate))
             And Si.Status = 'T';
        Exception
          When too_many_rows Then
            p_Result := '根据接口表实体仓编码获取实体仓信息多条。' || v_Nl ||
                        '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                        '实体仓编码：' || v_Po_Inv_Logistics_Code || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
          When no_data_found Then
            p_Result := '根据接口表实体仓编码获取不到实体仓信息。' || v_Nl ||
                        '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                        '实体仓编码：' || v_Po_Inv_Logistics_Code || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
          When Others Then
            p_Result := '根据接口表实体仓编码获取实体仓信息失败。' || v_Nl ||
                        '接口头ID：' || p_Intf_Head_Id || v_Nl ||
                        '实体仓编码：' || v_Po_Inv_Logistics_Code || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
      End If;

      --校验待生成中转单字段是否为空
      If v_Po_Entity_Id Is Null Then
        p_Result := '主体ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If v_Po_Type_Id Is Null Then
        p_Result := '单据类型ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If v_Po_Inv_Finance_id Is Null Then
        p_Result := '财务仓ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If v_Po_Vendor_Id Is Null Then
        p_Result := '供应商ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If v_Po_Price_List_Id Is Null Then
        p_Result := '价格列表ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If v_Po_Sales_Center_Id Is Null Then
        p_Result := '营销中心ID为空，生成中转单失败。' || v_Nl ||Sqlerrm;
        Raise v_Base_Exception;
      End If;

      --大物流，车间仓、结算仓、退货类型、来源订单头ID、来源订单号不能为空
      If(v_Po_Workshop_Inv_Code Is Null) Then
        p_Result := '车间仓为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      --校验车间仓信息是否有效存在以及存货类型
      Begin
        Select Count(*), t.Stock_Type
          Into v_Intf_Count, v_Stock_Wor_Type
          From t_Inv_Vendor_Mrpii_Inv t
         Where t.Inv_Inout_Type = 'OUT'
           And t.Organization_Id = v_Po_Vendor_Organization_Id
           And t.Entity_Id = v_Po_Entity_Id
           And t.Workshop_Inv_Code = v_Po_Workshop_Inv_Code
           And Nvl(t.Disable_Date, Sysdate + 1) > Sysdate
         Group By t.Stock_Type;
        --车间仓信息不存在
        If (v_Intf_Count = 0) Then
          p_Result := '车间仓信息不存在' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        End If;
        --校验车间仓和财务仓的存货类型是否一致
        If (v_Stock_Fin_Type != v_Stock_Wor_Type) Then
          p_Result := '车间仓的存货类型和财务仓的存货类型不一致' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        End If;
      Exception
        When Others Then
          p_Result := p_Result || '获取车间仓信息失败' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;

      --退货找原单
      If(v_Po_Cleared_Inv_Code Is Null) Then
        p_Result := '结算仓为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      --校验结算仓信息是否有效存在以及存货类型
      Begin
        Select Count(*), t.Stock_Type
          Into v_Intf_Count, v_Stock_Wor_Type
          From t_Inv_Vendor_Mrpii_Inv t
         Where t.Inv_Inout_Type = 'IN'
           And t.Organization_Id = v_Po_Vendor_Organization_Id
           And t.Cims_Organization_Id = v_Po_Finance_Oraganization_Id
           And t.Entity_Id = v_Po_Entity_Id
           And t.Workshop_Inv_Code = v_Po_Cleared_Inv_Code
           And Nvl(t.Disable_Date, Sysdate + 1) > Sysdate
         Group By t.Stock_Type;
        --结算仓信息不存在
        If (v_Intf_Count = 0) Then
          p_Result := '结算仓信息不存在' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        End If;
        --校验结算仓和财务仓的存货类型是否一致
        If (v_Stock_Fin_Type != v_Stock_Wor_Type) Then
          p_Result := '结算仓的存货类型和财务仓的存货类型不一致' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
        End If;
      Exception
        When Others Then
          p_Result := p_Result || '获取结算仓信息失败' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;

      If(v_Po_Item_Back_Type Is Null) Then
        p_Result := '退货类型为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If(v_Po_Order_Head_Id Is Null) Then
        p_Result := '来源订单头ID为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;

      If(v_Po_Sched_Order_Num Is Null) Then
        p_Result := '来源订单号为空，生成中转单失败。' || v_Nl || Sqlerrm;
        Raise v_Base_Exception;
      End If;


      --插入行表
      If(p_Result = v_Success) Then
        Select Count(*)
          Into v_Intf_Count
          From Intf_Inv_Po_Lines_Source t
         Where t.head_id = p_Intf_Head_Id;
        If v_Intf_Count = 0 Then
          p_Result := '获取接口行信息失败，接口头ID：' || To_Char(p_Intf_Head_Id);
          Raise v_Base_Exception;
        End If;


        For r_line In c_intf_lines Loop

          --获取产品有效信息
          Begin
            Select t.Item_Id,
                   t.Item_Name,
                   t.Barcode,
                   t.Defaultunit,
                   t.Sales_Main_Type
              Into v_Po_Item_Id,
                   v_Po_Item_Name,
                   v_Po_Item_Bar_Code,
                   v_Po_Uom_Code,
                   v_Sales_Main_Type
              From t_Bd_Item t
             Where t.Item_Code = r_Line.Item_Code
               And t.Entity_Id = v_Po_Entity_Id
               And t.Active_Flag = 'Y';
          Exception
            When no_data_found Then
              p_Result := '根据产品编码获取不到有效的产品信息。' || v_Nl ||
                          '产品编码：' || r_line.item_code || v_Nl ||
                          '接口头ID：' || p_Intf_Head_Id ||  v_Nl || Sqlerrm;
              Raise v_Base_Exception;
            When Others Then
              p_Result := '根据产品编码获取产品信息失败。' || v_Nl ||
                          '产品编码：' || r_line.item_code || v_Nl ||
                          '接口头ID：' || p_Intf_Head_Id || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;

          If(v_Po_Sales_Main_Type Is Null) Then
            v_Po_Sales_Main_Type := v_Sales_Main_Type;
          Else
            If(v_Po_Sales_Main_Type != v_Sales_Main_Type) Then
              p_Result := '本次生成中转单的产品大类不相同，请确认。' || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
            End If;
          End If;

          If(v_Po_Sales_Main_Type Is Null) Then
            p_Result := '产品大类为空，请确认。' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
          End If;

          --校验来源单行ID是否存在以及是否正确
          If(r_line.order_id_orig Is Null) Then
            p_Result := '产品' || r_line.item_code || '来源单行ID为空，请确认' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
          Else
            Begin
              Select Count(*),
                     Nvl(t.Can_Produce_Qty, 0),
                     Nvl(t.Cancel_Qty, 0)
                Into v_Po_Count, v_Can_Produce_Qty, v_Cancel_Qty
                From t_Pln_Order_Detail t
               Where t.Item_Code = r_Line.Item_Code
                 And t.Order_Detail_Id = r_Line.Order_Id_Orig
               Group By t.Can_Produce_Qty, t.Cancel_Qty;
               If v_Po_Count <> 1 Then
                 p_Result := '产品' || r_line.item_code || '来源单行ID不正确，请确认' || v_Nl || Sqlerrm;
                 Raise v_Base_Exception;
               End If;
            Exception
              When Others Then
                p_Result := '产品' || r_line.item_code || '来源单行ID不正确，请确认' || v_Nl || Sqlerrm;
                Raise v_Base_Exception;
            End;
          End If;

          --大物流，校验订单的可退货数量是否足够
          --获取中转单退货占用的数量以及退货红冲占用的数量差
          --获取中转单上退货占用的数量
          Begin
            Select Nvl(Sum(Pl.Billed_Qty), 0)
              Into v_Po_Qty
              From t_Inv_Po_Lines Pl
             Where Pl.Item_Code = r_Line.Item_Code
               And Pl.Po_Id In
                   (Select Ph.Po_Id
                      From t_Inv_Po_Headers Ph
                     Where Ph.Sched_Order_Num = v_Po_Sched_Order_Num
                       And Ph.Po_Type = v_Po_Type
                       And Ph.Close_Flag = 'N'
                       And Ph.Entity_Id = v_Po_Entity_Id)
               And Pl.Pln_Order_Detail_Id = r_Line.Order_Id_Orig;
          Exception
            When Others Then
              p_Result := '产品' || r_line.item_code || '获取中转单上退货被占用的数量报错' || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;

          --获取中转单上退货红冲占用的数量
          Begin
            Select Nvl(Sum(Pl.Billed_Qty), 0)
              Into v_Po_Cancel_Qty
              From t_Inv_Po_Lines Pl
             Where Pl.Item_Code = r_Line.Item_Code
               And Pl.Po_Id In
                   (Select Ph.Po_Id
                      From t_Inv_Po_Headers Ph
                     Where Ph.Sched_Order_Num = v_Po_Sched_Order_Num
                       And Ph.Po_Type In
                           (Select Bt.Bill_Type_Code
                              From t_Inv_Bill_Types Bt
                             Where Bt.Blue_Bill_Type_Id = v_Po_Type_Id)
                       And Ph.Po_Status = '14'
                       And Ph.Entity_Id = v_Po_Entity_Id)
               And Pl.Pln_Order_Detail_Id = r_Line.Order_Id_Orig;
          Exception
            When Others Then
              p_Result := '产品' || r_line.item_code || '获取中转单上退货红冲被占用的数量报错' || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;

          --订单上的生产数量-已取消数量-（中转退货占用的数量-中转退货红冲占用的数量）为本次可退的最多数量
          If((v_Can_Produce_Qty - v_Cancel_Qty - v_Po_Qty + v_Po_Cancel_Qty) < r_line.billed_qty) Then
            p_Result := '产品' || r_line.item_code || '本次退货的数量已超过订单上可退货的数量' || v_Nl ||
                        '订单明细行ID:' || r_line.order_id_orig || v_Nl ||
                        '订单上生产数量：' || v_Can_Produce_Qty || v_Nl ||
                        '订单上已取消数量：' || v_Cancel_Qty || v_Nl ||
                        '中转单退货占用的数量：' || v_Po_Qty || v_Nl ||
                        '中转退货红冲占用的数量：' || v_Po_Cancel_Qty || v_Nl ||
                        '本次退货的数量：' || r_line.billed_qty || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
          End If;

          Begin
          pkg_bd_price.p_Get_Price(p_Acc_Id         => Null, --账户ID
                                   p_Item_Code      => r_line.item_code, --产品ID
                                   p_Bill_Date      => To_Char(Sysdate, 'YYYYMMDD'), --单据日期
                                   p_Price_List_Id  => v_Po_Price_List_Id, --价格列表ID
                                   p_Entity_Id      => v_Po_Entity_Id, --业务主体ID
                                   p_Price          => v_Price, --返回价格
                                   p_Discount       => v_Discount, --返回折扣率
                                   p_Month_Discount => v_Month_Discount, --返回月返
                                   p_Cx_Flag        => v_Cx_Flag --返回是否促销机
                                   );
          Exception
            When Others Then
              p_Result := '获取产品价格失败，产品编码：' || r_line.item_code || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
          If v_price Is Null Then
            p_Result := '获取产品的价格为空，产品编码：' || r_line.item_code || v_Nl ||
                        '价格列表ID：' || v_Po_Price_List_Id || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
          End If;

          --出库校验库存是否足够，01入库。02出库
          If(v_Po_Bill_Action_Type = '02') Then
            Begin
              Pkg_Inv_Pub.p_Get_Item_Inv_Qoh(p_Entity_Id         => v_Po_Entity_Id,
                                             p_Inventory_Id      => v_Po_Inv_Finance_id,
                                             p_Item_Id           => v_Po_Item_Id,
                                             p_User_Code         => p_User_Code,
                                             p_Qoh_Qty           => v_Item_Onhand_Qty,
                                             p_Usable_Qoh_Qty    => v_Usable_Qoh_Qty,
                                             p_Occupy_Qty        => v_Item_Occupy_Qty,
                                             p_Result            => v_Value);
              If v_Value != v_Success Then
                p_Result := '获取库存可用量失败。';
                Raise v_Base_Exception;
              End If;
            Exception
              When no_data_found Then
                v_Usable_Qoh_Qty := 0;
              When Others Then
                p_Result := v_Value || '错误信息：' || p_Result || Sqlerrm;
                Raise v_Base_Exception;
            End;
            --校验库存是否足够
            If(r_line.billed_qty > v_Usable_Qoh_Qty) Then
              p_Result := '产品库存不足，接口头ID：' || p_Intf_Head_Id || v_Nl ||
                          '本次出库的产品编码：' || r_line.item_code || v_Nl ||
                          '本次出库的数量：' || r_line.billed_qty || v_Nl ||
                          '库存可用量：' || v_Usable_Qoh_Qty || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
            End If;
          End If;

          --退货找原单
          Begin
/*            Select Inv.Can_Qty,
                   Inv.Erp_Order_Header_Id,
                   Inv.Po_Line_Num,
                   Inv.Req_Line_Id,
                   Inv.Po_Line_Id
              Into v_Can_Qty,
                   v_Erp_Order_Header_Id,
                   v_Erp_Order_Line_Id,
                   v_Erp_Logist_Line_Id,
                   v_Po_Line_Id_Old
              From (Select \*+DRIVING_SITE(Ff)*\
                     p.Po_Id,
                     p.Po_Line_Id,
                     (p.Billed_Qty - Nvl(p.Canceled_Qty, 0) -
                     Nvl(p.Compensate_Qty, 0) - Nvl(p.Po_Back_Qty, 0)) As Can_Qty,
                     p.Item_Code,
                     p.Po_Line_Num,
                     p.Erp_Order_Header_Id,
                     p.Erp_Logist_Header_Id,
                     Ff.Req_Line_Id,
                     Ff.Order_Line_Num
                      From (Select Cc.Po_Id,
                                   Dd.Po_Line_Id,
                                   Dd.Billed_Qty,
                                   Dd.Canceled_Qty,
                                   Dd.Compensate_Qty,
                                   Dd.Po_Back_Qty,
                                   Dd.Item_Code,
                                   Dd.Po_Line_Num,
                                   Cc.Erp_Order_Header_Id,
                                   Cc.Erp_Logist_Header_Id
                              From Cims.t_Inv_Po_Headers Cc,
                                   Cims.t_Inv_Po_Lines   Dd
                             Where Dd.Po_Id = Cc.Po_Id
                               And Cc.Po_Status = '14'
                               And Cc.Po_Type = '1001'
                               And Cc.Erp_Order_Header_Id Is Not Null
                               And Dd.Item_Code = r_line.item_code
                               And Cc.Sales_Center_Id = v_Po_Sales_Center_Id
                               And Cc.Vendor_Organization_Id = v_Po_Vendor_Organization_Id
                               And Cc.Finance_Organization_Id = v_Po_Finance_Oraganization_Id
                               And Cc.Cleared_Inv_Code = v_Po_Cleared_Inv_Code
                               And Cc.Entity_Id = v_Po_Entity_Id
                               And (Dd.Billed_Qty - Nvl(Dd.Canceled_Qty, 0) -
                                   Nvl(Dd.Compensate_Qty, 0) -
                                   Nvl(Dd.Po_Back_Qty, 0)) > 0) p,
                           Apps.Cux_Icp_Logist_Req_Lines_v@Mdims2mderp Ff
                     Where Ff.Req_Line_Num = p.Po_Line_Num
                       And Ff.Req_Header_Id = p.Erp_Logist_Header_Id

                     Order By (p.Billed_Qty - Nvl(p.Canceled_Qty, 0) -
                              Nvl(p.Compensate_Qty, 0) -
                              Nvl(p.Po_Back_Qty, 0)) Desc) Inv
             Where Rownum <= 1;*/
             Select Inv.Can_Qty,
                    Inv.Erp_Order_Header_Id,
                    Inv.Po_Line_Num,
                    Inv.Req_Line_Id,
                    Inv.Po_Line_Id
               Into v_Can_Qty,
                    v_Erp_Order_Header_Id,
                    v_Erp_Order_Line_Id,
                    v_Erp_Logist_Line_Id,
                    v_Po_Line_Id_Old
               From (Select (l.Billed_Qty - Nvl(l.Canceled_Qty, 0) -
                            Nvl(l.Compensate_Qty, 0) -
                            Nvl(l.Po_Back_Qty, 0)) As Can_Qty,
                            h.Erp_Order_Header_Id,
                            l.Po_Line_Num,
                            Null Req_Line_Id,
                            l.Po_Line_Id
                       From t_Inv_Po_Headers h, t_Inv_Po_Lines l
                      Where h.Po_Id = l.Po_Id
                        And h.Po_Status = '14'
                        And h.Po_Type = '1001'
                        And h.Erp_Order_Header_Id Is Not Null
                        And h.Erp_Logist_Header_Id Is Not Null
                        And (Nvl(l.Billed_Qty, 0) - Nvl(l.Canceled_Qty, 0) -
                            Nvl(l.Compensate_Qty, 0) -
                            Nvl(l.Po_Back_Qty, 0)) > 0
                        And l.Item_Code = r_Line.Item_Code
                        And h.Sales_Center_Id = v_Po_Sales_Center_Id
                        And h.Vendor_Organization_Id =
                            v_Po_Vendor_Organization_Id
                        And h.Finance_Organization_Id =
                            v_Po_Finance_Oraganization_Id
                        And h.Cleared_Inv_Code = v_Po_Cleared_Inv_Code
                        And h.Entity_Id = v_Po_Entity_Id
                      Order By (l.Billed_Qty - Nvl(l.Canceled_Qty, 0) -
                               Nvl(l.Compensate_Qty, 0) -
                               Nvl(l.Po_Back_Qty, 0)) Desc) Inv
              Where Rownum <= 1;


             If(v_Can_Qty Is Null) Then
               v_Can_Qty := 0;
             End If;

          Exception
            When no_data_found Then
              v_Can_Qty := 0;
            When Others Then
              p_Result := '根据营销中心，供应商，财务仓，产品以及结算仓查找源单信息失败' || v_Nl ||
                          '营销中心编码：' || v_Po_Sales_Center_Code || v_Nl ||
                          '营销中心ID：' || v_Po_Sales_Center_Id || v_Nl ||
                          '供应商编码：' || v_Po_Vendor_Code || v_Nl ||
                          '供应商所属的组织：' || v_Po_Vendor_Organization_Id || v_Nl ||
                          '财务仓编码：' || v_Po_Inv_Finance_Code || v_Nl ||
                          '财务仓所属的组织：' || v_Po_Finance_Oraganization_Id || v_Nl ||
                          '产品编码：' || r_Line.Item_Code || v_Nl ||
                          '结算仓编码：' || v_Po_Cleared_Inv_Code || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;

          --本次退货的数量小于源单的可退数量，则找到原单，生成退货单，否则生成反向销售单
          If(r_line.billed_qty <= v_Can_Qty) Then
            --找到原单，插入中转单头表
            If(p_Result = v_Success And v_Po_Head_Id1 Is Null) Then
              Begin
                --中转单头ID
                select S_INV_PO_HEADERS.nextval Into v_Po_Head_Id1 from dual;

                Insert Into t_inv_po_headers
                (Po_Id, --采购单据ID
                 Entity_Id, --经营主体ID
                 Po_Type_Id, --单据类型ID
                 Po_Type, --单据类型
                 Po_Num, --采购单据编号
                 Billed_Date, --单据日期
                 Po_Status, --单据状态
                 Sales_Main_Type, --营销大类
                 Inv_Finance_Id, --财务仓ID
                 Inv_Finance_Code, --财务仓编码
                 Inv_Finance_Name, --财务仓名称
                 INV_LOGISTICS_ID, --实体仓ID
                 INV_LOGISTICS_CODE, --实体仓编码
                 INV_LOGISTICS_NAME, --实体仓名称
                 Vendor_Id, --供应商ID
                 Vendor_Code, --供应商编码
                 Vendor_Name, --供应商名称
                 WORKSHOP_INV_CODE, --车间仓
                 CLEARED_INV_CODE, --结算仓
                 Sales_Center_Id, --营销中心ID
                 Sales_Center_Code, --营销中心编码
                 Sales_Center_Name, --营销中心名称
                 Price_List_Id, --价格列表ID
                 ITEM_BACK_TYPE, --来源订单类型
                 ORDER_HEADER_ID, --来源订单头ID
                 SCHED_ORDER_NUM, --来源订单号
                 Created_By, --创建者
                 Creation_Date, --创建日期
                 ship_by, --发货人
                 ship_time, --发货时间
                 ship_date, --发货日期
                 Remark, --备注
                 Close_Flag,  --关闭标志
                 Last_Updated_By, --更新者
                 Last_Update_Date, --更新日期
                 Source_Type, --来源代号(工单入库)
                 ROPING_FLAG, --入库拉运标识
                 Red_Order_Flag, --红冲标识
                 vendor_operating_id,
                 vendor_organization_id,
                 Finance_Operating_id,
                 Finance_Organization_id,
                 PRODUCING_AREA_ID,
                 PRODUCING_AREA_CODE,
                 PRODUCING_AREA_NAME,
                 FIND_ORDER_FLAG,
                 ERP_TRANCATION,
                 INPUT_NUM
                 )
                 Values
                 (
                 v_Po_Head_Id1,
                 v_Po_Entity_Id,
                 v_Po_Type_Id,
                 v_Po_Type,
                 to_char(v_Po_Head_Id1),
                 trunc(Sysdate),
                 '21',
                 v_Po_Sales_Main_Type,
                 v_Po_Inv_Finance_id,
                 v_Po_Inv_Finance_Code,
                 v_Po_Inv_Finance_Name,
                 v_Po_Inv_Logistics_Id,
                 v_Po_Inv_Logistics_Code,
                 v_Po_Inv_Logistics_Name,
                 v_Po_Vendor_Id,
                 v_Po_Vendor_Code,
                 v_Po_Vendor_Name,
                 v_Po_Workshop_Inv_Code,
                 v_Po_Cleared_Inv_Code,
                 v_Po_Sales_Center_Id,
                 v_Po_Sales_Center_Code,
                 v_Po_Sales_Center_Name,
                 v_Po_Price_List_Id,
                 v_Po_Item_Back_Type,
                 v_Po_Order_Head_Id,
                 v_Po_Sched_Order_Num,
                 p_User_Code,
                 Sysdate,
                 p_User_Code,
                 Sysdate,
                 trunc(Sysdate),
                 v_Po_Remark || '，' || v_Po_Source_Type || '：' || v_Source_num,
                 'N',
                 p_User_Code,
                 Sysdate,
                 v_Po_Source_Type,
                 v_Po_Roping_Flag,
                 v_Po_Red_Order_Flag,
                 v_Po_Vendor_Operating_Id,
                 v_Po_Vendor_Organization_Id,
                 v_Po_Finance_Operating_Id,
                 v_Po_Finance_Oraganization_Id,
                 v_Po_Producing_Area_Id,
                 v_Po_Producing_Area_Code,
                 v_Po_Producing_Area_Name,
                 'Y',
                 '08',
                 v_Source_num
                 );
              Exception
                When Others Then
                  p_Result := '插入中转单头表失败：' || v_Nl || Sqlerrm;
                  Raise v_Base_Exception;
              End;
            End If;

            --找到原单，插入行表
            If(p_Result = v_Success) Then
              v_Po_Num1 := v_Po_Num1 + 1;
              Begin
                Insert Into t_Inv_Po_Lines
                  (Po_Line_Id, --采购单行ID
                   Po_Id, --采购单ID
                   Po_Line_Num, --采购单行编码
                   Item_Id, --产品ID
                   Item_Code, --产品编码，即销售码
                   Item_Name, --产品名称
                   Item_Bar_Code, --产品标识
                   Uom_Code, --产品单位
                   Item_Price, --产品价格
                   Billed_Qty, --开单数量
                   Shipped_Qty, --发货数量
                   Order_Id_Orig, --来源明细IS
                   Created_By, --创建者
                   Creation_Date, --创建日期
                   Last_Updated_By, --更新者
                   Last_Update_Date, --更新日期
                   ERP_ORDER_HEADER_ID, --关联订单号
                   ERP_ORDER_LINE_ID, --关联订单行号
                   ERP_LOGIST_LINE_ID, --关联物流行ID
                   PLN_ORDER_DETAIL_ID
                   )
                Values
                  (s_Inv_Po_Lines.Nextval,
                   v_Po_Head_Id1,
                   v_Po_Num1,
                   v_Po_Item_Id, --产品ID
                   r_Line.Item_Code, --产品编码，即销售码
                   v_Po_Item_Name, --产品名称
                   v_Po_Item_Bar_Code, --产品标识
                   v_Po_Uom_Code, --产品单位
                   v_Price, --产品价格
                   r_Line.Billed_Qty, --开单数量
                   r_Line.Billed_Qty, --发货数量
                   r_Line.Order_Id_Orig, --来源单明细ID
                   p_User_Code,
                   Sysdate,
                   p_User_Code,
                   Sysdate,
                   v_Erp_Order_Header_Id,
                   v_Erp_Order_Line_Id,
                   v_Erp_Logist_Line_Id,
                   r_Line.Order_Id_Orig);
              Exception
                When Others Then
                  p_Result := '生成中转单行失败。' || v_Nl || Sqlerrm;
                  Raise v_Base_Exception;
              End;
            End If;

            --找到原单，更新原单的退货数量
            Begin
              Update t_Inv_Po_Lines t
                 Set t.Po_Back_Flag = 'Y',
                     t.Po_Back_Qty  = Nvl(t.Po_Back_Qty, 0) +
                                      r_Line.Billed_Qty
               Where t.Po_Line_Id = v_Po_Line_Id_Old;
            Exception
              When Others Then
                p_Result := '更新原中转单行失败。' || v_Nl || Sqlerrm;
                Raise v_Base_Exception;
            End;

          Else
            --没找到原单，插入中转单头表
            if(p_Result = v_Success And v_Po_Head_Id2 Is Null) Then
              --呵呵
              Begin
                --中转单头ID
                select S_INV_PO_HEADERS.nextval Into v_Po_Head_Id2 from dual;

                Insert Into t_inv_po_headers
                (Po_Id, --采购单据ID
                 Entity_Id, --经营主体ID
                 Po_Type_Id, --单据类型ID
                 Po_Type, --单据类型
                 Po_Num, --采购单据编号
                 Billed_Date, --单据日期
                 Po_Status, --单据状态
                 Sales_Main_Type, --营销大类
                 Inv_Finance_Id, --财务仓ID
                 Inv_Finance_Code, --财务仓编码
                 Inv_Finance_Name, --财务仓名称
                 INV_LOGISTICS_ID, --实体仓ID
                 INV_LOGISTICS_CODE, --实体仓编码
                 INV_LOGISTICS_NAME, --实体仓名称
                 Vendor_Id, --供应商ID
                 Vendor_Code, --供应商编码
                 Vendor_Name, --供应商名称
                 WORKSHOP_INV_CODE, --车间仓
                 CLEARED_INV_CODE, --结算仓
                 Sales_Center_Id, --营销中心ID
                 Sales_Center_Code, --营销中心编码
                 Sales_Center_Name, --营销中心名称
                 Price_List_Id, --价格列表ID
                 ITEM_BACK_TYPE, --来源订单类型
                 ORDER_HEADER_ID, --来源订单头ID
                 SCHED_ORDER_NUM, --来源订单号
                 Created_By, --创建者
                 Creation_Date, --创建日期
                 ship_by, --发货人
                 ship_time, --发货时间
                 ship_date, --发货日期
                 Remark, --备注
                 Close_Flag,  --关闭标志
                 Last_Updated_By, --更新者
                 Last_Update_Date, --更新日期
                 Source_Type, --来源代号(工单入库)
                 ROPING_FLAG, --入库拉运标识
                 Red_Order_Flag, --红冲标识
                 vendor_operating_id,
                 vendor_organization_id,
                 Finance_Operating_id,
                 Finance_Organization_id,
                 PRODUCING_AREA_ID,
                 PRODUCING_AREA_CODE,
                 PRODUCING_AREA_NAME,
                 FIND_ORDER_FLAG,
                 ERP_TRANCATION,
                 INPUT_NUM
                 )
                 Values
                 (
                 v_Po_Head_Id2,
                 v_Po_Entity_Id,
                 v_Po_Type_Id,
                 v_Po_Type,
                 to_char(v_Po_Head_Id2),
                 trunc(Sysdate),
                 '21',
                 v_Po_Sales_Main_Type,
                 v_Po_Inv_Finance_id,
                 v_Po_Inv_Finance_Code,
                 v_Po_Inv_Finance_Name,
                 v_Po_Inv_Logistics_Id,
                 v_Po_Inv_Logistics_Code,
                 v_Po_Inv_Logistics_Name,
                 v_Po_Vendor_Id,
                 v_Po_Vendor_Code,
                 v_Po_Vendor_Name,
                 v_Po_Workshop_Inv_Code,
                 v_Po_Cleared_Inv_Code,
                 v_Po_Sales_Center_Id,
                 v_Po_Sales_Center_Code,
                 v_Po_Sales_Center_Name,
                 v_Po_Price_List_Id,
                 v_Po_Item_Back_Type,
                 v_Po_Order_Head_Id,
                 v_Po_Sched_Order_Num,
                 p_User_Code,
                 Sysdate,
                 p_User_Code,
                 Sysdate,
                 trunc(Sysdate),
                 v_Po_Remark || '，' || v_Po_Source_Type || '：' || v_Source_num,
                 'N',
                 p_User_Code,
                 Sysdate,
                 v_Po_Source_Type,
                 v_Po_Roping_Flag,
                 v_Po_Red_Order_Flag,
                 v_Po_Vendor_Operating_Id,
                 v_Po_Vendor_Organization_Id,
                 v_Po_Finance_Operating_Id,
                 v_Po_Finance_Oraganization_Id,
                 v_Po_Producing_Area_Id,
                 v_Po_Producing_Area_Code,
                 v_Po_Producing_Area_Name,
                 'N',
                 '09',
                 v_Source_num
                 );
              Exception
                When Others Then
                  p_Result := '插入中转单头表失败：' || v_Nl || Sqlerrm;
                  Raise v_Base_Exception;
              End;
            End If;

            --没找到原单，插入行表
            If(p_Result = v_Success) Then
              v_Po_Num2 := v_Po_Num2 + 1;
              Begin
                Insert Into t_Inv_Po_Lines
                  (Po_Line_Id, --采购单行ID
                   Po_Id, --采购单ID
                   Po_Line_Num, --采购单行编码
                   Item_Id, --产品ID
                   Item_Code, --产品编码，即销售码
                   Item_Name, --产品名称
                   Item_Bar_Code, --产品标识
                   Uom_Code, --产品单位
                   Item_Price, --产品价格
                   Billed_Qty, --开单数量
                   Shipped_Qty, --发货数量
                   Order_Id_Orig, --来源明细IS
                   Created_By, --创建者
                   Creation_Date, --创建日期
                   Last_Updated_By, --更新者
                   Last_Update_Date, --更新日期
                   PLN_ORDER_DETAIL_ID
                   )
                Values
                  (s_Inv_Po_Lines.Nextval,
                   v_Po_Head_Id2,
                   v_Po_Num2,
                   v_Po_Item_Id, --产品ID
                   r_Line.Item_Code, --产品编码，即销售码
                   v_Po_Item_Name, --产品名称
                   v_Po_Item_Bar_Code, --产品标识
                   v_Po_Uom_Code, --产品单位
                   v_Price, --产品价格
                   r_Line.Billed_Qty, --开单数量
                   r_Line.Billed_Qty, --发货数量
                   r_Line.Order_Id_Orig, --来源单明细ID
                   p_User_Code,
                   Sysdate,
                   p_User_Code,
                   Sysdate,
                   r_Line.Order_Id_Orig);
              Exception
                When Others Then
                  p_Result := '生成中转单行失败。' || v_Nl || Sqlerrm;
                  Raise v_Base_Exception;
              End;
            End If;

          End If;


        End Loop;
      End If;

      --检查是否生成多张中转单头，找到原单
      If(p_Result = v_Success) Then
        Select Count(*)
          Into v_Po_Count
          From t_Inv_Po_Headers t
         Where t.Po_Num = To_Char(v_Po_Head_Id1)
           And t.Entity_Id = v_Po_Entity_Id;
        If v_Po_Count > 1 Then
          p_Result := '生成多张中转单头信息，请检查';
          Raise v_Base_Exception;
        End If;
      End If;

      --检查是否生成多张中转单头，没找到原单
      If(p_Result = v_Success) Then
        Select Count(*)
          Into v_Po_Count
          From t_Inv_Po_Headers t
         Where t.Po_Num = To_Char(v_Po_Head_Id2)
           And t.Entity_Id = v_Po_Entity_Id;
        If v_Po_Count > 1 Then
          p_Result := '生成多张中转单头信息，请检查';
          Raise v_Base_Exception;
        End If;
      End If;

      --获取中转单号，找到原单，更新中转单号
      If(p_Result = v_Success  And v_Po_Head_Id1 Is Not Null) Then
        Begin
          v_Po_Num := Pkg_Bd.f_Get_Bill_No('invPONum',
                                                   '',
                                           v_Po_Entity_Id,
                                           '');
          If (v_Po_Num = '' Or v_Po_Num Is Null) Then
            p_Result := '生成的中转单号为空，请确认单号生成规则是否正确，单号规则：invPONum' || v_Nl ||Sqlerrm;
            Raise v_Base_Exception;
          End If;
        Exception
          When Others Then
            p_Result := '获取中转单单号失败，单据号生成规则：invPONum。' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
        --更新中转单编号
        Update t_Inv_Po_Headers t
           Set t.Po_Num = v_Po_Num, t.sales_main_type = v_Po_Sales_Main_Type
         Where t.Po_Id = v_Po_Head_Id1;
        p_Po_Num := '生成一张中转退货单号：' || v_Po_Num || '，' || v_Nl;
        p_Po_Head_Id := v_Po_Head_Id1;

        --更新接口表
        If(p_Result = v_Success) Then
          Update Intf_Inv_Po_Headers_Source t
             Set t.Status = 'Y'
           Where t.Head_Id = p_Intf_Head_Id;
        End If;
      End If;

      --获取中转单号，没找到原单，更新中转单号
      If(p_Result = v_Success  And v_Po_Head_Id2 Is Not Null) Then
        Begin
          v_Po_Num := Pkg_Bd.f_Get_Bill_No('invPONum',
                                                   '',
                                           v_Po_Entity_Id,
                                           '');
          If (v_Po_Num = '' Or v_Po_Num Is Null) Then
            p_Result := '生成的中转单号为空，请确认单号生成规则是否正确，单号规则：invPONum' || v_Nl ||Sqlerrm;
            Raise v_Base_Exception;
          End If;
        Exception
          When Others Then
            p_Result := '获取中转单单号失败，单据号生成规则：invPONum。' || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
        End;
        --更新中转单编号
        Update t_Inv_Po_Headers t
           Set t.Po_Num = v_Po_Num, t.sales_main_type = v_Po_Sales_Main_Type
         Where t.Po_Id = v_Po_Head_Id2;
        p_Po_Num := p_Po_Num || '生成一张反向销售单号：' || v_Po_Num || v_Nl;
        If(p_Po_Head_Id Is Null) Then
          p_Po_Head_Id := v_Po_Head_Id2;
        Else
          p_Po_Head_Id := p_Po_Head_Id || ',' || v_Po_Head_Id2;
        End If;


        --更新接口表
        If(p_Result = v_Success) Then
          Update Intf_Inv_Po_Headers_Source t
             Set t.Status = 'Y'
           Where t.Head_Id = p_Intf_Head_Id;
        End If;
      End If;


    Exception
      When v_Base_Exception Then
        p_Result := '生成中转单失败，' || p_Result;
        --自治事务，更新接口表的状态以及错误信息
        p_Result := p_Result || F_ADD_ERROR_LOG(p_Intf_Head_Id,p_Result);
      When Others Then
        p_Result := '生成中转单失败' || v_Nl || Sqlerrm;
        --自治事务，更新接口表的状态以及错误信息
        p_Result := p_Result || F_ADD_ERROR_LOG(p_Intf_Head_Id,p_Result);
    End;



  --------------------------------------------------------------------------
  --Author: sushu
  -- Created : 2015-11-20
  --Purpose:自治事务，更新接口表的状态以及错误信息
  --------------------------------------------------------------------------
  function F_ERROR_LOG(p_Result in varchar2) --错误信息
    Return Varchar2
    Is

    l_Return_Msg varchar2(255);
    pragma autonomous_transaction;
    Begin
      --启动独立事务
      Begin
         Commit;
      Exception
        When Others Then
          l_Return_Msg := substr(Sqlerrm,1,254);
      End;
      Return l_Return_Msg;

    End;
    
    
    
  --------------------------------------------------------------------------
  --Author: sushu
  -- Created : 2016-08-23
  --Purpose:中转单关联交易校验产品是否分配有效的供应商
  --------------------------------------------------------------------------
 /* Procedure p_item_vendor_relation(p_Po_Num In varchar2, --中转单号
                                   p_Entity_Id In Number, --主体
                                   p_Result       Out varchar2) Is --返回的结果
    
    v_Item_Vendor_Relation varchar2(10); --是否校验物料使用批准得供应商
    v_Vendor_Code varchar2(100); --供应商
    v_Finance_Operating_Id Number; --财务仓Ou
    v_Erp_Trancation varchar2(100); --ERP事务处理类型
    v_Vendor_Id Number; --erp对应的供应商ID
    v_Vendor_Site_Id Number; --erp对应的供应商地点ID
    v_Item_Code varchar2(2000); --产品拼接串
  
    Begin
      p_Result := v_Success;
      
      --获取是否校验物料使用批准的供应商的校验关系
      Begin
        v_Item_Vendor_Relation := Pkg_Bd.F_Get_Parameter_Value('inv_item_vendor_relation',p_Entity_Id);
      Exception
        When Others Then
          p_Result := p_Result || '获取系统参数inv_item_vendor_relation的值失败' || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      
      If(v_Item_Vendor_Relation = 'Y') Then
        --获取供应商以及财务仓ou
        Begin
          Select t.Vendor_Code, t.Finance_Operating_Id, t.Erp_Trancation
            Into v_Vendor_Code, v_Finance_Operating_Id, v_Erp_Trancation
            From t_Inv_Po_Headers t
           Where t.Po_Num = p_Po_Num
             And t.Entity_Id = p_Entity_Id;
        Exception
          When Others Then
            p_Result := p_Result || '获取供应商和财务仓ou报错' || v_Nl || '中转单号：' || p_Po_Num || v_Nl ||
                        Sqlerrm;
            Raise v_Base_Exception;
        End;
        
        If(v_Erp_Trancation = '07') Then
          Begin
            Select r_Vendor_Id, r_Vendor_Site_Id
              Into v_Vendor_Id, v_Vendor_Site_Id
              From Apps.Cux_Icp_Business_All@Mdims2mderp
             Where r_Vendor_Num = v_Vendor_Code
               And Supplier_System = 'GERP'
               And Requirement_System = 'GERP'
               And r_Org_Id = v_Finance_Operating_Id
               And Nvl(Disable_Date, Sysdate + 1) > Sysdate;
          Exception
            When Others Then
              p_Result := p_Result || '正向采购获取ERP中供应商ID以及供应商地点报错' || v_Nl || '供应商：' ||
                          v_Vendor_Code || v_Nl || '财务仓OU:' ||
                          v_Finance_Operating_Id || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
        Elsif(v_Erp_Trancation = '09') Then
          Begin
            Select r_Vendor_Id, r_Vendor_Site_Id
              Into v_Vendor_Id, v_Vendor_Site_Id
              From Apps.Cux_Icp_Business_All@Mdims2mderp
             Where s_Customer_Number = v_Vendor_Code
               And Supplier_System = 'GERP'
               And Requirement_System = 'GERP'
               And s_Org_Id = v_Finance_Operating_Id
               And Nvl(Disable_Date, Sysdate + 1) > Sysdate;
          Exception
            When Others Then
              p_Result := p_Result || '返向中转获取ERP中供应商ID以及供应商地点报错' || v_Nl || '供应商：' ||
                          v_Vendor_Code || v_Nl || '财务仓OU:' ||
                          v_Finance_Operating_Id || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
        End If;
        
        If(v_Erp_Trancation = '07') Then
          --获取中转单上没有对应批准供应商上的产品
          Begin
            Select Wm_Concat(b.Item_Code)
              Into v_Item_Code
              From Cims.t_Inv_Po_Headers             a,
                   Cims.t_Inv_Po_Lines               b,
                   Apps.Mtl_System_Items@Mdims2mderp Mi
             Where a.Po_Id = b.Po_Id
               And a.Po_Num = p_Po_Num
               And Mi.Must_Use_Approved_Vendor_Flag = 'Y'
               And Mi.Segment1 = b.Item_Code
               And a.Finance_Organization_Id = Mi.Organization_Id
               And Not Exists
             (Select 1
                      From Apps.Po_Approved_Supplier_List@Mdims2mderp m
                     Where m.Item_Id = Mi.Inventory_Item_Id
                       And Nvl(m.Disable_Flag, 'N') = 'N'
                       And m.Vendor_Id = v_Vendor_Id
                       And (m.Using_Organization_Id = -1 Or
                           m.Vendor_Site_Id = v_Vendor_Site_Id));
            If (v_Item_Code Is Not Null) Then
              p_Result := p_Result || '获取中转单上没有对应批准的有效供应商的产品：' || v_Item_Code || v_Nl ||
                          Sqlerrm;
              Raise v_Base_Exception;
            End If;
          Exception
            When Others Then
              p_Result := p_Result || '获取中转单上没有对应批准的有效供应商的产品失败' || v_Nl || '供应商：' ||
                          v_Vendor_Code || v_Nl || '财务仓OU:' ||
                          v_Finance_Operating_Id || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
        Elsif(v_Erp_Trancation = '09') Then
          --获取中转单上没有对应批准供应商上的产品
          Begin
            Select Wm_Concat(b.Item_Code)
              Into v_Item_Code
              From Cims.t_Inv_Po_Headers             a,
                   Cims.t_Inv_Po_Lines               b,
                   Apps.Mtl_System_Items@Mdims2mderp Mi
             Where a.Po_Id = b.Po_Id
               And a.Po_Num = p_Po_Num
               And Mi.Must_Use_Approved_Vendor_Flag = 'Y'
               And Mi.Segment1 = b.Item_Code
               And a.Vendor_Organization_Id = Mi.Organization_Id
               And Not Exists
             (Select 1
                      From Apps.Po_Approved_Supplier_List@Mdims2mderp m
                     Where m.Item_Id = Mi.Inventory_Item_Id
                       And Nvl(m.Disable_Flag, 'N') = 'N'
                       And m.Vendor_Id = v_Vendor_Id
                       And (m.Using_Organization_Id = -1 Or
                           m.Vendor_Site_Id = v_Vendor_Site_Id));
            If (v_Item_Code Is Not Null) Then
              p_Result := p_Result || '获取中转单上没有对应批准的有效供应商的产品：' || v_Item_Code || v_Nl ||
                          Sqlerrm;
              Raise v_Base_Exception;
            End If;
          Exception
            When Others Then
              p_Result := p_Result || '获取中转单上没有对应批准的有效供应商的产品失败' || v_Nl || '供应商：' ||
                          v_Vendor_Code || v_Nl || '财务仓OU:' ||
                          v_Finance_Operating_Id || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
        End If;
        
      End If;
      
      
    Exception
      When v_Base_Exception Then
        p_Result := '操作失败，' || p_Result;
      When Others Then
        p_Result := '操作失败' || v_Nl || Sqlerrm;
    End; */                               
   
 
 
  --------------------------------------------------------------------------
  --author:sushu
  --created:2017-04-24
  --purpose:CIMS-电商，生成调拨单
  --------------------------------------------------------------------------
  Procedure p_intf_ecm_inv_to_trsf(p_Intf_Head_Id   In Number,--接口头ID
                                   p_Trsf_Order_Num Out Varchar2,--返回调拨单号
                                   P_Result         Out varchar2) Is --返回结果
                                   
    Cursor c_Row_Get Is Select * From INTF_ECM_INV_TRSF_ORDER t Where t.intf_head_id = p_Intf_Head_Id;
    c_Row_info c_Row_Get%Rowtype;
    c_Bd_Item t_bd_item%Rowtype;
    c_Inv_Trsf_Order t_inv_trsf_order%Rowtype;
    v_Bill_Type_Id Number; --单据类型ID
    v_Bill_Type varchar2(40); --单据类型
    v_Sales_Center_Id Number; --营销中心ID
    v_Sales_Center_Code varchar2(100); --营销中心编码
    v_Sales_Center_Name varchar2(100); --营销中心名称
    v_Ship_Inv_Id Number; --发货仓库ID
    v_Ship_Inv_Code varchar2(100); --发货仓库编码
    v_Ship_Inv_Name varchar2(100); --发货仓库名称
    v_Traveling_Inv_Id Number; --在途仓ID
    v_Traveling_Inv_Code varchar2(100); --在途仓编码
    v_Traveling_Inv_Name varchar2(100); --在途仓名称
    v_Consignee_Inv_id Number; --收货仓ID
    v_Consignee_Inv_Code Varchar2(100); --收货仓库编码
    v_Consignee_Inv_Name varchar2(100); --收货仓库名称
    v_Ship_Organization_Id Number; --发货仓库组织
    v_Con_Organization_Id Number; --收货仓库组织
    v_Ship_Stock_Type varchar2(100); --发货仓库存货类型
    v_Con_Stock_Type varchar2(100); --收货仓库存货类型
    v_Count Number := 0;
    v_Trsf_Order_Id Number; --调拨单头ID
    v_Trsf_Order_line_Num Number; --调拨单行编号
    v_Trsf_Order_Line_Id Number; --调拨单行ID
    v_Sales_Main_Type varchar2(32 Byte); --产品大类
    v_Item_Start varchar2(2 Byte); --产品开头
    v_Trsf_Order_Number varchar2(240 Byte); --调拨单号
    v_If_Null Number :=0; --判断业务单据行是否为空
    v_Return_Flag Number; --库存是否返回成功与否的标识
    v_Return_Mes varchar2(2000 Byte); --库存是否返回信息
    v_Intf_Inv_Transaction_Id Number; --erp接口头ID
    v_Nosettled_Inventory_Id_Ship Number; --发货仓库对应的未结算仓ID
    v_Onway_Inventory_Id_Ship Number; --发货仓对应的在途仓ID
    v_Return_Inventory_Id_Ship Number; --发货仓对应的退货未结算仓ID
    v_Nosettled_Inventory_Id_Con Number; --收货仓库对应的未结算仓ID
    v_Onway_Inventory_Id_Con Number; --收货仓对应的在途仓ID
    v_Return_Inventory_Id_Con Number; --收货仓对应的退货未结算仓ID
    v_Docking_System_Ship varchar2(100 Byte); --发货仓库的对接系统
    v_Docking_System_Con varchar2(100 Byte); --收货仓库的对接系统
    V_CNT Number := 0;--临时变量
                                   
  
    Begin
      
      P_Result := v_Success;
      
      --参数验证是否为空
      If(p_Intf_Head_Id Is Null) Then
        P_Result := '无效参数，接口头ID不能为空';
        Raise v_Base_Exception;
      End If;
      
      --校验接口表信息是否存在
      Begin
        Open c_Row_Get;
        Fetch c_Row_Get Into c_Row_info;
        If c_Row_Get%Notfound Then
          P_Result := '获取接口信息失败，接口头ID：' || p_Intf_Head_Id;
          Raise v_Base_Exception;
        End If;
        Close c_Row_Get;
      Exception
        When Others Then
          P_Result := '获取接口信息失败：' || P_Result || v_Nl || Sqlerrm;
          Raise v_Base_Exception;
      End;
      
      For c_Row_Info In c_Row_Get Loop
        --根据来源单号校验是否重复生成调拨单，验重
        Begin
          Select Count(*)
            Into v_Count
            From t_Inv_Trsf_Order t
           Where t.Orig_Order_Num = c_Row_Info.Source_Num;
           If(v_Count > 0) Then
            Select t.trsf_order_num
              Into p_Trsf_Order_Num
              From t_Inv_Trsf_Order t
             Where t.Orig_Order_Num = c_Row_Info.Source_Num
               and rownum = 1;
            return;
           End If;
        Exception
          When v_Base_Exception Then
            P_Result := P_Result || v_Nl || Sqlerrm;
            Raise v_Base_Exception;
          When Others Then
            P_Result := '根据来源单号：' || c_Row_info.Source_Num || '查询已生成过的调拨单信息失败' || v_Nl || sqlerrm;
            Raise v_Base_Exception;
        End;
        --获取单据类型信息
        Begin
          Select Bill_Type_Id, Bill_Type_Code
            Into v_Bill_Type_Id, v_Bill_Type
            From t_Inv_Bill_Types
           Where Source_Type_Id In
                 (Select Source_Type_Id
                    From t_Inv_Source_Types
                   Where Source_Type_Code In ('1008'))
             And Entity_Id = c_Row_Info.Entity_Id
             And Cancel_Flag = 'N'
             And Sysdate Between Nvl(Begin_Date, Sysdate) And
                 Nvl(End_Date, Sysdate)
             And Bill_Period_Head_Id In
                 (Select t.Bill_Period_Head_Id
                    From t_Inv_Bill_Period_Line t
                   Where t.Transaction_Flag = 'Y'
                   Group By t.Bill_Period_Head_Id
                  Having Count(1) = 2);
        Exception
          When Others Then
            p_Result := '获取单据类型信息失败';
            Raise v_Base_Exception;
        End;
        --获取发货仓库信息
        Begin
          Select t.Inventory_Id,
                 t.Inventory_Code,
                 t.Inventory_Name,
                 t.Organization_Id,
                 t.stock_type,
                 ou.unit_id,
                 ou.code,
                 ou.name,
                 t.nosettled_inventory_id,
                 t.onway_inventory_id,
                 t.return_inventory_id,
                 t.docking_system
            Into v_Ship_Inv_Id,
                 v_Ship_Inv_Code,
                 v_Ship_Inv_Name,
                 v_Ship_Organization_Id,
                 v_Ship_Stock_Type,
                 v_Sales_Center_Id,
                 v_Sales_Center_Code,
                 v_Sales_Center_Name,
                 v_Nosettled_Inventory_Id_Ship,
                 v_Onway_Inventory_Id_Ship,
                 v_Return_Inventory_Id_Ship,
                 v_Docking_System_Ship
            From t_Inv_Inventories t, up_org_unit ou
           Where t.Inventory_Code = c_Row_Info.Ship_Inv_Code
             And t.Entity_Id = c_Row_Info.Entity_Id
             And t.begin_date < Sysdate
             And (t.end_date Is Null Or t.end_date > Sysdate)
             And t.unit_id = ou.unit_id
             And (ou.time_begin Is Null Or ou.time_begin < Sysdate)
             And (ou.time_end Is Null Or ou.time_end > Sysdate)
             And t.inventory_category = '01';
        Exception
          When Others Then
            P_Result := '获取发货仓库信息失败';
            Raise v_Base_Exception;
        End;
        --校验发货仓库对应的未结算、在途、退货未结算是否为空
        If(v_Nosettled_Inventory_Id_Ship Is Null Or v_Onway_Inventory_Id_Ship Is Null Or v_Return_Inventory_Id_Ship Is Null) Then
          P_Result := '发货仓库发货仓库对应的未结算、在途、退货未结算有为空';
          Raise v_Base_Exception;
        End If;

        --电商校验发货仓是否是ECM可操作
        select count(1) cnt into V_CNT 
          from cims.v_up_codelist t
         where t.CODETYPE = 'INV_TRSF_ORDER_ECM_INV_SELECT'
           and t.ENABLED = '0'
           and t.ENTITY_ID = c_Row_Info.Entity_Id
           and t.CODE_VALUE = v_Docking_System_Ship;

        If(V_CNT = 0 ) Then
          P_Result := '发货仓库物管主体['||v_Docking_System_Ship||']不属于ECM操作范围';
          Raise v_Base_Exception;
        End If;
        --获取收货仓库信息
        Begin
          Select t.Inventory_Id,
                 t.Inventory_Code,
                 t.Inventory_Name,
                 t.Organization_Id,
                 t.onway_inventory_id,
                 t.stock_type,
                 t.nosettled_inventory_id,
                 t.return_inventory_id,
                 t.docking_system
            Into v_Consignee_Inv_Id,
                 v_Consignee_Inv_Code,
                 v_Consignee_Inv_Name,
                 v_Con_Organization_Id,
                 v_Traveling_Inv_Id,
                 v_Con_Stock_Type,
                 v_Nosettled_Inventory_Id_Con,
                 v_Return_Inventory_Id_Con,
                 v_Docking_System_Con
            From t_Inv_Inventories t
           Where t.Inventory_Code = c_Row_Info.Consignee_Inv_Code
             And t.Entity_Id = c_Row_Info.Entity_Id
             And t.Begin_Date < Sysdate
             And (t.End_Date Is Null Or t.End_Date > Sysdate)
             And t.inventory_category = '01';
        Exception
          When Others Then
            P_Result := '获取收货仓库信息失败';
            Raise v_Base_Exception;
        End;
        --校验收货仓库对应的未结算、在途、退货未结算是否为空
        If(v_Nosettled_Inventory_Id_Con Is Null Or v_Traveling_Inv_Id Is Null Or v_Return_Inventory_Id_Con Is Null) Then
          P_Result := '收货仓库发货仓库对应的未结算、在途、退货未结算有为空';
          Raise v_Base_Exception;
        End If;
        --电商校验收货仓是否是电商仓
        /*
        If(c_Row_Info.Source_System = 'ECM' And v_Docking_System_Con <> 'ECM') Then
          P_Result := '收货仓库不是电商仓';
          Raise v_Base_Exception;
        End If;
        */
        --获取收货仓对应的在途仓信息
        Begin
          Select t.Inventory_Code, t.Inventory_Name
            Into v_Traveling_Inv_Code, v_Traveling_Inv_Name
            From t_Inv_Inventories t
           Where t.Inventory_Id = v_Traveling_Inv_Id
             And t.Begin_Date < Sysdate
             And (t.End_Date Is Null Or t.End_Date > Sysdate);
        Exception
          When Others Then
            P_Result := '获取收货仓对应的在途仓信息失败';
            Raise v_Base_Exception;
        End;
        --校验收发仓库组织是否相同
        If(v_Ship_Organization_Id <> v_Con_Organization_Id) Then
          P_Result := '发货仓库和收货仓库组织不同';
          Raise v_Base_Exception;
        End If;
        --校验收发仓库存货类型是否相同
        If(v_Ship_Stock_Type <> v_Con_Stock_Type) Then
          P_Result := '发货仓库和收货仓库存货类型不同';
          Raise v_Base_Exception;
        End If;
        
        --插入头
        Begin
          Select S_INV_TRSF_ORDER.Nextval Into v_Trsf_Order_Id From dual;
          Insert Into t_Inv_Trsf_Order
            (Trsf_Order_Id,
             Entity_Id,
             Trsf_Order_Num,
             Bill_Type_Id,
             Bill_Type,
             Trsf_Order_Status,
             Sales_Center_Id,
             Sales_Center_Code,
             Sales_Center_Name,
             Ship_Inv_Id,
             Ship_Inv_Code,
             Ship_Inv_Name,
             Traveling_Inv_Id,
             Traveling_Inv_Code,
             Traveling_Inv_Name,
             Consignee_Inv_Id,
             Consignee_Inv_Code,
             Consignee_Inv_Name,
             Orig_Order_Num,
             AUDIT_BY,
             AUDIT_DATE,
             Audit_Flag,
             Rcv_Flag,
             Created_By,
             Creation_Date,
             Last_Updated_By,
             Last_Update_Date,
             Remark,
             Close_Flag,
             SOURCE_SYSTEM,
             BILLED_DATE)
          Values
            (v_Trsf_Order_Id,
             c_Row_info.Entity_Id,
             '0',
             v_Bill_Type_Id,
             v_Bill_Type,
             '11',
             v_Sales_Center_Id,
             v_Sales_Center_Code,
             v_Sales_Center_Name,
             v_Ship_Inv_Id,
             v_Ship_Inv_Code,
             v_Ship_Inv_Name,
             v_Traveling_Inv_Id,
             v_Traveling_Inv_Code,
             v_Traveling_Inv_Name,
             v_Consignee_Inv_id,
             v_Consignee_Inv_Code,
             v_Consignee_Inv_Name,
             c_Row_info.Source_Num,
             'ECM',
             trunc(Sysdate),
             '1',
             '0',
             'ECM',
             Sysdate,
             'ECM',
             Sysdate,
             c_row_info.remark,
             'N',
             c_Row_info.Source_System,
             trunc(Sysdate));
        Exception
          When Others Then
            P_Result := '插入调拨头失败' || v_Nl || sqlerrm;
            Raise v_Base_Exception;
        End;
        --校验行信息
        For r_line In(Select * From intf_ecm_inv_trsf_order_line t Where t.intf_head_id = c_Row_info.Intf_Head_Id) Loop
          v_Count := v_Count + 1;
          Select s_inv_trsf_order_line_num.nextval Into v_Trsf_Order_line_Num From dual;
          --获取行信息
          Begin
            Select *
              Into c_Bd_Item
              From t_Bd_Item Bi
             Where Bi.Item_Code = r_Line.Item_Code
               And Bi.Entity_Id = c_Row_Info.Entity_Id
               And Bi.Active_Flag = 'Y'
               And Bi.Invstran_Flag = 'Y';
          Exception
            When Others Then
              p_Result := '根据产品编码' || r_Line.Item_Code || '获取产品信息失败' || v_Nl ||
                          Sqlerrm;
              Raise v_Base_Exception;
          End;
          --校验仓库类型和产品类型
          Begin
            Select substr(c_Bd_Item.Item_Code,0,1) Into v_Item_Start From dual;
            If(v_Ship_Stock_Type = '10' And v_Item_Start = 'T') Then
              P_Result := '成品仓库不能入推广物料产品';
              Raise v_Base_Exception;
            Elsif(v_Ship_Stock_Type ='11' And v_Item_Start <> 'T') Then
              P_Result := '推广物料的仓库不能入非推广物料产品';
              Raise v_Base_Exception;
            End If;
          Exception
            When Others Then
              P_Result := P_Result || '校验仓库类型和产品类型失败' || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
          --产品大类
          If(v_Count = 1) Then
            v_Sales_Main_Type := c_Bd_Item.Sales_Main_Type;
          Else
            If(v_Sales_Main_Type <> c_Bd_Item.Sales_Main_Type) Then
              P_Result := '产品营销大类不同' || v_Nl || sqlerrm;
              Raise v_Base_Exception;
            End If;
          End If;
         
         select count(1) cnt
           into V_CNT
           from cims.V_BD_MTL_SYSTEM_ITEMS_B t
          where t.organization_id = v_Ship_Organization_Id
            and t.item_code = c_Bd_Item.Item_Code;
           
          --校验ERP组织跟产品关系
          If V_CNT = 0 Then
            P_Result := 'ERP仓库组织ID['||v_Ship_Organization_Id||']不存在产品['||c_Bd_Item.Item_Code||']';
            Raise v_Base_Exception;
          End If;
        
          --保存行
          Select s_Inv_Trsf_Order_Line.Nextval Into v_Trsf_Order_Line_Id From dual;
          Begin
            Insert Into t_Inv_Trsf_Order_Line
              (Trsf_Order_Line_Id,
               Entity_Id,
               Trsf_Order_Id,
               Trsf_Order_Line_Num,
               Order_Line_Id_Orig,
               Item_Id,
               Item_Code,
               Item_Name,
               Uom,
               Billed_Qty,
               Created_By,
               Creation_Date,
               Last_Updated_By,
               Last_Update_Date)
            Values
              (v_Trsf_Order_Line_Id,
               c_Row_Info.Entity_Id,
               v_Trsf_Order_Id,
               v_Trsf_Order_Line_Num,
               r_Line.Source_Line_Id,
               c_Bd_Item.Item_Id,
               c_Bd_Item.Item_Code,
               c_Bd_Item.Item_Name,
               c_Bd_Item.Defaultunit,
               r_Line.Billed_Qty,
               'ECM',
               Sysdate,
               'ECM',
               Sysdate);
          Exception
            When Others Then
              p_Result := '插入行信息失败' || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
          --获取明细产品信息
          For r_detail In (Select Trunc(Nvl(c.Quantity, 0)) Sub_Qty, c.Item_Id, 
                          c.item_code, c.item_name, d.defaultunit
                          From t_Bd_Item                a,
                          t_Bd_Item_Assemblies     b,
                          t_Bd_Item_Assemblies_Sub c,
                          t_Bd_Item                d
                          Where a.Item_Id = c_Bd_Item.Item_Id
                          And a.Entity_Id = c_Row_info.Entity_Id
                          And a.Item_Id = b.Item_Id
                          And b.Entity_Id = c_Row_info.Entity_Id
                          And Trunc(Sysdate) Between Trunc(Nvl(b.Begin_Date, Sysdate + 1)) And
                             Trunc(Nvl(b.End_Date, Sysdate + 1))
                          And b.Item_Assembly_Id = c.Item_Assembly_Id
                          And c.Entity_Id = c_Row_info.Entity_Id
                          And Trunc(Sysdate) Between Trunc(Nvl(c.Begin_Date, Sysdate + 1)) And
                             Trunc(Nvl(c.End_Date, Sysdate + 1))
                          And Trunc(Nvl(c.Quantity, 0)) >= 1
                          And c.Item_Id = d.Item_Id
                          And d.Entity_Id = c_Row_info.Entity_Id
                          Union All
                          Select 1 Sub_Qty, e.Item_Id, e.item_code, e.item_name, e.defaultunit
                          From t_Bd_Item e
                          Where e.Item_Id = c_Bd_Item.Item_Id
                          And e.Entity_Id = c_Row_info.Entity_Id
                          And Not Exists
                          (Select 1
                                From t_Bd_Item_Assemblies Ia
                               Where Ia.Item_Id = e.Item_Id
                                 And Ia.Entity_Id = c_Row_info.Entity_Id
                                 And Trunc(Sysdate) Between Trunc(Nvl(Ia.Begin_Date, Sysdate + 1)) And
                                     Trunc(Nvl(Ia.End_Date, Sysdate + 1)))) Loop
            --保存明细
            Begin
              Insert Into t_Inv_Trsf_Order_Line_Detail
                (Trsf_Order_Line_Detail_Id,
                 Trsf_Order_Line_Id,
                 Entity_Id,
                 Item_Id,
                 Item_Code,
                 Item_Name,
                 Uom_Code,
                 Billed_Qty,
                 Created_By,
                 Creation_Date,
                 Last_Updated_By,
                 Last_Update_Date,
                 Trsf_Order_Id)
              Values
                (s_Inv_Trsf_Order_Line_Detail.Nextval,
                 v_Trsf_Order_Line_Id,
                 c_Row_Info.Entity_Id,
                 r_Detail.Item_Id,
                 r_Detail.Item_Code,
                 r_Detail.Item_Name,
                 r_Detail.Defaultunit,
                 r_Detail.Sub_Qty * r_Line.Billed_Qty,
                 'ECM',
                 Sysdate,
                 'ECM',
                 Sysdate,
                 v_Trsf_Order_Id);
            Exception
              When Others Then
                P_Result := '插入明细行失败' || v_Nl || sqlerrm;
                Raise v_Base_Exception;
            End;

          End Loop;
          
        End Loop;
        
        --更新调拨单单据编号、产品大类信息
        If(P_Result = v_Success) Then
          Begin
            v_Trsf_Order_Number := Pkg_Bd.f_Get_Bill_No('invTrsfOrderNum',
                                                         Null,
                                                         c_Row_info.Entity_Id,
                                                         Null);
          Exception
            When Others Then
              P_Result := '获取调拨单号生成失败' || v_Nl || sqlerrm;
              Raise v_Base_Exception;
          End;
          Update t_Inv_Trsf_Order t
             Set t.Trsf_Order_Num  = v_Trsf_Order_Number,
                 t.Sales_Main_Type = v_Sales_Main_Type
           Where t.Trsf_Order_Id = v_Trsf_Order_Id;
        End If;
        --调拨库存事务
        Begin
          Select *
            Into c_Inv_Trsf_Order
            From t_Inv_Trsf_Order t
           Where t.Trsf_Order_Id = v_Trsf_Order_Id;
        Exception
          When Others Then
            P_Result := '获取不到已生成的调拨单信息';
            Raise v_Base_Exception;
        End;
        --判断业务单据行是否为空
        Begin
          Select Count(1)
            Into v_Count
            From t_Inv_Trsf_Order_Line t
           Where t.Trsf_Order_Id = v_Trsf_Order_Id;
           If(v_count = 0) Then
             v_If_Null := 1;
           End If;
        Exception
          When Others Then
            P_Result := '获取生成的业务单据行信息失败';
            Raise v_Base_Exception;
        End;
        Begin
          pkg_inv_transaction.inv_transaction_total_deal(in_entity_id          => c_Inv_Trsf_Order.Entity_Id,--主体
                                                         in_bill_type_id       => c_Inv_Trsf_Order.Bill_Type_Id,--单据类型ID
                                                         is_business_state     => c_Inv_Trsf_Order.Trsf_Order_Status,--状态
                                                         id_transaction_date   => c_Inv_Trsf_Order.Billed_Date,--单据日期
                                                         in_business_header_id => c_Inv_Trsf_Order.Trsf_Order_Id,--单据头ID
                                                         in_if_null            => v_If_Null,--业务单据是否有行
                                                         is_bill_kind          => 'B2',--调拨
                                                         on_flag               => v_Return_Flag,--返回成功标识(<0都是失败)
                                                         os_prompt             => v_Return_Mes--返回信息
                                                         );
          If(v_Return_Flag < 0) Then
            P_Result := v_Return_Mes;
            Raise v_Base_Exception;
          Else
            --特殊库存占用
            pkg_pln_shares.p_Transfer_To_Shipment(p_Transfer_Head_Id => c_Inv_Trsf_Order.Trsf_Order_Id,--调拨头ID
                                                  p_Operation_Type   => 'AUDITING',--操作类型
                                                  p_Entity_Id        => c_Inv_Trsf_Order.Entity_Id,--主体
                                                  p_User_Code        => c_Inv_Trsf_Order.Created_By,
                                                  p_Result           => v_Return_Mes
                                                  );
            If(v_Return_Mes <> 'SUCCESS') Then
              P_Result := v_Return_Mes;
              Raise v_Base_Exception;
            End If;
          End If;
        Exception
          When Others Then
            P_Result := '调用库存事务失败：' || P_Result || v_Nl || sqlerrm;
            Raise v_Base_Exception;
        End;
        
        --插入erp接口表
        --获取明细行信息
        Begin
          Select Count(*)
            Into v_Count
            From t_Inv_Trsf_Order_Line_Detail t
           Where t.Trsf_Order_Id = v_Trsf_Order_Id;
        Exception
          When Others Then
            P_Result := '获取生成的业务单据明细行信息失败';
            Raise v_Base_Exception;
        End;
        If(v_Count > 0) Then
          --插入头表
          Select S_INTF_INV_TRANSACTION_HEAD.Nextval Into v_Intf_Inv_Transaction_Id From dual;
          Begin
            Insert Into INTF_INV_TRANSACTION_HEAD
              (ID,
               INTERFACE_NUM,
               ORDER_NUM,
               SOURCE_ORDER_TYPE,
               STATUS,
               ENTITY_ID,
               SUBINVENTORY
               )
             Values
               (v_Intf_Inv_Transaction_Id,
                'ERP-IMS-023',
                v_Trsf_Order_Number,
                '调拨子库转移',
                'N',
                c_Inv_Trsf_Order.Entity_Id,
                c_Inv_Trsf_Order.Ship_Inv_Code
                );
          Exception
            When Others Then
              P_Result := '插入erp接口头表失败' || v_Nl || Sqlerrm;
              Raise v_Base_Exception;
          End;
          --插入接口行表
          For r_detail In (Select * From t_inv_trsf_order_line_detail t Where t.trsf_order_id = v_Trsf_Order_Id) Loop
            Begin
              Insert Into INTF_INV_TRANSACTION
                (ID,
                 SUBINVENTORY,
                 TRANSFER_SUBINVENTORY,
                 TRANSACTION_DATE,
                 ORGANIZATION_CODE,
                 ITEM_NUMBER,
                 TRANSACTION_QUANTITY,
                 TRANSACTION_UOM,
                 TRANSACTION_TYPE,
                 ESB_DATA_SOURCE,
                 STATUS,
                 SOURCE_NUM,
                 HEADER_ID
                 )
               Select S_INTF_GERP_CIMS_TRANSACTION.Nextval,
                      c_Inv_Trsf_Order.Ship_Inv_Code,
                      c_Inv_Trsf_Order.Traveling_Inv_Code,
                      c_Inv_Trsf_Order.Audit_Date,
                      ii.organization_code,
                      r_detail.item_code,
                      r_detail.billed_qty,
                      r_detail.uom_code,
                      '2',
                      'ERP-IMS-023',
                      'N',
                      v_Trsf_Order_Number,
                      v_Intf_Inv_Transaction_Id
               From t_inv_inventories ii Where ii.inventory_id = c_Inv_Trsf_Order.Ship_Inv_Id;
            Exception
              When Others Then
                P_Result := '插入erp接口行失败' || v_Nl || Sqlerrm;
                Raise v_Base_Exception;
            End;
          End Loop;
        End If;
        
        --返回调拨单号
        If(P_Result = v_Success) Then
          p_Trsf_Order_Num := v_Trsf_Order_Number;
        End If;
        
        --更新接口表信息
        If(P_Result = v_Success) Then
          Begin
            Update Intf_Ecm_Inv_Trsf_Order t
               Set t.Responsetype    = 'S',
                   t.Responsemessage = t.Responsemessage ||
                                       v_Trsf_Order_Number
             Where t.Intf_Head_Id = p_Intf_Head_Id;
          Exception
            When Others Then
              P_Result := '更新接口表信息失败';
              Raise v_Base_Exception;
          End;
        End If;
        
        --提交
        If(P_Result = v_Success) Then
          Commit;
        Else
          Rollback;
        End If;
       
        
      End Loop;
      


      
    Exception
      When v_Base_Exception Then
        Rollback;
        P_Result := '调拨单生成失败：' || P_Result;
        --更新接口表
        Update Intf_Ecm_Inv_Trsf_Order t
           Set t.Responsetype    = 'E',
               t.Respnosecode    = '000004',
               t.Responsemessage = p_Result,
               t.Operstatus      = '1'
         Where t.Intf_Head_Id = p_Intf_Head_Id;
        Commit;
      When Others Then
        Rollback;
        P_Result := substr('异常:'||Sqlerrm,0,240);
        --更新接口表
        Update Intf_Ecm_Inv_Trsf_Order t
           Set t.Responsetype    = 'E',
               t.Respnosecode    = '000004',
               t.Responsemessage = p_Result,
               t.Operstatus      = '1'
         Where t.Intf_Head_Id = p_Intf_Head_Id;
        Commit;
    End;



End;
/

