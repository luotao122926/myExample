create view V_LG_TRAN_CONTRACT_LINE as
select
CONTRACT_LINE_ID,
CONTRACT_ID,
SALES_MAIN_TYPE,
SALES_ORDER_TYPE_ID,
SO_DOC_ID,
SO_DOC_NUM,
ITEM_CODE,
ITEM_NAME,
ITEM_UOM,
ITEM_PRICE,
UNIT_VOLUME,
UNIT_WEIGHT,
TOTAL_VOLUME,
TOTAL_WEIGHT,
FREIGHT,
FACT_SHIP_QTY,
FACT_RECEIVE_QTY,
AFFIRM_QTY,
SHATTER_QTY,
DIFF_QTY,
MOULD_QTY,
OUT_LINE_QTY,
PACK_SHATTER_QTY,
DIFF_REASON,
CREATED_BY,
CREATION_DATE,
LAST_UPDATED_BY,
LAST_UPDATE_DATE,
REMARK,
BREAK_CLAIMANT_AMOUNT,
DAMAGE_CLAIMANT_AMOUNT
from t_lg_contract_line
with read only
/

comment on table V_LG_TRAN_CONTRACT_LINE is '运输合同行'
/

comment on column V_LG_TRAN_CONTRACT_LINE.CONTRACT_LINE_ID is '运输合同行ID'
/

comment on column V_LG_TRAN_CONTRACT_LINE.CONTRACT_ID is '运输合同ID'
/

comment on column V_LG_TRAN_CONTRACT_LINE.SALES_MAIN_TYPE is '营销大类'
/

comment on column V_LG_TRAN_CONTRACT_LINE.SALES_ORDER_TYPE_ID is '销售单据类型ID'
/

comment on column V_LG_TRAN_CONTRACT_LINE.SO_DOC_ID is '财务单ID'
/

comment on column V_LG_TRAN_CONTRACT_LINE.SO_DOC_NUM is '财务单号'
/

comment on column V_LG_TRAN_CONTRACT_LINE.ITEM_CODE is '产品编码'
/

comment on column V_LG_TRAN_CONTRACT_LINE.ITEM_NAME is '产品名称'
/

comment on column V_LG_TRAN_CONTRACT_LINE.ITEM_UOM is '产品单位'
/

comment on column V_LG_TRAN_CONTRACT_LINE.ITEM_PRICE is '产品价格'
/

comment on column V_LG_TRAN_CONTRACT_LINE.UNIT_VOLUME is '单位体积'
/

comment on column V_LG_TRAN_CONTRACT_LINE.UNIT_WEIGHT is '单位重量'
/

comment on column V_LG_TRAN_CONTRACT_LINE.TOTAL_VOLUME is '总体积'
/

comment on column V_LG_TRAN_CONTRACT_LINE.TOTAL_WEIGHT is '总重量'
/

comment on column V_LG_TRAN_CONTRACT_LINE.FREIGHT is '运费'
/

comment on column V_LG_TRAN_CONTRACT_LINE.FACT_SHIP_QTY is '实发数量'
/

comment on column V_LG_TRAN_CONTRACT_LINE.FACT_RECEIVE_QTY is '实收数量'
/

comment on column V_LG_TRAN_CONTRACT_LINE.AFFIRM_QTY is '确认数量'
/

comment on column V_LG_TRAN_CONTRACT_LINE.SHATTER_QTY is '损坏数量'
/

comment on column V_LG_TRAN_CONTRACT_LINE.DIFF_QTY is '差异数量'
/

comment on column V_LG_TRAN_CONTRACT_LINE.MOULD_QTY is '霉变污染'
/

comment on column V_LG_TRAN_CONTRACT_LINE.OUT_LINE_QTY is '违规堆放'
/

comment on column V_LG_TRAN_CONTRACT_LINE.PACK_SHATTER_QTY is '包装破损'
/

comment on column V_LG_TRAN_CONTRACT_LINE.DIFF_REASON is '差异原因'
/

comment on column V_LG_TRAN_CONTRACT_LINE.REMARK is '备注'
/

