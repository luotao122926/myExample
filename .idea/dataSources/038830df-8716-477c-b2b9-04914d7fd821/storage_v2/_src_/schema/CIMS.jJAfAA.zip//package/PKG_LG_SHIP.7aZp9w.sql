create PACKAGE PKG_LG_SHIP IS

  V_ORG_ITEM_RELATION_CHECK_FLAG CONSTANT VARCHAR2(32) := 'BD_ITEM_ORG_RELATION_CHECK_FLAG'; --产品、组织关系校验
  
  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-08-02
  -- PURPOSE : 生成发货计划（原手工分配承运商处理方式）
  ----------------------------------------------------------------------
  PROCEDURE P_LG_GENERATION_SHIP_PLAN_OLD(I_SHIP_PLAN_ID IN NUMBER, --发货计划接口表ID
                                          I_OPER_NAME    IN VARCHAR2, --登录账号
                                          O_RESULT       OUT VARCHAR2, --返回错误码
                                          O_RESULT_MSG   OUT VARCHAR2, --返回错误信息
                                          O_SHIP_DOC_ID  OUT NUMBER --发货通知单ID
                                          );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-03-17
  -- PURPOSE : 生成发货计划（自动分配处理方式）
  ----------------------------------------------------------------------
  PROCEDURE P_LG_GENERATION_SHIP_PLAN(I_SHIP_PLAN_ID IN NUMBER, --发货计划接口表ID
                                      I_OPER_NAME    IN VARCHAR2, --登录账号
                                      O_RESULT       OUT VARCHAR2, --返回错误码
                                      O_RESULT_MSG   OUT VARCHAR2, --返回错误信息
                                      O_SHIP_PLAN_ID OUT NUMBER, --发货通知单ID
                                      O_VENDOR_CODE  OUT VARCHAR2 --供应商编码
                                      );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-08-02
  -- PURPOSE : 生成发货通知单
  ----------------------------------------------------------------------
  PROCEDURE P_LG_GENERATION_SHIP_DOC_OLD(I_BATCH_DEAL_NUM IN NUMBER,
                                         I_ENTITY_ID      IN NUMBER,
                                         I_OPER_NAME      IN VARCHAR2,
                                         O_RESULT         OUT VARCHAR2,
                                         O_RESULT_MSG     OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2014-08-04
  -- PURPOSE : 生成发货通知单
  ----------------------------------------------------------------------
  PROCEDURE P_LG_GENERATION_SHIP_DOC(I_SHIP_PLAN_IDS IN VARCHAR2, --发货计划集合
                                     I_ENTITY_ID     IN NUMBER, --主体ID
                                     I_OPER_NAME     IN VARCHAR2, --登录账号
                                     O_RESULT        OUT VARCHAR2, --返回错误码
                                     O_RESULT_MSG    OUT VARCHAR2, --返回错误信息
                                     O_BATCH_NUM     OUT NUMBER, --发货通知单批处理编号
                                     O_SHIP_DOC_NUM  OUT VARCHAR2 --发货通知单号
                                     );

  ----------------------------------------------------------------------
  -- AUTHOR  : XUQF
  -- CREATED : 2015-01-15
  -- PURPOSE : 冲销发货通知单
  ----------------------------------------------------------------------
  PROCEDURE P_LG_WRITE_OFF_SHIP_DOC(I_SO_NUM     IN VARCHAR2, --销售单号
                                    I_BILL_TYPE  IN VARCHAR2, --单据类型 00销售 01调拨
                                    I_ACCOUNT    IN VARCHAR2, --登录账号
                                    O_RESULT     OUT VARCHAR2,
                                    O_RESULT_MSG OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- AUTHOR  : 杨福伟
  -- CREATED : 2016-09-07
  -- PURPOSE : 齐套号需求：获取可发货通知单
  ----------------------------------------------------------------------
  PROCEDURE P_LG_GET_SHIPING_DOC(I_SHIP_DOC_ID     IN number,
                                 I_ENTITY_ID   IN  number,
                                 O_RESULT     OUT VARCHAR2,
                                 O_RESULT_MSG OUT VARCHAR2);


  ----------------------------------------------------------------------
  -- AUTHOR  : LILIAN
  -- CREATED : 2014-12-20
  -- PURPOSE : 获取线路
  ----------------------------------------------------------------------
  FUNCTION F_GET_TRANSPORT_LINE(in_ENTITY_ID               number,
                                in_SHIP_TO_LOCATION_CODE   varchar2,
                                in_CONSIGNEE_LOCATION_CODE varchar2)
    return number;

  ----------------------------------------------------------------------
  -- AUTHOR  : yangfw
  -- CREATED : 2015-05-25
  -- PURPOSE : 获取线路
  ----------------------------------------------------------------------
  FUNCTION F_GET_TRANSPORT_LINE_NEW(in_ENTITY_ID               number,
                                in_SHIP_TO_LOCATION_CODE   varchar2,
                                in_CONSIGNEE_LOCATION_CODE varchar2,
                                in_SHIP_WAY varchar2,
                                in_SHIP_TYPE varchar2,
                                in_LOAD_VEHICLE_TYPE varchar2)
    return number;
   ----------------------------------------------------------------------
  -- AUTHOR  : 吴林
  -- CREATED : 2015-06-02
  -- PURPOSE : 汇总订单备注
  ----------------------------------------------------------------------
  FUNCTION F_GET_ORDER_HEAD_REMARK(in_order_head_remarks VARCHAR2,
                                    in_now_order_head_remarks VARCHAR2)
  return VARCHAR2;

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-09-18
  *     创建者：周建刚
  *   功能说明：校验中心默认OU是否存在于客户有效OU清单中。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_LG_CUST_CENTER_OU_CHECK(V_LG_SHIP_PLAN         IN T_LG_SHIP_PLAN%ROWTYPE,    --营销中心
                                      P_RESULT               OUT NUMBER,     --返回错误ID
                                      P_ERR_MSG              OUT VARCHAR2    --返回错误信息
                                      );
END PKG_LG_SHIP;
/

