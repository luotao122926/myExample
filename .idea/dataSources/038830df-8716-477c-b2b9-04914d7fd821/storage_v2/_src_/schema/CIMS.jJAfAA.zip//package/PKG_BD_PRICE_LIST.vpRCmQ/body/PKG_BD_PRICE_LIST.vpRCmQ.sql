create PACKAGE BODY      PKG_BD_PRICE_LIST IS

  -----------------------------------------------------------------------------
  --  停用价格列表行      --add by liangym2
  -----------------------------------------------------------------------------
  PROCEDURE STOP_PRICE_LINE(IN_ENTITY_ID        IN NUMBER
                           ,IN_PRICE_LIST_ID    IN NUMBER
                           ,IN_ITEM_ID          IN NUMBER
                           ,IS_CHANNEL_ATTR     IN VARCHAR2
                           ,ID_STOP_DATE        IN DATE
                           ,IN_ADJUST_SRC_ID    IN NUMBER
                           ,IN_ADJUST_LINE_ID   IN NUMBER
                           ,IN_ADJUST_SRC_NUM   IN VARCHAR2
                           ,IS_LAST_UPDATE_BY   IN VARCHAR2
                           ,ID_LAST_UPDATE_DATE IN DATE
                           ,OS_MESSAGE          OUT VARCHAR2 --返回提示信息
                            ) IS
  BEGIN
    BEGIN
      MERGE INTO T_BD_PRICE_LINE U
      USING (SELECT DENSE_RANK() OVER(PARTITION BY L.PRICE_LIST_ID, L.ITEM_ID, L.CHANNEL_ATTR ORDER BY L.BEGIN_DATE DESC) AS RK,
                    GREATEST(ID_STOP_DATE, TRUNC(SYSDATE)-1) AS STOP_DATE,
                    L.PRICE_LINE_ID
               FROM T_BD_PRICE_LINE L
              WHERE L.PRICE_LIST_ID = IN_PRICE_LIST_ID
                AND L.ITEM_ID = IN_ITEM_ID
                AND L.ENTITY_ID = IN_ENTITY_ID
                AND (L.CHANNEL_ATTR = IS_CHANNEL_ATTR OR
                    (L.CHANNEL_ATTR IS NULL AND IS_CHANNEL_ATTR IS NULL))
                AND 'Y' = L.ACTIVE_FLAG
                AND (L.END_DATE IS NULL OR L.END_DATE >= TRUNC(SYSDATE))
              ORDER BY L.BEGIN_DATE) UT
      ON (U.PRICE_LINE_ID = UT.PRICE_LINE_ID)
      WHEN MATCHED THEN
        UPDATE
           SET U.LAST_UPDATED_BY  = IS_LAST_UPDATE_BY
              ,U.LAST_UPDATE_DATE = ID_LAST_UPDATE_DATE
              ,U.END_DATE = (CASE
                              WHEN (UT.STOP_DATE IS NULL) THEN
                               U.END_DATE
                              WHEN (SYSDATE >= U.BEGIN_DATE AND
                                   UT.STOP_DATE >= U.END_DATE) THEN
                               U.END_DATE
                              WHEN (SYSDATE >= U.BEGIN_DATE AND
                                   (U.END_DATE IS NULL OR
                                   UT.STOP_DATE < U.END_DATE)) THEN
                               UT.STOP_DATE
                              WHEN (SYSDATE < U.BEGIN_DATE AND
                                   UT.STOP_DATE < U.BEGIN_DATE) THEN
                               U.END_DATE
                              WHEN (SYSDATE < U.BEGIN_DATE AND
                                   UT.STOP_DATE >= U.BEGIN_DATE AND
                                   UT.STOP_DATE >= U.END_DATE) THEN
                               U.END_DATE
                              WHEN (SYSDATE < U.BEGIN_DATE AND
                                   UT.STOP_DATE >= U.BEGIN_DATE AND
                                   (U.END_DATE IS NULL OR
                                   UT.STOP_DATE < U.END_DATE)) THEN
                               UT.STOP_DATE
                              ELSE
                               U.END_DATE
                            END)
              ,U.ACTIVE_FLAG = (CASE
                                 WHEN (UT.STOP_DATE IS NULL) THEN
                                  'N'
                                 WHEN (SYSDATE >= U.BEGIN_DATE AND
                                      UT.STOP_DATE >= U.END_DATE) THEN
                                  U.ACTIVE_FLAG
                                 WHEN (SYSDATE >= U.BEGIN_DATE AND
                                      (U.END_DATE IS NULL OR
                                      UT.STOP_DATE < U.END_DATE)) THEN
                                  U.ACTIVE_FLAG
                                 WHEN (SYSDATE < U.BEGIN_DATE AND
                                      UT.STOP_DATE < U.BEGIN_DATE) THEN
                                  'N'
                                 WHEN (SYSDATE < U.BEGIN_DATE AND
                                      UT.STOP_DATE >= U.BEGIN_DATE AND
                                      UT.STOP_DATE >= U.END_DATE) THEN
                                  U.ACTIVE_FLAG
                                 WHEN (SYSDATE < U.BEGIN_DATE AND
                                      UT.STOP_DATE >= U.BEGIN_DATE AND
                                      (U.END_DATE IS NULL OR
                                      UT.STOP_DATE < U.END_DATE)) THEN
                                  U.ACTIVE_FLAG
                                 ELSE
                                  U.ACTIVE_FLAG
                               END)
              ,U.ADJUST_LIST_ID = (CASE
                                    WHEN (UT.STOP_DATE IS NULL) THEN
                                     DECODE(U.ADJUST_LIST_ID,
                                            NULL,
                                            IN_ADJUST_SRC_ID,
                                            U.ADJUST_LIST_ID)
                                    WHEN (SYSDATE >= U.BEGIN_DATE AND
                                         (U.END_DATE IS NULL OR
                                         UT.STOP_DATE < U.END_DATE)) THEN
                                     IN_ADJUST_SRC_ID
                                    WHEN (SYSDATE < U.BEGIN_DATE AND
                                         UT.STOP_DATE >= U.BEGIN_DATE AND
                                         (U.END_DATE IS NULL OR
                                         UT.STOP_DATE < U.END_DATE)) THEN
                                     IN_ADJUST_SRC_ID
                                    ELSE
                                     DECODE(U.ADJUST_LIST_ID,
                                            NULL,
                                            IN_ADJUST_SRC_ID,
                                            U.ADJUST_LIST_ID)
                                  END)
              ,U.MODIFY_LIST_NUM = (CASE
                                     WHEN (UT.STOP_DATE IS NULL) THEN
                                      DECODE(U.MODIFY_LIST_NUM,
                                             NULL,
                                             IN_ADJUST_SRC_NUM,
                                             U.MODIFY_LIST_NUM)
                                     WHEN (SYSDATE >= U.BEGIN_DATE AND
                                          (U.END_DATE IS NULL OR
                                          UT.STOP_DATE < U.END_DATE)) THEN
                                      IN_ADJUST_SRC_NUM
                                     WHEN (SYSDATE < U.BEGIN_DATE AND
                                          UT.STOP_DATE >= U.BEGIN_DATE AND
                                          (U.END_DATE IS NULL OR
                                          UT.STOP_DATE < U.END_DATE)) THEN
                                      IN_ADJUST_SRC_NUM
                                     ELSE
                                      DECODE(U.MODIFY_LIST_NUM,
                                             NULL,
                                             IN_ADJUST_SRC_NUM,
                                             U.MODIFY_LIST_NUM)
                                   END);
      OS_MESSAGE := 'SUCCESS';
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        OS_MESSAGE := '停用价格列表行发生异常：' || ',' || IN_PRICE_LIST_ID || ',' ||
                      IN_ITEM_ID || ',' || IS_CHANNEL_ATTR || ',' ||
                      IN_ADJUST_SRC_ID || ',' || IN_ADJUST_SRC_NUM || ',' ||
                      IN_ADJUST_LINE_ID || '[SQLCODE：' || SQLCODE ||
                      '，MSG：' || SQLERRM || ']';
    END;
  END;

  -----------------------------------------------------------------------------
  --  多价格列表批量调整通过检查 锁表       --add by liangym2
  -----------------------------------------------------------------------------
  PROCEDURE MULTI_PRICE_MODIFY_CHECK(IN_ENTITY_ID      IN NUMBER
                                    ,IN_MODIFY_LIST_ID IN NUMBER
                                    ,IS_MESSAGE        IN VARCHAR2
                                    ,OS_MESSAGE        OUT VARCHAR2 --返回提示信息
                                     ) IS
    CURSOR C_LOCK IS
      SELECT 1
        FROM T_BD_PRICE_LIST L
       WHERE EXISTS (SELECT 1
                FROM T_BD_MULTI_PRICE_MODIFY_DETAIL D
               WHERE D.MODIFY_LIST_ID = IN_MODIFY_LIST_ID
                 AND D.LIST_ID = L.PRICE_LIST_ID)
         FOR UPDATE NOWAIT;
    CURSOR C_LOCK_L IS
      SELECT 1
        FROM T_BD_PRICE_LINE L
       WHERE EXISTS
       (SELECT 1
                FROM T_BD_MULTI_PRICE_MODIFY_DETAIL D
               WHERE D.MODIFY_LIST_ID = IN_MODIFY_LIST_ID
                 AND D.LIST_ID = L.PRICE_LIST_ID
                 AND L.ITEM_ID = D.ITEM_ID
                 AND (L.CHANNEL_ATTR = D.CHANNEL_ATTR OR
                     (L.CHANNEL_ATTR IS NULL AND D.CHANNEL_ATTR IS NULL)))
         AND L.PRICE_LIST_ID IN
             (SELECT D.LIST_ID
                FROM T_BD_MULTI_PRICE_MODIFY_DETAIL D
               WHERE D.MODIFY_LIST_ID = IN_MODIFY_LIST_ID)
         AND L.ACTIVE_FLAG = 'Y'
         AND L.UQ_CHECK_FLAG = 0
         FOR UPDATE NOWAIT;
  BEGIN
    BEGIN
      OPEN C_LOCK;
      CLOSE C_LOCK;
      ROLLBACK;
      OPEN C_LOCK_L;
      CLOSE C_LOCK_L;
      ROLLBACK;
      OS_MESSAGE := 'SUCCESS';
    EXCEPTION
      WHEN OTHERS THEN
        IF SQLCODE = -30006 OR SQLCODE = -54 THEN
          OS_MESSAGE := IS_MESSAGE;
          IF OS_MESSAGE IS NULL THEN
            OS_MESSAGE := SQLERRM;
          END IF;
        END IF;
    END;
  END MULTI_PRICE_MODIFY_CHECK;
  
  -----------------------------------------------------------------------------
  --  价格列表通过回写其他接口表       --add by liangym2
  --如果处理内部结算价、推广物料采购价 并成功 返回 空值
  --否则不处理内部结算价、推广物料采购价的话，返回SUCCESS
  -----------------------------------------------------------------------------
  PROCEDURE PRICE_SUCCESS_WRITE(IN_ENTITY_ID      IN NUMBER
                               ,IN_LIST_ID        IN NUMBER
                               ,IN_ADJUST_LIST_ID IN NUMBER
                               ,IS_MODIFY_SOURCE  IN VARCHAR2
                               ,IS_LAST_UPDATE_BY IN VARCHAR2
                               ,OS_MESSAGE        OUT VARCHAR2 --返回提示信息
                                ) IS
    VN_COUNT NUMBER;
    VN_OUT_ADJ_ID	NUMBER;
    VS_PRE01 VARCHAR2(100);
    VS_PRE02 VARCHAR2(100);
    VS_PRE03 VARCHAR2(100);
    VS_PRE04 VARCHAR2(100);
    VS_PRE05 VARCHAR2(100);
    VS_PRE06 VARCHAR2(100);
    VR_PRICE_LIST T_BD_PRICE_LIST%ROWTYPE;
    VT_CREATED_BY T_BD_PRICE_LIST.CREATED_BY%TYPE;
  BEGIN
    IF 0 < IN_LIST_ID AND IS_MODIFY_SOURCE IS NULL THEN
      SELECT *
        INTO VR_PRICE_LIST
        FROM T_BD_PRICE_LIST
       WHERE PRICE_LIST_ID = IN_LIST_ID;
      VT_CREATED_BY := VR_PRICE_LIST.CREATED_BY;
      
      UPDATE T_BD_PRICE_LIST M
         SET M.CREATED_BY = '-30'
       WHERE M.PRICE_LIST_ID = IN_LIST_ID
         AND '30' <> M.DOC_STATUS;
      
      FOR LI IN (SELECT *
                   FROM T_BD_PRICE_LINE
                  WHERE PRICE_LIST_ID = IN_LIST_ID
                  ORDER BY ITEM_ID)
      LOOP
        --向产品新增定价接口表intf_bd_item_make_price插数据
        SELECT COUNT(0)
          INTO VN_COUNT
          FROM INTF_BD_ITEM_MAKE_PRICE M
         WHERE M.ITEM_CODE = LI.ITEM_CODE;
        IF 0 = VN_COUNT THEN
          INSERT INTO INTF_BD_ITEM_MAKE_PRICE
            (MAKE_PRICE_ID,
             PRICE_LIST_ID,
             ITEM_ID,
             ITEM_CODE,
             ITEM_NAME,
             CREATED_BY,
             CREATION_DATE,
             INTF_STATUS)
            SELECT SEQ_BD_ROW_ID.NEXTVAL,
                   LI.PRICE_LIST_ID,
                   LI.ITEM_ID,
                   LI.ITEM_CODE,
                   LI.ITEM_NAME,
                   'program',
                   SYSDATE,
                   'N'
              FROM DUAL
             WHERE NOT EXISTS (SELECT 1
                      FROM INTF_BD_ITEM_MAKE_PRICE M
                     WHERE M.ITEM_CODE = LI.ITEM_CODE);
        END IF;
      END LOOP;
      
      UPDATE T_BD_PRICE_LIST M
         SET M.DOC_STATUS  = '30'
            ,M.CREATED_BY  = VT_CREATED_BY
            ,M.ACTIVE_FLAG = 'Y'
       WHERE M.PRICE_LIST_ID = IN_LIST_ID
         AND '30' <> M.DOC_STATUS
         AND '-30' = M.CREATED_BY;
      
      PKG_BD_PRICE_CMS.PRC_LIST_TO_INTF(IN_ENTITY_ID,
                                        IN_LIST_ID,
                                        VN_OUT_ADJ_ID,
                                        NULL,
                                        OS_MESSAGE,
                                        VS_PRE01,
                                        VS_PRE02,
                                        VS_PRE03,
                                        VS_PRE04,
                                        VS_PRE05,
                                        VS_PRE06);
      IF VS_PRE01 = 'CMS' THEN
        IF OS_MESSAGE <> 'SUCCESS' THEN
          ROLLBACK;
          RETURN;
        ELSE
          PKG_BD_PRICE_CMS.PRC_LINE_TO_INTF(IN_ENTITY_ID,
                                            IN_LIST_ID,
                                            NULL,
                                            NULL,
                                            OS_MESSAGE,
                                            VS_PRE01,
                                            VS_PRE02,
                                            VS_PRE03,
                                            VS_PRE04,
                                            VS_PRE05,
                                            VS_PRE06);
          IF OS_MESSAGE <> 'SUCCESS' THEN
            ROLLBACK;
            RETURN;
          END IF;
        END IF;
      END IF;
    END IF;
    OS_MESSAGE := 'SUCCESS';
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      IF SQLCODE = -30006 OR SQLCODE = -54 THEN
        OS_MESSAGE := '价格列表通过回写其他接口表发生异常：[价格列表已被锁定]' || SQLERRM;
      ELSE
        OS_MESSAGE := '价格列表通过回写其他接口表发生异常：[SQLCODE：' || SQLCODE || '，MSG：' ||
                      SQLERRM || ']';
      END IF;
  END PRICE_SUCCESS_WRITE;

  -----------------------------------------------------------------------------
  --  多价格列表批量调整通过回写正式表        --add by liangym2
  --如果处理内部结算价、推广物料采购价 并成功 返回 空值
  --否则不处理内部结算价、推广物料采购价的话，返回SUCCESS
  -----------------------------------------------------------------------------
  PROCEDURE MULTI_PRICE_MODIFY_WRITE(IN_ENTITY_ID      IN NUMBER
                                    ,IN_MODIFY_LIST_ID IN NUMBER
                                    ,IS_LAST_UPDATE_BY IN VARCHAR2
                                    ,OS_MESSAGE        OUT VARCHAR2 --返回提示信息
                                     ) IS
    VN_COUNT NUMBER;
    VN_OUT_ADJ_ID NUMBER;
    VS_PRE01 VARCHAR2(100);
    VS_PRE02 VARCHAR2(100);
    VS_PRE03 VARCHAR2(100);
    VS_PRE04 VARCHAR2(100);
    VS_PRE05 VARCHAR2(100);
    VS_PRE06 VARCHAR2(100);
    CURSOR C_LOCK IS
      SELECT 1
        FROM T_BD_PRICE_LIST L
       WHERE EXISTS (SELECT 1
                FROM T_BD_MULTI_PRICE_MODIFY_DETAIL D
               WHERE D.MODIFY_LIST_ID = IN_MODIFY_LIST_ID
                 AND D.LIST_ID = L.PRICE_LIST_ID)
         FOR UPDATE WAIT 3;
    CURSOR C_LOCK_L IS
      SELECT 1
        FROM T_BD_PRICE_LINE L
       WHERE EXISTS
       (SELECT 1
                FROM T_BD_MULTI_PRICE_MODIFY_DETAIL D
               WHERE D.MODIFY_LIST_ID = IN_MODIFY_LIST_ID
                 AND D.LIST_ID = L.PRICE_LIST_ID
                 AND L.ITEM_ID = D.ITEM_ID
                 AND (L.CHANNEL_ATTR = D.CHANNEL_ATTR OR
                     (L.CHANNEL_ATTR IS NULL AND D.CHANNEL_ATTR IS NULL)))
         AND L.PRICE_LIST_ID IN
             (SELECT D.LIST_ID
                FROM T_BD_MULTI_PRICE_MODIFY_DETAIL D
               WHERE D.MODIFY_LIST_ID = IN_MODIFY_LIST_ID)
         AND L.ACTIVE_FLAG = 'Y'
         AND L.UQ_CHECK_FLAG = 0
         FOR UPDATE WAIT 3;
    VR_MULTI_PRICE_MODIFY T_BD_MULTI_PRICE_MODIFY%ROWTYPE;
    VT_CREATED_BY T_BD_MULTI_PRICE_MODIFY.CREATED_BY%TYPE;
  BEGIN
    BEGIN
      SELECT *
        INTO VR_MULTI_PRICE_MODIFY
        FROM T_BD_MULTI_PRICE_MODIFY
       WHERE MODIFY_LIST_ID = IN_MODIFY_LIST_ID;
    
      VT_CREATED_BY := VR_MULTI_PRICE_MODIFY.CREATED_BY;
      /*SELECT SID FROM V$MYSTAT WHERE ROWNUM =1;
      SELECT USERENV('SID') FROM DUAL;
      SELECT SID FROM V$SESSION WHERE AUDSID=USERENV('SESSIONID');*/
      
      --OPEN C_LOCK; commented by xiaoxu 多价格列表调整不需要锁定价格列表头
      OPEN C_LOCK_L;
      UPDATE T_BD_MULTI_PRICE_MODIFY M
         SET M.CREATED_BY = '-30'
       WHERE M.MODIFY_LIST_ID = IN_MODIFY_LIST_ID
         AND '30' <> M.DOC_STATUS;

      /*
      * 查找调整时间段与价格列表行时间段重叠的相同产品，若时间段重叠则根据调整时间段更新价格列表行的价格数据
      * 调整算法：
      * 1) 获取与当前调整数据“产品ID”相同的价格列表行数据（价格列表行数据按启用日期升序排序）
      * 2) 调整数据与每一条价格列表行数据进行比较（3到6步为循环操作）
      *   3) 判断调整时间段是否与原始价格列表行数据时间段重叠。如果重叠，转4)；否则，转2)
      *     4) 如果 原始启用日期 >= 调整启用日期，则删除原始价格列表行数据
      *     5) 否则，将原始价格列表行的停用日期设置为调整启用日期的前一天
      *     6) 由于操作4)删除了原始价格列表行数据，如果 原始停用日期 >= 调整停用日期，实际上会删除这段有效的价格新，
      *        所以对于这种情况要先新增一条数据：启用日期设置为调整停用日期的后一天、停用日期设置为原始的停用日期，
      *        操作6)实际上要在操作4)之前执行，否则原始价格列表行数据删除后取不到原始的停用日期
      * 7) 将调整数据插入到价格列表行
      */
      FOR LI IN (SELECT *
                   FROM T_BD_MULTI_PRICE_MODIFY_DETAIL
                  WHERE MODIFY_LIST_ID = IN_MODIFY_LIST_ID
                  ORDER BY LIST_ID, ITEM_ID)
      LOOP
        IF LI.BEGIN_DATE IS NULL THEN
          --停用价格列表行
          STOP_PRICE_LINE(IN_ENTITY_ID,
                          LI.LIST_ID,
                          LI.ITEM_ID,
                          LI.CHANNEL_ATTR,
                          LI.END_DATE,
                          IN_MODIFY_LIST_ID,
                          LI.MODIFY_LINE_ID,
                          VR_MULTI_PRICE_MODIFY.MODIFY_LIST_NUM,
                          NVL(VR_MULTI_PRICE_MODIFY.LAST_UPDATED_BY,
                              VR_MULTI_PRICE_MODIFY.CREATED_BY),
                          SYSDATE,
                          OS_MESSAGE);
          IF 'SUCCESS' <> OS_MESSAGE THEN
            ROLLBACK;
            RETURN;
          END IF;
        ELSE
          FOR IL1 IN (SELECT *
                        FROM T_BD_PRICE_LINE L
                       WHERE L.PRICE_LIST_ID = LI.LIST_ID
                         AND L.ITEM_ID = LI.ITEM_ID
                         AND (L.CHANNEL_ATTR = LI.CHANNEL_ATTR OR
                             (L.CHANNEL_ATTR IS NULL AND LI.CHANNEL_ATTR IS NULL))
                         AND NOT ('N' = L.ACTIVE_FLAG OR (L.END_DATE IS NOT NULL AND L.END_DATE < L.BEGIN_DATE))
                       --AND L.ACTIVE_FLAG = 'Y'
                       --AND L.UQ_CHECK_FLAG = 0
                       --获取与当前调整数据“产品ID”相同的价格列表行数据（价格列表行数据按启用日期升序排序）
                       ORDER BY L.CHANNEL_ATTR,
                                L.BEGIN_DATE,
                                L.PRICE_LINE_ID
                      )
          LOOP
            --判断时间段是否重叠
            IF (LI.END_DATE IS NULL AND IL1.END_DATE IS NULL) OR
               (IL1.END_DATE IS NULL AND LI.END_DATE >= IL1.BEGIN_DATE) OR
               (LI.END_DATE IS NULL AND IL1.END_DATE >= LI.BEGIN_DATE) OR
               (LI.END_DATE BETWEEN IL1.BEGIN_DATE AND IL1.END_DATE) OR
               --由于多价格列表调整限制启用日期必须是当天
               --对于原始停用日期在调整启用日期、调整停用日期之间重叠的情形
               --要排除原始停用日期等于调整停用日期（即同一天停用），因为这种情形没必要插入新数据
               (IL1.END_DATE >= LI.BEGIN_DATE AND IL1.END_DATE < LI.END_DATE)
            THEN
              --插入一条数据，保留未来有效的价格
              IF (IL1.END_DATE IS NULL AND LI.END_DATE >= IL1.BEGIN_DATE) OR
                 (LI.END_DATE >= IL1.BEGIN_DATE AND LI.END_DATE < IL1.END_DATE)
              THEN
                INSERT INTO T_BD_PRICE_LINE
                  (PRICE_LINE_ID,
                   PRICE_LIST_ID,
                   ITEM_ID,
                   ITEM_CODE,
                   ITEM_NAME,
                   COMPETITE_ATTR,
                   CHANNEL_ATTR,
                   UNIT_CODE,
                   LIST_PRICE,
                   --FLOOR_PRICE,
                   --COST_PRICE,
                   --RETAIL_PRICE,
                   DISCOUNT,
                   BEGIN_DATE,
                   END_DATE,
                   CREATED_BY,
                   CREATION_DATE,
                   LAST_UPDATED_BY,
                   LAST_UPDATE_DATE,
                   REMARK,
                   ENTITY_ID,
                   ACTIVE_FLAG,
                   ADJUST_LIST_ID,
                   --PROCESS_INSTANCE_ID,
                   MODIFY_LIST_NUM,
                   --UQ_CHECK_FLAG,
                   MODIFY_SOURCE)
                VALUES
                  (SEQ_BD_ROW_ID.NEXTVAL,
                   IL1.PRICE_LIST_ID,
                   IL1.ITEM_ID,
                   IL1.ITEM_CODE,
                   IL1.ITEM_NAME,
                   IL1.COMPETITE_ATTR,
                   IL1.CHANNEL_ATTR,
                   IL1.UNIT_CODE,
                   IL1.LIST_PRICE,
                   --IL1.FLOOR_PRICE,
                   --IL1.COST_PRICE,
                   --IL1.RETAIL_PRICE,
                   IL1.DISCOUNT,
                   --将新增明细数据的启用日期设置为调整停用日期的后一天
                   1 + LI.END_DATE,
                   IL1.END_DATE,
                   'program',
                   SYSDATE,
                   'program',
                   SYSDATE,
                   LI.REMARK,
                   IL1.ENTITY_ID,
                   'Y',
                   LI.MODIFY_LIST_ID,
                   --IL1.PROCESS_INSTANCE_ID,
                   VR_MULTI_PRICE_MODIFY.MODIFY_LIST_NUM,
                   --IL1.UQ_CHECK_FLAG,
                   '1' --设置价格列表行调整来源
                  );
              END IF;
              IF IL1.BEGIN_DATE >= LI.BEGIN_DATE THEN
                --beginDate2 >= beginDate1, 删除因调整导致无效的价格列表明细(调整后的价格覆盖价格列表明细的价格)
                /*DELETE FROM T_BD_PRICE_LINE_DL
                 WHERE PRICE_LINE_ID = IL1.PRICE_LINE_ID;
                
                INSERT INTO T_BD_PRICE_LINE_DL
                  SELECT *
                    FROM T_BD_PRICE_LINE
                   WHERE PRICE_LINE_ID = IL1.PRICE_LINE_ID;
                DELETE FROM T_BD_PRICE_LINE
                 WHERE PRICE_LINE_ID = IL1.PRICE_LINE_ID;
                 
                UPDATE T_BD_PRICE_LINE_DL
                   SET ADJUST_LIST_ID  = LI.MODIFY_LIST_ID
                      ,MODIFY_LIST_NUM = VR_MULTI_PRICE_MODIFY.MODIFY_LIST_NUM
                      ,MODIFY_SOURCE   = '1'
                 WHERE PRICE_LINE_ID = IL1.PRICE_LINE_ID;*/

                --不删除，改为失效
                UPDATE T_BD_PRICE_LINE
                   SET ADJUST_LIST_ID  = LI.MODIFY_LIST_ID
                      ,MODIFY_LIST_NUM = VR_MULTI_PRICE_MODIFY.MODIFY_LIST_NUM
                      ,MODIFY_SOURCE   = '1'
                      ,ACTIVE_FLAG     = 'N'
                      ,UQ_CHECK_FLAG   = IL1.PRICE_LINE_ID
                 WHERE PRICE_LINE_ID = IL1.PRICE_LINE_ID;
              ELSE
                --获取调整启用日期的前一天的日期
                --将价格列表明细的停用日期设置为调整启用日期的前一天，并保存
                UPDATE T_BD_PRICE_LINE
                   SET END_DATE         = LI.BEGIN_DATE - 1,
                       ADJUST_LIST_ID   = LI.MODIFY_LIST_ID,
                       MODIFY_LIST_NUM  = VR_MULTI_PRICE_MODIFY.MODIFY_LIST_NUM,
                       MODIFY_SOURCE    = '1',
                     --REMARK           = DECODE(REMARK,NULL,LI.REMARK,REMARK),
                       LAST_UPDATED_BY  = 'program',
                       LAST_UPDATE_DATE = SYSDATE
                 WHERE PRICE_LINE_ID = IL1.PRICE_LINE_ID;
              END IF;
            END IF;
          END LOOP;
          
          --插入本次调整数据
          INSERT INTO T_BD_PRICE_LINE
            (PRICE_LINE_ID,
             PRICE_LIST_ID,
             ITEM_ID,
             ITEM_CODE,
             ITEM_NAME,
             COMPETITE_ATTR,
             CHANNEL_ATTR,
             UNIT_CODE,
             LIST_PRICE,
             --FLOOR_PRICE,
             --COST_PRICE,
             --RETAIL_PRICE,
             DISCOUNT,
             BEGIN_DATE,
             END_DATE,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             REMARK,
             ENTITY_ID,
             ACTIVE_FLAG,
             ADJUST_LIST_ID,
             --PROCESS_INSTANCE_ID,
             MODIFY_LIST_NUM,
             --UQ_CHECK_FLAG,
             MODIFY_SOURCE)
          VALUES
            (SEQ_BD_ROW_ID.NEXTVAL,
             LI.LIST_ID,
             LI.ITEM_ID,
             LI.ITEM_CODE,
             LI.ITEM_NAME,
             LI.COMPETITE_ATTR,
             LI.CHANNEL_ATTR,
             LI.UNIT_CODE,
             LI.LIST_PRICE,
             --LI.FLOOR_PRICE,
             --LI.COST_PRICE,
             --LI.RETAIL_PRICE,
             LI.DISCOUNT,
             LI.BEGIN_DATE,
             LI.END_DATE,
             'program',
             SYSDATE,
             'program',
             SYSDATE,
             LI.REMARK,
             LI.ENTITY_ID,
             'Y',
             LI.MODIFY_LIST_ID,
             --LI.PROCESS_INSTANCE_ID,
             VR_MULTI_PRICE_MODIFY.MODIFY_LIST_NUM,
             --LI.UQ_CHECK_FLAG,
             '1'--设置价格列表行调整来源
            );
          --更新行上的客户型号drawing_no
          update t_bd_price_line b
             set b.drawing_no =
                 (select drawing_no
                    from t_bd_item it
                   where it.active_flag = 'Y'
                     and it.item_code = b.item_code
                     and it.entity_id = b.entity_id and rownum=1)
           where b.modify_list_num = vr_multi_price_modify.modify_list_num;
          
          --向产品新增定价接口表intf_bd_item_make_price插数据
          SELECT COUNT(0)
            INTO VN_COUNT
            FROM INTF_BD_ITEM_MAKE_PRICE M
           WHERE M.ITEM_CODE = LI.ITEM_CODE;
          IF 0 = VN_COUNT THEN
            INSERT INTO INTF_BD_ITEM_MAKE_PRICE
              (MAKE_PRICE_ID,
               PRICE_LIST_ID,
               ITEM_ID,
               ITEM_CODE,
               ITEM_NAME,
               CREATED_BY,
               CREATION_DATE,
               INTF_STATUS)
              SELECT SEQ_BD_ROW_ID.NEXTVAL,
                     LI.LIST_ID,
                     LI.ITEM_ID,
                     LI.ITEM_CODE,
                     LI.ITEM_NAME,
                     'program',
                     SYSDATE,
                     'N'
                FROM DUAL
               WHERE NOT EXISTS (SELECT 1
                        FROM INTF_BD_ITEM_MAKE_PRICE M
                       WHERE M.ITEM_CODE = LI.ITEM_CODE);
          END IF;
        END IF;
      END LOOP;
      
      VN_OUT_ADJ_ID := IN_MODIFY_LIST_ID;
      PKG_BD_PRICE_CMS.PRC_LIST_TO_INTF(IN_ENTITY_ID,
                                        NULL,
                                        VN_OUT_ADJ_ID,
                                        '1',
                                        OS_MESSAGE,
                                        VS_PRE01,
                                        VS_PRE02,
                                        VS_PRE03,
                                        VS_PRE04,
                                        VS_PRE05,
                                        VS_PRE06);
      IF VS_PRE01 = 'CMS' THEN
        IF OS_MESSAGE <> 'SUCCESS' THEN
          ROLLBACK;
          RETURN;
        ELSE
          PKG_BD_PRICE_CMS.PRC_LINE_TO_INTF(IN_ENTITY_ID,
                                            NULL,
                                            IN_MODIFY_LIST_ID,
                                            '1',
                                            OS_MESSAGE,
                                            VS_PRE01,
                                            VS_PRE02,
                                            VS_PRE03,
                                            VS_PRE04,
                                            VS_PRE05,
                                            VS_PRE06);
          IF OS_MESSAGE <> 'SUCCESS' THEN
            ROLLBACK;
            RETURN;
          END IF;
        END IF;
      END IF;
      
      --CLOSE C_LOCK; commented by xiaoxu 多价格列表调整不需要锁定价格列表头
      CLOSE C_LOCK_L;
      UPDATE T_BD_MULTI_PRICE_MODIFY M
         SET M.DOC_STATUS = '30'
         ,M.CREATED_BY = VT_CREATED_BY
       WHERE M.MODIFY_LIST_ID = IN_MODIFY_LIST_ID
         AND '30' <> M.DOC_STATUS
         AND '-30' = M.CREATED_BY;
      OS_MESSAGE := 'SUCCESS';
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        IF SQLCODE = -30006 OR SQLCODE = -54 THEN
          OS_MESSAGE := '多价格列表批量调整通过回写正式表发生异常：[价格列表行已被锁定]' || SQLERRM;
        ELSE
          OS_MESSAGE := '多价格列表批量调整通过回写正式表发生异常：[SQLCODE：' || SQLCODE ||
                        '，MSG：' || SQLERRM || ']';
        END IF;
    END;
  END MULTI_PRICE_MODIFY_WRITE;

  -----------------------------------------------------------------------------
  --  价格列表调整通过检查 锁表       --add by liangym2
  -----------------------------------------------------------------------------
  PROCEDURE PRICE_ADJUST_CHECK(IN_ENTITY_ID      IN NUMBER
                              ,IN_ADJUST_LIST_ID IN NUMBER
                              ,IS_MESSAGE        IN VARCHAR2
                              ,OS_MESSAGE        OUT VARCHAR2 --返回提示信息
                               ) IS
    CURSOR C_LOCK IS
      SELECT 1
        FROM T_BD_PRICE_LIST L
       INNER JOIN T_BD_PRICE_ADJUST D
          ON (D.ADJUST_LIST_ID = IN_ADJUST_LIST_ID AND
             D.PRICE_LIST_ID = L.PRICE_LIST_ID)
         FOR UPDATE OF L.PRICE_LIST_ID NOWAIT;
    CURSOR C_LOCK_L IS
      SELECT 1
        FROM T_BD_PRICE_LINE L
       INNER JOIN T_BD_PRICE_ADJUST D
          ON (D.ADJUST_LIST_ID = IN_ADJUST_LIST_ID AND
             D.PRICE_LIST_ID = L.PRICE_LIST_ID)
       INNER JOIN T_BD_PRICE_ADJUST_DETAIL DD
          ON (D.ADJUST_LIST_ID = DD.ADJUST_LIST_ID)
       WHERE L.ITEM_ID = DD.ITEM_ID
         AND (L.CHANNEL_ATTR = DD.CHANNEL_ATTR OR
             (L.CHANNEL_ATTR IS NULL AND DD.CHANNEL_ATTR IS NULL))
         AND L.ACTIVE_FLAG = 'Y'
         AND L.UQ_CHECK_FLAG = 0
         FOR UPDATE OF L.PRICE_LINE_ID NOWAIT;
  BEGIN
    BEGIN
      OPEN C_LOCK;
      CLOSE C_LOCK;
      ROLLBACK;
      OPEN C_LOCK_L;
      CLOSE C_LOCK_L;
      ROLLBACK;
      OS_MESSAGE := 'SUCCESS';
    EXCEPTION
      WHEN OTHERS THEN
        IF SQLCODE = -30006 OR SQLCODE = -54 THEN
          OS_MESSAGE := IS_MESSAGE;
          IF OS_MESSAGE IS NULL THEN
            OS_MESSAGE := SQLERRM;
          END IF;
        END IF;
    END;
  END PRICE_ADJUST_CHECK;

  -----------------------------------------------------------------------------
  --  价格列表调整通过回写正式表        --add by liangym2
  ----如果价格调整功能限制启用日期必须是当天，使用该存储过程
  --如果处理内部结算价、推广物料采购价 并成功 返回 空值
  --否则不是处理内部结算价、推广物料采购价的话，返回SUCCESS
  -----------------------------------------------------------------------------
  PROCEDURE PRICE_ADJUST_WRITE(IN_ENTITY_ID      IN NUMBER
                              ,IN_ADJUST_LIST_ID IN NUMBER
                              ,IS_LAST_UPDATE_BY IN VARCHAR2
                              ,OS_MESSAGE        OUT VARCHAR2 --返回提示信息
                               ) IS
    VN_COUNT NUMBER;
    VS_LOCK_PRICE_LIST VARCHAR2(5); --是否锁定价格列表头的标识
    --游标用于锁定需要更新的价格列表头
    CURSOR C_LOCK IS
      SELECT 1
        FROM T_BD_PRICE_LIST L
       INNER JOIN T_BD_PRICE_ADJUST D
          ON (D.ADJUST_LIST_ID = IN_ADJUST_LIST_ID AND
             D.PRICE_LIST_ID = L.PRICE_LIST_ID)
         FOR UPDATE OF L.PRICE_LIST_ID WAIT 3;
    --游标用于锁定需要更新的价格列表行
    CURSOR C_LOCK_L IS
      SELECT 1
        FROM T_BD_PRICE_LINE L
       INNER JOIN T_BD_PRICE_ADJUST D
          ON (D.ADJUST_LIST_ID = IN_ADJUST_LIST_ID AND
             D.PRICE_LIST_ID = L.PRICE_LIST_ID)
       INNER JOIN T_BD_PRICE_ADJUST_DETAIL DD
          ON (D.ADJUST_LIST_ID = DD.ADJUST_LIST_ID)
       WHERE L.ITEM_ID = DD.ITEM_ID
         AND (L.CHANNEL_ATTR = DD.CHANNEL_ATTR OR
             (L.CHANNEL_ATTR IS NULL AND DD.CHANNEL_ATTR IS NULL))
         AND L.ACTIVE_FLAG = 'Y'
         AND L.UQ_CHECK_FLAG = 0
         FOR UPDATE OF L.PRICE_LINE_ID WAIT 3;
    VR_PRICE_ADJUST T_BD_PRICE_ADJUST%ROWTYPE;
    VT_CREATED_BY T_BD_PRICE_ADJUST_DETAIL.CREATED_BY%TYPE;
    
    S_STEP VARCHAR2(100);
  BEGIN
    BEGIN
      SELECT *
        INTO VR_PRICE_ADJUST
        FROM T_BD_PRICE_ADJUST
       WHERE ADJUST_LIST_ID = IN_ADJUST_LIST_ID;
    
      VT_CREATED_BY := VR_PRICE_ADJUST.CREATED_BY;
      /*SELECT SID FROM V$MYSTAT WHERE ROWNUM = 1;
      SELECT USERENV('SID') FROM DUAL;
      SELECT SID FROM V$SESSION WHERE AUDSID = USERENV('SESSIONID');*/
      
      --获取是否需要锁定价格列表头表的标识 add by xiaoxu
      BEGIN
        SELECT 'Y'
          INTO VS_LOCK_PRICE_LIST
          FROM T_BD_PRICE_ADJUST D, T_BD_PRICE_LIST L
         WHERE D.ADJUST_LIST_ID = IN_ADJUST_LIST_ID
           AND D.PRICE_LIST_ID = L.PRICE_LIST_ID
           AND (NVL(D.BEGIN_DATE, SYSDATE) <> NVL(L.BEGIN_DATE, SYSDATE) OR
               NVL(D.END_DATE, SYSDATE) <> NVL(L.END_DATE, SYSDATE) OR
               NVL(D.LIST_DESC, '1') <> NVL(L.LIST_DESC, '1'));
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          VS_LOCK_PRICE_LIST := 'N';
      END;
      
      IF VS_LOCK_PRICE_LIST = 'Y' THEN
        S_STEP := '锁定价格列表头';
        OPEN C_LOCK;
      END IF;
      S_STEP := '锁定价格列表行';
      OPEN C_LOCK_L;
      
      S_STEP := '更新价格列表调整单创建人为-30';
      UPDATE T_BD_PRICE_ADJUST M
         SET M.CREATED_BY = '-30'
       WHERE M.ADJUST_LIST_ID = IN_ADJUST_LIST_ID
         AND '30' <> M.DOC_STATUS;
      
      S_STEP := '循环价格列表调行更新价格列表行';
      --循环调整价格列表行
      FOR LI IN (SELECT *
                   FROM T_BD_PRICE_ADJUST_DETAIL
                  WHERE ADJUST_LIST_ID = IN_ADJUST_LIST_ID
                  ORDER BY ITEM_ID)
      LOOP
        IF LI.BEGIN_DATE IS NULL OR 'STOP' = VR_PRICE_ADJUST.ADJUST_TYPE THEN
          --停用价格列表行
          STOP_PRICE_LINE(IN_ENTITY_ID,
                          VR_PRICE_ADJUST.PRICE_LIST_ID,
                          LI.ITEM_ID,
                          LI.CHANNEL_ATTR,
                          LI.END_DATE,
                          IN_ADJUST_LIST_ID,
                          LI.ADJUST_LINE_ID,
                          VR_PRICE_ADJUST.ADJUST_LIST_ID,
                          NVL(VR_PRICE_ADJUST.LAST_UPDATED_BY,
                              VR_PRICE_ADJUST.CREATED_BY),
                          SYSDATE,
                          OS_MESSAGE);
          IF 'SUCCESS' <> OS_MESSAGE THEN
            ROLLBACK;
            RETURN;
          END IF;
        ELSE
          FOR IL1 IN (SELECT *
                        FROM T_BD_PRICE_LINE L
                       WHERE L.PRICE_LIST_ID = VR_PRICE_ADJUST.PRICE_LIST_ID
                         AND L.ITEM_ID = LI.ITEM_ID
                         AND (L.CHANNEL_ATTR = LI.CHANNEL_ATTR OR
                             (L.CHANNEL_ATTR IS NULL AND LI.CHANNEL_ATTR IS NULL))
                         AND NOT ('N' = L.ACTIVE_FLAG OR (L.END_DATE IS NOT NULL AND L.END_DATE < L.BEGIN_DATE))
                       --AND L.ACTIVE_FLAG = 'Y'
                       --AND L.UQ_CHECK_FLAG = 0
                       --获取与当前调整数据“产品ID”相同的价格列表行数据（价格列表行数据按启用日期升序排序）
                       ORDER BY L.CHANNEL_ATTR,
                                L.BEGIN_DATE,
                                L.PRICE_LINE_ID
                      )
          LOOP
            --判断时间段是否重叠
            IF (LI.END_DATE IS NULL AND IL1.END_DATE IS NULL) OR
               (IL1.END_DATE IS NULL AND LI.END_DATE >= IL1.BEGIN_DATE) OR
               (LI.END_DATE IS NULL AND IL1.END_DATE >= LI.BEGIN_DATE) OR
               (LI.END_DATE BETWEEN IL1.BEGIN_DATE AND IL1.END_DATE) OR
               --如果价格调整功能限制启用日期必须是当天
               --对于原始停用日期在调整启用日期、调整停用日期之间重叠的情形
               --要排除原始停用日期等于调整停用日期（即同一天停用），因为这种情形没必要插入新数据
               (IL1.END_DATE >= LI.BEGIN_DATE AND IL1.END_DATE < LI.END_DATE)
            THEN
              --插入一条数据，保留未来有效的价格
              IF (IL1.END_DATE IS NULL AND LI.END_DATE >= IL1.BEGIN_DATE) OR
                 (LI.END_DATE >= IL1.BEGIN_DATE AND LI.END_DATE < IL1.END_DATE)
              THEN
                INSERT INTO T_BD_PRICE_LINE
                  (PRICE_LINE_ID,
                   PRICE_LIST_ID,
                   ITEM_ID,
                   ITEM_CODE,
                   ITEM_NAME,
                   COMPETITE_ATTR,
                   CHANNEL_ATTR,
                   UNIT_CODE,
                   LIST_PRICE,
                   --FLOOR_PRICE,
                   --COST_PRICE,
                   --RETAIL_PRICE,
                   DISCOUNT,
                   BEGIN_DATE,
                   END_DATE,
                   CREATED_BY,
                   CREATION_DATE,
                   LAST_UPDATED_BY,
                   LAST_UPDATE_DATE,
                   REMARK,
                   ENTITY_ID,
                   ACTIVE_FLAG,
                   ADJUST_LIST_ID,
                   --PROCESS_INSTANCE_ID,
                   MODIFY_LIST_NUM,
                   UQ_CHECK_FLAG,
                   MODIFY_SOURCE)
                VALUES
                  (SEQ_BD_ROW_ID.NEXTVAL,
                   IL1.PRICE_LIST_ID,
                   IL1.ITEM_ID,
                   IL1.ITEM_CODE,
                   IL1.ITEM_NAME,
                   IL1.COMPETITE_ATTR,
                   IL1.CHANNEL_ATTR,
                   IL1.UNIT_CODE,
                   IL1.LIST_PRICE,
                   --IL1.FLOOR_PRICE,
                   --IL1.COST_PRICE,
                   --IL1.RETAIL_PRICE,
                   IL1.DISCOUNT,
                   --将新增明细数据的启用日期设置为调整停用日期的后一天
                   1 + LI.END_DATE,
                   IL1.END_DATE,
                   'program',
                   SYSDATE,
                   'program',
                   SYSDATE,
                   LI.REMARK,
                   IL1.ENTITY_ID,
                   'Y',
                   LI.ADJUST_LIST_ID,
                   --IL1.PROCESS_INSTANCE_ID,
                   VR_PRICE_ADJUST.ADJUST_LIST_ID,
                   0,--IL1.UQ_CHECK_FLAG,
                   '0'--设置价格列表行调整来源
                  );
              END IF;
              
              IF IL1.BEGIN_DATE >= LI.BEGIN_DATE THEN
                --beginDate2 >= beginDate1, 删除因调整导致无效的价格列表明细(调整后的价格覆盖价格列表明细的价格)
                DELETE FROM T_BD_PRICE_LINE
                 WHERE PRICE_LINE_ID = IL1.PRICE_LINE_ID;
              ELSE
                --获取调整启用日期的前一天的日期
                --将价格列表明细的停用日期设置为调整启用日期的前一天，并保存
                UPDATE T_BD_PRICE_LINE
                   SET END_DATE         = LI.BEGIN_DATE - 1,
                       ADJUST_LIST_ID   = LI.ADJUST_LIST_ID,
                       MODIFY_LIST_NUM  = VR_PRICE_ADJUST.ADJUST_LIST_ID,
                       MODIFY_SOURCE    = '0',
                     --REMARK           = DECODE(REMARK,NULL,LI.REMARK,REMARK),
                       LAST_UPDATED_BY  = 'program',
                       LAST_UPDATE_DATE = SYSDATE
                 WHERE PRICE_LINE_ID = IL1.PRICE_LINE_ID;
              END IF;
            END IF;
          END LOOP;
          
          --插入本次调整数据
          INSERT INTO T_BD_PRICE_LINE
            (PRICE_LINE_ID,
             PRICE_LIST_ID,
             ITEM_ID,
             ITEM_CODE,
             ITEM_NAME,
             COMPETITE_ATTR,
             CHANNEL_ATTR,
             UNIT_CODE,
             LIST_PRICE,
             --FLOOR_PRICE,
             --COST_PRICE,
             --RETAIL_PRICE,
             DISCOUNT,
             BEGIN_DATE,
             END_DATE,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             REMARK,
             ENTITY_ID,
             ACTIVE_FLAG,
             ADJUST_LIST_ID,
             --PROCESS_INSTANCE_ID,
             MODIFY_LIST_NUM,
             UQ_CHECK_FLAG,
             MODIFY_SOURCE)
          VALUES
            (SEQ_BD_ROW_ID.NEXTVAL,
             VR_PRICE_ADJUST.PRICE_LIST_ID,
             LI.ITEM_ID,
             LI.ITEM_CODE,
             LI.ITEM_NAME,
             LI.COMPETITE_ATTR,
             LI.CHANNEL_ATTR,
             LI.UNIT_CODE,
             LI.LIST_PRICE,
             --LI.FLOOR_PRICE,
             --LI.COST_PRICE,
             --LI.RETAIL_PRICE,
             LI.DISCOUNT,
             LI.BEGIN_DATE,
             LI.END_DATE,
             'program',
             SYSDATE,
             'program',
             SYSDATE,
             LI.REMARK,
             LI.ENTITY_ID,
             'Y',
             LI.ADJUST_LIST_ID,
             --LI.PROCESS_INSTANCE_ID,
             VR_PRICE_ADJUST.ADJUST_LIST_ID,
             0,--LI.UQ_CHECK_FLAG,
             '0'--设置价格列表行调整来源
            );
            
          --向产品新增定价接口表intf_bd_item_make_price插数据
          SELECT COUNT(0)
            INTO VN_COUNT
            FROM INTF_BD_ITEM_MAKE_PRICE M
           WHERE M.ITEM_CODE = LI.ITEM_CODE;
          IF 0 = VN_COUNT THEN
            INSERT INTO INTF_BD_ITEM_MAKE_PRICE
              (MAKE_PRICE_ID,
               PRICE_LIST_ID,
               ITEM_ID,
               ITEM_CODE,
               ITEM_NAME,
               CREATED_BY,
               CREATION_DATE,
               INTF_STATUS)
              SELECT SEQ_BD_ROW_ID.NEXTVAL,
                     VR_PRICE_ADJUST.PRICE_LIST_ID,
                     LI.ITEM_ID,
                     LI.ITEM_CODE,
                     LI.ITEM_NAME,
                     'program',
                     SYSDATE,
                     'N'
                FROM DUAL
               WHERE NOT EXISTS (SELECT 1
                        FROM INTF_BD_ITEM_MAKE_PRICE M
                       WHERE M.ITEM_CODE = LI.ITEM_CODE);
          END IF;
        END IF;
      END LOOP;
      
      IF VS_LOCK_PRICE_LIST = 'Y' THEN
        CLOSE C_LOCK;
        S_STEP := '更新价格列表头';
        --更新价格列表头
        UPDATE T_BD_PRICE_LIST L
           SET L.BEGIN_DATE       = VR_PRICE_ADJUST.BEGIN_DATE
              ,L.END_DATE         = VR_PRICE_ADJUST.END_DATE
              ,L.LIST_DESC        = VR_PRICE_ADJUST.LIST_DESC
              ,L.LAST_UPDATED_BY  = VR_PRICE_ADJUST.CREATED_BY
              ,L.LAST_UPDATE_DATE = SYSDATE
         WHERE L.PRICE_LIST_ID = VR_PRICE_ADJUST.PRICE_LIST_ID;
      END IF;
      CLOSE C_LOCK_L;
      
      S_STEP := '更新价格列表调整单状态为审批通过';
      --更新价格列表调整单状态为审批通过
      UPDATE T_BD_PRICE_ADJUST M
         SET M.DOC_STATUS = '30', M.CREATED_BY = VT_CREATED_BY
       WHERE M.ADJUST_LIST_ID = IN_ADJUST_LIST_ID
         AND '30' <> M.DOC_STATUS
         AND '-30' = M.CREATED_BY;
         
      OS_MESSAGE := 'SUCCESS';
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        IF SQLCODE = -30006 OR SQLCODE = -54 THEN
          IF S_STEP = '锁定价格列表头' THEN
            OS_MESSAGE := '价格列表调整通过回写正式表发生异常：[价格列表头已被锁定]' || SQLERRM;
          ELSIF S_STEP = '锁定价格列表行' THEN
            OS_MESSAGE := '价格列表调整通过回写正式表发生异常：[价格列表行已被锁定]' || SQLERRM;
          ELSE
            OS_MESSAGE := '价格列表调整通过回写正式表发生异常：[数据已被锁定]' || SQLERRM;
          END IF;
        ELSE
          OS_MESSAGE := '价格列表调整通过回写正式表发生异常：[SQLCODE：' || SQLCODE ||
                        '，MSG：' || SQLERRM || ']';
        END IF;
    END;
  END PRICE_ADJUST_WRITE;

  -----------------------------------------------------------------------------
  --  价格列表调整通过回写正式表        --add by liangym2
  --如果处理内部结算价、推广物料采购价 并成功 返回 空值
  --否则不处理内部结算价、推广物料采购价的话，返回SUCCESS
  -----------------------------------------------------------------------------
  PROCEDURE PRICE_ADJUST_WRITE_NONDEL(IN_ENTITY_ID      IN NUMBER
                                     ,IN_ADJUST_LIST_ID IN NUMBER
                                     ,IS_LAST_UPDATE_BY IN VARCHAR2
                                     ,OS_MESSAGE        OUT VARCHAR2 --返回提示信息
                                      ) IS
    VN_COUNT NUMBER;
    VN_OUT_ADJ_ID NUMBER;
    VS_PRE01 VARCHAR2(100);
    VS_PRE02 VARCHAR2(100);
    VS_PRE03 VARCHAR2(100);
    VS_PRE04 VARCHAR2(100);
    VS_PRE05 VARCHAR2(100);
    VS_PRE06 VARCHAR2(100);
    VS_LOCK_PRICE_LIST VARCHAR2(5); --是否锁定价格列表头的标识
    --游标用于锁定需要更新的价格列表头
    CURSOR C_LOCK IS
      SELECT 1
        FROM T_BD_PRICE_LIST L
       INNER JOIN T_BD_PRICE_ADJUST D
          ON (D.ADJUST_LIST_ID = IN_ADJUST_LIST_ID AND
             D.PRICE_LIST_ID = L.PRICE_LIST_ID)
         FOR UPDATE OF L.PRICE_LIST_ID WAIT 3;
    --游标用于锁定需要更新的价格列表行
    CURSOR C_LOCK_L IS
      SELECT 1
        FROM T_BD_PRICE_LINE L
       INNER JOIN T_BD_PRICE_ADJUST D
          ON (D.ADJUST_LIST_ID = IN_ADJUST_LIST_ID AND
             D.PRICE_LIST_ID = L.PRICE_LIST_ID)
       INNER JOIN T_BD_PRICE_ADJUST_DETAIL DD
          ON (D.ADJUST_LIST_ID = DD.ADJUST_LIST_ID)
       WHERE L.ITEM_ID = DD.ITEM_ID
         AND (L.CHANNEL_ATTR = DD.CHANNEL_ATTR OR
             (L.CHANNEL_ATTR IS NULL AND DD.CHANNEL_ATTR IS NULL))
         AND L.ACTIVE_FLAG = 'Y'
         AND L.UQ_CHECK_FLAG = 0
         FOR UPDATE OF L.PRICE_LINE_ID WAIT 3;
    VR_PRICE_ADJUST T_BD_PRICE_ADJUST%ROWTYPE;
    VT_CREATED_BY T_BD_PRICE_ADJUST_DETAIL.CREATED_BY%TYPE;
    VT_BD_PL_SPLIT_DATE_OVERLAY T_BD_PARAM_LIST.DEFAULT_VALUE%TYPE;
    
    S_STEP VARCHAR2(100);
  BEGIN
    BEGIN
      SELECT *
        INTO VR_PRICE_ADJUST
        FROM T_BD_PRICE_ADJUST
       WHERE ADJUST_LIST_ID = IN_ADJUST_LIST_ID;
      VT_CREATED_BY := VR_PRICE_ADJUST.CREATED_BY;
      
      BEGIN
        SELECT PKG_BD.F_GET_PARAMETER_VALUE('BD_PRICE_LINE_SPLIT_DATE_OVERLAY',
                                            12,
                                            NULL,
                                            NULL)
          INTO VT_BD_PL_SPLIT_DATE_OVERLAY
          FROM DUAL;
      EXCEPTION
        WHEN OTHERS THEN
          VT_BD_PL_SPLIT_DATE_OVERLAY := 'N';
      END;
      VT_BD_PL_SPLIT_DATE_OVERLAY := NVL(VT_BD_PL_SPLIT_DATE_OVERLAY,'N');
      /*SELECT SID FROM V$MYSTAT WHERE ROWNUM = 1;
      SELECT USERENV('SID') FROM DUAL;
      SELECT SID FROM V$SESSION WHERE AUDSID = USERENV('SESSIONID');*/
      
      --获取是否需要锁定价格列表头表的标识 add by xiaoxu
      BEGIN
        SELECT 'Y'
          INTO VS_LOCK_PRICE_LIST
          FROM T_BD_PRICE_ADJUST D, T_BD_PRICE_LIST L
         WHERE D.ADJUST_LIST_ID = IN_ADJUST_LIST_ID
           AND D.PRICE_LIST_ID = L.PRICE_LIST_ID
           AND (NVL(D.BEGIN_DATE, SYSDATE) <> NVL(L.BEGIN_DATE, SYSDATE) OR
               NVL(D.END_DATE, SYSDATE) <> NVL(L.END_DATE, SYSDATE) OR
               NVL(D.LIST_DESC, '1') <> NVL(L.LIST_DESC, '1'));
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          VS_LOCK_PRICE_LIST := 'N';
      END;
        
      IF VS_LOCK_PRICE_LIST = 'Y' THEN
        S_STEP := '锁定价格列表头';
        OPEN C_LOCK;
      END IF;
      S_STEP := '锁定价格列表行';
      OPEN C_LOCK_L;
      
      S_STEP := '更新价格列表调整单创建人为-30';
      UPDATE T_BD_PRICE_ADJUST M
         SET M.CREATED_BY = '-30'
       WHERE M.ADJUST_LIST_ID = IN_ADJUST_LIST_ID
         AND '30' <> M.DOC_STATUS;
      
      S_STEP := '循环价格列表调行更新价格列表行';
      FOR LI IN (SELECT *
                   FROM T_BD_PRICE_ADJUST_DETAIL
                  WHERE ADJUST_LIST_ID = IN_ADJUST_LIST_ID
                  ORDER BY ITEM_ID)
      LOOP
        IF LI.BEGIN_DATE IS NULL OR 'STOP' = VR_PRICE_ADJUST.ADJUST_TYPE THEN
          --停用价格列表行
          STOP_PRICE_LINE(IN_ENTITY_ID,
                          VR_PRICE_ADJUST.PRICE_LIST_ID,
                          LI.ITEM_ID,
                          LI.CHANNEL_ATTR,
                          LI.END_DATE,
                          IN_ADJUST_LIST_ID,
                          LI.ADJUST_LINE_ID,
                          VR_PRICE_ADJUST.ADJUST_LIST_ID,
                          NVL(VR_PRICE_ADJUST.LAST_UPDATED_BY,
                              VR_PRICE_ADJUST.CREATED_BY),
                          SYSDATE,
                          OS_MESSAGE);
          IF 'SUCCESS' <> OS_MESSAGE THEN
            ROLLBACK;
            RETURN;
          END IF;
        ELSE
          FOR IL1 IN (SELECT *
                        FROM T_BD_PRICE_LINE L
                       WHERE L.PRICE_LIST_ID = VR_PRICE_ADJUST.PRICE_LIST_ID
                         AND L.ITEM_ID = LI.ITEM_ID
                         AND (L.CHANNEL_ATTR = LI.CHANNEL_ATTR OR
                             (L.CHANNEL_ATTR IS NULL AND LI.CHANNEL_ATTR IS NULL))
                         AND NOT ('N' = L.ACTIVE_FLAG OR (L.END_DATE IS NOT NULL AND L.END_DATE < L.BEGIN_DATE))
                       --AND L.ACTIVE_FLAG = 'Y'
                       --AND L.UQ_CHECK_FLAG = 0
                       --获取与当前调整数据“产品ID”相同的价格列表行数据（价格列表行数据按启用日期升序排序）
                       ORDER BY L.CHANNEL_ATTR,
                                L.BEGIN_DATE,
                                L.PRICE_LINE_ID
                      )
          LOOP
            --判断时间段是否重叠
            IF (LI.END_DATE IS NULL AND IL1.END_DATE IS NULL) OR
               (IL1.END_DATE IS NULL AND LI.END_DATE >= IL1.BEGIN_DATE) OR
               (LI.END_DATE IS NULL AND IL1.END_DATE >= LI.BEGIN_DATE) OR
               (LI.END_DATE BETWEEN IL1.BEGIN_DATE AND IL1.END_DATE) OR
               (IL1.END_DATE BETWEEN LI.BEGIN_DATE AND LI.END_DATE)
               /*(IL1.END_DATE >= LI.BEGIN_DATE AND IL1.END_DATE < LI.END_DATE)*/
            THEN
              --//调整停用日期小于原始停用日期且大于等于原始启用日期（包括两种场景）
					    --if (0 > beginDate1.compareTo(beginDate2) && null != endDate1 && 0 <= endDate1.compareTo(beginDate2) && (null == endDate2 || 0 > endDate1.compareTo(endDate2))) {
              IF LI.BEGIN_DATE < IL1.BEGIN_DATE AND LI.END_DATE >= IL1.BEGIN_DATE AND (IL1.END_DATE IS NULL OR LI.END_DATE < IL1.END_DATE) THEN
                IF 'N' = VT_BD_PL_SPLIT_DATE_OVERLAY THEN
                  UPDATE T_BD_PRICE_LINE L
                     SET L.ADJUST_LIST_ID   = LI.ADJUST_LIST_ID
                        ,L.MODIFY_LIST_NUM  = LI.ADJUST_LIST_ID
                        ,L.MODIFY_SOURCE    = '0'
                        ,L.LAST_UPDATED_BY  = NVL(LI.LAST_UPDATED_BY,
                                                  NVL(VR_PRICE_ADJUST.LAST_UPDATED_BY,
                                                      NVL(LI.CREATED_BY,
                                                          VR_PRICE_ADJUST.CREATED_BY)))
                        ,L.LAST_UPDATE_DATE = SYSDATE
                        ,L.ACTIVE_FLAG      = 'N'
                        ,L.UQ_CHECK_FLAG    = IL1.PRICE_LINE_ID
                        ,L.END_DATE         = IL1.BEGIN_DATE - 1
                   WHERE L.PRICE_LINE_ID = IL1.PRICE_LINE_ID;
                ELSE
                  UPDATE T_BD_PRICE_LINE L
                     SET L.ADJUST_LIST_ID   = LI.ADJUST_LIST_ID
                        ,L.MODIFY_LIST_NUM  = LI.ADJUST_LIST_ID
                        ,L.MODIFY_SOURCE    = '0'
                        ,L.LAST_UPDATED_BY  = NVL(LI.LAST_UPDATED_BY,
                                                  NVL(VR_PRICE_ADJUST.LAST_UPDATED_BY,
                                                      NVL(LI.CREATED_BY,
                                                          VR_PRICE_ADJUST.CREATED_BY)))
                        ,L.LAST_UPDATE_DATE = SYSDATE
                        ,L.BEGIN_DATE       = 1 + LI.END_DATE
                   WHERE L.PRICE_LINE_ID = IL1.PRICE_LINE_ID;
                END IF;
              
              --//调整启用日期大于等于原始启用日期且小于等于原始停用日期(包括四种场景)
					    --else if (0 <= beginDate1.compareTo(beginDate2) && (null == endDate2 || 0 >= beginDate1.compareTo(endDate2))) {
              ELSIF LI.BEGIN_DATE >= IL1.BEGIN_DATE AND (IL1.END_DATE IS NULL OR LI.BEGIN_DATE <= IL1.END_DATE) THEN
                UPDATE T_BD_PRICE_LINE L
                   SET L.ADJUST_LIST_ID   = LI.ADJUST_LIST_ID
                      ,L.MODIFY_LIST_NUM  = LI.ADJUST_LIST_ID
                      ,L.MODIFY_SOURCE    = '0'
                      ,L.LAST_UPDATED_BY  = NVL(LI.LAST_UPDATED_BY,
                                                NVL(VR_PRICE_ADJUST.LAST_UPDATED_BY,
                                                    NVL(LI.CREATED_BY,
                                                        VR_PRICE_ADJUST.CREATED_BY)))
                      ,L.LAST_UPDATE_DATE = SYSDATE
                      ,L.END_DATE         = -1 + LI.BEGIN_DATE
                      ,L.ACTIVE_FLAG = (CASE
                                         WHEN IL1.BEGIN_DATE >
                                              -1 + LI.BEGIN_DATE THEN
                                          'N'
                                         ELSE
                                          L.ACTIVE_FLAG
                                       END)
                      ,L.UQ_CHECK_FLAG = (CASE
                                           WHEN IL1.BEGIN_DATE >
                                                -1 + LI.BEGIN_DATE THEN
                                            IL1.PRICE_LINE_ID
                                           ELSE
                                            L.UQ_CHECK_FLAG
                                         END)
                 WHERE L.PRICE_LINE_ID = IL1.PRICE_LINE_ID;
                
                IF (VT_BD_PL_SPLIT_DATE_OVERLAY IS NULL OR 'N' <> VT_BD_PL_SPLIT_DATE_OVERLAY)
                   AND LI.END_DATE IS NOT NULL 
                   AND (IL1.END_DATE IS NULL OR IL1.END_DATE > LI.END_DATE)
                THEN
                  INSERT INTO T_BD_PRICE_LINE
                    (PRICE_LINE_ID,
                     PRICE_LIST_ID,
                     ITEM_ID,
                     ITEM_CODE,
                     ITEM_NAME,
                     COMPETITE_ATTR,
                     CHANNEL_ATTR,
                     UNIT_CODE,
                     LIST_PRICE,
                     --FLOOR_PRICE,
                     --COST_PRICE,
                     --RETAIL_PRICE,
                     DISCOUNT,
                     BEGIN_DATE,
                     END_DATE,
                     CREATED_BY,
                     CREATION_DATE,
                     LAST_UPDATED_BY,
                     LAST_UPDATE_DATE,
                     REMARK,
                     ENTITY_ID,
                     ACTIVE_FLAG,
                     ADJUST_LIST_ID,
                     --PROCESS_INSTANCE_ID,
                     MODIFY_LIST_NUM,
                     UQ_CHECK_FLAG,
                     MODIFY_SOURCE)
                  VALUES
                    (SEQ_BD_ROW_ID.NEXTVAL,
                     IL1.PRICE_LIST_ID,
                     IL1.ITEM_ID,
                     IL1.ITEM_CODE,
                     IL1.ITEM_NAME,
                     IL1.COMPETITE_ATTR,
                     IL1.CHANNEL_ATTR,
                     IL1.UNIT_CODE,
                     IL1.LIST_PRICE,
                     --IL1.FLOOR_PRICE,
                     --IL1.COST_PRICE,
                     --IL1.RETAIL_PRICE,
                     IL1.DISCOUNT,
                     --将新增明细数据的启用日期设置为调整停用日期的后一天
                     1 + LI.END_DATE,
                     IL1.END_DATE,--原始停用日期
                     IL1.CREATED_BY,
                     SYSDATE,
                     NVL(LI.LAST_UPDATED_BY,
                     NVL(VR_PRICE_ADJUST.LAST_UPDATED_BY,NVL(LI.CREATED_BY,VR_PRICE_ADJUST.CREATED_BY))),
                     SYSDATE,
                     IL1.REMARK,
                     --DECODE(IL1.REMARK,NULL,LI.REMARK,IL1.REMARK),
                     IL1.ENTITY_ID,
                     'Y',
                     LI.ADJUST_LIST_ID,
                     --IL1.PROCESS_INSTANCE_ID,
                     VR_PRICE_ADJUST.ADJUST_LIST_ID,
                     0,--IL1.UQ_CHECK_FLAG,
                     '0'--设置价格列表行调整来源
                    );
                END IF;
              
              --//其他两种场景：调整停用日期大于等于原始停用日期（调整停用日期为空，原始停用日期为空时调整停用日期也为空）且调整启用日期小于原始启用日期
              ELSE
                UPDATE T_BD_PRICE_LINE L
                   SET L.ADJUST_LIST_ID   = LI.ADJUST_LIST_ID
                      ,L.MODIFY_LIST_NUM  = LI.ADJUST_LIST_ID
                      ,L.MODIFY_SOURCE    = '0'
                      ,L.LAST_UPDATED_BY  = NVL(LI.LAST_UPDATED_BY,
                                                NVL(VR_PRICE_ADJUST.LAST_UPDATED_BY,
                                                    NVL(LI.CREATED_BY,
                                                        VR_PRICE_ADJUST.CREATED_BY)))
                      ,L.LAST_UPDATE_DATE = SYSDATE
                      ,L.END_DATE         = TRUNC(SYSDATE)
                      ,L.ACTIVE_FLAG      = 'N'
                      ,L.UQ_CHECK_FLAG    = IL1.PRICE_LINE_ID
                 WHERE L.PRICE_LINE_ID = IL1.PRICE_LINE_ID;
              END IF;
            END IF;
          END LOOP;
          
          --插入本次调整数据
          INSERT INTO T_BD_PRICE_LINE
            (PRICE_LINE_ID,
             PRICE_LIST_ID,
             ITEM_ID,
             ITEM_CODE,
             ITEM_NAME,
             COMPETITE_ATTR,
             CHANNEL_ATTR,
             UNIT_CODE,
             LIST_PRICE,
             --FLOOR_PRICE,
             --COST_PRICE,
             --RETAIL_PRICE,
             DISCOUNT,
             BEGIN_DATE,
             END_DATE,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             REMARK,
             ENTITY_ID,
             ACTIVE_FLAG,
             ADJUST_LIST_ID,
             --PROCESS_INSTANCE_ID,
             MODIFY_LIST_NUM,
             UQ_CHECK_FLAG,
             MODIFY_SOURCE)
          VALUES
            (SEQ_BD_ROW_ID.NEXTVAL,
             VR_PRICE_ADJUST.PRICE_LIST_ID,
             LI.ITEM_ID,
             LI.ITEM_CODE,
             LI.ITEM_NAME,
             LI.COMPETITE_ATTR,
             LI.CHANNEL_ATTR,
             LI.UNIT_CODE,
             LI.LIST_PRICE,
             --LI.FLOOR_PRICE,
             --LI.COST_PRICE,
             --LI.RETAIL_PRICE,
             LI.DISCOUNT,
             LI.BEGIN_DATE,
             LI.END_DATE,
             NVL(LI.LAST_UPDATED_BY
                ,NVL(VR_PRICE_ADJUST.LAST_UPDATED_BY,NVL(LI.CREATED_BY,VR_PRICE_ADJUST.CREATED_BY))),
             SYSDATE,
             NVL(LI.LAST_UPDATED_BY
                ,NVL(VR_PRICE_ADJUST.LAST_UPDATED_BY,NVL(LI.CREATED_BY,VR_PRICE_ADJUST.CREATED_BY))),
             SYSDATE,
             LI.REMARK,
             LI.ENTITY_ID,
             'Y',
             LI.ADJUST_LIST_ID,
             --LI.PROCESS_INSTANCE_ID,
             VR_PRICE_ADJUST.ADJUST_LIST_ID,
             0,--LI.UQ_CHECK_FLAG,
             '0'--设置价格列表行调整来源
            );
          
          --向产品新增定价接口表intf_bd_item_make_price插数据
          SELECT COUNT(0)
            INTO VN_COUNT
            FROM INTF_BD_ITEM_MAKE_PRICE M
           WHERE M.ITEM_CODE = LI.ITEM_CODE;
          IF 0 = VN_COUNT THEN
            INSERT INTO INTF_BD_ITEM_MAKE_PRICE
              (MAKE_PRICE_ID,
               PRICE_LIST_ID,
               ITEM_ID,
               ITEM_CODE,
               ITEM_NAME,
               CREATED_BY,
               CREATION_DATE,
               INTF_STATUS)
              SELECT SEQ_BD_ROW_ID.NEXTVAL,
                     VR_PRICE_ADJUST.PRICE_LIST_ID,
                     LI.ITEM_ID,
                     LI.ITEM_CODE,
                     LI.ITEM_NAME,
                     'program',
                     SYSDATE,
                     'N'
                FROM DUAL
               WHERE NOT EXISTS (SELECT 1
                        FROM INTF_BD_ITEM_MAKE_PRICE M
                       WHERE M.ITEM_CODE = LI.ITEM_CODE);
          END IF;
        END IF;
      END LOOP;
      
      VN_OUT_ADJ_ID := IN_ADJUST_LIST_ID;
      PKG_BD_PRICE_CMS.PRC_LIST_TO_INTF(IN_ENTITY_ID,
                                        NULL,
                                        VN_OUT_ADJ_ID,
                                        '0',
                                        OS_MESSAGE,
                                        VS_PRE01,
                                        VS_PRE02,
                                        VS_PRE03,
                                        VS_PRE04,
                                        VS_PRE05,
                                        VS_PRE06);
      IF VS_PRE01 = 'CMS' THEN
        IF OS_MESSAGE <> 'SUCCESS' THEN
          ROLLBACK;
          RETURN;
        ELSE
          PKG_BD_PRICE_CMS.PRC_LINE_TO_INTF(IN_ENTITY_ID,
                                            NULL,
                                            IN_ADJUST_LIST_ID,
                                            '0',
                                            OS_MESSAGE,
                                            VS_PRE01,
                                            VS_PRE02,
                                            VS_PRE03,
                                            VS_PRE04,
                                            VS_PRE05,
                                            VS_PRE06);
          IF OS_MESSAGE <> 'SUCCESS' THEN
            ROLLBACK;
            RETURN;
          END IF;
        END IF;
      END IF;
      
      IF VS_LOCK_PRICE_LIST = 'Y' THEN
        CLOSE C_LOCK;
        S_STEP := '更新价格列表头';
        UPDATE T_BD_PRICE_LIST L
           SET L.BEGIN_DATE       = VR_PRICE_ADJUST.BEGIN_DATE
              ,L.END_DATE         = VR_PRICE_ADJUST.END_DATE
              ,L.LIST_DESC        = VR_PRICE_ADJUST.LIST_DESC
              ,L.LAST_UPDATED_BY  = VR_PRICE_ADJUST.CREATED_BY
              ,L.LAST_UPDATE_DATE = SYSDATE
         WHERE L.PRICE_LIST_ID = VR_PRICE_ADJUST.PRICE_LIST_ID;
      END IF;
      CLOSE C_LOCK_L;
      
      S_STEP := '更新价格列表调整单状态为审批通过';
      UPDATE T_BD_PRICE_ADJUST M
         SET M.DOC_STATUS = '30', M.CREATED_BY = VT_CREATED_BY
       WHERE M.ADJUST_LIST_ID = IN_ADJUST_LIST_ID
         AND '30' <> M.DOC_STATUS
         AND '-30' = M.CREATED_BY;
         
      OS_MESSAGE := 'SUCCESS';
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        IF SQLCODE = -30006 OR SQLCODE = -54 THEN
          IF S_STEP = '锁定价格列表头' THEN
            OS_MESSAGE := '价格列表调整通过回写正式表发生异常：[价格列表头已被锁定]' || SQLERRM;
          ELSIF S_STEP = '锁定价格列表行' THEN
            OS_MESSAGE := '价格列表调整通过回写正式表发生异常：[价格列表行已被锁定]' || SQLERRM;
          ELSE
            OS_MESSAGE := '价格列表调整通过回写正式表发生异常：[数据已被锁定]' || SQLERRM;
          END IF;
        ELSE
          OS_MESSAGE := '价格列表调整通过回写正式表发生异常：[SQLCODE：' || SQLCODE ||
                        '，MSG：' || SQLERRM || ']';
        END IF;
    END;
  END PRICE_ADJUST_WRITE_NONDEL;
  
  --------------------------------------------------------------------
  --  价格列表调整或多价格列表批量调整审核通过后，写产品价格外发接口表
  --------------------------------------------------------------------
  PROCEDURE PRICE_ADJUST_2_ITEM_PRICE_INTF(IS_LAST_UPDATE_DATE IN VARCHAR2,
                                        OS_MESSAGE          OUT VARCHAR2 --返回提示信息
                                        ) IS
    S_STEP VARCHAR2(240);
  BEGIN
    OS_MESSAGE := 'OK';
    
    --价格列表调整，写产品价格外发接口表
    S_STEP := '价格列表调整，写产品价格外发接口表';
    INSERT INTO INTF_BD_ITEM_PRICE
        (INTF_ID,
         DEST_SYSTEM,
         INTF_STATUS,
         ITEM_ID,
         ITEM_CODE,
         PRICE,
         BEGIN_DATE,
         END_DATE,
         ACTIVE_FLAG,
         ENTITY_ID,
         SALES_CENTER_ID,
         SALES_CENTER_CODE,
         CUSTOMER_ID,
         CUSTOMER_CODE,
         CREATE_DATE)
        SELECT S_INTF_BD_ITEM_PRICE.NEXTVAL,
               'CCS',
               'N',
               ITEM_ID,
               ITEM_CODE,
               LIST_PRICE,
               BEGIN_DATE,
               END_DATE,
               ACTIVE_FLAG,
               ENTITY_ID,
               SALES_CENTER_ID,
               SALES_CENTER_CODE,
               CUSTOMER_ID,
               CUSTOMER_CODE,
               SYSDATE
          FROM (SELECT L.ITEM_ID,
                       L.ITEM_CODE,
                       L.LIST_PRICE,
                       L.BEGIN_DATE,
                       L.END_DATE,
                       L.ACTIVE_FLAG,
                       L.ENTITY_ID,
                       U.UNIT_ID       SALES_CENTER_ID,
                       U.CODE          SALES_CENTER_CODE,
                       C.CUSTOMER_ID,
                       C.CUSTOMER_CODE
                  FROM CIMS.T_BD_PRICE_SYSTEM      S,
                       CIMS.T_BD_PRICE_SYSTEM_CUST C,
                       CIMS.UP_ORG_UNIT            U,
                       CIMS.T_BD_PRICE_LINE        L,
                       CIMS.T_BD_PRICE_ADJUST      A
                 WHERE S.PRICE_TYPE = 'C' --成品价格体系
                   AND S.ACTIVE_FLAG = 'Y' --有效
                   AND S.PRICE_SYSTEM_ID = C.PRICE_SYSTEM_ID
                   AND C.ACTIVE_FLAG = 'Y'
                   AND C.SALES_CENTER_ID = U.UNIT_ID
                   AND U.TYPE_CODE = 'SC'
                   AND U.UNIT_TYPE = '网批' --网批中心
                   AND C.PRICE_LIST_ID = L.PRICE_LIST_ID
                   AND L.PRICE_LIST_ID = A.PRICE_LIST_ID
                   AND L.ADJUST_LIST_ID = A.ADJUST_LIST_ID
                   AND L.MODIFY_SOURCE = '0'
                   AND A.DOC_STATUS = '30' --审批通过
                   AND A.LAST_UPDATE_DATE >=
                       TO_DATE(IS_LAST_UPDATE_DATE, 'YYYY-MM-DD HH24:MI:SS')
                UNION
                SELECT L.ITEM_ID,
                       L.ITEM_CODE,
                       L.LIST_PRICE,
                       L.BEGIN_DATE,
                       L.END_DATE,
                       L.ACTIVE_FLAG,
                       L.ENTITY_ID,
                       O.SALES_CENTER_ID,
                       O.SALES_CENTER_CODE,
                       CA.CUSTOMER_ID,
                       CA.CUSTOMER_CODE
                  FROM CIMS.T_BD_PRICE_SYSTEM     S,
                       CIMS.T_BD_PRICE_SYSTEM_ORG O,
                       CIMS.UP_ORG_UNIT           U,
                       CIMS.T_CUSTOMER_ACCOUNT    CA,
                       CIMS.T_BD_PRICE_LINE       L,
                       CIMS.T_BD_PRICE_ADJUST     A
                 WHERE S.PRICE_TYPE = 'C' --成品价格体系
                   AND S.ACTIVE_FLAG = 'Y' --有效
                   AND S.PRICE_SYSTEM_ID = O.PRICE_SYSTEM_ID
                   AND O.ACTIVE_FLAG = 'Y'
                   AND O.SALES_CENTER_ID = U.UNIT_ID
                   AND U.TYPE_CODE = 'SC'
                   AND U.UNIT_TYPE = '网批' --网批中心
                   AND O.SALES_CENTER_ID = CA.SALES_CENTER_ID
                   AND CA.ACCOUNT_STATUS = '1' --账户有效
                   AND O.PRICE_LIST_ID = L.PRICE_LIST_ID
                   AND L.PRICE_LIST_ID = A.PRICE_LIST_ID
                   AND L.ADJUST_LIST_ID = A.ADJUST_LIST_ID
                   AND L.MODIFY_SOURCE = '0'
                   AND A.DOC_STATUS = '30' --审批通过
                   AND A.LAST_UPDATE_DATE >=
                       TO_DATE(IS_LAST_UPDATE_DATE, 'YYYY-MM-DD HH24:MI:SS')) V
         --只记录当前时间的价格
         WHERE TRUNC(SYSDATE) BETWEEN V.BEGIN_DATE AND NVL(V.END_DATE, TRUNC(SYSDATE));
    
      --多价格列表批量调整，写产品价格外发接口表
      S_STEP := '多价格列表批量调整，写产品价格外发接口表';
      INSERT INTO INTF_BD_ITEM_PRICE
          (INTF_ID,
           DEST_SYSTEM,
           INTF_STATUS,
           ITEM_ID,
           ITEM_CODE,
           PRICE,
           BEGIN_DATE,
           END_DATE,
           ACTIVE_FLAG,
           ENTITY_ID,
           SALES_CENTER_ID,
           SALES_CENTER_CODE,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           CREATE_DATE)
        SELECT S_INTF_BD_ITEM_PRICE.NEXTVAL,
               'CCS',
               'N',
               ITEM_ID,
               ITEM_CODE,
               LIST_PRICE,
               BEGIN_DATE,
               END_DATE,
               ACTIVE_FLAG,
               ENTITY_ID,
               SALES_CENTER_ID,
               SALES_CENTER_CODE,
               CUSTOMER_ID,
               CUSTOMER_CODE,
               SYSDATE
          FROM (SELECT L.ITEM_ID,
                       L.ITEM_CODE,
                       L.LIST_PRICE,
                       L.BEGIN_DATE,
                       L.END_DATE,
                       L.ACTIVE_FLAG,
                       L.ENTITY_ID,
                       U.UNIT_ID       SALES_CENTER_ID,
                       U.CODE          SALES_CENTER_CODE,
                       C.CUSTOMER_ID,
                       C.CUSTOMER_CODE
                  FROM CIMS.T_BD_PRICE_SYSTEM       S,
                       CIMS.T_BD_PRICE_SYSTEM_CUST  C,
                       CIMS.UP_ORG_UNIT             U,
                       CIMS.T_BD_PRICE_LINE         L,
                       CIMS.T_BD_MULTI_PRICE_MODIFY A
                 WHERE S.PRICE_TYPE = 'C' --成品价格体系
                   AND S.ACTIVE_FLAG = 'Y' --有效
                   AND S.PRICE_SYSTEM_ID = C.PRICE_SYSTEM_ID
                   AND C.ACTIVE_FLAG = 'Y'
                   AND C.SALES_CENTER_ID = U.UNIT_ID
                   AND U.TYPE_CODE = 'SC'
                   AND U.UNIT_TYPE = '网批'
                   AND C.PRICE_LIST_ID = L.PRICE_LIST_ID
                   AND L.ADJUST_LIST_ID = A.MODIFY_LIST_ID
                   AND L.MODIFY_SOURCE = '1'
                   AND A.DOC_STATUS = '30' --审批通过
                   AND A.LAST_UPDATE_DATE >=
                       TO_DATE(IS_LAST_UPDATE_DATE, 'YYYY-MM-DD HH24:MI:SS')
                UNION
                SELECT L.ITEM_ID,
                       L.ITEM_CODE,
                       L.LIST_PRICE,
                       L.BEGIN_DATE,
                       L.END_DATE,
                       L.ACTIVE_FLAG,
                       L.ENTITY_ID,
                       O.SALES_CENTER_ID,
                       O.SALES_CENTER_CODE,
                       CA.CUSTOMER_ID,
                       CA.CUSTOMER_CODE
                  FROM CIMS.T_BD_PRICE_SYSTEM       S,
                       CIMS.T_BD_PRICE_SYSTEM_ORG   O,
                       CIMS.UP_ORG_UNIT             U,
                       CIMS.T_CUSTOMER_ACCOUNT      CA,
                       CIMS.T_BD_PRICE_LINE         L,
                       CIMS.T_BD_MULTI_PRICE_MODIFY A
                 WHERE S.PRICE_TYPE = 'C' --成品价格体系
                   AND S.ACTIVE_FLAG = 'Y' --有效
                   AND S.PRICE_SYSTEM_ID = O.PRICE_SYSTEM_ID
                   AND O.ACTIVE_FLAG = 'Y'
                   AND O.SALES_CENTER_ID = U.UNIT_ID
                   AND U.TYPE_CODE = 'SC'
                   AND U.UNIT_TYPE = '网批'
                   AND O.SALES_CENTER_ID = CA.SALES_CENTER_ID
                   AND CA.ACCOUNT_STATUS = '1' --账户有效
                   AND O.PRICE_LIST_ID = L.PRICE_LIST_ID
                   AND L.ADJUST_LIST_ID = A.MODIFY_LIST_ID
                   AND L.MODIFY_SOURCE = '1'
                   AND A.DOC_STATUS = '30' --审批通过
                   AND A.LAST_UPDATE_DATE >=
                       TO_DATE(IS_LAST_UPDATE_DATE, 'YYYY-MM-DD HH24:MI:SS')) V
         --只记录当前时间的价格
         WHERE TRUNC(SYSDATE) BETWEEN V.BEGIN_DATE AND NVL(V.END_DATE, TRUNC(SYSDATE));
  EXCEPTION
    WHEN OTHERS THEN
      OS_MESSAGE := '写产品价格外发接口表异常：(' || S_STEP || ')' || 'SQLCODE:' || SQLCODE || ';SQLERRM:' || SQLERRM;
      ROLLBACK;
  END PRICE_ADJUST_2_ITEM_PRICE_INTF; 

END PKG_BD_PRICE_LIST;
/

