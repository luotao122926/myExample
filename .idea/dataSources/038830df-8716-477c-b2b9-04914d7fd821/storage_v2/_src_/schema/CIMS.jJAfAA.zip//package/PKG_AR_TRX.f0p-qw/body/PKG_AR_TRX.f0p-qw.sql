create package body      PKG_AR_TRX is
  v_Base_Exception Exception; --自定义异常
  --------------------------------------------------------------------------
  /**
  *循环发票签收过程
  *
  **/
  -------------------------------------------------------------------------
  Procedure p_Trx_CUSTOMER_SIGN_Cycle IS
    --接口头表游标
    Cursor c_Oi_Header Is
      Select *
         From INTF_SO_TRX_HEADERS Irah
         Where Irah.FLAG='0';
      r_Oi_Header c_Oi_Header%Rowtype;
      p_Result Varchar2(1000);
  Begin
     For r_Oi_Header In c_Oi_Header Loop
         p_Update_Trx_CUSTOMER_SIGN(r_Oi_Header.Id,p_Result);
     End Loop;
  End;
  ---------------------------------------------------------------------------
  /**
  * 发票签收接口程序
  * 功能：处理INTF_SO_TRX_HEADERS的客户签收信息
  *       更新到t_so_trx_headers,客户签收
  **/
  ---------------------------------------------------------------------------
  Procedure p_Update_Trx_CUSTOMER_SIGN(p_Oi_Header_Id In INTF_SO_TRX_HEADERS.ID%Type, --处理用的接口ID
                            p_Result           Out Varchar2 --返回值
                            ) IS
   OI_IDTRX_ID NUMBER; --接口表发票头ID
   OI_CUSTOMER_SIGN_FLAG VARCHAR2(1); --客户签收标示
   OI_CUSTOMER_SIGN_DATE DATE;   --客户签收时间
   PD_CUSTOMER_SIGN_FLAG VARCHAR2(1);--用于判断发票是否已被客户签收
   PD_CENTER_SIGN_FLAG VARCHAR2(1); --用于判断发票是否已被中心签收
  Begin
     p_Result:='OK';
     --取出接口表数据
     Begin
        Select Isth.IDTRX_ID, Isth.CUSTOMER_SIGN_FLAG,Isth.CUSTOMER_SIGN_DATE
          Into OI_IDTRX_ID, OI_CUSTOMER_SIGN_FLAG,OI_CUSTOMER_SIGN_DATE
          From INTF_SO_TRX_HEADERS Isth
         Where Isth.ID = p_Oi_Header_Id;
      Exception
        When No_Data_Found Then
          p_Result := '发票池头接口表有误，ID:' || p_Oi_Header_Id|| ',找不到';
          Raise v_Base_Exception;
      End;
      --获取对应发票的签收标示
      Begin
         Select Nvl(Trh.Center_Sign_Flag,'N'),Nvl(Trh.Customer_Sign_Flag,'N') into
                PD_CENTER_SIGN_FLAG,PD_CUSTOMER_SIGN_FLAG
             From t_so_trx_headers Trh
             Where Trh.Idtrx_Id=OI_IDTRX_ID;
      Exception
         When No_Data_Found Then
          p_Result := '发票池头接口表有误，ID:' || p_Oi_Header_Id|| ',找不到对应的发票';
          Raise v_Base_Exception;
      End;
      --判断发票是否已被客户签收
      If PD_CUSTOMER_SIGN_FLAG='Y' Then
         p_Result := '数据处理失败，发票（IDTRX_ID='||OI_IDTRX_ID||'）已被签收过，不可以重复签收';
         Raise v_Base_Exception;
      End If;
      --判断是接口表数据是否正确
      IF OI_IDTRX_ID is null  Then
        p_Result:='发票池头接口表有误，发票头ID为空';
        Raise v_Base_Exception;
      End If;
      IF OI_CUSTOMER_SIGN_FLAG is null  Then
        p_Result:='发票池头接口表有误，客户签收标示为空';
        Raise v_Base_Exception;
      End If;
      IF OI_CUSTOMER_SIGN_DATE is null  Then
        p_Result:='发票池头接口表有误，客户签收时间为空';
        Raise v_Base_Exception;
      End If;
      --update发票头的客户签收
      update t_so_trx_headers tsh
             set tsh.customer_sign_flag=OI_CUSTOMER_SIGN_FLAG,
                 tsh.Customer_Sign_Date=OI_CUSTOMER_SIGN_DATE
             where tsh.idtrx_id=OI_IDTRX_ID;
      --判断是否更新成功
      If Sql%Rowcount <= 0 Then
        p_Result:='发票头表更新数据失败，发票头ID：'||OI_IDTRX_ID||',不存在';
        Raise v_Base_Exception;
      End if;
      --update回写接口表信息
      update INTF_SO_TRX_HEADERS Isth set
             Isth.Status='0',
             Isth.Flag='1',
             Isth.Error_Info=null
             where Isth.Id=p_Oi_Header_Id;
      --处理完一张单提交一次事务
      Commit;
  Exception
    When v_Base_Exception Then
      p_Result := '失败，'||p_Result;
      Rollback;
      -- 回写接口表信息
      update INTF_SO_TRX_HEADERS Isth set
              Isth.Status='1',
              Isth.Flag='1',
              Isth.Error_Info=p_Result
              where Isth.Id=p_Oi_Header_Id;
      Commit;--提交事务
    When Others Then
      p_Result := '异常：' || Sqlerrm || Sqlcode || '. ERR:' || p_Result;
      Rollback;
      --回写接口表信息
      update INTF_SO_TRX_HEADERS Isth set
              Isth.Status='1',
              Isth.Flag='1',
              Isth.Error_Info=p_Result
              where Isth.Id=p_Oi_Header_Id;
      Commit;--提交事务
  End;
  ----------------------------------------------------------------------------------
  /**
  *循环开票申请单接口
  ***/
  ---------------------------------------------------------------------------------
  Procedure p_Invoice_Apply_Create_Cycle IS
     Cursor c_Oi_Header Is
         Select *
            From INTF_AR_INVOICE_APPLY_HEADER Irah
           Where Irah.Flag='0';
      r_Oi_Header c_Oi_Header%Rowtype;
      p_Result Varchar2(1000);
  Begin
     For r_Oi_Header In c_Oi_Header Loop
        p_Invoice_Apply_Create(r_Oi_Header.Oi_Header_Id,p_Result);
     End Loop;
  End;
  ----------------------------------------------------------------------------------
  /**
  *开票申请单接口程序
  *功能：新建开票申请单
  ***/
  ---------------------------------------------------------------------------------
  Procedure p_Invoice_Apply_Create(p_Oi_Header_Id In INTF_AR_INVOICE_APPLY_HEADER.OI_HEADER_ID%Type, --处理用的接口ID
                            p_Result           Out Varchar2 --返回值
                            ) IS
      PRAGMA AUTONOMOUS_TRANSACTION;
      --接口头表游标
      Cursor c_Oi_Header(c_Oi_Header_Id In INTF_AR_INVOICE_APPLY_HEADER.OI_HEADER_ID%Type) Is
         Select *
            From INTF_AR_INVOICE_APPLY_HEADER Irah
           Where Irah.Oi_Header_Id=c_Oi_Header_Id;
      r_Oi_Header c_Oi_Header%Rowtype;
      r_Oi_Header_Err c_Oi_Header%Rowtype;
      --接口行表游标
      Cursor c_Oi_Lines(c_Oi_Header_Id In INTF_AR_INVOICE_APPLY_HEADER.OI_HEADER_ID%Type) Is
         Select *
           From INTF_AR_INVOICE_APPLY_LINES Iral
          Where Iral.Oi_Header_Id=c_Oi_Header_Id;
      r_Oi_Lines c_Oi_Lines%Rowtype;
      oi_Sales_Center_Name Varchar2(100); --营销中心名称
      oi_Customer_Name Varchar2(100); --客户名称
      s_Invoice_Apply_id number; --序列的申请单ID
      oi_Invoice_Apply_Code VARCHAR2(100);--申请单编号

      ar_Conf_Lmit_Amount NUMBER(20,2);--配置信息每月结算金额上限
      ar_Conf_Lmit_Day number; --配置信息每月结算日期上限
      apply_Settle_Amount NUMBER(20,2);--申请单的总金额
      update_So_Header_Settle_Amount NUMBER(20,2);--财务单的金额
      cerrent_So_Settled_Amount NUMBER(20,2); --当月已结算总金额
      cerrent_Sysdate_Day_Tranc number; --当前系统时间
      soheader_invoice_apply_code VARCHAR2(100);--财务单已开申请单的编码
    Begin
      p_Result:='OK';
      oi_Invoice_Apply_Code:=null;
      --取接口头表的数据(打开游标)
      Open c_Oi_Header(p_Oi_Header_Id);
        Fetch c_Oi_Header Into r_Oi_Header;
        --判断是否取到接口头表数据
        If c_Oi_Header%Notfound Then
          p_Result:='接口头表ID:OI_HEADER_ID='||p_Oi_Header_Id||',找不到数据，制单失败';
          Raise v_Base_Exception;
        End If;
        --获取客户名称
        Begin
          Select Tch.Customer_Name
            Into oi_Customer_Name
          From t_Customer_Header Tch
          Where Tch.Customer_Id = r_Oi_Header.Customer_Id;
        Exception
          When No_Data_Found Then
            p_Result := '接口数据有误，客户ID' || r_Oi_Header.Customer_Id || '找不到';
          Raise v_Base_Exception;
        End;
        --获取营销中心名称
        Begin
          select u.name into oi_Sales_Center_Name
            from UP_ORG_UNIT u
            where u.UNIT_ID=r_Oi_Header.Sales_Center_Id
                  and u.entity_id=r_Oi_Header.Entity_Id;
        Exception
          When No_Data_Found then
            p_Result:='接口头表的营销中心Id:sales_Center_Id='||r_Oi_Header.Sales_Center_Id||'有误,获取中心名称失败';
            Raise v_Base_Exception;
        End;
        --获取应收配置的参数信息
        Begin
          select t.limt_day,
                 t.limt_amount Into
                 ar_Conf_Lmit_Day,
                 ar_Conf_Lmit_Amount
            from t_ar_conf t
           where t.entity_id = r_Oi_Header.Entity_Id
             and t.erp_ou = r_Oi_Header.Erp_Ou_Id
             and t.sales_center_id is null
             and t.customer_id is null;
        Exception
           When No_Data_Found then
            p_Result:='失败，接口头表的主体,Erp_Ou获取应收配置信息失败';
            Raise v_Base_Exception;
        End;
        --获取申请单号
        PKG_BD.P_GET_BILL_NO('ARAICODE',null,r_Oi_Header.Entity_Id,null,oi_Invoice_Apply_Code);
        If oi_Invoice_Apply_Code is null Then
            p_Result:='获取申请单号失败,接口数据oi_Header_id='||r_Oi_Header.Oi_Header_Id||',有误';
            Raise v_Base_Exception;
        End If;
        --取申请单头ID
        Select s_ar_invoice_apply_header.nextval Into s_Invoice_Apply_id From Dual;
        Begin
        --往申请单头表（t_ar_invoice_apply_header）新增申请单数据
          Insert Into t_ar_invoice_apply_header
          (INVOICE_APPLY_ID,
           INVOICE_APPLY_CODE,
           INVOICE_APPLY_STATUS,
           CREATED_BY,
           CREATION_DATE,
           APPROVED_BY,
           APPROVED_DATE,
           CUSTOMER_CODE,
           CUSTOMER_NAME,
           ENTITY_NAME,
           CENTER_NAME,
           AMOUNT,
           REMAEK,
           SALES_CENTER_ID,
           ENTITY_ID,
           CUSTOMER_ID,
           ERP_OU,
           SETTLE_BY,
           SETTLE_DATE,
           IS_SETTLE,
           SALES_MAIN_TYPE_ID,
           SOURCE_CODE,
           SOURCE_ID,
           SOURCE_SYSTEM,
           ATTRIBUTE3,
           ATTRIBUTE4
          )values(
           s_Invoice_Apply_id, --申请单头Id
           oi_Invoice_Apply_Code,--申请单编号
           '10',--制单类型
           r_Oi_Header.Created_By,--制单人
           trunc(sysdate,'DD'),--制单时间
           null,--审核人
           null,--审核时间
           r_Oi_Header.Customer_Code,--客户编码
           oi_Customer_Name,--客户名称
           null,--主体名称
           oi_Sales_Center_Name,--中心名称
           null,--申请单总金额
           r_Oi_Header.Remaek,--申请单备注
           r_Oi_Header.Sales_Center_Id,--中心ID
           r_Oi_Header.Entity_Id,--主体Id
           r_Oi_Header.Customer_Id,--客户ID
           r_Oi_Header.Erp_Ou_Id,--OU_ID
           NULL,--结算人
           null,--结算时间
           null,--结算标示
           null, --营销大类ID
           r_Oi_Header.Source_Code,  --来源编号
           r_Oi_Header.Source_Id,  --来源ID
           r_Oi_Header.Source_System,  --来源系统
           null,  --预留字段3
           null   --预留字段4
          );
        Exception
          When Others then
             p_Result:='往申请单头表添加数据失败，'||Sqlerrm ||'|'|| Sqlcode;
             Raise v_Base_Exception;
        End;
        apply_Settle_Amount:=0;--申请单的财务单总金额
        --遍历接口行表
        For r_Oi_Lines In c_Oi_Lines(p_Oi_Header_Id) Loop
           --检验财务单是否已开过申请单
           Begin
             select vso.invoice_apply_code into soheader_invoice_apply_code
               from v_ar_so_header_for_line vso
              where vso.so_header_id = r_Oi_Lines.So_Header_Id;
           Exception
              When No_Data_Found then
                 p_Result:='失败，接口表数据有误,系统不存在SO_HEADER_ID：'||r_Oi_Lines.So_Header_Id||'的财务单';
                 Raise v_Base_Exception;
           End;
           If soheader_invoice_apply_code is not null then
                 p_Result:='失败,单据号:'||r_Oi_Lines.So_Num
                            ||'的财务单已提交申请,不允许重复申请,申请单号:'||soheader_invoice_apply_code;
                 Raise v_Base_Exception;
           End If;
           --修改财务单invoice_apply_id
           update t_so_header Tsh set
               Tsh.Invoice_Apply_Id=s_Invoice_Apply_id
               Where Tsh.So_Num=r_Oi_Lines.So_Num and Tsh.So_Status='11'
                     and Tsh.Entity_Id=r_Oi_Lines.Entity_Id  and Tsh.Invoice_Apply_Id is null
                     and exists(select Tsd.So_Type_Extend_Id from t_so_type_extend Tsd
                                     where Tsd.bill_type_id=Tsh.Bill_Type_Id
                                     and Tsd.entity_id=Tsh.Entity_Id
                                     and Tsd.settle_flag='Y');
            If sql%Rowcount <= 0 then
               p_Result:='接口数据有误，单据号：'||r_Oi_Lines.So_Num||'，的财务单不符合开申请单';
               Raise v_Base_Exception;
            End If;
            --获取财务单金额
            Begin
             select (tsh.settle_amount*te.applied_plus_minus_flag)
               into update_So_Header_Settle_Amount
               from t_so_header tsh,t_so_type_extend te
              where tsh.bill_type_id=te.bill_type_id
                and tsh.entity_id=te.entity_id
                and tsh.so_header_id=r_Oi_Lines.So_Header_Id;
            Exception
              When No_Data_Found then
                 p_Result:='失败，接口表数据有误,获取SO_HEADER_ID：'||r_Oi_Lines.So_Header_Id||'的财务单的金额出错';
                 Raise v_Base_Exception;
            End;
            apply_Settle_Amount:=apply_Settle_Amount+update_So_Header_Settle_Amount;--所选财务单金额
            --更新接口行表
            update INTF_AR_INVOICE_APPLY_LINES Trs set
                   Trs.Flag='1',
                   Trs.Status='0',
                   Trs.Error_Info=null
              where Trs.Oi_Line_Id=r_Oi_Lines.Oi_Line_Id;
        End Loop;
      --判断是否超过每月结算金额上限或每月结算日期上限[已结算总金额考虑单据金额的正负情形 edited by zhoujg3 2017-02-05]
      select sum(Tso.Settle_Amount * te.applied_plus_minus_flag) into cerrent_So_Settled_Amount
       from t_so_header Tso,t_so_type_extend te --获取当月已结算金额
       where Tso.So_Status='12'
         and Tso.bill_type_id=te.bill_type_id
         and Tso.entity_id=te.entity_id
         and Tso.Entity_Id=r_Oi_Header.Entity_Id
         and Tso.Erp_Ou_Id=r_Oi_Header.Erp_Ou_Id
         and Tso.Settle_Date >=(select trunc(sysdate,'MONTH') from dual)
         and Tso.Settle_Date <=sysdate;
      Close c_Oi_Header;--(关闭游标)
      select to_char(sysdate, 'DD') Into cerrent_Sysdate_Day_Tranc from dual;--获取当天日期DD值
      --判断当前日期是否超过每月结算日期上限
      If ar_Conf_Lmit_Day is not null and cerrent_Sysdate_Day_Tranc > ar_Conf_Lmit_Day Then
         p_Result:='制单失败，当前日期已超过每月结算日期上限';
         Raise v_Base_Exception;
      End If;
      --判断已结算金额和所选财务单金额的总和是否超过每月结算金额上限
      If ar_Conf_Lmit_Amount is not null and apply_Settle_Amount+cerrent_So_Settled_Amount > ar_Conf_Lmit_Amount then
         p_Result:='制单失败，已结算金额和所选财务单金额的总和超过了结算金额上限('||ar_Conf_Lmit_Amount||')';
         Raise v_Base_Exception;
      End If;
      --修改申请单的金额
        update t_ar_invoice_apply_header Tah set
               Tah.Amount=apply_Settle_Amount
         where Tah.Invoice_Apply_Id=s_Invoice_Apply_id;
      --回写接口头表(制单成功)
        update INTF_AR_INVOICE_APPLY_HEADER Iar set
             Iar.Flag='1',
             Iar.Status='0',
             Iar.Attribute1=oi_Invoice_Apply_Code,
             Iar.Error_Info=null
             where Iar.Oi_Header_Id=p_Oi_Header_Id;
        Commit;--提交事务
    Exception
      When v_Base_Exception then
         p_Result:=p_Result||';'|| Sqlerrm || ';' || Sqlcode;
         rollback;
         --回写接口头表（制单失败）
         update INTF_AR_INVOICE_APPLY_HEADER Iars set
             Iars.Flag='1',
             Iars.Status='1',
             Iars.Error_Info=p_Result
             where Iars.Oi_Header_Id=p_Oi_Header_Id;
         --回写接口行表
         For r_Oi_Header_Err In c_Oi_Lines(p_Oi_Header_Id) Loop
             update INTF_AR_INVOICE_APPLY_LINES Irs set
             Irs.Flag='1',
             Irs.Status='1',
             Irs.Error_Info=p_Result
             where Irs.Oi_Line_Id=r_Oi_Header_Err.Oi_Line_Id;
         End Loop;
         Commit;--提交事务
      when Others then
         p_Result:= '异常：' || Sqlerrm || Sqlcode || '. ERR:' || p_Result;
         rollback;
         --回写接口头表（制单失败）
         update INTF_AR_INVOICE_APPLY_HEADER Iarb set
             Iarb.Flag='1',
             Iarb.Status='1',
             Iarb.Error_Info=p_Result
             where Iarb.Oi_Header_Id=p_Oi_Header_Id;
         --回写接口行表
         For r_Oi_Header_Err In c_Oi_Lines(p_Oi_Header_Id) Loop
             update INTF_AR_INVOICE_APPLY_LINES Irs set
             Irs.Flag='1',
             Irs.Status='1',
             Irs.Error_Info=p_Result
             where Irs.Oi_Line_Id=r_Oi_Header_Err.Oi_Line_Id;
         End Loop;
         Commit;--提交事务
    End;
-----------------------------------------------------------------------
/**
* 单独结算，申请送审检验程序
*  检验申请单下的销售单检验，红单与蓝单的关系，退货单与销售单的关系
*/
-----------------------------------------------------------------------
  Procedure p_Apply_So_Inspect(p_Invoice_Apply_Id In T_AR_INVOICE_APPLY_HEADER.Invoice_Apply_Id%Type, --申请单ID
                            p_Result           Out Varchar2 --返回值 
                            ) IS
    --获取申请单下的销售单游标
    Cursor c_Apply_So_Header(c_Invoice_Apply_Id In t_ar_invoice_apply_header.invoice_apply_id%Type) Is
       select * from t_so_header tsh where tsh.invoice_apply_id=c_Invoice_Apply_Id;
    r_Apply_So_Header c_Apply_So_Header%Rowtype; --游标c_Apply_So_Header的行  
    s_Invoice_Apply_Id t_so_header.invoice_apply_id%Type; --销售单获取的申请单Id 
    s_So_Status t_so_header.so_status%Type;--销售单的状态   
    vReturnCount Number;                   
  Begin
    p_Result:='OK';
    For r_Apply_So_Header In c_Apply_So_Header(p_Invoice_Apply_Id) Loop
      
       --内部关联交易客户必须完成关联物流对应的PO接收后才可结算 add 2019-5-17
        IF (NVL(r_Apply_So_Header.ENTITY_CUST_FLAG,PKG_SO_PUB.V_NO) = PKG_SO_PUB.V_YES AND (r_Apply_So_Header.ERP_LOGIST_RECEIVE_FLAG = PKG_SO_PUB.V_NO OR r_Apply_So_Header.ERP_LOGIST_RECEIVE_DATE IS NULL)) THEN
           p_Result := r_Apply_So_Header.BIZ_SRC_BILL_TYPE_NAME || '[' || r_Apply_So_Header.SO_NUM || ']还没有完成内部关联交易的PO签收，不可以结算！';
           RAISE v_Base_Exception; 
        END IF;
         
       --判断红单对应的蓝单是否结算或者在同一申请单中
       If r_Apply_So_Header.Orig_So_Num is not null then 
          select tsh.invoice_apply_id,tsh.so_status 
              into s_Invoice_Apply_Id,s_So_Status
          from t_so_header tsh where tsh.so_num =r_Apply_So_Header.Orig_So_Num;
          --蓝单没结算和不在申请单中,则检验不通过,提示：单据xxxx对应的蓝单没结算,请先结算蓝单。
          if s_So_Status<>'12' and nvl(s_Invoice_Apply_Id,-1) <> r_Apply_So_Header.Invoice_Apply_Id then
            p_Result:='单据:'||r_Apply_So_Header.So_Num||'对应的蓝单:'||
                          r_Apply_So_Header.Orig_So_Num||'未结算,请先结算蓝单';
            Raise v_Base_Exception;              
          end if;
       end If;
       --判断有源单的单据，其源单是是否在同一申请中或已结算
       If r_Apply_So_Header.Return_Orig_So_Num is not null and r_Apply_So_Header.Return_Mode='2' then
          select count(*) into vReturnCount 
             from t_so_header tsh where tsh.so_num=r_Apply_So_Header.Return_Orig_So_Num;
          --有源头单的单据结算，源单未结算和不在申请单中，则检验不通过,提示：单据xxx对应源单未结算,请先结算源单。
          if vReturnCount>0 then
             select tsh.invoice_apply_id,tsh.so_status
                 into s_Invoice_Apply_Id,s_So_Status 
             from t_so_header tsh where tsh.so_num=r_Apply_So_Header.Return_Orig_So_Num;
             --判断不通过,则抛出异常
             if s_So_Status<>'12' and nvl(s_Invoice_Apply_Id,-1)<>r_Apply_So_Header.Invoice_Apply_Id then 
                p_Result:='单据:'||r_Apply_So_Header.So_Num||'对应的源单:'||
                          r_Apply_So_Header.Return_Orig_So_Num||'未结算,请先结算源单';
                Raise v_Base_Exception;
             end if;
          end if;
       end If;
    End Loop;
  Exception
    when Others then
      p_Result:= '提示:' || p_Result;
  End;                          
--开票申请单接口程序 ，新增申请单
  Procedure p_Invoice_Apply_Create_ECM(
                            p_Oi_Header_Id In INTF_AR_INVOICE_APPLY_HEADER.OI_HEADER_ID%Type, --处理用的接口ID
                            P_INVOICE_APPLY_STATUS IN T_AR_INVOICE_APPLY_HEADER.INVOICE_APPLY_STATUS%TYPE,--开票申请单单据状态
                            p_Result           Out Varchar2 --返回值
                            ) IS
      --PRAGMA AUTONOMOUS_TRANSACTION;
      --接口头表游标
      Cursor c_Oi_Header(c_Oi_Header_Id In INTF_AR_INVOICE_APPLY_HEADER.OI_HEADER_ID%Type) Is
         Select *
            From INTF_AR_INVOICE_APPLY_HEADER Irah
           Where Irah.Oi_Header_Id=c_Oi_Header_Id;
      r_Oi_Header c_Oi_Header%Rowtype;
      r_Oi_Header_Err c_Oi_Header%Rowtype;
      --接口行表游标
      Cursor c_Oi_Lines(c_Oi_Header_Id In INTF_AR_INVOICE_APPLY_HEADER.OI_HEADER_ID%Type) Is
         Select *
           From INTF_AR_INVOICE_APPLY_LINES Iral
          Where Iral.Oi_Header_Id=c_Oi_Header_Id;
      r_Oi_Lines c_Oi_Lines%Rowtype;
      oi_Sales_Center_Name Varchar2(100); --营销中心名称
      oi_Customer_Name Varchar2(100); --客户名称
      s_Invoice_Apply_id number; --序列的申请单ID
      oi_Invoice_Apply_Code VARCHAR2(100);--申请单编号

      ar_Conf_Lmit_Amount NUMBER(20,2);--配置信息每月结算金额上限
      ar_Conf_Lmit_Day number; --配置信息每月结算日期上限
      apply_Settle_Amount NUMBER(20,2);--申请单的总金额
      update_So_Header_Settle_Amount NUMBER(20,2);--财务单的金额
      cerrent_So_Settled_Amount NUMBER(20,2); --当月已结算总金额
      cerrent_Sysdate_Day_Tranc number; --当前系统时间
      soheader_invoice_apply_code VARCHAR2(100);--财务单已开申请单的编码
    Begin
      p_Result:='OK';
      oi_Invoice_Apply_Code:=null;
      --取接口头表的数据(打开游标)
      Open c_Oi_Header(p_Oi_Header_Id);
        Fetch c_Oi_Header Into r_Oi_Header;
        --判断是否取到接口头表数据
        If c_Oi_Header%Notfound Then
          p_Result:='接口头表ID:OI_HEADER_ID='||p_Oi_Header_Id||',找不到数据，制单失败';
          Raise v_Base_Exception;
        End If;
        --获取客户名称
        Begin
          Select Tch.Customer_Name
            Into oi_Customer_Name
          From t_Customer_Header Tch
          Where Tch.Customer_Id = r_Oi_Header.Customer_Id;
        Exception
          When No_Data_Found Then
            p_Result := '接口数据有误，客户ID' || r_Oi_Header.Customer_Id || '找不到';
          Raise v_Base_Exception;
        End;
        --获取营销中心名称
        Begin
          select u.name into oi_Sales_Center_Name
            from UP_ORG_UNIT u
            where u.UNIT_ID=r_Oi_Header.Sales_Center_Id
                  and u.entity_id=r_Oi_Header.Entity_Id;
        Exception
          When No_Data_Found then
            p_Result:='接口头表的营销中心Id:sales_Center_Id='||r_Oi_Header.Sales_Center_Id||'有误,获取中心名称失败';
            Raise v_Base_Exception;
        End;
        --获取应收配置的参数信息
        Begin
          select t.limt_day,
                 t.limt_amount Into
                 ar_Conf_Lmit_Day,
                 ar_Conf_Lmit_Amount
            from t_ar_conf t
           where t.entity_id = r_Oi_Header.Entity_Id
             and t.erp_ou = r_Oi_Header.Erp_Ou_Id
             and t.sales_center_id is null
             and t.customer_id is null;
        Exception
           When No_Data_Found then
            p_Result:='失败，接口头表的主体,Erp_Ou获取应收配置信息失败';
            Raise v_Base_Exception;
        End;
        --获取申请单号
        PKG_BD.P_GET_BILL_NO('ARAICODE',null,r_Oi_Header.Entity_Id,null,oi_Invoice_Apply_Code);
        If oi_Invoice_Apply_Code is null Then
            p_Result:='获取申请单号失败,接口数据oi_Header_id='||r_Oi_Header.Oi_Header_Id||',有误';
            Raise v_Base_Exception;
        End If;
        --取申请单头ID
        Select s_ar_invoice_apply_header.nextval Into s_Invoice_Apply_id From Dual;
        Begin
        --往申请单头表（t_ar_invoice_apply_header）新增申请单数据
          Insert Into t_ar_invoice_apply_header
          (INVOICE_APPLY_ID,
           INVOICE_APPLY_CODE,
           INVOICE_APPLY_STATUS,
           CREATED_BY,
           CREATION_DATE,
           APPROVED_BY,
           APPROVED_DATE,
           CUSTOMER_CODE,
           CUSTOMER_NAME,
           ENTITY_NAME,
           CENTER_NAME,
           AMOUNT,
           REMAEK,
           SALES_CENTER_ID,
           ENTITY_ID,
           CUSTOMER_ID,
           ERP_OU,
           SETTLE_BY,
           SETTLE_DATE,
           IS_SETTLE,
           SALES_MAIN_TYPE_ID,
           SOURCE_CODE,
           SOURCE_ID,
           SOURCE_SYSTEM,
           ATTRIBUTE3,
           ATTRIBUTE4
          )values(
           s_Invoice_Apply_id, --申请单头Id
           oi_Invoice_Apply_Code,--申请单编号
           P_INVOICE_APPLY_STATUS,--制单类型 10: 制单; 20: 送审; 11: 已审核;12: 已结算
           r_Oi_Header.Created_By,--制单人
           trunc(sysdate,'DD'),--制单时间
           null,--审核人
           null,--审核时间
           r_Oi_Header.Customer_Code,--客户编码
           oi_Customer_Name,--客户名称
           null,--主体名称
           oi_Sales_Center_Name,--中心名称
           null,--申请单总金额
           r_Oi_Header.Remaek,--申请单备注
           r_Oi_Header.Sales_Center_Id,--中心ID
           r_Oi_Header.Entity_Id,--主体Id
           r_Oi_Header.Customer_Id,--客户ID
           r_Oi_Header.Erp_Ou_Id,--OU_ID
           NULL,--结算人
           null,--结算时间
           null,--结算标示
           null, --营销大类ID
           r_Oi_Header.Source_Code,  --来源编号
           r_Oi_Header.Source_Id,  --来源ID
           r_Oi_Header.Source_System,  --来源系统
           null,  --预留字段3
           null   --预留字段4
          );
        Exception
          When Others then
             p_Result:='往申请单头表添加数据失败，'||Sqlerrm ||'|'|| Sqlcode;
             Raise v_Base_Exception;
        End;
        apply_Settle_Amount:=0;--申请单的财务单总金额
        --遍历接口行表
        For r_Oi_Lines In c_Oi_Lines(p_Oi_Header_Id) Loop
           --检验财务单是否已开过申请单
           Begin
             select vso.invoice_apply_code into soheader_invoice_apply_code
               from v_ar_so_header_for_line vso
              where vso.so_header_id = r_Oi_Lines.So_Header_Id;
           Exception
              When No_Data_Found then
                 p_Result:='失败，接口表数据有误,系统不存在SO_HEADER_ID：'||r_Oi_Lines.So_Header_Id||'的财务单';
                 Raise v_Base_Exception;
           End;
           If soheader_invoice_apply_code is not null then
                 p_Result:='失败,单据号:'||r_Oi_Lines.So_Num
                            ||'的财务单已提交申请,不允许重复申请,申请单号:'||soheader_invoice_apply_code;
                 Raise v_Base_Exception;
           End If;
           --修改财务单invoice_apply_id
           update t_so_header Tsh set
               Tsh.Invoice_Apply_Id=s_Invoice_Apply_id
               Where Tsh.So_Num=r_Oi_Lines.So_Num and Tsh.So_Status='11'
                     and Tsh.Entity_Id=r_Oi_Lines.Entity_Id  and Tsh.Invoice_Apply_Id is null
                     and exists(select Tsd.So_Type_Extend_Id from t_so_type_extend Tsd
                                     where Tsd.bill_type_id=Tsh.Bill_Type_Id
                                     and Tsd.entity_id=Tsh.Entity_Id
                                     and Tsd.settle_flag='Y');
            If sql%Rowcount <= 0 then
               p_Result:='接口数据有误，单据号：'||r_Oi_Lines.So_Num||'，的财务单不符合开申请单';
               Raise v_Base_Exception;
            End If;
            --获取财务单金额
            Begin
             select (tsh.settle_amount*te.applied_plus_minus_flag)
               into update_So_Header_Settle_Amount
               from t_so_header tsh,t_so_type_extend te
              where tsh.bill_type_id=te.bill_type_id
                and tsh.entity_id=te.entity_id
                and tsh.so_header_id=r_Oi_Lines.So_Header_Id;
            Exception
              When No_Data_Found then
                 p_Result:='失败，接口表数据有误,获取SO_HEADER_ID：'||r_Oi_Lines.So_Header_Id||'的财务单的金额出错';
                 Raise v_Base_Exception;
            End;
            apply_Settle_Amount:=apply_Settle_Amount+update_So_Header_Settle_Amount;--所选财务单金额
            --更新接口行表
            update INTF_AR_INVOICE_APPLY_LINES Trs set
                   Trs.Flag='1',
                   Trs.Status='0',
                   Trs.Error_Info=null
              where Trs.Oi_Line_Id=r_Oi_Lines.Oi_Line_Id;
        End Loop;
      --判断是否超过每月结算金额上限或每月结算日期上限[已结算总金额考虑单据金额的正负情形 edited by zhoujg3 2017-02-05]
      select sum(Tso.Settle_Amount * te.applied_plus_minus_flag) into cerrent_So_Settled_Amount
       from t_so_header Tso,t_so_type_extend te --获取当月已结算金额
       where Tso.So_Status='12'
         and Tso.bill_type_id=te.bill_type_id
         and Tso.entity_id=te.entity_id
         and Tso.Entity_Id=r_Oi_Header.Entity_Id
         and Tso.Erp_Ou_Id=r_Oi_Header.Erp_Ou_Id
         and Tso.Settle_Date >=(select trunc(sysdate,'MONTH') from dual)
         and Tso.Settle_Date <=sysdate;
      Close c_Oi_Header;--(关闭游标)
      select to_char(sysdate, 'DD') Into cerrent_Sysdate_Day_Tranc from dual;--获取当天日期DD值
      --判断当前日期是否超过每月结算日期上限
      If ar_Conf_Lmit_Day is not null and cerrent_Sysdate_Day_Tranc > ar_Conf_Lmit_Day Then
         p_Result:='制单失败，当前日期已超过每月结算日期上限';
         Raise v_Base_Exception;
      End If;
      --判断已结算金额和所选财务单金额的总和是否超过每月结算金额上限
      If ar_Conf_Lmit_Amount is not null and apply_Settle_Amount+cerrent_So_Settled_Amount > ar_Conf_Lmit_Amount then
         p_Result:='制单失败，已结算金额和所选财务单金额的总和超过了结算金额上限('||ar_Conf_Lmit_Amount||')';
         Raise v_Base_Exception;
      End If;
      --修改申请单的金额
        update t_ar_invoice_apply_header Tah set
               Tah.Amount=apply_Settle_Amount
         where Tah.Invoice_Apply_Id=s_Invoice_Apply_id;
      --回写接口头表(制单成功)
        update INTF_AR_INVOICE_APPLY_HEADER Iar set
             Iar.Flag='1',
             Iar.Status='0',
             Iar.Attribute1=oi_Invoice_Apply_Code,
             Iar.Error_Info=null
             where Iar.Oi_Header_Id=p_Oi_Header_Id;
        --Commit;--提交事务
    Exception
      When v_Base_Exception then
         p_Result:=p_Result||';'|| Sqlerrm || ';' || Sqlcode;
         rollback;
         --回写接口头表（制单失败）
         update INTF_AR_INVOICE_APPLY_HEADER Iars set
             Iars.Flag='1',
             Iars.Status='1',
             Iars.Error_Info=p_Result
             where Iars.Oi_Header_Id=p_Oi_Header_Id;
         --回写接口行表
         For r_Oi_Header_Err In c_Oi_Lines(p_Oi_Header_Id) Loop
             update INTF_AR_INVOICE_APPLY_LINES Irs set
             Irs.Flag='1',
             Irs.Status='1',
             Irs.Error_Info=p_Result
             where Irs.Oi_Line_Id=r_Oi_Header_Err.Oi_Line_Id;
         End Loop;
         --Commit;--提交事务
      when Others then
         p_Result:= '异常：' || Sqlerrm || Sqlcode || '. ERR:' || p_Result;
         rollback;
         --回写接口头表（制单失败）
         update INTF_AR_INVOICE_APPLY_HEADER Iarb set
             Iarb.Flag='1',
             Iarb.Status='1',
             Iarb.Error_Info=p_Result
             where Iarb.Oi_Header_Id=p_Oi_Header_Id;
         --回写接口行表
         For r_Oi_Header_Err In c_Oi_Lines(p_Oi_Header_Id) Loop
             update INTF_AR_INVOICE_APPLY_LINES Irs set
             Irs.Flag='1',
             Irs.Status='1',
             Irs.Error_Info=p_Result
             where Irs.Oi_Line_Id=r_Oi_Header_Err.Oi_Line_Id;
         End Loop;
         --Commit;--提交事务
    End;
end PKG_AR_TRX;
/

