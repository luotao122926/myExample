create PACKAGE PKG_PMT_CHARGES IS
  ----------------------------------------------------------------------
  -- Author  : liangym2
  -- Created : 2018-04-03
  --add by liangym2 对字符串按指定字节数长度截取，避免SUBSTRB函数的乱码问题 
  ----------------------------------------------------------------------
  FUNCTION F_TRUNCB_VARCHAR
  --
  (IS_STR  VARCHAR2, --
   IN_BLEN          NUMBER
   ) RETURN VARCHAR2;
  ----------------------------------------------------------------------
  -- Author  : liyuanji
  -- Created : 2015-01-15
  -- Purpose : 推广物料采购支付（EMS）
  --CHARGES_TYPE 来源类型，保证EMS唯一，不要和其他模块写重复，默认10为推广物料
  --EMS_FLAG
  --IMPORT_EMS_TIME
  ----------------------------------------------------------------------
  PROCEDURE P_CHARGES_PAYMENT(I_ACCOUNT_HEAD_ID IN NUMBER, --推广物料结算批ID
                              I_ACCOUNT         IN VARCHAR2, --登录账号
                              O_RESULT          OUT VARCHAR2, --返回错误码
                              O_RESULT_MSG      OUT VARCHAR2 --返回错误信息
                              );
  ----------------------------------------------------------------------
  -- AUTHOR  : liyuanji
  -- CREATED : 2015-01-20
  -- PURPOSE : 获取推广物料采购EMS接口处理结果
  ----------------------------------------------------------------------
  PROCEDURE P_CHARGES_STATUS(O_RESULT     OUT VARCHAR2, --返回错误码
                             O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                             );
  ----------------------------------------------------------------------
  -- AUTHOR  : liyuanji
  -- CREATED : 2015-01-21
  -- PURPOSE : 获取推广物料采购结算批支付结果
  ----------------------------------------------------------------------
  PROCEDURE P_CHARGES_PAYMENT_RESULT(O_RESULT     OUT VARCHAR2, --返回错误码
                                     O_RESULT_MSG OUT VARCHAR2 --返回错误信息
                                     );
  ----------------------------------------------------------------------
  -- Author  : LIANGYM2
  -- Created : 2016-10-19
  -- Purpose : 推广物料结算批预付款检查
  ----------------------------------------------------------------------
  PROCEDURE P_CHECK_EC_LOAN_INFO(IN_ACCOUNT_HEAD_ID IN NUMBER, --推广物料结算批ID,
                                 OS_RESULT          OUT VARCHAR2, --返回错误码
                                 OS_RESULT_MSG      OUT VARCHAR2, --返回错误信息
                                 IR_ACCOUNT_HEAD    IN T_PMT_ACCOUNT_HEAD%ROWTYPE DEFAULT NULL,
                                 IS_PUB_FIN_SYS     IN VARCHAR2 DEFAULT NULL);
  ----------------------------------------------------------------------
  -- Author  : ex_zhangka
  -- Created : 2019-02-27
  -- Purpose : 推广物料采购支付（EMS）
  --CHARGES_TYPE 来源类型，保证EMS唯一，不要和其他模块写重复，默认10为推广物料
  --EMS_FLAG
  --IMPORT_EMS_TIME
  ----------------------------------------------------------------------
  PROCEDURE P_CHARGES_PAYMENT_CONTRACT(I_ACCOUNT_HEAD_ID IN NUMBER, --推广物料结算批ID
                                       I_ACCOUNT         IN VARCHAR2, --登录账号
                                       O_RESULT          OUT VARCHAR2, --返回错误码
                                       O_RESULT_MSG      OUT VARCHAR2 --返回错误信息
                                      );

END PKG_PMT_CHARGES;
/

