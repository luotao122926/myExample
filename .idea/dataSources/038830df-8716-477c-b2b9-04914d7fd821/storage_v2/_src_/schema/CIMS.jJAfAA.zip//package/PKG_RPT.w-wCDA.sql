create PACKAGE      PKG_RPT AS
  ------------------------------------------------------------------------------------------------
  --                                                                                            --
  --  报表后台包                                                                                 --
  --                                                                                            --
  --                                                                 --
  ------------------------------------------------------------------------------------------------
  /*
  2016-5-6 梁学荣
  创建报表后台包。
  2016-8-17 梁学荣
  优化生成报表性能：报表数据先写中间表，再通过中间表更新到报表中
  2016-8-24 梁学荣
  增加客户合并关系的数据合并统计处理。
  2017-1-5 梁学荣
  P_RECAL_RPT：增加锁定处理
  P_INIT_RPT_RESULT：增加锁定处理
  2017-6-2 梁学荣
  P_SET_RPT_RESULT_DETAIL：计算当前值时，增加空调按0处理
  2017-11-16 梁学荣
  P_BUILD_ENTITY_REPORT：修正没有使用主体条件取报表周期的问题
  */

  -----------------------------------------------------------------------------
  --      初始报表周期                                             --
  -----------------------------------------------------------------------------
  PROCEDURE P_INIT_PERIOD(
    IS_PERIOD_TYPE            IN  VARCHAR2 --周期类型
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,ID_BEGIN_DATE            IN  DATE     --起始日期
    ,ID_END_DATE              IN  DATE     --终止日期
    ,IN_PARENT_PERIOD_ID      IN  NUMBER   --上级周期ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --操作用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -----------------------------------------------------------------------------
  --  按主体计算报表                                                     --
  -----------------------------------------------------------------------------
  PROCEDURE P_BUILD_ENTITY_REPORT(
    IN_RPT_DEFINE_ID          IN  NUMBER   --报表定义ID
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,ID_RESULT_DATE           IN  DATE     --计算报表结果日期
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -----------------------------------------------------------------------------
  --  自动计算报表，通过JOB调用                                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_BUILD_REPORT;

  -----------------------------------------------------------------------------
  --  重算报表，通过JOB调用                                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_RECAL_RPT;

  -----------------------------------------------------------------------------
  --  重算报表调整项                                      --
  -----------------------------------------------------------------------------
  PROCEDURE P_RECAL_ADJUST(
    IN_RPT_RESULT_ID          IN  NUMBER   --报表结果ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );
  
  -----------------------------------------------------------------------------
  --  报表审核                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_CHECK_RPT(
    IN_RPT_RESULT_ID          IN  NUMBER   --报表结果ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -----------------------------------------------------------------------------
  --  报表取消审核                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_UNCHECK_RPT(
    IN_RPT_RESULT_ID          IN  NUMBER   --报表结果ID
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -----------------------------------------------------------------------------
  --  汇总竖放报表，写到中间表中，返回报表ID，从T_BD_RPT_SUM_DETAIL获取对应的报表结果                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_SUM_RPT_DETAIL(
    IN_RPT_DEFINE_ID          IN  NUMBER   --报表定义ID
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,IN_RPT_PERIOD_ID         IN  NUMBER   --报表周期ID
    ,IN_SALES_CENTER_ID       IN  NUMBER   --营销中心ID
    ,IS_GROUP_BY              IN  VARCHAR2 --分组汇总字段（不需写别名）              
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,ON_SUM_RPT_ID            OUT NUMBER   --成功则返回汇总报表ID，否则返回-1
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

  -----------------------------------------------------------------------------
  --  汇总横放报表，写到中间表中，返回报表ID，从T_BD_RPT_SUM_TRAVERSE获取对应的报表结果                                    --
  -----------------------------------------------------------------------------
  PROCEDURE P_SUM_RPT_TRAVERSE(
    IN_RPT_DEFINE_ID          IN  NUMBER   --报表定义ID
    ,IN_ENTITY_ID             IN  NUMBER   --主体ID
    ,IN_RPT_PERIOD_ID         IN  NUMBER   --报表周期ID
    ,IN_SALES_CENTER_ID       IN  NUMBER   --营销中心ID
    ,IS_GROUP_BY              IN  VARCHAR2 --分组汇总字段（不需写别名）              
    ,IS_STAT_WAY              IN  VARCHAR2 --统计方式，SUM:累计；CUR:当前            
    ,IS_USER_ACCOUNT          IN  VARCHAR2 --用户账号
    ,ON_SUM_RPT_ID            OUT NUMBER   --成功则返回汇总报表ID，否则返回-1
    ,OS_MESSAGE               OUT VARCHAR2 --成功则返回“OK”，否则返回出错信息
  );

END PKG_RPT;
/

