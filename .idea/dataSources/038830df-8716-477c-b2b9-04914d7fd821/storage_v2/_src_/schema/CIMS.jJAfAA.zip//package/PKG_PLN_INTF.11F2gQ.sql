create Package Pkg_Pln_Intf Is

  ----------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2014-07-23 08:55:53
  -- Purpose : 计划订单接口包
  ----------------------------------------------------------------------

  ----------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2014-07-23 08:55:53
  -- Purpose : 外部系统调用接口过程，检查数据是否正确
  ----------------------------------------------------------------------
  Procedure p_Chk_Cus_Order(p_Intf_Id In Number, p_Result Out Varchar2);

  ----------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2014-07-23 08:55:53
  -- Purpose : 生成客户订单数据
  ----------------------------------------------------------------------
  Procedure p_Create_Cus_Order(p_Intf_Id In Number, p_Result Out Varchar2);
  
  ----------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2015-01-20 08:55:53
  -- Purpose : JOB更新产品产地信息
  ----------------------------------------------------------------------
  Procedure p_Create_Item_Producing_Job;

  ----------------------------------------------------------------------
  -- Author  : NICRO.LI
  -- Created : 2014-07-29 08:55:53
  -- Purpose : 工单与订单匹配关系接口数据写入正式表
  ----------------------------------------------------------------------
  Procedure p_Create_Wip_Order_Relation(p_Entity_Id       In Number, --主体ID
                                        p_Organization_Id In Number, --组织ID
                                        p_User_Code       In Varchar2,
                                        p_Result          Out Varchar2);

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-08-28 17:55:00
  -- Purpose : 月计划业务表写入接口表
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_INTF_DOMESTIC_FORCAST(P_HEAD_ID     IN NUMBER, --月计划表头
                                           P_USER_CODE   IN VARCHAR2, --登录用户名
                                           P_RESULT      OUT VARCHAR2);
  ----------------------------------------------------------------------
  -- Author  : zhouly2
  -- Created : 2018-09-18
  -- Purpose : 月计划业务表写入接口表-（部分事业部需要新增字段）
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_INTF_DOMESTIC_FOR_NEW(P_HEAD_ID     IN NUMBER, --月计划表头
                                           P_USER_CODE   IN VARCHAR2, --登录用户名
                                           P_RESULT      OUT VARCHAR2);

  -- Author  : fenggq
  -- Created : 2014-08-30 13:51:00
  -- Purpose : 月计划订单业务表写入接口表
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_INTF_MONTH_PLAN(P_HEAD_ID      IN NUMBER, --月计划订单表头
                                     P_USER_CODE    IN VARCHAR2, --登录用户名
                                     P_SEND_STATUS  IN VARCHAR2, --引APS状态
                                     P_RESULT       OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-09-01 21:37:00
  -- Purpose : 周排产订单业务表写入接口表
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_INTF_WEEK_ORDER(P_HEAD_ID       IN NUMBER, --周排产订单表头
                                     P_ORDER_TYPE_ID IN NUMBER, --周排产类型ID
                                     P_USER_CODE     IN VARCHAR2, --登录用户名
                                     P_RESULT        OUT Varchar2
                                     );
                                     
  ----------------------------------------------------------------------
  -- Author  : Nicro.Li
  -- Created : 2016-09-05 21:37:00
  -- Purpose : 订单调整单写入APS周订单接口表
  ----------------------------------------------------------------------
  Procedure p_Create_Adjust_Week_Order(p_Adjust_Haed_Id       In Number, --订单调整表
                                       p_Order_Type_Id In Number, --周排产类型ID
                                       p_User_Code     In Varchar2, --登录用户名
                                       p_Result        Out Varchar2
                                       );

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-12-03 16:12:00
  -- Purpose : 更新产销平衡信息
  ----------------------------------------------------------------------
  PROCEDURE P_UPDATE_PROD_SALES_BALANCE(P_COLL_ORD_HEAD_ID IN NUMBER,   --订单类型ID
                                        P_PERIOD_ID        IN NUMBER,   --订单周期ID
                                        P_ENTITY_ID        IN NUMBER,   --主体ID
                                        P_RESULT           OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-01-14 15:14:00
  -- Purpose : 销售预测接口表写入业务表
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_SALES_FORECAST(P_TRX_NO IN VARCHAR2, --流水号
                                    P_RESULT OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-01-17 16:18:00
  -- Purpose : 周排产订单业务表写入申请订单承诺接口表
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_APPLY_PROMISED(P_ORDER_FLAG     IN NUMBER, --订单标识
                                    P_ORDER_HEAD_ID  IN NUMBER, --订单头ID
                                    P_PROMISED_MODEL IN VARCHAR2, --承诺模式（120：首次承诺或再次承诺；130：完成承诺时把未引入承诺的订单行均引入承诺）
                                    P_USER_CODE      IN VARCHAR2, --登录用户名
                                    P_RESULT         OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-01-22 20:24:00
  -- Purpose : 更新订单行
  ----------------------------------------------------------------------
  PROCEDURE P_UPDATE_ORDER_LINE(P_PROMISED_ID IN NUMBER, --申请订单承诺ID
                                P_RESULT      OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2015-03-20 15:15:00
  -- Purpose : 销售任务横表转换纵表
  ----------------------------------------------------------------------
  PROCEDURE P_ST_CHANGE_ST_STATISTICS(P_ORDER_TYPE_ID     IN NUMBER,   --订单类型ID
                                      P_PERIOD_ID         IN NUMBER,   --订单周期
                                      P_SALES_MAIN_TYPE   IN VARCHAR2, --营销大类
                                      P_ENTITY_ID         IN NUMBER,   --主体ID
                                      P_CREATED_BY        IN VARCHAR2, --创建人
                                      P_RESULT            OUT VARCHAR2);

  ----------------------------------------------------------------------
  -- Author  : fenggq
  -- Created : 2014-04-10 09:58:00
  -- Purpose : 校验订单承诺产品生命周期
  ----------------------------------------------------------------------
  PROCEDURE P_CHECK_ITEM_LIFE_CYCLE(P_ORDER_FLAG     IN NUMBER, --订单标识
                                    P_ORDER_HEAD_ID  IN NUMBER, --订单头ID
                                    P_ENTITY_ID      IN NUMBER, --主体ID
                                    P_RESULT         OUT VARCHAR2);
  
  ----------------------------------------------------------------------
  -- Author  : hejy3
  -- Created : 2016-5-23 
  -- Purpose : 获取预计交付期间
  ----------------------------------------------------------------------
  FUNCTION f_get_consignment_stage(p_Walkthrough_Date          IN DATE,
                                   p_Estimate_Consignment_Date IN DATE)
    RETURN VARCHAR2;
  
  ----------------------------------------------------------------------
  -- Author  : ex_zhangcc
  -- Created : 2015-12-14
  -- Purpose : T+3预排更新订单行表
  ----------------------------------------------------------------------
  PROCEDURE P_T3_upOrder_line(P_walkThrough_batch    In Varchar2, --预排批次
                              P_user_code            In varchar2, --用户
                              P_RESULT               OUT Varchar2--返回结果
                              );
  ----------------------------------------------------------------------
  -- Author  : ex_zhangcc
  -- Created : 2015-12-30
  -- Purpose : T+3预排发送写入接口表
  ----------------------------------------------------------------------
  PROCEDURE P_Insert_Order_Walkthrg_Send(P_period_code In Varchar2, --周期ID
                              p_sales_main_type      In varchar2, --大类
                              P_batch_id             In Number,  --批次
                              p_user_code            In varchar2,--用户
                              p_entity_id            In Number, --主体ID
                              p_walkthrouth_batch    Out Varchar2,--预排批次
                              P_RESULT               OUT Varchar2--返回结果
                              );
                              
  -----------------------------------------------------------------------------
  -- AUTHOR  : hejy3
  -- CREATED : 2016-4-12
  -- PURPOSE : 预排汇总数据引入预排接口
  -----------------------------------------------------------------------------
  PROCEDURE p_Wt_Collect_Into_Wt_Intf(p_Entity_Id IN NUMBER, --主体ID
                                      p_Period_Code IN VARCHAR2, --周期编码
                                      p_User_Code IN VARCHAR2, --用户
                                      p_Walkthrouth_Batch in Out Varchar2, --预排批次
                                      p_Result            Out Varchar2 --返回结果
                                      );                            
 
----------------------------------------------------------------------
  -- Author  : Nicro.Li
  -- Created : 2016-08-13
  -- Purpose : 提货订单汇总写入APS预排接口
  ----------------------------------------------------------------------
  Procedure p_LgCollect_Walkthrg_Send(p_Batch_Code       In Varchar2, --提货订单汇总头ID
                                      p_Entity_Id        In Number, --主体ID
                                      p_Period_Code      In Varchar2, --周期编码
                                      p_User_Code        In Varchar2, --用户
                                      p_Result           Out Varchar2 --返回结果
                                      );
  ----------------------------------------------------------------------
  -- Author  : ex_dengjh
  -- Created : 2017-04-10
  -- Purpose : 更新未处理的月度产能接口数据版本
  ----------------------------------------------------------------------                                     
  Procedure P_UPD_INTF_CAPA_DATA_VERSION(IN_DATA_VERSION in varchar2);
  ----------------------------------------------------------------------
  -- Author  : ex_dengjh
  -- Created : 2017-04-10
  -- Purpose : 更新接口数据到月剩余产能接口表
  ----------------------------------------------------------------------                                     
  Procedure P_INTF_CREATE_REMAIN_CAPACITY(IN_DATA_VERSION in varchar2);
  ----------------------------------------------------------------------
  -- Author  : lilh6
  -- Created : 2017-09-14 
  -- Purpose : 定制订单明细写接口表
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_INTF_LG_ORDER_TO_OCM(P_ENTITY_ID IN NUMBER, --主体ID
                                          P_RESULT    OUT VARCHAR2);
  ----------------------------------------------------------------------
  -- Author  : lilh6
  -- Created : 2018-1-24 
  -- Purpose : 定制订单信息写推送LMS接口表
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_INTF_LG_ORDER_TO_LMS(P_ENTITY_ID IN NUMBER, --主体ID
                                          P_RESULT    OUT VARCHAR2);
  ----------------------------------------------------------------------
  -- Author  : lilh6
  -- Created : 2018-1-31
  -- Purpose : 超期订单信息写接口表
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_INTF_LG_OVERDUE_ORDER(P_ENTITY_ID IN NUMBER, --主体ID
                                           --P_FLAG      IN VARCHAR2, --线上线下标志
                                           P_RESULT    OUT VARCHAR2);
  ----------------------------------------------------------------------
  -- Author  : lilh6
  -- Created : 2018-4-10
  -- Purpose : 写入产品选配信息
  ----------------------------------------------------------------------
  PROCEDURE P_CREATE_ITEM_MATCH_RELATION( P_RESULT    OUT VARCHAR2);  
                 
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-07-04
  *     创建者：周建刚
  *   功能说明：批量处理预约信息。
  *             按照中心+客户+地址+预约日期+客户预约单号维度汇总生成IMS预约单号
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_BOOK_INFO_TO_BATCH(P_BATCH_ID         IN NUMBER,   --批处理ID
                                 P_USER_CODE        IN VARCHAR2, --操作用户编码
                                 P_BOOK_NUM_RESULT  OUT VARCHAR2, --该批次生成的预约单号
                                 P_RESULT           OUT NUMBER,  --返回错误ID
                                 P_ERR_MSG          OUT VARCHAR2 --返回错误信息
                                 );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2019-04-12
  *     创建者：周建刚
  *   功能说明：预约单信息自动补全和校验。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_BOOK_INFO_CHECK(P_BATCH_ID         IN NUMBER,   --批处理ID
                              P_USER_CODE        IN VARCHAR2, --操作用户编码
                              P_RESULT           OUT NUMBER,  --返回错误ID
                              P_ERR_MSG          OUT VARCHAR2 --返回错误信息
                              );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-07-18
  *     创建者：周建刚
  *   功能说明：处理电商反馈的预约结果。
  */
  -------------------------------------------------------------------------------   
  PROCEDURE P_BOOK_RESULT_HANDLE(P_BOOK_TYPE      IN VARCHAR2, --操作类型：操作类型： confirm 预约成功反馈IMS;cancel 取消预约
                                 P_BOOK_NUM       IN VARCHAR2, --IMS预约单号
                                 P_OUT_BOOK_NUM   IN VARCHAR2, --客户预约单号（例如：天猫LBX单号）
                                 P_OUT_BOOK_DATE  IN VARCHAR2, --预约日期（天猫可能修改预约日期，以天猫反馈的预约日期为准）
                                 P_BOOK_RESULT    IN VARCHAR2, --预约结果提示信息
                                 P_USER_CODE      IN VARCHAR2, --操作用户编码
                                 P_RESULT         OUT NUMBER,  --返回错误ID
                                 P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                                 );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-08-01
  *     创建者：周建刚
  *   功能说明：关闭预约信息。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_BOOK_INFO_CLOSE(P_HEADER_ID      IN NUMBER,   --预约单头ID
                              P_USER_CODE      IN VARCHAR2, --操作用户编码
                              P_RESULT         OUT NUMBER,  --返回错误ID
                              P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                              );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-11-01
  *     创建者：周建刚
  *   功能说明：预约信息推送LOMS，安得业务简单化项目的预约发货计划功能。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_BOOK_INFO_2_LOMS(P_BOOK_TYPE      IN VARCHAR2, --操作类型：操作类型： confirm 预约成功反馈IMS;cancel 取消预约
                               P_BOOK_NUM       IN VARCHAR2, --IMS预约单号
                               P_USER_CODE      IN VARCHAR2, --操作用户编码
                               P_RESULT         OUT NUMBER,  --返回错误ID
                               P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                               );
                               
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-12-06
  *     创建者：周建刚
  *   功能说明：预约信息推送ECSCM，通过ECSCM系统传递到天猫。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_BOOK_INFO_2_ECSCM(P_BATCH_ID         IN NUMBER,   --批处理ID
                                P_RESULT           OUT NUMBER,  --返回错误ID
                                P_ERR_MSG          OUT VARCHAR2 --返回错误信息
                                );

  -------------------------------------------------------------------------------
  /*
  *   创建日期：2018-07-04
  *     创建者：周建刚
  *   功能说明：更新合并预约批次编码
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_BOOK_UPDATE_OUT_BATCH_NUM(P_ENTITY_ID IN NUMBER, --主体ID
                                       P_BATCH_ID         IN NUMBER,   --批处理ID
                                       P_USER_CODE        IN VARCHAR2, --操作用户编码
                                       P_RESULT           OUT NUMBER,  --返回错误ID
                                       P_ERR_MSG          OUT VARCHAR2 --返回错误信息
                                       );
  
  -------------------------------------------------------------------------------

 /*
  *   创建日期：2018-12-07
  *     创建者：huanghb12
  *   功能说明：预约单取消或者确认的时候后，刷新集拼单下的要求发货日期，预约确认后：将预约日期写到了发货通知单上，取消后：发货通知单上抹去了预约信息，修改集拼单及发货通知单的要求发货日期。
  */
  -------------------------------------------------------------------------------
  PROCEDURE P_REVISE_REQUIRE_SHIP_DATE(P_COLLAGE_ORDER_NUM IN VARCHAR2,--集拼单号
                                       P_USER_CODE      IN VARCHAR2, --操作用户编码
                                       P_RESULT         OUT NUMBER,  --返回错误ID
                                       P_ERR_MSG        OUT VARCHAR2 --返回错误信息
                                       );
  -------------------------------------------------------------------------------
  /*
  *   创建日期：2019-3-27
  *     创建者：lilh6
  *   功能说明：下线直发库存校验,安得装车前调用
  */
  -------------------------------------------------------------------------------
  Procedure p_Pln_Direct_Inv_Check(p_Esb_Num    In Varchar2, --ESB流水号
                                   p_Check_Type In Varchar2, --校验类型：CHECK  CANCEL
                                   p_Result     Out Varchar2 --返回错误信息
                                   );
  -------------------------------------------------------------------------------


End Pkg_Pln_Intf;
/

