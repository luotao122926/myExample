create PACKAGE BODY      PKG_AR_CCS_INTO_CIMS IS

  /*
  * CCS纸票录入，接口表数据插入业务表
  */
  PROCEDURE P_RECEIPT_INTO_NEW(P_CASH_RECEIPT_ID IN NUMBER, --批处理ID
                               P_MESSAGE         OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                               ) IS
    --事物控制，防止CCS调存储过程后，他们那边提交事物了，CIMS这边却没有同步控制事物
    --PRAGMA AUTONOMOUS_TRANSACTION;
    V_HEAD_COUNT            NUMBER; --收款头数据总数
    V_METHOD_COUNT          NUMBER; --收款方法数据总数
    V_APPENDIX_COUNT        NUMBER; --附件数据总数
    V_LINE_COUNT            NUMBER; --收款行数据总数
    V_SALES_MAIN_TYPE_COUNT NUMBER; --客户下营销大类数据总数
    V_CASH_RECEIPT_CODE     VARCHAR2(32); --收款单据编号
    V_CASH_RECEIPT_ID       NUMBER; --收款头ID
    V_CCS_SOURCE_CODE       VARCHAR2(32); --CCS单号
    V_CODE_LEN              NUMBER; --票据号长度
    V_DATE_TERM             NUMBER; --票据期限
    V_CURRENT_DATE          DATE; --当前系统日期（年月日）
    V_CUS_CEN_ACC_FLAG      NUMBER; --客户、营销中心、账户对应关系记录数
    V_CODE_REPEAT_FLAG      NUMBER; --票据号重复标志，0--不重复，非0---重复
    V_SUB_CODE_SUM          NUMBER; -- 票据分号总数
    V_LINE_AMOUNT           NUMBER; --单张收款单的分款金额总和
    V_APPENDIX_FLAG         VARCHAR2(2); --附件上传标志Y/N
    V_SALES_ERROR           VARCHAR2(100); --错误信息
    V_ENTITY_ID             NUMBER; --收款头主体ID
    V_CUSTOMER_CODE         VARCHAR2(100); --客户编码
    V_ACCOUNT_CODE          VARCHAR2(100); --账户编码
    V_SALES_CENTER_CODE     VARCHAR2(100); --营销中心编码
    V_CUSTOMER_ID           NUMBER; --客户ID
    V_CUSTOMER_NAME         VARCHAR2(300); --客户名称
    V_ACCOUNT_ID            NUMBER; --账户ID
    V_SALES_CENTER_ID       NUMBER; --营销中心ID
    V_SALES_CENTER_NAME     VARCHAR2(100); --营销中心名称
    V_SALES_MAIN_TYPE_ID    NUMBER; --营销大类ID
    V_SALES_MAIN_TYPE_NAME  VARCHAR2(100); --营销大类名称
    V_BUDGET_ITEM_CODE      VARCHAR2(240); --预算项目编码
    V_ERP_OU_NAME           VARCHAR2(100); --OU名称
    V_RP_APPENDIX           VARCHAR2(32); --附件ID
    V_SALES_LOOP_COUNT      NUMBER; --营销大类循环记录数
    V_SALES_COUNT           NUMBER; --营销大类重复记录数
    V_OU_CHECK              NUMBER; -- ERP_0U_ID校验标志
    V_CASH_CODE_CHECK       VARCHAR2(100); --票据号重复校验标志
    V_CUST_OU_MESS          VARCHAR2(1000); --客户OU
    V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常
    
    V_PUB_FIN_SYS           VARCHAR2(32); --是否销司业务

    --CCS收款头接口表数据
    CURSOR C_INTF_RECEIPT_HEAD IS
      SELECT *
        FROM CIMS.INTF_AR_RECEIPT_HEADERS_CCS H
       WHERE H.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID
         AND NVL(H.OPERATE_FLAG, '0') <> '1';

    HEAD_ROW C_INTF_RECEIPT_HEAD%ROWTYPE; --接口表收款头游标行数据

    --收款头对应的方法
    V_RECEIPT_METHOD_ID NUMBER; --收款方法ID
    CURSOR C_RECEIPT_MEHTOD IS
      SELECT *
        FROM CIMS.V_AR_RECEIPT_METHODS_CCS M
       WHERE M.RECEIPT_METHOD_ID = V_RECEIPT_METHOD_ID
         AND M.BUSINESS_TYPE = '1'
         AND M.ENTITY_ID = V_ENTITY_ID;

    METHOD_ROW C_RECEIPT_MEHTOD%ROWTYPE; --收款方法游标行数据

    --收款行
    CURSOR C_RECEIPT_LINES IS
      SELECT  L.CASH_RECEIPT_LINES_ID
             ,L.CASH_RECEIPT_ID,AMOUNT
             ,L.SALES_MAIN_TYPE_ID
             ,(CASE WHEN V_PUB_FIN_SYS = 'NC' THEN T.SC_ITEM_CLASS_CODE ELSE L.SALES_MAIN_TYPE_CODE END) SALES_MAIN_TYPE_CODE
             ,L.SALES_MAIN_TYPE_NAME
             ,L.REMARK
             ,L.ENTITY_ID
             ,L.SOURCE_LINE_CODE
             ,L.SOURCE_CODE
             ,L.ITEM_BRAND
        FROM CIMS.INTF_AR_RECEIPT_LINES_CCS L
      LEFT JOIN CIMS.T_BD_ITEM_CLASS_RELATION T 
                ON T.SC_ENTITY_ID = L.ENTITY_ID 
               AND T.HQ_ITEM_CLASS_CODE = L.SALES_MAIN_TYPE_CODE
               AND T.HQ_ITEM_BRAND = L.ITEM_BRAND
       WHERE L.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID;

    LINE_ROW C_RECEIPT_LINES%ROWTYPE; --收款行游标行数据

    --客户下有效营销大类
    CURSOR C_SALES_MAIN_TYPE IS
      SELECT T2.ITEM_CLASS_ID SALES_MAIN_TYPE_ID,
             T1.SALES_MAIN_TYPE_CODE,
             T1.SALES_MAIN_TYPE_NAME
        FROM T_CUSTOMER_SALES_MAIN_TYPE T1, T_BD_ITEM_CLASS T2
       WHERE T1.SALES_MAIN_TYPE_CODE = T2.CLASS_CODE
         AND T1.ENTITY_ID = T2.ENTITY_ID
         AND T1.ACTIVE_FLAG = 'Active'
         AND T2.ACTIVE_FLAG = 'Y'
         AND T1.ENTITY_ID = V_ENTITY_ID
         AND T1.CUSTOM_CODE = V_CUSTOMER_CODE;

    SALES_MAIN_TYPE_ROW C_SALES_MAIN_TYPE%ROWTYPE; --有效营销大类游标行数据

    --客户、中心、账户
    CURSOR C_CUSTOMER_ACCOUNT_CENTER IS
      SELECT V2.CUSTOMER_ID,
             V2.CUSTOMER_CODE,
             V2.CUSTOMER_NAME,
             V2.ACCOUNT_ID,
             V2.ACCOUNT_CODE,
             V2.SALES_CENTER_ID,
             V2.SALES_CENTER_CODE,
             V2.SALES_CENTER_NAME
        FROM CIMS.V_CUSTOMER_ACCOUNT_SALECENTER V2
       WHERE V2.CUSTOMER_CODE = V_CUSTOMER_CODE
         AND V2.SALES_CENTER_CODE = V_SALES_CENTER_CODE
         AND V2.ACCOUNT_CODE = V_ACCOUNT_CODE
         AND V2.ENTITY_ID = V_ENTITY_ID
         AND V2.ACTIVE_FLAG = 'Active'
         AND V2.ACCOUNT_STATUS = '1'
         AND V2.ORGACTIVE_FLAG = 'Active';

    CUST_ACC_CEN_ROW C_CUSTOMER_ACCOUNT_CENTER%ROWTYPE; --客户中心账户游标行数据
    
    --附件
    CURSOR C_RP_APPENDIX IS
      SELECT *
        FROM CIMS.INTF_AR_APPENDIX_CCS AP
       WHERE AP.SOURCE_CODE = V_CCS_SOURCE_CODE;
    RP_APPENDIX_ROW C_RP_APPENDIX%ROWTYPE; --附件游标行数据
    
    V_ACCEPT_BANK_NAME VARCHAR(300);
    V_DRAWERBANK_CNAPSCODE VARCHAR(300);
    V_FIRSTPAYEEBANK_CNAPSCODE VARCHAR(300);
  BEGIN
    P_MESSAGE := 'SUCCESS';
    --获取接口表数据数量
    SELECT COUNT(*)
      INTO V_HEAD_COUNT
      FROM CIMS.INTF_AR_RECEIPT_HEADERS_CCS H
     WHERE H.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID
       AND NVL(H.OPERATE_FLAG, '0') <> '1';

    IF (V_HEAD_COUNT > 0) THEN
      FOR HEAD_ROW IN C_INTF_RECEIPT_HEAD LOOP

        --校验CCS接口数据是否正确
        V_CCS_SOURCE_CODE   := HEAD_ROW.SOURCE_CODE;
        V_RECEIPT_METHOD_ID := HEAD_ROW.RECEIPT_METHOD_ID;
        V_ENTITY_ID         := HEAD_ROW.ENTITY_ID;
        V_CUSTOMER_CODE     := HEAD_ROW.CUSTOMER_CODE;
        V_ACCOUNT_CODE      := HEAD_ROW.ACCOUNT_CODE;
        V_SALES_CENTER_CODE := HEAD_ROW.SALES_CENTER_CODE;
        V_PUB_FIN_SYS := PKG_BD.F_GET_PARAMETER_VALUE(P_CONFIG_CODE => 'PUB_FIN_SYS',
                                                        P_ENTITY_ID =>  HEAD_ROW.ENTITY_ID);

        --校验收款单接口数据:必填项
        IF HEAD_ROW.CASH_RECEIPT_ID IS NULL THEN
          P_MESSAGE := '收款单id为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.SOURCE_CODE IS NULL THEN
          P_MESSAGE := '收款单CCS单据编号为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.RECEIPT_METHOD_ID IS NULL THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的收款方法为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.RECEIPT_STATUS_ID IS NULL THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的状态为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.RECEIPT_STATUS_ID <> 1 THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的状态不是1';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CUSTOMER_CODE IS NULL THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的客户编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.SALES_CENTER_CODE IS NULL THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的营销中心编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.ACCOUNT_CODE IS NULL THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的账户编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.ERP_OU_ID IS NULL THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的OU_ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CASH_RECEIPT_DATE IS NULL THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的单据日期为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.GL_DATE IS NULL THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的总账日期为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.AMOUNT IS NULL THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的金额为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CURRENCY_CODE IS NULL THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的币种为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CREATED_BY IS NULL THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的制单人为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CREATION_DATE IS NULL THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的制单时间为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.ENTITY_ID IS NULL THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的主体ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.SOURCE_CODE IS NULL THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的来源单号为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.SOURCE_SYSTEM IS NULL THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的来源系统为空';
          RAISE V_BIZ_EXCEPTION;
          --校验金额必须大于0
        ELSIF HEAD_ROW.AMOUNT <= 0 THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的金额必须大于0';
          RAISE V_BIZ_EXCEPTION;
        END IF;

        --校验OU_ID是否属于该主体
        BEGIN
          SELECT COUNT(ID)
            INTO V_OU_CHECK
            FROM CIMS.V_UP_CODELIST V
           WHERE V.CODETYPE = 'ar_ou_id'
             AND V.ENTITY_ID = V_ENTITY_ID
             AND V.CODE_VALUE = HEAD_ROW.ERP_OU_ID;
        END;
        IF V_OU_CHECK <> 1 THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的ERP_OU_ID有误，不属于主体' ||
                       V_ENTITY_ID || '，或者查询到的OU存在多条';
          RAISE V_BIZ_EXCEPTION;
        END IF;

        --收款方法数据数量
        SELECT COUNT(*)
          INTO V_METHOD_COUNT
          FROM CIMS.V_AR_RECEIPT_METHODS_CCS M
         WHERE M.RECEIPT_METHOD_ID = V_RECEIPT_METHOD_ID
           AND M.ENTITY_ID = V_ENTITY_ID
           AND M.BUSINESS_TYPE = '1';

        --校验收款必填项（收款方法配置）
        IF V_METHOD_COUNT <> 1 THEN
          P_MESSAGE := '根据收款单' || V_CCS_SOURCE_CODE || '的收款方法ID' ||
                       V_RECEIPT_METHOD_ID || '和主体ID' || V_ENTITY_ID ||
                       '查询到的收款方法为空，或者为多条';
          RAISE V_BIZ_EXCEPTION;
        ELSE
          FOR METHOD_ROW IN C_RECEIPT_MEHTOD LOOP

            --票据号长度
            V_CODE_LEN := METHOD_ROW.CASH_CODE_LENGTH;
            --票据期限
            V_DATE_TERM := METHOD_ROW.CASH_DATE_TERM;

            --收款方法配置的必填项
            IF (METHOD_ROW.RECEIPT_REQUIRE = 'Y') THEN
              IF HEAD_ROW.DRAWER IS NULL THEN
                P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的出票人为空';
                RAISE V_BIZ_EXCEPTION;
              ELSIF HEAD_ROW.DRAWER_BANK_ACCOUNT IS NULL THEN
                P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的出票人银行账户为空';
                RAISE V_BIZ_EXCEPTION;
              ELSIF HEAD_ROW.DRAWER_BANK IS NULL THEN
                P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的出票人银行空';
                RAISE V_BIZ_EXCEPTION;
              ELSIF HEAD_ROW.ACCEPTANCE_BANK_NAME IS NULL THEN
                P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的承兑银行号为空';
                RAISE V_BIZ_EXCEPTION;
              END IF;
            END IF;
            --若引入资金，第一收款人、第一收款人银行、第一收款人银行账号不能为空
            IF METHOD_ROW.INTO_BAN_FLAG = 'Y' THEN
              IF HEAD_ROW.FIRST_RECEIPT_NAME IS NULL THEN
                P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的第一收款人为空';
                RAISE V_BIZ_EXCEPTION;
              ELSIF HEAD_ROW.FIRST_RECEIPT_BANK_ACCOUNT IS NULL THEN
                P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的第一收款人银行账户为空';
                RAISE V_BIZ_EXCEPTION;
              ELSIF HEAD_ROW.FIRST_RECEIPT_BANK IS NULL THEN
                P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的第一收款人银行为空';
                RAISE V_BIZ_EXCEPTION;
              END IF;
            END IF;
          END LOOP;
        END IF;

        --校验第一收款人银行账号格式：字母、数字、中划线
        IF HEAD_ROW.FIRST_RECEIPT_BANK_ACCOUNT IS NOT NULL THEN
          IF REGEXP_SUBSTR(HEAD_ROW.FIRST_RECEIPT_BANK_ACCOUNT,
                           '[0-9a-zA-Z\-]*') <>
             HEAD_ROW.FIRST_RECEIPT_BANK_ACCOUNT THEN
            P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的第一收款人银行账户格式不正确';
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END IF;

        --校验出票人银行账号格式：字母、数字、中划线
        IF HEAD_ROW.DRAWER_BANK_ACCOUNT IS NOT NULL THEN
          IF REGEXP_SUBSTR(HEAD_ROW.DRAWER_BANK_ACCOUNT, '[0-9a-zA-Z\-]*') <>
             HEAD_ROW.DRAWER_BANK_ACCOUNT THEN
            P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的出票人银行账户格式不正确';
            RAISE V_BIZ_EXCEPTION;
          END IF;
          IF LENGTH(HEAD_ROW.DRAWER_BANK_ACCOUNT) >= 38 THEN
            P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的出票人银行账户长度必须小于38';
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END IF;

        --校验票据号格式：数字
        IF HEAD_ROW.CASH_CODE IS NOT NULL THEN
          IF REGEXP_SUBSTR(HEAD_ROW.CASH_CODE, '[0-9]*') <>
             HEAD_ROW.CASH_CODE THEN
            P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的票据号格式不正确';
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END IF;

        --校验票据号长度（收款方法配置），不校验票据号格式
        IF V_CODE_LEN IS NOT NULL THEN
          --电汇收款方法没有票据号
          IF V_CODE_LEN = 0 AND HEAD_ROW.CASH_CODE IS NOT NULL THEN
            P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的票据号长度不为0';
            RAISE V_BIZ_EXCEPTION;
          ELSIF V_CODE_LEN > 0 AND HEAD_ROW.CASH_CODE IS NULL THEN
            P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的票据号为空';
            RAISE V_BIZ_EXCEPTION;
          ELSIF HEAD_ROW.CASH_CODE IS NOT NULL AND V_CODE_LEN > 0 AND
                LENGTH(HEAD_ROW.CASH_CODE) <> V_CODE_LEN THEN
            P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的票据号长度为' ||
                         V_CODE_LEN;
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END IF;

        --校验票据期限：到期日>当天 、 到期日>=单据日期  、 到期日期-单据日期>票据期限
        BEGIN
          --当前系统日期
          SELECT TRUNC(SYSDATE) INTO V_CURRENT_DATE FROM DUAL;
          IF V_DATE_TERM IS NULL THEN
            IF HEAD_ROW.DUE_DATE < V_CURRENT_DATE THEN
              P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的到期日期不能小于当天';
              RAISE V_BIZ_EXCEPTION;
            ELSIF HEAD_ROW.DUE_DATE <= HEAD_ROW.CASH_DATE THEN
              P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的到期日期不能小于等于单据日期';
              RAISE V_BIZ_EXCEPTION;
            END IF;
          ELSE
            IF HEAD_ROW.DUE_DATE < V_CURRENT_DATE THEN
              P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的到期日期不能小于当天';
              RAISE V_BIZ_EXCEPTION;
            ELSIF HEAD_ROW.DUE_DATE IS NULL OR HEAD_ROW.CASH_DATE IS NULL THEN
              P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的出票日期/到期日期不能为空';
              RAISE V_BIZ_EXCEPTION;
            ELSIF HEAD_ROW.DUE_DATE - HEAD_ROW.CASH_DATE > V_DATE_TERM THEN
              P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的到期日期-出票日期>票据期限';
              RAISE V_BIZ_EXCEPTION;
            END IF;
          END IF;
        END;

        --校验附件:根据收款方法判断附件是否已经上传（厨电必须上传附件）
        BEGIN
          --2016-01-20修改，CCS收款单对应方法配置附件为非必须上传时，CCS上传附件，需要同步到CIMS
            SELECT COUNT(*)
              INTO V_APPENDIX_COUNT
              FROM CIMS.INTF_AR_APPENDIX_CCS X
             WHERE X.SOURCE_CODE = HEAD_ROW.SOURCE_CODE;

          SELECT TM.APPENDIX_FLAG
            INTO V_APPENDIX_FLAG
            FROM CIMS.T_AR_RECEIPT_METHODS TM
           WHERE TM.RECEIPT_METHOD_ID = V_RECEIPT_METHOD_ID;
          IF V_APPENDIX_FLAG = 'Y' THEN
            --获取CCS上传的附件记录数，若总记录数大于0，则表示已经上传附件，否则，没有上传附件。
            /*
            SELECT COUNT(*)
              INTO V_APPENDIX_COUNT
              FROM CIMS.INTF_AR_APPENDIX_CCS X
             WHERE X.SOURCE_CODE = HEAD_ROW.SOURCE_CODE;
             */
            IF V_APPENDIX_COUNT = 0 THEN
              P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的附件为空';
              RAISE V_BIZ_EXCEPTION;
            END IF;
          END IF;
        END;

        --校验客户、中心、账户是否对应
        BEGIN
          SELECT COUNT(*)
            INTO V_CUS_CEN_ACC_FLAG
            FROM CIMS.V_CUSTOMER_ACCOUNT_SALECENTER V
           WHERE V.CUSTOMER_CODE = V_CUSTOMER_CODE
             AND V.SALES_CENTER_CODE = V_SALES_CENTER_CODE
             AND V.ACCOUNT_CODE = V_ACCOUNT_CODE
             AND V.ENTITY_ID = V_ENTITY_ID
             AND V.ACTIVE_FLAG = 'Active'
             AND V.ACCOUNT_STATUS = '1'
             AND V.ORGACTIVE_FLAG = 'Active';

          IF V_CUS_CEN_ACC_FLAG <> 1 THEN
            P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE ||
                         '中的客户、营销中心、账户状态无效，或者没有一一对应';
            RAISE V_BIZ_EXCEPTION;
          ELSE
            FOR CUST_ACC_CEN_ROW IN C_CUSTOMER_ACCOUNT_CENTER LOOP
              V_CUSTOMER_ID       := CUST_ACC_CEN_ROW.CUSTOMER_ID;
              V_CUSTOMER_NAME     := CUST_ACC_CEN_ROW.CUSTOMER_NAME;
              V_ACCOUNT_ID        := CUST_ACC_CEN_ROW.ACCOUNT_ID;
              V_SALES_CENTER_ID   := CUST_ACC_CEN_ROW.SALES_CENTER_ID;
              V_SALES_CENTER_NAME := CUST_ACC_CEN_ROW.SALES_CENTER_NAME;
            END LOOP;
          END IF;
        END;

        --2015-10-22修改，增加客户-OU对应关系校验
        V_CUST_OU_MESS := PKG_AR_COMMON.F_VALIDATE_CUST_OU(V_CUSTOMER_ID,
                                                           HEAD_ROW.ERP_OU_ID);
        IF V_CUST_OU_MESS <> 'SUCCESS' THEN
          P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '中的转入客户（' ||
                       V_CUSTOMER_ID || '）、转入OU（' || HEAD_ROW.ERP_OU_ID ||
                       '）没有对应';
          RAISE V_BIZ_EXCEPTION;
        END IF;

        --根据系统参数ar_check_cashcode，判断是否校验票据号重复
        V_CASH_CODE_CHECK := PKG_BD.F_GET_PARAMETER_VALUE('ar_check_cashcode',HEAD_ROW.ENTITY_ID,NULL,NULL);
        IF V_CASH_CODE_CHECK = 'Y' THEN
          --校验票据号是否重复（合并导入、已冲销、冲销原单、已引接口的票据号，允许重复，）
          BEGIN
            SELECT COUNT(*)
              INTO V_CODE_REPEAT_FLAG --票据号重复数
              FROM CIMS.T_AR_CASH_RECEIPT_HEADERS
             WHERE CASH_CODE = HEAD_ROW.CASH_CODE
               AND CASH_RECEIPT_ID <> HEAD_ROW.CASH_RECEIPT_ID
               --2017-08-03 TIANMZH ADD 只校验相同主体的票据号
               AND ENTITY_ID = HEAD_ROW.ENTITY_ID
               AND RECEIPT_STATUS_ID NOT IN (2, 16) --作废、已冲销
               AND WRITEOFF_RECEIPT_CODE IS NULL --冲销原单号不为空，即冲销后生成的已确认状态的收款单
               AND INTO_GTMS_STATUS IS NULL --未引资金
               AND INTO_NC_CODE IS NULL --未引NC
               AND INTO_ERP_STATUS IS NULL; --未引ERP
            --非合并导入
            IF HEAD_ROW.UNITE_FLAG IS NULL OR HEAD_ROW.UNITE_FLAG <> 'Y' THEN
              IF V_CODE_REPEAT_FLAG > 0 THEN
                P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的票据号重复';
                RAISE V_BIZ_EXCEPTION;
              END IF;
            ELSE
              V_CODE_REPEAT_FLAG := V_CODE_REPEAT_FLAG + 1;
              --解析票据分号，判断票据总数与票据分号中的总数是否一致，暂不校验票据分号格式
              SELECT TO_NUMBER(SUBSTR(HEAD_ROW.SUB_CASH_CODE,
                                      INSTR(HEAD_ROW.SUB_CASH_CODE, '-', 1, 1) + 1,
                                      LENGTH(HEAD_ROW.SUB_CASH_CODE) -
                                      INSTR(HEAD_ROW.SUB_CASH_CODE, '-', 1, 2)))
                INTO V_SUB_CODE_SUM
                FROM DUAL;
              IF V_CODE_REPEAT_FLAG > 0 AND
                 V_SUB_CODE_SUM <> V_CODE_REPEAT_FLAG THEN
                P_MESSAGE := '票据号' || HEAD_ROW.CASH_CODE ||
                             '下的收款单（子票据）录入不全，或票据总数不正确';
                RAISE V_BIZ_EXCEPTION;
              END IF;
            END IF;
          END;
        END IF;
        
        --校验客户下的营销大类
        BEGIN
          SELECT COUNT(*)
            INTO V_LINE_COUNT
            FROM CIMS.INTF_AR_RECEIPT_LINES_CCS L
           WHERE L.CASH_RECEIPT_ID = HEAD_ROW.CASH_RECEIPT_ID;

          IF V_LINE_COUNT > 0 THEN
            V_LINE_AMOUNT := 0.0;
            --校验分款明细
            FOR LINE_ROW IN C_RECEIPT_LINES LOOP
              IF LINE_ROW.AMOUNT IS NULL THEN
                P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的分款明细中金额为空';
                RAISE V_BIZ_EXCEPTION;
              ELSIF LINE_ROW.AMOUNT IS NOT NULL AND LINE_ROW.AMOUNT <= 0 THEN
                P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的分款明细中金额小于等于0';
                RAISE V_BIZ_EXCEPTION;
              ELSIF LINE_ROW.SALES_MAIN_TYPE_CODE IS NULL THEN
                P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的分款明细中营销大类编码为空';
                RAISE V_BIZ_EXCEPTION;
              ELSE
                --校验营销大类是否重复
                BEGIN
                  SELECT COUNT(*)
                    INTO V_SALES_COUNT
                    FROM (SELECT A.SALES_MAIN_TYPE_CODE 
                               ,COUNT(A.SALES_MAIN_TYPE_CODE)
                           FROM(   
                              SELECT 
                                 (CASE WHEN V_PUB_FIN_SYS = 'NC' THEN T.SC_ITEM_CLASS_CODE ELSE L.SALES_MAIN_TYPE_CODE END) SALES_MAIN_TYPE_CODE
                              FROM CIMS.INTF_AR_RECEIPT_LINES_CCS L
                              LEFT JOIN CIMS.T_BD_ITEM_CLASS_RELATION T 
                                          ON T.SC_ENTITY_ID = L.ENTITY_ID 
                                         AND T.HQ_ITEM_CLASS_CODE = L.SALES_MAIN_TYPE_CODE
                                         AND T.HQ_ITEM_BRAND = L.ITEM_BRAND
                             WHERE L.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID ) A
                           GROUP BY A.SALES_MAIN_TYPE_CODE
                          HAVING COUNT(A.SALES_MAIN_TYPE_CODE) > 1);
                END;
                IF V_SALES_COUNT > 0 THEN
                  P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的分款明细中营销大类重复';
                  RAISE V_BIZ_EXCEPTION;
                END IF;
                BEGIN
                  SELECT COUNT(*)
                    INTO V_SALES_MAIN_TYPE_COUNT
                    FROM T_CUSTOMER_SALES_MAIN_TYPE T1, T_BD_ITEM_CLASS T2
                   WHERE T1.SALES_MAIN_TYPE_CODE = T2.CLASS_CODE
                     AND T1.ENTITY_ID = T2.ENTITY_ID
                     AND T1.ACTIVE_FLAG = 'Active'
                     AND T2.ACTIVE_FLAG = 'Y'
                     AND T1.ENTITY_ID = HEAD_ROW.ENTITY_ID
                     AND T1.CUSTOM_ID = V_CUSTOMER_ID;
                END;
                IF V_SALES_MAIN_TYPE_COUNT > 0 THEN
                  --判断营销大类是否有效，是否属于收款的客户
                  V_SALES_LOOP_COUNT := 0;
                  FOR SALES_MAIN_TYPE_ROW IN C_SALES_MAIN_TYPE LOOP
                    V_SALES_LOOP_COUNT := V_SALES_LOOP_COUNT + 1;
                    IF LINE_ROW.SALES_MAIN_TYPE_CODE =
                       SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_CODE THEN
                      V_SALES_ERROR := 'OK';
                      EXIT;
                    ELSE
                      IF V_SALES_LOOP_COUNT = V_SALES_MAIN_TYPE_COUNT THEN
                        P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE ||
                                     '的分款明细中营销大类不是有效的，或不存在';
                        RAISE V_BIZ_EXCEPTION;
                      END IF;
                    END IF;
                  END LOOP;
                ELSE
                  P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE ||
                               '客户下的营销大类为空或无效';
                  RAISE V_BIZ_EXCEPTION;
                END IF;
              END IF;
              V_LINE_AMOUNT := V_LINE_AMOUNT + LINE_ROW.AMOUNT;
            END LOOP;
          ELSE
            P_MESSAGE := '收款单行为空';
            RAISE V_BIZ_EXCEPTION;
          END IF;
          IF V_SALES_ERROR = 'OK' AND V_LINE_AMOUNT <> HEAD_ROW.AMOUNT THEN
            P_MESSAGE := '收款单' || V_CCS_SOURCE_CODE || '的金额与分款明细中金额总和不等';
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END;

        --附件
        IF V_APPENDIX_COUNT > 0 THEN
          --附件ID
          SELECT 'ARRP' || S_AR_RP_APPENDIX.NEXTVAL
            INTO V_RP_APPENDIX
            FROM DUAL;
          FOR RP_APPENDIX_ROW IN C_RP_APPENDIX LOOP
            --插入附件表
            INSERT INTO IMS_FILEINFO_INTERFACE
              (ID, BUSINESS_ID, BUSINESS_TYPE, FILE_PATH, CREATED_DATE)
            VALUES
              (SEQ_IMS_FILEINFO.NEXTVAL,
               V_RP_APPENDIX,
               'arReceiptCode',
               RP_APPENDIX_ROW.FILE_PATH,
               SYSDATE);
          END LOOP;
        END IF;

        --预算项目
        SELECT NVL(T.BUDGETITEMCODE, '0314')
          INTO V_BUDGET_ITEM_CODE
          FROM CIMS.INTF_GTSP_BUDGET_PROJECT T
         WHERE T.ATTRIBUTE1 = 'Y';

        --OU名称
        SELECT U.ERP_OU_NAME
          INTO V_ERP_OU_NAME
          FROM CIMS.V_AR_ENTITY_OU_CCS U
         WHERE U.ERP_OU_ID = HEAD_ROW.ERP_OU_ID;

        --生成收款单据号
        BEGIN
          V_CASH_RECEIPT_CODE := PKG_BD.F_GET_BILL_NO('ARARCODE',
                                                      NULL,
                                                      HEAD_ROW.ENTITY_ID,
                                                      NULL);
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := '取收款单据号失败！';
            RAISE V_BIZ_EXCEPTION;
        END;

        --获取收款单据ID
        SELECT S_AR_CASH_RECEIPT_HEADERS.NEXTVAL
          INTO V_CASH_RECEIPT_ID
          FROM DUAL;

        BEGIN
        
          --遍历收款接口表数据，插入收款头表
          INSERT INTO T_AR_CASH_RECEIPT_HEADERS
            (CASH_RECEIPT_ID,
             RECEIPT_METHOD_ID,
             RECEIPT_STATUS_ID,
             ACCOUNT_ID,
             CASH_RECEIPT_CODE,
             CASH_RECEIPT_DATE,
             GL_DATE,
             AMOUNT,
             CURRENCY_CODE,
             CASH_CODE,
             SUB_CASH_CODE,
             UNITE_FLAG,
             CASH_DATE,
             DUE_DATE,
             DRAWER,
             DRAWER_BANK_ACCOUNT,
             DRAWER_BANK,
             BACK_WRITE_NAME,
             FIRST_RECEIPT_NAME,
             FIRST_RECEIPT_BANK_ACCOUNT,
             FIRST_RECEIPT_BANK,
             ACCEPTANCE_BANK_NAME,
             BUDGET_ITEM_NAME,
             CREATED_BY,
             CREATION_DATE,
             REMAEK,
             CUSTOMER_ID,
             CUSTOMER_CODE,
             CUSTOMER_NAME,
             ACCOUNT_CODE,
             SALES_CENTER_ID,
             ENTITY_ID,
             IS_HONESTLY,
             SOURCE_TYPE,
             CONTRACT_NUM,
             ERP_OU_NAME,
             ERP_OU_ID,
             UPPER_AMOUNT,
             APPENDIX_ID,
             ATTRIBUTE3,
             ATTRIBUTE4,
             VERSION_NUM,
             ACCEPT_BANK_NAME,
             DRAWERBANK_CNAPSCODE,
             FIRSTPAYEEBANK_CNAPSCODE
             )
          VALUES
            (V_CASH_RECEIPT_ID,
             HEAD_ROW.RECEIPT_METHOD_ID,
             '1',
             V_ACCOUNT_ID,
             V_CASH_RECEIPT_CODE,
             HEAD_ROW.CASH_RECEIPT_DATE,
             HEAD_ROW.GL_DATE,
             HEAD_ROW.AMOUNT,
             HEAD_ROW.CURRENCY_CODE,
             HEAD_ROW.CASH_CODE,
             --票据分号、合并导入不存值
             '',
             '',
             HEAD_ROW.CASH_DATE,
             HEAD_ROW.DUE_DATE,
             HEAD_ROW.DRAWER,
             HEAD_ROW.DRAWER_BANK_ACCOUNT,
             HEAD_ROW.DRAWER_BANK,
             HEAD_ROW.BACK_WRITE_NAME,
             HEAD_ROW.FIRST_RECEIPT_NAME,
             HEAD_ROW.FIRST_RECEIPT_BANK_ACCOUNT,
             HEAD_ROW.FIRST_RECEIPT_BANK,
             HEAD_ROW.ACCEPTANCE_BANK_NAME,
             V_BUDGET_ITEM_CODE,
             HEAD_ROW.CREATED_BY,
             HEAD_ROW.CREATION_DATE,
             HEAD_ROW.REMAEK,
             V_CUSTOMER_ID,
             V_CUSTOMER_CODE,
             V_CUSTOMER_NAME,
             V_ACCOUNT_CODE,
             V_SALES_CENTER_ID,
             HEAD_ROW.ENTITY_ID,
             HEAD_ROW.IS_HONESTLY,
             HEAD_ROW.SOURCE_TYPE,
             HEAD_ROW.CONTRACT_NUM,
             V_ERP_OU_NAME,
             HEAD_ROW.ERP_OU_ID,
             MONEY_TO_RMB(HEAD_ROW.AMOUNT),
             V_RP_APPENDIX,
             HEAD_ROW.SOURCE_SYSTEM,
             HEAD_ROW.SOURCE_CODE,
             '0',
             (SELECT BANK_NAME FROM T_BD_BANKINFO WHERE UBANK_NO = HEAD_ROW.ACCEPTANCE_BANK_NAME AND rownum=1),
             (SELECT UBANK_NO FROM T_BD_BANKINFO WHERE BANK_NAME = HEAD_ROW.DRAWER_BANK AND rownum=1),
             (SELECT UBANK_NO FROM T_BD_BANKINFO WHERE BANK_NAME = HEAD_ROW.FIRST_RECEIPT_BANK AND rownum=1)
             );
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CCS_INTO_CIMS.P_RECEIPT_INTO_NEW',
                                                SQLCODE,
                                                'CCS纸票录入，接口表头数据插入业务表失败！：' ||
                                                SQLERRM);
            RAISE V_BIZ_EXCEPTION;
        END;

        --遍历收款接口表行数据，插入收款行表
        IF V_LINE_COUNT > 0 THEN
          FOR LINE_ROW IN C_RECEIPT_LINES LOOP
            FOR SALES_MAIN_TYPE_ROW IN C_SALES_MAIN_TYPE LOOP
              IF LINE_ROW.SALES_MAIN_TYPE_CODE =
                 SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_CODE THEN
                V_SALES_MAIN_TYPE_ID   := SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_ID;
                V_SALES_MAIN_TYPE_NAME := SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_NAME;
                EXIT;
              END IF;
            END LOOP;
            BEGIN
              INSERT INTO T_AR_CASH_RECEIPT_LINES
                (CASH_RECEIPT_LINES_ID,
                 CASH_RECEIPT_ID,
                 AMOUNT,
                 REMARK,
                 SALES_MAIN_TYPE_ID,
                 SALES_MAIN_TYPE_CODE,
                 SALES_MAIN_TYPE_NAME,
                 ENTITY_ID)
              VALUES
                (S_AR_CASH_RECEIPT_LINES.NEXTVAL,
                 V_CASH_RECEIPT_ID,
                 LINE_ROW.AMOUNT,
                 LINE_ROW.REMARK,
                 V_SALES_MAIN_TYPE_ID,
                 LINE_ROW.SALES_MAIN_TYPE_CODE,
                 V_SALES_MAIN_TYPE_NAME,
                 HEAD_ROW.ENTITY_ID);
            EXCEPTION
              WHEN OTHERS THEN
                P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CCS_INTO_CIMS.P_RECEIPT_INTO_NEW',
                                                    SQLCODE,
                                                    'CCS纸票录入，接口表行数据插入业务表失败！：' ||
                                                    SQLERRM);
                RAISE V_BIZ_EXCEPTION;
            END;
          END LOOP;
        END IF;

        --插入业务表成功，回写接口表数据
        BEGIN
          UPDATE CIMS.INTF_AR_RECEIPT_HEADERS_CCS C
             SET C.CASH_RECEIPT_CODE = V_CASH_RECEIPT_CODE,
                 C.STATUS            = '0',
                 C.ERROR_INFO        = 'SUCCESS',
                 C.OPERATE_FLAG      = '1'
           WHERE C.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID;
          P_MESSAGE := 'SUCCESS';
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CCS_INTO_CIMS.P_RECEIPT_INTO_NEW',
                                                SQLCODE,
                                                'CCS纸票录入，回写收款单号异常，更新接口表失败！：' ||
                                                SQLERRM);
            RAISE V_BIZ_EXCEPTION;
        END;
        --COMMIT;
      END LOOP;
    ELSE
      P_MESSAGE := '根据CCS提供的收款单头ID' || P_CASH_RECEIPT_ID ||
                   '上接口表INTF_AR_RECEIPT_HEADERS_CCS查询不到数据';
      RAISE V_BIZ_EXCEPTION;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      --ROLLBACK;
      BEGIN
        UPDATE CIMS.INTF_AR_RECEIPT_HEADERS_CCS C
           SET C.STATUS       = '1',
               C.ERROR_INFO   = P_MESSAGE,
               C.OPERATE_FLAG = '1'
         WHERE C.CASH_RECEIPT_ID = P_CASH_RECEIPT_ID;
        --COMMIT;
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CCS_INTO_CIMS.P_RECEIPT_INTO_NEW',
                                            SQLCODE,
                                            P_MESSAGE || SQLERRM);
      END;
  END;

  /*
  * CCS客户内产品转款，接口表数据插入业务表
  */
  PROCEDURE P_TURNFEE_INTO_NEW(P_CASH_TURNFEE_ID IN NUMBER, --批处理ID
                               P_MESSAGE         OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                               ) IS
    --PRAGMA AUTONOMOUS_TRANSACTION;
    V_HEAD_COUNT                NUMBER; --转款头数据总数
    V_METHOD_COUNT              NUMBER; --转款方法数据总数
    V_TF_APPENDIX_COUNT         NUMBER; --附件数据总数
    V_LINE_COUNT                NUMBER; --转款行数据总数
    V_IN_SALES_MAIN_TYPE_COUNT  NUMBER; --转入客户下营销大类数据总数
    V_OUT_SALES_MAIN_TYPE_COUNT NUMBER; --转出客户下营销大类数据总数

    V_TURNFEE_METHOD_ID NUMBER; --转款方法ID
    V_CASH_TURNFEE_CODE VARCHAR2(32); --转款单据编号
    V_CASH_TURNFEE_ID   NUMBER; --转款头ID
    V_CCS_SOURCE_CODE   VARCHAR2(32); --CCS单号
    V_ENTITY_ID         NUMBER; --主体ID

    V_IN_CUS_CEN_ACC_FLAG  NUMBER; --转入客户、营销中心、账户对应关系记录数
    V_OUT_CUS_CEN_ACC_FLAG NUMBER; --转出客户、营销中心、账户对应关系记录数
    V_LINE_AMOUNT          NUMBER; --单张转款单的分款金额总和
    V_APPENDIX_FLAG        VARCHAR2(2); --附件上传标志Y/N
    V_IN_SALES_ERROR       VARCHAR2(100); --转入错误信息
    V_OUT_SALES_ERROR      VARCHAR2(100); --转出错误信息

    V_IN_CUSTOMER_CODE     VARCHAR2(100); --转入客户编码
    V_IN_ACCOUNT_CODE      VARCHAR2(100); --转入账户编码
    V_IN_SALES_CENTER_CODE VARCHAR2(100); --转入营销中心编码

    V_OUT_CUSTOMER_CODE     VARCHAR2(100); --转出客户编码
    V_OUT_ACCOUNT_CODE      VARCHAR2(100); --转出账户编码
    V_OUT_SALES_CENTER_CODE VARCHAR2(100); --转出营销中心编码

    V_IN_CUSTOMER_ID          NUMBER; --转入客户ID
    V_IN_CUSTOMER_NAME        VARCHAR2(300); --转入客户名称
    V_IN_ACCOUNT_ID           NUMBER; --转入账户ID
    V_IN_SALES_CENTER_ID      NUMBER; --转入营销中心ID
    V_IN_SALES_CENTER_NAME    VARCHAR2(100); --转入营销中心名称
    V_IN_SALES_MAIN_TYPE_ID   NUMBER; --转入营销大类ID
    V_IN_SALES_MAIN_TYPE_NAME VARCHAR2(100); --转入营销大类名称

    V_OUT_CUSTOMER_ID          NUMBER; --转出客户ID
    V_OUT_CUSTOMER_NAME        VARCHAR2(300); --转出客户名称
    V_OUT_ACCOUNT_ID           NUMBER; --转出账户ID
    V_OUT_SALES_CENTER_ID      NUMBER; --转出营销中心ID
    V_OUT_SALES_CENTER_NAME    VARCHAR2(100); --转出营销中心名称
    V_OUT_SALES_MAIN_TYPE_ID   NUMBER; --转出营销大类ID
    V_OUT_SALES_MAIN_TYPE_NAME VARCHAR2(100); --转出营销大类名称

    V_IN_ERP_OU_NAME  VARCHAR2(100); --转入OU名称
    V_OUT_ERP_OU_NAME VARCHAR2(100); --转出OU名称

    V_IN_SALES_LOOP_COUNT  NUMBER; --转入营销大类循环记录数
    V_OUT_SALES_LOOP_COUNT NUMBER; --转出营销大类循环记录数
    V_IN_SALES_COUNT          NUMBER; --转入营销大类分款行重复记录数
    V_OUT_SALES_COUNT         NUMBER; --转入营销大类分款行重复记录数
    V_IN_OUT_SALES_COUNT   NUMBER; --转入、转出营销大类相同记录数

    V_TF_APPENDIX VARCHAR2(32); --附件ID

    V_METHOD_CHECK NUMBER; --转款方法ID校验标志
    V_IN_OU_CHECK  NUMBER; --转入OU校验标志
    V_OUT_OU_CHECK NUMBER; --转出OU校验标志

    V_CUST_OU_MESS VARCHAR2(1000); --客户与OU校验信息

    V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常
    
    V_SYSTEM_TF_CHECK   VARCHAR2(32); --是否允许体系外转款
    V_IN_CUSTOMER_SYSTEM_CODE VARCHAR2(100); --转入客户体系
    V_OUT_CUSTOMER_SYSTEM_CODE VARCHAR2(100); --转出客户体系

    --CCS转款头接口表数据
    CURSOR C_INTF_TURNFEE_HEAD IS
      SELECT H.*, M.IN_TURNFEE, M.OUT_TURNFEE
        FROM CIMS.INTF_AR_TURNFEE_HEADERS_CCS H
        LEFT JOIN CIMS.T_AR_RECEIPT_METHODS M
          ON H.RECEIPT_METHOD_ID = M.RECEIPT_METHOD_ID
       WHERE H.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID
         AND NVL(H.OPERATE_FLAG, '0') <> '1';

    HEAD_ROW C_INTF_TURNFEE_HEAD%ROWTYPE; --接口表转款头游标行数据

    --转款行
    CURSOR C_TURNFEE_LINES IS
      SELECT *
        FROM CIMS.INTF_AR_TURNFEE_LINES_CCS L
       WHERE L.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID;

    LINE_ROW C_TURNFEE_LINES%ROWTYPE; --转款行游标行数据

    --转入客户下有效转入营销大类
    CURSOR C_IN_SALES_MAIN_TYPE IS
      SELECT T2.ITEM_CLASS_ID,
             T1.SALES_MAIN_TYPE_CODE,
             T1.SALES_MAIN_TYPE_NAME
        FROM T_CUSTOMER_SALES_MAIN_TYPE T1, T_BD_ITEM_CLASS T2
       WHERE T1.SALES_MAIN_TYPE_CODE = T2.CLASS_CODE
         AND T1.ENTITY_ID = T2.ENTITY_ID
         AND T1.ACTIVE_FLAG = 'Active'
         AND T2.ACTIVE_FLAG = 'Y'
         AND T1.ENTITY_ID = V_ENTITY_ID
         AND T1.CUSTOM_CODE = V_IN_CUSTOMER_CODE;

    IN_SALES_MAIN_TYPE_ROW C_IN_SALES_MAIN_TYPE%ROWTYPE; --有效营销大类游标行数据

    --转出客户下有效转出营销大类
    CURSOR C_OUT_SALES_MAIN_TYPE IS
      SELECT T2.ITEM_CLASS_ID,
             T1.SALES_MAIN_TYPE_CODE,
             T1.SALES_MAIN_TYPE_NAME
        FROM T_CUSTOMER_SALES_MAIN_TYPE T1, T_BD_ITEM_CLASS T2
       WHERE T1.SALES_MAIN_TYPE_CODE = T2.CLASS_CODE
         AND T1.ENTITY_ID = T2.ENTITY_ID
         AND T1.ACTIVE_FLAG = 'Active'
         AND T2.ACTIVE_FLAG = 'Y'
         AND T1.ENTITY_ID = V_ENTITY_ID
         AND T1.CUSTOM_CODE = V_OUT_CUSTOMER_CODE;

    OUT_SALES_MAIN_TYPE_ROW C_OUT_SALES_MAIN_TYPE%ROWTYPE; --有效营销大类游标行数据

    --转入客户、中心、账户
    CURSOR C_IN_CUSTOMER_ACCOUNT_CENTER IS
      SELECT V2.CUSTOMER_ID,
             V2.CUSTOMER_CODE,
             V2.CUSTOMER_NAME,
             V2.ACCOUNT_ID,
             V2.ACCOUNT_CODE,
             V2.SALES_CENTER_ID,
             V2.SALES_CENTER_CODE,
             V2.SALES_CENTER_NAME
        FROM CIMS.V_CUSTOMER_ACCOUNT_SALECENTER V2
       WHERE V2.CUSTOMER_CODE = V_IN_CUSTOMER_CODE
         AND V2.SALES_CENTER_CODE = V_IN_SALES_CENTER_CODE
         AND V2.ACCOUNT_CODE = V_IN_ACCOUNT_CODE
         AND V2.ENTITY_ID = V_ENTITY_ID
         AND V2.ACTIVE_FLAG = 'Active'
         AND V2.ACCOUNT_STATUS = '1'
         AND V2.ORGACTIVE_FLAG = 'Active';

    IN_CUST_ACC_CEN_ROW C_IN_CUSTOMER_ACCOUNT_CENTER%ROWTYPE; --转入客户中心账户游标行数据

    --转出客户、中心、账户
    CURSOR C_OUT_CUSTOMER_ACCOUNT_CENTER IS
      SELECT V2.CUSTOMER_ID,
             V2.CUSTOMER_CODE,
             V2.CUSTOMER_NAME,
             V2.ACCOUNT_ID,
             V2.ACCOUNT_CODE,
             V2.SALES_CENTER_ID,
             V2.SALES_CENTER_CODE,
             V2.SALES_CENTER_NAME
        FROM CIMS.V_CUSTOMER_ACCOUNT_SALECENTER V2
       WHERE V2.CUSTOMER_CODE = V_OUT_CUSTOMER_CODE
         AND V2.SALES_CENTER_CODE = V_OUT_SALES_CENTER_CODE
         AND V2.ACCOUNT_CODE = V_OUT_ACCOUNT_CODE
         AND V2.ENTITY_ID = V_ENTITY_ID
         AND V2.ACTIVE_FLAG = 'Active'
         AND V2.ACCOUNT_STATUS = '1'
         AND V2.ORGACTIVE_FLAG = 'Active';

    OUT_CUST_ACC_CEN_ROW C_OUT_CUSTOMER_ACCOUNT_CENTER%ROWTYPE; --转出客户中心账户游标行数据

    --附件
    CURSOR C_TF_APPENDIX IS
      SELECT *
        FROM CIMS.INTF_AR_APPENDIX_CCS AP
       WHERE AP.SOURCE_CODE = V_CCS_SOURCE_CODE;
    TF_APPENDIX_ROW C_TF_APPENDIX%ROWTYPE; --附件游标行数据

  BEGIN
    P_MESSAGE := 'SUCCESS';
    --获取接口表数据数量
    SELECT COUNT(*)
      INTO V_HEAD_COUNT
      FROM CIMS.INTF_AR_TURNFEE_HEADERS_CCS H
     WHERE H.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID
       AND NVL(H.OPERATE_FLAG, '0') <> '1';

    IF (V_HEAD_COUNT > 0) THEN
      FOR HEAD_ROW IN C_INTF_TURNFEE_HEAD LOOP

        --校验CCS接口数据是否正确
        V_CCS_SOURCE_CODE       := HEAD_ROW.SOURCE_CODE;
        V_TURNFEE_METHOD_ID     := HEAD_ROW.RECEIPT_METHOD_ID;
        V_ENTITY_ID             := HEAD_ROW.ENTITY_ID;
        V_IN_CUSTOMER_CODE      := HEAD_ROW.IN_CUSTOMER_CODE;
        V_IN_ACCOUNT_CODE       := HEAD_ROW.IN_ACCOUNT_CODE;
        V_IN_SALES_CENTER_CODE  := HEAD_ROW.IN_SALES_CENTER_CODE;
        V_OUT_CUSTOMER_CODE     := HEAD_ROW.OUT_CUSTOMER_CODE;
        V_OUT_ACCOUNT_CODE      := HEAD_ROW.OUT_ACCOUNT_CODE;
        V_OUT_SALES_CENTER_CODE := HEAD_ROW.OUT_SALES_CENTER_CODE;

        --校验转款单接口数据:必填项
        IF HEAD_ROW.CASH_TURNFEE_ID IS NULL THEN
          P_MESSAGE := '转款单id为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.SOURCE_CODE IS NULL THEN
          P_MESSAGE := '转款单CCS单据编号为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.RECEIPT_METHOD_ID IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的转款方法为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.RECEIPT_STATUS_ID IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的状态为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.RECEIPT_STATUS_ID <> 1 THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的状态不是1';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_CUSTOMER_CODE IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的转入客户编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_SALES_CENTER_CODE IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的转入营销中心编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_ACCOUNT_CODE IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的转入账户编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_CUSTOMER_CODE IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的转出客户编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_SALES_CENTER_CODE IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的转出营销中心编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_ACCOUNT_CODE IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的转出账户编码为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.IN_ERP_OU_ID IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的转入OU_ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.OUT_ERP_OU_ID IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的转出OU_ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CASH_RECEIPT_DATE IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的单据日期为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.GL_DATE IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的总账日期为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.AMOUNT IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的金额为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CURRENCY_CODE IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的币种为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CREATED_BY IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的制单人为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.CREATION_DATE IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的制单时间为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.ENTITY_ID IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的主体ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.SOURCE_CODE IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的来源单号为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.SOURCE_SYSTEM IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的来源系统为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF HEAD_ROW.REMAEK IS NULL THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的备注为空';
          RAISE V_BIZ_EXCEPTION;
          --校验金额必须大于0
        ELSIF HEAD_ROW.AMOUNT <= 0 THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的金额必须大于0';
          RAISE V_BIZ_EXCEPTION;
        END IF;

        --转入OU与转出OU必须相同
        IF HEAD_ROW.IN_ERP_OU_ID <> HEAD_ROW.OUT_ERP_OU_ID THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的转入OU_ID与转出OU_ID不同';
          RAISE V_BIZ_EXCEPTION;
        END IF;

        --校验转款方法ID是否属于该主体
        BEGIN
          SELECT COUNT(TM.RECEIPT_METHOD_ID)
            INTO V_METHOD_CHECK
            FROM CIMS.T_AR_RECEIPT_METHODS TM
           WHERE TM.RECEIPT_METHOD_ID = HEAD_ROW.RECEIPT_METHOD_ID
             AND TM.ENTITY_ID = HEAD_ROW.ENTITY_ID;
        END;
        IF V_METHOD_CHECK <> 1 THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的转款方法ID有误，不属于主体' ||
                       V_ENTITY_ID || '，或者查询到的转款方法存在多条';
          RAISE V_BIZ_EXCEPTION;
        END IF;

        --校验转入OU_ID是否属于该主体
        BEGIN
          SELECT COUNT(ID)
            INTO V_IN_OU_CHECK
            FROM CIMS.V_UP_CODELIST V
           WHERE V.CODETYPE = 'ar_ou_id'
             AND V.ENTITY_ID = V_ENTITY_ID
             AND V.CODE_VALUE = HEAD_ROW.IN_ERP_OU_ID;
        END;
        IF V_IN_OU_CHECK <> 1 THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的转入OU_ID有误，不属于主体' ||
                       V_ENTITY_ID || '，或者查询到的OU存在多条';
          RAISE V_BIZ_EXCEPTION;
        END IF;

        --校验转出OU_ID是否属于该主体
        BEGIN
          SELECT COUNT(ID)
            INTO V_OUT_OU_CHECK
            FROM CIMS.V_UP_CODELIST V
           WHERE V.CODETYPE = 'ar_ou_id'
             AND V.ENTITY_ID = V_ENTITY_ID
             AND V.CODE_VALUE = HEAD_ROW.OUT_ERP_OU_ID;
        END;
        IF V_OUT_OU_CHECK <> 1 THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的转出OU_ID有误，不属于主体' ||
                       V_ENTITY_ID || '，或者查询到的OU存在多条';
          RAISE V_BIZ_EXCEPTION;
        END IF;

        --客户内产品转款，则转入客户、中心、账户与转出客户、中心、账户必须相同
        IF HEAD_ROW.IN_TURNFEE IS NULL OR HEAD_ROW.OUT_TURNFEE IS NULL THEN
          IF HEAD_ROW.IN_CUSTOMER_CODE <> HEAD_ROW.OUT_CUSTOMER_CODE THEN
            P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的转入客户编码与转出客户编码不同';
            RAISE V_BIZ_EXCEPTION;
          ELSIF HEAD_ROW.IN_ACCOUNT_CODE <> HEAD_ROW.OUT_ACCOUNT_CODE THEN
            P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的转入账户编码与转出账户编码不同';
            RAISE V_BIZ_EXCEPTION;
          ELSIF HEAD_ROW.IN_SALES_CENTER_CODE <>
                HEAD_ROW.OUT_SALES_CENTER_CODE THEN
            P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE ||
                         '的转入营销中心编码与转出营销中心编码不同';
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END IF;
        
        
                        --根据系统参数AR_SYSTEM_TF，是否允许体系外转款
        V_SYSTEM_TF_CHECK := PKG_BD.F_GET_PARAMETER_VALUE('AR_SYSTEM_TF',HEAD_ROW.ENTITY_ID,NULL,NULL);
        IF V_SYSTEM_TF_CHECK = 'N' THEN 
            IF HEAD_ROW.IN_ACCOUNT_CODE <> HEAD_ROW.OUT_ACCOUNT_CODE and HEAD_ROW.IN_CUSTOMER_CODE <> HEAD_ROW.OUT_CUSTOMER_CODE  THEN   
               SELECT
                 C.SYSTEM_CODE
                INTO
                  V_IN_CUSTOMER_SYSTEM_CODE
               FROM 
                 T_CUSTOMER_SYSTEM C
               WHERE   
                 C.CUSTOMER_CODE = HEAD_ROW.IN_CUSTOMER_CODE;
                 
                SELECT
                 C.SYSTEM_CODE
                INTO
                  V_OUT_CUSTOMER_SYSTEM_CODE
               FROM 
                 T_CUSTOMER_SYSTEM C
               WHERE   
                 C.CUSTOMER_CODE = HEAD_ROW.OUT_CUSTOMER_CODE;
                 
              IF   V_IN_CUSTOMER_SYSTEM_CODE is null 
                 OR V_OUT_CUSTOMER_SYSTEM_CODE is null
                 OR V_IN_CUSTOMER_SYSTEM_CODE <> V_OUT_CUSTOMER_SYSTEM_CODE THEN
                   P_MESSAGE := '转款单'  ||'不同体系内客户之间不能做转款';
              RAISE V_BIZ_EXCEPTION;
              END IF;       
            END IF;   
        END IF;

        --转款方法数据数量
        SELECT COUNT(*)
          INTO V_METHOD_COUNT
          FROM CIMS.V_AR_RECEIPT_METHODS_CCS M
         WHERE M.RECEIPT_METHOD_ID = V_TURNFEE_METHOD_ID
           AND M.BUSINESS_TYPE = '3';

        --校验转款必填项（转款方法配置）
        IF V_METHOD_COUNT <> 1 THEN
          P_MESSAGE := '根据转款单' || V_CCS_SOURCE_CODE || '的转款方法ID （' ||
                       V_TURNFEE_METHOD_ID || '）查询到的转款方法为空，或者为多条';
          RAISE V_BIZ_EXCEPTION;
        END IF;

        --校验附件:根据收款方法判断附件是否已经上传（厨电必须上传附件）
        BEGIN
          --2016-01-20修改
          SELECT COUNT(*)
              INTO V_TF_APPENDIX_COUNT
              FROM CIMS.INTF_AR_APPENDIX_CCS X
             WHERE X.SOURCE_CODE = HEAD_ROW.SOURCE_CODE;

          SELECT TM.APPENDIX_FLAG
            INTO V_APPENDIX_FLAG
            FROM CIMS.T_AR_RECEIPT_METHODS TM
           WHERE TM.RECEIPT_METHOD_ID = HEAD_ROW.RECEIPT_METHOD_ID
             AND TM.ENTITY_ID = HEAD_ROW.ENTITY_ID;
          IF V_APPENDIX_FLAG = 'Y' THEN
            --获取CCS上传的附件记录数，若总记录数大于0，则表示已经上传附件，否则，没有上传附件。
            /*
            SELECT COUNT(*)
              INTO V_TF_APPENDIX_COUNT
              FROM CIMS.INTF_AR_APPENDIX_CCS X
             WHERE X.SOURCE_CODE = HEAD_ROW.SOURCE_CODE;
             */
            IF V_TF_APPENDIX_COUNT = 0 THEN
              P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的附件为空';
              RAISE V_BIZ_EXCEPTION;
            END IF;
          END IF;
        END;

        --校验转入客户、中心、账户是否对应
        BEGIN
          SELECT COUNT(*)
            INTO V_IN_CUS_CEN_ACC_FLAG
            FROM CIMS.V_CUSTOMER_ACCOUNT_SALECENTER V
           WHERE V.CUSTOMER_CODE = V_IN_CUSTOMER_CODE
             AND V.SALES_CENTER_CODE = V_IN_SALES_CENTER_CODE
             AND V.ACCOUNT_CODE = V_IN_ACCOUNT_CODE
             AND V.ENTITY_ID = V_ENTITY_ID
             AND V.ACTIVE_FLAG = 'Active'
             AND V.ACCOUNT_STATUS = '1'
             AND V.ORGACTIVE_FLAG = 'Active';

          IF V_IN_CUS_CEN_ACC_FLAG <> 1 THEN
            P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE ||
                         '中的转入客户、转入营销中心、转入账户状态无效，或者没有一一对应';
            RAISE V_BIZ_EXCEPTION;
          ELSE
            FOR IN_CUST_ACC_CEN_ROW IN C_IN_CUSTOMER_ACCOUNT_CENTER LOOP
              V_IN_CUSTOMER_ID       := IN_CUST_ACC_CEN_ROW.CUSTOMER_ID;
              V_IN_CUSTOMER_NAME     := IN_CUST_ACC_CEN_ROW.CUSTOMER_NAME;
              V_IN_ACCOUNT_ID        := IN_CUST_ACC_CEN_ROW.ACCOUNT_ID;
              V_IN_SALES_CENTER_ID   := IN_CUST_ACC_CEN_ROW.SALES_CENTER_ID;
              V_IN_SALES_CENTER_NAME := IN_CUST_ACC_CEN_ROW.SALES_CENTER_NAME;
            END LOOP;
          END IF;
        END;

        --校验转出客户、中心、账户是否对应
        BEGIN
          SELECT COUNT(*)
            INTO V_OUT_CUS_CEN_ACC_FLAG
            FROM CIMS.V_CUSTOMER_ACCOUNT_SALECENTER V
           WHERE V.CUSTOMER_CODE = V_OUT_CUSTOMER_CODE
             AND V.SALES_CENTER_CODE = V_OUT_SALES_CENTER_CODE
             AND V.ACCOUNT_CODE = V_OUT_ACCOUNT_CODE
             AND V.ENTITY_ID = V_ENTITY_ID
             AND V.ACTIVE_FLAG = 'Active'
             AND V.ACCOUNT_STATUS = '1'
             AND V.ORGACTIVE_FLAG = 'Active';

          IF V_OUT_CUS_CEN_ACC_FLAG <> 1 THEN
            P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE ||
                         '中的转出客户、转出营销中心、转出账户状态无效，或者没有一一对应';
            RAISE V_BIZ_EXCEPTION;
          ELSE
            FOR OUT_CUST_ACC_CEN_ROW IN C_OUT_CUSTOMER_ACCOUNT_CENTER LOOP
              V_OUT_CUSTOMER_ID       := OUT_CUST_ACC_CEN_ROW.CUSTOMER_ID;
              V_OUT_CUSTOMER_NAME     := OUT_CUST_ACC_CEN_ROW.CUSTOMER_NAME;
              V_OUT_ACCOUNT_ID        := OUT_CUST_ACC_CEN_ROW.ACCOUNT_ID;
              V_OUT_SALES_CENTER_ID   := OUT_CUST_ACC_CEN_ROW.SALES_CENTER_ID;
              V_OUT_SALES_CENTER_NAME := OUT_CUST_ACC_CEN_ROW.SALES_CENTER_NAME;
            END LOOP;
          END IF;
        END;

        --2015-10-22修改，增加客户-OU对应关系校验
        --转入客户、OU
        V_CUST_OU_MESS := PKG_AR_COMMON.F_VALIDATE_CUST_OU(V_IN_CUSTOMER_ID,
                                                           HEAD_ROW.IN_ERP_OU_ID);
        IF V_CUST_OU_MESS <> 'SUCCESS' THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '中的转入客户（' ||
                       V_IN_CUSTOMER_ID || '）、转入OU（' ||
                       HEAD_ROW.IN_ERP_OU_ID || '）没有对应';
          RAISE V_BIZ_EXCEPTION;
        END IF;
        --转出客户、OU
        V_CUST_OU_MESS := PKG_AR_COMMON.F_VALIDATE_CUST_OU(V_OUT_CUSTOMER_ID,
                                                           HEAD_ROW.OUT_ERP_OU_ID);
        IF V_CUST_OU_MESS <> 'SUCCESS' THEN
          P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '中的转出客户（' ||
                       V_OUT_CUSTOMER_ID || '）、转出OU（' ||
                       HEAD_ROW.OUT_ERP_OU_ID || '）没有对应';
          RAISE V_BIZ_EXCEPTION;
        END IF;

        --校验客户下的营销大类
        BEGIN
          SELECT COUNT(*)
            INTO V_LINE_COUNT
            FROM CIMS.INTF_AR_TURNFEE_LINES_CCS L
           WHERE L.CASH_TURNFEE_ID = HEAD_ROW.CASH_TURNFEE_ID;

          IF V_LINE_COUNT > 0 THEN
            V_LINE_AMOUNT := 0.0;
            --校验分款明细
            FOR LINE_ROW IN C_TURNFEE_LINES LOOP
              IF LINE_ROW.AMOUNT IS NULL THEN
                P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的分款明细中金额为空';
                RAISE V_BIZ_EXCEPTION;
              ELSIF LINE_ROW.AMOUNT IS NOT NULL AND LINE_ROW.AMOUNT <= 0 THEN
                P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的分款明细中金额小于等于0';
                RAISE V_BIZ_EXCEPTION;
              ELSIF LINE_ROW.IN_SALES_MAIN_TYPE_CODE IS NULL THEN
                P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE ||
                             '的分款明细中转入营销大类编码为空';
                RAISE V_BIZ_EXCEPTION;
              ELSIF LINE_ROW.OUT_SALES_MAIN_TYPE_CODE IS NULL THEN
                P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE ||
                             '的分款明细中转出营销大类编码为空';
                RAISE V_BIZ_EXCEPTION;
              ELSE
                --客户内产品转款
                IF HEAD_ROW.IN_TURNFEE IS NULL AND
                   HEAD_ROW.OUT_TURNFEE IS NULL THEN
                  --校验转入营销大类与转出营销大类是否相同，若相同则校验失败，否则校验通过
                  BEGIN
                    SELECT COUNT(L.IN_SALES_MAIN_TYPE_CODE)
                      INTO V_IN_OUT_SALES_COUNT
                      FROM CIMS.INTF_AR_TURNFEE_LINES_CCS L
                     WHERE L.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID
                       AND L.IN_SALES_MAIN_TYPE_CODE =
                           L.OUT_SALES_MAIN_TYPE_CODE;
                  END;
                  IF V_IN_OUT_SALES_COUNT > 0 THEN
                    P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE ||
                                 '的分款明细中转入营销大类和转出营销大类相同';
                   RAISE V_BIZ_EXCEPTION;
                  END IF;
                END IF;

                --校验分款中的转入大类和转出大类是否重复，若重复则校验失败，否则校验通过
                BEGIN
                  SELECT COUNT(*)
                    INTO V_IN_SALES_COUNT
                    FROM (SELECT L.IN_SALES_MAIN_TYPE_CODE ,
                                 COUNT(L.IN_SALES_MAIN_TYPE_CODE) SALES_COUNT
                            FROM CIMS.INTF_AR_TURNFEE_LINES_CCS L
                           WHERE L.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID
                           GROUP BY L.IN_SALES_MAIN_TYPE_CODE 
                          HAVING COUNT(L.IN_SALES_MAIN_TYPE_CODE)>1);
                END;
                IF V_IN_SALES_COUNT> 0  THEN
                  P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE ||
                               '的分款明细中存在重复的分款行，即分款行1和分款行2中的转入营销大类相同';
                  RAISE V_BIZ_EXCEPTION;
                END IF;
                
                BEGIN
                  SELECT COUNT(*)
                    INTO V_OUT_SALES_COUNT
                    FROM (SELECT L.OUT_SALES_MAIN_TYPE_CODE ,
                                 COUNT(L.OUT_SALES_MAIN_TYPE_CODE) SALES_COUNT
                            FROM CIMS.INTF_AR_TURNFEE_LINES_CCS L
                           WHERE L.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID
                           GROUP BY L.OUT_SALES_MAIN_TYPE_CODE 
                          HAVING COUNT(L.OUT_SALES_MAIN_TYPE_CODE)>1);
                END;
                IF V_OUT_SALES_COUNT>0 THEN
                  P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE ||
                               '的分款明细中存在重复的分款行，即分款行1和分款行2中的转出营销大类相同';
                  RAISE V_BIZ_EXCEPTION;
                END IF;
                BEGIN
                  --转入客户下的有效营销大类总数
                  SELECT COUNT(*)
                    INTO V_IN_SALES_MAIN_TYPE_COUNT
                    FROM T_CUSTOMER_SALES_MAIN_TYPE T1, T_BD_ITEM_CLASS T2
                   WHERE T1.SALES_MAIN_TYPE_CODE = T2.CLASS_CODE
                     AND T1.ENTITY_ID = T2.ENTITY_ID
                     AND T1.ACTIVE_FLAG = 'Active'
                     AND T2.ACTIVE_FLAG = 'Y'
                     AND T1.ENTITY_ID = HEAD_ROW.ENTITY_ID
                     AND T1.CUSTOM_ID = V_IN_CUSTOMER_ID;
                  --转出客户下的有效营销大类总数
                  SELECT COUNT(*)
                    INTO V_OUT_SALES_MAIN_TYPE_COUNT
                    FROM T_CUSTOMER_SALES_MAIN_TYPE T1, T_BD_ITEM_CLASS T2
                   WHERE T1.SALES_MAIN_TYPE_CODE = T2.CLASS_CODE
                     AND T1.ENTITY_ID = T2.ENTITY_ID
                     AND T1.ACTIVE_FLAG = 'Active'
                     AND T2.ACTIVE_FLAG = 'Y'
                     AND T1.ENTITY_ID = HEAD_ROW.ENTITY_ID
                     AND T1.CUSTOM_ID = V_OUT_CUSTOMER_ID;
                END;
                ---判断转入营销大类是否有效，是否属于转款的客户
                IF V_IN_SALES_MAIN_TYPE_COUNT > 0 THEN
                  V_IN_SALES_LOOP_COUNT := 0;
                  FOR IN_SALES_MAIN_TYPE_ROW IN C_IN_SALES_MAIN_TYPE LOOP
                    V_IN_SALES_LOOP_COUNT := V_IN_SALES_LOOP_COUNT + 1;
                    IF LINE_ROW.IN_SALES_MAIN_TYPE_CODE =
                       IN_SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_CODE THEN
                      V_IN_SALES_ERROR := 'OK';
                      EXIT;
                    ELSE
                      IF V_IN_SALES_LOOP_COUNT = V_IN_SALES_MAIN_TYPE_COUNT THEN
                        P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE ||
                                     '的分款明细中转入营销大类编码不是有效的，或不存在';
                        RAISE V_BIZ_EXCEPTION;
                      END IF;
                    END IF;
                  END LOOP;
                ELSE
                  P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE ||
                               '转入客户下的转入营销大类编码为空';
                  RAISE V_BIZ_EXCEPTION;
                END IF;
                --判断转出营销大类是否有效，是否属于转款的客户
                IF V_OUT_SALES_MAIN_TYPE_COUNT > 0 THEN
                  V_OUT_SALES_LOOP_COUNT := 0;
                  FOR OUT_SALES_MAIN_TYPE_ROW IN C_OUT_SALES_MAIN_TYPE LOOP
                    V_OUT_SALES_LOOP_COUNT := V_OUT_SALES_LOOP_COUNT + 1;
                    IF LINE_ROW.OUT_SALES_MAIN_TYPE_CODE =
                       OUT_SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_CODE THEN
                      V_OUT_SALES_ERROR := 'OK';
                      EXIT;
                    ELSE
                      IF V_OUT_SALES_LOOP_COUNT =
                         V_OUT_SALES_MAIN_TYPE_COUNT THEN
                        P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE ||
                                     '的分款明细中转出营销大类编码不是有效的，或不存在';
                        RAISE V_BIZ_EXCEPTION;
                      END IF;
                    END IF;
                  END LOOP;
                ELSE
                  P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE ||
                               '转入客户下的转入营销大类编码为空';
                  RAISE V_BIZ_EXCEPTION;
                END IF;
              END IF;
              V_LINE_AMOUNT := V_LINE_AMOUNT + LINE_ROW.AMOUNT;
            END LOOP;
          ELSE
            P_MESSAGE := '转款单行为空';
            RAISE V_BIZ_EXCEPTION;
          END IF;
          IF V_IN_SALES_ERROR = 'OK' AND V_OUT_SALES_ERROR = 'OK' AND
             V_LINE_AMOUNT <> HEAD_ROW.AMOUNT THEN
            P_MESSAGE := '转款单' || V_CCS_SOURCE_CODE || '的金额与分款明细中金额总和不等';
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END;
        

        
        --附件
        IF V_TF_APPENDIX_COUNT > 0 THEN
          --附件ID
          SELECT 'ARTF' || S_AR_RP_APPENDIX.NEXTVAL
            INTO V_TF_APPENDIX
            FROM DUAL;
          FOR TF_APPENDIX_ROW IN C_TF_APPENDIX LOOP
            --插入附件表
            INSERT INTO IMS_FILEINFO_INTERFACE
              (ID, BUSINESS_ID, BUSINESS_TYPE, FILE_PATH, CREATED_DATE)
            VALUES
              (SEQ_IMS_FILEINFO.NEXTVAL,
               V_TF_APPENDIX,
               'arTurnfeeCode',
               TF_APPENDIX_ROW.FILE_PATH,
               SYSDATE);
          END LOOP;
        END IF;
        
        --客户内转款（客户内不同营销中心或者客户内相同营销中心不同营销大类），由于转款流程已经在ccs走完，所以到cims系统直接变为已审核状态 add by huanghb12
        IF HEAD_ROW.IN_CUSTOMER_CODE = HEAD_ROW.OUT_CUSTOMER_CODE THEN
          HEAD_ROW.RECEIPT_STATUS_ID := '5';
        END IF;

        --转入OU名称
        SELECT U.ERP_OU_NAME
          INTO V_IN_ERP_OU_NAME
          FROM CIMS.V_AR_ENTITY_OU_CCS U
         WHERE U.ERP_OU_ID = HEAD_ROW.IN_ERP_OU_ID;

        --转出OU名称
        SELECT U.ERP_OU_NAME
          INTO V_OUT_ERP_OU_NAME
          FROM CIMS.V_AR_ENTITY_OU_CCS U
         WHERE U.ERP_OU_ID = HEAD_ROW.OUT_ERP_OU_ID;

        --生成转款单据号
        BEGIN
          V_CASH_TURNFEE_CODE := PKG_BD.F_GET_BILL_NO('ARTFCODE',
                                                      NULL,
                                                      HEAD_ROW.ENTITY_ID,
                                                      NULL);
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := '取转款单据号失败！';
            RAISE V_BIZ_EXCEPTION;
        END;

        --获取转款单据ID
        SELECT S_AR_CASH_TURNFEE_HEADER.NEXTVAL
          INTO V_CASH_TURNFEE_ID
          FROM DUAL;

        BEGIN
          --遍历收款接口表数据，插入收款头表
          INSERT INTO T_AR_CASH_TURNFEE_HEADER
            (CASH_TURNFEE_ID,
             CASH_TURNFEE_CODE,
             OUT_CUSTOMER_ID,
             OUT_CUSTOMER_CODE,
             OUT_CUSTOMER_NAME,
             OUT_ACCOUNT_ID,
             OUT_ACCOUNT_CODE,
             OUT_SALES_CENTER_ID,
             OUT_SALES_CENTER_CODE,
             OUT_SALES_CENTER_NAME,
             OUT_ERP_OU_ID,
             OUT_ERP_OU_NAME,
             IN_CUSTOMER_ID,
             IN_CUSTOMER_CODE,
             IN_CUSTOMER_NAME,
             IN_ACCOUNT_ID,
             IN_ACCOUNT_CODE,
             IN_SALES_CENTER_ID,
             IN_SALES_CENTER_CODE,
             IN_SALES_CENTER_NAME,
             IN_ERP_OU_ID,
             IN_ERP_OU_NAME,
             CASH_RECEIPT_DATE,
             GL_DATE,
             AMOUNT,
             UPPER_AMOUNT,
             CURRENCY_CODE,
             STATUS,
             CASH_RECEIPT_CREATED_BY,
             CASH_RECEIPT_CREATION_BY_TIME,
             REMARK,
             ENTITY_ID,
             RECEIPT_METHOD_ID,
             APPENDIX_ID,
             ATTRIBUTE2,
             ATTRIBUTE3,
             --2015-10-22修改，增加中转关联号
             ATTRIBUTE4,
             VERSION_NUM)
          VALUES
            (V_CASH_TURNFEE_ID,
             V_CASH_TURNFEE_CODE,
             V_OUT_CUSTOMER_ID,
             V_OUT_CUSTOMER_CODE,
             V_OUT_CUSTOMER_NAME,
             V_OUT_ACCOUNT_ID,
             V_OUT_ACCOUNT_CODE,
             V_OUT_SALES_CENTER_ID,
             V_OUT_SALES_CENTER_CODE,
             V_OUT_SALES_CENTER_NAME,
             HEAD_ROW.OUT_ERP_OU_ID,
             V_OUT_ERP_OU_NAME,
             V_IN_CUSTOMER_ID,
             V_IN_CUSTOMER_CODE,
             V_IN_CUSTOMER_NAME,
             V_IN_ACCOUNT_ID,
             V_IN_ACCOUNT_CODE,
             V_IN_SALES_CENTER_ID,
             V_IN_SALES_CENTER_CODE,
             V_IN_SALES_CENTER_NAME,
             HEAD_ROW.IN_ERP_OU_ID,
             V_IN_ERP_OU_NAME,
             HEAD_ROW.CASH_RECEIPT_DATE,
             HEAD_ROW.GL_DATE,
             HEAD_ROW.AMOUNT,
             MONEY_TO_RMB(HEAD_ROW.AMOUNT),
             HEAD_ROW.CURRENCY_CODE,
             HEAD_ROW.RECEIPT_STATUS_ID,
             HEAD_ROW.CREATED_BY,
             HEAD_ROW.CREATION_DATE,
             HEAD_ROW.REMAEK,
             HEAD_ROW.ENTITY_ID,
             HEAD_ROW.RECEIPT_METHOD_ID,
             V_TF_APPENDIX,
             HEAD_ROW.SOURCE_SYSTEM,
             HEAD_ROW.SOURCE_CODE,
             V_CASH_TURNFEE_CODE,
             '0');
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CCS_INTO_CIMS.P_TURNFEE_INTO_NEW',
                                                SQLCODE,
                                                'CCS客户内产品转款，接口表数据插入业务表失败！：' ||
                                                SQLERRM);
            RAISE V_BIZ_EXCEPTION;
        END;
        --遍历转款接口表行数据，插入转款行表
        IF V_LINE_COUNT > 0 THEN
          FOR LINE_ROW IN C_TURNFEE_LINES LOOP
            FOR OUT_SALES_MAIN_TYPE_ROW IN C_OUT_SALES_MAIN_TYPE LOOP
              IF LINE_ROW.OUT_SALES_MAIN_TYPE_CODE =
                 OUT_SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_CODE THEN
                V_OUT_SALES_MAIN_TYPE_ID   := OUT_SALES_MAIN_TYPE_ROW.ITEM_CLASS_ID;
                V_OUT_SALES_MAIN_TYPE_NAME := OUT_SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_NAME;
                EXIT;
              END IF;
            END LOOP;
            FOR IN_SALES_MAIN_TYPE_ROW IN C_IN_SALES_MAIN_TYPE LOOP
              IF LINE_ROW.IN_SALES_MAIN_TYPE_CODE =
                 IN_SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_CODE THEN
                V_IN_SALES_MAIN_TYPE_ID   := IN_SALES_MAIN_TYPE_ROW.ITEM_CLASS_ID;
                V_IN_SALES_MAIN_TYPE_NAME := IN_SALES_MAIN_TYPE_ROW.SALES_MAIN_TYPE_NAME;
                EXIT;
              END IF;
            END LOOP;

            BEGIN
              INSERT INTO T_AR_CASH_TURNFEE_LINE
                (CASH_TURNFEE_LINE_ID,
                 CASH_TURNFEE_ID,
                 AMOUNT,
                 REMARK,
                 IN_SALES_MAIN_TYPE_ID,
                 IN_SALES_MAIN_TYPE_CODE,
                 IN_SALES_MAIN_TYPE_NAME,
                 OUT_SALES_MAIN_TYPE_ID,
                 OUT_SALES_MAIN_TYPE_CODE,
                 OUT_SALES_MAIN_TYPE_NAME,
                 ENTITY_ID)
              VALUES
                (S_AR_CASH_TURNFEE_LINE.NEXTVAL,
                 V_CASH_TURNFEE_ID,
                 LINE_ROW.AMOUNT,
                 LINE_ROW.REMARK,
                 V_IN_SALES_MAIN_TYPE_ID,
                 LINE_ROW.IN_SALES_MAIN_TYPE_CODE,
                 V_IN_SALES_MAIN_TYPE_NAME,
                 V_OUT_SALES_MAIN_TYPE_ID,
                 LINE_ROW.OUT_SALES_MAIN_TYPE_CODE,
                 V_OUT_SALES_MAIN_TYPE_NAME,
                 HEAD_ROW.ENTITY_ID);
            EXCEPTION
              WHEN OTHERS THEN
                P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CCS_INTO_CIMS.P_TURNFEE_INTO_NEW',
                                                    SQLCODE,
                                                    'CCS客户内产品转款，接口表行数据插入业务表失败！：' ||
                                                    SQLERRM);
                RAISE V_BIZ_EXCEPTION;
            END;
          END LOOP;
        END IF;
        --插入业务表成功，回写接口表数据
        BEGIN
          UPDATE CIMS.INTF_AR_TURNFEE_HEADERS_CCS C
             SET C.CASH_TURNFEE_CODE = V_CASH_TURNFEE_CODE,
                 C.STATUS            = '0',
                 C.ERROR_INFO        = 'SUCCESS',
                 C.OPERATE_FLAG      = '1'
           WHERE C.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID;
          P_MESSAGE := 'SUCCESS';
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CCS_INTO_CIMS.P_TURNFEE_INTO_NEW',
                                                SQLCODE,
                                                'CCS客户内产品转款，回写转款单号异常，更新接口表失败！：' ||
                                                SQLERRM);
            RAISE V_BIZ_EXCEPTION;
        END;
        --COMMIT;
      END LOOP;
    ELSE
      P_MESSAGE := '根据CCS提供的转款单头ID' || P_CASH_TURNFEE_ID ||
                   '上接口表INTF_AR_TURNFEE_HEADERS_CCS查询不到数据';
      RAISE V_BIZ_EXCEPTION;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      --ROLLBACK;
      BEGIN
        UPDATE CIMS.INTF_AR_TURNFEE_HEADERS_CCS C
           SET C.STATUS       = '1',
               C.ERROR_INFO   = P_MESSAGE,
               C.OPERATE_FLAG = '1'
         WHERE C.CASH_TURNFEE_ID = P_CASH_TURNFEE_ID;
        --COMMIT;
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CCS_INTO_CIMS.P_TURNFEE_INTO_NEW',
                                            SQLCODE,
                                            P_MESSAGE || SQLERRM);
      END;
  END;

  /*
  * CCS三方解付申请引入CIMS，接口表数据插入业务表
  */
  PROCEDURE P_THREE_PAY_APPLY_INTO(P_THREE_PAY_ID IN NUMBER, --批处理ID
                                   P_MESSAGE      OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                   ) IS
    --PRAGMA AUTONOMOUS_TRANSACTION;
    V_THREE_PAY_COUNT          NUMBER; --解付明细数据总数
    V_RECEIPT_STATUS_ID        NUMBER; --收款单据状态ID
    V_RECEIPT_LINE_ID          NUMBER; --收款行ID
    V_THREE_PAY_SUBTOTAL_COUNT NUMBER; --三方解付明细分类总和记录总数
    V_UNSOLUTION_AMOUNT        NUMBER; --未解付金额
    V_THREE_PAY_ID             NUMBER; --业务表三方承兑解付ID序列
    V_BIZ_EXCEPTION EXCEPTION; --自定义业务异常

    V_APPENDIX_FLAG   VARCHAR2(2); --附件上传标志Y/N  add by anht
    V_APPENDIX_COUNT  NUMBER; --附件数据总数  add by anht
    V_RP_APPENDIX     VARCHAR2(32); --附件ID  add by anht
    V_CCS_SOURCE_CODE VARCHAR2(32); --CCS单号 add by anht

    --CCS三方解付接口表数据
    CURSOR C_THREE_PAY_APPLY_DETAIL IS
      SELECT *
        FROM CIMS.INTF_AR_ACCE_SOLU_PAY_CCS H
       WHERE H.THREE_PAY_ID = P_THREE_PAY_ID
         AND NVL(H.ATTRIBUTE1, '0') <> '1';

    THREE_PAY_ROW C_THREE_PAY_APPLY_DETAIL%ROWTYPE; --解付明细接口表游标行数据

    CURSOR C_THREE_PAY_APPLY_SUBTOTAL IS
      SELECT *
        FROM CIMS.V_AR_ACCE_SOLU_PAY_CCS V
       WHERE V.CASH_RECEIPT_LINES_ID = V_RECEIPT_LINE_ID;

    THREE_PAY_SUBTOTAL_ROW C_THREE_PAY_APPLY_SUBTOTAL%ROWTYPE; --解付明细视图游标行数据

    --附件 add by anht
    CURSOR C_RP_APPENDIX IS
      SELECT *
        FROM CIMS.INTF_AR_SOLU_APPENDIX_CCS AP
       WHERE AP.CCS_THREE_PAY_ID = P_THREE_PAY_ID;
    RP_APPENDIX_ROW C_RP_APPENDIX%ROWTYPE;

  BEGIN
    P_MESSAGE := 'SUCCESS';
    --获取接口表数据数量
    SELECT COUNT(*)
      INTO V_THREE_PAY_COUNT
      FROM CIMS.INTF_AR_ACCE_SOLU_PAY_CCS H
     WHERE H.THREE_PAY_ID = P_THREE_PAY_ID
       AND NVL(H.ATTRIBUTE1, '0') <> '1';

    IF (V_THREE_PAY_COUNT > 0) THEN
      FOR THREE_PAY_ROW IN C_THREE_PAY_APPLY_DETAIL LOOP
        V_RECEIPT_LINE_ID := THREE_PAY_ROW.CASH_RECEIPT_LINES_ID;
        V_CCS_SOURCE_CODE := THREE_PAY_ROW.SOURCE_CODE; --保存来源单号 add by anht

        --1、校验必填字段是否为空
        IF V_RECEIPT_LINE_ID IS NULL THEN
          P_MESSAGE := '收款单据行ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF THREE_PAY_ROW.THREE_PAY_ID IS NULL THEN
          P_MESSAGE := '三方承兑解付申请ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF THREE_PAY_ROW.SOLUTION_PAY_STATUS IS NULL THEN
          P_MESSAGE := '解付状态ID为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF THREE_PAY_ROW.SOLUTION_PAY_AMOUNT IS NULL THEN
          P_MESSAGE := '申请解付金额为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF THREE_PAY_ROW.SOLUTION_PAY_BY IS NULL THEN
          P_MESSAGE := '解付申请人为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF THREE_PAY_ROW.SOLUTION_PAY_TIME IS NULL THEN
          P_MESSAGE := '解付申请时间为空';
          RAISE V_BIZ_EXCEPTION;
        ELSIF THREE_PAY_ROW.ENTITY_ID IS NULL THEN
          P_MESSAGE := '主体ID为空';
          RAISE V_BIZ_EXCEPTION;
          --2015-09-08修改，CCS申请解付的单据，可以是CCS录入的，也可以是C-IMS系统的单据，取消来源单号、系统的校验
          /*
          ELSIF THREE_PAY_ROW.SOURCE_LINE_CODE IS NULL THEN
            P_MESSAGE := '来源单据行号为空';
            RAISE V_BIZ_EXCEPTION;
          ELSIF THREE_PAY_ROW.SOURCE_CODE IS NULL THEN
            P_MESSAGE := '来源单据号（CCS单号）为空';
            RAISE V_BIZ_EXCEPTION;
          ELSIF THREE_PAY_ROW.SOURCE_SYSTEM IS NULL THEN
            P_MESSAGE := '来源系统为空';
            RAISE V_BIZ_EXCEPTION;
            */
        END IF;

        --2、校验三方解付明细对应的收款单，如果单据状态为3-已确认（且冲销原单号为空）、5-已审核、6-已汇，则允许申请解付
        --2015-09-08修改，取消来源单号关联，使用收款单行ID关联
        SELECT COUNT(*)
          INTO V_RECEIPT_STATUS_ID
          FROM CIMS.T_AR_CASH_RECEIPT_HEADERS TH,
               CIMS.T_AR_CASH_RECEIPT_LINES   L,
               CIMS.INTF_AR_ACCE_SOLU_PAY_CCS PAY
         WHERE TH.CASH_RECEIPT_ID = L.CASH_RECEIPT_ID
           AND L.CASH_RECEIPT_LINES_ID = PAY.CASH_RECEIPT_LINES_ID
           AND PAY.THREE_PAY_ID = P_THREE_PAY_ID
           AND TH.WRITEOFF_RECEIPT_CODE IS NULL
           AND TH.RECEIPT_STATUS_ID IN (3, 5, 6);

        IF V_RECEIPT_STATUS_ID = 0 THEN
          P_MESSAGE := '根据CCS提供的三方解付明细申请ID' || P_THREE_PAY_ID ||
                       '，查询不到单据状态为已确认(未冲销)/已审核/已汇的收款单，不允许进行解付申请';
          RAISE V_BIZ_EXCEPTION;
        ELSIF V_RECEIPT_STATUS_ID > 1 THEN
          P_MESSAGE := '根据CCS提供的三方解付明细申请ID' || P_THREE_PAY_ID ||
                       '，查询到的收款单为多条，数据有问题，不允许进行解付申请';
          RAISE V_BIZ_EXCEPTION;
        END IF;

        --3、申请的解付金额必须大于0
        IF THREE_PAY_ROW.SOLUTION_PAY_AMOUNT <= 0 THEN
          P_MESSAGE := '解付金额为' || THREE_PAY_ROW.SOLUTION_PAY_AMOUNT ||
                       '，不允许进行解付申请';
          RAISE V_BIZ_EXCEPTION;
        END IF;

        --4、申请的解付状态为1
        IF THREE_PAY_ROW.SOLUTION_PAY_STATUS <> 1 THEN
          P_MESSAGE := '解付状态为' || THREE_PAY_ROW.SOLUTION_PAY_STATUS ||
                       '，不允许进行解付申请';
          RAISE V_BIZ_EXCEPTION;
        END IF;

        --5、校验申请的解付金额<=行金额-（已解付金额+待解付金额）
        --获取已经解付的金额明细记录数
        SELECT COUNT(*)
          INTO V_THREE_PAY_SUBTOTAL_COUNT
          FROM CIMS.V_AR_ACCE_SOLU_PAY_CCS V
         WHERE V.CASH_RECEIPT_LINES_ID = V_RECEIPT_LINE_ID;
        --比较未解付金额与申请解付金额大小
        IF V_THREE_PAY_SUBTOTAL_COUNT > 0 THEN
          FOR THREE_PAY_SUBTOTAL_ROW IN C_THREE_PAY_APPLY_SUBTOTAL LOOP
            V_UNSOLUTION_AMOUNT := THREE_PAY_SUBTOTAL_ROW.LINE_AMOUNT -
                                   THREE_PAY_SUBTOTAL_ROW.SOLUTION_AMOUNT -
                                   THREE_PAY_SUBTOTAL_ROW.WAIT_SOLUTION_AMOUNT;
            IF V_UNSOLUTION_AMOUNT < THREE_PAY_ROW.SOLUTION_PAY_AMOUNT THEN
              P_MESSAGE := '申请的解付金额' || THREE_PAY_ROW.SOLUTION_PAY_AMOUNT ||
                           '过大，超过未解付金额' || V_UNSOLUTION_AMOUNT || '(=行金额' ||
                           THREE_PAY_SUBTOTAL_ROW.LINE_AMOUNT || '-已解付金额' ||
                           THREE_PAY_SUBTOTAL_ROW.SOLUTION_AMOUNT ||
                           '-待解付金额' ||
                           THREE_PAY_SUBTOTAL_ROW.WAIT_SOLUTION_AMOUNT || ')';
              RAISE V_BIZ_EXCEPTION;
            END IF;
          END LOOP;
        END IF;

        --6、校验附件:根据系统参数设置来判断(厨电要求必须上传附件)
        BEGIN
          /*
          --校验附件:根据收款方法判断附件是否已经上传（厨电必须上传附件）
          SELECT TM.APPENDIX_FLAG
            INTO V_APPENDIX_FLAG
            FROM CIMS.T_AR_CASH_RECEIPT_HEADERS TH,
                 CIMS.T_AR_CASH_RECEIPT_LINES   L,
                 CIMS.INTF_AR_ACCE_SOLU_PAY_CCS PAY,
                 CIMS.T_AR_RECEIPT_METHODS      TM
           WHERE TH.CASH_RECEIPT_ID = L.CASH_RECEIPT_ID
             AND PAY.CASH_RECEIPT_LINES_ID = L.CASH_RECEIPT_LINES_ID
             AND PAY.THREE_PAY_ID = P_THREE_PAY_ID
             AND TM.RECEIPT_METHOD_ID = TH.RECEIPT_METHOD_ID;
             */
          PKG_BD.P_GET_PARAMETER_VALUE('ar_threepay_appendix_param',
                                       THREE_PAY_ROW.ENTITY_ID,
                                       NULL,
                                       NULL,
                                       V_APPENDIX_FLAG);
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := '获取三方解付申请附件上传标志异常，请联系管理员';
            RAISE V_BIZ_EXCEPTION;
        END;

        SELECT COUNT(*)
            INTO V_APPENDIX_COUNT
            FROM CIMS.INTF_AR_SOLU_APPENDIX_CCS X
           WHERE X.CCS_THREE_PAY_ID = THREE_PAY_ROW.THREE_PAY_ID;

        IF V_APPENDIX_FLAG = 'Y' THEN
          --获取CCS上传的附件记录数，若总记录数大于0，则表示已经上传附件，否则，没有上传附件。
          /*
          SELECT COUNT(*)
            INTO V_APPENDIX_COUNT
            FROM CIMS.INTF_AR_SOLU_APPENDIX_CCS X
           WHERE X.CCS_THREE_PAY_ID = THREE_PAY_ROW.THREE_PAY_ID;
           */
          IF V_APPENDIX_COUNT = 0 THEN
            P_MESSAGE := '三方解付申请' || THREE_PAY_ROW.SOURCE_CODE || '的附件为空';
            RAISE V_BIZ_EXCEPTION;
          END IF;
        END IF;

        --附件插入接口表  add by anht
        IF V_APPENDIX_COUNT > 0 THEN
          --附件ID
          SELECT 'ARTP' || S_AR_TP_APPENDIX.NEXTVAL
            INTO V_RP_APPENDIX
            FROM DUAL;
          FOR RP_APPENDIX_ROW IN C_RP_APPENDIX LOOP
            --插入附件表
            INSERT INTO IMS_FILEINFO_INTERFACE
              (ID, BUSINESS_ID, BUSINESS_TYPE, FILE_PATH, CREATED_DATE)
            VALUES
              (SEQ_IMS_FILEINFO.NEXTVAL,
               V_RP_APPENDIX,
               'arReceiptThreePayCode',
               RP_APPENDIX_ROW.FILE_PATH,
               SYSDATE);
          END LOOP;
        END IF;

        --校验通过，将数据插入业务表
        --获取业务表三方解付明细ID序列
        SELECT S_AR_ACCE_SOLU_PAY.NEXTVAL INTO V_THREE_PAY_ID FROM DUAL;
        BEGIN
          INSERT INTO CIMS.T_AR_ACCE_SOLU_PAY
            (THREE_PAY_ID,
             CASH_RECEIPT_LINES_ID,
             SOLUTION_PAY_AMOUNT,
             DELIVERY_NOTICE_CODE,
             SOLUTION_PAY_BY,
             SOLUTION_PAY_TIME,
             SOLUTION_PAY_STATUS,
             ENTITY_ID,
             VERSION_NUM,
             SOURCE_SYSTEM,
             SOURCE_CODE,
             SOURCE_LINE_CODE,
             APPENDIX_ID --附件ID  add by anht
             )
          VALUES
            (V_THREE_PAY_ID,
             V_RECEIPT_LINE_ID,
             THREE_PAY_ROW.SOLUTION_PAY_AMOUNT,
             THREE_PAY_ROW.DELIVERY_NOTICE_CODE,
             THREE_PAY_ROW.SOLUTION_PAY_BY,
             THREE_PAY_ROW.SOLUTION_PAY_TIME,
             THREE_PAY_ROW.SOLUTION_PAY_STATUS,
             THREE_PAY_ROW.ENTITY_ID,
             '0',
             THREE_PAY_ROW.SOURCE_SYSTEM,
             THREE_PAY_ROW.SOURCE_CODE,
             THREE_PAY_ROW.SOURCE_LINE_CODE,
             V_RP_APPENDIX --附件ID  add by anht
             );
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CCS_INTO_CIMS.P_THREE_PAY_APPLY_INTO',
                                                SQLCODE,
                                                'CCS三方解付，接口表数据插入业务表失败！：' ||
                                                SQLERRM);
            RAISE V_BIZ_EXCEPTION;
        END;
        --更新接口表数据，处理状态-成功，处理信息-SUCCESS
        BEGIN
          UPDATE CIMS.INTF_AR_ACCE_SOLU_PAY_CCS C
             SET C.STATUS           = '0',
                 C.ERROR_INFO       = 'SUCCESS',
                 C.ATTRIBUTE1       = '1',
                 C.BUS_THREE_PAY_ID = V_THREE_PAY_ID
           WHERE C.THREE_PAY_ID = P_THREE_PAY_ID;
          P_MESSAGE := 'SUCCESS';
        EXCEPTION
          WHEN OTHERS THEN
            P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CCS_INTO_CIMS.P_THREE_PAY_APPLY_INTO',
                                                SQLCODE,
                                                'CCS三方解付，回写异常，更新接口表失败！：' ||
                                                SQLERRM);
            RAISE V_BIZ_EXCEPTION;
        END;
        --COMMIT;
      END LOOP;
    ELSE
      P_MESSAGE := 'CCS提供的三方解付明细申请ID （' || P_THREE_PAY_ID ||
                   '）有误，已处理过的数据不再进行解付处理，请联系管理员';
      RAISE V_BIZ_EXCEPTION;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      --ROLLBACK;
      BEGIN
        UPDATE CIMS.INTF_AR_ACCE_SOLU_PAY_CCS C
           SET C.STATUS = '1', C.ERROR_INFO = P_MESSAGE, C.ATTRIBUTE1 = '1'
         WHERE C.THREE_PAY_ID = P_THREE_PAY_ID;
        --COMMIT;
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CCS_INTO_CIMS.P_THREE_PAY_APPLY_INTO',
                                            SQLCODE,
                                            P_MESSAGE || SQLERRM);
      END;
  END;

  /*
  * CCS接口表数据插入业务表批量测试
  */
  PROCEDURE P_CCS_BATCH_INTO_CIMS(P_FLAG_ID IN NUMBER, --批处理ID，1-收款；2-转款；3-三方解付
                                  P_MESSAGE OUT VARCHAR2 --成功则返回“SUCCESS”，否则返回出错信息
                                  ) IS
    --CCS收款头接口表数据
    CURSOR C_INTF_BATCH_RECEIPT_HEAD IS
      SELECT *
        FROM CIMS.INTF_AR_RECEIPT_HEADERS_CCS H
       WHERE NVL(H.OPERATE_FLAG, '0') <> '1';
    RECEIPT_HEAD_ROW C_INTF_BATCH_RECEIPT_HEAD%ROWTYPE; --接口表收款头游标行数据

    --CCS转款头接口表数据
    CURSOR C_INTF_BATCH_TURNFEE_HEAD IS
      SELECT *
        FROM CIMS.INTF_AR_TURNFEE_HEADERS_CCS H
       WHERE NVL(H.OPERATE_FLAG, '0') <> '1';

    TURNFEE_HEAD_ROW C_INTF_BATCH_TURNFEE_HEAD%ROWTYPE; --接口表转款头游标行数据

    --CCS收款头接口表数据
    CURSOR C_BATCH_THREE_PAY_APPLY_DETAIL IS
      SELECT *
        FROM CIMS.INTF_AR_ACCE_SOLU_PAY_CCS H
       WHERE NVL(H.ATTRIBUTE1, '0') <> '1';

    THREE_PAY_ROW C_BATCH_THREE_PAY_APPLY_DETAIL%ROWTYPE; --解付明细接口表游标行数据
  BEGIN
    --收款
    IF P_FLAG_ID = 1 THEN
      FOR RECEIPT_HEAD_ROW IN C_INTF_BATCH_RECEIPT_HEAD LOOP
        PKG_AR_CCS_INTO_CIMS.P_RECEIPT_INTO_NEW(RECEIPT_HEAD_ROW.CASH_RECEIPT_ID,
                                                P_MESSAGE);
      END LOOP;
    ELSIF P_FLAG_ID = 2 THEN
      FOR TURNFEE_HEAD_ROW IN C_INTF_BATCH_TURNFEE_HEAD LOOP
        PKG_AR_CCS_INTO_CIMS.P_TURNFEE_INTO_NEW(TURNFEE_HEAD_ROW.CASH_TURNFEE_ID,
                                                P_MESSAGE);
      END LOOP;
    ELSIF P_FLAG_ID = 3 THEN
      FOR THREE_PAY_ROW IN C_BATCH_THREE_PAY_APPLY_DETAIL LOOP
        PKG_AR_CCS_INTO_CIMS.P_THREE_PAY_APPLY_INTO(THREE_PAY_ROW.THREE_PAY_ID,
                                                    P_MESSAGE);
      END LOOP;
    END IF;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        P_MESSAGE := PKG_BD.F_ADD_ERROR_LOG('PKG_AR_CCS_INTO_CIMS.P_CCS_BATCH_INTO_CIMS',
                                            SQLCODE,
                                            P_MESSAGE || SQLERRM);
      END;
  END;
END PKG_AR_CCS_INTO_CIMS;
/

