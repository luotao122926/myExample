create view V_CUSTOMER_CONTACTS as
select CONTACTS_ID,
       ENTITY_ID,
       CUSTOMER_ID,
       CUSTOMER_CODE,
       DEPT_ID,
       DEPT_CODE,
       CONTACTS_POSITION,
       CONTACTS_NAME,
       CONTACTS_PHONES,
       CONTACTS_MAIL,
       ACTIVE_FLAG,
       CREATED_BY,
       CREATION_DATE,
       LAST_UPDATE_DATE,
       LAST_UPDATE_BY,
       LAST_INTERFACE_DATE,
       SIEBEL_CONTACTS_ID,
       SIEBEL_CUSTOMER_ID,
       PRE_FIELD_01,
       PRE_FIELD_02,
       PRE_FIELD_03,
       PRE_FIELD_04,
       PRE_FIELD_05,
       PRE_FIELD_06
  from T_CUSTOMER_CONTACTS with read only
/

comment on column V_CUSTOMER_CONTACTS.CONTACTS_ID is '联系人ID'
/

comment on column V_CUSTOMER_CONTACTS.ENTITY_ID is '主体ID'
/

comment on column V_CUSTOMER_CONTACTS.CUSTOMER_ID is '客户ID'
/

comment on column V_CUSTOMER_CONTACTS.CUSTOMER_CODE is '客户编码'
/

comment on column V_CUSTOMER_CONTACTS.DEPT_ID is '事业部ID'
/

comment on column V_CUSTOMER_CONTACTS.DEPT_CODE is '事业部编码'
/

comment on column V_CUSTOMER_CONTACTS.CONTACTS_POSITION is '联系人职位'
/

comment on column V_CUSTOMER_CONTACTS.CONTACTS_NAME is '联系人姓名'
/

comment on column V_CUSTOMER_CONTACTS.CONTACTS_PHONES is '联系人电话'
/

comment on column V_CUSTOMER_CONTACTS.CONTACTS_MAIL is '联系人邮箱'
/

comment on column V_CUSTOMER_CONTACTS.ACTIVE_FLAG is '是否有效(Y/N)'
/

comment on column V_CUSTOMER_CONTACTS.CREATED_BY is '创建人'
/

comment on column V_CUSTOMER_CONTACTS.CREATION_DATE is '创建日期'
/

comment on column V_CUSTOMER_CONTACTS.LAST_UPDATE_DATE is '最后修改时间'
/

comment on column V_CUSTOMER_CONTACTS.LAST_UPDATE_BY is '最后修改人'
/

comment on column V_CUSTOMER_CONTACTS.LAST_INTERFACE_DATE is '最后同步时间'
/

comment on column V_CUSTOMER_CONTACTS.SIEBEL_CONTACTS_ID is '主数据联系人ID'
/

comment on column V_CUSTOMER_CONTACTS.SIEBEL_CUSTOMER_ID is '主数据客户ID'
/

comment on column V_CUSTOMER_CONTACTS.PRE_FIELD_01 is '预留字段1'
/

comment on column V_CUSTOMER_CONTACTS.PRE_FIELD_02 is '预留字段2'
/

comment on column V_CUSTOMER_CONTACTS.PRE_FIELD_03 is '预留字段3'
/

comment on column V_CUSTOMER_CONTACTS.PRE_FIELD_04 is '预留字段4'
/

comment on column V_CUSTOMER_CONTACTS.PRE_FIELD_05 is '预留字段5'
/

comment on column V_CUSTOMER_CONTACTS.PRE_FIELD_06 is '预留字段6'
/

